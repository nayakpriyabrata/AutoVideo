# AutoVideoAI v7.0.10 — exact Flow image recovery

The reported job reaches shot_001 closing-frame recovery but cannot identify its existing image. The screenshots show multiple gallery images and a reused scene-only prompt. Previous recovery compared that text only to the complete Agent instruction (routing wrapper and optional tracking label). Flow can omit that wrapper from Reuse prompt.

This update accepts either the exact full submitted instruction or the exact creative brief extracted from our known instruction envelope. It normalizes Unicode and whitespace only. Changed scene text, partial matches, unknown envelopes, unrelated tiles, and image/video mismatches remain rejected. Existing journals are supported without deleting or resetting them. No extra generation is authorized by this change. Files still undergo normal image validation.

Recovery logs and recovery.json now include gallery candidate and readable/unavailable prompt counts. This makes a missing Reuse prompt control distinguishable from an exact-text mismatch. If Flow exposes neither stable media identity nor an exact matching prompt, automatic recovery still stops instead of guessing.

## Upgrade and resume the existing job

1. Stop Studio, CLI jobs and the local runner. Back up the existing installation.
2. Extract the new build and copy its source into the existing job installation. Preserve outputs/, data/, local .env/config settings, browser profiles, project bindings and request journals. Do not overwrite saved local configuration with example defaults. Do not delete .flow-request.json files or click Generate manually.
3. Confirm VERSION reads 7.0.10 and restart Studio/the runner.
4. Resume the same job:

```sh
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6
```

Expected successful correlation message: Verified N image candidate(s) against the saved exact generation prompt; recovering without a new generation.

The job's gallery and WSL browser are not accessible in the build/test environment. This release fixes the reproduced matching defect; it does not claim that the user's live job has completed. If it still cannot match, provide storyboard/shot_001_close.jpg.flow-request.json and storyboard/shot_001_close.jpg.recovery.json (remove credentials/signed URL query tokens before sharing). Logs now identify unreadable controls or unmatched candidate prompts.

All v7.0.9 compact previews, batch B-roll approval and optional clip logos remain included.

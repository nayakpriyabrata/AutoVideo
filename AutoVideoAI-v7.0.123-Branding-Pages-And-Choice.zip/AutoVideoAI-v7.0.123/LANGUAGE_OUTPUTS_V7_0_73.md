# AutoVideoAI 7.0.73 — language outputs, background music, cleanup keeps every video

## What changed

### 1. The English master gets the profile intro and outro
- When a production has language editions and the English channel profile has an intro or outro, the English master is branded automatically at the end of the render.
- Only intro and outro are added. Captions, music, text cards and any channel mark are already in the master, so the logo and channel name are not applied twice.
- Output: `render/<job>-en-branded.mp4`. The unbranded `render/<job>-final.mp4` stays where it was.
- Single-language productions are unchanged.

### 2. Finished editions are copied into render/
- Every finished Hindi or Odia edition is copied, verified by SHA-256, to `render/<job>-<lang>-edition.mp4`.
- The originals stay in `language_editions/<stamp>/exports/`.
- Editions that already exported (for example the 21 Oct run) are copied the next time the editions step runs.

### 3. Background music was effectively silent
Diagnosis (measured with real FFmpeg on a synthetic narration and a music bed at a realistic level):
- The music was in the mix, but the sidechain ducking was 8:1 at -30 dBFS with a 600 ms release. Between phrases the bed fell to about -46 dBFS, which is inaudible.
- The Create slider defaulted to 0.10, and so did Pro mode; standard mode used 0.16. Realistic music at 0.10–0.16 sat roughly 15–25 dB under narration, and near-silent in pauses once ducked.

Changes:
- Ducking is 4:1 at -28 dBFS (threshold 0.04), 120 ms attack, 400 ms release. Music drops about 9 dB under speech and comes back in pauses.
- Default narration Music gain is 0.20 (Create slider and presentation default).
- The same ducking is used in the Finishing Studio, the editions, the music overlay and Clip Studio.

Existing jobs keep their saved Music gain. If a job was created at 0.10, raise **Music gain** to about 0.20 before rendering again.

### 4. Cleanup keeps every language video (fixes a 7.0.72 gap)
- 7.0.72 would have treated the branded master, the render/ edition copies and the edition exports as media to free. They are now kept.
- New: keep a verified copy of every kept video in a folder you choose:
  - CLI: `python3 cli.py v3 cleanup-apply <job_id> --digest <digest> --keep-video-dir "D:/Videos/Ready"`
  - GUI: "Also copy the videos…" field in Manage saved jobs & clips → Free space after finishing.
- Copies keep their original names. An existing file with the same name must be identical, otherwise nothing is deleted.
- The folder must be outside the job.

### 5. Commands
- `python3 cli.py v3 language-outputs <job_id>`: adds the English intro/outro if needed, then renders pending editions and copies them into render/. The dashboard button "Add English intro/outro and render pending language editions" does the same.

### 6. Caption timing: warning added, cause not yet fixed
- On-screen transcript timing can drift 2–3 s when captions are estimated from the script instead of measured from speech.
- Estimated timing happens when: the Odia caption provider is forced to `script-timed`; or Groq and local Whisper are both unavailable, so the script-estimate fallback is used.
- Now: when captions are estimated, the render adds a readiness warning ("Captions are estimated from the script…").
- Not done: a measured fix. It needs the job's `audio/*.words.meta.json` (engine name) and first word timings to confirm which path your job used.

## Not in this release
- Playful text cards and five-point educational boxes.
- Hook generation with Gemini Web.
- Full channel-manager evaluation and its feature list.

## Install
Requires 7.0.72 installed. For an installation at 7.0.70, first run the 7.0.71 and 7.0.72 updaters, in order.

```
python3 ../AutoVideoAI-v7.0.73/tools/update_v772_to_v773.py .            # dry run
python3 ../AutoVideoAI-v7.0.73/tools/update_v772_to_v773.py . --apply    # installs code only
```
Stop the dashboard first. Outputs, saved jobs, profiles, music and browser profiles are not copied or changed.

## Tests
- `tests/test_v773_language_outputs.py`: intro/outro plan, skip rules, render/ copies, record.
- `tests/test_v773_cleanup_keeps_language_videos.py`: deliverables kept, keep-directory copy, conflict stops before deletion.
- `tests/test_audio_mix_quality.py` (ducking must cut the bed by at least 6 dB under speech and recover) passes with the new ducking.
- `tests/test_optional_presentation.py` expectation updated: narrated default Music gain is 0.20 in every mode.
- Full suite against the 7.0.72 tree: the same 57 environmental failures and 11 errors; no new failures.
- FFmpeg-based render tests need ffprobe on the machine; the sandbox used for this build has none, so the final render and caption burn were not played back here.

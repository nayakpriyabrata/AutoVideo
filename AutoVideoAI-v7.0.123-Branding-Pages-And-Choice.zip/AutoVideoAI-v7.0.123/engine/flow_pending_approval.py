"""v7.0.99: read-only evidence that a saved Flow video request is waiting for an approval click.

Field case (job ``20261022-143856-7-small-daily-habits-tha-9729``, 2026-10-26 14:50 IST): the saved Flow
project showed the agent turn

    "I'm going to generate 1 video clip interpolating between your start and end frames using Omni 1.1
     Flash in 16:9 at 360p for 6 seconds. Would you like me to kick off this 1 video generation, costing
     5 credits?"   [Approve] [Always approve] [Reject]

Nothing had been generated, so every download-only recovery scan honestly reported "no verified match" and
paused again. The card is the whole blocker: a video request is confirmed by a *click*, not by a wait.

This module answers, from files only and without opening a browser:

* was this take submitted (intent/submitted ledger line, or a ``submitted``/``submission_uncertain`` phase)?
* was an approval ever reserved or clicked for it (journal ``approval_reservations``, ledger ``approval``)?
* therefore, is a pending card the most likely reason no video exists?

It never clicks and never writes. ``approval_decision`` is the pure guard used by the provider before any
approve action, so the rules can be tested without Playwright.
"""
from __future__ import annotations

import json
from pathlib import Path

JOURNAL_SUFFIX = '.flow-request.json'
SUBMITTED_PHASES = {'submitted', 'submission_uncertain'}


def _load(path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def shot_id_for(journal) -> str:
    parts = Path(journal).as_posix().split('/')
    for index, part in enumerate(parts):
        if part == 'shots' and index + 1 < len(parts):
            return parts[index + 1]
    return ''


def evidence_for(journal) -> dict:
    """Describe one saved request: submitted, approved, and whether a card is probably pending."""
    journal = Path(journal)
    request = _load(journal)
    target = journal.name[:-len(JOURNAL_SUFFIX)] if journal.name.endswith(JOURNAL_SUFFIX) else journal.name
    ledger = journal.with_name(journal.name[:-len(JOURNAL_SUFFIX)] + '.submit-ledger.jsonl')
    try:
        from .flow_submit_guard import read_events
        events = read_events(str(ledger))
    except (OSError, ValueError, ImportError):
        events = []
    reservations = [r for r in (request.get('approval_reservations') or []) if isinstance(r, dict)]
    # ``flow_approval.reserve`` writes a reservation immediately before the click, so a reservation is
    # evidence that this card was approved (or an approval was attempted); the ledger line confirms it.
    clicked = ([e for e in events if e.get('event') == 'approval'] or reservations)
    submitted = (any(e.get('event') in ('intent', 'submitted', 'unreadable') for e in events)
                 or str(request.get('phase') or '') in SUBMITTED_PHASES)
    costs = [r.get('cost') for r in reservations if isinstance(r.get('cost'), int)]
    kind = str(request.get('kind') or '')
    # Only a video request needs a credit card. An image request is free and generates without one.
    needs_card = kind == 'video'
    suspected = bool(needs_card and submitted and not clicked
                     and str(request.get('status') or '') != 'downloaded')
    if not needs_card:
        reason = 'an image request is free and needs no approval card'
    elif clicked:
        reason = 'an approval was already reserved/clicked for this request'
    elif not submitted:
        reason = 'this request was never submitted'
    elif suspected:
        reason = ('no approval click is recorded for this submitted video request: Flow is probably still '
                  'waiting on its Approve/Reject card, or the card was approved directly in the browser (that '
                  'click is not recorded here)');
    else:
        reason = 'this request is already downloaded'
    return {'journal': str(journal), 'target': target, 'shot_id': shot_id_for(journal),
            'kind': kind, 'phase': str(request.get('phase') or ''),
            'submitted': bool(submitted), 'approved': bool(clicked),
            'needs_approval_card': bool(needs_card), 'suspected_pending': bool(suspected),
            'cost': max(costs) if costs else None, 'reason': reason}


def approval_evidence(job_dir) -> list[dict]:
    """Every unresolved Flow journal of a job, with approval evidence. Read-only."""
    root = Path(job_dir)
    if not root.is_dir():
        return []
    rows = []
    for journal in sorted(root.rglob('*' + JOURNAL_SUFFIX)):
        rows.append(evidence_for(journal))
    return rows


def pending(job_dir) -> list[dict]:
    return [row for row in approval_evidence(job_dir) if row.get('suspected_pending')]


def approve_command(job_id: str, row: dict) -> str:
    """The one command that approves this exact card once, or an empty string when none applies."""
    if not row.get('suspected_pending'):
        return ''
    shot = row.get('shot_id')
    if not shot:
        return ''
    cost = row.get('cost')
    credits = str(cost) if isinstance(cost, int) else '<credits on the card>'
    return (f'python3 cli.py v3 approve-request {job_id} --shot-id {shot} '
            f'--confirm-credits {credits}')


def approval_decision(probe, confirm_credits) -> tuple[bool, str]:
    """Pure guard: may this visible card be clicked once? Nothing is clicked here.

    ``probe`` is what the browser read: ``{'visible': bool, 'cost': int|None, 'question': str,
    'video': bool}``. Every refusal names what to do instead.
    """
    probe = probe or {}
    if not probe.get('visible'):
        return False, ('no clickable Approve control is visible in the saved project; nothing was clicked. '
                       'Wait for the card to appear, or download a video that already exists.')
    cost = probe.get('cost')
    if not isinstance(cost, int) or isinstance(cost, bool) or cost < 0:
        return False, ('the visible card does not state a readable credit cost; nothing was clicked. '
                       'Approve it yourself in the saved project if you accept the charge.')
    if not probe.get('video'):
        return False, ('the newest Flow agent turn is not a video generation request; nothing was clicked. '
                       'Approve an image card - if any - in Flow directly; images need no approval here.')
    if confirm_credits is None:
        return False, (f'the card asks for {cost} credits; pass --confirm-credits {cost} to approve it once, '
                       'or click Approve in the saved project yourself')
    try:
        confirmed = int(confirm_credits)
    except (TypeError, ValueError):
        return False, f'--confirm-credits must be a number of credits (the card asks for {cost}); nothing was clicked'
    if confirmed != cost:
        return False, (f'you confirmed {confirmed} credits but the card asks for {cost}; nothing was clicked. '
                       f'Re-run with --confirm-credits {cost} if {cost} credits is acceptable.')
    return True, f'card asks for {cost} credits; one approval will be clicked'

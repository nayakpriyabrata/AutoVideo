"""Unattended continuation after recoverable Flow interruptions.

A job that stops on a recoverable browser, network, or busy-service error is
retried by a background supervisor after a growing delay, without a manual
Resume. The supervisor lives in the Studio process: it can only run while the
computer is awake and Studio is open. Auth, quota, approval, missing-media and
user-decision stops are never retried.
"""
import json
import threading
import time
from pathlib import Path

from .production import save

STATE_FILE = 'auto_resume.json'
BACKOFF_MINUTES = (2, 5, 10, 20, 30, 60)
MAX_AUTOMATIC_RESUMES = 8
SCAN_SECONDS = 30

_supervisor = None
_supervisor_lock = threading.Lock()


def load(root):
    try:
        data = json.loads((Path(root) / STATE_FILE).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write(root, data):
    save(Path(root) / STATE_FILE, data)


def strict_failure_action(settings, original, pause_requested):
    """Decide what a strict Flow frame failure does: 'retry', 'pause' or 'fail'.

    'retry' hands the job to run_with_recovery, which records a recoverable
    failure for automatic resume if its own budget runs out. A pending Flow
    request is never retried here: it may already have consumed credits, so it
    keeps the existing manual path.
    """
    from .automatic_recovery import can_recover
    from .providers.flow_browser import FlowRequestPending
    if pause_requested:
        return 'pause'
    if settings.get('flow_auto_recovery', True) is not True:
        return 'fail'
    if original is None or isinstance(original, FlowRequestPending):
        return 'fail'
    return 'retry' if can_recover(original) else 'fail'


def note_recoverable_failure(root, reason, *, progress=None, now=None):
    """Record that the job stopped on a recoverable interruption."""
    data = load(root)
    data['pending_failure'] = {
        'recoverable': True,
        'reason': str(reason)[:500],
        'progress': list(progress or []),
        'at': time.time() if now is None else now,
    }
    _write(root, data)


def after_run(factory, job_id, result, error=None, *, now=None):
    """Update the automatic-resume state when a Studio production run ends."""
    now = time.time() if now is None else now
    root = factory.pm.job_dir(job_id)
    data = load(root)
    failure = data.pop('pending_failure', None) or {}
    status = result.get('status') if isinstance(result, dict) else None
    if status == 'done':
        data = {'state': 'idle', 'attempts': 0, 'updated_at': now}
    elif failure.get('recoverable'):
        progress = list(failure.get('progress') or [])
        if progress and progress > list(data.get('best_progress') or []):
            # Saved media advanced since the last automatic resume: this is a
            # new interruption, not a stagnant loop, so the budget restarts.
            data['best_progress'] = progress
            data['attempts'] = 0
        attempts = int(data.get('attempts', 0) or 0)
        if attempts >= MAX_AUTOMATIC_RESUMES:
            data.update(state='exhausted', reason=failure.get('reason', ''), updated_at=now)
        else:
            delay = BACKOFF_MINUTES[min(attempts, len(BACKOFF_MINUTES) - 1)] * 60
            data.update(state='waiting', attempts=attempts + 1, next_at=now + delay,
                        reason=failure.get('reason', ''), updated_at=now)
    else:
        message = result.get('message') if isinstance(result, dict) else ''
        reason = error or message or status or 'stopped'
        data.update(state='stopped', reason=str(reason)[:500], updated_at=now)
    _write(root, data)
    return data


def candidate_jobs(outputs_root):
    root = Path(outputs_root)
    if not root.is_dir():
        return []
    return sorted(child for child in root.iterdir() if child.is_dir() and (child / STATE_FILE).is_file())


def scan_once(factory, *, now=None, start=None):
    """Start every job whose automatic resume is due. Returns the started job ids."""
    from . import job_monitor
    start = start or job_monitor.start
    now = time.time() if now is None else now
    started = []
    for folder in candidate_jobs(factory.pm.root):
        data = load(folder)
        state = data.get('state')
        if state == 'waiting' and float(data.get('next_at', 0) or 0) > now:
            continue
        if state not in ('waiting', 'running'):
            continue
        job_id = folder.name
        # Mark the attempt before starting, so a fast failure cannot be
        # overwritten by a stale 'running' record. Restore it if nothing starts.
        previous = dict(data)
        data.update(state='running', started_at=now)
        _write(folder, data)
        if start(factory, job_id):
            factory.pm.log(job_id, 'auto_resume_started', {'attempt': data.get('attempts', 0)})
            started.append(job_id)
        else:
            _write(folder, previous)
    return started


def ensure_supervisor(factory, *, interval=SCAN_SECONDS):
    """Start the background supervisor once per Studio process."""
    global _supervisor
    with _supervisor_lock:
        if _supervisor is not None and _supervisor.is_alive():
            return _supervisor

        def loop():
            while True:
                try:
                    scan_once(factory)
                except Exception as error:  # keep supervising; log for the runtime record
                    print(f'[auto-resume] scan failed: {type(error).__name__}: {error}')
                time.sleep(interval)

        _supervisor = threading.Thread(target=loop, name='autovideo-auto-resume', daemon=True)
        _supervisor.start()
        return _supervisor


def describe(data, now=None):
    """Short, user-facing status line for a job, or '' when nothing is pending."""
    now = time.time() if now is None else now
    state = data.get('state')
    if state == 'waiting':
        due = max(0, int(float(data.get('next_at', now)) - now))
        minutes = (due + 59) // 60
        return (f'Automatic resume in about {minutes} min (attempt {data.get("attempts", 1)} of {MAX_AUTOMATIC_RESUMES}). '
                'Keep this computer awake with Studio open; saved media and requests are kept.')
    if state == 'running':
        return 'Automatic resume is running.'
    if state == 'exhausted':
        return f'Automatic resume stopped after {MAX_AUTOMATIC_RESUMES} attempts. Resume manually once the Flow problem is fixed.'
    return ''

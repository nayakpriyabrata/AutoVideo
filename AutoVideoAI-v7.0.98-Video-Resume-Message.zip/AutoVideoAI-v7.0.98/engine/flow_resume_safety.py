"""Zero-network preflight for outstanding Google Flow requests.

Pending journals are not proof of successful generation, and missing image files
are not authorization for another submission. Default to preserving credits.
"""
from __future__ import annotations
import json
import hashlib
from pathlib import Path


def check_job(job_dir):
    root = Path(job_dir).expanduser().absolute()
    if root.is_symlink() or not (root / 'production_manifest.json').is_file():
        raise ValueError('Expected an existing, non-symlink AutoVideoAI job directory')
    rows = []
    for journal in sorted(root.rglob('*.flow-request.json')):
        if journal.is_symlink():
            rows.append({'journal': str(journal.relative_to(root)), 'state': 'unreadable', 'reason': 'symlink'}); continue
        try:
            data = json.loads(journal.read_text(encoding='utf-8'))
            state = str(data.get('status') or data.get('state') or 'unknown').lower()
            image_path = Path(str(journal)[:-len('.flow-request.json')])
            image_present = image_path.is_file() and image_path.stat().st_size > 0
            if state == 'superseded_by_authorized_replacement':
                # Supersession is not a claim that the original request was
                # downloaded. Both the new asset and its installed frame must
                # remain bound to the committed replacement bytes.
                expected = data.get('replacement_sha256')
                valid = isinstance(expected, str) and len(expected) == 64
                for value in (data.get('replacement_file'), data.get('replacement_target')):
                    candidate = root / str(value or '')
                    valid = valid and (bool(value) and not candidate.is_symlink()
                        and candidate.resolve().is_relative_to(root.resolve())
                        and candidate.is_file())
                    if valid:
                        valid = hashlib.sha256(candidate.read_bytes()).hexdigest() == expected
                if not valid:
                    rows.append({'journal': str(journal.relative_to(root)), 'state': 'replacement_missing_or_changed'})
                continue
            if data.get('scope') in ('isolated_one_frame_one_request', 'isolated_image_v1') and state == 'downloaded':
                if (not image_present or image_path.is_symlink() or
                        hashlib.sha256(image_path.read_bytes()).hexdigest() != data.get('media_sha256')):
                    rows.append({'journal': str(journal.relative_to(root)), 'state': 'replacement_missing_or_changed'})
                continue
            if (data.get('scope') == 'isolated_image_v1' and str(data.get('phase') or '') == 'submission_uncertain'
                    and not image_present):
                # v7.0.93: image requests cost no Flow credits. A submit that was never acknowledged, with no local
                # image, goes through generate(): recover once, then one fresh image request if nothing was produced
                # (up to 3 per shot). 'submitted' journals keep blocking (7.0.87 download-only wait); video journals
                # keep blocking until explicitly reconciled.
                continue
            if state in ('pending', 'submitted', 'running', 'generating', 'unknown', 'unreadable'):
                # v7.0.96: carry the last recovery verdict so a blocked Resume explains itself
                # instead of repeating the same wait.
                rows.append({'journal': str(journal.relative_to(root)), 'state': state, 'local_image_exists': image_present,
                             'kind': str(data.get('kind') or ''),
                             'scope': str(data.get('scope') or ''),
                             'phase': str(data.get('phase') or ''),
                             'recovery_state': str(data.get('recovery_state') or ''),
                             'last_recovery_error': str(data.get('last_recovery_error') or '')[:300],
                             'saved_project_url': str(data.get('saved_project_url') or data.get('project_url') or ''),
                             'observed_project_url': str(data.get('observed_project_url') or '')})
        except (OSError, ValueError, TypeError) as exc:
            rows.append({'journal': str(journal.relative_to(root)), 'state': 'unreadable', 'reason': type(exc).__name__})
    return {'job_id': root.name, 'safe_to_generate': not rows, 'unresolved_count': len(rows), 'unresolved': rows,
            'policy': 'Conservative: pending/unreadable requests always require explicit reconciliation before new generation.'}


def journal_target(journal) -> str:
    """``flow/shots/shot_014/take_01.mp4`` from its ``.flow-request.json`` path."""
    journal = str(journal or '')
    return journal[:-len('.flow-request.json')] if journal.endswith('.flow-request.json') else journal


def journal_shot_id(journal) -> str:
    """``shot_014`` from a journal path written by the flow worker, else ''."""
    parts = str(journal or '').split('/')
    for index, part in enumerate(parts):
        if part == 'shots' and index + 1 < len(parts):
            return parts[index + 1]
    return ''


def image_request_row(row) -> bool:
    """An image request: the only journal that may be replaced without credit approval.

    Journals written before ``kind``/``scope`` were recorded are classified by their path: a take under
    ``flow/shots/<shot>/`` (or any video file) is a video request, everything else is an image request.
    """
    kind = str(row.get('kind') or '')
    if kind:
        return kind == 'image'
    scope = str(row.get('scope') or '')
    if scope:
        return scope in ('isolated_image_v1', 'isolated_one_frame_one_request')
    target = journal_target(row.get('journal') or '')
    if target.startswith('flow/shots/') or target.lower().endswith(('.mp4', '.webm', '.mov')):
        return False
    return True


class FlowResumeBlocked(RuntimeError):
    def __init__(self, report):
        self.report = report
        job = report['job_id']
        images, videos, reasons = [], [], []
        for row in report.get('unresolved', []):
            journal = str(row.get('journal') or '')
            if not journal.endswith('.flow-request.json'):
                continue
            target = journal_target(journal)
            (images if image_request_row(row) else videos).append(target)
            if row.get('recovery_state'):
                reasons.append(f"{target}: {row['recovery_state']}"
                               + (f" ({row['last_recovery_error']})" if row.get('last_recovery_error') else ''))
        saved = images + videos
        message = (f"Safe Resume blocked: {report['unresolved_count']} unresolved Flow request journal(s) for {job}. "
                   f"Saved request(s): {', '.join(saved) or 'see logs/resume-reconciliation.json'}. ")
        if reasons:
            message += "Last recovery result: " + '; '.join(reasons) + ". "
        if images:
            steps = '; '.join(f"python3 cli.py v3 archive-request {job} {image}" for image in images)
            message += ("Image requests cost no Flow credits, so ONE fresh image request may be submitted without "
                        f"credit approval: `{steps}`. That archives the old request, kept on record, and the next "
                        "Resume makes one new free image request; the archive refuses when a real image is already "
                        "saved. ")
        if videos:
            # 7.0.98: a video request is not free. Saying "archive it, image requests are free" here was wrong and
            # the command it named (without --confirm-new-credit-spend) only printed a dry run, so it never moved.
            shot_ids = sorted({journal_shot_id(item) for item in videos} - {''})
            shot_flag = (' --shot-id ' + shot_ids[0]) if len(shot_ids) == 1 else ''
            message += ("Video request(s) " + ', '.join(videos) + " cannot be redone for free: a new Flow video "
                        "spends credits, so nothing is resubmitted automatically. First recover the exact saved "
                        "video (0 credits, QC still runs): "
                        f"`python3 cli.py v3 recover-flow-video {job}{shot_flag} --wait-seconds 180`. If you can see "
                        "that video in the saved project, pass its exact editor URL: "
                        f"`python3 cli.py v3 recover-flow-video {job}{shot_flag} --asset-url https://flow.google.com/project/<id>/edit/<id> "
                        "--asset-reviewed` (the URL must belong to the project saved in the request). Only if the video "
                        "does not exist in that project is a replacement needed: "
                        + '; '.join(f"python3 cli.py v3 archive-request {job} {video} --confirm-new-credit-spend"
                                    for video in videos)
                        + " archives the old request and the next Resume submits ONE new PAID video request. ")
        if saved:
            waits = " and waits once (60 s per image)" if images else ""
            message += (f"Resume reopens the exact saved project{waits}; it never submits anything on its own while "
                        "a journal is unresolved. ")
        message += ("Read-only diagnosis of every journal: "
                    f"`python3 tools/flow_resume_preflight.py outputs/{job}`. "
                    "See logs/resume-reconciliation.json for recovery results.")
        super().__init__(message)


def require_safe_job(job_dir):
    result = check_job(job_dir)
    if not result['safe_to_generate']:
        raise FlowResumeBlocked(result)
    return result

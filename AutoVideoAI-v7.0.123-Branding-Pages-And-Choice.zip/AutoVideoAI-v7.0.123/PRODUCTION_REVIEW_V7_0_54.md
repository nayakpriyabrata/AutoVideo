# AutoVideoAI development review — 17 October 2026

## Assessment

The tool has useful planning, local rendering, saved-job and provider components, but its signed-in Flow automation is not yet production dependable. The incident involved three separate classes of failure: confusing an old asset with a new request, missing or stale approval-card state, and losing a browser download when its target closed. The manual import successfully recovered outputs; it did not validate automatic end-to-end recovery. A universal “never fails” download promise would be misleading.

Use a layered workflow: exact browser capture when available, durable request journal, resumable download-only recovery, then explicit reviewed file import. Keep generated results available even if a provider UI changes. Never silently spend a second generation credit to compensate for a download failure.

## Delivered in 7.0.54

| Area | Concrete change | Remaining limitation |
|---|---|---|
| Flow transfers | Intercept an exact same-origin blob download anchor before its native click can close the target. Chunk bytes into a temporary file; validate before atomic publication. Existing native and event-URL paths remain. | Controlled chunk tests passed; live browser installation was unavailable here. Programmatic downloads without an anchor and whole-context crashes can still fail. |
| Recovery | Includes r1–r3 fixes for pre-existing assets, exact shot-project selection, pending-journal commit after accepted recovery and truthful blocked status. | Multiple rewritten/unreadable prompts still require review. No gallery-position guessing. |
| Approval | Includes a1 history-independent card reservations. Unknown-cost controls are polled instead of immediately reserved. | No unreadable cost is approved. “Always approve” in Flow is external state; visible cards and price verification may be absent. |
| External AI video | Optional per-job shot selection; export prompts, aspect, seconds, reference hashes and incoming paths. GUI previews/uploads, CLI import, per-shot receipt and normal QC. | Requires a saved shot plan. Does not submit to arbitrary third-party providers. REVIEW remains an allowed existing QC outcome. |
| Music | Automatic reliable mode tries local → browser-free Commons → Pixabay → original offline instrumental. Commons requires explicit CC0 or CC-BY-4.0 metadata; saves source, attribution, license evidence and checksum. Topic influences the query unless a music mood was supplied. | Metadata is evidence, not legal certainty; no guarantee against Content ID. This environment did not verify live catalog results. |
| B-roll | Production search exposes slot/total, query, retrieved count, elapsed operation heartbeat and validation phase. | These are work counters, not a promise of semantic accuracy or a reliable ETA. Clip Studio also displays per-slot search/validation progress. Its GUI refreshes between blocking source calls; production logs include heartbeat updates during source calls. |

## Recommended next work, in priority order

| Priority | Missing capability | Why it matters / acceptance criterion |
|---|---|---|
| P0 | Provider request state machine | Persist prepared, submitted, awaiting approval, approved, queued, completed, downloading and validated separately. Resume must continue the exact saved state, with no implicit resubmission. |
| P0 | Live Flow cohort regression harness | Record sanitized DOM fixtures for current cards, tiles and download menus; run a small explicitly authorized live canary. Releasing many patches validated only by mocks is insufficient. |
| P0 | A durable worker service | A process outside Streamlit owns video, B-roll and render tasks with heartbeat, cancellation and crash recovery. Closing the dashboard must never lose task ownership. |
| P0 | QC decision semantics | Separate warnings from failures; REVIEW should visibly require user disposition before publishing. Low continuity, wrong duration and blur must not be hidden by a high aggregate score. |
| P0 | Scene truth and reference scope | A location master must not override an explicitly different scene environment. Detect conflicting cast names and indoor/outdoor instructions before generating. Do not rewrite old approved prompts silently. |
| P1 | Unified media inbox | One GUI for automatic downloads, reviewed local uploads and external results, with shot binding, previews, SHA receipts and explicit replacement history. |
| P1 | Semantic B-roll matching | Show scene text beside each cutaway; reject off-topic footage; rank visual concepts rather than literal narration keywords. Cache searches and continue/retry individual slots. |
| P1 | Music audition and licensing receipt | Offer 3 theme-ranked previews, speech/instrumental flags, tempo/mood tags, automatic ducking and an attribution file included with exports. Prevent silent mismatch and reused generic tracks. |
| P1 | Render observability | Per-stage progress and current clip/shot, encoder time versus timeline duration, speed, heartbeat, estimated remaining time with uncertainty, and downloadable full logs. |
| P1 | Project lifecycle manager | Group image workers, video requests and references by job. Review remote cleanup only after local bytes and receipts validate; retain pending/shared projects. Show uncertain deletions as uncertain. |
| P1 | Publication checks | Platform profiles, caption-safe areas, loudness and true-peak checks, end-frame checks, language QA, rights/attribution bundle and a final publish-review screen. |
| P2 | Editorial and hook tools | Optional opening action in first 2 seconds, closing payoff, music-aware cuts, user-selected sound hooks, beat-aligned B-roll, chapter cards and side-by-side variants. |
| P2 | Cost and quality budgeting | Estimate browser projects, generation requests, runtime and likely credits before submission. Separate planned/approved/spent/unknown costs; never count a download retry as generation. |

## Suggested release gate

Before calling this production grade, demonstrate three complete jobs on the target WSL machine: a music-only 30-second reel, a narrated 5-minute video with B-roll, and a recovered old job. Each must survive a dashboard reconnect and a controlled browser interruption without duplicate paid requests. Validate every final export’s actual content and audio, not only its file header or aggregate QC score. Keep a known-good release and code-only rollback.

## What was deliberately not claimed

This review is based on source inspection, the supplied failure logs and automated local tests. It is not an exhaustive live execution of every feature or third-party website. The release does not promise copyright immunity, guaranteed virality, platform publishing success, or complete Flow UI stability. Automatic YouTube/Instagram/Facebook publishing and remote deletion of whole shared projects need their own explicit workflows and validation.


## Reference documentation

- Playwright Downloads: https://playwright.dev/python/docs/downloads — context lifetime controls download availability; context closure deletes its temporary downloads.
- MediaWiki Imageinfo: https://www.mediawiki.org/wiki/API:Imageinfo — public file URLs and extended metadata.
- CommonsMetadata: https://www.mediawiki.org/wiki/Extension:CommonsMetadata — extracted licensing metadata is a best-effort interpretation, not a rights guarantee.
- Pixabay FAQ: https://pixabay.com/service/faq/ — free music can still be registered with Content ID.


## Validation for this release

Full offline regression suite: 1,121 passed (13 deprecation warnings). Additional focused checks cover the final external-import, music-filtering and B-roll changes. Release archive checksums and a cumulative r3+a1 code-only upgrade were checked with runtime sentinel files preserved. Exact live Flow capture and live Commons search were not verified; the browser binary download in this environment was truncated.

# v7.0.77: language editions follow the job's choices

Update from 7.0.76 with `tools/update_v776_to_v777.py`.

## What changed

- **Text cards off means no cards in any edition.** The job's "Include text cards" setting is stored with each language batch. When it is off, no card is drafted for any language and no card is drawn, even if an older batch still has cards. When it is on, every language's cards are drafted from that language's own reviewed narration. If a language was prepared without cards, the render stops with a clear message to prepare that batch again.
- **Educational jobs get the points series in every edition.** The points box (2–8 points) and single takeaway, tip and warning cards are drafted per language and drawn with the same animation as the main video. Non-educational jobs keep the plain keypoint cards.
- **Hooks in every edition.** Hooks are drafted from each language's own narration after that language's voice is ready. If hook drafting fails for a language, that edition renders without hooks and the edition record carries a warning. The other languages are not affected.
- **Hook pill placement.** The pill starts below the channel-name badge in both orientations, so the two no longer overlap.
- **The English master is unchanged.** Its branding plan never takes edition cards or hooks.

Older jobs and batches without these flags keep the legacy behaviour: cards on, not educational, no hooks.

## Cleanup in this release

The release zip no longer ships the historical one-off update scripts (`tools/update_v*_to_v*.py` except the current one) or the four one-off Flow recovery scripts that have no callers. Their tests were removed too. Installs that need an earlier update should run the updater from that release's zip, in order. `tools/update_v776_to_v777.py` prints the exact chain when it is run on an older install.

## Tests

`tests/test_v777_edition_cards_hooks.py` covers the drafting choices, the plan gating, the primary-branding exclusion, the hook placement, and real FFmpeg renders that compare frames: the hook pill appears only while it is shown, and an edition with text cards off shows no points box.

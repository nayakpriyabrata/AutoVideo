# Clip music and Flow cleanup — v7.0.60

## Install

Stop Dashboard and CLI production. Extract this ZIP beside `AutoVideoAI-v7`, then run from the existing installation:

```bash
cat VERSION
python3 ../AutoVideoAI-v7.0.60/tools/update_v759_to_v760.py . --apply
./dashboard.sh
```

The code-only updater requires the existing installation to report `7.0.59` (or an already installed `7.0.60`). It backs up changed code. It does not copy or erase outputs, music, browser profiles, or saved jobs. Keep the shared outputs link and `AUTOVIDEO_MUSIC_LIBRARY` configuration if you use one.

## Background music for clips

In Clip Studio, expand **Background music**, enable **Add soft background music**, and choose **Reviewed shared music library**. Enter a topic/mood that matches the imported theme tags. Import a licensed audio file if needed, include the exact source page and license label, and confirm you reviewed its rights for the target platforms. Preview and select the track. An automatic theme match requires matching tags; you can select a specific reviewed track instead. Clip Studio prevents starting with no track. The clip report records the file hash and reviewed license/source page. The original speech stays audible under a low music bed. Review the rendered audio before publishing.

The existing reliable automatic option also checks the shared music library first, then may use other configured sources. Select **Reviewed shared music library** when you want an exact reusable track with recorded rights evidence.

## Remote project cleanup

Open **Manage saved jobs & clips**, select whole jobs, and choose **Review complete deletion**. The review lists the exact Flow project URLs, eligible isolated-image projects, and reasons other projects are retained. Check **Also delete verified isolated-image Flow projects**, then confirm complete deletion. The app checks the saved media hashes, request journal and live image gallery before using the project-level Delete menu, and requires a Flow deletion confirmation. If any remote deletion is uncertain, it retains the local job and recovery data. Its ledger marks an uncertain remote click so the app will not blindly retry it. Refresh and inspect that project manually before any further cleanup.

Video projects, pending requests, projects shared with other saved work, and image projects without a complete verified gallery inventory remain on Flow. There is no safe automatic deletion for those cases in this release. If you delete the local job while leaving a remote project, save its listed URL first. Remote deletion cannot be undone through the local application.

## Verification and limitations

Focused tests cover successful deletion, a missing remote confirmation that preserves the local job, library theme matching and changed-track refusal. Python compilation passed. The full Pytest runner in this workspace exits with a bus error before collection. This release has not been exercised against a signed-in live Flow account, so the exact current project-menu UI may require an adapter adjustment; failure keeps local records. Music rights and editorial fit still require review for YouTube, Instagram and Facebook.

"""Browser-free Commons music retrieval with explicit per-item license evidence."""
import hashlib,html,json,re,time
from pathlib import Path
from urllib.parse import urlsplit
import requests
LICENSES={'https://creativecommons.org/publicdomain/zero/1.0/','https://creativecommons.org/licenses/by/4.0/'}
def plain(value):return html.unescape(re.sub('<[^>]+>','',str(value)))[:1500]
def music_query(theme):
    text=str(theme).lower()
    for words,query in [(['rain','forest','nature','meditation'],'ambient piano instrumental'),(['confidence','motivation','success','habit'],'inspiring piano instrumental'),(['dance','joy','celebration'],'upbeat instrumental'),(['technology','ai ','science'],'electronic ambient instrumental')]:
        if any(w in text for w in words):return query
    return ' '.join(re.findall(r'[a-z]{3,}',text)[:5])+' instrumental'
def metadata(info):
    e=info.get('extmetadata',{});value=lambda k:plain(e.get(k,{}).get('value',''))
    license_url=value('LicenseUrl').replace('http://','https://')
    if license_url.rstrip('/')+'/' not in LICENSES:return None
    url=info.get('url','');u=urlsplit(url)
    if u.scheme!='https' or u.hostname!='upload.wikimedia.org' or u.username or u.password:return None
    if not str(info.get('mime','')).startswith('audio/'):return None
    return {'url':url,'license_url':license_url,'license':value('LicenseShortName'),
            'creator':value('Artist'),'attribution':value('Attribution'),'page_url':info.get('descriptionurl',''),
            'source':'wikimedia-commons','license_evidence':e}
def obtain(theme,workdir,session=None):
    session=session or requests.Session();query=music_query(theme);started=time.monotonic()
    response=session.get('https://commons.wikimedia.org/w/api.php',params={'action':'query','format':'json','generator':'search','gsrnamespace':6,'gsrsearch':query+' filetype:audio','gsrlimit':10,'prop':'imageinfo','iiprop':'url|mime|extmetadata'},headers={'User-Agent':'AutoVideoAI/7.0.54 (local video editor; licensed music lookup)'},timeout=(5,15),allow_redirects=False)
    response.raise_for_status();pages=response.json().get('query',{}).get('pages',{})
    for page in pages.values():
        if time.monotonic()-started>45:break
        row=metadata((page.get('imageinfo') or [{}])[0])
        if not row:continue
        target=Path(workdir)/('commons-'+hashlib.sha256(row['url'].encode()).hexdigest()[:16]+'.ogg');target.parent.mkdir(parents=True,exist_ok=True)
        stage=target.with_suffix('.part')
        try:
            with session.get(row['url'],stream=True,timeout=(5,10),allow_redirects=False) as media:
                media.raise_for_status()
                if media.status_code!=200:continue
                size=0
                with stage.open('wb') as h:
                    for chunk in media.iter_content(65536):
                        if time.monotonic()-started>60:raise TimeoutError('Music transfer deadline')
                        size+=len(chunk)
                        if size>32*1024*1024:raise ValueError('Music asset exceeds 32 MiB')
                        h.write(chunk)
            from ..flow_music import validate_audio
            validate_audio(str(stage));stage.replace(target)
            row.pop('url');row.update(path=str(target.resolve()),query=query,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),retrieved_at=time.time())
            (target.with_suffix('.license.json')).write_text(json.dumps(row,indent=2))
            (Path(workdir)/'music-attribution.txt').write_text(f"Music: {row['creator']}\nSource: {row['page_url']}\nLicense: {row['license_url']}\n{row['attribution']}\n")
            return row
        except Exception:continue
        finally:
            if stage.exists():stage.unlink()
    return {'path':None,'source':'wikimedia-commons','error':'No playable CC0 or CC-BY-4.0 music matched the theme'}

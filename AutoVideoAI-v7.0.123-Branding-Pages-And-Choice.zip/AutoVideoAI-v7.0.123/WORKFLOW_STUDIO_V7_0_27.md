# AutoVideoAI 7.0.27 · Workflow Studio

## Upgrade

Stop active Studio, CLI and runner jobs before upgrading. Extract this build into a new folder. Preview migration, then apply it:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.26 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.26 . --apply
```

Substitute your actual previous folder. Migration preserves jobs, characters and credentials and rebases saved local paths. Restart Studio using your existing Python environment. Never delete an unfinished job's request journals to force generation.

## What changed

- Studio production runs are owned by a process-level task registry. Changing theme or workspace reconnects through Queue to saved progress and a bounded live-log tail. Resume and Render are disabled while that job runs, including jobs started from CLI. Keep the Studio server/WSL running until completion; this does not keep jobs alive after terminating Python.
- Queue overrides stale database “planned” status when the production lock is active. Watching never creates another run.
- Flow's readiness wait compares stable media identity instead of the entire thumbnail fingerprint. Changes in dimensions, labels and signed URLs no longer restart the stability timer when an independent asset ID proves identity.
- A matching video already open in the exact saved project editor downloads through its asset toolbar. Gallery and editor downloads keep a stable project tab alive. Unknown legacy assets still need exact review; no video is regenerated automatically.
- Flow reference reuse tries exact alias search, then unfiltered Uploads rows. Some Flow search cohorts index prompts rather than uploaded filenames. Matching remains exact; unrelated media is never substituted.
- Flow Music uses configured local Chromium, low shared-memory/GPU flags and WSL Wayland with bounded X11 fallback. A closed target allows one browser restart. After music submission, recovery rescans the recorded session instead of generating again. Launch diagnostics are redacted in `logs/flow-music/browser-launch.txt`. Quiet mode remains opt-in and does not silently open a visible fallback.
- Light/Warm multiselects, chips, native details headers and dropdowns use explicit theme surfaces. Headings are larger; Dark remains available.
- History is a compact media gallery with separate Clips, Long-form and Short-form tabs, nine tiles per page. It displays real saved files only.
- Character Library supports name, description, voice and photo changes. Delete hides a card from future pickers while preserving photo files needed by existing approved jobs. Existing card face crop controls remain available.
- Clip Studio accepts up to 50 B-roll suggestions per clip. Actual count is limited by clip duration and safe insert spacing; batch search handles up to 500 candidates across clips. Existing batch approval remains available.
- AI Recreate can reuse a saved review's approved B-roll for this exact clip. Assets are copied into the job and verified by hash; placement follows measured narration duration. This inserts cutaways at render time and does not automatically remove underlying planned Flow shots or reduce their credit budget.
- Image or locally generated text logos have Small, Medium and Large sizes. Text logos offer Ocean, Sunset and Forest palettes. Available in Guided Studio, Clip Studio, local editing and saved-job presentation controls. The private control center supports text logos for clip jobs too.
- Settings accepts masked API key entry. It atomically updates only the chosen key in the local `.env`, preserves other settings, restricts file permissions, and never returns the secret value. Keys stay on your computer; the hosted site has no API-key editor or storage.

## Claude review applicability

The supplied review audited v7.0.16 without live app, screenshots or account tests. Treat its numerical readiness scores as that reviewer's estimates, not measured failure rates.

| Recommendation | Current disposition |
|---|---|
| Durable request journals, no duplicate videos, credit gates | Preserved |
| Unified running-job monitoring and accurate state | Implemented process-owned monitoring and lock-based running detection here |
| Bounded browser recovery and clear launch errors | Improved here; submitted music requests recover by rescan |
| Static-scene QC and partial clip batches | Already supported by recent builds; preserved |
| Safe cleanup with dry run and protected final assets | Already present; preserved |
| Stage input hashes and a complete state-machine migration | Appropriate next foundation change; requires compatibility migration and failure-injection tests |
| Single manifest writer and append-only events | Valid recommendation; not claimed complete in this feature release |
| Split Factory and Flow adapter | Incremental refactor recommended, rather than replacing all working journals at once |
| Face embeddings | Optional future addition requiring suitable model licensing and separate calibration for cartoons; pHash is not face recognition |
| Legacy Chrome bridge authentication | Still needs a separately reviewed compatibility change; do not expose that legacy bridge beyond loopback. The control-center runner already enforces bearer/Origin checks |
| Automatically delete accepted media / expand publication | Not adopted; accepted media, identity references and request journals remain protected |

## Validation and limits

Offline tests cover reconnecting without duplicate starts, theme changes while observing a saved job, stable typed-media detection, music crash recovery after submission, character updates preserving old references, exact approved B-roll reuse, logos and masked key updates. Existing request, QC, cleanup and credit protections remain covered by the regression suite.

Live WSLg/Chromium, Google Flow and Flow Music operation must still be verified on the user's machine. No paid Google request was made for validation. This release cannot promise a fixed provider failure rate or recover an ambiguous legacy asset without reliable identity evidence.

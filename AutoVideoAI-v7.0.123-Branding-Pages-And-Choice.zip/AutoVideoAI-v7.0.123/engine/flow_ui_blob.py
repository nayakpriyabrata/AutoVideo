"""Save an exact UI blob download in the page before the browser's download manager starts it.

v7.0.89: the click hook. Flow starts image downloads by clicking a detached blob anchor
(`a.click()` or a synthetic click event). Those clicks never reach a document-level listener,
so the earlier capture saw no click in any run. Once the browser's download manager starts
a blob download, the browser process can close (v7.0.88 logs showed the crash at the download
event). This module now also hooks `HTMLAnchorElement.click` and `dispatchEvent` while armed:
the first exact blob anchor is read in the page (fetch resolves the blob URL at call time, so a
revoke right after the click does not matter) and the bytes are sent to Python, and no browser
download starts. If the in-page read fails, the original click runs, as before.

Only a blob URL on the existing Flow page is intercepted. No private endpoint,
credential copying, media-gallery guessing, or new generation is involved.
"""
import base64,os,secrets,tempfile,time
from pathlib import Path
SCRIPT=r'''({name,key,limit})=>{
 if(typeof window.__avBlobRemove==='function'){try{window.__avBlobRemove();}catch(e){}}
 const origin=location.origin;
 const originalClick=HTMLAnchorElement.prototype.click;
 const originalDispatch=HTMLAnchorElement.prototype.dispatchEvent;
 const state={active:true,hooked:false};
 window[key]=state;
 const exactBlob=(a)=>{try{return !!a&&typeof a.href==='string'&&a.href.startsWith('blob:'+origin+'/')&&a.hasAttribute('download');}catch(e){return false;}};
 const take=(a)=>{
  if(!state.active)return false;
  state.active=false;
  const href=a.href;
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),30000);
  let started;
  try{started=fetch(href,{signal:controller.signal});}catch(error){started=Promise.reject(error);}
  (async()=>{
   try{
    const response=await started;
    if(!response.ok)throw Error('blob unavailable');
    if(await window[name]({intercepted:true})!==true)throw Error('capture rejected');
    const reader=response.body.getReader();let total=0,index=0;
    while(true){const {done,value}=await reader.read();if(done)break;
     total+=value.length;if(total>limit){await reader.cancel();throw Error('size limit');}
     let binary='';for(let i=0;i<value.length;i+=8192)binary+=String.fromCharCode(...value.subarray(i,i+8192));
     if(await window[name]({index:index++,data:btoa(binary)})!==true)throw Error('capture rejected');
    }
    if(await window[name]({done:true,bytes:total})!==true)throw Error('validation failed');
   }catch(error){
    try{await window[name]({error:'Exact UI blob capture failed'});}catch(e){}
    // Fall back to the original download only while the capture is still open.
    if(window[key]){try{originalClick.call(a);}catch(e){}}
   }finally{clearTimeout(timer);}
  })();
  return true;
 };
 const hookedClick=function click(){if(state.active&&exactBlob(this)){take(this);return undefined;}return originalClick.apply(this,arguments);};
 const hookedDispatch=function dispatchEvent(event){if(state.active&&event&&event.type==='click'&&exactBlob(this)){take(this);return true;}return originalDispatch.apply(this,arguments);};
 const handler=(event)=>{
  const a=event.target&&event.target.closest?event.target.closest('a[download],a[href^="blob:"]'):null;
  if(!state.active||!a||!String(a.href).startsWith('blob:'+origin+'/'))return;
  event.preventDefault();event.stopImmediatePropagation();take(a);
 };
 HTMLAnchorElement.prototype.click=hookedClick;
 HTMLAnchorElement.prototype.dispatchEvent=hookedDispatch;
 document.addEventListener('click',handler,true);
 const restore=()=>{
  if(HTMLAnchorElement.prototype.click===hookedClick)delete HTMLAnchorElement.prototype.click;
  if(HTMLAnchorElement.prototype.dispatchEvent===hookedDispatch)delete HTMLAnchorElement.prototype.dispatchEvent;
 };
 state.remove=()=>{state.active=false;document.removeEventListener('click',handler,true);restore();if(window.__avBlobRemove===state.remove)delete window.__avBlobRemove;delete window[key];};
 window.__avBlobRemove=state.remove;
 state.hooked=true;
 return true;
}'''
class Capture:
    def __init__(self,page,output,validator):
        self.page=page;self.output=str(output);self.validator=validator;self.done=False;self.error='';self.size=0;self.index=0;self.active=True;self.started=time.monotonic()
        self.limit=128*1024*1024;self.key='avblob_'+secrets.token_hex(8);self.name=self.key+'_write'
        self.messages=0;self.foreign=0;self.reported=False;self.intercepted=False;self.hooked=False
        parent=Path(output).resolve().parent;parent.mkdir(parents=True,exist_ok=True)
        fd,self.stage=tempfile.mkstemp(dir=parent,prefix='.flow-ui-',suffix=Path(output).suffix);self.handle=os.fdopen(fd,'wb')
    def receive(self,source,message):
        if not self.active:return False
        self.messages+=1
        if source.get('page')!=self.page:
            self.foreign+=1;self.error=self.error or 'source_page_mismatch';return False
        try:
            if time.monotonic()-self.started>120:raise ValueError('Capture deadline')
            if message.get('error'):raise ValueError(message['error'])
            if message.get('intercepted'):
                # v7.0.89: the page's click hook took the exact blob; no browser download will start.
                self.intercepted=True;return True
            if message.get('done'):
                if message.get('bytes')!=self.size or self.size==0:raise ValueError('Incomplete blob')
                self.handle.flush();self.handle.close()
                if not self.validator(self.stage):raise ValueError('Invalid media bytes')
                os.replace(self.stage,self.output);self.done=True;self.active=False;return True
            if message.get('index')!=self.index:raise ValueError('Out-of-order chunk')
            chunk=base64.b64decode(message['data'],validate=True)
            if len(chunk)>4*1024*1024 or self.size+len(chunk)>self.limit:raise ValueError('Capture limit')
            self.handle.write(chunk);self.size+=len(chunk);self.index+=1;return True
        except Exception as error:
            self.error=type(error).__name__;self.active=False;return False
    def install(self):
        if not str(self.page.url).startswith(('https://flow.google.com/','https://labs.google/')):raise ValueError('Flow page required')
        self.page.expose_binding(self.name,self.receive)
        self.hooked=bool(self.page.evaluate(SCRIPT,{'name':self.name,'key':self.key,'limit':self.limit}))
        return self
    def close(self):
        self.active=False
        self._report()
        try:self.page.evaluate('(key)=>window[key]?.remove()',self.key)
        except Exception:pass
        if not self.handle.closed:self.handle.close()
        if os.path.exists(self.stage):os.unlink(self.stage)
    def _report(self):
        # v7.0.88: one summary per capture. messages=0 means the page's click hook never ran.
        if self.reported:return
        self.reported=True
        from .flow_download_diagnostics import diag
        state='done' if self.done else 'not-done'
        diag('exact UI blob capture '+state+': hook='+('on' if self.hooked else 'off')+' intercepted='+('yes' if self.intercepted else 'no')
             +' messages='+str(self.messages)+' foreign='+str(self.foreign)
             +' chunks='+str(self.index)+' bytes='+str(self.size)+' error='+(self.error or 'none'))
def arm(page,output,validator):
    from .flow_download_diagnostics import describe_exception,diag
    capture=Capture(page,output,validator)
    try:
        armed=capture.install()
        diag('exact UI blob capture armed: click hook '+('on' if armed.hooked else 'off'))
        return armed
    except Exception as error:
        diag('exact UI blob capture not armed: '+describe_exception(error))
        capture.close();return None

"""Explicit completed-job deletion with preview, lock, database backup and confirmation.

Only completed jobs whose Flow journals are resolved and whose final video exists
are eligible. Never follows job-directory symlinks or touches shared browser logins.
"""
from pathlib import Path
import json
import shutil
import sqlite3
import time
import uuid
import os
from .job_cleanup import _completed_without_pending, _size
from .production_lock import acquire, release


def completed_job_delete(outputs, db_path, job_id, *, apply=False, confirmation=''):
    outputs=Path(outputs).absolute()
    db_path=Path(db_path).absolute()
    if not job_id or job_id in ('.','..') or Path(job_id).name!=job_id or '/' in job_id or '\\' in job_id:
        raise ValueError('Invalid job ID')
    if outputs.is_symlink():
        # Shared workspace output root is intentionally a link; its target must be trusted.
        outputs=outputs.resolve(strict=True)
    if not outputs.is_dir():raise ValueError('Outputs directory missing')
    job=outputs/job_id
    if job.is_symlink() or not job.is_dir():raise ValueError('Job directory missing or linked')
    eligible,reason=_completed_without_pending(job)
    result={'job_id':job_id,'eligible':eligible,'reason':reason or 'Completed job with resolved Flow requests',
            'bytes':_size(job),'apply':apply,'includes':'job folder and SQLite index only; external browser profiles excluded'}
    if not apply:return result
    if confirmation!=job_id:raise ValueError('Type the exact job ID to confirm permanent deletion')
    if not eligible:raise ValueError('Deletion refused: '+reason)
    service=Path.home()/'.local/share/autovideoai'
    service.mkdir(parents=True,exist_ok=True)
    with (service/'production.lock').open('a+b') as lock:
        try:acquire(lock,blocking=False)
        except BlockingIOError:raise RuntimeError('Production running: stop it before deleting a job')
        try:
            from .job_monitor import _tasks, _guard
            with _guard:
                if any(t['thread'].is_alive() for t in _tasks.values()):
                    raise RuntimeError('A Studio job is running or queued')
            eligible,reason=_completed_without_pending(job)
            if not eligible:raise ValueError('Job changed: '+reason)
            if not db_path.is_file():raise ValueError('Job DB missing; deletion refused')
            with sqlite3.connect(db_path) as cx:
                backup=db_path.with_name('jobs-before-delete-'+str(time.time_ns())+'.db')
                with sqlite3.connect(backup) as dst:cx.backup(dst)
            trash=outputs/'.deletion-quarantine'
            trash.mkdir(exist_ok=True)
            target=trash/(job_id+'-'+uuid.uuid4().hex)
            os.rename(job,target)
            try:
                with sqlite3.connect(db_path) as cx:
                    cx.execute('DELETE FROM jobs WHERE job_id=?',(job_id,))
            except BaseException:
                os.rename(target,job)
                raise
            # If physical deletion fails, quarantined files remain for manual review.
            try:
                shutil.rmtree(target)
                result['deleted']=True
            except OSError as error:
                result['deleted']=False
                result['quarantine']=str(target)
                result['warning']='Index removed, but files remain quarantined: '+str(error)
            result['backup_db']=str(backup)
            return result
        finally:release(lock)

# 7.0.54 — recovery and production workflow update

## Install into the existing workspace

Stop Studio, runner and CLI production. Extract beside your existing AutoVideoAI-v7 folder. From the existing folder:

```bash
python3 ../AutoVideoAI-v7.0.54/tools/update_v753_to_v754.py .
python3 ../AutoVideoAI-v7.0.54/tools/update_v753_to_v754.py . --apply
./dashboard.sh
```

Supports base v7.0.53 and recovery hotfixes r1–r3 / approval a1. Backs up changed code and retains outputs, cast, audio, profiles and settings. Code updates do not repair an old job's conflicting creative brief or authorize a second generation. Keep recovered accepted shots.

## Optional external AI clips

For a NEW full video job, tick sidebar **New jobs: generate video shots externally** before Create. The job prepares the shot plan and waits for reviewed external clips before video generation. This is separate from Mini Reels. Still-reference preparation and narration remain part of the normal workflow.

For an EXISTING planned job, open Queue → **External AI video clips · prompts and uploads · optional**. Choose shots and export the plan. Download prompts, generate on Flow or any chosen platform, then upload each MP4 by shot ID. Review playback and rights, then import and run QC. Selected external clips can also replace a pending Flow request, but only with the additional explicit checkbox. Accepted takes are never silently replaced. Uploaded clip audio follows the existing narration/music timeline policy; this feature does not automatically treat generated dialogue as narration.

CLI examples, from the existing installation:

```bash
python3 tools/external_video.py enable JOB_ID --shots shot_001 shot_005
```

Prompts: `outputs/JOB_ID/external_video/prompts.md`. Machine-readable timing and reference hashes: `external_video/plan.json`. Put completed files at the plan's required incoming paths, then explicitly import:

```bash
python3 tools/external_video.py import JOB_ID --shot-id shot_001 --reviewed --platform Flow
```

Or pass `--file /absolute/path/clip.mp4`. Add `--replace-pending` only when deliberately replacing the selected shot's unresolved Flow request. After accepted imports, Resume the same job. `disable JOB_ID` returns to automatic production; pending requests still block new generation.

## Music

Reliable automatic music now tries local → Commons direct HTTP → Pixabay browser → original offline instrumental. Commons selects only CC0 or CC-BY-4.0 metadata and playable audio with a bounded download. The query includes the video topic unless a custom music mood is supplied. Receipts and attribution text are saved under the job audio directory. Include the attribution when using a CC-BY track. This is a new source option within automatic mode, not a separate commercial music subscription and not a promise of no claims.

## Progress

Production B-roll emits slot/total, current query, elapsed operation heartbeat, retrieved count, validation phase and final result. Clip Studio searches show per-slot progress between source calls; the main job worker retains durable progress logs. A blocked provider can still consume its configured timeout. No speculative ETA is shown.

## Downloads

A new guarded path captures an exact same-origin blob anchor before its native download click can close the page. It writes bounded chunks to a temporary file, validates the media, then atomically publishes. Other Flow download modes retain native/event-URL recovery and reviewed local import. Blob capture is limited to 128 MiB; no private Flow API is used. A revoked blob, changed UI or entire browser crash can still require user-assisted recovery.

See PRODUCTION_REVIEW_V7_0_54.md for priorities, remaining limitations and suggested release gates. Live Flow capture and live catalog matching were not verified in this environment.

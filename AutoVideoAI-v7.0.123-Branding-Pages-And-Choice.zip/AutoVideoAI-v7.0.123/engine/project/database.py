"""SQLite job database (stdlib sqlite3 - no ORM needed)."""
from __future__ import annotations
import os
import sqlite3
import datetime

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs(
  job_id TEXT PRIMARY KEY,
  topic TEXT, status TEXT, video_type TEXT, target_seconds INTEGER,
  aspect TEXT, profile TEXT, preset TEXT,
  script_status TEXT DEFAULT 'pending',
  flow_project TEXT DEFAULT '',
  est_credits INTEGER DEFAULT 0,
  actual_generations INTEGER DEFAULT 0,
  accepted_shots INTEGER DEFAULT 0,
  rejected_shots INTEGER DEFAULT 0,
  retry_count INTEGER DEFAULT 0,
  render_status TEXT DEFAULT 'pending',
  final_path TEXT DEFAULT '',
  dry_run INTEGER DEFAULT 0,
  updated_at TEXT
);
"""


class JobDB:
    def __init__(self, path: str = "data/jobs.db"):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.path = path
        with self._cx() as cx:
            cx.executescript(SCHEMA)

    def _cx(self):
        cx = sqlite3.connect(self.path)
        cx.row_factory = sqlite3.Row
        return cx

    def upsert(self, job_id: str, **fields):
        fields["updated_at"] = datetime.datetime.now().isoformat(timespec="seconds")
        cols = ["job_id", *fields.keys()]
        vals = [job_id, *fields.values()]
        sets = ", ".join(f"{c}=excluded.{c}" for c in fields)
        with self._cx() as cx:
            cx.execute(f"INSERT INTO jobs({','.join(cols)}) VALUES({','.join('?'*len(cols))}) "
                       f"ON CONFLICT(job_id) DO UPDATE SET {sets}", vals)

    def get(self, job_id: str) -> dict | None:
        with self._cx() as cx:
            r = cx.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        return dict(r) if r else None

    def list(self, limit: int = 50) -> list[dict]:
        with self._cx() as cx:
            rows = cx.execute("SELECT * FROM jobs ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def bump(self, job_id: str, field: str, by: int = 1):
        with self._cx() as cx:
            cx.execute(f"UPDATE jobs SET {field}={field}+?, updated_at=? WHERE job_id=?",
                       (by, datetime.datetime.now().isoformat(timespec="seconds"), job_id))

    def missing_jobs(self, outputs):
        from pathlib import Path
        root = Path(outputs).resolve()
        if not root.is_dir():
            return []  # Disconnected/missing output drive is never a prune signal.
        result = []
        for row in self.list(100000):
            identifier = row['job_id']
            if Path(identifier).name != identifier or identifier in ('.', '..'):
                continue
            try:
                (root/identifier).lstat()
            except FileNotFoundError:
                result.append(row)
            except OSError:
                pass
        return result

    def prune_missing(self, outputs, identifiers):
        """Back up the index, then recheck absent folders under the production lock."""
        from pathlib import Path
        import time
        from engine.production_lock import acquire, release
        from engine.job_monitor import _tasks, _guard
        service = Path.home()/'.local/share/autovideoai'
        service.mkdir(parents=True, exist_ok=True)
        removed = []
        with (service/'production.lock').open('a+b') as lock:
            try:
                acquire(lock, blocking=False)
            except BlockingIOError:
                raise ValueError('Production is active; wait before removing missing entries')
            try:
                with _guard:
                    if any(t['thread'].is_alive() for t in _tasks.values()):
                        raise ValueError('A Studio job is running or queued; wait before removing entries')
                    eligible = {r['job_id'] for r in self.missing_jobs(outputs)} & set(identifiers)
                    backup = Path(self.path).with_name('jobs-before-prune-'+str(time.time_ns())+'.db')
                    with self._cx() as cx:
                        if eligible:
                            with sqlite3.connect(backup) as target:
                                cx.backup(target)
                        for identifier in sorted(eligible):
                            # Folder creation since preview preserves the entry.
                            try:
                                (Path(outputs).resolve()/identifier).lstat()
                            except FileNotFoundError:
                                pass
                            except OSError:
                                continue
                            else:
                                continue
                            cx.execute('DELETE FROM jobs WHERE job_id=?', (identifier,))
                            removed.append(identifier)
                    return {'removed': removed, 'backup': str(backup) if eligible else None}
            finally:
                release(lock)

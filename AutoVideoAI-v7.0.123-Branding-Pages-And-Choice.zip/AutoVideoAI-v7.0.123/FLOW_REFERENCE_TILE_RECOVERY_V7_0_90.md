# Flow image recovery: uploaded references shown as tiles (v7.0.90)

## What the job showed (shot_020, 2026-10-25)
- The request was journaled as `submission_uncertain`, with no acknowledgement.
- After the persisted project reopened, the probes downloaded for the two new tiles were the
  two uploaded references: `location_master.jpg` and `character-aradhya-aaa37613-0.png`
  (the journal records both as references, checked by checksum and visual match).
- No generated image appeared in the project in any attempt. This is consistent with the
  recorded data, but it does not prove whether Flow generated one.
- The generation wait counted the two references as fresh output. After 30 s it returned
  `Multiple distinct images require exact request correlation`, so the exact classifier never
  decided anything. Three recovery attempts ran the same way, and the job was left paused.

## Cause
Uploaded references are listed in the project grid under URLs that differ from the pre-submit
baseline. The baseline therefore does not exclude them, and the wait sees them as new output.
The journal already classifies them, but the wait did not use that.

## What changed
- `engine/flow_image_transaction.py`: the references the journal has already classified (by
  checksum or visual match, in this project) are added to the wait's baseline. Only those are
  excluded; tile order is never used.
- `engine/providers/flow_browser.py`: `wait_for_agent_generation(..., transactional_images=True)`
  returns after the stability window instead of failing, so the exact classifier decides. Other
  callers keep the old failure.
- `engine/isolated_frame_regeneration.py`: the same exclusion and hand-off for regenerated frames.

## What it does not do
- It never submits a prompt, clicks Generate, or spends credits. Recovery stays download-only.
- It does not pick between two real, non-reference outputs. That still stops with
  `No unique non-reference image yet`, and no file is written.
- It does not create an image when Flow produced none. If the project shows no generated image,
  recovery can wait and then stop. A new submission would spend credits, so that is a user decision.

## Verification
- `tests/test_v790_reference_tile_recovery.py`: references excluded only when classified in this
  project; recovery classifies the references, waits with them excluded, then commits the one
  real output; two real outputs stay blocked with no file written; a wait that sees only
  references does not commit; the waiter hands over only when transactional.
- Mutation check: removing the exclusion and the hand-off makes 3 of these tests fail.
- The v743 image-transaction, v787 download and v788/v789 tests still pass.

## What to do with the paused job (shot_020)
1. Open the saved Flow project and look for a new generated image (not the two references).
   Do not click Generate.
2. Install 7.0.90 and resume. Recovery is download-only and will report either the one
   unique image, or the reason it could not decide.
3. If Flow shows no generated image for shot_020, send the project screenshot before any
   resubmission.

## Update
From 7.0.89: `python3 ../AutoVideoAI-v7.0.90/tools/update_v789_to_v790.py . --apply`
From 7.0.88: first `python3 ../AutoVideoAI-v7.0.89/tools/update_v788_to_v789.py . --apply`.
Stop the dashboard first. Runtime data, jobs, profiles and outputs are never touched.

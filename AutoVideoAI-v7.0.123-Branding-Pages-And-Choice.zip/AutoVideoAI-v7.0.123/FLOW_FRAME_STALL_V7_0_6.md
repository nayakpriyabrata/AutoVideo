# v7.0.6 — Flow frame progress and exact image download recovery

## What was found

The supplied run downloaded shot_006 opening and shot_005 closing frames, then last reported that another exact image was matched. This proves partial progress, but does not prove which browser operation stopped on the user's PC. No live WSL session was accessed.

Two code defects made this difficult to diagnose:

- Parallel workers returned a whole batch before reporting individual outcomes. One slow frame hid completed frames in the same batch.
- Playwright `Download.save_as()` and `Download.path()` wait for browser download completion and offer no timeout argument. An image transfer could therefore hold a worker indefinitely. The canonical tile menu also created an unnecessary extra project tab before saving.

The screenshot reveals a separate content defect: the location keyword `ai` matched the middle of `Maiya`, selecting a tech studio. The generic kids-story character also replaced the named Kanha.

## Changes

- Resume reuses valid saved worker artifacts before attempting browser startup, even if the browser cannot launch.
- Completed frames report immediately, on the coordinator thread; worker threads never call Streamlit or the job database.
- During longer requests the Studio emits a worker heartbeat every 15 seconds, showing the assigned shot, frame, phase and elapsed wait. Ready and failed counters are separate.
- A read-only diagnostic snapshot is saved under `.flow-workers/economy_frame_progress.json` inside the job folder.
- Exact image download events use bounded HTTPS transfer instead of unbounded browser `save_as`/`path`: a 120-second wait deadline, connection timeout up to 10 seconds, read timeout up to 15 seconds, maximum 32 MB, and at most three Google-hosted redirects. A stalled HTTP reader may finish in the background, but can never write job files: only the coordinator can commit validated bytes received before its deadline. Image bytes, full decode and content length are validated before atomic replacement.
- A failed, expired or unsupported image event URL leaves the saved request available for download-only recovery. No different tile is chosen and no replacement Flow prompt is submitted. URLs requiring browser credentials or blob URLs need operator assistance; this patch does not copy credentials.
- The direct tile-menu path no longer opens a guard project tab. The exact viewer fallback retains its guard, and menu/viewer locator actions have explicit short timeouts.
- AI/tech location keywords now match whole words. New kids-story plans explicitly naming Kanha/Krishna retain child Krishna, Yasoda when named, and a traditional Vrindavan setting. Modern productivity B-roll substitutions are disabled for that story world.

## Recover the existing job

1. Stop the current production once using Ctrl+C in the WSL terminal that owns Studio/CLI. Do not start a second producer while it is still running.
2. Back up the installation and job before upgrading. Keep the original installation path and all `outputs`, `data`, local configuration, `.env`, browser profiles and `.flow-workers` request journals. Do not delete journals or change worker count while recovering the exact old worker bindings.
3. Install v7.0.6 application source into the stopped installation, preserving local configuration. Use the same WSL Python environment; install its requirements if needed. `cat VERSION` should show `7.0.6`. Restart Studio afterward.
4. If you accept the saved storyboard, resume this same job from Queue or run:

   python3 cli.py v3 resume 20261005-200354-little-kanha-helping-yas-8092

   Valid saved worker artifacts are copied/reused. Pending worker requests retain their original saved projects and artifact paths. Resume will attempt their exact downloads; paid video journals remain guarded against duplicate submission.
5. To inspect progress from a second WSL terminal:

   cat outputs/20261005-200354-little-kanha-helping-yas-8092/.flow-workers/economy_frame_progress.json

   Heartbeats show an active wait rather than a completed frame. They do not override capacity limits or declare a missing download successful.

**Content warning for this particular job:** Resume preserves its existing story bible and downloaded visuals, including the generic modern child/tech-room imagery shown in the screenshot. This patch deliberately does not rewrite an in-flight manifest or silently spend credits to replace those assets. For a correct Kanha/Yasoda story, create a separate plan-only job after upgrade and review its script, story bible and storyboard before generation. The new topic rules apply to newly created plans.

## Validation and limits

Regression tests cover reporting the first frame before its worker batch ends, reporting a heartbeat before any frame ends, coordinator-thread reporting, bounded image transfers, invalid/truncated bytes, redirect restrictions, preservation of an existing file, and the Maiya/Kanha story identity. Existing continuity, exact request recovery and download-integrity tests remain part of the suite.

Live Google Flow and the user's WSL session were not exercised. A frozen browser transport, browser shutdown, provider capacity waits and paid video saves are separate from the bounded image-transfer fix. A heartbeat is diagnostic; it does not forcibly kill a worker or guarantee an external service will finish.

All v7.0.5 narration, music, B-roll and Mini Reel changes remain included; see WORKFLOW_RESILIENCE_V7_0_5.md.

Release validation: **685 engine tests passed**, including the slow-reader/no-late-write and cached-frame/no-browser cases; **27 control-center checks passed**. Twelve pre-existing dependency deprecation warnings remain.

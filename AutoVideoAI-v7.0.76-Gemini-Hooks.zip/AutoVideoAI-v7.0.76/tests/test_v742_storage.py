from pathlib import Path
import tempfile
import unittest
from tools.shared_workspace import plan
from engine.job_delete import completed_job_delete

class StorageTests(unittest.TestCase):
    def test_share_preserves_data_and_links(self):
        with tempfile.TemporaryDirectory() as base:
            b=Path(base); build=b/'build';build.mkdir();(build/'VERSION').write_text('7.0.41')
            (build/'outputs').mkdir();(build/'outputs'/'keep.txt').write_text('saved')
            report=plan(build,b/'shared')
            self.assertFalse((build/'outputs').is_symlink())
            self.assertIn('move_then_link',str(report))
            plan(build,b/'shared',True)
            self.assertTrue((build/'outputs').is_symlink())
            self.assertEqual((build/'outputs'/'keep.txt').read_text(),'saved')
            (b/'next').mkdir();(b/'next'/'VERSION').write_text('7.0.42')
            plan(b/'next',b/'shared',True)
            self.assertEqual((b/'next'/'outputs'/'keep.txt').read_text(),'saved')

    def test_refuse_conflicting_data(self):
        with tempfile.TemporaryDirectory() as base:
            b=Path(base);build=b/'build';(build/'outputs').mkdir(parents=True)
            (build/'VERSION').write_text('7.0.41');(build/'outputs'/'a').write_text('a')
            (b/'shared'/'outputs').mkdir(parents=True)
            with self.assertRaises(ValueError):plan(build,b/'shared',True)
            self.assertEqual((build/'outputs'/'a').read_text(),'a')

    def test_delete_refuses_incomplete_job(self):
        with tempfile.TemporaryDirectory() as base:
            b=Path(base);job=b/'outputs'/'job-001';job.mkdir(parents=True)
            (job/'production_manifest.json').write_text('{"status":"paused"}')
            preview=completed_job_delete(b/'outputs',b/'data'/'jobs.db','job-001')
            self.assertFalse(preview['eligible'])
            with self.assertRaises(ValueError):
                completed_job_delete(b/'outputs',b/'data'/'jobs.db','job-001',apply=True,confirmation='job-001')
            self.assertTrue(job.exists())

if __name__=='__main__':unittest.main()

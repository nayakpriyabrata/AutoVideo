# AutoVideo 7.0.91: Flow reference identity by tile label, and a guarded shot resubmission

## Why 7.0.90 did not fix shot_020

Flow gave the two uploaded references (`location_master.jpg`, `character-aradhya-aaa37613-0`) new
`/asb/` URLs on each project load. The 7.0.90 exclusion relied on the saved URL signature, so the
references were not excluded. Each run downloaded them again, and the generation wait counted them as
new output. Recovery then reported "No unique non-reference image yet" and stopped. The 7.0.90 early
hand-off did not trigger, and the wait ran silently for the full 360 s.

## What 7.0.91 changes

1. **Stable reference identity.** Flow's tile label, `AV_<hash12>_<filename>`, is read from each probed
   tile. When a probe is classified as an uploaded reference, its label is recorded in the journal.
   Labels survive project reloads even when the URL changes.
2. **Excluded from the wait.** Tiles with a recorded reference label are removed before the generation
   wait counts candidates. Two real outputs are still blocked and reported.
3. **No repeated downloads.** A reloaded reference that matches a recorded label reuses its saved bytes.
   It is not downloaded again, and no duplicate probe files are created.
4. **The wait says what it is doing.** A transactional wait prints its timeout and how many reference labels
   it excluded at the start, so a long wait is no longer silent.
5. **New tool: `tools/archive_uncertain_flow_image.py`.** It moves one unresolved shot journal aside so the
   next Resume makes one new submission. It is never deleted, and it refuses when:
   - the shot already has a downloaded image;
   - the journal phase is not `submission_uncertain` or `submitted`;
   - any saved probe is a valid image that is not a classified uploaded reference (recover it instead);
   - the job is running (production lock held).
   Without `--confirm-new-credit-spend` it only prints a dry run and changes nothing.

## Steps for shot_020 (only after the user approves the credit spend)

```
python3 tools/archive_uncertain_flow_image.py outputs/20261022-143856-7-small-daily-habits-tha-9729/storyboard/shot_020_open.jpg
python3 tools/archive_uncertain_flow_image.py outputs/20261022-143856-7-small-daily-habits-tha-9729/storyboard/shot_020_open.jpg --confirm-new-credit-spend
```

Then press Resume once. The old request is kept as `shot_020_open.jpg.flow-request.archived-<UTC>.json`
beside the output. Do not press Resume again without a new approval.

## Other notes

- Default TTS split size remains 2400 characters.
- `tools/update_v789_to_v790.py` is superseded and removed from `tools/`. The 7.0.90 zip still holds it.
- Install with the updater from the 7.0.90 folder:
  `python3 ../AutoVideoAI-v7.0.91/tools/update_v790_to_v791.py .` (dry run), then add `--apply`.

## Verification status

- Fixture tests only: `tests/test_v791_reference_labels.py` (13 tests) covers label parsing and exclusion,
  reloaded references with new URLs (no re-download, no duplicate probes), labelled exclusion in the wait,
  and the archive guards.
- Full offline suite: 53 failed, 11 errors, 1397 passed, 44 skipped. The failures and errors are the same
  environmental and pre-existing group as 7.0.90 (ffmpeg/ffprobe, typography, Streamlit). The suite is not green.
- Updater round trip: 7.0.90 install to 7.0.91 with dry run, apply and an idempotent re-run; a 7.0.89 install is refused with the chain message.
- Not verified against live Flow. The shot_020 outcome is unknown until the user runs the new submission.

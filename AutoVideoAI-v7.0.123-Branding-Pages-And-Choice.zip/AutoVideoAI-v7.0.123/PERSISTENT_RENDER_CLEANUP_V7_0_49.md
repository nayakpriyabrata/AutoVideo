# AutoVideoAI v7.0.49

## Clip rendering

- Clip Studio B-roll rendering now runs as a persistent Studio job instead of a single Streamlit request.
- Queue & Resume shows the exact stage, percent, completed clips and clips remaining.
- Closing or changing the browser tab does not cancel rendering while Studio is running.
- If Studio itself stops, reopen the saved clip job and choose **Resume unfinished clip render**.
- Every completed clip is checkpointed. Resume validates and reuses that exact output; changed decisions or assets force a fresh render.

## Reviewed cleanup

- History → Gallery & Downloads → Manage saved jobs & clips can select all failed, paused or completed work.
- The deletion review lists every owned local path and estimated storage before deletion.
- Local deletion includes the job/clip folder, recovery journals, cached source material owned by that clip folder, worker clones, associated logs and database entry.
- Shared libraries, login profiles, external sources and data referenced by unselected work are protected.
- Recorded Google Flow projects are listed separately. Remote deletion is opt-in and runs before local deletion.
- A remote project shared by unselected work is never deleted. Flow must expose an explicitly labelled project-action control and route away after confirmation; otherwise cleanup stops and retains local recovery data.

## Update an existing installation

Stop Studio and all jobs, extract this release beside the existing folder, then run from the extracted v7.0.49 folder:

```bash
python3 tools/update_v743_to_v749.py ../AutoVideoAI-v7.0.48 --apply
```

The updater accepts v7.0.43 through v7.0.48, backs up replaced code, and does not copy runtime data, `.env`, browser profiles, outputs or saved jobs.

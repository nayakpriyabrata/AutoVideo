"""Archive one unresolved Flow image journal so that ONE explicit Resume makes ONE new submission.

Used by `cli.py v3 archive-request` and by tools/archive_uncertain_flow_image.py. The journal is renamed,
never deleted, so the old Flow request stays on record. Spending credits still requires the explicit
--confirm-new-credit-spend flag, and nothing is submitted by this module.
"""
from __future__ import annotations

import fcntl
import json
import time
from pathlib import Path

from .flow_image_transaction import completed, journal_path
from .isolated_frame_regeneration import image_valid

ALLOWED_PHASES = {'submission_uncertain', 'submitted'}


def archive_uncertain_request(output, confirm_new_credit_spend=False):
    """Return (exit_code, lines). 0 = done or dry run, 2 = refused, nothing changed."""
    output = Path(output).resolve()
    path = journal_path(output)
    if not path.is_file():
        return 0, [f'No open Flow image journal at {path.name}; nothing to archive.']
    try:
        request = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError) as error:
        return 2, [f'REFUSED: the journal cannot be read ({type(error).__name__}). Nothing was changed.']
    phase = str(request.get('phase') or '')
    if phase not in ALLOWED_PHASES:
        return 2, [f'REFUSED: journal phase is {phase!r}; only {sorted(ALLOWED_PHASES)} can be archived.']
    if request.get('status') == 'downloaded' or completed(output, request) or image_valid(output):
        return 2, ['REFUSED: this shot already has a downloaded image; there is nothing to resubmit.']
    for entry in (request.get('capture_probes') or {}).values():
        if entry.get('reference'):  # a known uploaded reference (label or path)
            continue
        if entry.get('file') and image_valid(output.parent / str(entry['file'])):
            return 2, [f'REFUSED: {entry["file"]} is a valid image that is not a classified uploaded reference. '
                       'Recover it instead of resubmitting.']

    lock_path = output.parent / '.production.lock'
    with lock_path.open('a+b') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return 2, ['REFUSED: the job is running (production lock held). Stop it, then retry.']
        stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
        archived = output.with_name(output.name + '.flow-request.archived-' + stamp + '.json')
        lines = [f'Journal:  {path.name}',
                 f'Phase:    {phase}  acknowledged={request.get("submission_acknowledged")}',
                 f'Project:  {request.get("project_url")}',
                 f'Archive:  {archived.name}']
        if not confirm_new_credit_spend:
            return 0, lines + ['Dry run. Add --confirm-new-credit-spend to archive. Nothing was changed.']
        path.rename(archived)
        return 0, lines + ['Archived. Press Resume once: that makes ONE new submission in a new Flow project.',
                           'Do not press Resume again unless the user approves another credit spend.']

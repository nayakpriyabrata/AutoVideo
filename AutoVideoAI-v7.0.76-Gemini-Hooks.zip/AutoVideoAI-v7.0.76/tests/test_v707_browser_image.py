import asyncio
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from PIL import Image
from playwright.sync_api import sync_playwright, Download
from engine.providers.flow_browser import FlowBrowser


@pytest.mark.parametrize('url', ['blob:https://flow.google.com/exact-artifact', 'https://flow.google.com/authenticated-download'])
def test_exact_native_artifact_uses_real_playwright_sync_bridge(tmp_path, monkeypatch, url):
    import engine.providers.flow_browser as module
    b=FlowBrowser.__new__(FlowBrowser)
    b._save_image_download_url=lambda *args:pytest.fail('Native artifact must not use a separate HTTP request')
    with sync_playwright() as p:
        class Impl:
            _loop=p._impl_obj._loop
            _dispatcher_fiber=p._impl_obj._dispatcher_fiber
            async def save_as(self,path):
                await asyncio.sleep(.01)
                Image.new('RGB',(200,200),'green').save(path,format='PNG')
            async def cancel(self):pytest.fail('Completed download must not be cancelled')
        out=str(tmp_path/'image.jpg')
        impl=Impl();impl.url=url
        assert b._save_download_event(Download(impl),out)==out
        with Image.open(out) as image:assert image.size==(200,200)
    assert list(tmp_path.iterdir())==[Path(out)]


@pytest.mark.parametrize('mode',['stalled','invalid','closed'])
def test_native_failure_is_bounded_and_preserves_existing_asset(tmp_path, monkeypatch, mode):
    import engine.providers.flow_browser as module
    monkeypatch.setattr(module,'_FLOW_IMAGE_DOWNLOAD_TIMEOUT_S',.03)
    b=FlowBrowser.__new__(FlowBrowser);cancelled=[]
    out=tmp_path/'image.jpg';out.write_bytes(b'preserved')
    with sync_playwright() as p:
        class Impl:
            _loop=p._impl_obj._loop
            _dispatcher_fiber=p._impl_obj._dispatcher_fiber
            async def save_as(self,path):
                if mode=='stalled':await asyncio.sleep(100)
                if mode=='closed':raise RuntimeError('Target closed')
                Path(path).write_bytes(b'invalid image')
            async def cancel(self):cancelled.append(True)
        assert b._save_browser_image_artifact(Download(Impl()),str(out)) is None
        assert cancelled==([True] if mode=='stalled' else [])
    assert out.read_bytes()==b'preserved' and list(tmp_path.iterdir())==[out]


def test_recovery_panel_state_is_read_only_and_uses_current_saved_policy(tmp_path):
    from engine.factory import Factory
    from engine.project.manifest import Shot
    import json
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'jobs.db'))
    job=f.create_job('recovery',flow_pause_on_unresolved_request=False)
    m=f.pm.load_manifest(job);m.shots=[Shot(shot_id='shot_001')];m.status='failed';f.pm.save_manifest(m)
    folder=Path(f.pm.job_dir(job));pause=folder/'pause_state.json'
    state=f.recovery_state(job)
    assert not pause.exists() and state['status']=='failed' and not state['pause_on_unresolved']
    pause.write_text(json.dumps({'kind':'legacy_pause_recovery','reason':'This job is paused'}))
    before=pause.read_bytes()
    assert 'paused' not in f.recovery_state(job)['reason'] and pause.read_bytes()==before
    f.set_flow_pause_on_unresolved_request(job,True)
    assert f.recovery_state(job)['pause_on_unresolved'] and pause.read_bytes()==before

"""Recommended royalty-free music, by video type, with the licence each track carries (v7.0.107).

The user asked for "excellent, widely used, pleasant, royalty-free and without copyright on YouTube"
background music, per video type, to download locally into ``music_library/``. Guessing a track name is
useless, so this is a small, checked catalogue:

* every entry names its platform, the exact licence, and whether a credit line is required;
* ``credit`` holds the line to paste into the YouTube description when attribution is required;
* ``themes`` uses the tags ``engine/audio/music_library.py`` understands, so an imported track is picked for
  the right videos automatically;
* ``search`` is what to type on the platform, so the list still works if a direct link changes.

Nothing here downloads or re-hosts music. Licences change; the doc that ships with the app
(``docs/MUSIC_LIBRARY.md``) says to re-check the licence page before publishing.
"""
from __future__ import annotations

SCHEMA = "music-catalogue-v1"

# Video types the app actually produces (``content_type`` / preset families).
VIDEO_TYPES = {
    "education": "Explainer, how-to and educational videos",
    "motivation": "Motivational and self-improvement videos",
    "documentary": "Documentary, story and cinematic narration",
    "technology": "Technology, AI and science videos",
    "kids": "Kids and cartoon stories",
    "travel": "Travel and lifestyle",
    "business": "Business, finance and career",
}


def _track(**row):
    return row


CATALOGUE = [
    _track(
        id="monplaisir-free-to-use-1", title="Free To Use 1", artist="Monplaisir",
        platform="Free Music Archive", licence="CC0 1.0 (public domain)", attribution="none",
        credit="", url="https://freemusicarchive.org/music/Monplaisir/",
        search="Monplaisir Free To Use 1", themes=["calm", "motivation"], tempo="slow",
        video_types=["education", "motivation", "business"],
        notes="Already the local default in this installation (music_library/). Calm, unobtrusive bed "
              "that survives ducking under speech. Best first choice for talking-head narration.",
    ),
    _track(
        id="buckley-amberlight", title="Amberlight", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Amberlight' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/amberlight/",
        search="Scott Buckley Amberlight", themes=["calm", "motivation"], tempo="slow",
        video_types=["education", "motivation", "documentary"],
        notes="Warm piano and strings. Empathetic, hopeful tone for habit/wellbeing explainers.",
    ),
    _track(
        id="buckley-life-in-motion", title="Life In Motion", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Life In Motion' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/life-in-motion/",
        search="Scott Buckley Life In Motion", themes=["calm", "motivation"], tempo="slow",
        video_types=["education", "documentary", "business", "travel"],
        notes="Neoclassical piano, clarinet and strings. Introspective without being sad.",
    ),
    _track(
        id="buckley-discovery", title="Discovery", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Discovery' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/discovery/",
        search="Scott Buckley Discovery", themes=["cinematic", "technology"], tempo="medium",
        video_types=["documentary", "technology", "education", "travel"],
        notes="Optimistic hybrid orchestra with synth arpeggios. Good under an opening hook, then duck it.",
    ),
    _track(
        id="buckley-origami", title="Origami", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Origami' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/origami/",
        search="Scott Buckley Origami", themes=["upbeat", "technology"], tempo="medium",
        video_types=["business", "technology", "education"],
        notes="Smooth electro-jazz groove. Works under listicles and 'three things to try' videos.",
    ),
    _track(
        id="buckley-echoes", title="Echoes", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Echoes' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/echoes/",
        search="Scott Buckley Echoes", themes=["cinematic", "calm"], tempo="slow",
        video_types=["documentary", "motivation"],
        notes="Solo cello and strings; builds after 3 minutes, so use its first half as a bed.",
    ),
    _track(
        id="buckley-midvinter", title="Midvinter", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Midvinter' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/midvinter/",
        search="Scott Buckley Midvinter", themes=["calm"], tempo="slow",
        video_types=["education", "kids"],
        notes="Simple piano lullaby. The gentlest entry here; use at low volume under meditation content.",
    ),
]

# Where to get more, and what the licence really allows. Re-check each page before publishing.
SAFE_SOURCES = [
    {"name": "YouTube Audio Library", "url": "https://support.google.com/youtube/answer/3376882?hl=en",
     "licence": "YouTube Audio Library license, or CC BY 4.0 for tracks marked 'Attribution required'",
     "attribution": "Depends on the track: filter 'Attribution not required' to skip credits",
     "content_id": "No Content ID claims for tracks downloaded from the Audio Library",
     "notes": "Safest option for a YouTube-first channel: lives in YouTube Studio, downloadable as MP3, "
              "filterable by mood and by attribution. The copyright-safe promise is YouTube-only."},
    {"name": "Pixabay Music", "url": "https://pixabay.com/music/",
     "licence": "Pixabay Content License (content from before 2019 is CC0)",
     "attribution": "Not required", "content_id": "Some tracks are Content ID registered (shield icon)",
     "notes": "Largest free library with no credit line needed. Download the MP3 and keep the track page; "
              "avoid tracks with the Content ID shield for monetised videos. Do not resell tracks as files."},
    {"name": "Scott Buckley (CC BY 4.0)", "url": "https://www.scottbuckley.com.au/library/",
     "licence": "CC BY 4.0", "attribution": "Required in the video description, in the exact published form",
     "content_id": "Registered with a claim-release process tied to the credit line",
     "notes": "Cinematic and neoclassical tracks that sound expensive. Paste the credit text verbatim or you "
              "will get a claim. See https://www.scottbuckley.com.au/library/using-this-music/."},
    {"name": "Free Music Archive", "url": "https://freemusicarchive.org/",
     "licence": "Per track: CC0, CC BY, CC BY-SA (never use NC/ND for monetised work)",
     "attribution": "Depends on the track; filter to CC0 for no-credit use",
     "content_id": "Varies by artist", "notes": "Where Monplaisir's CC0 catalogue lives."},
    {"name": "Incompetech / Kevin MacLeod", "url": "https://incompetech.com/music/royalty-free/music.html",
     "licence": "CC BY 4.0 (older tracks CC BY 3.0)",
     "attribution": "Required", "content_id": "Some tracks are claimed; the site publishes the credit format",
     "notes": "Huge, well-known catalogue at every mood; the credit format on each track page must be copied."},
]


def recommend(content_type="", themes=None, limit=8):
    """Tracks suited to a video type and/or theme tags, best first."""
    kind = str(content_type or "").strip().lower()
    wanted = {str(theme).strip().lower() for theme in (themes or []) if str(theme).strip()}
    scored = []
    for index, track in enumerate(CATALOGUE):
        score = 0
        if kind and kind in track["video_types"]:
            score += 3
        score += 2 * len(wanted & set(track["themes"]))
        if track["attribution"] == "none":
            score += 1  # fewer obligations is a feature for a channel that reuses tracks
        if score:
            scored.append((score, index, track))
    scored.sort(key=lambda row: (-row[0], row[1]))
    return [track for _, _, track in scored[:max(1, int(limit))]]


def credit_block(tracks):
    """The description block for every track that needs one; empty when none do."""
    lines = [track["credit"] for track in tracks or [] if track.get("attribution") == "required" and track.get("credit")]
    if not lines:
        return ""
    return "Music:\n" + "\n".join(lines)


def theme_tags(content_type="", tracks=None, limit=3):
    """The library tags to attach when importing a track for this kind of video.

    Only the themes of the recommended tracks, most common first, so the advice is
    "tag it calm or motivation" rather than the whole vocabulary.
    """
    rows = tracks if tracks is not None else recommend(content_type, limit=6)
    counts = {}
    for track in rows:
        for theme in track["themes"]:
            counts[theme] = counts.get(theme, 0) + 1
    ranked = sorted(counts, key=lambda theme: (-counts[theme], theme))
    return ranked[:max(1, int(limit))] or ["calm"]

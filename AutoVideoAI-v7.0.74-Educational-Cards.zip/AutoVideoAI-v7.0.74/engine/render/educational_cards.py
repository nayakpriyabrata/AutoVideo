"""Educational text-card kinds (7.0.74).

Only used for videos whose content_type is "education". Copy is supplied by the
Gemini Web draft in speech_cards; this module only draws it:

* takeaway / tip / warning: one point with a glyph badge (star, check, triangle).
* points: a titled, numbered list of 3-5 short points in a transparent panel.

Each card PNG is a full-canvas transparent frame. Its panel rectangle is returned
as ``box`` so the FFmpeg renderer can pop the panel open and closed (anim='pop').
Other video types keep the 7.0.73 keypoint cards unchanged.
"""
from __future__ import annotations

import math
from pathlib import Path

from PIL import Image, ImageDraw

EDUCATIONAL_TYPES = ("education",)
SINGLE_KINDS = ("takeaway", "tip", "warning")
LIST_KIND = "points"
EDUCATIONAL_KINDS = SINGLE_KINDS + (LIST_KIND,)
LABELS = {"takeaway": "KEY IDEA", "tip": "TRY THIS", "warning": "AVOID THIS"}
MIN_POINTS, MAX_POINTS, MAX_POINT_CHARS = 3, 5, 60
INK = (12, 20, 35, 255)


def is_educational(content_type) -> bool:
    return str(content_type or "").strip().lower() in EDUCATIONAL_TYPES


def _badge(d, kind, cx, cy, r, palette):
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=palette["accent"])
    stroke = max(4, int(r * .22))
    if kind == "tip":
        d.line([(cx - .50 * r, cy + .05 * r), (cx - .12 * r, cy + .42 * r), (cx + .52 * r, cy - .38 * r)],
               fill=INK, width=stroke, joint="curve")
    elif kind == "warning":
        d.polygon([(cx, cy - .62 * r), (cx + .66 * r, cy + .50 * r), (cx - .66 * r, cy + .50 * r)], fill=INK)
        d.rounded_rectangle((cx - .08 * r, cy - .30 * r, cx + .08 * r, cy + .16 * r),
                            radius=max(2, int(.06 * r)), fill=palette["accent"])
        d.ellipse((cx - .09 * r, cy + .27 * r, cx + .09 * r, cy + .43 * r), fill=palette["accent"])
    else:  # takeaway: five-point star
        points = []
        for i in range(10):
            angle = -math.pi / 2 + i * math.pi / 5
            radius = .62 * r if i % 2 == 0 else .27 * r
            points.append((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
        d.polygon(points, fill=INK)


def render_single(card: dict, path, width: int, height: int, style: str) -> dict:
    from .typography import resolve_style, PALETTES, fit, draw_text
    kind = card["kind"]
    style = resolve_style(style)
    palette = PALETTES[style]
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    vertical = height > width
    scale = min(width, height) / 1080.0
    left, top = int(width * .065), int(height * .12)
    panel_w = int(width * (.80 if vertical else .62))
    pad, stroke = max(12, int(30 * scale)), max(1, int(3 * scale))
    badge_r = max(26, int(52 * scale))
    content_x = left + pad + 2 * badge_r + pad
    content_w = left + panel_w - pad - content_x
    label = fit(d, LABELS[kind], content_w, int(60 * scale), size=44 * scale, minimum=30 * scale,
                style=style, bold=True, max_lines=1, stroke=max(1, stroke - 1))
    body = fit(d, card["text"], content_w, int(height * .36), size=66 * scale, minimum=44 * scale,
               style=style, bold=True, headline=True, max_lines=3, stroke=stroke)
    gap = int(10 * scale)
    text_h = (label.height if label else 0) + gap + body.height
    panel_h = max(2 * badge_r, text_h) + 2 * pad
    d.rounded_rectangle((left, top, left + panel_w, top + panel_h), radius=int(28 * scale),
                        fill=palette["panel"], outline=(255, 255, 255, 65), width=max(1, int(2 * scale)))
    _badge(d, kind, left + pad + badge_r, top + panel_h / 2, badge_r, palette)
    y = top + (panel_h - text_h) / 2
    boxes = []
    if label:
        boxes.append(draw_text(d, label, (content_x, y, content_x + content_w, y + label.height), palette["secondary"]))
    y += (label.height if label else 0) + gap
    boxes.append(draw_text(d, body, (content_x, y, content_x + content_w, y + body.height), (255, 255, 255, 255)))
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    img.save(path)
    return {"kind": kind, "path": str(path), "box": [left, top, panel_w, panel_h],
            "layout": {"style": style, "font_sizes": [label.size if label else 0, body.size],
                       "text_boxes": boxes, "canvas": [width, height]}}


def render_list(card: dict, path, width: int, height: int, style: str) -> dict:
    from .structured_graphics import render_card
    event = {"kind": "list", "start": card["start"], "end": card["end"], "title": card["text"],
             "rows": [{"label": point} for point in card["points"]], "active": None}
    return render_card(event, path, width, height, style=style)


def render_card_png(card: dict, path, width: int, height: int, style: str = "playful") -> dict:
    """Draw one educational card and return its overlay fields (path, box, layout)."""
    kind = card.get("kind")
    if kind == LIST_KIND:
        info = render_list(card, path, width, height, style)
    elif kind in SINGLE_KINDS:
        info = render_single(card, path, width, height, style)
    else:
        raise ValueError("Unknown educational card kind: " + str(kind))
    return {**info, "kind": kind, "start": card["start"], "end": card["end"], "title": card["text"],
            "anchor": "top-left", "opacity": 1, "anim": "pop", "fade_in": .22, "fade_out": .22}

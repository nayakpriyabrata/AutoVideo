# AutoVideoAI v7.0.42 — Safe Resume Foundation

This upgrade is intentionally conservative. It blocks accidental duplicate Flow submissions when locally saved request journals remain pending. It **does not** claim to automatically reconcile Google Flow's remote images, and it does not solve every stability issue discussed.

## Installation (v7.0.41 patched source only)

Extract this ZIP **over a copy** of your current v7.0.41 installation. Preserve symlinks to `AutoVideoAI-Shared`; never overwrite the shared workspace. The patch replaces only `engine/factory.py` and adds `engine/flow_resume_safety.py`, `tools/flow_resume_preflight.py`, and `tests/test_v742_safe_resume_gate.py`; it updates VERSION.

Before extraction:

```bash
cd /mnt/c/Users/eiyanpr/Downloads/Auto
cp -a AutoVideoAI-v7.0.41 AutoVideoAI-v7.0.42
cd AutoVideoAI-v7.0.42
unzip -o ../AutoVideoAI-v7.0.42-Safe-Resume-Foundation.zip
python3 -m pytest -q tests/test_v742_safe_resume_gate.py tests/test_v739_automatic_recovery.py tests/test_flow_unreadable_gallery_circuit_breaker.py
```

**WSL note**: `cp -a` of a large job source can consume significant space; use your existing shared-workspace migration flow and confirm `outputs`, `data`, `.autovideo-control`, `assets/channel`, and `assets/music` remain symlinks before running. If unsure, use `cp -a --reflink=auto` only on a filesystem that supports it, or install in place after preserving the original factory module.

## Read-only preflight

```bash
python3 tools/flow_resume_preflight.py outputs/<job-id>
```

Exit 0 permits generation; exit 3 signifies unresolved request journals. Any corrupted or unreadable journal also blocks. The check runs automatically before normal job execution from CLI, dashboard, and automation paths calling Factory.run_job().

## Boundaries

- The preflight does not contact Flow and cannot establish remote asset provenance.
- It does not interpret missing images as authorization to regenerate.
- It will block an old job until journals are reconciled, even if some images already exist.
- No unsafe bypass is included.
- Do not delete the old Little Kanha project until the new build is validated.
- No change to database schema, render engine, or shared workspace.

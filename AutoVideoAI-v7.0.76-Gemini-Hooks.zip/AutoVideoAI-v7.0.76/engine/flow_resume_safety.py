"""Zero-network preflight for outstanding Google Flow requests.

Pending journals are not proof of successful generation, and missing image files
are not authorization for another submission. Default to preserving credits.
"""
from __future__ import annotations
import json
import hashlib
from pathlib import Path


def check_job(job_dir):
    root = Path(job_dir).expanduser().absolute()
    if root.is_symlink() or not (root / 'production_manifest.json').is_file():
        raise ValueError('Expected an existing, non-symlink AutoVideoAI job directory')
    rows = []
    for journal in sorted(root.rglob('*.flow-request.json')):
        if journal.is_symlink():
            rows.append({'journal': str(journal.relative_to(root)), 'state': 'unreadable', 'reason': 'symlink'}); continue
        try:
            data = json.loads(journal.read_text(encoding='utf-8'))
            state = str(data.get('status') or data.get('state') or 'unknown').lower()
            image_path = Path(str(journal)[:-len('.flow-request.json')])
            image_present = image_path.is_file() and image_path.stat().st_size > 0
            if state == 'superseded_by_authorized_replacement':
                # Supersession is not a claim that the original request was
                # downloaded. Both the new asset and its installed frame must
                # remain bound to the committed replacement bytes.
                expected = data.get('replacement_sha256')
                valid = isinstance(expected, str) and len(expected) == 64
                for value in (data.get('replacement_file'), data.get('replacement_target')):
                    candidate = root / str(value or '')
                    valid = valid and (bool(value) and not candidate.is_symlink()
                        and candidate.resolve().is_relative_to(root.resolve())
                        and candidate.is_file())
                    if valid:
                        valid = hashlib.sha256(candidate.read_bytes()).hexdigest() == expected
                if not valid:
                    rows.append({'journal': str(journal.relative_to(root)), 'state': 'replacement_missing_or_changed'})
                continue
            if data.get('scope') in ('isolated_one_frame_one_request', 'isolated_image_v1') and state == 'downloaded':
                if (not image_present or image_path.is_symlink() or
                        hashlib.sha256(image_path.read_bytes()).hexdigest() != data.get('media_sha256')):
                    rows.append({'journal': str(journal.relative_to(root)), 'state': 'replacement_missing_or_changed'})
                continue
            if state in ('pending', 'submitted', 'running', 'generating', 'unknown', 'unreadable'):
                rows.append({'journal': str(journal.relative_to(root)), 'state': state, 'local_image_exists': image_present})
        except (OSError, ValueError, TypeError) as exc:
            rows.append({'journal': str(journal.relative_to(root)), 'state': 'unreadable', 'reason': type(exc).__name__})
    return {'job_id': root.name, 'safe_to_generate': not rows, 'unresolved_count': len(rows), 'unresolved': rows,
            'policy': 'Conservative: pending/unreadable requests always require explicit reconciliation before new generation.'}


class FlowResumeBlocked(RuntimeError):
    def __init__(self, report):
        self.report = report
        super().__init__(f"Safe Resume blocked: {report['unresolved_count']} unresolved Flow request journal(s) for "
                         f"{report['job_id']}. Run `python3 tools/flow_resume_preflight.py "
                         f"outputs/{report['job_id']}` and reconcile existing assets first. "
                         "See logs/resume-reconciliation.json for recovery results.")


def require_safe_job(job_dir):
    result = check_job(job_dir)
    if not result['safe_to_generate']:
        raise FlowResumeBlocked(result)
    return result

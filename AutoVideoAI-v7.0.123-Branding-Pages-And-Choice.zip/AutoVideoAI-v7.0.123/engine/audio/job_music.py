"""Persist successful music retrieval so rendering never repeats the same lookup."""
import hashlib
import json
from pathlib import Path
from .music_provider import _sha256


def obtain_job_music(audio_dir, mode, mood, local_path=''):
    # Auto promises a playable bed, including a disclosed original offline fallback.
    mode = 'reliable' if mode == 'auto' else mode
    parameters = {'mode': mode, 'mood': mood, 'local_path': str(local_path or '')}
    fingerprint = hashlib.sha256(json.dumps(parameters, sort_keys=True).encode()).hexdigest()
    cache = Path(audio_dir) / 'music_preflight.json'
    try:
        previous = json.loads(cache.read_text())
        meta = previous['music']
        if (previous['fingerprint'] == fingerprint and meta.get('path')
                and Path(meta['path']).is_file() and meta.get('sha256') == _sha256(meta['path'])):
            return meta
    except (OSError, ValueError, KeyError, TypeError):
        pass
    if mode == 'off':
        return {'path': None, 'source': 'off'}
    if local_path:
        path = Path(local_path).resolve()
        if not path.is_file():
            raise ValueError(f'Local music file does not exist: {path}')
        meta = {'path': str(path), 'source': 'local-user-supplied', 'sha256': _sha256(str(path)),
                'license': 'User must verify music rights'}
    else:
        from .music_provider import ensure_background_music
        meta = ensure_background_music(mood, str(audio_dir), mode=mode)
    if meta.get('path'):
        from ..flow_music import validate_audio
        validate_audio(meta['path'])
        meta['sha256'] = _sha256(meta['path'])
        from ..production import save
        save(cache, {'fingerprint': fingerprint, 'music': meta})
    return meta

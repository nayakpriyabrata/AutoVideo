"""v7.0.68: every selected language edition is rendered from its own reviewed narration.

Real FFmpeg media, no Gemini/TTS/Flow calls. Narration tones are used as voice
fingerprints: 660 Hz for Hindi and 880 Hz for Odia. An English 440 Hz voice must
never appear in a non-English edition.
"""
import array
import hashlib
import importlib.util
import json
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('finish_v768', ROOT / 'engine' / 'finishing_studio.py')
finish = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(finish)

needs_ffmpeg = pytest.mark.skipif(not (shutil.which('ffmpeg') and shutil.which('ffprobe')), reason='FFmpeg required')


def _tone(path, frequency, seconds):
    cmd = ['ffmpeg', '-y', '-loglevel', 'error', '-f', 'lavfi', '-i', f'sine=frequency={frequency}:sample_rate=44100',
           '-t', str(seconds), '-c:a', 'libmp3lame', '-b:a', '128k', str(path)]
    subprocess.run(cmd, check=True)
    return path


def _picture(path, seconds):
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc2=size=640x360:rate=24',
                    '-t', str(seconds), '-an', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', str(path)], check=True)
    return path


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _zero_crossings_per_second(path, seconds=1.0, start=0.0):
    raw = subprocess.run(['ffmpeg', '-loglevel', 'error', '-ss', str(start), '-i', str(path), '-vn', '-ac', '1', '-ar', '8000',
                          '-f', 's16le', '-t', str(seconds), '-'], capture_output=True, check=True).stdout
    samples = array.array('h', raw)
    crossings = sum(1 for a, b in zip(samples, samples[1:]) if (a < 0) != (b < 0))
    return crossings / seconds


def _duration(path):
    out = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', str(path)],
                         capture_output=True, text=True, check=True).stdout
    return float(out.strip())


def _job(tmp_path, *, picture_seconds=3.0, hindi_seconds=3.0, odia_seconds=3.0, odia_profile=None):
    """A finished production: clean visual master plus reviewed Hindi/Odia bundles."""
    job = tmp_path / 'job'
    (job / 'render').mkdir(parents=True)
    (job / 'production').mkdir()
    (job / 'audio').mkdir()
    visual = _picture(job / 'render' / 'visual-master.mp4', picture_seconds)
    finish._atomic_json(job / 'production' / 'visual_master.json',
                        {'path': str(visual.resolve()), 'sha256': _sha(visual), 'duration': picture_seconds,
                         'contains': 'picture and approved B-roll only; no speech, captions, music or branding'})
    bundles = {}
    for code, freq, seconds in (('hi', 660, hindi_seconds), ('or', 880, odia_seconds)):
        folder = job / 'speech-editions' / code / ('key-' + code)
        folder.mkdir(parents=True)
        audio = _tone(folder / 'voice.mp3', freq, seconds)
        words = [{'word': 'शब्द', 'start': 0.1, 'end': 0.9}, {'word': 'दो', 'start': 1.0, 'end': 1.8},
                 {'word': 'तीन', 'start': 2.0, 'end': 2.8}]
        words_path = folder / 'words.json'
        words_path.write_text(json.dumps(words, ensure_ascii=False), encoding='utf-8')
        bundles[code] = {'audio': str(audio), 'audio_sha256': _sha(audio), 'duration': seconds,
                         'words': str(words_path), 'script': 'स्वीकृत वर्णन', 'language': code,
                         'timing_source': 'test-measured',
                         'cards': [{'text': 'नमस्ते', 'start': 0.5, 'end': 2.5, 'start_word': 0, 'end_word': 1,
                                    'spoken_anchor': 'शब्द दो'}]}
    profiles = {'hi': None, 'or': odia_profile}
    finish._atomic_json(job / 'production' / 'language_editions.json',
                        {'source_language': 'en', 'editions': ['en', 'hi', 'or'], 'profiles': profiles,
                         'prepare_audio': True, 'bundles': bundles, 'status': 'prepared batch attached'})
    return job


@needs_ffmpeg
def test_each_selected_language_is_rendered_with_its_own_narration(tmp_path):
    from engine.language_editions import render_job_editions
    profile_root = tmp_path / 'profiles'
    logo = tmp_path / 'odia-logo.png'
    from PIL import Image
    Image.new('RGB', (120, 120), 'orange').save(logo)
    odia_profile = finish.save_profile('Odia Pragati', names={'or': 'ଓଡ଼ିଆ ପ୍ରଗତି'}, logo=logo, root=profile_root)
    job = _job(tmp_path, odia_profile=str(odia_profile))

    report = render_job_editions(job)

    assert report['status'] == 'exported', report
    hindi = Path(report['editions']['hi']['path'])
    odia = Path(report['editions']['or']['path'])
    assert hindi.is_file() and odia.is_file()
    assert hindi.name.startswith('hi-') and odia.name.startswith('or-')
    # Each edition speaks its own reviewed narration, never the primary/English voice.
    assert 1250 < _zero_crossings_per_second(hindi) < 1400          # 660 Hz Hindi voice
    assert 1700 < _zero_crossings_per_second(odia) < 1850           # 880 Hz Odia voice
    assert abs(_duration(hindi) - 3.0) < 0.3 and abs(_duration(odia) - 3.0) < 0.3
    hindi_provenance = json.loads(hindi.with_suffix('.provenance.json').read_text(encoding='utf-8'))
    assert hindi_provenance['captions_burned'] is True and hindi_provenance['narration_fitted_picture'] is False
    assert json.loads(odia.with_suffix('.provenance.json').read_text(encoding='utf-8'))['channel']['name'] == 'Odia Pragati'
    record = json.loads((job / 'production' / 'language_editions_render.json').read_text(encoding='utf-8'))
    assert record['status'] == 'exported' and set(record['editions']) == {'hi', 'or'}

    # Re-running reuses the verified exports; nothing is re-rendered or overwritten.
    again = render_job_editions(job)
    assert again['status'] == 'exported'
    assert again['editions']['hi']['path'] == report['editions']['hi']['path']


@needs_ffmpeg
def test_longer_localized_narration_stretches_the_picture_within_the_limit(tmp_path):
    from engine.language_editions import render_job_editions
    job = _job(tmp_path, picture_seconds=3.0, hindi_seconds=3.3, odia_seconds=3.0)
    report = render_job_editions(job)
    assert report['status'] == 'exported', report
    export = Path(report['editions']['hi']['path'])
    assert abs(_duration(export) - 3.3) < 0.2          # the whole Hindi narration is kept
    assert 1250 < _zero_crossings_per_second(export, seconds=1.0, start=0.5) < 1400   # Hindi voice intact
    provenance = json.loads(export.with_suffix('.provenance.json').read_text(encoding='utf-8'))
    assert provenance['narration_fitted_picture'] is True


@needs_ffmpeg
def test_narration_more_than_quarter_longer_fails_visibly_not_with_english(tmp_path):
    from engine.language_editions import render_job_editions
    job = _job(tmp_path, picture_seconds=3.0, hindi_seconds=4.2, odia_seconds=3.0)
    report = render_job_editions(job)
    assert report['status'] == 'partial'
    assert report['editions']['hi']['status'] == 'failed'
    assert '25%' in report['editions']['hi']['error']
    assert report['editions']['or']['status'] == 'exported'


@needs_ffmpeg
def test_missing_reviewed_narration_is_refused_before_any_render(tmp_path):
    from engine.language_editions import render_job_editions
    job = _job(tmp_path)
    state_path = job / 'production' / 'language_editions.json'
    state = json.loads(state_path.read_text(encoding='utf-8'))
    del state['bundles']['or']
    state_path.write_text(json.dumps(state, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(ValueError, match='Odia'):
        render_job_editions(job)
    assert not (job / 'language_editions').exists()


@needs_ffmpeg
def test_single_language_job_keeps_the_normal_single_render(tmp_path):
    from engine.language_editions import render_job_editions
    job = tmp_path / 'job'
    (job / 'production').mkdir(parents=True)
    finish._atomic_json(job / 'production' / 'language_editions.json',
                        {'source_language': 'en', 'editions': ['en'], 'profiles': {}, 'bundles': {}})
    assert render_job_editions(job)['status'] == 'single_language'
    assert render_job_editions(tmp_path / 'no-selection')['status'] == 'not_requested'


@needs_ffmpeg
def test_manual_edition_never_borrows_the_source_voice(tmp_path):
    """Finishing Studio: a Hindi edition without its own narration is refused, not exported in English."""
    source = _picture(tmp_path / 'source.mp4', 2.0)
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', str(source), '-f', 'lavfi', '-i', 'sine=frequency=440',
                    '-t', '2', '-c:v', 'copy', '-c:a', 'aac', '-shortest', str(tmp_path / 'with-voice.mp4')], check=True)
    profile = finish.save_profile('Guard', root=tmp_path / 'profiles')
    plan = finish.create_plan(tmp_path / 'with-voice.mp4', profile, languages=['en', 'hi'],
                              output_root=tmp_path / 'out', source_language='en')
    finish.set_edition(plan, 'hi', cards=[], reviewed=True)
    with pytest.raises(ValueError, match='no reviewed narration'):
        finish.render(plan, 'hi')
    finish.set_edition(plan, 'en', cards=[], reviewed=True)
    assert finish.render(plan, 'en').is_file()        # the source-language edition keeps its own audio


@needs_ffmpeg
def test_edition_without_a_channel_profile_renders_without_a_mark(tmp_path):
    source = _picture(tmp_path / 'source.mp4', 2.0)
    plan = finish.create_plan(source, {'hi': None}, languages=['hi'], output_root=tmp_path / 'out', require_profiles=False)
    data = json.loads(Path(plan).read_text(encoding='utf-8'))
    assert data['editions']['hi']['channel']['name'] == '' and data['editions']['hi']['assets'] == {}
    with pytest.raises(ValueError, match='channel profile'):
        finish.create_plan(source, {'hi': None}, languages=['hi'], output_root=tmp_path / 'out2')


def test_primary_render_hooks_language_editions_and_surfaces_failures():
    factory = (ROOT / 'engine' / 'factory.py').read_text(encoding='utf-8')
    assert 'render_job_editions(' in factory
    assert 'Language editions need attention' in factory
    assert factory.index('render_job_editions(') < factory.index('m.status = "done"')
    assert '"language_editions": edition_report' in factory


def test_create_page_blocks_extra_editions_without_approved_batch_and_offers_profiles():
    app = (ROOT / 'app.py').read_text(encoding='utf-8')
    assert 'Additional language editions need Voiceover and an approved language batch' in app
    assert 'len(batch_languages)>1 and not (studio_voice_on and use_prepared_batch)' in app
    assert 'Create a {edition_label} channel profile here' in app
    assert 'def language_edition_panel' in app and 'render_job_editions' in app
    assert app.index('Additional language editions · optional') < app.index('2 · Review script and cast · optional')
    assert 'Prepare selected language scripts for review · no TTS' in app


def test_finishing_ui_declares_source_language_before_planning():
    ui = (ROOT / 'engine' / 'finishing_ui.py').read_text(encoding='utf-8')
    assert "'Language spoken in this source video'" in ui
    assert 'source_language=source_language' in ui

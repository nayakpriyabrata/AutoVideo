# v7.0.9 — easier B-roll review, compact video previews and optional clip logos

## Review five clips without fifty separate approvals

In **Clip Studio**, generate the highlights and related B-roll suggestions as before. The review displays one highlight's suggestions at a time in a compact three-column gallery, with at most six previews per page. Use the clip and page selectors to inspect them. The original highlight is shown once in a collapsed panel. Video player fullscreen remains available; output resolution and framing are unchanged.

Set **Batch decision applies to → All clips**, tick the single batch approval checkbox, and click **Approve all & render**. This saves exact-file approvals and renders the approved cutaways into one separate version of each highlight. You can also approve the previewed clip's batch, skip a batch, or edit individual timing/decisions under **Advanced individual decisions and placement**. Individual edits persist only the visible page; other saved decisions remain untouched.

Batch approval skips missing or changed assets. It requires the displayed review identity and candidate hashes to match, retains per-file hash verification, and records the batch decision. It does not certify semantic relevance or grant publication rights. Pending suggestions outside an approved per-clip scope still need a batch decision before rendering all saved cutaways. Original highlights are preserved.

Already-generated clips can be loaded using **Load saved highlights for B-roll review — no regeneration**. The compact review and batch controls apply to their existing suggestion report too.

## Optional channel logo

Before creating new clips, open **Optional channel logo**, enable **Show my channel logo on clips**, and enter a local WSL path to a PNG, JPEG or WebP image. Transparent PNG is recommended. Choose the corner and width (5–25% of frame width, default 12%). The logo is scaled proportionally, height-capped and inset from the corner. This is an image logo, not animated channel text.

The option is off by default. Invalid enabled logos fail validation before source/provider processing. A validated transparent overlay snapshot is saved with the clip job, composited during the original render, and retained in its subsequent B-roll versions. Source audio, captions and output dimensions remain part of the existing pipeline. Changing a saved overlay file blocks rendering rather than silently using a different logo. Existing clips generated without a logo are not retroactively branded by changing the creation controls; enable the option on the next clip batch.

The private control center also has an optional clip logo switch, WSL image path, corner and size controls. Its local runner forwards these choices to the engine.

CLI/YAML equivalents:

```yaml
show_channel_logo: true
channel_logo_path: "/mnt/c/Users/your-name/Pictures/channel-logo.png"
channel_logo_size: 0.12
channel_logo_position: top-right
```

## Upgrade

Stop Studio and any CLI job, back up the installation, and update source files inside the existing installation folder. Preserve outputs, data, .env, configuration, profiles and request journals. Restart Studio and the local runner to load the update. Existing Flow recovery protections from v7.0.8 remain included.

## v7.0.9 validation

Full engine suite: 709 passed, with 12 existing dependency deprecation warnings. Private control center: 29 tests passed and syntax checks passed. Tests include a 50-candidate batch, missing/changed asset skipping, rejection of stale review identities, real Streamlit pagination and batch interaction, optional-logo validation, and actual FFmpeg renders confirming visible logo pixels on highlight/B-roll copies with and without added music. Audio streams were retained. Logo choices also round-trip through the private local runner payload. No external source download, paid generation, or live user WSL session was used.

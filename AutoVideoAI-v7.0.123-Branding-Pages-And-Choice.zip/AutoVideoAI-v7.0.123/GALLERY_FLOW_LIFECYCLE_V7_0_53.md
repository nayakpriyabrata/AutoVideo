# AutoVideoAI 7.0.53 — gallery, cast scope and Flow lifecycle

## Findings from the supplied run

The runtime log contains 52 New-project actions, 13 download failures and two approval clicks. The two recorded approvals occur on different shot attempts; they do not establish that one video needed multiple paid approvals. The decisive video failure was target closure while saving an exact blob download. Later gallery scans sometimes could not see that asset. The plan had 42 shots: 34 single-still motion scenes and 8 paired-frame video scenes, which implies 50 storyboard stills plus the location master. One-project-per-still isolation therefore explains most of this project count; it is not evidence of 52 paid video generations.

The gallery created players and eagerly read MP4 download payloads across every tab. That is removed: the page now renders six metadata-only cards in one category, and only a selected video opens in a popup. Download preparation happens inside that popup. The workspace/page widgets now use their initialized Session State without also supplying a conflicting default index.

The draft sent the entire saved character library to Gemini. Aanya was a model suggestion from that supplied cast, not a hard-coded engine identity. Drafting now starts with an empty optional cast scope; only explicitly selected saved characters are sent. Changing that scope clears the old proposal. Final production casting remains a separate selection. The image-replacement checkbox now defaults off, matching the engine's opt-in policy.

A browser lifecycle defect could leave a loaded guard tab behind whenever the project changed. Across a large storyboard this can accumulate many heavy pages. The app now reuses one app-owned guard across projects; borrowed user tabs are not retargeted or closed. This is a confirmed resource leak; it is not proof of the precise reason Chromium crashed on this PC.

## Exact downloads

For a UI-generated blob download, the adapter now tries to capture that exact blob while its browser context is alive. It uses only Flow-origin download-event URLs, a bounded 16 MiB transfer and a bounded browser wait, and validates the local image/video before committing it. It does not guess an asset by position or fetch another file. Existing native/HTTPS download paths remain available. A whole-browser crash can still make its blob inaccessible; the saved request remains download-only for recovery.

## Repeated approval cards

Guided Studio → Advanced now includes **Maximum approval cards per video request**, 1–3, default 1. The Control Center exposes the same setting. If deliberately permitting two cards, choose 2 and a sufficient **total per-generation cap**. For example two displayed five-credit cards require a cap of at least ten. This does not guarantee Flow needs or will show two cards.

The adapter keeps probing for late cards and reserves each distinct request question durably before clicking. All displayed costs share the same total request cap. Unknown costs, excessive counts and over-budget totals stop. Polling/reopening the same question never approves it again. Credit parsing uses the current question rather than an older cheaper card in chat history. An uncertain click retains its reservation. Persistent Always-approve remains an explicit legacy option, not the default.

Download-only Resume/Recover does not approve new credit-bearing work. For the currently pending shot, inspect its saved Flow project and finish any deliberately approved visible account confirmation yourself if needed, then use exact recovery. Increasing a new-job setting does not rewrite an existing submitted request or authorize its resubmission.

## Clean completed still projects

Open **Gallery & Downloads → Clean downloaded Flow image projects · optional → Review saved Flow projects**.

The review distinguishes eligible isolated-image projects from retained ones. Select individual projects, inspect their exact links, confirm, then choose **Delete selected verified image projects**. This is an explicit cleanup operation after capture; projects are not automatically deleted in the middle of production.

Eligibility requires downloaded status, a valid local image matching its saved hash, available unchanged reference files, the isolated-image protocol and a complete captured gallery inventory. All video projects, unresolved requests, unknown/legacy projects, changed or missing images and unreadable evidence are retained. Production must be stopped before cleanup. If a project is shared with a pending/video journal within the output root, it is retained.

Immediately before deletion the adapter opens the exact saved project URL and checks that its entire readable live gallery still matches the captured image inventory. It accepts only a scoped project menu with Rename / View bin / Delete. It handles a project-specific confirmation dialog and requires a fresh explicit Project-deleted confirmation. Merely navigating away is not success. Unknown UI, extra media, missing identity evidence or a missing confirmation stops verification.

Each operation is reserved before the remote action. If deletion is uncertain, the local ledger retains that state and prevents an automatic repeat. Inspect the recorded project manually in that case. Local captures, request journals, video projects and resume data are kept. Keep backups of local media: deleting the Flow copy removes that download-recovery source. Perform this review before deleting a complete local job if you want its recorded project identities available.

The project-menu adapter is checked with controlled fixtures, not your signed-in Google account. The attached screenshot establishes the menu layout but does not establish the confirmation/toast behavior of every Flow cohort. The feature therefore fails closed when that confirmation cannot be verified. Whole-job remote deletion remains disabled; this separate reviewed action is limited to verified isolated still projects.

## Install and recover this job

Wait for active work to stop, then stop Studio and the runner. Extract the ZIP next to the existing installation. From the existing `AutoVideoAI-v7` directory:

```bash
python3 ../AutoVideoAI-v7.0.53/tools/update_v743_to_v753.py . --apply
./dashboard.sh
```

The cumulative updater accepts 7.0.43–7.0.52, verifies release hashes, backs up code and preserves runtime settings, browser profiles, media, journals and shared job folders. Continue running commands from the updated existing directory.

For `20261016-115816-the-power-of-self-confid-31b9`, use the saved job's **Recover exact saved Flow request** action after upgrading. Keep its video project and journals. This update does not clear its pending flag or start a replacement video. If a gallery identity still cannot be proved, export its support report for the exact saved request rather than repeatedly generating anew.

## Documentation checked

- [Streamlit download buttons](https://docs.streamlit.io/develop/api-reference/widgets/st.download_button): attached download data can consume server memory; the gallery defers payload preparation to the selected popup.
- [Playwright downloads](https://playwright.dev/python/docs/downloads): browser-context lifetime matters to temporary downloads, which must be saved durably.
- [Google Flow project management](https://support.google.com/flow/answer/16935308?hl=en): project deletion and asset deletion are distinct actions. This feature never uses a media-tile delete action to stand in for a project delete.

No real Google generation, credit approval or remote deletion was submitted during development. Live Google UI behavior and the precise crash cause on the user's PC remain unverified.

## Release verification

Full engine suite: 1,113 passed, 13 dependency deprecation warnings. Final focused gallery/cleanup/UI checks: 27 passed. Control Center: 26 JavaScript and 19 Python runner tests passed; JavaScript/Python syntax checks passed. Coverage includes exact origin-bound blob captures, guard-tab reuse, current-card price parsing, cumulative reservations, popup-only gallery loading, empty draft-cast scope, changed-media protection, uncertain deletion retention, and mandatory remote success confirmation. Release hashes and cumulative updater preservation are checked before delivery.

"""Add a reviewed music bed to an existing video without regenerating visuals."""
import hashlib
import json
import math
from pathlib import Path
import subprocess

from ..production import digest, probe, save
from ..review_lock import review_transaction
from .music_library import list_tracks


def add_music_copy(source, track, volume=.18):
    source=Path(source).expanduser().resolve();track=Path(track).expanduser().resolve()
    if not source.is_file() or not track.is_file():raise ValueError('Select an existing video and music track')
    reviewed=next((r for r in list_tracks() if Path(r['path']).resolve()==track),None)
    if not reviewed or digest(track)!=reviewed['sha256']:
        raise ValueError('Music must be a reviewed, unchanged track from the shared library')
    if not isinstance(volume,(int,float)) or not math.isfinite(volume) or not .01<=volume<=.5:
        raise ValueError('Music gain must be 0.01–0.50')
    media=probe(source)
    if not any(s.get('codec_type')=='video' for s in media.get('streams',[])):
        raise ValueError('Source is not a video')
    duration=float(media.get('format',{}).get('duration') or 0)
    if not math.isfinite(duration) or not 1<=duration<=21600:
        raise ValueError('Unsupported video duration')
    from ..flow_music import validate_audio
    validate_audio(track)
    original=digest(source);key=hashlib.sha256(json.dumps([original,reviewed['sha256'],volume]).encode()).hexdigest()[:16]
    target=source.with_name(source.stem+'-music-'+key+'.mp4')
    meta=Path(str(target)+'.json')
    with review_transaction(str(meta)):
        if target.is_file() and meta.is_file():
            previous=json.loads(meta.read_text())
            if previous.get('output_sha256')==digest(target):return str(target)
        stage=source.parent/('.'+target.name+'.part.mp4')
        voice=any(s.get('codec_type')=='audio' for s in media.get('streams',[]))
        if voice:
            filters=(f'[0:a:0]aresample=48000,aformat=channel_layouts=stereo,apad,atrim=0:{duration}[voice];'
                     f'[1:a:0]aresample=48000,aformat=channel_layouts=stereo,volume={volume},atrim=0:{duration}[music];'
                     '[voice]asplit=2[main][detect];[music][detect]sidechaincompress=threshold=0.03:ratio=6:attack=100:release=550[duck];'
                     f'[main][duck]amix=inputs=2:duration=first:normalize=0,atrim=0:{duration},'
                     'loudnorm=I=-14:TP=-1.5:LRA=11[mix]')
        else:
            filters=f'[1:a:0]aresample=48000,aformat=channel_layouts=stereo,volume={volume},atrim=0:{duration},loudnorm=I=-14:TP=-1.5:LRA=11[mix]'
        command=['ffmpeg','-v','error','-nostdin','-y','-i',str(source),'-stream_loop','-1','-i',str(track),
                 '-filter_complex',filters,'-map','0:v:0','-map','[mix]','-c:v','copy','-c:a','aac','-b:a','192k',
                 '-t',str(duration),'-movflags','+faststart',str(stage)]
        try:
            subprocess.run(command,capture_output=True,text=True,timeout=max(120,min(1800,int(duration*5))),check=True)
            if not stage.is_file() or stage.stat().st_size<10000 or digest(source)!=original:
                raise RuntimeError('Music copy did not validate or the source changed')
            output=probe(stage)
            if not any(s.get('codec_type')=='audio' for s in output.get('streams',[])):
                raise RuntimeError('Music copy has no audio')
            stage.replace(target)
            save(meta,{'source_sha256':original,'music_sha256':reviewed['sha256'],
                       'music_source_url':reviewed['source_url'],'license':reviewed['license'],
                       'volume':volume,'output_sha256':digest(target)})
            return str(target)
        except subprocess.CalledProcessError as error:
            raise RuntimeError('FFmpeg music mix failed: '+str(error.stderr)[-500:]) from error
        finally:stage.unlink(missing_ok=True)


def music_overlay_panel(st, source, key):
    with st.expander('Add reviewed background music to a copy · optional'):
        tracks=list_tracks()
        if not tracks:
            st.caption('Import tracks in Guided Studio or Music Video first.')
            return
        selected=st.selectbox('Reviewed track',[r['path'] for r in tracks],key=key+'-track',
            format_func=lambda path:next(r['title']+' · '+r['license'] for r in tracks if r['path']==path))
        st.audio(selected)
        volume=st.slider('Music gain',.01,.5,.18,.01,key=key+'-gain')
        st.caption('Creates a new copy and keeps the original. Check that the source does not already contain music before mixing.')
        if st.button('Make copy with music',key=key+'-create'):
            try:
                with st.spinner('Mixing music over the saved video…'):
                    st.session_state[key+'-result']=add_music_copy(source,selected,volume)
            except Exception as error:st.error(str(error))
        output=st.session_state.get(key+'-result')
        if output and Path(output).is_file():
            st.success('Music copy saved: '+output)
            st.video(output,width=360)

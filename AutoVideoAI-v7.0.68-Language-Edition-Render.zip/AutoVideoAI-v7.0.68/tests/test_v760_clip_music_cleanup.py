import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS

import pytest


def test_clip_library_records_reviewed_provenance(tmp_path, monkeypatch):
    from engine.audio.music_library import select_theme
    folder = tmp_path/'music_library';folder.mkdir()
    music = folder/'song.mp3';music.write_bytes(b'fixture audio')
    digest=hashlib.sha256(music.read_bytes()).hexdigest()
    (folder/'manifest.json').write_text(json.dumps({'tracks':[{'file':music.name,
       'sha256':digest,'title':'Rain Garden','tags':['calm','rain'],
       'source_url':'https://example.org/song','license':'CC0'}]}))
    monkeypatch.setenv('AUTOVIDEO_MUSIC_LIBRARY',str(folder))
    assert select_theme('rain forest')['path']==str(music)
    music.write_bytes(b'changed')
    with pytest.raises(ValueError,match='changed'):select_theme('rain forest')


def test_job_cleanup_remote_success_then_local_delete(tmp_path, monkeypatch):
    from engine.factory import Factory
    from engine.storage_manager import preview_deletion, delete_selected
    from engine.flow_image_transaction import SCOPE, sha
    from engine.flow_project_cleanup import inventory
    import engine.flow_project_cleanup as cleanup
    from PIL import Image
    monkeypatch.chdir(tmp_path);monkeypatch.setenv('HOME',str(tmp_path/'home'))
    import engine.providers.flow_browser as browser
    monkeypatch.setattr(browser,'PROFILE_DIR',str(tmp_path/'.profile'))
    factory=Factory(str(tmp_path/'outputs'),str(tmp_path/'data/jobs.db'))
    job=factory.create_job('Test deletion',dry_run=True)
    folder=Path(factory.pm.job_dir(job));image=folder/'storyboard'/'frame.jpg'
    Image.new('RGB',(160,120),'blue').save(image)
    url='https://flow.google.com/project/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    journal=Path(str(image)+'.flow-request.json')
    journal.write_text(json.dumps({'scope':SCOPE,'kind':'image','status':'downloaded',
      'project_url':url,'media_sha256':sha(image),'reference_hashes':{},
      'capture_inventory':['exact-image']}))
    calls=[]
    class Provider:
        def _ensure(self):return NS(delete_exact_project=lambda u,**kw:(calls.append(u) or {'status':'deleted'}))
        def close(self):pass
    cleanup_delete=cleanup.delete_selected
    monkeypatch.setattr(cleanup,'delete_selected',lambda root,rows,lock_held=False:
        cleanup_delete(root,rows,Provider,lock_held=lock_held))
    preview=preview_deletion(factory,['job:'+job],install=tmp_path)
    assert [r['project_url'] for r in preview['flow']['eligible']]==[url]
    result=delete_selected(factory,preview,delete_flow_projects=True)
    assert calls==[url] and result['flow_projects_deleted']==[url]
    assert not folder.exists() and factory.db.get(job) is None


def test_job_cleanup_remote_uncertainty_retains_local_records(tmp_path, monkeypatch):
    from engine.factory import Factory
    from engine.storage_manager import preview_deletion, delete_selected
    from engine.flow_image_transaction import SCOPE, sha
    from PIL import Image
    import engine.flow_project_cleanup as cleanup
    import engine.providers.flow_browser as browser
    monkeypatch.chdir(tmp_path);monkeypatch.setenv('HOME',str(tmp_path/'home'))
    monkeypatch.setattr(browser,'PROFILE_DIR',str(tmp_path/'.profile'))
    factory=Factory(str(tmp_path/'outputs'),str(tmp_path/'data/jobs.db'))
    job=factory.create_job('Uncertain remote',dry_run=True)
    folder=Path(factory.pm.job_dir(job));image=folder/'storyboard'/'frame.jpg'
    Image.new('RGB',(160,120),'blue').save(image)
    url='https://flow.google.com/project/bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    Path(str(image)+'.flow-request.json').write_text(json.dumps({'scope':SCOPE,
      'kind':'image','status':'downloaded','project_url':url,'media_sha256':sha(image),
      'reference_hashes':{},'capture_inventory':['exact-image']}))
    class Provider:
        def _ensure(self):return NS(delete_exact_project=lambda *a,**kw:(_ for _ in ()).throw(RuntimeError('No confirmation')))
        def close(self):pass
    original=cleanup.delete_selected
    monkeypatch.setattr(cleanup,'delete_selected',lambda root,rows,lock_held=False:original(root,rows,Provider,lock_held=lock_held))
    preview=preview_deletion(factory,['job:'+job],install=tmp_path)
    with pytest.raises(ValueError,match='local data'):
        delete_selected(factory,preview,delete_flow_projects=True)
    assert folder.exists() and factory.db.get(job)
    assert cleanup.inventory(factory.pm.root)[0]['remote_state']=='uncertain'

# v7.0.41 — Flow project isolation (offline test release)

This incremental patch focuses on reliable Flow project attribution. It is NOT certified against the current live Google Flow UI; test on a copy of your installation and use a test job before production.

## Four project design
- Up to three parallel still-image workers, each with its own existing Flow project binding (`worker-1-project.json`, etc.) and isolated browser profile. Each worker checks the active project URL immediately before requesting an image.
- One distinct Flow motion-video project, recorded in `outputs/<job>/flow_video_project.json`. The video provider attempts to create a genuinely new Flow project on first use; when that fails or Flow still displays the previous project, it stops rather than scanning another project's gallery.
- Storyboard master/reference images may still use the existing per-job `flow_project_url`. That legacy project is not the video project.
- Pending Flow request journals retain their original project URL and continue to control recovery. Never delete journals or manually move media between projects.

## Limitations
- No remote Flow UI integration tests were performed. Flow's project-creation button may behave differently; if so, the video workflow intentionally stops and requires a selector fix.
- Parallel workers do not guarantee a three-fold speed increase; shared account credit/capacity limits, Chrome RAM and UI stability can lower throughput.
- This release guards project identity and prevents cross-project scanning; it does not replace semantic video QC, and does not automatically publish.
- Existing job settings and outputs must be preserved. Back up the installation before patching.

## Test
Run `python3 -m pytest -q tests/test_v741_project_isolation.py tests/test_economy_parallel_frames.py tests/test_v716_frame_batch_recovery.py tests/test_v601_flow_parallel_and_recovery.py tests/test_v739_automatic_recovery.py`.

## Run
Configure `flow_image_workers: 3` for independent image workers, then start a small new job. Do not run jobs simultaneously until worker project identity is verified. Existing pending jobs should first be resumed with their original request journals intact.

# Exact Flow video download recovery — v7.0.61

## What the supplied job shows

For `20261017-152520-stop-wasting-your-life-4e09`, the saved pending request is `flow/shots/shot_008/take_01.mp4.flow-request.json` in project `https://flow.google.com/project/1cc33857-aaaf-4f7f-ac7a-2e20fc6687d3`. The job log reports that the video tile was matched and a `blob:` download event fired three times, but the browser target closed before Playwright produced a valid MP4. The pending journal correctly blocks another generation. Earlier report snapshots show a pre-existing wall-clock video in the same project; do not import that video merely because it is visible.

## Install

Let any currently running job finish or stop it safely, then close Studio and the runner. Extract the corrected r2 ZIP beside your installed `AutoVideoAI-v7`. The updater recognizes the earlier standalone `tools/recover_reviewed_local_video.py` and backs it up before replacing it. From the existing installation:

```bash
cat VERSION
python3 ../AutoVideoAI-v7.0.61-r2/tools/update_v760_to_v761.py . --apply
./dashboard.sh
```

The updater accepts v7.0.60 (or an already installed v7.0.61). Install v7.0.60 first if `cat VERSION` shows v7.0.59; use the intervening updates if older. It changes code only and preserves output videos, saved Flow requests, profiles, settings, approved reviews and the music library.

## Resolve this shot without another Flow generation

Try **Recover proven-new Flow video** once after updating. The download callback now attempts to capture the exact `blob:` bytes immediately, before the Flow tab can close. If Flow still closes the target, use the reviewed local import:

1. Open the saved project above in your normal Chrome, open the actual video for `shot_008`, and verify that it shows the requested action. Copy that video's exact `/project/.../edit/...` URL. The wall-clock video and uploaded opening/closing images are different assets.
2. Download that video manually as an MP4. Ensure it plays completely on your PC.
3. In Studio → Queue → this job → **Recover a visually reviewed video**, paste the exact editor URL, check that it belongs to `shot_008`, upload the MP4, then click **Import reviewed MP4 and run QC**. After a successful QC result, click **Resume saved job**.

CLI equivalent from the upgraded installation:

```bash
python3 tools/recover_reviewed_local_video.py \
  20261017-152520-stop-wasting-your-life-4e09 \
  --shot-id shot_008 \
  --file '/mnt/c/Users/eiyanpr/Downloads/YOUR_REVIEWED_VIDEO.mp4' \
  --asset-url 'https://flow.google.com/project/1cc33857-aaaf-4f7f-ac7a-2e20fc6687d3/edit/YOUR_EXACT_VIDEO_ID' \
  --asset-reviewed
python3 cli.py v3 resume 20261017-152520-stop-wasting-your-life-4e09
```

Replace the two placeholders with the real downloaded file and editor URL. Do not run the sample literally. The importer acquires the job production lock, requires one unresolved video journal, checks the exact project identity, validates the MP4, runs shot QC, records the local file hash and editor URL, and then resolves that journal. A rejected or unrelated MP4 keeps the request pending. It requests no new Flow generation credits.

## Limits

The browser event capture is an additional recovery attempt, not a guarantee that a crashing Flow tab or Chromium process can be kept alive. The local import is the supported way to finish when the browser cannot deliver the exact blob. Human visual review is required to prove that the downloaded video belongs to `shot_008`; file validity and project URL alone cannot prove scene identity. Do not approve another generation for this already submitted request.

Focused offline tests cover immediate event capture, project mismatch rejection, QC rejection, exact journal resolution and repeat-import refusal. Python compilation and a code-only upgrade smoke test passed. A live signed-in Flow download was not available in this environment.

## Video tile readiness in r2

When recovering an exact video from the project grid, the browser waits 15 seconds, then looks for the same recorded asset for up to 15 more seconds before opening its download menu. A changed or missing tile stops recovery without selecting another video. This delay may help Flow finish preparing the download; Chrome target closure can still occur, in which case use reviewed MP4 import.

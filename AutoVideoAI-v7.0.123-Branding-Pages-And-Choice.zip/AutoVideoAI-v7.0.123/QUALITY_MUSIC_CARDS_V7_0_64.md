# v7.0.64 · video review and creation changes

The reviewed 224.5-second, 1080p landscape export has readable pictures but several editorial cards cover speech captions and some cutaways are loosely related to the narration. It is a draft for review, not an automatic publish decision. The audio stream exists, but the supplied file alone does not establish which music was selected. The local-music code path could continue without an asset when narration existed; this release blocks that omission before Flow visuals start.

In Guided Studio, choose **Background music → local**, then select the exact file under **Shared licensed track** (or enter a path). The three OGG files manually copied to `AutoVideoAI-Shared/music_library` appear by filename even if they have no library manifest. Verify the permission for the exact file and destination. Music preflight validates audio and records `audio/music_preflight.json`; the render records `audio/sound_plan.json`. A failed music choice now stops before visuals, with an actionable error. Re-rendering an already completed video requires a separate finishing plan; it does not retroactively modify the old MP4.

Approve a script, then open **Gemini Web text cards · separate reviewed request**. The card request sends text and duration only, uses the selected delete-after-read cleanup policy, and returns editable timing and copy. Check the suggestions and choose **Use these reviewed card suggestions**. Rendering places these transparent cards above the speech caption area and suppresses competing automatic editorial cards. The original generated cards also move above captions. Actual measured speech duration scales reviewed card times proportionally. Keep speech captions set to **None** if you do not want burned transcript text; no transcript upload is required for a generated voiceover.

Select saved language-specific channel profiles during creation. The production language profile supplies this job's channel name and logo. The choices for English, Hindi and Odia editions are recorded in `production/language_editions.json`. The other editions are a Finishing Studio handoff: each translated script, narration and card text still needs review. Intro and outro assets stored in the respective channel profiles are used in Finishing Studio, not inserted automatically into this source master. One source footage master can therefore be reused without spending Flow credits again, but this release does not automatically translate or synthesize all three editions.

The channel name stays at the upper left. If a logo is supplied, its persistent mark sits at the lower right. Watch the preview for collision with source text or platform controls. The export still requires editorial, audio, pronunciation, rights and platform review before publication.

Stop Studio and all active jobs. Extract the ZIP beside the current v7.0.63 folder, then from the current installation run:

```bash
python3 ../AutoVideoAI-v7.0.64/tools/update_v763_to_v764.py . --apply
./dashboard.sh
```

The updater backs up changed code, preserves runtime outputs, and refuses unexpected changes to the files it replaces. The release was verified with a local card render and syntax checks in this environment; full end-to-end Flow and Gemini browser tests require your signed-in WSL session.

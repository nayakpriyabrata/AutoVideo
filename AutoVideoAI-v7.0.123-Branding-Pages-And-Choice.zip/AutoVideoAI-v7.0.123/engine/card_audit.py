"""Would two cards be on screen together? Answer it before spending a render (v7.0.117).

v7.0.116 made an edition draw **one card at a time** - the job's copied cards and the language's own drafted cards
were anchored to the same sentence and used to be drawn on top of each other. That fix only shows in a *new* render,
and an edition render is the expensive part of the whole flow (an hour or two of CPU on the field job). A record
written before 7.0.116 cannot say whether the file on disk has the old overlap, and the listing used to stay silent
about it - silence that reads as "checked, fine".

This module answers the question from the saved job, in seconds, without rendering any video:

* what cards the job has for each language - the copied ``bundle['cards']`` and the edition's own
  ``production/speech_cards.json``;
* which of them would share the screen (with the shared seconds);
* what a render will do about it: which cards are drawn, which are skipped, and why.

It reads files and draws card PNGs into a temporary folder to learn their windows; it never encodes, never writes into
the job, never records anything, never re-records a voice and never spends a Flow credit.
"""
from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path


def _read(path, default=None):
    try:
        path = Path(path)
        if not path.is_file():
            return default
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


def _label(code):
    try:
        from engine.languages import LANGUAGES
        return LANGUAGES[str(code)].label
    except Exception:
        return str(code)


def _plan_geometry(job_root, code):
    """The frame size and card style the last plan for this language used, so the audit matches the render."""
    width, height, style = 1280, 720, 'bold'
    for folder in sorted(Path(job_root, 'language_editions').glob('*/plan.json'), reverse=True):
        plan = _read(folder, {}) or {}
        edition = (plan.get('editions') or {}).get(code)
        if not edition:
            continue
        source = (plan.get('source') or {}).get('width'), (plan.get('source') or {}).get('height')
        if all(isinstance(value, int) and value > 0 for value in source):
            width, height = source
        style = str(edition.get('card_style') or plan.get('card_style') or style)
        break
    return int(width), int(height), style


def _edition_cards(bundle, code, width, height, style, workdir):
    """The windows of the language's own drafted cards, or an explanation of why there are none."""
    from engine import speech_cards
    folder = Path(str(bundle.get('audio') or '')).parent
    cards_file = folder / 'production' / 'speech_cards.json'
    if not cards_file.is_file():
        return [], 'this language has no drafted card file of its own'
    root = Path(workdir) / ('edition-cards-' + str(code))
    (root / 'production').mkdir(parents=True, exist_ok=True)
    shutil.copyfile(cards_file, root / 'production' / 'speech_cards.json')
    try:
        overlays = speech_cards.render(root, Path(str(bundle['audio'])), _read(bundle['words'], []) or [],
                                       str(bundle.get('script') or ''), float(bundle.get('duration') or 0),
                                       width, height, style,
                                       educational=bool(bundle.get('educational')),
                                       topic=str(bundle.get('topic') or ''), language=str(code),
                                       captions=bool(bundle.get('captions_burned', True))) or []
    except Exception as error:      # a stale draft is a real finding, not a crash: report it in words
        first = str(error).strip().splitlines()[0] if str(error).strip() else error.__class__.__name__
        return [], 'its drafted card file could not be read: ' + first[:400]
    return [dict(event) for event in overlays], ''


def audit_language(job_root, code, state, *, workdir=None):
    """One language: both card lists, the collisions, and what a render would draw."""
    from engine.render.card_slots import conflicts, is_card, max_at_once, resolve
    bundles = (state or {}).get('bundles') or {}
    bundle = bundles.get(code)
    result = {'language': code, 'label': _label(code), 'plan_cards': 0, 'edition_cards': 0,
              'conflicts': [], 'dropped': [], 'drawn': 0, 'notes': [], 'message': ''}
    if not bundle:
        result['message'] = _label(code) + ' has no saved narration, so it has no cards to audit yet.'
        return result
    temporary = None
    try:
        temporary = workdir or tempfile.mkdtemp(prefix='card-audit-')
        width, height, style = _plan_geometry(job_root, code)
        overlays, why = _edition_cards(bundle, code, width, height, style, temporary)
        legacy = list(bundle.get('cards') or []) if bundle.get('text_cards', True) else []
        result['plan_cards'] = len(legacy)
        result['edition_cards'] = sum(1 for event in overlays if is_card(event.get('kind')))
        if why:
            result['notes'].append(_label(code) + ': ' + why + '.')
        entries, owners = [], {}
        for index, event in enumerate(overlays):
            if not is_card(event.get('kind')):
                continue
            entry = dict(event)
            entry['source'] = 'the edition card file'
            owners[id(entry)] = ('overlay', index)
            entries.append(entry)
        for card in legacy:
            entry = {'kind': 'keypoint', 'start': card.get('start'), 'end': card.get('end'),
                     'title': card.get('text', ''), 'source': 'the job card copy'}
            owners[id(entry)] = ('legacy', card)
            entries.append(entry)
        if not entries:
            result['message'] = (_label(code) + ' has no text cards saved for this narration, so no two cards can '
                                 'share the screen.')
            return result
        result['conflicts'] = conflicts(entries)
        report = {}
        kept = resolve(entries, report=report)
        result['drawn'] = len(kept)
        result['cards_at_once'] = max_at_once(kept)
        result['dropped'] = list(report.get('dropped') or [])
        worst = max([row.get('shared_seconds') or 0 for row in result['conflicts']] or [0])
        result['worst_overlap_seconds'] = round(float(worst), 3)
        duplicates = sum(1 for row in result['dropped'] if row.get('duplicate'))
        result['duplicates'] = duplicates
        if result['conflicts'] and duplicates == len(result['conflicts']):
            # The field shape: the same sentence drafted twice, once per card source.
            result['message'] = (
                _label(code) + ': the same card is scheduled twice for the same moment (once by the job card '
                'copy, once by the edition card file, ' + f'{worst:.1f}s apart). A render draws it once.')
        elif result['conflicts']:
            pairs = len(result['conflicts'])
            result['message'] = (
                _label(code) + ': ' + str(len(entries)) + ' card window(s) in '
                + str(result['plan_cards']) + ' job card(s) and ' + str(result['edition_cards'])
                + ' edition card(s); ' + (str(pairs) + ' pair(s) would be on screen together'
                                          if pairs > 1 else '1 pair would be on screen together')
                + f" (longest overlap {worst:.1f}s). A render draws {result['drawn']} card(s) and skips "
                + str(len(result['dropped'])) + '.')
        else:
            result['message'] = (_label(code) + ': ' + str(len(entries)) + ' card(s), no two share the screen. '
                                 'A render draws all of them.')
        return result
    finally:
        if workdir is None and temporary:
            shutil.rmtree(temporary, ignore_errors=True)


def audit_job(job_root, *, languages=None):
    """Every selected language's card state, from the saved job. Read-only; seconds, not minutes."""
    job_root = Path(job_root)
    state = _read(job_root / 'production' / 'language_editions.json', {}) or {}
    from engine.language_editions import requested_languages
    source, extra, state_languages = requested_languages(job_root)
    if state_languages is None:
        return {'job': str(job_root), 'status': 'not_requested', 'languages': {}, 'problems': [],
                'message': 'No language editions were selected for this job, so it has no edition cards to audit.'}
    wanted = [code for code in (languages or extra) if code in extra]
    record = _read(job_root / 'production' / 'language_editions_render.json', {}) or {}
    rows, problems = {}, []
    for code in wanted:
        row = audit_language(job_root, code, state_languages)
        entry = (record.get('editions') or {}).get(code) or {}
        row['rule_recorded'] = entry.get('cards_on_screen_at_once') is not None
        row['current_file'] = str(entry.get('path') or '')
        rows[code] = row
        if row.get('conflicts'):
            problems.append(row['message'])
    return {'job': str(job_root), 'status': 'audited', 'source_language': source, 'languages': rows,
            'problems': problems,
            'message': '' if not rows else ('' if problems else
                                            'No two cards share the screen in any selected language.')}


def format_audit(data):
    """Readable lines: what each language has, what overlaps, and what a render will do."""
    lines = []
    if not data.get('languages'):
        return [str(data.get('message') or 'Nothing to audit.')]
    for code, row in data['languages'].items():
        lines.append(row['label'] + ' (' + code + ')')
        lines.append('  job cards: ' + str(row.get('plan_cards', 0)) + ' · edition cards: '
                     + str(row.get('edition_cards', 0)) + ' · drawn by a render: '
                     + str(row.get('drawn', 0)))
        lines.append('  ' + str(row.get('message') or ''))
        for note in row.get('notes') or []:
            lines.append('  note: ' + note)
        for dropped in (row.get('dropped') or [])[:6]:
            text = str(dropped.get('text') or '')[:70]
            shared = (f" ({dropped['would_share_seconds']:.1f}s of overlap)"
                      if dropped.get('would_share_seconds') else '')
            if dropped.get('duplicate'):
                lines.append('  - not drawn twice: "' + text + '" is already drawn once' + shared)
            else:
                lines.append('  - skipped: "' + text + '" because "'
                             + str(dropped.get('kept') or 'another card')[:70] + '" is still showing' + shared)
        if row.get('current_file'):
            lines.append('  current file: ' + row['current_file'] + ' ('
                         + ('rendered with the one-card rule' if row.get('rule_recorded')
                            else 'rendered before 7.0.116 - its card overlap is not recorded') + ')')
    return lines

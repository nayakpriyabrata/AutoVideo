import json
from pathlib import Path
from types import SimpleNamespace
import pytest
from PIL import Image
from engine import flow_image_transaction as tx
from engine.providers.flow_browser import FlowBrowserProvider, FlowRequestPending, FlowBrowser
from engine.flow_resume_safety import check_job

PROJECT = 'https://flow.google.com/project/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'


def picture(path, color):
    Image.new('RGB', (128, 96), color).save(path)
    return str(path)


class Bridge:
    normalize_project_url = staticmethod(FlowBrowser.normalize_project_url)
    _agent_image_instruction = staticmethod(FlowBrowser._agent_image_instruction)
    def __init__(self, refs, generated):
        self.refs = refs; self.generated = generated; self.assets = []
        self.downloads = []; self.sends = 0; self.ack = True; self.matches = True
        self.closed_on = set(); self.fail_on = set(); self.project = PROJECT; self.ui = {}
        self._page = SimpleNamespace(goto=lambda *a, **k: None, wait_for_timeout=lambda ms: None)
    def create_isolated_image_project(self,name): self.assets=[]; self.project=PROJECT
    def current_project_url(self): return self.project
    def ensure_project(self, *a, **k): self.project = k.get('project_url') or PROJECT
    def media_assets(self): return [{'kind': 'image', 'sig': x} for x in self.assets]
    def download_latest_asset(self, path, preferred_signature, **kw):
        self.downloads.append(preferred_signature)
        if preferred_signature in self.fail_on: raise RuntimeError('target closed before save')
        source = self.refs.get(preferred_signature, self.generated)
        Path(path).write_bytes(Path(source).read_bytes())
        if preferred_signature in self.closed_on: raise RuntimeError('target closed after save')
    def detect_editor_mode(self): return 'agent'
    def select_agent_generation_type(self, *a): pass
    def attach_agent_media(self, refs, **kw): self.assets = list(self.refs); return len(refs)
    def _fill_editor_box(self, *a): pass
    def agent_submission_state(self, text): return {'composer_matches': self.matches, 'prompt_occurrences': 0}
    def submit_prepared_text_video(self, mode): self.sends += 1
    def wait_for_submission_ack(self, *a): return self.ack
    def wait_for_agent_generation(self, **kw):
        if self.sends: self.assets = list(self.refs) + ['generated']
        return bool(self.sends)


class Provider:
    def __init__(self, bridge): self.bridge = bridge; self.closes = 0
    def _ensure(self): return self.bridge
    def close(self): self.closes += 1


@pytest.fixture
def case(tmp_path):
    r1 = picture(tmp_path/'master1.jpg', 'red'); r2 = picture(tmp_path/'master2.jpg', 'blue')
    generated = picture(tmp_path/'scene.jpg', 'green')
    output = tmp_path/'frame.jpg'
    bridge = Bridge({'r1': r1, 'r2': r2}, generated)
    request = {'scope': tx.SCOPE, 'status': 'pending', 'kind': 'image', 'project_url': PROJECT,
        'reference_hashes': {r: tx.sha(r) for r in (r1, r2)}, 'baseline': ['old-r1','old-r2'], 'signature': ''}
    return output, bridge, request


def test_reference_uploads_are_never_results(case):
    output, b, r = case; b.assets = ['r1','r2']
    with pytest.raises(RuntimeError, match='No unique non-reference'): tx.capture(Provider(b), b, r, output, list(b.refs.values()))
    assert not output.exists()


def test_save_then_browser_close_commits(case):
    output,b,r=case; b.assets=['generated','r1','r2']; b.closed_on={'generated','r1','r2'}
    tx.capture(Provider(b),b,r,output,list(b.refs.values()))
    assert tx.completed(output,r); assert output.read_bytes()==Path(b.generated).read_bytes()


def test_partial_inventory_does_not_redownload_saved_candidate(case):
    output,b,r=case; b.assets=['generated','r1','r2']; b.fail_on={'r1'}
    with pytest.raises(RuntimeError): tx.capture(Provider(b),b,r,output,list(b.refs.values()))
    r=json.loads(tx.journal_path(output).read_text()); b.fail_on.clear()
    tx.capture(Provider(b),b,r,output,list(b.refs.values()))
    assert b.downloads.count('generated')==1; assert tx.completed(output,r)


def test_ambiguous_extra_image_blocks(case):
    output,b,r=case; b.assets=['r1','r2','generated','other']
    with pytest.raises(RuntimeError,match='extra images'): tx.capture(Provider(b),b,r,output,list(b.refs.values()))
    assert b.downloads==[]


def test_wrong_project_blocks(case):
    output,b,r=case; b.project=PROJECT.replace('a','b')
    with pytest.raises(RuntimeError,match='project changed'): tx.capture(Provider(b),b,r,output,list(b.refs.values()))


def test_modified_master_blocks(case):
    output,b,r=case; picture(Path(next(iter(b.refs.values()))),'yellow')
    with pytest.raises(RuntimeError,match='reference changed'): tx.capture(Provider(b),b,r,output,list(b.refs.values()))


def test_modified_probe_blocks(case):
    output,b,r=case; b.assets=['generated','r1','r2']; b.fail_on={'r1'}
    with pytest.raises(RuntimeError): tx.capture(Provider(b),b,r,output,list(b.refs.values()))
    probe=next(e for e in r['capture_probes'].values() if e['signature']=='generated')
    picture(output.parent/probe['file'],'yellow'); b.fail_on.clear()
    with pytest.raises(RuntimeError,match='checksum changed'): tx.capture(Provider(b),b,r,output,list(b.refs.values()))


def test_successful_generation_and_resume_never_resend(case):
    output,b,r=case; p=Provider(b)
    compiled={'prompt':'Little Kanha dancing', 'reference_paths':list(b.refs.values())}
    first=tx.generate(p,SimpleNamespace(shot_id='shot_001'),compiled,output,False,'hash')
    second=tx.generate(p,SimpleNamespace(shot_id='shot_001'),compiled,output,False,'hash')
    assert first['path']==second['path']; assert b.sends==1
    saved=json.loads(tx.journal_path(output).read_text()); assert saved['submission_acknowledged']


def test_no_acknowledgement_is_uncertain_not_resubmitted(case):
    output,b,r=case; b.ack=False; p=Provider(b)
    compiled={'prompt':'Kanha', 'reference_paths':list(b.refs.values())}
    result = tx.generate(p,SimpleNamespace(shot_id='shot_001'),compiled,output,False,'hash')
    assert result['path'] == str(output) and tx.image_valid(output)
    request=json.loads(tx.journal_path(output).read_text()); assert request['phase']=='submission_uncertain'
    b.assets=list(b.refs)+['generated']
    tx.generate(p,SimpleNamespace(shot_id='shot_001'),compiled,output,False,'hash')
    assert b.sends==1


def test_unfilled_composer_does_not_send(case):
    output,b,r=case; b.matches=False
    with pytest.raises(FlowRequestPending,match='complete prompt'): tx.generate(Provider(b),SimpleNamespace(shot_id='shot_001'),{'prompt':'Kanha'},output,False,'hash')
    assert b.sends==0
    assert json.loads(tx.journal_path(output).read_text())['phase']=='preparing'


def test_gate_rejects_missing_committed_bytes(case):
    output,b,r=case; b.assets=['generated','r1','r2']
    tx.capture(Provider(b),b,r,output,list(b.refs.values()))
    (output.parent/'production_manifest.json').write_text('{}')
    assert check_job(output.parent)['safe_to_generate']
    output.unlink(); assert not check_job(output.parent)['safe_to_generate']


def test_resume_reconciles_without_submit(case):
    output,b,r=case; b.assets=['r1','r2','generated']; r.update(source_prompt='Kanha',shot_id='shot_001',vertical=False,request_hash='hash',phase='submitted')
    tx.write_json(tx.journal_path(output),r); (output.parent/'production_manifest.json').write_text('{}')
    from engine.flow_resume_recovery import reconcile_job
    result=reconcile_job(output.parent, provider_factory=lambda:Provider(b))
    assert result['safe_to_generate']; assert b.sends==0


def test_actual_provider_routes_new_request_to_transaction(case,monkeypatch):
    output,b,r=case; provider=FlowBrowserProvider.__new__(FlowBrowserProvider)
    called=[]
    monkeypatch.setattr(tx,'generate',lambda *args: called.append(args) or {'path':str(output)})
    provider._guarded_generation_once(SimpleNamespace(shot_id='shot_001'),{'prompt':'Kanha'},None,str(output),False,False,'image')
    assert len(called)==1


def test_submission_ack_requires_new_conversation_occurrence():
    b=FlowBrowser.__new__(FlowBrowser)
    b._page=SimpleNamespace(wait_for_timeout=lambda ms:None)
    b.agent_submission_state=lambda prompt:{'prompt_occurrences':2}
    assert b.wait_for_submission_ack('prompt',{'prompt_occurrences':1}, timeout_s=.01)
    assert not b.wait_for_submission_ack('prompt',{'prompt_occurrences':2}, timeout_s=.001)


def test_transaction_retry_budget_is_not_multiplied(tmp_path, monkeypatch):
    p=FlowBrowserProvider.__new__(FlowBrowserProvider); calls=[]
    def fail(*a, **kw):
        calls.append(1); raise FlowRequestPending('recover exhausted')
    monkeypatch.setattr(p,'_guarded_generation_once',fail)
    with pytest.raises(FlowRequestPending):
        p._guarded_generation(SimpleNamespace(shot_id='s'),{},None,str(tmp_path/'frame.jpg'),False,False,'image')
    assert len(calls)==1


def test_replacement_commit_unblocks_gate(tmp_path, monkeypatch):
    from engine.flow_image_replacement import replace_image
    import hashlib
    root=tmp_path; (root/'production_manifest.json').write_text('{}')
    output=str(root/'frame.jpg'); prompt='Kanha'; shot=SimpleNamespace(shot_id='s')
    key=hashlib.sha256(json.dumps(['image','s',prompt,False],sort_keys=True).encode()).hexdigest()
    request={'kind':'image','request_hash':key,'project_url':PROJECT,'status':'pending','scope':tx.SCOPE}
    tx.write_json(output+'.flow-request.json',request)
    class P:
        calls=0
        def _guarded_generation_once(self,shot,compiled,refs,path,vertical,dry,kind):
            self.calls+=1
            assert compiled['project_url']=='' or self.calls>1
            picture(Path(path),'green')
            tx.write_json(path+'.flow-request.json',{'kind':'image','scope':tx.SCOPE,'status':'downloaded','media_sha256':tx.sha(path)})
            return {'path':path,'project_url':PROJECT}
        def _asset_valid(self,path,kind):return tx.image_valid(path)
    p=P(); compiled={'prompt':prompt,'flow_replace_unresolved_images':True,'flow_image_replacement_root':str(root),'flow_image_replacement_limit':1}
    replace_image(p,shot,compiled,output,False,pending_error=RuntimeError('no acknowledgement'))
    assert check_job(root)['safe_to_generate']
    assert json.loads(Path(output+'.flow-request.json').read_text())['status']=='superseded_by_authorized_replacement'


def test_permission_off_does_not_create_replacement(tmp_path):
    from engine.flow_image_replacement import replace_image
    import hashlib
    output=str(tmp_path/'frame.jpg'); key=hashlib.sha256(json.dumps(['image','s','p',False],sort_keys=True).encode()).hexdigest()
    tx.write_json(output+'.flow-request.json',{'kind':'image','request_hash':key,'project_url':PROJECT})
    with pytest.raises(FlowRequestPending,match='permission'):
        replace_image(None,SimpleNamespace(shot_id='s'),{'prompt':'p'},output,False,pending_error=RuntimeError())
    assert not Path(output+'.image-replacement.json').exists()


def test_saved_replacement_child_finishes_parent_offline(tmp_path):
    from engine.flow_image_replacement import finish_saved_replacement
    parent=tmp_path/'frame.jpg'; child=tmp_path/'frame.jpg.replacement-01.jpg'
    (tmp_path/'production_manifest.json').write_text('{}')
    picture(child,'green')
    tx.write_json(str(parent)+'.flow-request.json',{'kind':'image','status':'pending','request_hash':'hash','project_url':PROJECT})
    tx.write_json(str(child)+'.flow-request.json',{'kind':'image','status':'downloaded','request_hash':'hash','media_sha256':tx.sha(child)})
    reservation=Path(str(parent)+'.image-replacement.json')
    tx.write_json(reservation,{'original_request_hash':'hash','original_project_url':PROJECT})
    assert finish_saved_replacement(tmp_path,reservation)
    assert parent.read_bytes()==child.read_bytes(); assert check_job(tmp_path)['safe_to_generate']
    assert finish_saved_replacement(tmp_path,reservation)


def test_combined_legacy_and_new_replacement_cap(tmp_path):
    from engine.flow_image_replacement import replace_image
    import hashlib
    output=str(tmp_path/'frame.jpg'); key=hashlib.sha256(json.dumps(['image','s','p',False],sort_keys=True).encode()).hexdigest()
    tx.write_json(output+'.flow-request.json',{'kind':'image','request_hash':key,'project_url':PROJECT})
    tx.write_json(tmp_path/'authorized_frame_replacements/ledger.json',{'frames':{'old-frame':{}}})
    cfg={'prompt':'p','flow_replace_unresolved_images':True,'flow_image_replacement_limit':1,'flow_image_replacement_root':str(tmp_path)}
    with pytest.raises(FlowRequestPending,match='cap'):
        replace_image(None,SimpleNamespace(shot_id='s'),cfg,output,False,pending_error=RuntimeError())


def test_completed_candidate_inventory_recovers_offline(case,monkeypatch):
    output,b,r=case; b.assets=['generated','r1','r2']
    original=tx.commit_capture
    monkeypatch.setattr(tx,'commit_capture',lambda *a: (_ for _ in ()).throw(OSError('process lost before commit')))
    with pytest.raises(OSError): tx.capture(Provider(b),b,r,output,list(b.refs.values()))
    monkeypatch.setattr(tx,'commit_capture',original)
    p=Provider(b)
    p._ensure=lambda:pytest.fail('Complete local inventory must not open the browser')
    tx.recover(p,r,output)
    assert tx.completed(output,r)


def test_explicit_new_project_never_reuses_existing_composer():
    b=FlowBrowser.__new__(FlowBrowser); events=[]
    b.ui={}; b._project_url=PROJECT
    b._page=SimpleNamespace(goto=lambda *a,**kw: events.append('home'))
    b.current_project_url=lambda: b._project_url or ''
    b.dismiss_onboarding=lambda **kw:None
    b.create_project=lambda name: (events.append('new'),setattr(b,'_project_url',PROJECT.replace('aaaa','bbbb')))
    b._composer_visible=lambda timeout:True
    url=b.create_isolated_image_project('frame')
    assert events==['home','new']; assert url!=PROJECT

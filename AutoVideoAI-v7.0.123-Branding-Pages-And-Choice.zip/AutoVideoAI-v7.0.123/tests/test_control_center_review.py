"""Regression cases found while reviewing the v7 control-center integration."""
import json
import pytest
from engine.studio_config import load_video_config
from engine.content_plan import validate_plan
from engine.publishing import _clean_metadata_text, _normalize_source_urls


@pytest.mark.parametrize('field,value', [
    ('duration', 10.5), ('duration', True), ('flow_image_workers', 0),
    ('flow_image_workers', 1.5), ('max_credits', -1), ('max_retries', -1),
    ('flow_capacity_retries', -1), ('flow_scenes', -1),
    ('flow_video_recovery_wait_seconds', -1), ('video_share', float('nan')),
    ('stock_share', 2), ('shot_max_seconds', float('inf')),
    ('plan_only', 'false'), ('flow_reuse_project_media', 'false'),
])
def test_invalid_settings_fail_before_job_creation(tmp_path, field, value):
    path = tmp_path / 'job.json'
    path.write_text(json.dumps({'topic': 'Reviewed job', field: value}))
    with pytest.raises(ValueError, match=field):
        load_video_config(str(path))


def test_unsupported_odia_voice_fails_early_but_import_and_silent_are_valid(tmp_path):
    path = tmp_path / 'job.json'
    config = {'topic': 'Native story', 'language': 'or', 'tts_provider': 'edge'}
    path.write_text(json.dumps(config))
    with pytest.raises(ValueError, match='Odia'):
        load_video_config(str(path))
    for extra in ({'voiceover_enabled': False}, {'narration_input_path': 'voice.wav'}):
        path.write_text(json.dumps({**config, **extra}))
        assert load_video_config(str(path))['language'] == 'or'


@pytest.mark.parametrize('rights', [None, [], 'own_content'])
def test_malformed_plan_rights_give_actionable_error(rights):
    with pytest.raises(ValueError, match='rights'):
        validate_plan({'approved': True, 'rights': rights})


def test_upload_metadata_preserves_carriage_return_line_breaks():
    assert _clean_metadata_text('First\rSecond\r\nThird', 100, multiline=True) == 'First\nSecond\nThird'


def test_source_urls_preserve_case_sensitive_paths():
    assert _normalize_source_urls(['https://example.com/Garden', 'https://example.com/garden']) == [
        'https://example.com/Garden', 'https://example.com/garden']


def test_zero_capacity_limits_reach_parallel_flow_provider(tmp_path, monkeypatch):
    from pathlib import Path
    from types import SimpleNamespace as NS
    from engine.factory import Factory
    from engine.project.manifest import Shot
    import engine.providers.flow_browser as flow
    import engine.qc.video_qc as qc
    seen = []
    class Provider:
        def __init__(self, **kwargs): pass
        def _ensure(self):
            return NS(ensure_project=lambda *a, **k: None,
                      current_project_url=lambda: 'https://flow.google.com/project/test')
        def generate_image(self, shot, compiled, out, vertical, **kwargs):
            seen.append(compiled)
            Path(out).write_bytes(b'fake test image')
            return {'path': out}
        def close(self): pass
    monkeypatch.setattr(flow, 'FlowBrowserProvider', Provider)
    monkeypatch.setattr(flow, 'PROFILE_DIR', str(tmp_path / 'profile'))
    monkeypatch.setattr(qc, 'score_image', lambda path: {'overall': 1})
    f = Factory(outputs=str(tmp_path / 'outputs'), db_path=str(tmp_path / 'jobs.db'))
    job = f.create_job('zero limits', profile='FLOW_ECONOMY', images_per_shot=1)
    m = f.pm.load_manifest(job)
    m.shots = [Shot(shot_id='shot_001', compiled_prompt='one original image')]
    f.pm.save_manifest(m)
    f._is_valid_image_file = lambda path: Path(path).is_file()
    f._generate_scene_images_parallel(m, f.pm.dirs(job), NS(add=lambda *a: None),
        True, 1, lambda *a: None, {'flow_capacity_wait_seconds': 0,
        'flow_capacity_retries': 0}, 1)
    assert seen and all(c['flow_capacity_wait_seconds'] == c['flow_capacity_retries'] == 0 for c in seen)


def test_mini_recovery_preserves_reviewed_limits(tmp_path, monkeypatch):
    from pathlib import Path
    from engine import mini_reels as reels
    from engine.providers.flow_browser import FlowRequestPending
    brief = {'title': 'Garden', 'video_prompt': 'A tiny garden wakes up', 'prompt_provider': 'gemini-web'}
    seen = []
    class Provider:
        def generate(self, shot, compiled, refs, out, vertical, dry_run):
            seen.append(compiled)
            Path(str(out) + '.flow-request.json').write_text(json.dumps({'status': 'pending'}))
            raise FlowRequestPending('Saved request pending')
        def close(self): pass
    monkeypatch.setattr(reels, 'FlowBrowserProvider', Provider)
    rid = 'reviewed-reel-12345'
    kwargs = {'max_generation_credits': 4, 'flow_capacity_wait_seconds': 0,
              'flow_capacity_retries': 0, 'flow_video_recovery_wait_seconds': 5}
    with pytest.raises(FlowRequestPending):
        reels.generate_flow_reel(rid, brief=brief, flow_prompt='Reviewed original prompt',
            output_root=str(tmp_path), **kwargs)
    with pytest.raises(FlowRequestPending):
        reels.recover_flow_reel(rid, output_root=str(tmp_path))
    assert len(seen) == 2
    for compiled in seen:
        assert {key: compiled[key] for key in kwargs} == kwargs


def test_adapter_brief_never_calls_flow_and_keeps_chat(monkeypatch):
    import os
    from engine import mini_reels as reels
    from tools.control_center_adapter import execute
    calls = []
    monkeypatch.setattr(reels, 'generate_prompt_brief', lambda idea, **kw: calls.append('gemini') or {'video_prompt': 'Original scene'})
    monkeypatch.setattr(reels, 'compose_flow_prompt', lambda *a, **kw: 'Editable original Flow prompt')
    monkeypatch.setattr(reels, 'generate_flow_reel', lambda *a, **kw: pytest.fail('Brief must not submit Flow'))
    monkeypatch.setenv('AUTOVIDEO_GEMINI_CHAT_CLEANUP', 'delete-after-read')
    result = execute('mini-brief', {'config': {'idea': 'Garden', 'visual_style': 'miniature-diorama',
        'language': 'en', 'audio_mode': 'silent', 'category': 'general', 'model': 'veo_fast'}})
    assert calls == ['gemini'] and result['flow_prompt'] == 'Editable original Flow prompt'
    assert os.environ['AUTOVIDEO_GEMINI_CHAT_CLEANUP'] == 'keep'

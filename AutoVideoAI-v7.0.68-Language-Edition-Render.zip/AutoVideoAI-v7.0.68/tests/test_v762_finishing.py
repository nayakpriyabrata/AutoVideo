"""A real FFmpeg export and the review and no-overwrite guards."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import pytest

spec = importlib.util.spec_from_file_location('finishing', Path(__file__).parents[1]/'engine'/'finishing_studio.py')
finish = importlib.util.module_from_spec(spec);spec.loader.exec_module(finish)


def test_multilingual_finishing_export(tmp_path):
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        pytest.skip('FFmpeg required')
    source=tmp_path/'source.mp4'
    subprocess.run(['ffmpeg','-y','-loglevel','error','-f','lavfi','-i','color=c=blue:s=640x360:r=30',
                    '-f','lavfi','-i','sine=frequency=440','-t','2','-c:v','libx264','-threads','2','-c:a','aac',str(source)],check=True)
    profile=finish.save_profile('Example',root=tmp_path/'profiles')
    plan=finish.create_plan(source,profile,languages=['en','hi'],output_root=tmp_path/'outputs')
    with pytest.raises(ValueError, match='Review'):
        finish.render(plan,'en')
    finish.set_edition(plan,'en',cards=[],reviewed=True)
    result=finish.render(plan,'en')
    assert result.is_file() and json.loads(result.with_suffix('.provenance.json').read_text())['output_sha256']==finish._hash(result)
    with pytest.raises(ValueError, match='needs review'):
        finish.render(plan,'hi')
    with pytest.raises(FileExistsError):
        finish.render(plan,'en')
    source.write_bytes(b'not a video')
    assert result.is_file()  # the finished export and copied original survive source changes

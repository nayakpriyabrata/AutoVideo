import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest


@pytest.mark.parametrize('launch_succeeds', [True, False])
def test_media_browser_uses_shared_launcher_and_releases_manager(monkeypatch, tmp_path, launch_succeeds):
    import sys
    from engine.providers import web_media_helper as media, flow_browser
    events = []
    page = NS(on=lambda *a: None, goto=lambda *a, **kw: None,
              wait_for_timeout=lambda *a: None)
    context = NS(pages=[page], close=lambda: events.append('context closed'))
    manager = NS(start=lambda: NS(), stop=lambda: events.append('manager stopped'))
    monkeypatch.setitem(sys.modules, 'playwright.sync_api', NS(sync_playwright=lambda: manager))
    class Launcher:
        def __init__(self, **kw):
            self._ctx = None
            self.bcfg = {}
        def _launch_options(self):
            return [{'mode': 'first'}, {'mode': 'fallback'}]
        def _launch_persistent(self, option):
            events.append(option['mode'])
            if option['mode'] == 'first' or not launch_succeeds:
                raise RuntimeError('launch fixture failure')
            self._ctx = context
    monkeypatch.setattr(flow_browser, 'FlowBrowser', Launcher)
    monkeypatch.setattr(media.os.path, 'expanduser', lambda *a: str(tmp_path/'profile'))
    monkeypatch.setattr(media, '_music_result_pages', lambda *a, **kw: [])
    with pytest.raises(media.MediaSearchError):
        media.run('music', 'soft instrumental', str(tmp_path/'music.mp3'))
    assert events[:2] == ['first', 'fallback']
    assert events[-1] == 'manager stopped'
    assert ('context closed' in events) is launch_succeeds


def clip_fixture(monkeypatch, tmp_path):
    import engine.clipping as c
    from engine.render import captions_ass, ffmpeg_renderer
    source = tmp_path / 'original.mp4'
    source.write_bytes(b'source')
    rows = [{'start': i*30., 'end': i*30.+25, 'duration': 25,
             'title': f'Useful lesson number {i}', 'score': 85, 'text': 'Learn a useful lesson.'}
            for i in range(3)]
    monkeypatch.setattr(c, 'resolve_input', lambda *a, **kw: str(source))
    monkeypatch.setattr(c, '_duration', lambda *a: 100)
    monkeypatch.setattr(c, '_transcribe_in_chunks', lambda *a, **kw: [
        {'start': i, 'end': i+.5, 'word': 'lesson'} for i in range(100)])
    monkeypatch.setattr(c, 'rank_highlights', lambda *a, **kw: rows)
    monkeypatch.setattr(c, '_face_crop_x', lambda *a: .5)
    monkeypatch.setattr(captions_ass, 'build_captions', lambda *a, **kw: {'ass': str(tmp_path/'cap.ass')})
    calls = []
    def render(cmd, *a, **kw):
        calls.append(cmd)
        Path(cmd[-1]).write_bytes(b'encoded')
        return NS(returncode=0)
    monkeypatch.setattr(ffmpeg_renderer, '_run_ffmpeg_progress', render)
    monkeypatch.setattr(c, '_clip_qc_report', lambda *a, **kw: {'decision': 'PASS', 'quality_score': 85})
    return c, calls


def test_batch_continues_after_block_and_persists_results(monkeypatch, tmp_path):
    c, calls = clip_fixture(monkeypatch, tmp_path)
    results = iter([{'decision': 'BLOCK', 'quality_score': 40, 'blocking_issues': ['motion_ok']},
                    {'decision': 'PASS', 'quality_score': 85}, {'decision': 'PASS', 'quality_score': 85}])
    monkeypatch.setattr(c, '_clip_qc_report', lambda *a, **kw: next(results))
    report = c.create_highlight_clips('https://instagram.com/reel/example', str(tmp_path/'clips'),
        count=3, source_rights='own_content', ranking_provider='local')
    assert len(calls) == 3 and len(report['outputs']) == 2
    assert len(report['blocked_outputs']) == 1 and report['partial_result']
    saved = json.loads((tmp_path/'clips/highlights.partial.json').read_text())
    assert saved['completed_count'] == 3 and saved['outputs'] == report['outputs']


def test_batch_continues_after_render_error(monkeypatch, tmp_path):
    c, calls = clip_fixture(monkeypatch, tmp_path)
    from engine.render import ffmpeg_renderer
    original = ffmpeg_renderer._run_ffmpeg_progress
    def render(cmd, *a, **kw):
        if '-ss' in cmd and cmd[cmd.index('-ss')+1] == '0.0':
            raise RuntimeError('fixture encoding failure')
        return original(cmd, *a, **kw)
    monkeypatch.setattr(ffmpeg_renderer, '_run_ffmpeg_progress', render)
    report = c.create_highlight_clips('source', str(tmp_path/'clips'), count=3,
                                    source_rights='own_content', ranking_provider='local')
    assert len(report['errors']) == 1 and len(report['outputs']) == 2


def test_optional_music_failure_is_explicit_and_preserves_audio(monkeypatch, tmp_path):
    c, calls = clip_fixture(monkeypatch, tmp_path)
    from engine.audio import music_provider
    monkeypatch.setattr(music_provider, 'ensure_background_music', lambda *a, **kw:
                        {'path': None, 'error': 'browser_launch_failed'})
    report = c.create_highlight_clips('source', str(tmp_path/'clips'), count=3,
        source_rights='own_content', ranking_provider='local', background_music_enabled=True,
        music_failure_policy='continue-original')
    assert not report['music']['enabled'] and report['music']['warning'] == 'browser_launch_failed'
    assert all('0:a?' in cmd and '-stream_loop' not in cmd for cmd in calls)
    with pytest.raises(RuntimeError, match='music'):
        c.create_highlight_clips('source', str(tmp_path/'stop'), source_rights='own_content',
            background_music_enabled=True, music_failure_policy='stop')


@pytest.mark.parametrize('source_static,aligned', [(True, True),(False, True),(True, False)])
def test_source_static_review_never_hides_render_only_freeze(monkeypatch, tmp_path, source_static, aligned):
    import engine.clipping as c
    from engine.render import ffmpeg_renderer as r
    video = tmp_path/'out.mp4';video.write_bytes(b'x'*4096)
    probe = {'format': {'duration': 30}, 'streams': [
        {'codec_type':'video','codec_name':'h264','width':1080,'height':1920},
        {'codec_type':'audio','codec_name':'aac'}]}
    monkeypatch.setattr(c, '_run', lambda cmd, **kw: NS(returncode=0, stdout=json.dumps(probe) if cmd[0]=='ffprobe' else '', stderr=''))
    monkeypatch.setattr(r, '_black_duration_ratio', lambda *a, **kw: 0)
    def freeze(path, duration, **kw):
        if path == 'source':
            return {'ratio': .4 if source_static else 0, 'longest': 12 if source_static else 0,
                    'intervals': [[0,12]] if aligned else [[15,27]]}
        return {'ratio': .4, 'longest': 12, 'intervals': [[0,12]]}
    monkeypatch.setattr(r, '_freeze_metrics', freeze)
    qc = c._clip_qc_report(str(video), 30, 85, 80, source_path='source', source_start=45)
    assert not qc['ready_to_publish']
    assert qc['decision'] == ('REVIEW' if source_static and aligned else 'BLOCK')


def test_music_cache_checks_hash_and_invalidates_after_file_change(monkeypatch,tmp_path):
    from engine.audio import job_music, music_provider
    from engine.audio.hooks import synthesize
    track = tmp_path/'licensed.wav';synthesize(track, 'soft')
    calls=[]
    def search(*a, **kw):
        calls.append(kw)
        return {'path': str(track), 'source': 'fixture'}
    monkeypatch.setattr(music_provider,'ensure_background_music',search)
    job_music.obtain_job_music(tmp_path,'auto','ambient')
    job_music.obtain_job_music(tmp_path,'auto','ambient')
    assert len(calls)==1
    synthesize(track, 'cinematic')
    job_music.obtain_job_music(tmp_path,'auto','ambient')
    assert len(calls)==2


def test_gemini_failed_start_does_not_poison_shared_session(monkeypatch):
    from engine.providers import gemini_web as g
    monkeypatch.setattr(g,'_SESSION',None)
    candidates=[]
    class Browser:
        def __init__(self): candidates.append(self);self.closed=False
        def ensure_session(self,**kw): raise RuntimeError('launcher failed')
        def close(self): self.closed=True
    monkeypatch.setattr(g,'GeminiWebBrowser',Browser)
    with pytest.raises(RuntimeError,match='launcher failed'):g.get_shared_session()
    assert g._SESSION is None and candidates[0].closed


def test_gemini_adapter_releases_session_on_response_and_error(monkeypatch):
    from engine.providers import gemini_web as g
    closed=[]
    monkeypatch.setattr(g,'close_shared_session',lambda:closed.append(True))
    monkeypatch.setattr(g,'get_shared_session',lambda:NS(ask=lambda *a,**kw:'{"ok":true}'))
    assert g.gemini_web_generate('system','task')=='{"ok":true}'
    def failure(*a,**kw):raise RuntimeError('composer unavailable')
    monkeypatch.setattr(g,'get_shared_session',lambda:NS(ask=failure))
    with pytest.raises(RuntimeError):g.gemini_web_generate('system','task')
    assert len(closed)==2


def test_non_youtube_urls_do_not_go_to_youtube_gemini_analysis(monkeypatch,tmp_path):
    c,calls=clip_fixture(monkeypatch,tmp_path)
    monkeypatch.setattr(c,'_gemini_youtube_candidates',lambda *a,**kw:pytest.fail('wrong provider'))
    monkeypatch.setattr(c,'_gemini_web_youtube_candidates',lambda *a,**kw:pytest.fail('wrong provider'))
    report=c.create_highlight_clips('https://facebook.com/watch/?v=example',str(tmp_path/'clips'),
        count=3,source_rights='own_content',ranking_provider='gemini-hybrid')
    assert len(report['outputs'])==3 and 'Non-YouTube source' in report['ranking_fallback_reason']


def test_cartoon_and_identity_scenes_are_not_stock_eligible():
    from engine.planning.economy_storyboard import stock_eligible
    assert not stock_eligible(NS(subject='CHARACTER_01',compiled_prompt='',visual_goal='',lighting=''))
    assert not stock_eligible(NS(subject='kid',compiled_prompt='animated-film lighting',visual_goal='',lighting=''))
    assert stock_eligible(NS(subject='trees',compiled_prompt='forest aerial',visual_goal='nature',lighting='daylight'))


def test_storyboard_repair_requires_review_and_preserves_accepted_takes():
    from engine.factory import Factory
    factory=Factory.__new__(Factory)
    factory.pm=NS(load_manifest=lambda job:NS(shots=[NS(shot_id='shot_010',accepted_take='accepted.mp4')]))
    with pytest.raises(ValueError,match='Review'):factory.repair_storyboard_shot('job','shot_010')
    with pytest.raises(ValueError,match='accepted takes'):factory.repair_storyboard_shot('job','shot_010',reviewed=True)

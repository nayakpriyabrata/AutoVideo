"""Channel name and logo decisions for the Create form.

Channel profiles chosen in Language editions are the source of truth. The
Create form asks for a name or logo only for the editions that still have no
profile, and saves those entries as profiles when the production is created.
"""


def branding_plan(editions, profiles, primary):
    """Which editions still need a channel name and logo in the Create form.

    ``editions`` lists every selected edition (primary included); ``profiles``
    maps edition codes to chosen profile paths.
    """
    selected = list(editions) or [primary]
    missing = [edition for edition in selected if edition not in profiles]
    return {
        'complete': not missing,
        'primary_missing': primary in missing,
        'inline': [edition for edition in missing if edition != primary],
    }


def save_missing_profiles(entries, save_profile, upload_media):
    """Save one profile per edition that was given a name; return {edition: path}.

    ``entries`` maps edition -> (name, uploaded_logo_or_None). An edition left
    without a name gets no profile and renders with no channel mark.
    """
    saved = {}
    for edition, (name, logo) in entries.items():
        name = str(name or '').strip()
        if not name:
            continue
        logo_path = upload_media(logo, 'logo')
        saved[edition] = str(save_profile(name, names={edition: name}, logo=logo_path))
    return saved

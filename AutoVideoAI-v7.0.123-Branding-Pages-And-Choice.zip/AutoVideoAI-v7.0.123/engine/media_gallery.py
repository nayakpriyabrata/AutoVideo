"""Discover saved exports and delete only explicitly reviewed output files."""
from pathlib import Path
import hashlib
import json
from .production import digest
from .production_lock import acquire, release


def _real_file(path):
    path=Path(path).absolute()
    return path.is_file() and not any(p.is_symlink() for p in [path,*path.parents])


def gallery_items(factory, jobs, clips):
    groups={'Clips':[], 'Long-form videos':[], 'Short-form videos':[]}
    seen=set()
    def add(group,path,label,state='saved',job_id=None):
        path=Path(path).absolute()
        if not _real_file(path):return
        path=path.resolve()
        if str(path) in seen:return
        seen.add(str(path))
        groups[group].append({'path':str(path),'label':label,'state':state,'job_id':job_id})
    for clip in clips:
        add('Clips',clip['path'],clip.get('label') or Path(clip['path']).stem,clip.get('state','saved'))
    # Read the real job folders too: migrated DB final_path values can be stale.
    indexed={j['job_id']:j for j in jobs}
    for manifest in Path(factory.pm.root).glob('*/production_manifest.json'):
        indexed.setdefault(manifest.parent.name,{'job_id':manifest.parent.name})
    for job in indexed.values():
        try: manifest=factory.pm.load_manifest(job['job_id'])
        except (OSError,ValueError):continue
        group='Short-form videos' if manifest.aspect=='9:16' else 'Long-form videos'
        folder=Path(factory.pm.job_dir(job['job_id']))/'render'
        paths=([Path(job['final_path'])] if job.get('final_path') else [])+sorted(folder.glob('*-final*.mp4'))
        for path in paths:
            # Exports must belong to this job; never adopt an unrelated old path.
            if path.absolute().parent!=folder.absolute():continue
            add(group,path,job.get('topic') or manifest.topic,job.get('status') or manifest.status,job['job_id'])
    for metadata in Path(factory.pm.root).glob('**/mini_reel.json'):
        try: record=json.loads(metadata.read_text())
        except (OSError,ValueError):continue
        for video in sorted(metadata.parent.glob('mini-reel*.mp4')):
            add('Short-form videos',video,record.get('topic') or video.parent.name,record.get('status','saved'))
    return groups


def deletion_preview(item):
    path=Path(item['path'])
    if not _real_file(path):raise ValueError('This export is missing or is a linked file. Refresh Gallery.')
    return {**item,'sha256':digest(path),'bytes':path.stat().st_size}


def delete_export(factory, preview, jobs, clips, allowed_roots):
    """Recheck inventory, roots, locks, references and bytes before unlinking one export."""
    path=Path(preview['path']).absolute()
    inventory=[item for rows in gallery_items(factory,jobs,clips).values() for item in rows]
    item=next((i for i in inventory if i['path']==str(path)),None)
    if item is None or not any(path.is_relative_to(Path(r).resolve()) for r in allowed_roots):
        raise ValueError('File is outside the selected gallery output folders; nothing deleted')
    service=Path.home()/'.local/share/autovideoai';service.mkdir(parents=True,exist_ok=True)
    from contextlib import ExitStack
    with ExitStack() as stack:
        lock=stack.enter_context((service/'production.lock').open('a+b'))
        try:acquire(lock,blocking=False)
        except BlockingIOError:raise ValueError('Production is active. Wait before deleting an export.')
        job_lock=None
        try:
            if item.get('job_id'):
                job_lock=stack.enter_context((Path(factory.pm.job_dir(item['job_id']))/'.production.lock').open('a+b'))
                try:acquire(job_lock,blocking=False)
                except BlockingIOError:
                    job_lock=None
                    raise ValueError('This job is running or queued; its export is protected.')
            from .job_monitor import _guard, _tasks
            with _guard:
                if any(t['thread'].is_alive() for t in _tasks.values()):
                    raise ValueError('A job is running or queued. Wait before deleting an export.')
                partial=path.parent/'highlights.partial.json'
                complete=path.parent/'highlights.json'
                if partial.is_file() and (not complete.is_file() or partial.stat().st_mtime_ns>complete.stat().st_mtime_ns):
                    checkpoint=json.loads(partial.read_text())
                    if checkpoint.get('completed_count',0)<checkpoint.get('selected_count',0):
                        raise ValueError('This clip batch is unfinished; finish the batch before deleting its exports.')
                edit_report=path.parent/'edits.json'
                if edit_report.is_file() and 'summary' not in json.loads(edit_report.read_text()):
                    raise ValueError('This local edit batch is unfinished; its exports are protected.')
                journal=Path(str(path)+'.flow-request.json')
                if journal.exists():
                    if json.loads(journal.read_text()).get('status')!='downloaded':
                        raise ValueError('This file has a pending Flow request; recover it before deletion.')
                # AI recreation approval reads its original clip again on Resume.
                for record in Path(factory.pm.root).glob('*/recreation.json'):
                    data=json.loads(record.read_text())
                    source=data.get('source_clip')
                    if source and Path(source).absolute()==path:
                        raise ValueError('This video is the source of saved recreation job '+record.parent.name+'; retained for Resume.')
                if not _real_file(path) or digest(path)!=preview['sha256']:
                    raise ValueError('This file changed after review. Refresh Gallery and review deletion again.')
                if item.get('job_id'):
                    # Update index first: a DB write failure must preserve media.
                    row=factory.db.get(item['job_id']) or {}
                    if row.get('final_path') and Path(row['final_path']).absolute()==path:
                        factory.db.upsert(item['job_id'],final_path='',render_status='deleted',status='output_deleted')
                try:path.unlink()
                except OSError:
                    if item.get('job_id') and row.get('final_path') and Path(row['final_path']).absolute()==path:
                        factory.db.upsert(item['job_id'],final_path=row['final_path'],render_status=row.get('render_status','done'),status=row.get('status','done'))
                    raise
                return {'path':str(path),'freed_bytes':preview['bytes']}
        finally:
            if job_lock:release(job_lock)
            release(lock)


def media_gallery(st, factory, jobs, clips, allowed_roots=None):
    groups = gallery_items(factory, jobs, clips)
    allowed_roots = allowed_roots or [factory.pm.root]
    st.caption('Choose a video to open its player and download controls. Cards load metadata only.')

    @st.dialog('Play saved video', width='large')
    def play(item):
        path = Path(item['path'])
        if not _real_file(path):
            st.error('This saved export is no longer available. Refresh Gallery.'); return
        st.write(item['label'])
        st.video(str(path))
        if st.button('Prepare MP4 download', key='prepare-gallery-download'):
            st.download_button('Download MP4', path.read_bytes(), file_name=path.name,
                               key='selected-gallery-download', mime='video/mp4', on_click='ignore')
        st.caption('Close this window to release the player. The original file remains saved.')

    category = st.radio('Video category', list(groups), index=next((i for i,rows in enumerate(groups.values()) if rows),0), horizontal=True, key='gallery-category')
    rows = groups[category]
    if not rows:
        st.info('No saved '+category.lower()+' yet.'); return
    maximum = max(1, (len(rows)+5)//6)
    page = st.number_input('Gallery page',1,maximum,1,key='gallery-page-'+category+'-'+str(maximum))
    visible = rows[(page-1)*6:page*6]
    for start in range(0,len(visible),3):
        for col,item in zip(st.columns(3),visible[start:start+3]):
            with col:
                with st.container(border=True):
                    path=Path(item['path']);identifier=hashlib.sha256(str(path).encode()).hexdigest()[:20]
                    st.write(item['label']);st.caption(item['state'])
                    st.caption(f'{path.stat().st_size/1024**2:.1f} MB · '+path.name)
                    if st.button('▶ Play / download', key='gallery-play-'+identifier): play(item)
                    if st.button('Delete exported video',key='gallery-delete-'+identifier):
                        try:st.session_state['gallery-review-'+identifier]=deletion_preview(item)
                        except (OSError,ValueError) as error:st.error(str(error))
                    preview=st.session_state.get('gallery-review-'+identifier)
                    if preview:
                        st.warning('Permanently delete this exported file? Job media and recovery records are kept.')
                        st.code(preview['path'],language='text')
                        confirmed=st.checkbox('I confirm deletion of this file',key='gallery-confirm-'+identifier)
                        if st.button('Confirm permanent deletion',key='gallery-apply-'+identifier,disabled=not confirmed):
                            try:
                                delete_export(factory,preview,jobs,clips,allowed_roots)
                                st.session_state.pop('gallery-review-'+identifier,None);st.rerun()
                            except (OSError,ValueError) as error:st.error(str(error))
                        if st.button('Cancel deletion',key='gallery-cancel-'+identifier):
                            st.session_state.pop('gallery-review-'+identifier,None);st.rerun()

# AutoVideoAI v7.0.35 — edited photos, music sign-in and large B-roll renders

## Findings from the supplied logs

Google explicitly rejected the Flow Music sign-in browser (“This browser or app may not be secure”). Holding that browser open longer cannot guarantee account access. Google documents that software-controlled browsers may be rejected: https://support.google.com/accounts/answer/7675428 . No security restrictions are disabled or hidden.

Flow downloaded the saved location master after two browser closures. The original character photo did not become a verified composer attachment. That differs from a missing Character Library entry. The logs do not reveal which upload validation or attachment control rejected it, so this release adds compatible upload preparation and file-specific diagnostics rather than claiming one proved cause.

The final render opened more than 100 inputs simultaneously. The supplied error contains stream mappings but not an exit code or FFmpeg failure line. Resource exhaustion is plausible, not established. This release bounds concurrent media inputs and writes full failure diagnostics.

## Changes

- Real character photos, including photos added through Edit, get a deterministic RGB JPEG upload copy up to 2048 pixels, with EXIF orientation applied and transparency composited on white. Originals, reference hashes and frozen job approvals remain unchanged. No face is regenerated, cropped or substituted. Prepared upload metadata binds the copy to its original hash.
- Photo-backed jobs pause on required-reference attachment failures rather than quietly using unrelated free images/image-motion for that failure. Exact picker names and verified composer attachments are still required. The improved attachment protocol permits one bounded remediation for older exhausted upload records; it does not submit generation or spend credits.
- Failed attachment diagnostics record the local upload format, size, alias and redacted error in `logs/flow/reference-upload-*.json`. Pending Flow request journals are retained.
- Google’s rejected Flow Music sign-in is identified. Use **Manual Flow Music sign-in and track import → Open Flow Music in my normal browser**. Sign in, generate and download yourself, then import the chosen MP3/WAV/M4A/OGG/FLAC. The import validates playable audio and requires your permission declaration; it makes no new music request. Automated generation/recovery remains available for an already usable session, but is not guaranteed to overcome Google’s sign-in policy.
- Large edits use staged rendering instead of opening all sources/cutaways/graphics together. Every approved cutaway remains in the picture. Staging uses at most eight video/media inputs per stage; the final original audio mix can add its audio inputs. B-roll audio is never introduced. Captions and the final audio mix are applied once; transparent branding is retained.
- Bounded rendering uses hard cuts at scene boundaries and retains the original intended timeline length. Crossfade overlap time is deducted from the scene ends. Temporary staging files are removed on success/failure; original clips, approved B-roll, narration, captions and journals are preserved.
- FFmpeg worker/filter threads are bounded. Failures include the exit code and full diagnostics in `bounded_ffmpeg.log`, `bounded_failure.json` or `ffmpeg_failure.log` rather than only the last stream-mapping lines.

## Upgrade and recover

Stop Studio/CLI jobs before migration. Keep the old directory as a backup. From the freshly extracted v7.0.35 directory:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.34 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.34 . --apply
./dashboard.sh
```

Use the actual old folder name if different. Do not delete request journals or manually rename a different image to a pending asset.

For the already generated job whose encoding failed, **render the same saved job**, rather than starting generation again:

```bash
python3 cli.py v3 render 20261009-192205-why-discipline-beats-mot-15dd
```

This reuses saved accepted takes and B-roll decisions. Existing accepted image-motion fallbacks stay unchanged; a render cannot retrospectively restore their character likeness. Review those scenes before publishing. New or resumed ungenerated scenes use the improved upload path and pause if required identity references cannot attach.

## Validation limits

Local checks include an edited CMYK/high-resolution character-photo round trip, preserved source hashes, detected Google rejection, playable music import and a real render with 20 base scenes plus 60 distinct-timed cutaways. A cutaway-frame comparison verifies the inserted picture, not only the return metadata. Live Google Flow/Flow Music and your WSLg/browser session remain unverified. This release cannot promise a permanent zero-failure upload or bypass provider identity/account restrictions.

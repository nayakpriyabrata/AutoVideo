"""Bounded recovery of typed Flow interruptions; never retries user decisions."""
from pathlib import Path
import json
import time

from .production import save


def can_recover(error):
    from .providers.flow_browser import (FlowReferenceUnavailable, FlowRequestPending,
        FlowBrowserClosedError, FlowTransientNetworkError, FlowServiceBusy)
    if not isinstance(error, (FlowReferenceUnavailable, FlowRequestPending,
                              FlowBrowserClosedError, FlowTransientNetworkError, FlowServiceBusy)):
        return False
    # Reference adapters can wrap an authentication screen. Retrying cannot
    # supply credentials, quota or missing/changed approved source media.
    text = str(error).lower()
    return not any(value in text for value in ('sign in', 'sign-in', 'login required',
        'quota exceeded', 'insufficient credits', 'approval required', 'file not found',
        'no such file', 'changed after approval',
        'recorded flow request differs from this prompt',
        'recorded request belongs to a different flow project',
        'restore its project binding'))


CHECKPOINT_PREFIX = 'Image recovery checkpoint retained'


def recoverable_download_interruption(error):
    """True when a saved exact image request was only interrupted during download.

    flow_image_transaction.recover() re-raises the last browser/network/busy error
    as FlowRequestPending('Image recovery checkpoint retained: ...') from it. The
    request is already recorded and recovery is download-only (no upload, fill or
    Send), so it is safe for automatic resume. Plain pending or submitted requests
    are not covered: they may already have consumed credits.
    """
    from .providers.flow_browser import (FlowRequestPending, FlowBrowserClosedError,
                                         FlowTransientNetworkError, FlowServiceBusy)
    if not isinstance(error, FlowRequestPending) or not str(error).startswith(CHECKPOINT_PREFIX):
        return False
    cause = error.__cause__
    return isinstance(cause, (FlowBrowserClosedError, FlowTransientNetworkError, FlowServiceBusy)) and can_recover(cause)


def checkpoint(factory, job_id):
    """Only validated saved frames and accepted takes count as progress."""
    root = Path(factory.pm.job_dir(job_id))
    frames = tuple(sorted(p.name for p in (root / 'storyboard').glob('*.jpg')
                          if factory._is_valid_image_file(str(p))))
    manifest = factory.pm.load_manifest(job_id)
    accepted = tuple(sorted(s.shot_id for s in manifest.shots if s.accepted_take))
    return frames, accepted


def run_with_recovery(factory, job_id, progress_cb, auto_render, *, sleep=time.sleep):
    from .factory import RecoverableInterruption
    from .flow_reference_policy import reference_recovery_episode
    from .progress import JobProgress
    settings = factory._settings(job_id)
    enabled = settings.get('flow_auto_recovery', True) is True
    progress = JobProgress(factory.pm.job_dir(job_id), progress_cb)
    previous_active = getattr(factory, '_automatic_recovery_active', False)
    previous_providers = getattr(factory, '_active_job_providers', None)
    factory._automatic_recovery_active = enabled
    total = 0
    stagnant = 0
    previous = checkpoint(factory, job_id) if enabled else None
    history = []
    state_path = Path(factory.pm.job_dir(job_id)) / 'automatic_recovery.json'
    try:
        while True:
            factory._active_job_providers = []
            try:
                with reference_recovery_episode():
                    result = factory._run_job(job_id, progress_cb, auto_render)
                if history:
                    save(state_path, {'status': 'finished', 'outcome': result.get('status', 'returned'),
                                      'attempts': total, 'history': history})
                return result
            except RecoverableInterruption as error:
                current = checkpoint(factory, job_id) if enabled else None
                stagnant = 0 if current != previous else stagnant + 1
                previous = current
                total += 1
                event = {'attempt': total, 'shot_id': error.shot_id,
                         'error_type': type(error.original).__name__,
                         'no_progress_attempts': stagnant, 'at': time.time()}
                history.append(event)
                # Four retries without new saved media; twenty across an
                # advancing run. There is never an unlimited browser/upload loop.
                retry = enabled and can_recover(error.original) and stagnant <= 4 and total <= 20
                if not retry:
                    factory._automatic_recovery_active = False
                    manifest = factory.pm.load_manifest(job_id)
                    manifest.status = 'paused'; factory.pm.save_manifest(manifest)
                    factory.db.upsert(job_id, status='paused')
                    factory._write_pause_state(job_id, error.shot_id, str(error),
                        kind='flow_recovery_exhausted', project_url=error.project_url)
                    save(state_path, {'status': 'needs_attention', 'attempts': total, 'history': history})
                    if enabled and can_recover(error.original):
                        # Unattended continuation: the supervisor retries this job later.
                        from .auto_resume import note_recoverable_failure
                        frames, accepted = current if current is not None else checkpoint(factory, job_id)
                        note_recoverable_failure(factory.pm.job_dir(job_id), str(error),
                                                 progress=[len(frames), len(accepted)])
                    raise
                delay = min(60, 10 * 2 ** min(stagnant, 3))
                save(state_path, {'status': 'waiting', 'attempts': total, 'history': history,
                                  'next_retry_at': time.time() + delay})
                progress.emit('Automatic Flow recovery', 26,
                    f'{error.shot_id}: retry {total}/20 in {delay}s; saved media and request journals retained.')
                # Close providers before backoff, including ones bypassed by an
                # exception before the storyboard's normal close path.
            finally:
                for provider in factory._active_job_providers:
                    try: provider.close()
                    except Exception: pass
                factory._active_job_providers = []
            remaining = delay
            while remaining > 0:
                step = min(5, remaining); sleep(step); remaining -= step
                if remaining and remaining % 15 == 0:
                    progress.emit('Automatic Flow recovery', 26, f'Retrying in {remaining}s; Ctrl+C stops safely.')
    except KeyboardInterrupt:
        if history:
            save(state_path, {'status': 'stopped', 'attempts': total, 'history': history})
            manifest = factory.pm.load_manifest(job_id)
            manifest.status = 'paused'; factory.pm.save_manifest(manifest)
            factory.db.upsert(job_id, status='paused')
        raise
    finally:
        factory._automatic_recovery_active = previous_active
        factory._active_job_providers = previous_providers

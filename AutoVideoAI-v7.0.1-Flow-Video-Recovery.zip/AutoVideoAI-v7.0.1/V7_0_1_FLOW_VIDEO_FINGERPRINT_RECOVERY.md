# AutoVideoAI v7.0.1 — Safe Flow video fingerprint recovery

v7.0.1 fixes one specific resume failure: Flow can keep the completed video tile in the project gallery while its media URL/fingerprint has changed since the pending request was journaled. Previously the downloader correctly refused to substitute a different tile, but could not recover this same-job case automatically.

## Safe rematch conditions

On **download-only Resume** of an already-saved video request, v7.0.1 refreshes a missing saved fingerprint only when all of these are true:

1. The saved request still belongs to the same Flow project and same shot/request hash.
2. The journal has a non-empty pre-request baseline, and **every** baseline tile is visible in the current gallery.
3. The saved signature is typed as a video but no longer matches any visible asset.
4. Exactly **one** distinct, fresh, typed video tile exists beyond that baseline.

The rematch is written to `.flow-request.json`, including SHA-256 fingerprints for the old and refreshed signatures. AutoVideoAI then targets that exact tile through the project-gallery menu and requests Flow's original-size export (normally shown as **360p — Original size**). This path does not enter the media viewer and does not submit another generation.

## Refusal cases

No rematch occurs when the baseline is empty or incomplete, more than one fresh video is present, only a queued thumbnail/still is visible, the saved asset is still visible, the project/request binding differs, or the evidence is otherwise uncertain. In those cases the original exact-signature safeguards remain in force and the job stays pending; no different tile is selected and no replacement generation is submitted.

The two downloads are distinct operations: this recovery chooses the exact gallery tile; the existing browser-download recovery then handles a Flow target closing after the download event. The latter still streams only the exact event's asset and validates the resulting MP4.

## Targeted test coverage

Offline tests cover the unique-fresh-video rematch, refusal on multiple candidates or an incomplete baseline, and preference for the original exact tile when it remains visible. These tests do not spend Flow credits or claim that a particular historical job has already been recovered.

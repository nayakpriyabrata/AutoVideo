from types import SimpleNamespace as NS
from pathlib import Path
import json
import pytest
from engine.providers.flow_browser import FlowBrowser, FlowUIChanged
from engine.project.database import JobDB
from engine.production import save, digest
from engine.reference_manager import ReferenceManager
from engine.cast import register_cast

class Nodes:
    def __init__(self, nodes=()): self.nodes=list(nodes)
    def count(self): return len(self.nodes)
    def nth(self,i): return self.nodes[i]

class Node:
    def __init__(self,visible=True): self.visible=visible;self.clicks=[]
    def is_visible(self,**kwargs): return self.visible
    def click(self,**kwargs): self.clicks.append(kwargs)
    def fill(self,text,**kwargs): self.text=text


def test_login_does_not_accept_flow_signin_wall_or_accounts_page():
    browser=FlowBrowser.__new__(FlowBrowser)
    page=NS(url='https://flow.google.com/',is_closed=lambda:False,
        get_by_text=lambda pattern,**kwargs:Nodes([Node()]),locator=lambda selector:Nodes([Node()]))
    browser._page=page
    assert not browser.is_logged_in()
    page.url='https://accounts.google.com/ServiceLogin'
    assert not browser.is_logged_in()
    page.url='https://flow.google.com/'
    page.get_by_text=lambda pattern,**kwargs:Nodes()
    assert browser.is_logged_in()
    page.locator=lambda selector:Nodes()
    assert not browser.is_logged_in()  # loading/blank DOM also isn't authenticated


def test_session_waits_for_manual_login_instead_of_returning_immediately():
    browser=FlowBrowser.__new__(FlowBrowser);checks=iter([False,False,True]);waits=[]
    browser._page=NS(url='https://flow.google.com/',is_closed=lambda:False,wait_for_timeout=lambda ms:waits.append(ms))
    browser._set=lambda state:None;browser.ui={};browser.is_logged_in=lambda:next(checks)
    assert browser._post_connect(5)
    assert waits==[1000,1000]


def test_composer_dismisses_picker_and_uses_visible_editor():
    browser=FlowBrowser.__new__(FlowBrowser);hidden=Node(False);live=Node()
    dismissed=[];browser._dismiss_media_picker=lambda:dismissed.append(True)
    browser._page=NS(locator=lambda selector:Nodes([hidden,live]))
    assert browser._fill_editor_box('agent_prompt_box','Reviewed prompt') is live
    assert dismissed and live.text=='Reviewed prompt' and not hidden.clicks
    assert live.clicks==[{'timeout':12000}]


def test_open_picker_blocks_prompt_if_escape_does_not_close_it():
    browser=FlowBrowser.__new__(FlowBrowser);browser._media_picker_open=lambda:True
    browser._page=NS(keyboard=NS(press=lambda k:None),wait_for_timeout=lambda ms:None)
    with pytest.raises(FlowUIChanged,match='no prompt submitted'):browser._fill_editor_box('agent_prompt_box','prompt')


def test_resolver_skips_hidden_first_match():
    browser=FlowBrowser.__new__(FlowBrowser);hidden=Node(False);visible=Node()
    browser.ui={'actions':{'test':[{'by':'css','selector':'textbox'}]}}
    browser._page=NS(locator=lambda s:Nodes([hidden,visible]))
    assert browser._resolve('test',timeout_ms=100) is visible


def test_absent_add_button_is_not_attachment_evidence(monkeypatch):
    from engine.providers import flow_browser
    clock=iter(range(20));monkeypatch.setattr(flow_browser.time,'monotonic',lambda:next(clock))
    browser=FlowBrowser.__new__(FlowBrowser);browser._agent_reference_names=lambda:[]
    browser._click_text_action=lambda *a,**kw:False
    browser._page=NS(get_by_text=lambda *a,**kw:Nodes(),wait_for_timeout=lambda ms:None)
    assert not browser._finish_agent_media_picker('AV_original.jpg',timeout_ms=1000)


def test_saved_cast_recovers_frozen_job_photo_after_library_path_disappears(tmp_path):
    root=tmp_path/'outputs/job';root.mkdir(parents=True)
    refs=ReferenceManager(str(root/'references'));photo=Path(refs.dir)/'character-aanya-0.jpg';photo.write_bytes(b'original face')
    snapshot={'characters':[{'id':'aanya','name':'Aanya','references':[{'path':'/old/data/content/characters/aanya/face.jpg','sha256':digest(photo)}]}]}
    save(root/'cast_snapshot.json',snapshot)
    assert register_cast(root,refs)[0]['id']=='aanya'
    assert refs.get('character')==[str(photo)]
    assert json.loads((root/'cast_snapshot.json').read_text())==snapshot


def test_saved_cast_recovers_migrated_library_file_only_when_hash_matches(tmp_path):
    root=tmp_path/'outputs/job';root.mkdir(parents=True)
    photo=tmp_path/'data/content/characters/aanya/face.jpg';photo.parent.mkdir(parents=True);photo.write_bytes(b'original')
    save(root/'cast_snapshot.json',{'characters':[{'id':'aanya','name':'Aanya','references':[{'path':'/old/data/content/characters/aanya/face.jpg','sha256':digest(photo)}]}]})
    refs=ReferenceManager(str(root/'references'));register_cast(root,refs)
    assert Path(refs.get('character')[0]).read_bytes()==b'original'
    Path(refs.get('character')[0]).unlink();photo.write_bytes(b'changed')
    with pytest.raises(ValueError,match='Aanya, photo 1'):register_cast(root,refs)


def test_missing_index_prune_preserves_incomplete_folders_and_backups(tmp_path):
    outputs=tmp_path/'outputs';outputs.mkdir();(outputs/'incomplete').mkdir()
    db=JobDB(str(tmp_path/'data/jobs.db'))
    for name in ['missing','incomplete','created-later']:db.upsert(name,topic=name)
    assert {r['job_id'] for r in db.missing_jobs(outputs)}=={'missing','created-later'}
    (outputs/'created-later').mkdir()
    report=db.prune_missing(outputs,['missing','created-later','incomplete'])
    assert report['removed']==['missing'] and Path(report['backup']).is_file()
    assert db.get('incomplete') and db.get('created-later') and not db.get('missing')
    assert JobDB(report['backup']).get('missing')
    assert db.missing_jobs(tmp_path/'disconnected')==[]


def test_storyboard_missing_references_do_not_crash(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard,navigate
    f,app=dashboard(tmp_path,monkeypatch)
    job=f.create_job('A healthy finance habit',target_seconds=20,dry_run=True)
    from engine.project.manifest import Shot
    m=f.pm.load_manifest(job)
    m.shots=[Shot(shot_id='shot_001', reference_assets=[str(tmp_path/f'missing-{i}.jpg') for i in range(5)])]
    f.pm.save_manifest(m)
    app.session_state['job_id']=job;app.run()
    navigate(app,'STORYBOARD')
    assert not app.exception
    assert any('saved reference file(s) are missing' in w.value for w in app.warning)


def test_legacy_false_upload_reservation_gets_one_verified_protocol_remediation(tmp_path,monkeypatch):
    import hashlib
    from engine.flow_reference_policy import reserve_reference_reattach
    monkeypatch.chdir(tmp_path)
    root=tmp_path/'data/flow_media_uploads/upload_registry';root.mkdir(parents=True)
    file=root/(hashlib.sha256(b'project').hexdigest()+'.reattach.json')
    file.write_text(json.dumps({'AV_face.jpg':True}))
    assert reserve_reference_reattach('project','AV_face.jpg')
    assert not reserve_reference_reattach('project','AV_face.jpg')


def test_upload_alias_checks_bytes_even_for_same_size_cache(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path)
    browser=FlowBrowser.__new__(FlowBrowser);photo=tmp_path/'face.jpg';photo.write_bytes(b'face')
    alias=browser._media_upload_alias(str(photo))
    cached=Path(browser._aliased_upload_path(str(photo),alias));cached.write_bytes(b'fake')
    assert Path(browser._aliased_upload_path(str(photo),alias)).read_bytes()==b'face'


def test_log_capture_stays_stable_and_settings_prune_is_reviewable(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard,navigate
    f,app=dashboard(tmp_path,monkeypatch)
    job=f.create_job('A saved job',target_seconds=20,dry_run=True)
    f.db.upsert('absent-job',topic='Missing job')
    log=Path(f.pm.job_dir(job))/'logs/runtime.log';log.write_text('first log\nsecond log\n')
    app.session_state['job_id']=job;app.run();navigate(app,'QUEUE')
    next(w for w in app.button if w.label=='Capture logs for copying').click().run()
    captured=next(w for w in app.text_area if w.label=='Captured logs · select all and copy')
    assert 'second log' in captured.value
    log.write_text('changed live log\n');app.run()
    assert 'second log' in next(w for w in app.text_area if w.label=='Captured logs · select all and copy').value
    navigate(app,'SETTINGS')
    next(w for w in app.button if w.label=='Remove these missing entries').click().run()
    assert not app.exception and f.db.get('absent-job') is None and f.db.get(job)


def test_missing_prune_refuses_during_production(tmp_path):
    from engine.production_lock import production_slot
    outputs=tmp_path/'outputs';outputs.mkdir()
    db=JobDB(str(tmp_path/'data/jobs.db'));db.upsert('missing',topic='Missing')
    with production_slot(outputs/'running'):
        with pytest.raises(ValueError,match='Production is active'):db.prune_missing(outputs,['missing'])
    assert db.get('missing')


def test_cli_prune_preview_and_apply(tmp_path):
    import subprocess,sys
    outputs=tmp_path/'outputs';outputs.mkdir()
    db=JobDB(str(tmp_path/'data/jobs.db'));db.upsert('missing',topic='Missing')
    command=[sys.executable,str(Path(__file__).resolve().parents[1]/'tools/prune_missing_jobs.py'),
             '--database',db.path,'--outputs',str(outputs)]
    preview=json.loads(subprocess.run(command,check=True,capture_output=True,text=True).stdout)
    assert preview['missing'][0]['job_id']=='missing' and db.get('missing')
    applied=json.loads(subprocess.run(command+['--apply'],check=True,capture_output=True,text=True).stdout)
    assert applied['removed']==['missing'] and db.get('missing') is None


def test_partial_attachment_retry_reuses_exact_composer_chip_without_picker(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path)
    photo=tmp_path/'face.jpg';photo.write_bytes(b'original identity')
    browser=FlowBrowser.__new__(FlowBrowser);alias=browser._media_upload_alias(str(photo))
    browser._agent_reference_names=lambda:[alias]
    browser.current_project_url=lambda:'https://flow.google.com/project/test'
    browser._dismiss_media_picker=lambda:None
    browser._try_attach_existing_project_media=lambda alias:pytest.fail('Already attached references must not open another picker')
    assert browser.attach_agent_media([str(photo)])==1

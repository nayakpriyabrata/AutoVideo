import asyncio
import json
from pathlib import Path
from types import SimpleNamespace as NS
import threading
import time
import pytest
from PIL import Image
from engine.providers.flow_browser import FlowBrowser, FlowBrowserProvider
from engine import quiet_browser as quiet
from engine.flow_reference_policy import reserve_reference_reattach
from engine.production_lock import production_slot


def test_reference_reattach_reservation_survives_resume_and_is_exact(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert reserve_reference_reattach('project-a','AV_abc_face.png')
    assert not reserve_reference_reattach('project-a','AV_abc_face.png')
    assert reserve_reference_reattach('project-b','AV_abc_face.png')
    assert reserve_reference_reattach('project-a','AV_other_face.png')


def test_verified_attachment_resets_but_failed_reattach_remains_bounded(tmp_path,monkeypatch):
    from engine.flow_reference_policy import upload_record
    monkeypatch.chdir(tmp_path);photo=tmp_path/'face.png';photo.write_bytes(b'identity')
    browser=FlowBrowser.__new__(FlowBrowser);url='https://flow.google.com/project/test'
    alias=browser._media_upload_alias(str(photo));upload_record(url,alias,record=True)
    browser.current_project_url=lambda:url;browser._try_attach_existing_project_media=lambda n:False
    files=[]
    locator=NS(count=lambda:1,last=NS(set_input_files=lambda p:files.append(Path(p).read_bytes())))
    browser._page=NS(locator=lambda s:locator,wait_for_timeout=lambda n:None,keyboard=NS(press=lambda k:None))
    browser._agent_reference_names=lambda:[]
    browser._finish_agent_media_picker=lambda n:True
    browser._dismiss_media_picker=lambda:None
    browser._open_agent_add_menu=lambda:None
    browser._resolve=lambda *a,**kw:NS(click=lambda **kwargs:None)
    class Chooser:
        value=NS(set_files=lambda p:files.append(Path(p).read_bytes()))
        def __enter__(self):return self
        def __exit__(self,*args):pass
    browser._page.expect_file_chooser=lambda **kwargs:Chooser()
    assert browser.attach_agent_media([str(photo)])==1
    assert files==[b'identity']
    assert browser.attach_agent_media([str(photo)])==1 # verified success permits a later recovery
    browser._finish_agent_media_picker=lambda n:False
    with pytest.raises(Exception,match='no verified composer attachment'):browser.attach_agent_media([str(photo)])
    with pytest.raises(Exception,match='one local-file reattachment'):browser.attach_agent_media([str(photo)])
    assert files==[b'identity']*3


def test_quiet_never_attaches_visible_cdp_or_uses_windows_exe(monkeypatch):
    b=FlowBrowser.__new__(FlowBrowser);b.bcfg={'quiet':True,'mode':'auto','executable':'/mnt/c/Chrome.exe'}
    assert b._launch_options()==[{'kind':'bundled'}]
    b.bcfg['mode']='cdp'
    with pytest.raises(RuntimeError,match='CDP'):b._launch_options()


def test_missing_quiet_dependency_stops_without_visible_fallback(monkeypatch):
    monkeypatch.setattr(quiet.shutil,'which',lambda n:None)
    with pytest.raises(RuntimeError,match='did not open a visible browser'):quiet.browser_environment()


def test_video_artifact_failure_preserves_verified_output(tmp_path,monkeypatch):
    from playwright import async_api
    class Artifact:
        def __init__(self,impl):pass
        async def save_as(self,path):Path(path).write_bytes(b'partial');raise RuntimeError('Target closed')
    monkeypatch.setattr(async_api,'Download',Artifact)
    output=tmp_path/'video.mp4';output.write_bytes(b'verified')
    b=FlowBrowser.__new__(FlowBrowser)
    assert b._save_browser_video_artifact(NS(_impl_obj=object(),_sync=asyncio.run),str(output)) is None
    assert output.read_bytes()==b'verified'
    assert list(tmp_path.iterdir())==[output]


def test_video_artifact_validates_before_atomic_replace(tmp_path,monkeypatch):
    from playwright import async_api
    class Artifact:
        def __init__(self,impl):pass
        async def save_as(self,path):Path(path).write_bytes(b'exact-video')
    monkeypatch.setattr(async_api,'Download',Artifact)
    monkeypatch.setattr(FlowBrowserProvider,'_is_valid_video_file',lambda p:Path(p).read_bytes()==b'exact-video')
    output=tmp_path/'video.mp4';b=FlowBrowser.__new__(FlowBrowser)
    assert b._save_browser_video_artifact(NS(_impl_obj=object(),_sync=asyncio.run),str(output))==str(output)
    assert output.read_bytes()==b'exact-video'
    assert list(tmp_path.iterdir())==[output]


def test_multiple_tabs_serialize_and_duplicate_job_is_rejected(tmp_path,monkeypatch):
    monkeypatch.setattr(Path,'home',classmethod(lambda cls:tmp_path))
    started=threading.Event();entered=threading.Event()
    def second():
        started.set()
        with production_slot(tmp_path/'job2'):entered.set()
    with production_slot(tmp_path/'job1'):
        with pytest.raises(RuntimeError,match='already running'):
            with production_slot(tmp_path/'job1'):pass
        t=threading.Thread(target=second);t.start();assert started.wait(1)
        assert not entered.wait(.1)
    t.join(2);assert entered.is_set() and not t.is_alive()


def test_saved_card_crop_finds_offcenter_face_without_mutating_photo():
    from engine.studio_widgets import face_thumbnail
    image=Image.new('RGB',(600,800),'green')
    for x in range(380,500):
        for y in range(420,540):image.putpixel((x,y),(255,0,0))
    original=image.tobytes()
    crop=face_thumbnail(image,focus={'x':.73,'y':.6,'zoom':4})
    assert crop.getpixel((70,80))[0]>200 and image.tobytes()==original


def test_show_quiet_browser_reveals_existing_display_without_restart(tmp_path,monkeypatch):
    monkeypatch.setattr(quiet,'_root',lambda:tmp_path)
    monkeypatch.setattr(quiet,'_dependencies',lambda names:None)
    monkeypatch.setattr(quiet,'_live',lambda pid,token:True)
    (tmp_path/'display.json').write_text(json.dumps({'pid':41,'display':':81'}))
    (tmp_path/'viewer.json').write_text(json.dumps({'pid':42,'port':5909}))
    (tmp_path/'vnc-password').write_bytes(b'private-password')
    commands=[];monkeypatch.setattr(quiet.subprocess,'Popen',lambda args,**kw:commands.append(args))
    quiet.show_browser()
    assert len(commands)==1 and commands[0][0]=='vncviewer'
    assert commands[0][-1]=='127.0.0.1::5909'


def test_approved_short_script_defaults_to_measured_without_rewrite(tmp_path):
    from engine.factory import Factory
    from engine.production import read
    from tests.test_v600_content_studio import plan
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'db.sqlite'))
    job=f.create_job('One useful lesson',target_seconds=180)
    value=plan();f.import_content_plan(job,value)
    assert f._settings(job)['narration_runtime_policy']=='measured'
    assert read(Path(f.pm.job_dir(job))/'approved_content_plan.json')['narration']==value['narration']


@pytest.mark.parametrize('saved_url',['','https://flow.google.com/project/saved-child'])
def test_only_new_replacement_leaves_original_composer(saved_url,tmp_path):
    navigations=[];projects=[]
    bridge=NS(ui={'url':'https://flow.google.com/'},_page=NS(goto=lambda url,**kw:navigations.append(url)),
              _project_ready='original',_project_url='https://flow.google.com/project/original')
    def ensure(name,project_url=None):
        projects.append((name,project_url));raise RuntimeError('Stop before generation')
    bridge.ensure_project=ensure
    provider=FlowBrowserProvider();provider._ensure=lambda:bridge
    with pytest.raises(RuntimeError):
        provider._generate_image_once(NS(shot_id='shot_001'),{'flow_replacement_request':True,
            'project':'replacement-child','project_url':saved_url},str(tmp_path/'image.jpg'),True)
    assert navigations==([] if saved_url else ['https://flow.google.com/'])
    assert projects==[('replacement-child',saved_url or '')] or projects==[('replacement-child',None)]

from pathlib import Path
import json
import pytest
from types import SimpleNamespace as NS
from engine.flow_reference_policy import compact_photo_brief,upload_record
from engine.planning.frame_prompts import frame_prompt
from engine.providers.flow_browser import FlowBrowser,FlowUIChanged


def test_long_photo_identity_keeps_scene_and_framing():
    identity='Long character identity. '*100
    shot=NS(subject='CHARACTER_01 ('+identity+')',subject_action='closes laptop',environment='tech studio',
            visual_goal='Scene 6 finish explaining',narration='future reels',camera_framing='wide establishing',lighting='blue')
    brief=frame_prompt(shot,{'characters':[{'canonical':identity}]},True,'close')
    compact=compact_photo_brief(brief,['/references/character-debanshi-0.png'])
    assert len(compact)<1500
    for text in ['STORYBOARD CLOSE FRAME','AFTER','CHARACTER_01','closes laptop','Scene 6 finish explaining',
                 'future reels','wide establishing','tech studio','blue']:
        assert text in compact
    assert identity not in compact
    assert compact_photo_brief(brief,[])==brief


def test_unknown_or_ambiguous_template_not_rewritten():
    assert compact_photo_brief('Custom prompt',['character-0.png'])=='Custom prompt'
    brief='STORYBOARD CLOSE FRAME, Subject: two Action context: values Action context: conflict'
    assert compact_photo_brief(brief,['character-0.png'])==brief


def test_registry_persists_and_is_project_and_content_scoped(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert not upload_record('project-a','AV_hash_character.png')
    upload_record('project-a','AV_hash_character.png',record=True)
    assert upload_record('project-a','AV_hash_character.png')
    assert not upload_record('project-b','AV_hash_character.png')
    assert not upload_record('project-a','AV_changed_character.png')
    assert not upload_record('','AV_hash_character.png',record=True)


def test_known_reference_after_one_reattach_never_uploads_again(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path);p=tmp_path/'character-photo.png';p.write_bytes(b'photo')
    b=FlowBrowser.__new__(FlowBrowser);alias=b._media_upload_alias(str(p))
    url='https://flow.google.com/project/existing'
    upload_record(url,alias,record=True)
    b.current_project_url=lambda:url
    b._agent_reference_names=lambda:[]
    b._try_attach_existing_project_media=lambda name:False
    from engine.flow_reference_policy import reserve_reference_reattach
    assert reserve_reference_reattach(url,alias)
    b._aliased_upload_path=lambda *args:pytest.fail('Second recovery upload path must not execute')
    with pytest.raises(FlowUIChanged,match='one local-file reattachment'):
        b.attach_agent_media([str(p)])


def test_existing_reference_reused_and_remembered(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path);p=tmp_path/'character-photo.png';p.write_bytes(b'photo')
    b=FlowBrowser.__new__(FlowBrowser);url='https://flow.google.com/project/existing'
    b._agent_reference_names=lambda:[]
    b.current_project_url=lambda:url;b._try_attach_existing_project_media=lambda name:True
    b._aliased_upload_path=lambda *args:pytest.fail('Reuse must not upload')
    assert b.attach_agent_media([str(p)])==1
    assert upload_record(url,b._media_upload_alias(str(p)))


def test_oversized_unknown_brief_stops_before_prompt_or_submission(tmp_path):
    from engine.providers.flow_browser import FlowBrowserProvider
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider)
    b=NS(ensure_project=lambda *a,**kw:None,current_project_url=lambda:'https://flow.google.com/project/test',
         detect_editor_mode=lambda:'agent',select_agent_generation_type=lambda kind:None,
         media_asset_signatures=lambda:set(),_agent_image_instruction=FlowBrowser._agent_image_instruction,
         _fill_editor_box=lambda *a:pytest.fail('Truncated prompt must not be sent'),
         submit_prepared_text_video=lambda *a:pytest.fail('No new submission permitted'))
    provider._ensure=lambda:b
    provider._record_submission=lambda *a,**kw:pytest.fail('Invalid brief must not create a submission journal')
    with pytest.raises(FlowUIChanged,match='exceeds 4000'):
        provider._generate_image_once(NS(shot_id='shot_007'),{'prompt':'unknown brief '+('x'*4500)},str(tmp_path/'frame.jpg'),True)

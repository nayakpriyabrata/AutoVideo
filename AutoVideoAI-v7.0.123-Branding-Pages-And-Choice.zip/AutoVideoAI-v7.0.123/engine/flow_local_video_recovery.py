"""Import a reviewed download for one pending Flow video request without a browser."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import time
from urllib.parse import urlsplit

from .production import save
from .production_lock import production_slot


def _project_id(url, *, editor=False):
    parsed = urlsplit(str(url or ''))
    pattern = r'/project/([A-Za-z0-9-]+)' + (r'/edit/[A-Za-z0-9-]+' if editor else '')
    match = re.fullmatch(pattern, parsed.path)
    if (parsed.scheme != 'https' or parsed.hostname != 'flow.google.com'
            or parsed.username or parsed.password or parsed.query or parsed.fragment
            or parsed.port not in (None, 443) or not match):
        raise ValueError('Use the exact Flow editor URL from the saved project')
    return match.group(1)


def import_reviewed_video(factory, job_id, shot_id, source, asset_url, *, reviewed=False):
    """Preserve journal evidence and QC a local MP4 reviewed in its exact Flow editor."""
    if reviewed is not True:
        raise ValueError('Confirm that the downloaded video belongs to this pending shot')
    if not re.fullmatch(r'[A-Za-z0-9_-]+', str(job_id)) or not re.fullmatch(r'shot_\d+', str(shot_id)):
        raise ValueError('Invalid job or shot ID')
    reviewed_project = _project_id(asset_url, editor=True)
    source = Path(source).expanduser().resolve(strict=True)
    if source.suffix.lower() != '.mp4' or not source.is_file() or source.stat().st_size == 0:
        raise ValueError('Choose a nonempty downloaded MP4')
    from .providers.flow_browser import FlowBrowserProvider
    if not FlowBrowserProvider._is_valid_video_file(str(source)):
        raise ValueError('MP4 failed playable video validation')
    folder = Path(factory.pm.job_dir(job_id))
    with production_slot(folder):
        shot_dir = folder/'flow'/'shots'/shot_id
        journals = sorted(shot_dir.glob('take_*.mp4.flow-request.json'))
        if len(journals) != 1 or journals[0].is_symlink():
            raise ValueError('Expected exactly one saved Flow video request for this shot')
        journal = journals[0]
        request = json.loads(journal.read_text(encoding='utf-8'))
        if (request.get('kind') != 'video' or request.get('status') == 'downloaded'
                or reviewed_project != _project_id(request.get('project_url'))):
            raise ValueError('Reviewed video does not match an unresolved request in this project')
        manifest = factory.pm.load_manifest(job_id)
        shot = next((s for s in manifest.shots if s.shot_id == shot_id), None)
        if shot is None or shot.accepted_take:
            raise ValueError('Shot is absent or already accepted; nothing replaced')
        canonical = Path(str(journal)[:-len('.flow-request.json')])
        if canonical.exists() and canonical.stat().st_size:
            raise ValueError('The canonical request already has media; reconcile it first')
        # Copy to a same-volume staging file before QC, so a renamed/moved
        # source cannot change between validation and acceptance.
        fd, stage_name = tempfile.mkstemp(dir=shot_dir, prefix='.reviewed-flow-', suffix='.mp4')
        os.close(fd)
        stage = Path(stage_name)
        try:
            shutil.copyfile(source, stage)
            if not FlowBrowserProvider._is_valid_video_file(str(stage)):
                raise ValueError('Copied MP4 failed validation')
            result = factory.associate_download(job_id, shot_id, str(stage))
            qc = result.get('qc', {})
            if str(qc.get('decision', '')).upper() not in ('ACCEPT', 'REVIEW'):
                return {'resolved': False, 'shot_id': shot_id, 'new_credits': 0,
                        'message': 'QC rejected this MP4; the request stays pending', **result}
            evidence = journal.with_name(journal.name + '.before-local-recovery-' + time.strftime('%Y%m%d-%H%M%S'))
            shutil.copy2(journal, evidence)
            os.replace(stage, canonical)
            request.update(status='downloaded', operator_selected_asset_url=asset_url,
                           operator_selection_at=time.time(), recovery_download_path=str(canonical),
                           media_sha256=hashlib.sha256(canonical.read_bytes()).hexdigest(), recovery_qc=qc)
            save(journal, request)
            manifest = factory.pm.load_manifest(job_id)
            manifest.status = 'planned'
            factory.pm.save_manifest(manifest)
            factory.db.upsert(job_id, status='planned')
            pause_file = folder/'pause_state.json'
            if pause_file.is_file():
                pause = json.loads(pause_file.read_text(encoding='utf-8'))
                pause.update(resolved=True, recovered_shot=shot_id, recovered_file=result.get('take'),
                             recovery_qc=qc)
                save(pause_file, pause)
            return {'resolved': True, 'shot_id': shot_id, 'new_credits': 0, **result}
        finally:
            stage.unlink(missing_ok=True)

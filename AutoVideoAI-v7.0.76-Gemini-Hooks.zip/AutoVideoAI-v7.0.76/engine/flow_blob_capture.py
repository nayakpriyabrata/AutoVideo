"""Capture only the exact UI download blob, within its live browser context."""
import asyncio
import base64
import os
from pathlib import Path
import tempfile

SCRIPT = r'''async ({url,limit}) => {
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),15000);
 try {
  const response=await fetch(url,{signal:controller.signal});
  if(!response.ok || !response.body)return null;
  const reader=response.body.getReader();let size=0;const chunks=[];
  while(true){const {done,value}=await reader.read();if(done)break;
   size+=value.length;if(size>limit){await reader.cancel();return null;}chunks.push(value);}
  const bytes=new Uint8Array(size);let offset=0;
  for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  let binary='';for(let i=0;i<size;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return {bytes:size,data:btoa(binary)};
 } finally {clearTimeout(timer);}
}'''


def capture(bridge, download, output):
    url=str(getattr(download,'url','') or '')
    if not url.startswith(('blob:https://flow.google.com/','blob:https://labs.google/')):
        return None
    limit=128*1024*1024
    from playwright.async_api import Page
    for page in (getattr(bridge,'_page',None),getattr(bridge,'_guard_page',None)):
        try:
            if page is None or page.is_closed():continue
            current=str(page.url or '')
            if not current.startswith(('https://flow.google.com/','https://labs.google/')):continue
            if not getattr(page,'_impl_obj',None) or not callable(getattr(page,'_sync',None)):continue
            async def read():
                return await asyncio.wait_for(Page(page._impl_obj).evaluate(SCRIPT,{'url':url,'limit':limit}),timeout=20)
            payload=page._sync(read())
            if not isinstance(payload,dict) or type(payload.get('bytes')) is not int or not 0<payload['bytes']<=limit:continue
            data=base64.b64decode(payload['data'],validate=True)
            if len(data)!=payload['bytes']:continue
            parent=Path(output).resolve().parent;parent.mkdir(parents=True,exist_ok=True)
            fd,temp=tempfile.mkstemp(prefix='.flow-exact-blob-',suffix=Path(output).suffix,dir=parent)
            try:
                with os.fdopen(fd,'wb') as handle:handle.write(data)
                from .providers.flow_browser import FlowBrowserProvider
                kind='video' if str(output).lower().endswith('.mp4') else 'image'
                validator=FlowBrowserProvider.__new__(FlowBrowserProvider)
                if not validator._asset_valid(temp,kind):continue
                os.replace(temp,output)
                print('[Flow] Saved and validated the exact download blob while its browser context was alive.')
                return output
            finally:
                if os.path.isfile(temp):os.remove(temp)
        except Exception:
            continue
    return None

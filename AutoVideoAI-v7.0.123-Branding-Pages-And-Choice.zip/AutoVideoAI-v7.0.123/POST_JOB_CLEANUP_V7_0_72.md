# Post-job cleanup · v7.0.72

## Why

v7.0.71 had cleanup only as whole-job deletion (Manage saved jobs & clips), which also deletes the final video. Nothing removed media that a finished video no longer needs. Two kinds of folder grew without limit:

- **Generation jobs:** every Flow take (including unused takes), raw downloads, storyboard frames, references, narration and audio, stock copies, and any intermediate renders.
- **Clip studio folders:** `_clip_work/<source>/` kept the downloaded source video and per-batch speech and frame files after each run finished.

v7.0.72 adds a reviewed "Free space" step that keeps the finished video and removes only the media.

## What is kept

- Every validated final video in `render/` (`*final*.mp4`), and every finished clip output in a clip folder.
- All JSON, text, subtitles, logs, reports, and Flow request journals (`*.flow-request.json`).
- Symlinks, which are never followed or removed.

## What is removed

- **Generation job:** media files under the job folder (`.mp4`, `.mov`, `.jpg`, `.png`, `.mp3`, `.wav`, `.m4a`, and similar), plus any interrupted `render/.bounded-*` temp folders.
- **Clip folder:** media files under `_clip_work/` (the downloaded source and batch work).

Remote Google Flow media is never touched. Use the existing storage manager for that.

## When it is blocked

Nothing is deleted if any of these is true:

- The job status is not `done`.
- No final video in `render/` passes validation.
- A Flow request is not `downloaded`.
- `auto_resume.json` or `pause_state.json` shows an automatic resume that is running or waiting.
- Production holds the job's `.production.lock`.
- A clip run has no readable `highlights.json`.

## How to use it (after the video is finished)

1. Open the dashboard and go to **Manage saved jobs & clips**.
2. Select the finished job or clip folder.
3. Open **Free space after finishing**, then press **Review cleanup**.
4. Check the category table and the kept video list.
5. Tick the confirmation box, then press **Free space now**.

The apply step recomputes the plan and refuses if anything changed since review.

From the command line:

```
python3 cli.py v3 cleanup-plan <job_id>                 # preview, prints a digest
python3 cli.py v3 cleanup-apply <job_id> --digest <d>   # delete exactly the reviewed set
python3 cli.py v3 cleanup-plan --clip-folder <folder>
python3 cli.py v3 cleanup-apply --clip-folder <folder> --digest <d>
```

Each applied cleanup writes `logs/post_job_cleanup_<time>.json` (clip folders: at the folder root) with the removed categories, bytes freed, and kept videos.

## Trade-offs

- After cleanup, source takes and narration cannot be used to re-render the job. Re-rendering a job would need new generation, which spends credits. Keep the final video.
- A clip folder's source video must be downloaded again before its clips can be re-cut.
- Cleanup is manual. Nothing is deleted automatically.

## Not covered yet

- Automatic cleanup on a schedule.
- Remote Flow gallery cleanup (use the existing storage manager, which requires its own confirmation).
- Live browser test of the Streamlit panel. The logic is covered by unit tests; please check the panel on your machine.

## Install

Stop the dashboard, then from the 7.0.71 installation folder:

```
python3 ../AutoVideoAI-v7.0.72/tools/update_v771_to_v772.py .            # dry run
python3 ../AutoVideoAI-v7.0.72/tools/update_v771_to_v772.py . --apply
```

The updater replaces code and documentation only. Outputs, saved jobs, browser profiles, music, characters, and channel profiles are never copied, moved, or deleted.

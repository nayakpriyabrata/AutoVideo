"""v7.0.106: a rendered video is never deleted without a copy that can be found again.

The user asked where a finished video goes when a job is cleaned up. Until now: nowhere. The completed-job
deletion moved the whole job folder into ``outputs/.deletion-quarantine/`` and then removed it, and the Clip
Studio cleanup unlinked rendered clips - the finished video was gone with the file that produced it.

This module moves (not copies) a rendered file into a predictable folder, so cleanup still frees the job
folder while the video survives:

    <outputs>/_render-backups/<job id>/<file name>          finished job videos
    <clips folder>/_render-backups/<stamp>/<file name>      Clip Studio clips

The location can be changed with ``AUTOVIDEO_RENDER_BACKUP_DIR`` (absolute, outside ``outputs`` is fine) or
the ``render_backup_dir`` setting. A move inside one filesystem is an atomic rename; across filesystems the
bytes are copied, hashed, verified and only then is the original removed. If a backup cannot be verified the
caller is told so and must not delete the original - no silent data loss.
"""
from __future__ import annotations

import hashlib
import os
import shutil
from pathlib import Path

BACKUP_DIRNAME = '_render-backups'
ENV_VAR = 'AUTOVIDEO_RENDER_BACKUP_DIR'
VIDEO_SUFFIXES = ('.mp4', '.mov', '.mkv', '.webm', '.m4v')


def backup_root(outputs=None, settings=None) -> Path:
    """Where rendered files are kept after cleanup.

    ``AUTOVIDEO_RENDER_BACKUP_DIR`` wins, then the ``render_backup_dir`` setting, then
    ``<outputs>/_render-backups`` (same drive, so the move is an instant rename).
    """
    override = str(os.environ.get(ENV_VAR) or (settings or {}).get('render_backup_dir') or '').strip()
    if override:
        return Path(override).expanduser().absolute()
    base = Path(outputs) if outputs else Path('outputs')
    base = base.expanduser()
    try:
        base = base.resolve()
    except OSError:
        base = base.absolute()
    return base / BACKUP_DIRNAME


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_label(label: str) -> str:
    cleaned = ''.join(char if char.isalnum() or char in '-._' else '-' for char in str(label or ''))
    return cleaned.strip('.-') or 'job'


def _free_target(folder: Path, name: str, source: Path) -> tuple[Path, str]:
    """A target path that does not overwrite a different file; notes an identical existing backup."""
    candidate = folder / name
    if not candidate.exists():
        return candidate, ''
    try:
        if candidate.is_file() and not candidate.is_symlink() and candidate.stat().st_size == source.stat().st_size \
                and _sha256(candidate) == _sha256(source):
            return candidate, 'identical backup already exists'
    except OSError:
        pass
    stem, suffix = os.path.splitext(name)
    for index in range(2, 1000):
        candidate = folder / f'{stem}-{index}{suffix}'
        if not candidate.exists():
            return candidate, ''
    raise OSError(f'No free backup name for {name}')


def plan(paths, *, root, label) -> dict:
    """Report what a backup would move, without touching anything."""
    root = Path(root)
    folder = root / _safe_label(label)
    rows = []
    for raw in paths:
        path = Path(raw)
        rows.append({'source': str(path), 'target': str(folder / path.name),
                     'bytes': path.stat().st_size if path.is_file() and not path.is_symlink() else 0,
                     'exists': path.is_file() and not path.is_symlink()})
    return {'root': str(root), 'folder': str(folder), 'files': rows,
            'bytes': sum(row['bytes'] for row in rows)}


def backup_files(paths, *, root, label, apply=True) -> dict:
    """Move each rendered file into the backup folder. Raises before deleting anything it cannot verify.

    Returns ``{'root', 'folder', 'files': [...], 'bytes', 'warnings'}``. Each moved row carries its
    ``target``, ``bytes``, ``sha256`` and ``mode`` ('move' or 'copy+verify').
    """
    root = Path(root)
    folder = root / _safe_label(label)
    report = {'root': str(root), 'folder': str(folder), 'apply': bool(apply), 'files': [],
              'bytes': 0, 'warnings': []}
    selected = []
    for raw in paths:
        path = Path(raw)
        if path.is_symlink():
            report['warnings'].append(f'skipped symlink: {path.name}')
            continue
        if not path.is_file():
            report['warnings'].append(f'missing: {path.name}')
            continue
        if path.suffix.lower() not in VIDEO_SUFFIXES:
            report['warnings'].append(f'not a video file: {path.name}')
            continue
        selected.append(path)
    if not selected:
        return report
    if not apply:
        for path in selected:
            report['files'].append({'source': str(path), 'target': str(folder / path.name),
                                    'bytes': path.stat().st_size, 'state': 'would move'})
        report['bytes'] = sum(row['bytes'] for row in report['files'])
        return report
    folder.mkdir(parents=True, exist_ok=True)
    for path in selected:
        size = path.stat().st_size
        digest = _sha256(path)
        target, note = _free_target(folder, path.name, path)
        if note:
            # Same bytes are already backed up: dropping the original loses nothing.
            path.unlink()
            report['files'].append({'source': str(path), 'target': str(target), 'bytes': size,
                                    'sha256': digest, 'mode': 'already-backed-up', 'note': note})
            report['bytes'] += size
            continue
        mode = 'move'
        try:
            os.replace(path, target)
        except OSError:
            # Different filesystem (or a locked file on Windows): copy, verify, then remove.
            mode = 'copy+verify'
            partial = target.with_name(target.name + '.part')
            shutil.copy2(path, partial)
            if partial.stat().st_size != size or _sha256(partial) != digest:
                partial.unlink(missing_ok=True)
                raise OSError(f'Backup verification failed for {path.name}; the original was kept')
            os.replace(partial, target)
            path.unlink()
        if target.stat().st_size != size:
            raise OSError(f'Backup size mismatch for {path.name}; the original was kept')
        report['files'].append({'source': str(path), 'target': str(target), 'bytes': size,
                                'sha256': digest, 'mode': mode})
        report['bytes'] += size
    return report


def restore(root, label, *, outputs, subdir='render') -> dict:
    """Put a job's backed-up videos back into ``<outputs>/<job>/<subdir>/``.

    The job folder may no longer exist (it was deleted); the videos are restored so they can be watched,
    copied or delivered. Restoring does not recreate the production, its manifest or its database entry.
    """
    root = Path(root)
    folder = root / _safe_label(label)
    target_dir = Path(outputs) / _safe_label(label) / subdir
    report = {'folder': str(folder), 'target': str(target_dir), 'files': [], 'bytes': 0}
    if not folder.is_dir():
        report['warning'] = 'No backup folder for this job'
        return report
    target_dir.mkdir(parents=True, exist_ok=True)
    for source in sorted(path for path in folder.iterdir() if path.is_file() and not path.is_symlink()):
        if source.suffix.lower() not in VIDEO_SUFFIXES:
            continue
        target = target_dir / source.name
        if target.exists() and target.stat().st_size == source.stat().st_size:
            report['files'].append({'source': str(source), 'target': str(target), 'state': 'already there'})
            continue
        partial = target.with_name(target.name + '.part')
        shutil.copy2(source, partial)
        os.replace(partial, target)
        report['files'].append({'source': str(source), 'target': str(target), 'state': 'restored',
                                'bytes': target.stat().st_size})
        report['bytes'] += target.stat().st_size
    return report


def inventory(root) -> list[dict]:
    """Every backed-up video, newest folder first: what exists and how big it is."""
    root = Path(root)
    rows = []
    if not root.is_dir():
        return rows
    for folder in sorted(root.iterdir(), key=lambda item: item.name):
        if not folder.is_dir() or folder.is_symlink():
            continue
        files = [path for path in sorted(folder.iterdir())
                 if path.is_file() and not path.is_symlink() and path.suffix.lower() in VIDEO_SUFFIXES]
        rows.append({'job': folder.name, 'folder': str(folder),
                     'files': [{'name': path.name, 'bytes': path.stat().st_size, 'path': str(path)}
                               for path in files],
                     'bytes': sum(path.stat().st_size for path in files)})
    return rows

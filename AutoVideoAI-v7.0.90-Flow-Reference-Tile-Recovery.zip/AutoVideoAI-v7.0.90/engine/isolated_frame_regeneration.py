"""Bounded, explicitly authorized replacement of unresolved storyboard frames.

Each frame gets one isolated project and one durable submission reservation.
Recovery uses that project/baseline, not equality with Flow's rewritten prompt.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import time
import uuid
import unicodedata


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with tmp.open('w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def image_valid(path):
    from PIL import Image
    try:
        with Image.open(path) as image:
            image.verify()
        with Image.open(path) as image:
            return min(image.size) >= 64
    except (OSError, ValueError):
        return False


def brief(submitted):
    # Only accept the complete known Agent envelope. Never infer a creative
    # instruction from a truncated journal or a gallery thumbnail.
    text = ' '.join(str(submitted or '').split())
    match = re.fullmatch(
        r'(?:Request tracking label AVREQ_[a-f0-9]{24}; metadata only, never draw or write it in the image\. )?'
        r'Create exactly 1 STILL IMAGE, not a video\. Use (?:portrait orientation \(9:16\)|landscape orientation \(16:9\)) '
        r'and the no-charge Nano Banana 2 Lite image model when available\. '
        r'Create this image exactly from the creative brief: (.+)', text)
    if not match:
        raise ValueError('Request lacks the complete saved creative brief')
    return match.group(1)


def plan(job):
    from .flow_resume_safety import check_job
    root = Path(job).resolve(strict=True)
    manifest = json.loads((root / 'production_manifest.json').read_text())
    if manifest.get('job_id') != root.name:
        raise ValueError('Manifest and job directory do not match')
    shots = {s['shot_id']: s for s in manifest['shots']}
    groups, blocked = {}, []
    for row in check_job(root)['unresolved']:
        relative = row['journal']
        path = root / relative
        try:
            if path.is_symlink() or not path.resolve().is_relative_to(root):
                raise ValueError('Journal is symlinked or outside job')
            # New reserved replacements are handled from the same durable ledger.
            if relative.startswith('authorized_frame_replacements/'):
                continue
            match = re.fullmatch(r'shot_(\d+)_(open|close)_[0-9a-f]+\.jpg(?:\.replacement-01\.jpg)?\.flow-request\.json', path.name)
            if not match or not relative.startswith('.flow-workers/economy-frame-artifacts/'):
                raise ValueError('Only unresolved worker storyboard frames are supported')
            sid, role = 'shot_' + match.group(1), match.group(2)
            if sid not in shots or shots[sid].get('accepted_take'):
                raise ValueError('Shot is absent or already accepted; not replaced')
            request = json.loads(path.read_text())
            if request.get('kind') != 'image':
                raise ValueError('Only image requests can be replaced')
            creative = brief(request.get('submitted_prompt'))
            key = sid + '_' + role
            if key in groups and groups[key]['brief'] != creative:
                raise ValueError('Original and replacement briefs differ; automatic grouping refused')
            frame = groups.setdefault(key, {'key': key, 'shot_id': sid, 'role': role,
                'brief': creative, 'journals': [], 'target': 'storyboard/' + key + '.jpg'})
            frame['journals'].append({'path': relative, 'sha256': sha(path)})
        except (OSError, ValueError, TypeError, AttributeError) as error:
            blocked.append({'journal': relative, 'reason': str(error)})
    ledger = root / 'authorized_frame_replacements' / 'ledger.json'
    records = json.loads(ledger.read_text()).get('frames', {}) if ledger.is_file() else {}
    # Include an existing reservation even after a partly completed commit.
    for key, record in records.items():
        if record.get('phase') != 'committed' or key in groups:
            saved = record['frame']
            current = groups.get(key)
            if current and (current['brief'] != saved['brief'] or
                    not {x['path'] for x in current['journals']}.issubset({x['path'] for x in saved['journals']})):
                blocked.append({'frame': key, 'reason': 'Reserved frame context changed'})
            else:
                groups[key] = saved
    refs = [root / 'storyboard' / name for name in ('character_master.jpg', 'location_master.jpg')]
    for ref in refs:
        if ref.is_symlink() or not image_valid(ref):
            blocked.append({'reference': str(ref.relative_to(root)), 'reason': 'Valid saved master reference required'})
    frames = sorted(groups.values(), key=lambda f: f['key'])
    fingerprint = hashlib.sha256(json.dumps({'frames': frames, 'aspect': manifest['aspect'],
        'references': [(p.name, sha(p) if p.is_file() else '') for p in refs]}, sort_keys=True).encode()).hexdigest()
    return {'job_id': root.name, 'frame_count': len(frames), 'frames': frames, 'blocked': blocked,
            'aspect': manifest['aspect'], 'references': [str(p) for p in refs], 'plan_sha256': fingerprint,
            'policy': 'One new request per frame. Existing generations may already have spent credits. Unknown submissions are never resent.'}


def settled_references(bridge, count, seconds=45):
    deadline, previous, stable = time.monotonic() + seconds, None, 0
    while time.monotonic() < deadline:
        assets = bridge.media_assets()
        signatures = {a['sig'] for a in assets if a.get('sig')}
        if len(assets) == count and len(signatures) == count and all(a.get('kind') == 'image' for a in assets):
            stable = stable + 1 if signatures == previous else 1
            previous = signatures
            if stable >= 3:
                return sorted(signatures)
        else:
            previous, stable = None, 0
        bridge._page.wait_for_timeout(750)
    raise RuntimeError('Reference gallery did not settle; no generation submitted')


def capture(provider, bridge, request, output, references):
    from .flow_image_transaction import capture as durable_capture
    return durable_capture(provider, bridge, request, output, references)


def recover_capture(provider_factory, provider, bridge, record, request, output, references):
    """Bounded download recovery; no fill, attach or submit action on retries."""
    current = provider
    try:
        for attempt in range(3):
            try:
                capture(current, bridge, request, output, references)
                return
            except Exception as error:
                if type(error).__name__ not in ('FlowBrowserClosedError', 'FlowBrowserClosedErrorVideo') or attempt == 2:
                    raise
                print('Download target closed; reconnecting to the SAME reserved project (no new generation).', flush=True)
                try: current.close()
                except Exception: pass
                current = provider_factory()
                bridge = current._ensure()
                bridge.ensure_project(record['project_name'], project_url=request['project_url'])
    finally:
        if current is not provider:
            try: current.close()
            except Exception: pass


def commit(root, record, output):
    frame = record['frame']
    request = json.loads(Path(str(output) + '.flow-request.json').read_text())
    if request.get('status') != 'downloaded' or request.get('media_sha256') != sha(output) or not image_valid(output):
        raise RuntimeError('Replacement does not have validated capture evidence')
    backup = output.parent / 'originals'
    backup.mkdir(exist_ok=True)
    targets = [root / frame['target']]
    originals = []
    for index, item in enumerate(frame['journals']):
        path = root / item['path']
        original_copy = backup / (str(index) + '.request.json')
        data = json.loads(path.read_text())
        if data.get('status') == 'superseded_by_authorized_replacement':
            if data.get('replacement_file') != str(output.relative_to(root)):
                raise RuntimeError('Journal already superseded by a different replacement')
        elif sha(path) != item['sha256']:
            raise RuntimeError('Original request changed since reservation')
        if not original_copy.exists():
            shutil.copy2(path, original_copy)
        media = Path(str(path)[:-len('.flow-request.json')])
        targets.append(media)
        originals.append((path, data, original_copy))
    # Validate every destination before modifying any original file.
    for target in targets:
        if target.is_symlink() or not target.resolve().is_relative_to(root):
            raise RuntimeError('Replacement destination is symlinked or outside job')
    for index, target in enumerate(dict.fromkeys(targets)):
        saved = backup / (str(index) + '.media')
        if target.is_file() and not saved.exists():
            shutil.copy2(target, saved)
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(target.name + '.replacement.tmp')
        shutil.copy2(output, temporary)
        os.replace(temporary, target)
    for path, data, original_copy in originals:
        data.update(status='superseded_by_authorized_replacement',
                    replacement_file=str(output.relative_to(root)),
                    replacement_target=frame['target'], replacement_sha256=sha(output),
                    original_request_backup=str(original_copy.relative_to(root)))
        write_json(path, data)


def regenerate(job, apply=False, max_replacements=7, provider_factory=None, *, _locked=False, allow_new=True):
    root = Path(job).resolve(strict=True)
    preview = plan(root)
    if not apply:
        return preview
    if type(max_replacements) is not int or not 1 <= max_replacements <= 100:
        raise ValueError('Replacement cap must be between 1 and 100')
    if preview['blocked']:
        return {**preview, 'status': 'blocked_before_generation'}
    from .production_lock import production_slot
    from .providers.flow_browser import FlowBrowserProvider, FlowBrowser
    from .flow_resume_safety import check_job
    provider_factory = provider_factory or FlowBrowserProvider
    from contextlib import nullcontext
    with (nullcontext() if _locked else production_slot(str(root))):
        preview = plan(root)
        if preview['blocked']:
            return {**preview, 'status': 'blocked_before_generation'}
        base = root / 'authorized_frame_replacements'
        base.mkdir(exist_ok=True)
        ledger_path = base / 'ledger.json'
        ledger = json.loads(ledger_path.read_text()) if ledger_path.is_file() else {'frames': {}}
        new = [f for f in preview['frames'] if f['key'] not in ledger['frames']]
        if new and not allow_new:
            return {**preview, 'status': 'replacement_permission_required'}
        other_ledger = root / 'flow_image_replacements' / 'ledger.json'
        other_count = len(json.loads(other_ledger.read_text()).get('reservations', {})) if other_ledger.is_file() else 0
        if len(ledger['frames']) + len(new) + other_count > max_replacements:
            return {**preview, 'status': 'cap_exceeded', 'reserved_count': len(ledger['frames'])}
        results = []
        for frame in preview['frames']:
            key = frame['key']
            record = ledger['frames'].get(key)
            if record is None:
                record = {'phase': 'preparing', 'frame': frame, 'plan_sha256': preview['plan_sha256'],
                    'project_name': 'AutoVideo-BoundedFrame-' + uuid.uuid4().hex,
                    'reference_hashes': {p: sha(p) for p in preview['references']}}
                ledger['frames'][key] = record
                write_json(ledger_path, ledger)
            if record['frame'] != frame:
                results.append({'frame': key, 'status': 'context_changed'}); continue
            output = base / key / 'replacement.jpg'
            output.parent.mkdir(exist_ok=True)
            journal = Path(str(output) + '.flow-request.json')
            provider = None
            print('Replacing ' + key + ' (one reserved request)...', flush=True)
            try:
                if any(sha(p) != h for p, h in record['reference_hashes'].items()):
                    raise RuntimeError('Master reference changed; reserved context is immutable')
                saved_request = json.loads(journal.read_text()) if journal.is_file() else {}
                captured = (saved_request.get('status') == 'downloaded' and image_valid(output)
                            and saved_request.get('media_sha256') == sha(output))
                if not captured:
                    provider = provider_factory()
                    bridge = provider._ensure()
                    if journal.is_file():
                        request = json.loads(journal.read_text())
                        if request.get('frame_key') != key or request.get('scope') != 'isolated_one_frame_one_request':
                            raise RuntimeError('Replacement journal context mismatch')
                        bridge.ensure_project(record['project_name'], project_url=request['project_url'])
                    elif record['phase'] == 'preparing':
                        if not record.get('project_url'):
                            bridge.create_isolated_image_project(record['project_name'])
                        else:
                            bridge.ensure_project(record['project_name'], project_url=record['project_url'])
                        project = FlowBrowser.normalize_project_url(bridge.current_project_url())
                        if not project:
                            raise RuntimeError('No valid replacement project URL')
                        if record.get('project_url') and record['project_url'] != project:
                            raise RuntimeError('Reserved replacement project changed')
                        old_projects = {FlowBrowser.normalize_project_url(json.loads((root / j['path']).read_text()).get('project_url'))
                                        for j in frame['journals']}
                        used_projects = {r.get('project_url') for k, r in ledger['frames'].items() if k != key}
                        if project in old_projects or project in used_projects:
                            raise RuntimeError('Replacement project is not isolated from original/other requests')
                        if not record.get('project_url') and bridge.media_assets():
                            raise RuntimeError('Replacement requires an empty project; no generation submitted')
                        record['project_url'] = project
                        write_json(ledger_path, ledger)
                        if bridge.detect_editor_mode() != 'agent':
                            raise RuntimeError('Journaled Flow Agent editor required')
                        bridge.select_agent_generation_type('image')
                        refs = preview['references']
                        if bridge.attach_agent_media(refs, reuse_existing=True) != len(refs):
                            raise RuntimeError('Master references not attached; no generation submitted')
                        baseline = settled_references(bridge, len(refs))
                        instruction = bridge._agent_image_instruction(frame['brief'], preview['aspect'], 1)
                        if len(instruction) > 4000 or not instruction.endswith(frame['brief']):
                            raise RuntimeError('Complete prompt exceeds Flow limit; no submission made')
                        bridge._fill_editor_box('agent_prompt_box', instruction)
                        request = {'kind': 'image', 'status': 'pending', 'frame_key': key,
                            'scope': 'isolated_one_frame_one_request', 'project_url': project,
                            'baseline': baseline, 'submitted_prompt': instruction,
                            'reference_hashes': record['reference_hashes'], 'signature': ''}
                        # Reservation and pending journal precede the single click.
                        write_json(journal, request)
                        record['phase'] = 'submission_uncertain'
                        write_json(ledger_path, ledger)
                        before = bridge.agent_submission_state(instruction)
                        if not before.get('composer_matches'):
                            raise RuntimeError('Prompt not retained in composer; request reservation retained')
                        bridge.submit_prepared_text_video('agent')
                        request['submission_acknowledged'] = bridge.wait_for_submission_ack(instruction, before)
                        write_json(journal, request)
                        if not request['submission_acknowledged']:
                            raise RuntimeError('Flow did not acknowledge the replacement prompt; reservation retained')
                    else:
                        raise RuntimeError('Submission uncertain without a journal; no repeat submission allowed')
                    if FlowBrowser.normalize_project_url(bridge.current_project_url()) != request['project_url']:
                        raise RuntimeError('Wrong replacement project')
                    # No prompt-string correlation here: only this isolated request
                    # can create a new asset after the verified reference baseline.
                    # A recorded image signature means generation already reached
                    # capture. Do not rerun the generic freshness wait after reopen.
                    if not request.get('signature'):
                        from .flow_image_transaction import wait_baseline
                        bridge.wait_for_agent_generation(before_assets=wait_baseline(request), timeout_s=360,
                            required_kind='image', approval='once', max_generation_credits=0,
                            image_request=None, service_busy_wait_s=90, service_busy_retries=1,
                            transactional_images=True)
                    recover_capture(provider_factory, provider, bridge, record, request, output, preview['references'])
                commit(root, record, output)
                record['phase'] = 'committed'
                record['media_sha256'] = sha(output)
                write_json(ledger_path, ledger)
                results.append({'frame': key, 'status': 'committed'})
            except Exception as error:
                record['last_error_type'] = type(error).__name__
                write_json(ledger_path, ledger)
                results.append({'frame': key, 'status': 'pending_or_blocked', 'error_type': type(error).__name__,
                                'message': str(error)[:500]})
            finally:
                if provider:
                    try: provider.close()
                    except Exception: pass
        remaining = check_job(root)
        result = {'addon_revision': 2, 'status': 'ready_to_resume' if remaining['safe_to_generate'] else 'replacement_pending',
                  'results': results, 'remaining_count': remaining['unresolved_count'],
                  'reserved_count': len(ledger['frames']), 'ledger': str(ledger_path)}
        write_json(base / 'report.json', result)
        return result

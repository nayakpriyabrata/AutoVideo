import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from PIL import Image
from engine import flow_music as music
from engine.production import read, save


class Browser:
    def __init__(self):
        self.page=NS(url=music.HOME,wait_for_timeout=lambda ms:None)
        self.submissions=0;self.downloads=[];self.assets=[];self.fail=False
    def start_session(self): pass
    def rows(self):return self.assets
    def submit(self,prompt):
        self.submissions+=1;self.page.url=music.HOME+'session/session-123'
        if self.fail:raise RuntimeError('Page closed after submission')
        self.assets=[{'key':'first','label':'Same title · version 1'}, {'key':'second','label':'Same title · version 2'}]
    def open(self,url):self.page.url=url
    def download(self,key,path):
        if not any(r['key']==key for r in self.assets):raise RuntimeError('Exact asset unavailable')
        self.downloads.append(key);Path(path).write_bytes(b'music')


def test_generate_once_two_versions_exact_download_and_rescan(tmp_path,monkeypatch):
    journal=music.new_request('Soft piano instrumental for dialogue',tmp_path)
    browser=Browser()
    with pytest.raises(ValueError,match='Approve'):music.operate(browser,journal,'generate')
    assert browser.submissions==0
    result=music.operate(browser,journal,'generate',approved=True,wait_seconds=0)
    assert len(result['candidates'])==2 and browser.submissions==1
    with pytest.raises(ValueError,match='already submitted'):music.operate(browser,journal,'generate',approved=True)
    monkeypatch.setattr(music,'validate_audio',lambda p:32)
    chosen=music.operate(browser,journal,'download',key='second')
    assert browser.downloads==['second'] and music.completed_track(journal)==chosen['path']
    music.operate(browser,journal,'download',key='second')
    assert browser.downloads==['second']
    assert music.operate(browser,journal,'scan',wait_seconds=0)['state']=='downloaded'
    assert browser.submissions==1


def test_timeout_keeps_submitted_journal_and_exact_session(tmp_path):
    journal=music.new_request('Original Odia devotional song about kindness',tmp_path)
    browser=Browser();browser.fail=True
    with pytest.raises(RuntimeError):music.operate(browser,journal,'generate',approved=True)
    assert read(journal)['state']=='submission-uncertain'
    assert music.session_url(read(journal)['session_url'])
    with pytest.raises(ValueError,match='already submitted'):music.operate(browser,journal,'generate',approved=True)
    music.operate(browser,journal,'scan',wait_seconds=0)
    assert browser.submissions==1
    with pytest.raises(ValueError):music.bind_session(journal,'https://flowmusic.app/session/other')


def test_changed_or_missing_candidate_never_downloads_different_song(tmp_path):
    journal=music.new_request('A quiet soft ambient instrumental',tmp_path);browser=Browser()
    music.operate(browser,journal,'generate',approved=True,wait_seconds=0)
    browser.assets=[{'key':'different','label':'Same title'}]
    with pytest.raises(RuntimeError):music.operate(browser,journal,'download',key='second')
    assert browser.downloads==[] and browser.submissions==1
    with pytest.raises(ValueError):music.operate(browser,journal,'download',key='different')
    assert read(journal)['state']=='candidates-ready'


def test_music_timeout_stops_browser_group_without_resubmission(monkeypatch):
    calls=[]
    class Process:
        pid=12345
        def communicate(self,timeout=None):
            calls.append(timeout)
            if len(calls)==1:raise music.subprocess.TimeoutExpired('browser',timeout)
            return '', ''
    monkeypatch.setattr(music.subprocess,'Popen',lambda *a,**k:Process())
    killed=[];monkeypatch.setattr(music.os,'killpg',lambda pid,sig:killed.append((pid,sig)))
    with pytest.raises(RuntimeError,match='Rescan'):music.run_browser('scan','saved-request.json')
    assert calls==[480,10] and killed==[(12345,music.signal.SIGTERM)]


def test_music_signin_wall_cannot_be_mistaken_for_ready_composer():
    auth=NS(count=lambda:1,nth=lambda i:NS(is_visible=lambda:True))
    browser=music.MusicBrowser(NS(get_by_role=lambda *a,**k:auth))
    with pytest.raises(RuntimeError,match='sign-in'):browser.composer()
    assert not music.session_url('https://user:password@flowmusic.app/session/other')


def test_saved_clips_survive_session_and_migration(tmp_path):
    from engine.studio_review import discover_clips
    folder=tmp_path/'my-clips';folder.mkdir()
    clip=folder/'first.mp4';clip.write_bytes(b'mp4')
    blocked=folder/'second.mp4';blocked.write_bytes(b'mp4')
    save(folder/'highlights.json',{'outputs':['/old/version/outputs/my-clips/first.mp4'],
        'blocked_outputs':[str(blocked)]})
    choices=discover_clips(tmp_path)
    assert {r['path'] for r in choices}=={str(clip),str(blocked)}
    assert next(r for r in choices if r['path']==str(blocked))['state']=='QC review required'


def test_script_review_has_no_approval_until_user_reviews(tmp_path,monkeypatch):
    from engine.studio_review import draft_script_cast,save_reviewed_plan
    import engine.providers.gemini_web as gemini
    reply={'narration':'Aanya helps a friend.', 'scenes':[{'text':'Aanya helps a friend.', 'visual_intent':'Aanya hands over a book.'}],
           'character_suggestions':[{'character_id':'aanya','role':'helper','reason':'Fits the story'}]}
    monkeypatch.setattr(gemini,'gemini_web_generate',lambda *a,**k:json.dumps(reply))
    review=draft_script_cast('A kind helper',45,'en',[{'id':'aanya','name':'Aanya','description':'Cheerful child with a yellow coat'}],'cartoon story')
    assert not review['plan']['approved'] and not review['plan']['rights']['adaptation_confirmed']
    with pytest.raises(ValueError):save_reviewed_plan(review['plan'],False,tmp_path)
    path=save_reviewed_plan(review['plan'],True,tmp_path)
    assert read(path)['approved']
    reply['character_suggestions'][0]['character_id']='unknown'
    with pytest.raises(ValueError,match='unknown cast'):draft_script_cast('Story',45,'en',[])


def test_reliable_music_records_browser_failure_and_uses_valid_offline_audio(tmp_path,monkeypatch):
    from engine.audio import music_provider as provider
    monkeypatch.setattr(provider,'pick_music',lambda mood:None)
    original=provider.subprocess.run
    monkeypatch.setattr(provider.subprocess,'run',lambda command,**kw:NS(returncode=1,stderr='AUTOVIDEO_MEDIA_SEARCH=browser_launch_failed') if 'engine.providers.web_media_helper' in command else original(command,**kw))
    # Real offline WAV creation + ffprobe verification; network is never used.
    result=provider.ensure_background_music('soft piano',str(tmp_path),mode='reliable')
    assert result['source']=='local-generated-instrumental' and music.validate_audio(result['path'])==32
    assert 'pixabay:' in result['warning'] and 'local:' in result['warning']


def test_card_shows_image_and_escapes_names_and_name_only_without_photo(tmp_path):
    from engine.studio_widgets import character_cards
    photo=tmp_path/'portrait.jpg';Image.new('RGB',(100,100),'blue').save(photo)
    from contextlib import nullcontext
    styles=[];labels=[]
    column=NS(container=lambda **kw:nullcontext())
    fake=NS(columns=lambda n:[column]*n,markdown=lambda text,**kw:styles.append(text),
        dialog=lambda *a,**kw:lambda fn:fn,button=lambda label,**kw:labels.append(label) or False)
    character_cards(fake,[
        {'id':'aanya','name':'Aanya <script>','references':[{'path':str(photo)}]},
        {'id':'none','name':'No photo','references':[]}])
    assert 'data:image/jpeg;base64' in styles[0]
    assert 'data:image/jpeg;base64' not in styles[1]
    assert labels==['Aanya <script>','No photo']
    assert all('<script>' not in style for style in styles) # names use native buttons, never unsafe HTML


def test_mini_cast_photos_frozen_across_download_only_resume(tmp_path,monkeypatch):
    from engine import mini_reels as reels
    from engine.content_library import CharacterLibrary
    from engine.providers.flow_browser import FlowRequestPending
    from tests.test_mini_reels import BRIEF
    monkeypatch.chdir(tmp_path)
    photo=tmp_path/'photo.png';Image.new('RGB',(50,50),'blue').save(photo)
    char=CharacterLibrary().create('Momo','A cheerful little monkey with big eyes and yellow shirt',reference_files=[photo],original_confirmed=True)
    calls=[]
    class Provider:
        def generate(self,shot,compiled,refs,out,**kw):
            calls.append(compiled)
            assert 'character-'+char['id'] in compiled['reference_paths'][0]
            if len(calls)==1:
                Path(out+'.flow-request.json').write_text('{}')
                raise FlowRequestPending('pending exact video')
            Path(out).write_bytes(b'video'*2000);return {'path':out}
        def close(self):pass
    monkeypatch.setattr(reels,'FlowBrowserProvider',Provider)
    monkeypatch.setattr(reels,'_audio_stream_present',lambda p:True)
    with pytest.raises(FlowRequestPending):
        reels.generate_flow_reel('test-cast-reel',brief=BRIEF,character_ids=[char['id']])
    Path(char['references'][0]['path']).unlink()
    result=reels.generate_flow_reel('test-cast-reel')
    assert result['status']=='complete' and calls[0]['prompt']==calls[1]['prompt']
    with pytest.raises(ValueError,match='frozen cast'):
        reels.generate_flow_reel('test-cast-reel',character_ids=[])


def test_new_controls_visible_and_source_mode_survives_rerun(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard,navigate
    import engine.content_library as library
    monkeypatch.setattr(library.CharacterLibrary,'list',lambda self:[])
    _,app=dashboard(tmp_path,monkeypatch)
    assert not app.exception
    assert any(w.label=='Choose saved characters (optional, up to three)' for w in app.multiselect)
    navigate(app,'CLIP STUDIO')
    assert any(w.label=='Show my channel logo on clips' for w in app.checkbox)
    next(w for w in app.checkbox if w.label=='Add soft background music').check().run()
    assert not app.exception
    music_source=next(w for w in app.radio if w.label=='Music source')
    assert 'Flow Music browser' in music_source.options
    music_source.set_value('Flow Music browser').run()
    assert not app.exception
    assert next(w for w in app.button if w.label=='✂️ Analyse and create clips').disabled
    navigate(app,'AI RECREATE')
    next(w for w in app.radio if w.label=='Recreation source').set_value('Local video file').run()
    assert any(w.label=='Local video path (WSL/Linux path)' for w in app.text_input)
    navigate(app,'MUSIC VIDEO')
    assert any(w.label=='Song source' for w in app.radio)
    navigate(app,'MINI REELS')
    assert any(w.label=='Choose saved characters (optional, up to three)' for w in app.multiselect)

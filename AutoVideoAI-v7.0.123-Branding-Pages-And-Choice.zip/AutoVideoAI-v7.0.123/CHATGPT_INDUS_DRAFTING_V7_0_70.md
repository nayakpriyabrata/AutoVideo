# AutoVideoAI v7.0.70 — ChatGPT Web and Indus AI drafting

## What changed

- **ChatGPT Web drafting (new).** Create → Drafting model → "ChatGPT Web (signed-in browser session)".
  It works like Gemini Web: a visible browser window with a saved profile. Sign in to ChatGPT once in that
  window; later drafts reuse the session. Each draft opens a fresh chat and returns when the reply stops changing.
  - Default cleanup, `delete-after-read`, uses a ChatGPT **temporary chat**, so the draft is not kept in your history.
  - Set "Draft chat cleanup" to `keep` to save the draft to your ChatGPT history.
  - Optional environment variables: `CHATGPT_WEB_LOGIN_WAIT` (seconds to wait for sign-in, default 300),
    `CHATGPT_WEB_RESPONSE_TIMEOUT` (default 300), `CHATGPT_WEB_BROWSER_MODE`, `CHATGPT_WEB_BROWSER_CHANNEL`,
    `CHATGPT_WEB_BROWSER_EXE`, `CHATGPT_WEB_CDP_URL`.
- **Indus AI drafting (new, optional).** Sarvam's Indus model through the Sarvam API. Create → Drafting model →
  "Indus AI · Sarvam". Set `SARVAM_API_KEY`. Model defaults to `sarvam-105b`; override with `SARVAM_SCRIPT_MODEL`.
  Reasoning is off so the output budget goes to the script; `SARVAM_MAX_TOKENS` (default 4096) caps the reply.
  Indus is also available as a job-level script provider.
- Cleanup control label is now "Draft chat cleanup" and applies to both Gemini Web and ChatGPT Web.

## Not yet verified

- The ChatGPT Web selectors were written for the current ChatGPT web app but have not been tested against a live
  session. If ChatGPT changes its page, the selectors in `engine/providers/chatgpt_web.py` (`SELECTORS`) need adjusting.
- Indus AI's Odia coverage is not confirmed by Sarvam's documentation. Check an Odia script draft before relying on it.
  Gemini Web or ChatGPT Web remain the defaults for Odia.

## Updating

- From 7.0.69: run `python3 ../AutoVideoAI-v7.0.70/tools/update_v769_to_v770.py .` (dry run), then add `--apply`.
- From 7.0.68: first run the 7.0.69 updater, then the 7.0.70 updater.
- Only code and documentation are replaced. Outputs, jobs, browser profiles, music, characters and channel profiles are untouched.

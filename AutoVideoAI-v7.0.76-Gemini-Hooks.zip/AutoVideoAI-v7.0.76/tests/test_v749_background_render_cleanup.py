import json
import time
from pathlib import Path


def test_background_clip_render_persists_progress(monkeypatch, tmp_path):
    review = tmp_path / 'broll-review.json'
    review.write_text(json.dumps({'candidates': [{
        'clip_output': str(tmp_path / 'one.mp4'), 'approved': True,
        'rights_reviewed': True,
    }]}), encoding='utf-8')

    def fake_apply(path, progress_cb=None):
        progress_cb('Rendering picture intervals', 50, 'clip 1/1 · 2/4 intervals complete')
        output = tmp_path / 'one-broll.mp4'
        output.write_bytes(b'video')
        progress_cb('Clip complete', 100, '1/1 · one-broll.mp4')
        return {'outputs': [str(output)]}

    import engine.broll
    import engine.clip_render_jobs as jobs
    monkeypatch.setattr(engine.broll, 'apply_clip_studio_review', fake_apply)
    assert jobs.start(str(review)) is True
    assert jobs.start(str(review)) is False
    deadline = time.time() + 5
    view = jobs.snapshot(str(review))
    while view['running'] and time.time() < deadline:
        time.sleep(.05)
        view = jobs.snapshot(str(review))
    assert view['state']['status'] == 'completed'
    assert view['state']['percent'] == 100
    assert view['state']['completed_clips'] == 1
    assert view['logs']


def test_flow_cleanup_plan_blocks_shared_project(tmp_path):
    from engine.storage_manager import _flow_cleanup_plan
    url = 'https://flow.google.com/project/11111111-2222-3333-4444-555555555555'
    first = tmp_path / 'first'; second = tmp_path / 'second'
    first.mkdir(); second.mkdir()
    (first / 'settings.json').write_text(json.dumps({'flow_project_url': url}))
    (second / 'request.json').write_text(json.dumps({'project_url': url + '/edit/abc'}))
    rows = [
        {'key': 'job:first', 'path': str(first)},
        {'key': 'job:second', 'path': str(second)},
    ]
    plan = _flow_cleanup_plan(rows, [rows[0]])
    assert plan['projects'] == [url]
    assert plan['deletable'] == []
    assert plan['shared'][url] == ['job:second']


def test_flow_cleanup_plan_deduplicates_unshared_project(tmp_path):
    from engine.storage_manager import _flow_cleanup_plan
    url = 'https://flow.google.com/project/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
    folder = tmp_path / 'job'; folder.mkdir()
    (folder / 'one.json').write_text(json.dumps({'url': url}))
    (folder / 'two.yaml').write_text('project: ' + url + '\n')
    row = {'key': 'job:one', 'path': str(folder)}
    plan = _flow_cleanup_plan([row], [row])
    assert plan['projects'] == [url]
    assert plan['deletable'] == [url]

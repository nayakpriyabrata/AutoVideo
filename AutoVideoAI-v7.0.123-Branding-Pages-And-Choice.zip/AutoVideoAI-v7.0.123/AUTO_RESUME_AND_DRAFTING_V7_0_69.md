# AutoVideo v7.0.69: automatic resume, channel setup and drafting models

## What changed

**1. Unattended automatic resume.** A production that stops on a recoverable Flow
interruption (browser page closed while downloading, temporary network loss,
Flow Agent at high demand) no longer waits for a manual Resume.

- Recoverable browser and network failures in strict Flow frame generation go back
  through the existing bounded recovery loop instead of ending the job as failed.
- When that loop runs out of retries, the job is recorded in `auto_resume.json`
  and a background supervisor in the Studio process resumes it after a growing
  delay: 2, 5, 10, 20, 30, then 60 minutes between attempts, up to 8 automatic
  resumes. The count restarts when saved media advances.
- Never retried automatically: sign-in or quota problems, approval or changed-media
  stops, a Flow request that was submitted but whose result is unknown (it may
  already have used credits), and any run where you turned automatic recovery off
  or chose to pause.
- The job monitor shows the minutes until the next attempt and the attempt number.

Limits: the supervisor runs only while Studio is open and the computer is awake.
If the laptop sleeps or the dashboard closes, nothing runs until it is back. Keep
the computer plugged in and set it not to sleep, and start the dashboard when you
leave the house.

**2. Channel name and logo in Create.**

- The channel name and logo prompts at the end of Create follow the language
  profiles chosen in Language editions and channel profiles (step 3).
- When every selected edition has a profile, those prompts are hidden. The form
  says the name and logo come from the profiles.
- For any edition without a profile, Create asks for its channel name and logo in
  that language, with an optional logo upload. Each entry is saved as that
  edition's channel profile when you create the production. A blank name means
  that edition has no channel mark.
- With a single language and no profile, the original channel name and logo fields
  are shown.

**3. Script drafting with more models.** The "Draft script + suggest saved cast"
button has a Drafting model selector:

- Gemini Web (signed-in browser session, unchanged, default)
- ChatGPT / OpenAI API (`OPENAI_API_KEY`)
- Gemini API (`GEMINI_API_KEY`)
- Groq (`GROQ_API_KEY`)
- xAI Grok (`XAI_API_KEY`)
- Ollama on this computer (`OLLAMA_BASE_URL`)

A provider without its key is shown as not configured and is disabled. Each
draft records the model that wrote it (`drafted_by`). The model name for each
provider comes from its existing environment setting (for example
`OPENAI_SCRIPT_MODEL`). ChatGPT in a signed-in browser session, like Gemini Web,
is not part of this release.

## Install

Apply to an installed 7.0.68 folder:

    python3 ../AutoVideoAI-v7.0.69/tools/update_v768_to_v769.py .            # dry run
    python3 ../AutoVideoAI-v7.0.69/tools/update_v768_to_v769.py . --apply

An install still on 7.0.67 must first run the 7.0.68 updater.
Stop the dashboard before applying, then restart it.
Outputs, jobs, browser profiles, music, characters and channel profiles are not touched.

## Verification

- 24 new tests (`tests/test_v769_*`): recovery classification and backoff, budget
  reset on progress, supervisor scheduling, job-thread state, Create channel
  branding on the real page, and drafting providers.
- Full suite: 1242 passed, 24 failed. The same 24 fail on the untouched 7.0.68 tree
  (environment-dependent card typography, upload picker and dashboard tests).
- Not tested live: Flow browser behaviour, the ChatGPT/OpenAI API call itself
  (needs your key), and a real overnight unattended run.

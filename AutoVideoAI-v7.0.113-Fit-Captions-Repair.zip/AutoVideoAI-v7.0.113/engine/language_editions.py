"""Render the reviewed language editions of a finished production.

The production's own final render stays the primary-language edition. Each
additional edition is built from the same clean visual master (picture only),
its exact reviewed narration, its timed cards and word-timed captions, and the
channel profile chosen in Create. Nothing here calls Gemini, Flow or any visual
generator, and nothing is overwritten: each export is a new file.

State lives in the job:
  production/language_editions.json       selections saved by Create (inputs)
  production/language_editions_render.json per-language render record (outputs)
"""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path

from . import finishing_studio as finish

STATE_NAME = 'language_editions.json'
RECORD_NAME = 'language_editions_render.json'


def _read(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding='utf8'))


def _label(code):
    return finish.LANGUAGES.get(code, code)


def _production_music(job_root):
    """Reuse the primary production's background track, with its recorded licence."""
    sound = _read(Path(job_root) / 'audio' / 'sound_plan.json', {}) or {}
    music = sound.get('music')
    if isinstance(music, str):
        music = {'path': music}
    if not isinstance(music, dict) or not music.get('path'):
        return None, ''
    path = Path(music['path'])
    if not path.is_file():
        return None, ''
    licence = ' · '.join(str(x) for x in (music.get('source'), music.get('license')) if x) or \
        'Production background track; licence recorded in the job provenance'
    return str(path), licence


def _record_path(job_root):
    return Path(job_root) / 'production' / RECORD_NAME


def _save_record(job_root, record):
    record['updated_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    finish._atomic_json(_record_path(job_root), record)


def requested_languages(job_root):
    """(source_language, additional_languages, state) for a job; empty when single-language."""
    state = _read(Path(job_root) / 'production' / STATE_NAME)
    if not state:
        return None, [], None
    source = str(state.get('source_language') or 'en')
    editions = list(dict.fromkeys(state.get('editions') or [source]))
    return source, [code for code in editions if code != source], state


#: Languages whose burned transcript is off by default (v7.0.109). Odia speech recognition is not reliable
#: enough to spell the reviewed script correctly, so a wrong-looking transcript is worse than none - the
#: edition still carries its cards, hooks, channel badge and narration.
TRANSCRIPT_OFF_BY_DEFAULT = ('or',)


def transcript_settings(state):
    """What each extra edition should do about burned captions.

    A job records this in ``production/language_editions.json`` under ``transcript``::

        {"default": true, "languages": {"or": false}}

    ``default`` applies to every extra language without its own entry. A job saved before 7.0.109 has no
    ``transcript`` key and gets the built-in default: every language with a transcript except Odia.
    """
    raw = (state or {}).get('transcript')
    if not isinstance(raw, dict):
        raw = {'default': True, 'languages': {code: False for code in TRANSCRIPT_OFF_BY_DEFAULT}}
    default = bool(raw.get('default', True))
    per = {}
    for code, value in (raw.get('languages') or {}).items():
        per[str(code)] = bool(value)
    return {'default': default, 'languages': per}


def transcript_for(state, code):
    """Whether this extra language burns a transcript, per the job's saved choice."""
    prefs = transcript_settings(state)
    return bool(prefs['languages'].get(str(code), prefs['default']))


def set_transcript(job_root, *, default=None, languages=None, save=True):
    """Record the transcript choice for a saved job and return the new preferences.

    ``default`` applies to every extra language and clears per-language overrides; ``languages`` is a mapping of
    ``code -> bool`` for the exceptions. Nothing is rendered here: the next edition render picks up the change,
    and because each render record stores what it burned, only the languages that changed render again.
    """
    job_root = Path(job_root).resolve()
    path = job_root / 'production' / STATE_NAME
    state = _read(path)
    if not state:
        raise ValueError('This job has no saved language editions (' + str(path) + ' does not exist), so there '
                         'is no transcript to change. Single-language jobs choose captions in Create '
                         '(Speech captions) or with `python3 cli.py v3 render <job> --caption-display none`.')
    source, extra, state = requested_languages(job_root)
    prefs = transcript_settings(state)
    if default is not None:
        prefs = {'default': bool(default), 'languages': {}}
    for code, value in dict(languages or {}).items():
        code = str(code)
        if code not in extra:
            raise ValueError('No extra ' + _label(code) + ' edition is selected for this job, so it has no '
                             'transcript of its own. Selected editions: ' + ', '.join(extra or ['none']))
        prefs['languages'][code] = bool(value)
    state['transcript'] = prefs
    if save:
        finish._atomic_json(path, state)
    return prefs


def transcript_plan(job_root):
    """``{code: bool}`` for every extra edition, plus the source of the decision (v7.0.109)."""
    source, extra, state = requested_languages(job_root)
    if state is None:
        return {'editions': {}, 'default': True, 'languages': {}, 'saved': False}
    prefs = transcript_settings(state)
    return {'editions': {code: transcript_for(state, code) for code in extra},
            'edited': {code: caption_signature(job_root, code)[1] == 'edited' for code in extra},
            'default': prefs['default'], 'languages': prefs['languages'],
            'saved': isinstance(state.get('transcript'), dict),
            'worksheet': str(Path(job_root) / 'production' / STATE_NAME)}


def _publish_copy(export, destination):
    """Copy a finished export into render/ atomically and verify the bytes."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.stem + '.copying.mp4')
    try:
        shutil.copy2(export, temporary)
        if finish._hash(temporary) != finish._hash(export):
            raise ValueError('Copy verification failed for ' + destination.name)
        os.replace(temporary, destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return str(destination)


def edition_render_name(job_root, code):
    """File name of a finished language edition inside the production's render/ folder."""
    return Path(job_root).name + '-' + code + '-edition.mp4'


def _mark_superseded(job_root, code, current):
    """Write ``superseded.json`` beside every older export of this language (v7.0.111).

    Every render keeps the previous video, which is deliberate - switching a transcript back and forth must never
    destroy a version the user already had. But a folder full of ``or-<stamp>.mp4`` files with no marker is how
    the user ended up playing yesterday's Odia video and reporting that the captions had not changed. The marker
    is a plain file next to the old export, so any file manager shows which one is current.
    """
    from . import edition_files
    current = str(current or '')
    marked = []
    for path in edition_files.scan_exports(job_root):
        if edition_files._export_language(path) != str(code):
            continue
        marker = path.parents[1] / 'superseded.json'
        if str(path) == current:
            marker.unlink(missing_ok=True)
            continue
        payload = {'superseded_by': current,
                   'superseded_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                   'note': ('This is not the current ' + _label(code) + ' video of this job. The current file is '
                            + (Path(current).name if current else 'not rendered yet') + '; this one is kept only '
                            'as the earlier version.')}
        if _read(marker) != payload:
            finish._atomic_json(marker, payload)
            marked.append(str(marker))
    return marked


def _sync_render_copies(job_root, record):
    """Keep every finished edition visible in render/. Idempotent; returns True when the record changed."""
    changed = False
    render_dir = Path(job_root) / 'render'
    for code, entry in (record.get('editions') or {}).items():
        if entry.get('status') != 'exported' or not entry.get('path'):
            continue
        export = Path(entry['path'])
        if not export.is_file():
            continue
        _mark_superseded(job_root, code, export)
        target = render_dir / edition_render_name(job_root, code)
        if target.is_file() and finish._hash(target) == entry.get('sha256'):
            if entry.get('render_copy') != str(target):
                entry['render_copy'] = str(target)
                changed = True
            continue
        try:
            entry['render_copy'] = _publish_copy(export, target)
            entry.pop('render_copy_error', None)
        except Exception as error:  # the export itself is still valid; report the copy problem
            # v7.0.111: a copy that could not be replaced (a player holds it open on Windows) used to stay in
            # render/ while the record still pointed at it - so the app played the previous video and the user
            # saw the old captions. Rename it out of the way (best effort) and stop advertising it.
            stale = ''
            try:
                if target.is_file() and finish._hash(target) != entry.get('sha256'):
                    stale = str(target.with_name(target.stem + '.superseded-' +
                                                 time.strftime('%Y%m%d-%H%M%S') + target.suffix))
                    os.replace(target, stale)
            except OSError:
                stale = ''
            # Whatever happens, stop advertising a file that is not this export.
            entry['render_copy'] = ''
            entry['render_copy_error'] = (str(error)[:200] +
                                          ('. The previous copy was renamed to ' + Path(stale).name +
                                           '; watch the export path instead.' if stale else
                                           '. The copy in render/ is still the previous video; watch the export '
                                           'path instead.'))
        changed = True
    return changed


def render_primary_branding(job_root, final_path, *, progress=None):
    """Give the primary-language master the profile intro and outro automatically.

    Only multi-language productions are touched, and only when the primary
    language's channel profile has an intro or outro. The picture, captions,
    music and any channel mark are already in the final master, so the logo and
    channel name are not applied a second time. Writes ``<job>-<lang>-branded.mp4``
    into render/ and records the outcome under ``primary`` in the render record.
    """
    job_root = Path(job_root).resolve()
    emit = progress or (lambda label, pct, detail='': None)
    source, _extra, state = requested_languages(job_root)
    if state is None:
        return {'status': 'not_requested'}
    profile_path = (state.get('profiles') or {}).get(source)
    profile = _read(profile_path, {}) if profile_path else {}
    assets = (profile or {}).get('assets') or {}
    if not (assets.get('intro') or assets.get('outro')):
        return {'status': 'no_intro_outro', 'language': source}
    final = Path(final_path)
    if not final.is_file():
        return {'status': 'failed', 'language': source, 'error': 'Primary master is missing: ' + final.name}
    record = _read(_record_path(job_root), {'schema_version': 1, 'editions': {}})
    emit('Adding intro and outro to the ' + _label(source) + ' master', 0, _label(source))
    try:
        plan_path = finish.create_plan(
            final, {source: profile_path}, languages=[source], output_root=job_root / 'primary_branding',
            source_rights='own_content', source_language=source, require_profiles=True,
            fit_narration=False, captions=False, use_clean_master=False, editorial=False)
        plan = _read(plan_path)
        edition = plan['editions'][source]
        # Only intro and outro: no narration, cards, captions, music, logo or channel name are added here.
        edition['assets'] = {k: v for k, v in (edition.get('assets') or {}).items() if k in ('intro', 'outro')}
        edition.update({'channel': {'name': '', 'display_name': ''}, 'narration': None, 'cards': [],
                        'words': None, 'music': None, 'speech_cards': None, 'hooks': None,
                        'educational': False, 'text_cards': False, 'hook_warning': ''})
        edition.pop('script', None)
        edition.pop('timing_source', None)
        plan['shared_music'] = None
        plan['shared_music_license'] = ''
        finish._atomic_json(plan_path, plan)
        finish.set_edition(plan_path, source, reviewed=True)
        exported = finish.render(plan_path, source, progress=lambda value: emit(
            'Adding intro and outro to the ' + _label(source) + ' master', 100 * float(value), _label(source)))
        target = job_root / 'render' / (job_root.name + '-' + source + '-branded.mp4')
        copied = _publish_copy(exported, target)
        report = {'status': 'exported', 'language': source, 'path': str(exported), 'render_copy': copied,
                  'sha256': finish._hash(exported), 'plan': str(plan_path),
                  'source_master': str(final), 'finished_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    except Exception as error:
        report = {'status': 'failed', 'language': source, 'error': str(error)[:800],
                  'source_master': str(final), 'finished_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    record['primary'] = report
    _save_record(job_root, record)
    return report


def record_narration_error(job_root, message):
    """Save why the extra language narrations were not prepared (7.0.95).

    The state file is the only place the job panel and the CLI look. Recording
    the reason there means an English-only result always names the cause instead
    of looking like the language selection was ignored.
    """
    job_root = Path(job_root).resolve()
    path = job_root / 'production' / STATE_NAME
    state = _read(path)
    if not state:
        return None
    state['narration_error'] = ' '.join(str(message or '').split())[:800]
    state['narration_error_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    finish._atomic_json(path, state)
    return path


def caption_signature(job_root, code):
    """What the burned caption text is made of for this language (v7.0.110).

    A saved correction in ``production/transcripts/<language>.json`` wins over the measured words, and its
    bytes are part of "is this video current?" - so fixing one spelling re-renders that edition (and only it).
    """
    from . import transcript_edit
    path = transcript_edit.edit_path(job_root, code)
    if not path.is_file():
        return '', 'measured'
    try:
        return finish._hash(path), 'edited'
    except OSError:
        return '', 'measured'


def _bundle_is_current(job_root, code, bundle, entry, *, verify=True, transcript=None, captions_sha=None):
    """A finished export that still matches the reviewed narration and its bytes.

    ``verify=False`` only checks that the file exists. The dashboard passes it so a
    panel rerun does not re-hash every exported video; the renderer always verifies.

    7.0.109: ``transcript`` is what the job now asks for. A video burned with a transcript when the job no
    longer wants one is out of date, and so is the reverse - which is what makes "re-render without the
    transcript, and later again with it" work without re-recording anything.
    """
    if not bundle or entry.get('status') != 'exported' or entry.get('audio_sha256') != bundle.get('audio_sha256'):
        return False
    if transcript is not None and bool(entry.get('captions', True)) != bool(transcript):
        return False
    if captions_sha is not None and str(entry.get('caption_words_sha256') or '') != str(captions_sha):
        return False
    export = Path(entry.get('path') or '')
    if not bool(entry.get('path')) or not export.is_file():
        return False
    return True if not verify else finish._hash(export) == entry.get('sha256')


def _visual_master(job_root, *, verify=True):
    """The approved clean picture for the editions, or (None, reason)."""
    record = _read(Path(job_root) / 'production' / 'visual_master.json')
    if not record or not record.get('path'):
        return None, ('The clean visual master (production/visual_master.json) was not created by this render. '
                      'It is written by the FFmpeg staging render; a MoviePy fallback or an interrupted render does '
                      'not create it. Use "Build a picture-only master from the finished video" in the job panel, '
                      'or render the production again with FFmpeg available.')
    visual = Path(record['path'])
    if not visual.is_file():
        return None, 'The clean visual master is missing from render/. Render this production again.'
    if verify and finish._hash(visual) != record.get('sha256'):
        return None, 'The clean visual master changed after the render. Render this production again.'
    return visual, ''


def ensure_visual_master(job_root, *, allow_recovered_picture=False, progress=None):
    """Build a picture-only master when the render never wrote one (7.0.95).

    The preferred master is the silent staged picture. When a production rendered
    through the MoviePy fallback, or an older job has no ``visual_master.json``,
    the only picture available is the finished primary master. That file already
    carries the primary edition's burned captions, text cards and channel mark,
    so reusing it is **opt-in**: an edition built on it would inherit English
    captions. Nothing is generated here and no credits are used.

    Returns ``{'status': 'present'|'recovered'|'refused'|'not_requested', ...}``.
    """
    job_root = Path(job_root).resolve()
    emit = progress or (lambda label, pct, detail='': None)
    _source, extra, state = requested_languages(job_root)
    if not extra:
        return {'status': 'not_requested'}
    visual, reason = _visual_master(job_root)
    if visual is not None:
        return {'status': 'present', 'path': str(visual)}
    if not allow_recovered_picture:
        return {'status': 'refused', 'reason': reason}
    render_dir = job_root / 'render'
    primary = next((p for p in (render_dir / (job_root.name + '-final-broll.mp4'),
                                render_dir / (job_root.name + '-final.mp4')) if p.is_file()), None)
    if primary is None:
        return {'status': 'refused', 'reason': 'No finished primary master in render/ to copy the picture from.'}
    target = render_dir / 'visual-master.mp4'
    emit('Building a picture-only master from the finished video', 0, job_root.name)
    from .render.ffmpeg_renderer import ffmpeg_exe
    temporary = target.with_name('visual-master.pending.mp4')
    command = [ffmpeg_exe(), '-y', '-hide_banner', '-loglevel', 'error', '-i', str(primary),
               '-map', '0:v:0', '-an', '-c:v', 'copy', '-movflags', '+faststart', str(temporary)]
    try:
        import subprocess
        result = subprocess.run(command, capture_output=True, text=True, timeout=1800)
        if result.returncode or not temporary.is_file() or not temporary.stat().st_size:
            temporary.unlink(missing_ok=True)
            return {'status': 'refused',
                    'reason': 'Could not copy the picture: ' + (result.stderr or 'FFmpeg failed')[-400:]}
        os.replace(temporary, target)
    except Exception as error:  # never leave a half-written master behind
        temporary.unlink(missing_ok=True)
        return {'status': 'refused', 'reason': str(error)[:400]}
    record = {'path': str(target), 'sha256': finish._hash(target),
              'contains': 'picture copied from the finished primary master; it may still contain the '
                          'burned captions, text cards and channel mark of that edition',
              'recovered': True, 'recovered_from': str(primary),
              'created_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    finish._atomic_json(job_root / 'production' / 'visual_master.json', record)
    emit('Picture-only master recovered from the finished video', 100, job_root.name)
    return {'status': 'recovered', 'path': str(target), 'contains': record['contains']}


def edition_diagnosis(job_root, *, verify=True):
    """Why each selected language did or did not render, in plain words (7.0.95).

    Read-only. Used by the Create/Queue job panel and by
    ``python3 cli.py v3 language-outputs <job> --explain`` so an English-only
    result always names the language and the one action that unblocks it.
    ``verify=False`` skips byte hashing for a fast panel refresh.
    """
    job_root = Path(job_root).resolve()
    source, extra, state = requested_languages(job_root)
    if state is None:
        return {'status': 'not_requested', 'source_language': 'en', 'editions': {},
                'message': 'No language editions were selected for this job; only one video is expected.'}
    record = _read(_record_path(job_root), {'editions': {}}) or {'editions': {}}
    bundles = state.get('bundles') or {}
    visual, visual_reason = _visual_master(job_root, verify=verify) if extra else (None, '')
    editions = {}
    for code in extra:
        entry = (record.get('editions') or {}).get(code, {})
        bundle = bundles.get(code)
        want_transcript = transcript_for(state, code)
        burned = bool(entry.get('captions', True))
        caption_sha, caption_source = caption_signature(job_root, code)
        if (entry.get('status') == 'exported'
                and _bundle_is_current(job_root, code, bundle, entry, verify=verify, transcript=want_transcript,
                                       captions_sha=caption_sha)):
            editions[code] = {'status': 'exported', 'path': entry.get('path'),
                              'render_copy': entry.get('render_copy'),
                              'transcript': burned, 'transcript_source': caption_source,
                              'message': _label(code) + ' edition is exported '
                                         + ('with its transcript.' if burned else 'without a transcript.'),
                              'warning': entry.get('warning') or entry.get('cards_warning') or ''}
            continue
        if bundle is None:
            editions[code] = {'status': 'needs_narration', 'transcript': want_transcript,
                              'message': _label(code) + ' has no reviewed narration prepared for this job, so it '
                                                         'cannot be rendered. The English voice is never reused.',
                              'next_action': 'Create step 4: prepare the language scripts, generate all selected '
                                             'voices, review them and reuse that exact batch. Existing jobs can '
                                             'prepare the same batch from Jobs & Recovery > Speech batches.'}
            continue
        if visual is None:
            editions[code] = {'status': 'needs_picture', 'message': visual_reason,
                              'transcript': want_transcript,
                              'next_action': 'Render the production again, or build the picture-only master in the '
                                             "job panel (it may include the burned captions of the primary edition)."}
            continue
        if entry.get('status') == 'failed' or entry.get('error'):
            # Narration and picture are both present; the render itself failed.
            detail = str(entry.get('error', ''))
            repair = ("Run the `refresh-cards` command quoted in the message above, then press "
                      '"Add primary intro/outro and render pending language editions" again. It re-drafts '
                      "the cards only: no narration, no video, no Flow credits."
                      if 'refresh-cards' in detail else
                      'Fix the message above, then press "Add primary intro/outro and render pending '
                      'language editions".')
            editions[code] = {'status': 'failed', 'error': detail, 'transcript': want_transcript, 'transcript_source': caption_source,
                              'message': _label(code) + ' edition failed: ' + detail[:900],
                              'next_action': repair}
            continue
        editions[code] = {'status': entry.get('status') or 'pending',
                          'transcript': want_transcript, 'transcript_source': caption_source,
                          'message': _label(code) + ' narration is ready; the edition has not been rendered yet '
                                     + ('with its transcript.' if want_transcript else 'and a transcript is '
                                        'switched off for it.'),
                          'next_action': 'Press "Add English intro/outro and render pending language editions".'}
    ready = sum(1 for row in editions.values() if row['status'] == 'exported')
    if not extra:
        status = 'single_language'
    elif ready == len(extra):
        status = 'exported'
    elif ready:
        status = 'partial'
    else:
        status = 'not_rendered'
    message = ''
    if status == 'single_language':
        message = ('Only one language was selected, so only one video is expected. Add Hindi and/or Odia in '
                   'Create step 1 to produce the other editions.')
    return {'status': status, 'source_language': source, 'editions': editions, 'message': message,
            'selected': [source] + extra, 'bundles_prepared': sorted(bundles),
            'transcript': transcript_plan(job_root),
            'narration_error': state.get('narration_error', ''),
            'visual_master': {'ready': visual is not None, 'reason': visual_reason},
            'record': str(_record_path(job_root))}


def caption_evidence(job_root, code, entry, *, measure=False):
    """What the *current export* actually shows, and whether that contradicts the job (v7.0.113).

    Returns ``{'looks_like_text': bool|None, 'source': ..., 'detail': str, 'disputed': bool}``.

    A record can be wrong about a file - and in the field it was: the plan said ``captions: false``, the file had
    captions, because the narration-fit step re-enabled them. So when the job asks for no transcript, the export's
    own picture is the evidence: the detections recorded at render time, or, with ``measure=True``, a fresh
    sampling of the file.
    """
    path = Path(str(entry.get('path') or ''))
    result = {'looks_like_text': None, 'source': '', 'detail': '', 'disputed': False}
    if not path.is_file():
        return result
    detected = entry.get('captions_detected') or {}
    if detected.get('checked') and not measure:
        result.update(looks_like_text=bool(detected.get('looks_like_text')), source='recorded',
                      detail=str(detected.get('detail') or ''))
        return result
    if measure:
        try:
            from .render.caption_check import probe
            fresh = probe(path)
            if fresh.get('checked'):
                result.update(looks_like_text=bool(fresh.get('looks_like_text')), source='measured now',
                              detail=str(fresh.get('detail') or ''))
                return result
        except Exception:
            pass
    if detected.get('checked'):
        result.update(looks_like_text=bool(detected.get('looks_like_text')), source='recorded',
                      detail=str(detected.get('detail') or ''))
    return result


def _captions_contradict(job_root, code, entry, *, wants, measure=False):
    """True when this export must be rendered again because it shows the wrong thing.

    Two pieces of evidence, in order: the export's own provenance (``captions_burned``) and its picture. The job's
    wish is the reference. A file that was already re-rendered once and still disagrees is not re-rendered again
    for ever: it is marked ``captions_disputed`` and explained instead.
    """
    if entry.get('status') != 'exported' or entry.get('captions_disputed'):
        return False
    # Measuring costs a few frame reads, so it is only done when this job asks for NO transcript - that is the
    # direction nobody can see from the record alone, and the one the field report was about.
    evidence = caption_evidence(job_root, code, entry, measure=bool(measure) and not wants)
    shown = evidence['looks_like_text']
    if shown is None:
        # No picture evidence yet: fall back to what the export recorded it burned.
        from . import finishing_studio as finish
        prov = _read(Path(str(entry.get('path') or '')).with_suffix('.provenance.json'), {}) or {}
        if 'captions_burned' in prov:
            shown = bool(prov.get('captions_burned'))
    return shown is not None and bool(shown) != bool(wants)


def render_job_editions(job_root, *, progress=None, fit_policy=None):
    """Render every pending additional edition. Returns a status report; never silently English.

    Status values: ``not_requested`` (no language state), ``single_language``,
    ``exported`` (all editions current), ``partial`` or ``failed`` (see ``editions``).

    7.0.95: one language can no longer block the others. A missing narration, a
    rejected plan or a failed render is recorded for that language only, and the
    remaining editions are still attempted. Recoverable review mismatches (a
    batch prepared without text cards, or without its points file) are reported
    as warnings on the edition instead of stopping every language.
    """
    job_root = Path(job_root).resolve()
    emit = progress or (lambda label, pct, detail='': None)
    source, extra, state = requested_languages(job_root)
    if state is None:
        return {'status': 'not_requested', 'editions': {}}
    if not extra:
        return {'status': 'single_language', 'editions': {}}

    bundles = state.get('bundles') or {}
    record = _read(_record_path(job_root), {'schema_version': 1, 'editions': {}})
    record.setdefault('editions', {})
    record['schema_version'] = 1

    wants = {code: transcript_for(state, code) for code in extra}
    captions = {code: caption_signature(job_root, code) for code in extra}
    pending = [code for code in extra if not _bundle_is_current(job_root, code, bundles.get(code),
                                                                record['editions'].get(code, {}),
                                                                transcript=wants[code],
                                                                captions_sha=captions[code][0])]
    # v7.0.113: a file can be "current" and still show the wrong thing. When the job asks for no transcript in a
    # language and the current export has captions burned into it, that language is pending again - which is how
    # the field job gets repaired by simply rendering it, instead of needing a hand-edited record.
    for code in extra:
        if code in pending:
            continue
        entry = record['editions'].get(code, {})
        if _captions_contradict(job_root, code, entry, wants=wants[code], measure=True):
            entry['repaint_reason'] = ('The current export of ' + _label(code) + ' shows burned captions although '
                                       'this job asks for no transcript in ' + _label(code) + '. It is rendered '
                                       'again, and the earlier file is kept.')
            pending.append(code)
    if not pending:
        if _sync_render_copies(job_root, record):
            _save_record(job_root, record)
        return {'status': 'exported', 'editions': record['editions'], 'record': str(_record_path(job_root))}

    visual, visual_reason = _visual_master(job_root)
    profiles = state.get('profiles') or {}
    music_path, music_licence = _production_music(job_root)
    failures = []
    for index, code in enumerate(extra):
        label = _label(code)
        if code not in pending:
            continue
        bundle = bundles.get(code)
        if bundle is None:
            message = (label + ' has no reviewed narration prepared for this job. The English voice is never used '
                              'as a fallback. Prepare its narration in Create step 4, then render again.')
            record['editions'][code] = {'status': 'needs_narration', 'error': message,
                                        'finished_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
            failures.append(label + ': ' + message)
            _save_record(job_root, record)
            continue
        if visual is None:
            record['editions'][code] = {'status': 'needs_picture', 'error': visual_reason,
                                        'finished_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
            failures.append(label + ': ' + visual_reason)
            _save_record(job_root, record)
            continue
        emit('Rendering ' + label + ' edition', 100 * index / max(1, len(extra)), label)
        # The previous export stays on disk in its own language_editions/<stamp>/exports/ folder, so switching
        # the transcript back and forth never destroys the version the user already had.
        entry = {'status': 'rendering', 'audio_sha256': bundle.get('audio_sha256'), 'captions': wants[code],
                 'caption_words_sha256': captions[code][0], 'caption_source': captions[code][1],
                 'channel': {}, 'started_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        reason = str((record['editions'].get(code) or {}).get('repaint_reason') or '')
        record['editions'][code] = entry
        if reason:
            entry['repaint_reason'] = reason
        _save_record(job_root, record)
        try:
            # One plan per language: a rejected plan for Hindi must not stop Odia.
            plan_path = finish.create_plan(
                visual, {code: profiles.get(code)}, languages=[code],
                output_root=job_root / 'language_editions', source_rights='own_content',
                shared_music=music_path, shared_music_license=music_licence,
                source_language=source, require_profiles=False, fit_narration=True, captions=wants[code],
                fit_policy=fit_policy)
            plan = json.loads(Path(plan_path).read_text(encoding='utf8'))
            # v7.0.110: burn the corrected transcript when the user saved one, from an immutable snapshot.
            if captions[code][1] == 'edited':
                from . import transcript_edit
                snapshot, report = transcript_edit.snapshot_for_plan(
                    job_root, code, Path(plan_path).parent / 'assets' / ('captions-' + code + '.json'))
                plan['editions'][code]['caption_words'] = {'path': str(snapshot),
                                                           'sha256': report['sha256']}
                plan['editions'][code]['caption_words_source'] = 'edited'
                finish._atomic_json(plan_path, plan)
            finish.set_edition(plan_path, code, reviewed=True)
            entry.update(plan=str(plan_path), channel=plan['editions'][code].get('channel', {}),
                         warning=(plan['editions'][code].get('cards_warning')
                                  or plan['editions'][code].get('hook_warning') or ''))

            def edition_progress(value, _index=index, _label=label):
                emit('Rendering ' + _label + ' edition', 100 * (_index + float(value)) / max(1, len(extra)), _label)
            exported = finish.render(plan_path, code, progress=edition_progress, fit_policy=fit_policy)
            entry.update(status='exported', path=str(exported), sha256=finish._hash(exported))
            entry.pop('repaint_reason', None)
            suppressed = str((_read(Path(str(exported)).with_suffix('.provenance.json'), {}) or {})
                             .get('captions_suppressed') or '')
            if suppressed:
                entry['warning'] = (entry.get('warning') + ' ' if entry.get('warning') else '') + suppressed
            # v7.0.112: look at the picture and record what it shows. The record and the plan can agree with each
            # other and still be wrong about the file; three sampled frames cannot be.
            try:
                from .render.caption_check import probe as caption_probe
                detected = caption_probe(exported)
                entry['captions_detected'] = {key: detected[key] for key in ('checked', 'ratio',
                                                                            'looks_like_text', 'detail')}
                # Only one direction is a warning. A caption is not on screen every second, so samples that
                # find nothing prove nothing - but text that IS visible while this job asked for none is
                # exactly the report that started this.
                if detected.get('checked') and detected.get('looks_like_text') and not wants[code]:
                    # Rendered again and the picture still disagrees: one more attempt is pointless. Say so, and
                    # stop treating this file as stale so a render does not loop for ever.
                    entry['captions_disputed'] = True
                    entry.pop('repaint_reason', None)
                    entry['warning'] = (entry.get('warning') + ' ' if entry.get('warning') else '') + \
                        ('This finished file shows burned text in its caption band, although this job asks for '
                         'no transcript in ' + _label(code) + ', and it was just rendered. ' +
                         str(detected.get('detail') or '') +
                         ' The file is kept and will not be re-rendered again automatically. Set the transcript '
                         'switch for ' + _label(code) + ' explicitly (job panel, or '
                         '`python3 cli.py v3 language-outputs <job> --transcript-off ' + code + '`) and render '
                         'once more.')
                elif detected.get('checked'):
                    entry.pop('captions_disputed', None)
            except Exception:      # a check must never stop an export
                entry['captions_detected'] = {'checked': False, 'detail': 'Not checked.'}
            entry.pop('error', None)
            _sync_render_copies(job_root, {'editions': {code: entry}})
        except Exception as error:  # keep the primary edition and every finished edition
            # 7.0.108: these messages now carry the numbers and the exact repair command, so they are kept
            # whole instead of being cut in the middle of the instructions.
            entry.update(status='failed', error=str(error)[:1500])
            failures.append(label + ': ' + str(error)[:900])
        entry['finished_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        _save_record(job_root, record)
    emit('Language editions finished', 100)

    statuses = {code: (record['editions'].get(code) or {}).get('status') for code in extra}
    if all(status == 'exported' for status in statuses.values()):
        overall = 'exported'
    elif any(status == 'exported' for status in statuses.values()):
        overall = 'partial'
    else:
        overall = 'failed'
    record['status'] = overall
    _save_record(job_root, record)
    return {'status': overall, 'editions': record['editions'], 'record': str(_record_path(job_root)),
            'error': '; '.join(failures)}


def render_language_outputs(job_root, *, progress=None, allow_recovered_picture=False, fit_policy=None):
    """Everything that makes a multi-language production complete, in order.

    1. the primary master with the profile intro/outro (skipped when already current);
    2. a picture-only master when the render never wrote one (only with
       ``allow_recovered_picture``, because that copy can carry the primary
       edition's burned captions);
    3. every pending extra edition, copied into render/.
    Returns ``{'primary': ..., 'editions': ..., 'diagnosis': ...}``. Never silently English.
    """
    job_root = Path(job_root).resolve()
    source, extra, state = requested_languages(job_root)
    if state is None:
        return {'primary': {'status': 'not_requested'}, 'editions': {'status': 'not_requested', 'editions': {}},
                'diagnosis': edition_diagnosis(job_root)}
    if extra:
        ensure_visual_master(job_root, allow_recovered_picture=allow_recovered_picture, progress=progress)
    render_dir = job_root / 'render'
    final = next((p for p in (render_dir / (job_root.name + '-final-broll.mp4'),
                              render_dir / (job_root.name + '-final.mp4')) if p.is_file()), None)
    if final is None:
        primary = {'status': 'failed', 'language': source,
                   'error': 'No final master in render/. Render the production first.'}
    else:
        previous = (_read(_record_path(job_root), {}) or {}).get('primary') or {}
        copy = previous.get('render_copy')
        if (previous.get('status') == 'exported' and previous.get('source_master') == str(final)
                and copy and Path(copy).is_file()):
            primary = previous
        else:
            primary = render_primary_branding(job_root, final, progress=progress)
    editions = render_job_editions(job_root, progress=progress, fit_policy=fit_policy)
    return {'primary': primary, 'editions': editions, 'diagnosis': edition_diagnosis(job_root)}

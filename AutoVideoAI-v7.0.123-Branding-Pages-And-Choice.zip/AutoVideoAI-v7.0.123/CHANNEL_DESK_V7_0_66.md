# AutoVideoAI v7.0.66 — Channel Desk and TTS-first batch

## Upgrade from v7.0.65

Stop production and close Studio. Extract the ZIP beside your existing `AutoVideoAI-v7` folder. From the existing folder:

```bash
python3 ../AutoVideoAI-v7.0.66/tools/update_v765_to_v766.py .
python3 ../AutoVideoAI-v7.0.66/tools/update_v765_to_v766.py . --apply
./dashboard.sh
```

The updater backs up changed code, preserves runtime data and refuses unexpected local edits. It supports v7.0.65 or an already applied v7.0.66. If you are still on v7.0.64, apply the included `update_v764_to_v765.py` from the **v7.0.65 archive first**, then apply this update. Do not run an older updater out of this new archive against an older installation: its release manifest differs. The Control Center deployment does not install code on your PC.

## TTS before cards — one action for all languages

In **Create → Reels & Long Videos**:

1. Approve the script in step 2, or import an approved script.
2. Select English, Hindi and/or Odia and the appropriate channel profiles in step 3. The production language is included in preparation.
3. In **4 · TTS first → timed cards for all selected languages**, choose the TTS provider.
4. Click **Prepare all selected TTS → then all language text cards**.
5. Listen to each audio, read each translation and inspect cards. Approve reuse of that exact batch, then create the production.

All selected voices/timings are prepared before any card request. This is a single user action with separate language requests. A failed TTS stage prevents the card phase. Retry reuses saved voices. Approved files are snapshotted into the job and reused. Changes to script, language selection, provider or imported audio create a separate preparation identity. TTS providers may have their own costs; no Flow visuals are generated in this preparation action. Timing can still be estimated if exact speech alignment is unavailable.

Alternatively enable automatic preparation during production; that also uses the all-voices-first sequence. Music-only/Silent skip speech preparation. Legacy saved jobs retain their existing card format.

## Channel manager workflow

Open **Content & Delivery → Channel Desk**:

- **Editorial brief:** optional Gemini Web suggestions for three titles, hooks and thumbnail design briefs grounded in your script. Suggestions are not automatically applied.
- **Watch & listen review:** choose the exact saved export; inspect opening/closing previews, contact sheet and audio/video measurements. Review notes acknowledge intentional warnings. Signoff is tied to the exact file.
- **Channel performance:** download the normalized CSV template and import your own metrics. Keep view counts and watch time on matching definitions and reporting windows. Previous imports are retained; the current analysis dataset is explicitly replaced by the next import.

For final delivery, export through Publishing Desk, review that **delivery MP4** in Channel Desk, then optionally attach its `review.json` in Publishing Desk. A source-master review cannot approve a different destination export. Signoff is local; it does not publish to a social account.

CLI review (no browser or credit-bearing generation):

```bash
python3 tools/channel_review.py review '/absolute/path/final.mp4' --destination youtube_long
python3 tools/channel_review.py metrics '/absolute/path/channel-metrics.csv' --min-views 100
```

Add `--silent` only for an intentionally silent export. Review files default to `outputs/channel-reviews` for CLI and the shared `channel_desk/reviews` folder for the GUI.

See `CHANNEL_MANAGER_AUDIT_V7_0_66.md` for the independent assessment, code evidence, implemented changes and remaining priorities. This release does not claim a permanent fix for every Google browser download failure or automatically certify publication quality.

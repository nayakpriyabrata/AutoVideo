# AutoVideoAI 7.0.14 — reviewed legacy shot-4 recovery

The supplied support report shows that Flow rewrote Debanshi shot 4’s closing
frame prompt and removed AVREQ metadata. Exact equality could not match it.
The reviewed candidate is the CLOSE FRAME for sharing scripts on the platform,
with macro-insert framing in the same tech studio. The OPEN FRAME for that scene
and all other scenes remain excluded.

This release applies a compatibility binding automatically during Resume,
restricted to the recorded request hash, original project, legacy marker,
submitted prompt prefix, and saved exact candidate evidence. It backs up the
journal first. The existing recovery adapter must re-read the exact bound prompt
from a live tile and validate the downloaded image. No Generate click is added.
Changed requests and unrelated jobs do not qualify. Accepted media is retained.

## Upgrade from 7.0.13

Stop AutoVideoAI before migration. From the extracted 7.0.14 directory:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.13 . --apply
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6
```

No separate binding script is required. This addresses the report’s specific
legacy request. It does not prove recovery on the user's live WSL browser, and
other legacy prompts that Flow rewrote remain subject to exact-asset review.

# v7.0.46 — persistent Clip Studio job history

Clip Studio has preserved each batch report under `clip-history/`, but the dashboard's old **Load saved highlights** button opened only the latest `highlights.json` alias from the manually entered output folder. Older generated clips were therefore difficult to find even though their reports and media still existed.

v7.0.46 adds a **Saved clip jobs** panel near the bottom of Clip Studio. It:

- scans the current output folder and `outputs/` for completed and partial Clip Studio batches;
- deduplicates a permanent historical report and its latest alias;
- lists batches newest-first with creation time, first highlight title, state and available clip count;
- loads the selected exact report without transcription, Gemini analysis, download or regeneration;
- uniquely rebases saved clip paths when an installation was moved to shared storage;
- reconnects the selected batch to its exact B-roll review through the v7.0.45 hash checks.

The existing button remains as **Load latest highlights from the current output folder**.

## Update

Stop Studio and the local runner. Extract the v7.0.46 ZIP beside the existing folder, then run from the existing installation:

```bash
python3 ../AutoVideoAI-v7.0.46/tools/update_v743_to_v746.py . --apply
cat VERSION
bash dashboard.sh
```

VERSION must say `7.0.46`. The updater accepts v7.0.43 through v7.0.45, creates a code backup, and preserves shared outputs, clip history, B-roll reviews/assets, Flow journals, profiles and settings.

## Reopen an old clip batch

1. Open **Content & Delivery → Clip Studio**.
2. Scroll below **Analyse and create clips**.
3. Expand **Saved clip jobs**.
4. Select the desired dated batch and click **Load selected clip job — no regeneration**.
5. To continue B-roll work, enable **Prepare related stock B-roll suggestions**, keep **Replace previous suggestions** off, and use the review panel below.

If the panel reports `0/N` available clips, the historical report exists but its referenced MP4 files are no longer present or cannot be uniquely located. The tool will not silently associate a different clip.

## Validation

57 focused regression tests passed, including historical batch discovery, duplicate-alias removal, migrated-path rebasing, Streamlit selection/loading, B-roll approval/recovery, and exact Flow video-download recovery.

"""Bounded progress heartbeat around a blocking provider operation."""
import threading,time
from contextlib import contextmanager
@contextmanager
def pulse(callback,stage,percent,info,interval=5):
    stop=threading.Event();started=time.monotonic()
    def emit():
        if callback:callback(stage,percent,f'{info} · elapsed {int(time.monotonic()-started)}s')
    def run():
        while not stop.wait(interval):
            try:emit()
            except Exception:pass
    emit();thread=threading.Thread(target=run,daemon=True)
    background=bool(callback and getattr(callback,'allow_background',True))
    if background:thread.start()
    try:yield
    finally:
        stop.set()
        if background:thread.join(timeout=1)

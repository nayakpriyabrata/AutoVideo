"""Cards anchored to measured speech tokens, never global duration scaling.

7.0.75: educational videos only (see render/educational_cards.is_educational). The
AI drafting provider writes a points series (2-8 points, spread across the whole
narration: each point is shown while it is spoken) and optional single-point cards
before or after the series. Other video types keep the one-line keypoint cards.
"""
import hashlib
import json
import math
import re
import time
import unicodedata
from pathlib import Path

from .render.educational_cards import SINGLE_KINDS, MIN_POINTS, MAX_POINTS, MAX_POINT_CHARS

EDUCATIONAL_VARIANT = 'educational-v3'
SERIES_MIN_SECONDS = 2.0
SERIES_HOLD_SECONDS = 1.0
BASE_PROMPT = (
    'You are an editorial video producer. Suggest sparse, useful transparent pop-up cards. '
    'Use the supplied narration words for exact anchors, not guessed seconds. '
    'Return JSON {"cards":[{"text":"short takeaway","start_word":0,"end_word":5}]}. '
    'Choose at most 18 cards, roughly one per 20–35 seconds, no overlapping anchors, '
    'each 2–6 seconds and at most 80 characters. Keep total coverage below 25%. '
    'Do not repeat entire subtitles. No invented facts, statistics, or generic numbered headings. '
    'Use the target language and exact zero-based word IDs. Cards should reinforce the opening promise, '
    'useful actions and payoff. Empty cards is allowed if none is useful.')


def educational_prompt(topic):
    return (
        'You are a senior editor for an educational YouTube channel. '
        f'The video topic is: {topic}. '
        'Write on-screen text for a narrated educational video using only the supplied narration words. '
        'Return JSON {"series":{"title":"...","points":[{"text":"...","start_word":0,"end_word":8}]},'
        '"cards":[{"kind":"takeaway","text":"...","start_word":0,"end_word":5}]}. '
        'series: the main points the narrator makes, in spoken order. Use as many points as the narration '
        'genuinely makes, from 2 to 8 (fewer for short videos). Each point is at most 60 characters, specific '
        'to the topic, and anchored to the words where the narrator makes that point. Points must not overlap '
        'and must spread across the whole video: the first point starts within the first quarter of the '
        'narration and the last point ends after the three-quarter mark. Series title: at most 60 characters. '
        'cards: optional single-point cards, kind "takeaway" (key idea), "tip" (practical action) or "warning" '
        '(common mistake). At most 4 cards, each at most 80 characters, lasting 2 to 6 seconds, and only in a '
        'moment before the first point or after the last point. '
        'Use the target language and exact zero-based word IDs. Use only facts stated in the narration: '
        'no invented facts, statistics or numbers. No greetings, no story or character narration. '
        'Empty lists are allowed if none fit.')


def _variant(educational, topic):
    if not educational:
        return ''
    return EDUCATIONAL_VARIANT + '|' + ' '.join(str(topic or '').split())


def fingerprint(audio, words, script, variant=''):
    h = hashlib.sha256()
    with Path(audio).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    h.update(json.dumps(words, sort_keys=True, ensure_ascii=False).encode())
    h.update(str(script).encode())
    if variant:
        h.update(variant.encode())
    return h.hexdigest()


def validate_words(words, duration):
    if not isinstance(words, list) or not words:
        raise ValueError('Speech cards require saved narration word timestamps')
    previous = 0.0
    for word in words:
        start, end = word.get('start'), word.get('end')
        if (not isinstance(word.get('word'), str) or not word['word'].strip()
                or any(type(v) not in (int, float) or not math.isfinite(v) for v in (start, end))
                or not 0 <= start < end <= duration + .1 or start < previous - .05):
            raise ValueError('Narration word timings are invalid or unordered')
        previous = start


def _word_span(row, words):
    first, last = row.get('start_word'), row.get('end_word')
    if any(type(i) is not int for i in (first, last)) or not 0 <= first <= last < len(words):
        raise ValueError('Card refers to an invalid speech word index')
    return first, last


def _anchor_one(row, words, duration, educational):
    """One drafted card. Raises ValueError only for this card; the caller drops it."""
    if not isinstance(row, dict):
        raise ValueError('card is not an object')
    first, last = _word_span(row, words)
    text = row.get('text')
    if not isinstance(text, str) or not 1 <= len(text.strip()) <= 80 or '\n' in text:
        raise ValueError('copy must be a short single line of at most 80 characters')
    if educational:
        kind = row.get('kind') or 'takeaway'
        if kind not in SINGLE_KINDS:
            raise ValueError('educational single cards must be takeaway, tip or warning')
    else:
        kind = 'keypoint'
    start, end = float(words[first]['start']), float(words[last]['end'])
    end = min(duration, max(end, start + 2.0, start + len(text.split()) / 2.8))
    # A long spoken phrase is clamped to a 6 s card rather than rejected.
    end = min(end, start + 6.0)
    if end - start < 1.5:
        raise ValueError('the spoken anchor is shorter than 1.5 seconds')
    return {'text': text.strip(), 'start': round(start, 3), 'end': round(end, 3),
            'start_word': first, 'end_word': last, 'kind': kind,
            'spoken_anchor': ' '.join(w['word'] for w in words[first:last+1])}


def anchor_cards(draft, words, duration, educational=False, report=None):
    """Single-line cards. Educational videos use takeaway, tip or warning kinds only.

    A card that cannot be placed on the narration is dropped and its reason is added to
    ``report`` (a list, when given). One bad card never stops the rest of the set.
    """
    validate_words(words, duration)
    rows = draft.get('cards') if isinstance(draft, dict) else None
    if rows is None:
        rows = []
    if not isinstance(rows, list) or len(rows) > 18:
        raise ValueError('Gemini must return at most 18 sparse cards')
    dropped = report if report is not None else []
    cards = []
    for index, row in enumerate(rows):
        try:
            cards.append(_anchor_one(row, words, duration, educational))
        except (ValueError, KeyError, IndexError, TypeError) as error:
            dropped.append({'index': index, 'reason': str(error)})
    cards.sort(key=lambda c: c['start'])
    # Overlapping cards: keep the earlier one and drop the later.
    kept = []
    for card in cards:
        if kept and card['start'] < kept[-1]['end'] + .15:
            dropped.append({'index': None, 'reason': 'overlaps an earlier card', 'text': card['text']})
            continue
        kept.append(card)
    cards = kept
    # Coverage: drop the longest cards until the set is sparse again.
    limit = max(6, duration * .30)
    while cards and sum(c['end'] - c['start'] for c in cards) > limit:
        longest = max(range(len(cards)), key=lambda i: cards[i]['end'] - cards[i]['start'])
        dropped.append({'index': None, 'reason': 'too much of the video covered', 'text': cards[longest]['text']})
        del cards[longest]
    return cards


def anchor_series(draft, words, duration):
    """Validate the educational points series. Returns None when the draft has no series."""
    series = draft.get('series') if isinstance(draft, dict) else None
    if not series:
        return None
    if not isinstance(series, dict):
        raise ValueError('The points series must be an object')
    title = series.get('title')
    if not isinstance(title, str) or not 1 <= len(title.strip()) <= MAX_POINT_CHARS or '\n' in title:
        raise ValueError(f'The series title must be one line of at most {MAX_POINT_CHARS} characters')
    points = series.get('points')
    if not isinstance(points, list) or not MIN_POINTS <= len(points) <= MAX_POINTS:
        raise ValueError(f'A points series needs {MIN_POINTS} to {MAX_POINTS} points')
    rows, previous_end = [], -1.0
    for point in points:
        if not isinstance(point, dict):
            raise ValueError('Each point must be an object')
        first, last = _word_span(point, words)
        text = point.get('text')
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= MAX_POINT_CHARS or '\n' in text:
            raise ValueError(f'Each point must be one short line of at most {MAX_POINT_CHARS} characters')
        start = float(words[first]['start'])
        end = max(float(words[last]['end']), start + SERIES_MIN_SECONDS)
        if start < previous_end - .05:
            raise ValueError('Series points overlap or are out of spoken order')
        previous_end = end
        rows.append({'text': text.strip(), 'start_word': first, 'end_word': last,
                     'start': round(start, 3), 'end': round(min(end, duration), 3)})
    if rows[0]['start'] > duration * .25 or rows[-1]['end'] < duration * .70:
        raise ValueError('The points must cover the whole video: start in the first quarter and end after 70%')
    return {'title': title.strip(), 'points': rows,
            'start': rows[0]['start'], 'end': round(min(duration, rows[-1]['end'] + SERIES_HOLD_SECONDS), 3)}


def series_segments(series):
    """Each point owns the time from its start until the next point starts."""
    out = []
    points = series['points']
    for i, point in enumerate(points):
        end = points[i+1]['start'] if i + 1 < len(points) else series['end']
        out.append({'index': i, 'count': len(points), 'title': series['title'], 'text': point['text'],
                    'points': points, 'start': point['start'], 'end': round(end, 3)})
    return out


def _overlaps(card, series):
    return card['start'] < series['end'] and series['start'] < card['end']


def _series_record(series):
    """Compact, re-validatable form saved in speech_cards.json."""
    return {'title': series['title'], 'points': [{'text': p['text'], 'start_word': p['start_word'],
                                                 'end_word': p['end_word']} for p in series['points']]}


def _draft_text(provider, system, user, cleanup):
    from .studio_review import _draft_generate
    return _draft_generate(provider or 'gemini-web', system, user, cleanup=cleanup)


LANGUAGE_NAMES = {'en': 'English', 'hi': 'Hindi (Devanagari script)', 'or': 'Odia (Oriya script, U+0B00-U+0B7F)'}


def _card_texts(draft):
    """Every piece of on-screen copy the drafter returned (cards, series title and points)."""
    texts = []
    for card in (draft or {}).get('cards') or []:
        if isinstance(card, dict):
            texts.append(str(card.get('text') or card.get('title') or ''))
    series = (draft or {}).get('series') or {}
    if isinstance(series, dict):
        texts.append(str(series.get('title') or ''))
        texts += [str(p.get('text') or p.get('title') or '') if isinstance(p, dict) else str(p)
                  for p in series.get('points') or []]
    return [t for t in texts if t.strip()]


RETRY_MAX_SECONDS = 90


def _drop_wrong_language(draft, language):
    """Remove cards, and the points series, whose copy is not in the edition's script.

    Returns (draft, dropped). English editions are returned unchanged.
    """
    if language == 'en' or not isinstance(draft, dict):
        return draft, []
    from .languages import script_language
    out = dict(draft)
    dropped, kept = [], []
    for index, card in enumerate(draft.get('cards') or []):
        text = card.get('text') if isinstance(card, dict) else None
        if isinstance(text, str) and text.strip() and script_language(text) != language:
            dropped.append({'index': index, 'reason': f'copy is not in {language}', 'text': text[:60]})
        else:
            kept.append(card)
    out['cards'] = kept
    series = draft.get('series')
    if isinstance(series, dict) and any(script_language(t) != language for t in _card_texts({'series': series})):
        out['series'] = None
        dropped.append({'index': None, 'reason': f'points series is not in {language}'})
    return out, dropped


def _wrong_language_texts(draft, language):
    """Copy that is not written in the edition's own script.

    English editions are not checked.  Odia and Hindi cards must contain at
    least one native-script character, so an English draft cannot ship inside
    an Odia video.
    """
    if language == 'en':
        return []
    from .languages import script_language
    return [t for t in _card_texts(draft) if script_language(t) != language]


def prepare(root, audio, words, script, duration, language, cleanup='delete-after-read', timing_source='measured',
            educational=False, topic='', provider='gemini-web'):
    from .production import save
    root = Path(root)
    target = root / 'production' / 'speech_cards.json'
    variant = _variant(educational, topic)
    key = fingerprint(audio, words, script, variant)
    if target.is_file():
        prior = json.loads(target.read_text(encoding='utf-8'))
        # A saved result that lost every card to the language check is retried, not reused.
        if prior.get('fingerprint') == key and (prior.get('cards') or not prior.get('dropped_cards')):
            anchor_cards(prior, words, duration, educational)
            if educational and prior.get('series'):
                anchor_series(prior, words, duration)
            return prior
    validate_words(words, duration)
    from .planning.script_engine import _extract_json
    indexed = [{'id': i, 'word': w['word'], 'start': w['start'], 'end': w['end']} for i,w in enumerate(words)]
    name = LANGUAGE_NAMES.get(language, language)
    user = (f'Language: {language} ({name})\nWrite every card, title and point in {name}. Do not write card copy in English '
            f'unless the language is English.\nMeasured duration: {duration:.3f}s\nReviewed script:\n{script}\n'
            'Timed narration words:\n'+json.dumps(indexed, ensure_ascii=False))

    def _draft(text):
        if educational:
            return _draft_text(provider, educational_prompt(topic), text, cleanup)
        from .providers.gemini_web import gemini_web_generate
        return gemini_web_generate(BASE_PROMPT, text, cleanup=cleanup)

    started = time.time()
    raw = _draft(user)
    save(target.with_name('speech_cards-draft.json'), {'response': raw, 'fingerprint': key, 'provider': provider})
    draft = _extract_json(raw)
    texts = _card_texts(draft)
    wrong = _wrong_language_texts(draft, language)
    # Retry once, only when the whole draft is in the wrong script and the first answer came back quickly.
    # A slow Gemini Web answer is not asked for again (that would double a multi-minute wait); partly wrong
    # copy is dropped instead, so the rest of the set is still used.
    if texts and len(wrong) == len(texts) and time.time() - started <= RETRY_MAX_SECONDS:
        correction = (f'\nCorrection: the previous draft wrote card text outside {name}. Rewrite every card, title and '
                      f'point in {name} script, keeping the same timing and word IDs.')
        raw = _draft(user + correction)
        save(target.with_name('speech_cards-draft.json'), {'response': raw, 'fingerprint': key, 'provider': provider,
                                                            'retry': 'language'})
        draft = _extract_json(raw)
    draft, language_dropped = _drop_wrong_language(draft, language)
    card_report = []
    cards = anchor_cards(draft, words, duration, educational, report=card_report)
    series = anchor_series(draft, words, duration) if educational else None
    dropped = 0
    if series:
        kept = [c for c in cards if not _overlaps(c, series)]
        dropped, cards = len(cards) - len(kept), kept
    result = {'schema_version': 3 if educational else 1, 'source': 'gemini-web-speech-anchors', 'fingerprint': key,
              'duration': duration, 'language': language, 'timing_source': timing_source,
              'review_required': True, 'educational': bool(educational), 'draft_provider': provider if educational else 'gemini-web',
              'series': _series_record(series) if series else None, 'dropped_overlapping_cards': dropped,
              'cards': cards, 'dropped_cards': card_report + language_dropped}
    for item in result['dropped_cards']:
        print('[Text cards] dropped one card: ' + str(item.get('reason')))
    save(target, result)
    return result


def render(root, audio, words, script, duration, width, height, style, educational=False, topic=''):
    path = Path(root) / 'production' / 'speech_cards.json'
    if not path.is_file():
        return None
    data = json.loads(path.read_text(encoding='utf-8'))
    variant = _variant(educational, topic)
    if data.get('fingerprint') != fingerprint(audio, words, script, variant):
        raise ValueError('Narration or timings changed after card drafting. Resume to refresh speech cards before rendering.')
    from .render.graphics import OverlayEvent, render_overlay_png
    from .render.educational_cards import render_card_png, render_series
    overlays = []
    cards = anchor_cards(data, words, duration, educational)
    series = anchor_series({'series': data['series']}, words, duration) if educational and data.get('series') else None
    if series:
        segments = series_segments(series)
        last = len(segments) - 1
        for seg in segments:
            target = Path(root) / 'render' / 'graphics' / f'speech-series-{seg["index"]:02d}.png'
            info = render_series(seg, target, int(width), int(height), style, active=seg['index'])
            if seg['count'] == 1:
                mode = 'pop'
            elif seg['index'] == 0:
                mode = 'open'
            elif seg['index'] == last:
                mode = 'close'
            else:
                mode = None
            info.update(kind='points', start=seg['start'], end=seg['end'], title=series['title'], anchor='top-left',
                        opacity=1, fade_in=.22 if seg['index'] == 0 else 0, fade_out=.22 if seg['index'] == last else 0)
            if mode:
                info['anim'] = mode
            overlays.append(info)
    for index, card in enumerate(cards):
        target = Path(root) / 'render' / 'graphics' / f'speech-card-{index:02d}.png'
        if educational:
            overlays.append(render_card_png(card, target, int(width), int(height), style=style))
            continue
        event = OverlayEvent('keypoint', card['start'], card['end'], card['text'], anchor='top-left')
        render_overlay_png(event, str(target), int(width), int(height), style=style)
        overlays.append(event.to_dict())
    return overlays


def prepare_edition(root, script, language, *, provider='auto', audio_path=None, cleanup='delete-after-read', draft_cards=True,
                    text_cards=True, educational=False, topic='', card_provider='gemini-web', hooks=False):
    """Reusable narration/card bundle for a reviewed language script or uploaded voice."""
    from .production import save, probe, digest
    from .languages import default_voice, language_pack
    from .audio.tts import synthesize_narration, _audio_to_mp3
    from .captions import get_word_timestamps_resilient
    language = language_pack(language).code
    if not str(script).strip():
        raise ValueError('Provide the reviewed script for this language')
    source_hash = fingerprint(audio_path, [], script) if audio_path else ''
    key = hashlib.sha256(json.dumps([script, language, provider, source_hash], ensure_ascii=False).encode()).hexdigest()[:24]
    folder = Path(root) / 'speech-editions' / language / key
    folder.mkdir(parents=True, exist_ok=True)
    audio, word_path = folder/'voice.mp3', folder/'words.json'
    if not audio.is_file():
        if audio_path:
            if Path(audio_path).suffix.lower() == '.mp3':
                import shutil
                shutil.copy2(audio_path, audio)
            else:
                _audio_to_mp3(str(audio_path), str(audio))
            source_words=Path(str(audio_path)+'.words.json')
            native=json.loads(source_words.read_text()) if source_words.is_file() else []
        else:
            result = synthesize_narration(script, default_voice(language), str(audio), provider=provider, language=language)
            native = result.get('words') or []
        if native:
            save(word_path, native)
            source_meta=Path(str(audio_path)+'.words.meta.json') if audio_path else None
            metadata=json.loads(source_meta.read_text()) if source_meta and source_meta.is_file() else {'timing_source': 'native-tts' if not audio_path else 'unverified'}
            save(str(audio)+'.words.meta.json', metadata)
    duration = float(probe(audio)['format']['duration'])
    if word_path.is_file():
        words = json.loads(word_path.read_text())
    else:
        words = get_word_timestamps_resilient(str(audio), script_text=script, language=language, audio_duration=duration) or []
        save(word_path, words)
    meta_path = Path(str(audio)+'.words.meta.json')
    meta = json.loads(meta_path.read_text()) if meta_path.is_file() else {}
    result = {'audio': str(audio), 'words': str(word_path), 'duration': duration, 'audio_sha256': digest(audio),
              'script': script, 'language': language, 'cards': [],
              'timing_source': meta.get('timing_source', meta.get('engine', 'unverified')), 'review_required': True,
              'text_cards': bool(text_cards), 'educational': bool(educational), 'topic': str(topic or ''),
              'card_provider': str(card_provider or 'gemini-web'), 'hooks': bool(hooks)}
    validate_words(words,duration)
    if draft_cards:
        result = complete_edition_cards(result,cleanup)
    else:
        save(folder/'narration.json', result)
    return result


def _bundle_flags_match(bundle, wanted):
    """Same card/hook/educational choices as the saved bundle. Legacy bundles (no flags) mean cards on, no hooks."""
    return (bool(bundle.get('text_cards', True)) == wanted['text_cards']
            and bool(bundle.get('educational', False)) == wanted['educational']
            and bool(bundle.get('hooks', False)) == wanted['hooks'])


def _bundle_matches(bundle, wanted):
    """Flags match and, when hooks were requested, the hook draft is ready."""
    return _bundle_flags_match(bundle, wanted) and (not wanted['hooks'] or bool(bundle.get('hooks_ready')))


def complete_edition_cards(bundle,cleanup='delete-after-read'):
    """Draft the language's cards (if text cards are on) and hooks (if requested) from its own reviewed narration.

    7.0.77: nothing is drafted when text cards are off. Hook failures are recorded in the bundle and never
    stop the batch; the edition then renders without hooks and says so.
    """
    from .production import digest,save
    audio=Path(bundle['audio']);folder=audio.parent
    if digest(audio)!=bundle['audio_sha256']:raise ValueError('Prepared narration changed; prepare TTS again')
    words=json.loads(Path(bundle['words']).read_text())
    topic=str(bundle.get('topic','') or '')
    if bundle.get('text_cards',True):
        cards=prepare(folder,audio,words,bundle['script'],bundle['duration'],bundle['language'],cleanup=cleanup,timing_source=bundle['timing_source'],
                      educational=bool(bundle.get('educational',False)),topic=topic,provider=bundle.get('card_provider') or 'gemini-web')
        result=dict(bundle,cards=cards['cards'])
    else:
        result=dict(bundle,cards=[])
    result['hooks_ready']=False;result['hooks_error']=''
    if bundle.get('hooks'):
        try:
            from .video_hooks import draft_hooks
            draft_hooks(folder,audio,words,bundle['script'],bundle['duration'],bundle['language'],topic=topic,cleanup=cleanup)
            result['hooks_ready']=True
        except Exception as error:
            result['hooks_error']=str(error)[:300]
    save(folder/'bundle.json',result)
    return result


def batch_key(script,source_language,languages,provider,audio_path=''):
    from .production import digest
    payload=[script.strip(),source_language,sorted(set(languages)),provider,digest(audio_path) if audio_path else '']
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False).encode()).hexdigest()[:24]


def localization_key(script,source_language,languages):
    payload=[script.strip(),source_language,sorted(set(languages))]
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False).encode()).hexdigest()[:24]


def prepare_localized_scripts(root,source_script,source_language,languages,*,cleanup='delete-after-read',progress=None):
    """Create language editions from one approved master without making audio or visuals."""
    from .production import save
    from .languages import language_pack,script_language
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    editions=list(dict.fromkeys(language_pack(x).code for x in languages))
    source_language=language_pack(source_language).code
    if not source_script.strip() or not editions:raise ValueError('Approve a master script and select at least one output language')
    if source_language not in editions:raise ValueError('The master language must remain one of the output editions')
    expected=localization_key(source_script,source_language,editions)
    target=root/'localized_scripts.json'
    if target.is_file():
        saved=json.loads(target.read_text(encoding='utf-8'))
        if saved.get('fingerprint')==expected and all(saved.get('scripts',{}).get(x,'').strip() for x in editions):return saved
    emit=progress or (lambda *args:None)
    scripts={source_language:source_script.strip()}
    for index,language in enumerate(x for x in editions if x!=source_language):
        emit('Localizing the approved master script',int(95*index/max(1,len(editions)-1)),language.upper())
        raw=gemini_web_generate(
            'Localize the approved master narration for a separate language edition. Preserve every fact, name, '
            'claim, story beat and ordering. Write natural spoken language rather than a literal translation. '
            'Do not add or remove ideas. Keep approximately the same spoken duration. Return JSON '
            '{"narration":"..."}. This draft will be reviewed by a human before TTS.',
            f'Source language: {source_language}\nTarget: {language}\nApproved master narration:\n{source_script}',cleanup=cleanup)
        translated=_extract_json(raw)
        narration=translated.get('narration','') if isinstance(translated,dict) else ''
        if not isinstance(narration,str) or not narration.strip():raise ValueError('Localization did not return narration for '+language.upper())
        if script_language(narration)!=language:raise ValueError('Localized script language differs from '+language.upper())
        scripts[language]=narration.strip()
    result={'schema_version':1,'phase':'scripts_approved' if editions==[source_language] else 'review_scripts','fingerprint':expected,'source_language':source_language,
            'source_script':source_script.strip(),'editions':editions,'scripts':scripts,'reviewed':{source_language:True}}
    save(target,result);emit('Localized scripts ready for review',100)
    return result


def approve_localized_scripts(root,state,edited_scripts,approvals):
    """Save the exact scripts the user reviewed; later TTS must consume this snapshot."""
    from .production import save
    from .languages import script_language
    root=Path(root);editions=state.get('editions',[]);source_language=state.get('source_language')
    expected=localization_key(state.get('source_script',''),source_language,editions)
    if state.get('fingerprint')!=expected:raise ValueError('Master script or language selection changed; prepare localization again')
    scripts={}
    for language in editions:
        value=str(edited_scripts.get(language,'')).strip()
        if not value:raise ValueError('The '+language.upper()+' narration is empty')
        if language!=source_language and script_language(value)!=language:raise ValueError('Reviewed script language differs from '+language.upper())
        if not approvals.get(language):raise ValueError('Review and approve the '+language.upper()+' narration')
        scripts[language]=value
    result=dict(state,phase='scripts_approved',scripts=scripts,reviewed={x:True for x in editions})
    save(root/'localized_scripts.json',result)
    return result


# Unicode blocks a reviewed narration must use for its language (7.0.80).
NATIVE_SCRIPT_RANGES = {'or': (0x0B00, 0x0B7F), 'hi': (0x0900, 0x097F)}


def foreign_script_words(text, language):
    """Words that mix or corrupt scripts inside a native-language narration (7.0.80).

    A 7.0.79 Odia narration contained 'βαğβαğ' in place of an Odia word, which the TTS reads as noise.
    Flagged: any letter from a non-Latin foreign script (Greek, Cyrillic, ...), or Latin letters mixed into
    a native word. Pure Latin words (brand names, loanwords such as 'Instagram') are allowed.
    Digits, punctuation (including the danda) and marks in the native script are ignored.
    """
    code = str(language or '').lower()
    if code not in NATIVE_SCRIPT_RANGES:
        return []
    low, high = NATIVE_SCRIPT_RANGES[code]
    bad = []
    for word in re.findall(r"\S+", str(text or '')):
        native = latin = foreign = False
        for c in word:
            if not c.isalpha():
                continue
            if low <= ord(c) <= high:
                native = True
            elif c.isascii() or 'LATIN' in unicodedata.name(c, ''):
                latin = True
            else:
                foreign = True
        if foreign or (native and latin):
            bad.append(word.strip('.,;:!?\'"’‘“”()[]{}।॥'))
    return bad


def prepare_batch(root,source_script,source_language,languages,*,provider='auto',audio_path=None,cleanup='delete-after-read',progress=None,localized_scripts=None,
                  text_cards=True,educational=False,topic='',card_provider='gemini-web',hooks=False):
    """One action, two phases: every language voice first, then separate card requests."""
    from .production import save
    from .languages import language_pack
    root=Path(root);editions=list(dict.fromkeys(language_pack(x).code for x in languages))
    source_language=language_pack(source_language).code
    if not source_script.strip() or not editions:raise ValueError('Approve a script and select at least one language')
    if localized_scripts is None:
        localized=prepare_localized_scripts(root,source_script,source_language,editions,cleanup=cleanup,progress=progress)
        scripts=localized['scripts']
    else:
        scripts={language:str(localized_scripts.get(language,'')).strip() for language in editions}
        if any(not scripts[x] for x in editions):raise ValueError('Every selected language needs a reviewed localized script before TTS')
        if scripts.get(source_language)!=source_script.strip():raise ValueError('Reviewed master script changed; prepare the language scripts again')
    # 7.0.80: stop before any TTS call when a reviewed narration has words in the wrong script.
    for language in editions:
        wrong = foreign_script_words(scripts[language], language)
        if wrong:
            raise ValueError(language_pack(language).label + ' narration has words outside its script: ' + ', '.join(wrong[:8])
                             + '. Correct them in step 4 and save; no TTS was started.')
    scripts_hash=hashlib.sha256(json.dumps(scripts,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    state={'source_language':source_language,'source_script':source_script,'editions':editions,'scripts_sha256':scripts_hash,'bundles':{},'phase':'tts'}
    emit=progress or (lambda *args:None)
    # No text-card call can occur in this first loop.
    for index,language in enumerate(editions):
        script=scripts[language]
        emit('Preparing TTS and word timings',int(45*index/len(editions)),language.upper())
        state['bundles'][language]=prepare_edition(root,script,language,provider=provider,audio_path=audio_path if language==source_language else None,cleanup=cleanup,draft_cards=False,
                                                   text_cards=text_cards,educational=educational,topic=topic,card_provider=card_provider,hooks=hooks)
        save(root/'batch.json',state)
    state['phase']='cards';save(root/'batch.json',state)
    for index,language in enumerate(editions):
        emit('All voices ready · drafting timed cards',50+int(45*index/len(editions)),language.upper())
        state['bundles'][language]=complete_edition_cards(state['bundles'][language],cleanup)
        save(root/'batch.json',state)
    state['phase']='ready_for_review';save(root/'batch.json',state);emit('All selected language bundles ready',100)
    return state


def attach_prepared_batch(job_root,batch):
    """Snapshot preflight assets into the job so later cleanup cannot break Resume."""
    import shutil
    from .production import save,digest
    job_root=Path(job_root);bundles={}
    if batch.get('phase')!='ready_for_review':raise ValueError('Finish all voices and cards first')
    for language,bundle in batch['bundles'].items():
        source=Path(bundle['audio']).parent
        if digest(bundle['audio'])!=bundle['audio_sha256']:raise ValueError('Prepared voice changed')
        target=job_root/'speech-editions'/language/source.name
        if source.resolve()!=target.resolve():shutil.copytree(source,target,dirs_exist_ok=True)
        result=dict(bundle,audio=str(target/'voice.mp3'),words=str(target/'words.json'))
        validate_words(json.loads(Path(result['words']).read_text()),result['duration'])
        bundles[language]=result
    source_language=batch['source_language']
    if source_language not in bundles:raise ValueError('Include the production language in the batch')
    save(job_root/'production/prepared_speech.json',bundles[source_language])
    cards=Path(bundles[source_language]['audio']).parent/'production/speech_cards.json'
    save(job_root/'production/speech_cards.json',json.loads(cards.read_text()))
    return bundles


def prepare_selected_editions(root, source_script, source_language, settings, progress=None, *,
                              text_cards=True, hooks=False, educational=False, topic='', card_provider='gemini-web'):
    """Prepare selected language narration bundles before spending on visuals."""
    from .production import save
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    from .languages import script_language, language_pack
    path = Path(root)/'production/language_editions.json'
    if not path.is_file():return
    data = json.loads(path.read_text())
    if not data.get('prepare_audio'):return
    editions = list(dict.fromkeys(language_pack(lang).code for lang in data.get('editions', [])))
    from .production import digest
    existing=data.get('bundles',{})
    wanted={'text_cards':bool(text_cards),'hooks':bool(hooks),'educational':bool(educational)}
    reusable=(all(lang in existing and Path(existing[lang]['audio']).is_file()
                  and digest(existing[lang]['audio'])==existing[lang]['audio_sha256'] and _bundle_flags_match(existing[lang],wanted)
                  for lang in editions)
              and existing.get(source_language,{}).get('script','').strip()==source_script.strip())
    if reusable:
        # 7.0.80: a saved batch whose only gap is a failed hook draft is reused. Only the hooks are drafted
        # again; localization, TTS and card drafts are not repeated (the 7.0.79 run repeated all of them).
        missing=[lang for lang in editions if wanted['hooks'] and not existing[lang].get('hooks_ready')]
        for lang in missing:
            try:
                existing[lang]=complete_edition_cards(existing[lang],settings.get('gemini_chat_cleanup','keep'))
            except Exception as error:
                existing[lang]=dict(existing[lang],hooks_ready=False,hooks_error=str(error)[:300])
        if missing:
            data['bundles']=existing
            save(path,data)
        return
    audio=Path(root)/'narration/voice.mp3'
    result=prepare_batch(root,source_script,source_language,editions,provider=settings.get('tts_provider','auto'),
                         audio_path=audio if audio.is_file() else None,cleanup=settings.get('gemini_chat_cleanup','keep'),
                         progress=(lambda label,pct,detail='':progress(label,14+3*pct/100,detail)) if progress else None,
                         text_cards=text_cards,educational=educational,topic=topic,card_provider=card_provider,hooks=hooks)
    if source_language in result['bundles'] and audio.is_file():
        primary=result['bundles'][source_language]
        card_file=Path(primary['audio']).parent/'production/speech_cards.json'
        source_words=Path(str(audio)+'.words.json')
        if card_file.is_file() and source_words.is_file():
            card_data=json.loads(card_file.read_text())
            if card_data.get('fingerprint')==fingerprint(audio,json.loads(source_words.read_text()),source_script):
                save(Path(root)/'production/speech_cards.json',card_data)
    data['bundles']=result['bundles'];data['status']='all voices first, then all cards; review required'
    save(path,data)

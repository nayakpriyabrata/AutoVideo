import json
import subprocess
from pathlib import Path
import pytest
from PIL import Image
from engine.local_video_edits import segment_ranges, reviewed_words, edit_video
from engine.studio_widgets import face_thumbnail


def test_ranges_cover_all_source():
    assert segment_ranges(75,'convert')==[(0.,75)]
    assert segment_ranges(75,'split',30)==[(0,30),(30,60),(60,75)]
    with pytest.raises(ValueError):segment_ranges(10,'split',0)


def test_reviewed_odia_and_invalid_timings():
    assert reviewed_words({'words':[{'word':'ନମସ୍କାର','start':0,'end':1}]},2)[0]['word']=='ନମସ୍କାର'
    for value in ([{'word':'x','start':-1,'end':1}], [{'word':'x','start':0,'end':float('nan')}], [{'word':'x','start':1,'end':3}]):
        with pytest.raises(ValueError):reviewed_words(value,2)


def test_face_thumbnail_keeps_face_and_original():
    original=Image.new('RGB',(200,600),'blue')
    original.paste('red',(80,20,120,60))
    thumb=face_thumbnail(original,face_boxes=[(80,20,40,40)])
    assert thumb.size==(140,160)
    assert sum(1 for p in thumb.getdata() if p[0]>200 and p[2]<50)>100
    assert original.size==(200,600)


@pytest.fixture
def source(tmp_path):
    path=tmp_path/'source.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=320x180:rate=15',
        '-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','2.2','-c:v','libx264','-c:a','aac',str(path)],check=True)
    return path


def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))


def test_convert_without_optional_services(source,tmp_path,monkeypatch):
    import engine.local_video_edits as mod
    monkeypatch.setattr(mod,'_transcribe_in_chunks',lambda *a,**k:pytest.fail('Unexpected transcription'))
    monkeypatch.setattr(mod,'_face_crop_x',lambda *a:.5)
    result=edit_video(str(source),str(tmp_path/'out'),rights_confirmed=True)
    assert result['failed_count']==0,result
    media=probe(result['outputs'][0]);video=next(s for s in media['streams'] if s['codec_type']=='video')
    assert (video['width'],video['height'])==(1080,1920)
    assert any(s['codec_type']=='audio' for s in media['streams'])
    assert abs(float(media['format']['duration'])-2.2)<.15
    assert not result['segments'][0].get('caption_ass_path')


def test_music_split_logo_and_complete_coverage(source,tmp_path):
    logo=tmp_path/'logo.png';Image.new('RGBA',(60,60),'red').save(logo)
    result=edit_video(str(source),str(tmp_path/'out'),mode='split',seconds=1,framing='fit',
        show_channel_logo=True,channel_logo_path=str(logo),rights_confirmed=True)
    assert result['failed_count']==0,result
    assert len(result['outputs'])==3
    assert result['segments'][-1]['end']==pytest.approx(result['source_duration'])
    frame=subprocess.check_output(['ffmpeg','-v','error','-i',result['outputs'][0],'-frames:v','1','-f','image2pipe','-vcodec','png','-'])
    import io
    image=Image.open(io.BytesIO(frame));pixel=image.getpixel((300,15))
    assert pixel[0]>180 and pixel[1]<80
    assert source.is_file()


def test_batch_continues_after_render_failure(source,tmp_path,monkeypatch):
    import engine.render.ffmpeg_renderer as renderer
    original=renderer._run_ffmpeg_progress;calls=[]
    def render(*a,**k):
        calls.append(1)
        if len(calls)==2:raise RuntimeError('fixture download/render failure')
        return original(*a,**k)
    monkeypatch.setattr(renderer,'_run_ffmpeg_progress',render)
    result=edit_video(str(source),str(tmp_path/'out'),mode='split',seconds=1,framing='fit',rights_confirmed=True)
    assert len(calls)==3
    assert [s['status'] for s in result['segments']]==['rendered','failed','rendered']
    assert result['partial_result'] and len(result['outputs'])==2
    assert json.loads(Path(result['report_path']).read_text())['failed_count']==1


def test_reviewed_odia_caption_render(source,tmp_path):
    result=edit_video(str(source),str(tmp_path/'out'),framing='fit',transcript='reviewed',language='oriya',
        transcript_data={'words':[{'word':'ନମସ୍କାର','start':.2,'end':1.5}]},rights_confirmed=True)
    assert result['failed_count']==0,result
    ass=Path(result['segments'][0]['caption_ass_path']).read_text(encoding='utf-8-sig')
    assert 'ନମସ୍କାର' in ass
    assert result['language']=='or'


def test_highlights_can_omit_burned_captions(source,tmp_path,monkeypatch):
    import engine.clipping as clips
    import engine.render.captions_ass as captions
    words=[{'word':str(i),'start':i*.2,'end':i*.2+.15} for i in range(8)]
    monkeypatch.setattr(clips,'_transcribe_in_chunks',lambda *a,**k:words)
    monkeypatch.setattr(clips,'rank_highlights',lambda *a,**k:[{'start':0,'end':2,'duration':2,'title':'Example moment','text':'Example moment','score':85}])
    monkeypatch.setattr(captions,'build_captions',lambda *a,**k:pytest.fail('Burned captions must remain off'))
    result=clips.create_highlight_clips(str(source),str(tmp_path/'clips'),count=1,min_seconds=1,max_seconds=3,
        ranking_provider='local',framing='fit',captions_enabled=False)
    item=result['highlights'][0]
    assert not item.get('render_error'),item
    assert item['caption_ass_path']==''
    assert item['qc']['checks']['captions_present']


@pytest.mark.parametrize('keep_source_audio',[True,False])
def test_optional_music_works_with_and_without_source_audio(source,tmp_path,keep_source_audio):
    silent=tmp_path/'silent.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(source),'-an','-c:v','copy',str(silent)],check=True)
    result=edit_video(str(source if keep_source_audio else silent),str(tmp_path/'out'),framing='fit',
        music_path=str(source),rights_confirmed=True)
    assert result['failed_count']==0,result
    assert any(s['codec_type']=='audio' for s in probe(result['outputs'][0])['streams'])

# AutoVideo 7.0.94: image requests can pass Flow's credit approval guard; early waits are logged

**Status: fixture-tested only.** The approval and wait behaviour is verified with fakes in
`tests/test_v794_image_approval.py`. It has NOT been verified against live Flow. Watch the first image run
after installing.

**Default split size: 2400 characters** per Gemini TTS request (unchanged from 7.0.82).

## Why

Job `20261022-143856-7-small-daily-habits-tha-9729`, shot_023 opening frame, 19:18-19:23 IST on 2026-10-25:

- The 7.0.93 fresh-request loop made three submissions, each in a new project, and then stopped at the cap of 3.
- Each wait logged "Waiting up to 360s", but two of them returned after about 43 s and the third after about 1 s.
  Nothing was logged about why.
- Cause in code: image requests set the approval journal but never the outstanding request id. The approval probe
  refused every card at its first check ("no outstanding request; unsolicited approval refused"). The wait then
  returned `False` with no log line.

The 19:27 recovery run in a new process waited the full six minutes and still found no image in project
`ca1709fe`. That is a separate open question. The new logs will show what Flow is doing.

## What changed

- **Image approvals use the video credit guard.** An image request sets its own request id before submitting and
  before recovery waits. A card is clicked only when it shows a visible cost at or below `max_generation_credits`
  (0 for images), and only once per request. A card with no visible cost is never clicked. A paid card is refused
  and logged as a credit-guard block.
- **Reservations are kept.** Approval reservations written during a wait are copied back into the in-memory request
  before any journal write, so a later write cannot drop them and allow a second click.
- **Approval refusals and timeouts are logged.** A refused approval prints `[Flow] Approval refused: <reason>` and
  the wait ends. A wait that runs out of time prints `[Flow] Wait ended after <n>s ...`. Some other early exits in the
  same loop still return without a log line; they are not covered by this release.
- Unchanged: the fresh-request cap (3 per shot), the rule that two real outputs stay blocked, the rule that video is
  never resubmitted automatically, and the Resume gate.

## Job 20261022-143856-7-small-daily-habits-tha-9729 (shot_023)

These steps run on your machine, after installing 7.0.94. Nothing is run from this zip.

1. Archive the saved request. It is kept on record, not deleted. Image requests cost no Flow credits, but this command
   still asks for the credit flag. Run it only if you approve the one additional submission:

       python3 cli.py v3 archive-request 20261022-143856-7-small-daily-habits-tha-9729 storyboard/shot_023_open.jpg --confirm-new-credit-spend

2. Resume. With no journal left for shot_023, this makes one new image submission. If it produces no image, the
   per-shot cap of 3 stops it again, with an explicit reason.

       python3 cli.py v3 resume 20261022-143856-7-small-daily-habits-tha-9729

## Update

From the installation folder, after extracting this zip beside it. The installation must be 7.0.93 (run the 7.0.93
update first if it is older):

    python3 ../AutoVideoAI-v7.0.94/tools/update_v793_to_v794.py .            # dry run
    python3 ../AutoVideoAI-v7.0.94/tools/update_v793_to_v794.py . --apply    # install

Stop the dashboard first. Outputs, saved jobs and browser profiles are not touched.

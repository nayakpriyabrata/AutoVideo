"""Local whole-video reframing and fixed-duration music-video splitting.
No editorial selection, Gemini or Flow generation. Source audio is retained.
"""
import json
import math
import time
from pathlib import Path
from .clipping import (_run, _duration, resolve_input, framing_filter,
    fit_output_dimensions, _face_crop_x, _face_crop_track, _clip_word_timings, _file_sha256,
    _rights_policy, _transcribe_in_chunks, soft_music_filter)


def reviewed_words(value, duration):
    """Accept a reviewed source-relative word transcript; never invent timings."""
    words = value.get('words') if isinstance(value, dict) else value
    if not isinstance(words, list) or not words:
        raise ValueError('Reviewed transcript needs a nonempty words array: word, start, end (seconds).')
    result=[]
    previous=-1.0
    for item in words:
        if not isinstance(item, dict) or not isinstance(item.get('word'), str) or not item['word'].strip():
            raise ValueError('Each transcript word must contain nonempty text.')
        start, end=item.get('start'), item.get('end')
        if any(type(v) not in (int,float) or not math.isfinite(v) for v in (start,end)):
            raise ValueError('Transcript timestamps must be finite numbers.')
        if start < 0 or end <= start or end > duration+.1 or start < previous:
            raise ValueError('Transcript must be ordered and within the source duration.')
        previous=start
        result.append({'word':item['word'].strip(), 'start':float(start), 'end':float(end)})
    return result


def segment_ranges(total, mode, seconds=30):
    if mode not in ('convert','split'):
        raise ValueError('Mode must be convert or split.')
    if not math.isfinite(total) or total <= .1:
        raise ValueError('Source has no usable video duration.')
    if mode=='convert': return [(0.0,total)]
    if type(seconds) not in (int,float) or not math.isfinite(seconds) or not 1 <= seconds <= 600:
        raise ValueError('Segment length must be 1–600 seconds.')
    count=math.ceil(total/seconds)
    if count>1000: raise ValueError('This request exceeds 1000 segments; increase segment length.')
    return [(i*seconds,min(total,(i+1)*seconds)) for i in range(count)]


from .production_lock import serialize_clip_production

@serialize_clip_production
def edit_video(source, output_dir, *, mode='convert', seconds=30,
               framing='face-crop', transcript='none', language='en',
               transcript_data=None, caption_provider='auto', music_path='',
               music_volume=.08, show_channel_logo=False, channel_logo_path='',
               channel_logo_position='top-right', channel_logo_size=.12,
               source_rights='own_content', rights_confirmed=False, progress_cb=None):
    from .languages import language_pack
    from .clip_branding import validate_clip_logo, prepare_clip_logo, clip_logo_path
    from .render.ffmpeg_renderer import _run_ffmpeg_progress, _fontsdir, _esc_filter_path
    language=language_pack(language).code
    if transcript not in ('none','automatic','reviewed'):
        raise ValueError('Transcript must be none, automatic or reviewed.')
    if language=='or' and transcript=='automatic':
        raise ValueError('For Odia/Oriya captions, supply a reviewed timed transcript. Automatic Odia ASR is unverified.')
    framing_filter(framing)
    segment_ranges(1,mode,seconds)
    if type(music_volume) not in (int,float) or not math.isfinite(music_volume) or not 0<=music_volume<=.35:
        raise ValueError('Music volume must be between 0 and 0.35.')
    logo=validate_clip_logo(show_channel_logo,channel_logo_path,channel_logo_size,channel_logo_position)
    rights=_rights_policy(source,source_rights,rights_confirmed)
    root=Path(output_dir).resolve();root.mkdir(parents=True,exist_ok=True)
    # Independent work/output directory prevents prior edits from being overwritten.
    work=root/('edit-'+str(time.time_ns()));work.mkdir()
    from .progress import JobProgress
    progress=JobProgress(str(root),progress_cb)
    emit=progress.emit
    emit('Preparing source video',2)
    local=resolve_input(source,str(work),rights_confirmed=rights_confirmed,source_rights=source_rights)
    probe=_run(['ffprobe','-v','error','-show_streams','-of','json',local],timeout=60)
    streams=json.loads(probe.stdout or '{}').get('streams',[])
    if not any(s.get('codec_type')=='video' for s in streams):raise ValueError('Source has no video stream.')
    audio=any(s.get('codec_type')=='audio' for s in streams)
    total=_duration(local); ranges=segment_ranges(total,mode,seconds)
    words=[]
    if isinstance(transcript_data,dict) and transcript_data.get('source_sha256') and transcript_data['source_sha256']!=_file_sha256(local):
        raise ValueError('Transcript draft belongs to a different source video. Draft or select the correct transcript.')
    if transcript=='reviewed': words=reviewed_words(transcript_data,total)
    elif transcript=='automatic':
        if not audio: raise ValueError('Automatic captions need a source audio stream; choose None or a reviewed transcript.')
        words=_transcribe_in_chunks(local,str(work),total,caption_provider,emit,language=language)
        if not words: raise RuntimeError('No speech transcript was produced. Choose None or supply reviewed timings.')
    width,height=(1080,1920) if framing=='face-crop' else fit_output_dimensions(local)
    branding=prepare_clip_logo(logo,str(work),width,height)
    if music_path:
        music_path=str(Path(music_path).resolve())
        check=_run(['ffprobe','-v','error','-show_streams','-of','json',music_path],timeout=60)
        if check.returncode or not any(s.get('codec_type')=='audio' for s in json.loads(check.stdout or '{}').get('streams',[])):
            raise ValueError('Selected music has no playable audio stream.')
    music_hash=_file_sha256(music_path) if music_path else ''
    report={'mode':mode,'method':'local-'+mode,'source':local,'source_duration':total,
        'source_sha256':_file_sha256(local),'rights':rights,'transcript':transcript,'language':language,
        'framing':framing,'crop_method':'sampled static face center per output' if framing=='face-crop' else 'full frame',
        'music':{'path':music_path,'sha256':music_hash,'volume':music_volume},
        'branding':branding,'outputs':[],'segments':[],'report_path':str(work/'edits.json')}
    def save(): (work/'edits.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    save()
    for i,(start,end) in enumerate(ranges,1):
        item={'start':start,'end':end,'duration':end-start,'status':'pending'}
        report['segments'].append(item)
        try:
            if music_path and _file_sha256(music_path)!=music_hash:raise RuntimeError('Selected music file changed during rendering.')
            duration=end-start
            face=_face_crop_x(local,start,duration) if framing=='face-crop' else .5
            track=_face_crop_track(local,start,duration,face) if framing=='face-crop' else []
            vf=framing_filter(framing,face,width,height,face_track=track)
            item['face_track']=track
            clip_words=_clip_word_timings(words,start,end)
            if transcript!='none' and clip_words:
                from .render.captions_ass import build_captions
                cap=build_captions(clip_words,str(work/f'captions_{i:03d}'),template='OPUS',
                    aspect='9:16' if height>width else '16:9',W=width,H=height,duration=duration)
                vf+=",subtitles='"+_esc_filter_path(str(Path(cap['ass']).resolve()))+"'"
                fonts=_fontsdir()
                if fonts:vf+=":fontsdir='"+_esc_filter_path(fonts)+"'"
                item['caption_ass_path']=cap['ass']
            output=work/(f'vertical-{i:03d}.mp4' if mode=='convert' else f'music-shot-{i:03d}.mp4')
            temporary=work/(output.stem+'.partial.mp4')
            cmd=['ffmpeg','-y','-ss',str(start),'-t',str(duration),'-i',local]
            graph=[]
            if music_path:
                cmd+=['-stream_loop','-1','-i',music_path]
                if audio:graph.append(soft_music_filter(duration,music_volume))
                else:graph.append(f'[1:a]volume={music_volume},atrim=0:{duration},asetpts=PTS-STARTPTS[aout]')
            lp=clip_logo_path(branding)
            if lp:
                index=2 if music_path else 1
                cmd+=['-loop','1','-i',lp]
                graph += [f'[0:v]{vf}[base]',f'[{index}:v]format=rgba[logo]', '[base][logo]overlay=0:0:shortest=1[vout]']
                video_map='[vout]'
            else:
                cmd+=['-vf',vf];video_map='0:v:0'
            if graph:cmd+=['-filter_complex',';'.join(graph)]
            cmd+=['-map',video_map,'-map','[aout]' if music_path else '0:a?',
                  '-t',str(duration),'-c:v','libx264','-preset','veryfast','-crf','18',
                  '-c:a','aac','-b:a','192k','-r','30','-movflags','+faststart',str(temporary)]
            p=_run_ffmpeg_progress(cmd,duration,progress_cb=lambda pct,detail:emit(
                f'Rendering {i}/{len(ranges)}',10+85*((i-1)+pct/100)/len(ranges),detail),timeout=max(180,int(duration*30)))
            if p.returncode:raise RuntimeError('FFmpeg failed: '+(p.stderr or '')[-700:])
            inspection=_run(['ffprobe','-v','error','-show_streams','-of','json',str(temporary)],timeout=60)
            rendered=json.loads(inspection.stdout or '{}').get('streams',[])
            video=next((s for s in rendered if s.get('codec_type')=='video'),{})
            if (video.get('width'),video.get('height'))!=(width,height):raise RuntimeError('Output dimensions did not match the requested framing.')
            if (audio or music_path) and not any(s.get('codec_type')=='audio' for s in rendered):raise RuntimeError('Expected output audio stream is missing.')
            actual=_duration(str(temporary))
            if abs(actual-duration)>max(.25,duration*.01):raise RuntimeError('Rendered duration did not match the requested segment.')
            temporary.replace(output)
            item.update(status='rendered',output=str(output),face_center_x=face,
                transcript_words=clip_words,sha256=_file_sha256(str(output)))
            report['outputs'].append(str(output))
        except Exception as error:
            item.update(status='failed',error=str(error))
        save()
    report['failed_count']=sum(s['status']=='failed' for s in report['segments'])
    report['partial_result']=bool(report['failed_count'])
    report['summary']=f"{len(report['outputs'])}/{len(ranges)} outputs rendered; {report['failed_count']} failed. Original source preserved."
    save();emit(report['summary'],100)
    return report

# AutoVideoAI v7.0.2 — Flow download recovery

This update addresses generated videos that remain unresolved after Flow browser recovery.

- Gallery classification now scopes video badges and controls to their own tile. Agent queue thumbnails and neighboring images cannot inherit another tile's video badge.
- Stable media identity tolerates thumbnail resizing while retaining strict matching for opaque URLs.
- Video downloads select Original size through the tile Download submenu. GIF and paid upscaling options are excluded.
- Saved video requests can be recovered without a legacy pause baseline. Failed jobs expose recovery controls in Studio and the private control center.
- If the saved fingerprint cannot be matched, explicitly review the intended video and provide its exact Flow /project/.../edit/... URL. Confirmation and the saved project must match before download. Recovery runs local media validation and QC before accepting the take. No new Generate request is submitted.

## Recover an existing WSL job

Stop the old Studio and runner. Extract the new release to a fresh folder. Preserve and transfer your existing outputs, local settings, credentials and browser profiles following CONTROL_CENTER_SETUP.md; do not delete the old installation until recovery succeeds.

Open Queue and select the failed job. Try exact request recovery first. If the saved fingerprint still cannot be matched, open the intended video thumbnail in the saved Flow project, verify its content belongs to the pending shot, and copy its /edit/ URL. Paste it into reviewed recovery, check the confirmation, and download. Choose Resume only after QC acceptance.

Use the selected video's toolbar or tile menu, not the global Download project command. Do not associate an unrelated MP4 or create a replacement job to recover this request.

## Verification limit

Automated engine, runner and interface checks cover these paths with DOM and provider fixtures. The user's live authenticated Flow UI and WSL installation have not been exercised. This update cannot guarantee that a particular old signature identifies the correct clip; explicit visual confirmation resolves that ambiguity.

Validation: 644 engine/runner tests passed; 13 control-center JavaScript tests and 13 runner tests passed. Twelve existing dependency deprecation warnings remain. No live provider generation was performed.

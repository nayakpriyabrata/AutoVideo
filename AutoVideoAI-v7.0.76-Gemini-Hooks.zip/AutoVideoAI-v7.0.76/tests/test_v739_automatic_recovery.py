from pathlib import Path
from types import SimpleNamespace as NS
import json
import pytest
from PIL import Image

from engine.factory import Factory, RecoverableInterruption
from engine.automatic_recovery import run_with_recovery, can_recover
from engine.providers.flow_browser import (FlowBrowser, FlowBrowserProvider,
    FlowReferenceUnavailable, FlowRequestPending, FlowAuthNeeded, FlowUIChanged)
from engine.routing.provider_router import NeedsDecision


def factory(tmp_path, monkeypatch):
    monkeypatch.setenv('HOME', str(tmp_path / 'home'))
    f = Factory(str(tmp_path / 'outputs'), str(tmp_path / 'data/jobs.db'))
    job = f.create_job('Automatic recovery test', dry_run=True)
    return f, job


def test_transient_reference_failure_recovers_without_manual_resume(tmp_path, monkeypatch):
    f, job = factory(tmp_path, monkeypatch)
    calls = []; waits = []; episodes = []; closed = []
    from engine.flow_reference_policy import reference_episode_id
    def run(*args):
        calls.append(1); episodes.append(reference_episode_id())
        f._active_job_providers.append(NS(close=lambda: closed.append(len(calls))))
        if len(calls) == 1:
            f._pause_pending_flow(f.pm.load_manifest(job), 'shot_026', FlowReferenceUnavailable('Overlay blocks reference upload'))
        return {'status': 'done'}
    f._run_job = run
    result = run_with_recovery(f, job, None, True, sleep=waits.append)
    assert result['status'] == 'done' and len(calls) == 2
    assert episodes[0] != episodes[1] and closed == [1, 2]
    assert sum(waits) == 20 and max(waits) <= 5
    state = json.loads((Path(f.pm.job_dir(job)) / 'automatic_recovery.json').read_text())
    assert state['status'] == 'finished'


def test_repeated_no_progress_stops_bounded_and_keeps_original_media(tmp_path, monkeypatch):
    f, job = factory(tmp_path, monkeypatch)
    image = Path(f.pm.job_dir(job)) / 'storyboard/shot_001_open.jpg'
    Image.new('RGB', (160, 100), 'green').save(image); original = image.read_bytes()
    calls = []
    def run(*args):
        calls.append(1)
        f._pause_pending_flow(f.pm.load_manifest(job), 'shot_026', FlowReferenceUnavailable('Exact reference unavailable; no generation submitted'))
    f._run_job = run
    with pytest.raises(RecoverableInterruption):
        run_with_recovery(f, job, None, True, sleep=lambda _: None)
    assert len(calls) == 5 and f.db.get(job)['status'] == 'paused'
    assert image.read_bytes() == original
    state = json.loads((image.parent.parent / 'automatic_recovery.json').read_text())
    assert state['status'] == 'needs_attention' and state['attempts'] == 5


@pytest.mark.parametrize('reason', ['Approval required', 'Quota exceeded', 'Sign in to continue', 'File not found'])
def test_wrapped_reference_hard_stops_are_not_retried(tmp_path, monkeypatch, reason):
    f, job = factory(tmp_path, monkeypatch); calls = []
    def run(*args):
        calls.append(1)
        f._pause_pending_flow(f.pm.load_manifest(job), 'shot_026', FlowReferenceUnavailable(reason))
    f._run_job = run
    with pytest.raises(NeedsDecision):
        run_with_recovery(f, job, None, True, sleep=lambda _: pytest.fail('Hard stop waited'))
    assert len(calls) == 1 and f.db.get(job)['status'] == 'paused'


def test_new_saved_frames_reset_no_progress_but_total_attempts_are_bounded(tmp_path, monkeypatch):
    f, job = factory(tmp_path, monkeypatch); calls = []
    def run(*args):
        calls.append(1)
        Image.new('RGB', (160, 100), 'blue').save(Path(f.pm.job_dir(job)) / 'storyboard' / f'shot_{len(calls):03d}_open.jpg')
        f._pause_pending_flow(f.pm.load_manifest(job), 'shot_026', FlowRequestPending('Saved exact request needs recovery; no new generation'))
    f._run_job = run
    with pytest.raises(RecoverableInterruption):
        run_with_recovery(f, job, None, True, sleep=lambda _: None)
    assert len(calls) == 21
    state = json.loads((Path(f.pm.job_dir(job)) / 'automatic_recovery.json').read_text())
    assert state['history'][-1]['no_progress_attempts'] == 0


def test_disabled_recovery_and_untyped_errors_do_not_retry(tmp_path, monkeypatch):
    f, job = factory(tmp_path, monkeypatch)
    f._settings = lambda _: {'flow_auto_recovery': False}
    calls = []
    def run(*args):
        calls.append(1)
        f._pause_pending_flow(f.pm.load_manifest(job), 'shot_001', FlowRequestPending('Pending request'))
    f._run_job = run
    with pytest.raises(RecoverableInterruption):
        run_with_recovery(f, job, None, True, sleep=lambda _: pytest.fail('Disabled recovery waited'))
    assert len(calls) == 1
    assert not can_recover(RuntimeError('programming bug'))
    assert not can_recover(FlowAuthNeeded('Sign in'))


def test_cancel_during_backoff_releases_recovery_state(tmp_path, monkeypatch):
    f, job = factory(tmp_path, monkeypatch)
    f._run_job = lambda *args: f._pause_pending_flow(f.pm.load_manifest(job), 'shot_001', FlowRequestPending('Pending request'))
    def stop(_): raise KeyboardInterrupt
    with pytest.raises(KeyboardInterrupt): run_with_recovery(f, job, None, True, sleep=stop)
    assert not f._automatic_recovery_active and f._active_job_providers is None


def test_transparent_menu_backdrop_is_dismissed_before_reference_click():
    b = FlowBrowser.__new__(FlowBrowser); events = []; state = {'visible': True}
    b._media_picker_open = lambda: False
    b._transient_menu_overlay_open = lambda: state['visible']
    def press(key): events.append(key); state['visible'] = False
    b._page = NS(keyboard=NS(press=press), wait_for_timeout=lambda _: None)
    b._dismiss_media_picker()
    assert events == ['Escape'] and not state['visible']


def test_stuck_backdrop_stops_without_forced_click():
    b = FlowBrowser.__new__(FlowBrowser); events = []
    b._media_picker_open = lambda: False; b._transient_menu_overlay_open = lambda: True
    b._page = NS(keyboard=NS(press=events.append), wait_for_timeout=lambda _: None)
    with pytest.raises(FlowUIChanged): b._dismiss_media_picker()
    assert events == ['Escape'] * 3


def test_rotated_signature_rebinds_exact_prompt_without_generation(tmp_path):
    p = FlowBrowserProvider.__new__(FlowBrowserProvider)
    out = str(tmp_path / 'frame.jpg')
    request = {'kind': 'image', 'project_url': 'https://flow.google.com/project/test',
               'signature': 'old', 'submitted_prompt': 'exact scene', 'baseline': []}
    Path(out + '.flow-request.json').write_text(json.dumps(request))
    calls = []
    b = NS(ensure_project=lambda *a, **kw: None, media_assets=lambda: [{'sig': 'new'}],
           download_latest_asset=lambda path, **kw: calls.append(kw) or path)
    p.recover_browser = lambda *a, **kw: True; p._ensure = lambda: b
    p._identify_single_fresh_asset = lambda bridge, record, kind, **kw: 'new'
    assert p._download_after_browser_recovery('project', out, project_url=request['project_url'], preferred_signature='old') == out
    assert calls[0]['preferred_signature'] == 'new'
    assert json.loads(Path(out + '.flow-request.json').read_text())['signature'] == 'new'


def test_unverified_rotated_signature_never_downloads_or_generates(tmp_path):
    p = FlowBrowserProvider.__new__(FlowBrowserProvider); out = str(tmp_path / 'frame.jpg')
    Path(out + '.flow-request.json').write_text(json.dumps({'kind': 'image', 'signature': 'old'}))
    b = NS(ensure_project=lambda *a, **kw: None, media_assets=lambda: [],
           download_latest_asset=lambda *a, **kw: pytest.fail('No exact match'))
    p.recover_browser = lambda *a, **kw: True; p._ensure = lambda: b
    p._identify_single_fresh_asset = lambda *a, **kw: ''
    with pytest.raises(FlowRequestPending): p._download_after_browser_recovery('project', out, preferred_signature='old')


def test_resume_keeps_cached_identical_nonvideo_frame_pair(tmp_path):
    from tests.test_v716_frame_batch_recovery import setup_batch
    from tests.test_economy_parallel_frames import _Refs
    f, m, dirs, settings, calls = setup_batch(tmp_path, set())
    settings['flow_image_workers'] = 1
    for shot in m.shots:
        shot.provider = 'image'
        for label in ('open', 'close'):
            Image.new('RGB', (96, 96), 'blue').save(Path(dirs['storyboard']) / f'{shot.shot_id}_{label}.jpg')
    before = {p.name: p.read_bytes() for p in Path(dirs['storyboard']).glob('*.jpg')}
    f._generate_economy_frames(m, dirs, _Refs(), False, settings, {}, lambda *a: None)
    assert not calls
    assert before == {p.name: p.read_bytes() for p in Path(dirs['storyboard']).glob('*.jpg')}

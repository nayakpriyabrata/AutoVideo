# AutoVideoAI 7.0.3 — workflow recovery

## Upgrade safely

Stop Studio, the local runner and CLI jobs first. Back up the existing installation.
Extract this ZIP separately. To retain existing job paths, overlay the new source
files onto your existing installation rather than moving or renaming its folder.
Preserve outputs/, data/, browser profiles, .env and config/user_settings.yaml.
The release excludes these runtime files. Review configuration defaults before
copying config files over custom settings. Restart Studio and the runner using
the same Python environment. Existing accepted takes are preserved.

## Clips continue after QC blocks

A QC-blocked clip is retained with its .qc.json report. Remaining highlights
continue rendering. highlights.json reports partial results, blocked outputs and
render errors; highlights.partial.json checkpoints progress after each clip.
Review outputs before publishing. Static source scenes are compared against the
same source window: matching freezes become editorial review, not automatic PASS.
Unexpected freezes, decode failures and black frames can still block a clip.

For an OLD interrupted batch, use the saved selection and local source cache:

    python3 cli.py v3 clip-recover --folder outputs/my-clips --indices 4 5 --dry-run
    python3 cli.py v3 clip-recover --folder outputs/my-clips --indices 4 5

For a ten-highlight batch stopped at clip 1, select indices 2 through 10 instead.
This requires an unambiguous saved selection, source video and word timestamps.
It creates a separate recovery folder, preserves original audio, and makes no
new ranking or provider requests. It does not resume music or B-roll edits.

## Music

Pixabay media browsing now uses the WSL-capable browser launch fallbacks instead
of a bare Chromium launch. Successful job music retrieval is cached and checked
by file hash before reuse. Music-only jobs check availability before generating
new visuals. A licensed local track remains the reliable offline option.

Clip Studio offers an explicit option to continue with original audio if optional
music is unavailable. The report records the warning. CLI equivalent:

    --background-music-enabled --music-failure-policy continue-original

The default CLI policy stops on missing requested music. Music-only productions
are never silently converted to silent video. Change to Silent explicitly or
choose a licensed local track, then render using accepted visuals.

## B-roll

B-roll is a review-and-apply edit. In Clip Studio, enable suggestions and run the
batch, or use “Load saved highlights for B-roll review — no regeneration”. Search
for suggestions, preview every asset, approve or skip, save decisions, and apply
the approved cutaways. Edited copies are created; original clips are preserved.
Failed render rows no longer consume suggestion slots. Search failures show their
actual detail. Suggestions do not automatically attach themselves.

## Gemini and Flow

Gemini script requests now close their Playwright session after each operation;
startup failures do not leave a partially initialized shared session. This avoids
stale browser objects across Studio reruns. Your persistent sign-in profile stays
on disk. Sign-in or consent screens still need manual attention. Restart Studio
after upgrading. If the composer is absent, inspect the visible Gemini browser;
no prompt is submitted until a usable composer is found. Imported approved script
JSON is an alternative to browser planning.

Flow preserves pending request journals and never submits a replacement merely
because recovery fails. v7.0.2 reviewed exact-asset recovery is retained. Agent
failure reporting includes the matched failure marker; the generic word “blocked”
alone no longer causes a generation-failure match.

Queue can repair an unaccepted shot from its saved opening/closing storyboard
frames after you review them. This local image-motion transition spends no Flow
credits and must pass QC. It does not create character animation or overwrite
accepted takes. Cartoon identity scenes no longer route to generic stock footage.

## Other source sites

Public Facebook, Instagram and other supported URLs use yt-dlp. Support varies by
site, authentication requirements and website changes; not every URL is supported.
Use a permitted local file when a download fails. Non-YouTube URLs use speech
transcripts for highlight ranking instead of being sent to Gemini's YouTube URL
analysis. Confirm source rights and review edits before publishing.

## Verification limits

Automated tests cover batch continuation, source-aware freeze review, music
fallback/cache, browser launch fallbacks, Gemini session lifecycle and local repair.
Encoded media tests remain in the complete suite. These tests do not verify your
live WSL browser, Google accounts, current provider pages or source-site access.

Validation: 658 engine tests passed (12 dependency deprecation warnings).

from types import SimpleNamespace as NS

import pytest
from playwright.sync_api import TimeoutError as ClickTimeout

from engine.providers import flow_browser as m


def picker(monkeypatch, unstable=1, parent_succeeds=True, scoped=True):
    now=[0.0]; title_clicks=[]; parent_clicks=[]
    monkeypatch.setattr(m.time,'monotonic',lambda:now[0])
    def click_title(**kw):
        title_clicks.append(kw);now[0]+=kw['timeout']/1000
        if len(title_clicks)<=unstable:raise ClickTimeout('not stable')
    def click_parent(**kw):
        parent_clicks.append(kw);now[0]+=kw['timeout']/1000
        if not parent_succeeds:raise ClickTimeout('not stable')
    parent=NS(count=lambda:1,is_visible=lambda **kw:True,click=click_parent)
    title=NS(is_visible=lambda **kw:True,click=click_title,locator=lambda s:parent)
    tabs=NS(count=lambda:1,nth=lambda i:title)
    scope=NS(get_by_text=lambda name,**kw:tabs)
    b=m.FlowBrowser.__new__(m.FlowBrowser)
    b._page=NS(evaluate=lambda js:scoped,locator=lambda s:scope,
               wait_for_timeout=lambda ms:now.__setitem__(0,now[0]+ms/1000))
    b._click_text_action=lambda *a,**kw:pytest.fail('global sidebar clicked')
    return b,now,title_clicks,parent_clicks


def test_unstable_uploads_title_uses_scoped_clickable_parent(monkeypatch):
    b,now,titles,parents=picker(monkeypatch)
    assert b._picker_uploads(timeout_ms=3500)
    assert len(titles)==len(parents)==1
    assert now[0]<=3.5
    assert all('force' not in kw for kw in titles+parents)


def test_permanently_unstable_uploads_bounded_without_global_fallback(monkeypatch):
    b,now,titles,parents=picker(monkeypatch,unstable=100,parent_succeeds=False)
    assert not b._picker_uploads(timeout_ms=3500)
    assert 1<len(titles)==len(parents) and now[0]<=3.51


def test_missing_picker_never_clicks_global_uploads(monkeypatch):
    b,now,titles,parents=picker(monkeypatch,scoped=False)
    assert not b._picker_uploads()
    assert not titles and not parents


def test_finish_retries_uploads_before_exact_row(monkeypatch):
    b,now,titles,parents=picker(monkeypatch)
    attempts=[];names=[False]
    def uploads(**kw):
        attempts.append('uploads');now[0]+=.2
        return len(attempts)>1
    b._picker_uploads=uploads
    b._clear_media_picker_search=lambda:None
    b._agent_reference_names=lambda:['AV_exact.jpg'] if names[0] else []
    b._click_exact_reference_row=lambda *a:attempts.append('row') or True
    b._click_text_action=lambda *a,**kw:names.__setitem__(0,True)
    b._dismiss_media_picker=lambda:None
    assert b._finish_agent_media_picker('AV_exact.jpg',timeout_ms=3000)
    assert attempts[:3]==['uploads','uploads','row']

"""Durable one-project/one-image transactions, shared by production and recovery.

Only decoded, non-reference media is committed. Probe files are bound to their
project, signature and checksum before moving on to another browser action.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import time
import uuid

from .isolated_frame_regeneration import image_valid, sha, write_json
from .flow_reference_validation import matching_reference

SCOPE = 'isolated_image_v1'
SCOPES = {SCOPE, 'isolated_one_frame_one_request'}


def journal_path(output):
    return Path(str(output) + '.flow-request.json')


def references_for(request):
    refs = request.get('reference_hashes') or {}
    for value, expected in refs.items():
        path = Path(value)
        if not image_valid(path) or sha(path) != expected:
            raise RuntimeError('Saved image reference changed or is missing: ' + path.name)
    return list(refs)


REFERENCE_LABEL_RE = re.compile(r'AV_[0-9a-f]{6,}_[^\s|]{1,200}?\.(?:jpe?g|png|webp)', re.I)


def reference_label(asset):
    """Flow's tile label for an uploaded reference (AV_<hash>_<filename>), or ''. Stable across loads."""
    text = str((asset or {}).get('tile_hint') or (asset or {}).get('hint') or '')
    match = REFERENCE_LABEL_RE.search(text)
    return match.group(0) if match else ''


def exclude_reference_labels(assets, labels=None):
    """Drop uploaded-reference tiles from a generation wait or inventory.

    v7.0.92: every AV_<hash>_<file> tile is an uploaded reference, whether or not the journal has seen
    it before. Labels recorded by the journal are still honoured for tiles without a parsable label.
    """
    labels = [label for label in (labels or []) if label]
    kept = []
    for a in (assets or []):
        text = str(a.get('tile_hint') or a.get('hint') or '')
        if reference_label(a) or any(label in text for label in labels):
            continue
        kept.append(a)
    return kept


def known_reference_labels(request):
    """Labels of tiles the journal has classified as uploaded references in this project."""
    project = request.get('project_url')
    return sorted({str(entry['reference_label']) for entry in (request.get('capture_probes') or {}).values()
                   if entry.get('reference') and entry.get('reference_label') and entry.get('project_url') == project})


def known_reference_signatures(request):
    """Tile signatures already classified as uploaded references by checksum/visual match.

    v7.0.90: Flow re-lists uploaded references as project tiles under new URLs, so the
    pre-submit baseline does not always match them. Once the journal has classified such a
    tile, it is excluded from the generation wait. The journal, not tile order, decides.
    """
    project = request.get('project_url')
    return {str(entry['signature']) for entry in (request.get('capture_probes') or {}).values()
            if entry.get('reference') and entry.get('signature') and entry.get('project_url') == project}


def wait_baseline(request):
    return set(request.get('baseline', [])) | known_reference_signatures(request)


def completed(output, request):
    return (request.get('status') == 'downloaded' and image_valid(output)
            and request.get('media_sha256') == sha(output))


def commit_capture(output, request, source, method):
    output = Path(output)
    if not image_valid(source) or matching_reference(source, references_for(request)):
        raise RuntimeError('Image is invalid or an uploaded reference; request retained')
    stage = output.with_name(output.name + '.commit.tmp')
    shutil.copy2(source, stage)
    os.replace(stage, output)
    request.update(status='downloaded', media_sha256=sha(output), capture_method=method)
    write_json(journal_path(output), request)
    return request


def capture(provider, bridge, request, output, references):
    from .providers.flow_browser import media_signature_matches
    output = Path(output)
    if request.get('scope') not in SCOPES:
        raise RuntimeError('Content exclusion requires an isolated single-request project')
    references_for(request)
    project = request['project_url']
    if bridge.normalize_project_url(bridge.current_project_url()) != project:
        raise RuntimeError('Image project changed; no download attempted')
    if completed(output, request):
        return request
    legacy_stage = Path(str(output) + '.download.jpg')
    if (request.get('scope') == 'isolated_one_frame_one_request' and request.get('signature')
            and image_valid(legacy_stage) and not matching_reference(legacy_stage, references)):
        return commit_capture(output, request, legacy_stage, 'saved_identified_download')
    # The full inventory and every probe are saved before download begins. A
    # crash after save_as is recoverable even before the checksum was journaled.
    probes = request.setdefault('capture_probes', {})
    assets = [a for a in bridge.media_assets() if a.get('kind') == 'image' and a.get('sig')]
    distinct = []
    for asset in assets:
        if not any(media_signature_matches(asset['sig'], a['sig']) for a in distinct):
            distinct.append(asset)
    if not distinct:
        raise RuntimeError('No completed image yet: the saved project has no images; request retained')
    if len(distinct) > len(references) + 1:
        raise BlockedOutputs('Extra images are saved in the reserved project; two real outputs stay blocked')
    inventory = [str(a['sig']) for a in distinct]
    request['capture_inventory'] = inventory
    write_json(journal_path(output), request)
    eligible = []
    for signature in inventory:
        # A stable baseline signature proves this is an uploaded reference.
        if any(media_signature_matches(signature, old) for old in request.get('baseline', [])):
            continue
        key = hashlib.sha256((project + '\n' + signature).encode()).hexdigest()
        label = reference_label(next((a for a in distinct if str(a.get('sig')) == signature), None))
        if label:
            # v7.0.92: an uploaded reference is identified by its live label. It is never downloaded,
            # so Flow re-listing it under a new URL cannot cause a repeat download or a false candidate.
            ref_entry = next((e for e in probes.values() if e.get('project_url') == project
                              and e.get('reference_label') == label), None)
            if ref_entry is None:
                ref_entry = {'project_url': project, 'signature': signature, 'file': '',
                             'state': 'label_reference', 'reference': 'label:' + label,
                             'reference_label': label}
                probes[key] = ref_entry
            ref_entry['signature'] = signature
            ref_entry.setdefault('reference', 'label:' + label)
            write_json(journal_path(output), request)
            continue
        entry = probes.get(key)
        if entry is None:
            # Reuse only a recorded stable identity, never candidate tile order.
            entry = next((e for e in probes.values() if e.get('project_url') == project
                          and media_signature_matches(e.get('signature'), signature)), None)
        if entry is None and label:
            # v7.0.91: a classified uploaded reference keeps its label across project loads, even when
            # Flow gives its tile a new URL. Reuse its saved bytes instead of downloading another copy.
            entry = next((e for e in probes.values() if e.get('project_url') == project and e.get('reference')
                          and e.get('reference_label') == label), None)
            if entry is not None:
                entry['signature'] = signature
        if entry is None:
            entry = {'project_url': project, 'signature': signature,
                     'file': output.name + '.probe-' + key[:20] + '.jpg', 'state': 'reserved'}
            probes[key] = entry
            write_json(journal_path(output), request)
        if label:
            entry['reference_label'] = label
        probe = output.parent / entry['file']
        if probe.parent != output.parent or probe.is_symlink() or entry.get('project_url') != project:
            raise RuntimeError('Invalid saved probe location or project')
        valid = image_valid(probe)
        if valid and entry.get('sha256') and sha(probe) != entry['sha256']:
            raise RuntimeError('Saved candidate checksum changed; refusing substitution')
        if not valid:
            try:
                bridge.download_latest_asset(str(probe), preferred_signature=signature, before_signatures=set())
            except Exception:
                # A close after all bytes were saved is not a failed download.
                if not image_valid(probe):
                    raise
            if not image_valid(probe):
                raise RuntimeError('Candidate download incomplete; checkpoint retained')
        entry.update(state='downloaded', sha256=sha(probe),
                     reference=matching_reference(probe, references))
        write_json(journal_path(output), request)
        if not entry['reference']:
            eligible.append((signature, probe))
    if len(eligible) != 1:
        if not eligible:
            raise RuntimeError('No generated image yet: only uploaded references are saved; request retained')
        raise BlockedOutputs(f'{len(eligible)} non-reference images are saved; two real outputs stay blocked for review')
    signature, source = eligible[0]
    # All files from this inventory have now been classified. No further browser
    # calls can invalidate these bytes, including closing the project tab.
    request.update(signature=signature, reference_exclusion_verified=True)
    write_json(journal_path(output), request)
    return commit_capture(output, request, source, 'isolated_project_reference_exclusion')



def recover_checkpoint(output, request):
    """Finish a completely classified saved inventory without opening Flow."""
    from .providers.flow_browser import media_signature_matches
    if request.get('scope') not in SCOPES or not request.get('capture_inventory'):
        return False
    refs = references_for(request)
    probes = request.get('capture_probes', {})
    eligible = []
    for signature in request['capture_inventory']:
        if any(media_signature_matches(signature, old) for old in request.get('baseline', [])):
            continue
        matches = [e for e in probes.values() if e.get('project_url') == request['project_url']
                   and media_signature_matches(e.get('signature'), signature)]
        if len(matches) != 1:
            return False
        entry = matches[0]
        probe = Path(output).parent / entry['file']
        if (probe.parent != Path(output).parent or probe.is_symlink() or not image_valid(probe)
                or not entry.get('sha256') or sha(probe) != entry['sha256']):
            return False
        if not matching_reference(probe, refs):
            eligible.append((signature, probe))
    if len(eligible) != 1 or len(request['capture_inventory']) > len(refs) + 1:
        return False
    request['signature'] = eligible[0][0]
    commit_capture(output, request, eligible[0][1], 'saved_classified_inventory')
    return True


class NoGeneratedOutput(RuntimeError):
    """The saved project holds no generated image after the wait (only uploaded references, or nothing)."""


class BlockedOutputs(RuntimeError):
    """Two or more real outputs are saved. Never resubmitted or replaced automatically."""


NO_OUTPUT_TOKENS = ('No completed image', 'No generated image yet')
BLOCKED_TOKENS = ('Extra images are saved', 'non-reference images are saved')
FRESH_IMAGE_REQUESTS = 3  # total submissions per shot, including the first. Image requests are free in Flow.

NO_OUTPUT_MESSAGE = ('No generated image is in the saved Flow project: only the uploaded references were found '
                     'after the wait, so the earlier submission produced nothing. Image requests cost no Flow credits, '
                     'so a fresh image request will be submitted in a new project.')
BLOCKED_MESSAGE = ('Two or more real images are saved for {image}. Recovery stopped without submitting or replacing; '
                   'review the saved Flow project and choose which image to keep.')


def _job_name(output):
    parts = Path(output).resolve().parts
    return parts[-3] if len(parts) >= 3 and parts[-2] == 'storyboard' else '<job-id>'


def _matches(error, tokens):
    return any(token in str(error) for token in tokens)


def recover(provider, request, output, compiled=None, attempts=3):
    """Only reopen, wait and download. Never upload, fill or submit here."""
    from .providers.flow_browser import FlowRequestPending
    compiled = compiled or {}
    refs = references_for(request)
    if completed(output, request) or recover_checkpoint(output, request):
        return request
    last = None
    for attempt in range(attempts):
        try:
            bridge = provider._ensure()
            bridge.ensure_project(request.get('project_name') or 'AutoVideo-Image', project_url=request['project_url'])
            # First consume existing media. This avoids another six-minute wait
            # after a download interruption. If only references exist, wait once.
            try:
                return capture(provider, bridge, request, output, refs)
            except RuntimeError as error:
                if _matches(error, BLOCKED_TOKENS):
                    raise BlockedOutputs(str(error)) from error
                if not _matches(error, NO_OUTPUT_TOKENS):
                    raise
                if attempt:
                    raise
            approval_context(bridge, output, request)
            try:
                bridge.wait_for_agent_generation(before_assets=wait_baseline(request), timeout_s=360,
                    exclude_labels=known_reference_labels(request),
                    required_kind='image', approval=compiled.get('approval', 'once'),
                    max_generation_credits=compiled.get('max_generation_credits', 0), image_request=None,
                    service_busy_wait_s=compiled.get('flow_capacity_wait_seconds', 90),
                    service_busy_retries=compiled.get('flow_capacity_retries', 1),
                    transactional_images=True)
            finally:
                sync_approval_reservations(output, request)
            try:
                return capture(provider, bridge, request, output, refs)
            except RuntimeError as error:
                if _matches(error, BLOCKED_TOKENS):
                    raise BlockedOutputs(str(error)) from error
                if _matches(error, NO_OUTPUT_TOKENS):
                    raise NoGeneratedOutput(str(error)) from error
                raise
        except BlockedOutputs as error:
            request['recovery_state'] = 'blocked_multiple_outputs'
            request['last_recovery_error'] = str(error)[:500]
            write_json(journal_path(output), request)
            raise FlowRequestPending(BLOCKED_MESSAGE.format(image=output.name)) from error
        except NoGeneratedOutput as error:
            # Waiting again cannot create an output that Flow never produced. Stop this run now.
            request['last_recovery_error'] = NO_OUTPUT_MESSAGE[:500]
            request['recovery_state'] = 'no_generated_output_in_project'
            write_json(journal_path(output), request)
            pending = FlowRequestPending(NO_OUTPUT_MESSAGE)
            pending.fresh_request_allowed = True  # read by generate(); the only case that may resubmit
            raise pending from error
        except Exception as error:
            last = error
            request['last_recovery_error'] = str(error)[:500]
            write_json(journal_path(output), request)
            if attempt + 1 < attempts:
                try: provider.close()
                except Exception: pass
    raise FlowRequestPending('Image recovery checkpoint retained: ' + str(last)) from last


def approval_context(bridge, output, request):
    """v7.0.94: image requests use the same credit approval guard as video.

    The Flow approval probe refuses any card unless the bridge has a journal AND an outstanding request id.
    Image submissions set the journal but never the request id, so every wait on that bridge ended at once,
    silently (job 20261022-143856-7, 19:19-19:23 IST). The id here lets a card be checked against this journal;
    max_generation_credits stays 0, so a paid card is refused and logged, and an unpriced card is never clicked.
    """
    bridge._approval_journal = str(journal_path(output))
    bridge._approval_card_limit = 1
    bridge._awaiting_request_id = 'image:' + str(request.get('request_hash') or journal_path(output).name)


def sync_approval_reservations(output, request):
    """Keep credit reservations written by the approval probe. Journal writes use the in-memory request, so
    without this a later write would drop a reservation made during the wait and allow a second click."""
    try:
        disk = json.loads(journal_path(output).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return
    if 'approval_reservations' in disk:
        request['approval_reservations'] = disk['approval_reservations']
        request['approval_credit_total_reserved'] = disk.get('approval_credit_total_reserved', 0)


def fresh_request_count(output):
    """Number of archived (old, unresolved) submissions for this shot image."""
    output = Path(output)
    return len(list(output.parent.glob(output.name + '.flow-request.archived-*.json')))


def archive_saved_request(output):
    """Rename an unresolved image journal so a fresh request can be submitted. Nothing is deleted.

    Image requests cost no Flow credits, so no credit flag is needed. Refuses if a valid non-reference image
    is saved. It takes no lock: the caller already holds the production slot.
    """
    output = Path(output)
    path = journal_path(output)
    request = json.loads(path.read_text(encoding='utf-8'))
    if request.get('scope') != SCOPE or request.get('kind') != 'image':
        raise RuntimeError('Only a saved image request can be archived for a fresh request')
    for entry in (request.get('capture_probes') or {}).values():
        if entry.get('reference'):
            continue
        if entry.get('file') and image_valid(output.parent / str(entry['file'])):
            raise RuntimeError(f"{entry['file']} is a valid image that is not a classified uploaded reference; "
                               'recover it instead of resubmitting')
    stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + '-' + uuid.uuid4().hex[:6]
    archived = output.with_name(output.name + '.flow-request.archived-' + stamp + '.json')
    path.rename(archived)
    return archived


def generate(provider, shot, compiled, output, vertical, request_hash):
    """Image generation with fresh requests. Only a saved request with no output is ever replaced, and only up to
    FRESH_IMAGE_REQUESTS submissions per shot. Two real outputs, and video requests, are never resubmitted here."""
    from .providers.flow_browser import FlowRequestPending
    output = Path(output)
    while True:
        try:
            return _generate_once(provider, shot, compiled, output, vertical, request_hash)
        except FlowRequestPending as error:
            if not getattr(error, 'fresh_request_allowed', False):
                raise
            used = fresh_request_count(output)
            if used + 1 >= FRESH_IMAGE_REQUESTS:
                raise FlowRequestPending(str(error) + f' Automatic fresh image requests stopped after {used + 1} '
                                         'submission(s); review the saved Flow project before any further action.') from error
            archived = archive_saved_request(output)
            print(f'[Flow] {output.name}: the saved image request produced no image. Submitting a fresh free image '
                  f'request ({used + 2} of {FRESH_IMAGE_REQUESTS}); the old request is kept as {archived.name}.')


def _generate_once(provider, shot, compiled, output, vertical, request_hash):
    from .providers.flow_browser import FlowBrowser, FlowRequestPending
    from .flow_reference_policy import compact_photo_brief
    from .isolated_frame_regeneration import settled_references
    output = Path(output)
    path = journal_path(output)
    if path.is_file():
        request = json.loads(path.read_text())
        if request.get('request_hash') != request_hash or request.get('scope') != SCOPE:
            raise FlowRequestPending('Image transaction context changed')
        current_refs = {str(Path(p).resolve()): sha(p) for p in compiled.get('reference_paths', [])}
        if current_refs != request.get('reference_hashes', {}):
            raise FlowRequestPending('Image transaction references differ from the saved request')
        if request.get('phase') != 'preparing':
            recover(provider, request, output, compiled)
            return result(output, request)
    else:
        refs = list(dict.fromkeys(str(Path(p).resolve()) for p in compiled.get('reference_paths', [])))
        if any(not image_valid(p) for p in refs):
            raise FlowRequestPending('A required image reference is missing or invalid')
        still = compact_photo_brief(compiled.get('prompt', ''), refs)
        instruction = FlowBrowser._agent_image_instruction(still, '9:16' if vertical else '16:9', 1)
        if len(instruction) > 4000 or not instruction.endswith(still.strip()):
            raise FlowRequestPending('Complete image instruction exceeds the composer limit')
        request = {'schema_version': 1, 'scope': SCOPE, 'kind': 'image', 'status': 'pending',
            'phase': 'preparing', 'request_hash': request_hash,
            'project_name': 'AutoVideo-Image-' + uuid.uuid4().hex, 'project_url': '',
            'reference_hashes': {p: sha(p) for p in refs}, 'submitted_prompt': instruction,
            'source_prompt': compiled.get('prompt', ''), 'shot_id': str(shot.shot_id),
            'vertical': bool(vertical), 'replacement_request': bool(compiled.get('flow_replacement_request')),
            'baseline': [], 'signature': ''}
        write_json(path, request)
    refs = references_for(request)
    bridge = provider._ensure()
    if not request.get('project_url'):
        bridge.create_isolated_image_project(request['project_name'])
    else:
        bridge.ensure_project(request['project_name'], project_url=request['project_url'])
    project = FlowBrowser.normalize_project_url(bridge.current_project_url())
    if not project or (request.get('project_url') and request['project_url'] != project):
        raise FlowRequestPending('Isolated image project binding changed')
    if not request.get('project_url') and bridge.media_assets():
        raise FlowRequestPending('New image request requires an empty project')
    request['project_url'] = project
    write_json(path, request)
    if bridge.detect_editor_mode() != 'agent':
        raise FlowRequestPending('Flow Agent editor unavailable; no prompt submitted')
    bridge.select_agent_generation_type('image')
    if refs and bridge.attach_agent_media(refs, reuse_existing=True) != len(refs):
        raise FlowRequestPending('References not attached; no prompt submitted')
    request['baseline'] = settled_references(bridge, len(refs))
    # Verify the exact composer text before reserving the send action. The
    # acknowledgement comes from a new non-editable conversation occurrence.
    bridge._fill_editor_box('agent_prompt_box', request['submitted_prompt'])
    before = bridge.agent_submission_state(request['submitted_prompt'])
    if not before.get('composer_matches'):
        raise FlowRequestPending('Flow composer did not retain the complete prompt; no Send attempted')
    request.update(phase='submission_uncertain', submission_before=before, submitted_at=time.time())
    write_json(path, request)
    approval_context(bridge, output, request)
    bridge.submit_prepared_text_video('agent')
    acknowledged = bridge.wait_for_submission_ack(request['submitted_prompt'], before)
    request.update(phase='submitted' if acknowledged else 'submission_uncertain',
                   submission_acknowledged=acknowledged)
    write_json(path, request)
    if not acknowledged:
        # A collapsed prompt echo cannot prove Send failed. Recover this SAME
        # project; reference exclusion still rejects all uploaded inputs.
        print('[Flow] Prompt echo not confirmed; recovering the same image project without resubmitting.')
    recover(provider, request, output, compiled)
    return result(output, request)


def result(output, request):
    return {'path': str(output), 'provider': 'flow', 'model': 'imagen_flow', 'credits': 0,
            'project_url': request['project_url'], 'log': 'Durable isolated image transaction completed'}

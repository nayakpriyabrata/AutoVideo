"""Prove that a card really reached the finished video (v7.0.107).

The plan says a card sits at 03:12 for four seconds; that does not prove a viewer sees it. Transport
problems (a dropped overlay label, an edition render that ignores the overlay list, a card drawn in the
wrong region) all look identical in the JSON and only differ in the file.

This module samples the finished master: for each placed card it grabs the frame in the middle of the card
and a control frame shortly before/after it, then compares the pixels of the card's own region. A card that
is on screen changes those pixels measurably; a card that never rendered leaves them identical.

Bounded by design: at most ``limit`` cards, two half-scale frames each, no audio, no re-encode.
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

VISIBLE_MEAN_DELTA = 3.0  # mean absolute difference (0-255) over the card region
SKIP_KINDS = {"watermark"}


def _tool(name):
    from ..finishing_studio import _tool as resolve
    return resolve(name)


def _grab(video, when, target, width, height):
    cmd = [_tool("ffmpeg"), "-y", "-hide_banner", "-loglevel", "error",
           "-ss", f"{max(0.0, float(when)):.3f}", "-i", str(video), "-frames:v", "1", "-an",
           "-vf", f"scale={width}:{height}", str(target)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return Path(target).is_file() and target.stat().st_size > 0 and result.returncode == 0


def _region(box, width, height, full_w, full_h):
    if not box or len(box) != 4:
        return (0, 0, width, height)
    scale_x, scale_y = width / float(full_w or width), height / float(full_h or height)
    x, y, w, h = (float(v) for v in box)
    left = max(0, min(width - 1, int(x * scale_x)))
    top = max(0, min(height - 1, int(y * scale_y)))
    right = max(left + 1, min(width, int((x + w) * scale_x)))
    bottom = max(top + 1, min(height, int((y + h) * scale_y)))
    return (left, top, right, bottom)


def verify(video, overlays, *, limit=8, duration=None) -> dict:
    """Return ``{'checked': n, 'missing': [...], 'per_overlay': [...], 'reason': ...}``."""
    try:
        from PIL import Image, ImageChops, ImageStat
    except Exception as error:  # pragma: no cover - Pillow ships with the app
        return {"checked": 0, "missing": [], "per_overlay": [], "reason": f"Pillow unavailable: {error}"}
    video = Path(video)
    if not video.is_file():
        return {"checked": 0, "missing": [], "per_overlay": [], "reason": "no finished video to check"}
    candidates = [e for e in (overlays or [])
                  if str(e.get("kind")) not in SKIP_KINDS
                  and isinstance(e.get("start"), (int, float)) and isinstance(e.get("end"), (int, float))
                  and float(e["end"]) - float(e["start"]) >= 0.6]
    if not candidates:
        return {"checked": 0, "missing": [], "per_overlay": [], "reason": "nothing to check"}
    candidates = candidates[:max(1, int(limit))]
    try:
        from ..finishing_studio import _probe
        info, total = _probe(video)
        stream = next((s for s in info["streams"] if s.get("codec_type") == "video"), {})
        full_w, full_h = int(stream.get("width") or 0), int(stream.get("height") or 0)
        total = float(duration or total)
    except Exception:
        full_w = full_h = 0
        total = float(duration or 0)
    if not full_w or not full_h:
        return {"checked": 0, "missing": [], "per_overlay": [], "reason": "could not read the video size"}
    width, height = max(160, full_w // 2), max(160, full_h // 2)
    per_overlay, missing = [], []
    folder = Path(tempfile.mkdtemp(prefix=".graphics-check-"))
    try:
        for index, event in enumerate(candidates):
            start, end = float(event["start"]), float(event["end"])
            if total and start >= total:
                per_overlay.append({"kind": event.get("kind"), "start": round(start, 2),
                                    "visible": False, "reason": "card starts after the end of the video"})
                missing.append(f"{event.get('kind')} at {start:.1f}s (past the end)")
                continue
            mid = start + max(0.2, (end - start) / 2)
            control = start - 0.6 if start > 0.8 else min(end + 0.6, (total or end + 0.6) - 0.05)
            on_frame, off_frame = folder / f"{index}-on.png", folder / f"{index}-off.png"
            if not (_grab(video, min(mid, max(0.0, (total or mid) - 0.05)), on_frame, width, height)
                    and _grab(video, max(0.0, control), off_frame, width, height)):
                per_overlay.append({"kind": event.get("kind"), "start": round(start, 2),
                                    "visible": False, "reason": "frames could not be read"})
                missing.append(f"{event.get('kind')} at {start:.1f}s (frames unreadable)")
                continue
            try:
                with Image.open(on_frame) as first, Image.open(off_frame) as second:
                    first = first.convert("RGB")
                    second = second.convert("RGB")
                    first = first.resize((width, height))
                    second = second.resize((width, height))
                    region = _region(event.get("box"), width, height, full_w, full_h)
                    delta = ImageStat.Stat(ImageChops.difference(first.crop(region), second.crop(region))).mean
                    score = sum(delta) / max(1, len(delta))
            except Exception as error:
                per_overlay.append({"kind": event.get("kind"), "start": round(start, 2),
                                    "visible": False, "reason": f"frame compare failed: {error}"})
                missing.append(f"{event.get('kind')} at {start:.1f}s (compare failed)")
                continue
            visible = score >= VISIBLE_MEAN_DELTA
            per_overlay.append({"kind": event.get("kind"), "start": round(start, 2),
                                "seconds": round(end - start, 2), "visible": visible,
                                "mean_pixel_delta": round(score, 2),
                                "region": list(region)})
            if not visible:
                missing.append(f"{event.get('kind')} at {start:.1f}s")
    finally:
        shutil.rmtree(folder, ignore_errors=True)
    return {"checked": len(per_overlay), "missing": missing, "per_overlay": per_overlay,
            "threshold_mean_delta": VISIBLE_MEAN_DELTA,
            "reason": "" if per_overlay else "nothing to check"}

"""Render the reviewed language editions of a finished production.

The production's own final render stays the primary-language edition. Each
additional edition is built from the same clean visual master (picture only),
its exact reviewed narration, its timed cards and word-timed captions, and the
channel profile chosen in Create. Nothing here calls Gemini, Flow or any visual
generator, and nothing is overwritten: each export is a new file.

State lives in the job:
  production/language_editions.json       selections saved by Create (inputs)
  production/language_editions_render.json per-language render record (outputs)
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from . import finishing_studio as finish

STATE_NAME = 'language_editions.json'
RECORD_NAME = 'language_editions_render.json'


def _read(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding='utf8'))


def _label(code):
    return finish.LANGUAGES.get(code, code)


def _production_music(job_root):
    """Reuse the primary production's background track, with its recorded licence."""
    sound = _read(Path(job_root) / 'audio' / 'sound_plan.json', {}) or {}
    music = sound.get('music')
    if isinstance(music, str):
        music = {'path': music}
    if not isinstance(music, dict) or not music.get('path'):
        return None, ''
    path = Path(music['path'])
    if not path.is_file():
        return None, ''
    licence = ' · '.join(str(x) for x in (music.get('source'), music.get('license')) if x) or \
        'Production background track; licence recorded in the job provenance'
    return str(path), licence


def _record_path(job_root):
    return Path(job_root) / 'production' / RECORD_NAME


def _save_record(job_root, record):
    record['updated_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    finish._atomic_json(_record_path(job_root), record)


def requested_languages(job_root):
    """(source_language, additional_languages, state) for a job; empty when single-language."""
    state = _read(Path(job_root) / 'production' / STATE_NAME)
    if not state:
        return None, [], None
    source = str(state.get('source_language') or 'en')
    editions = list(dict.fromkeys(state.get('editions') or [source]))
    return source, [code for code in editions if code != source], state


def render_job_editions(job_root, *, progress=None):
    """Render every pending additional edition. Returns a status report; never silently English.

    Status values: ``not_requested`` (no language state), ``single_language``,
    ``exported`` (all editions current), ``partial`` or ``failed`` (see ``editions``).
    Raises ValueError only for preconditions the user must fix first.
    """
    job_root = Path(job_root).resolve()
    emit = progress or (lambda label, pct, detail='': None)
    source, extra, state = requested_languages(job_root)
    if state is None:
        return {'status': 'not_requested', 'editions': {}}
    if not extra:
        return {'status': 'single_language', 'editions': {}}

    bundles = state.get('bundles') or {}
    not_ready = [code for code in extra if code not in bundles]
    if not_ready:
        raise ValueError('Approve and prepare the narration for ' + ', '.join(_label(c) for c in not_ready) +
                         ' in Create step 4 before rendering language editions. No English voice is used as a fallback.')
    visual_record = _read(job_root / 'production' / 'visual_master.json')
    if not visual_record:
        raise ValueError('The clean visual master is missing. Render this production again so the language '
                         'editions use the approved picture.')
    visual = Path(visual_record['path'])
    if not visual.is_file() or finish._hash(visual) != visual_record.get('sha256'):
        raise ValueError('The clean visual master changed or is missing. Render this production again.')

    record = _read(_record_path(job_root), {'schema_version': 1, 'editions': {}})
    previous = record.get('editions', {})
    pending = []
    for code in extra:
        bundle_sha = bundles[code].get('audio_sha256')
        entry = previous.get(code, {})
        export = Path(entry.get('path', '')) if entry.get('path') else None
        current = (entry.get('status') == 'exported' and entry.get('audio_sha256') == bundle_sha
                   and export is not None and export.is_file() and finish._hash(export) == entry.get('sha256'))
        if not current:
            pending.append(code)
    if not pending:
        return {'status': 'exported', 'editions': previous, 'record': str(_record_path(job_root))}

    profiles = state.get('profiles') or {}
    music_path, music_licence = _production_music(job_root)
    plan_path = finish.create_plan(
        visual, {code: profiles.get(code) for code in pending}, languages=pending,
        output_root=job_root / 'language_editions', source_rights='own_content',
        shared_music=music_path, shared_music_license=music_licence,
        source_language=source, require_profiles=False, fit_narration=True, captions=True)
    plan = json.loads(Path(plan_path).read_text(encoding='utf8'))
    for code in pending:
        finish.set_edition(plan_path, code, reviewed=True)

    record.update({'schema_version': 1, 'source_language': source, 'plan': str(plan_path)})
    failures = []
    for index, code in enumerate(pending):
        label = _label(code)
        entry = {'status': 'rendering', 'plan': str(plan_path), 'audio_sha256': bundles[code].get('audio_sha256'),
                 'channel': plan['editions'][code].get('channel', {})}
        record.setdefault('editions', {})[code] = entry
        _save_record(job_root, record)
        emit('Rendering ' + label + ' edition', 100 * index / len(pending), label)

        def edition_progress(value, _index=index, _label=label):
            emit('Rendering ' + _label + ' edition', 100 * (_index + float(value)) / len(pending), _label)
        try:
            exported = finish.render(plan_path, code, progress=edition_progress)
            entry.update(status='exported', path=str(exported), sha256=finish._hash(exported))
        except Exception as error:  # keep the primary edition and every finished edition
            entry.update(status='failed', error=str(error)[:800])
            failures.append(label + ': ' + str(error)[:300])
        entry['finished_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        _save_record(job_root, record)
    emit('Language editions finished', 100)

    statuses = {code: record['editions'][code].get('status') for code in extra}
    if all(status == 'exported' for status in statuses.values()):
        overall = 'exported'
    elif any(status == 'exported' for status in statuses.values()):
        overall = 'partial'
    else:
        overall = 'failed'
    record['status'] = overall
    _save_record(job_root, record)
    return {'status': overall, 'editions': record['editions'], 'record': str(_record_path(job_root)),
            'error': '; '.join(failures)}

"""Optional, exact-file channel-logo snapshots for highlight and B-roll renders."""
import hashlib
import math
import os
from pathlib import Path
from PIL import Image, ImageOps

POSITIONS = ('top-right', 'top-left', 'bottom-right', 'bottom-left')


def validate_clip_logo(enabled=False, path='', size=.12, position='top-right'):
    if type(enabled) is not bool:
        raise ValueError('Show channel logo must be true or false')
    if not enabled:
        return None
    if type(size) not in (int, float) or not math.isfinite(size) or not .05 <= size <= .25:
        raise ValueError('Logo size must be 5–25 percent of frame width')
    if position not in POSITIONS:
        raise ValueError('Unsupported channel logo position')
    p=Path(path).expanduser().resolve()
    if not p.is_file():
        raise ValueError('Select a playable PNG/JPEG/WebP logo image before creating clips')
    with Image.open(p) as image:
        if image.format not in ('PNG', 'JPEG', 'WEBP') or image.width*image.height > 25_000_000:
            raise ValueError('Logo must be a PNG/JPEG/WebP image up to 25 megapixels')
        image.verify()
    return {'source_path':str(p), 'size':float(size), 'position':position,
            'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}


def prepare_clip_logo(options, work, width, height):
    if options is None:
        return {}
    src=Path(options['source_path'])
    if hashlib.sha256(src.read_bytes()).hexdigest()!=options['source_sha256']:
        raise ValueError('Channel logo changed during preparation; reselect it')
    with Image.open(src) as im:
        logo=ImageOps.exif_transpose(im).convert('RGBA')
    logo.thumbnail((max(1,int(width*options['size'])),max(1,int(height*.12))),Image.Resampling.LANCZOS)
    canvas=Image.new('RGBA',(width,height),(0,0,0,0))
    margin=max(8,int(min(width,height)*.035))
    x=margin if options['position'].endswith('left') else width-logo.width-margin
    y=margin if options['position'].startswith('top') else height-logo.height-margin
    canvas.alpha_composite(logo,(x,y))
    folder=Path(work);folder.mkdir(parents=True,exist_ok=True)
    name=hashlib.sha256(repr(sorted(options.items())).encode()+f'{width}x{height}'.encode()).hexdigest()[:20]
    out=folder/f'channel-logo-{name}.png';tmp=out.with_suffix('.tmp.png')
    try:
        canvas.save(tmp,format='PNG');os.replace(tmp,out)
    finally:
        tmp.unlink(missing_ok=True)
    return {**options,'overlay_path':str(out.resolve()),'overlay_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
            'width':width,'height':height,'enabled':True}


def clip_logo_path(branding):
    if not branding or not branding.get('enabled'):
        return ''
    path=Path(branding.get('overlay_path') or '')
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=branding.get('overlay_sha256'):
        raise ValueError('Saved channel logo changed or is missing; restore the exact logo snapshot')
    return str(path)

"""A quiet original instrumental loop: no browser, network or third-party track."""
from pathlib import Path
import wave


def create_instrumental(workdir):
    import numpy as np
    from .music_provider import _sha256
    root = Path(workdir)
    root.mkdir(parents=True, exist_ok=True)
    path = root/'original-soft-instrumental.wav'
    rate, seconds = 48000, 32
    audio = np.zeros((rate*seconds, 2), dtype=np.float64)
    chords = [(48, 60, 64, 67), (45, 57, 60, 64), (41, 53, 57, 60), (43, 55, 59, 62)]
    for beat in range(32):
        chord = chords[(beat//8) % 4]
        note = chord[(beat % 4)]
        t = np.arange(rate*3)/rate
        frequency = 440*2**((note-69)/12)
        envelope = np.minimum(t/.025, 1)*np.exp(-t*1.7)
        sound = (np.sin(2*np.pi*frequency*t) + .2*np.sin(4*np.pi*frequency*t)
                 + .06*np.sin(6*np.pi*frequency*t))*envelope*.13
        start = beat*rate
        sound = sound[:len(audio)-start]
        pan = .35 if beat % 2 else .65
        audio[start:start+len(sound), 0] += sound*(1-pan)
        audio[start:start+len(sound), 1] += sound*pan
    fade = np.minimum(np.arange(len(audio))/rate, 1)*np.minimum(np.arange(len(audio))[::-1]/rate, 1)
    pcm = (np.clip(audio*fade[:, None], -.95, .95)*32767).astype('<i2')
    temporary = path.with_suffix('.tmp.wav')
    with wave.open(str(temporary), 'wb') as out:
        out.setnchannels(2); out.setsampwidth(2); out.setframerate(rate)
        out.writeframes(pcm.tobytes())
    temporary.replace(path)
    return {'path': str(path.resolve()), 'source': 'local-generated-instrumental',
            'sha256': _sha256(path), 'license': 'Original procedural composition',
            'provenance_note': 'Generated locally by AutoVideoAI; no downloaded song or voice.'}

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec python3 cli.py v3 dashboard "$@"

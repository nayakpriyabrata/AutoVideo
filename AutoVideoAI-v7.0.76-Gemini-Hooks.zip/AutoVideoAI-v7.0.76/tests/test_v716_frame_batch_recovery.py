import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from PIL import Image
from engine.factory import Factory,FlowFrameBatchPending
from engine.providers.flow_browser import FlowRequestPending
from tests.test_economy_parallel_frames import _shot,_Refs,_ProjectLog


def setup_batch(tmp_path, blocked):
    root=tmp_path/'job';storyboard=root/'storyboard';storyboard.mkdir(parents=True)
    calls=[]
    class Flow:
        def generate_image(self,shot,compiled,out,vertical,dry_run=False):
            name=Path(out).name;calls.append(name)
            if name in blocked:raise FlowRequestPending('Exact saved request still unresolved; no new generation')
            color=tuple(hashlib.sha256(compiled['prompt'].encode()).digest()[:3])
            Image.new('RGB',(96,96),color).save(out)
            return {'path':out,'provider':'flow','project_url':'https://flow.google.com/project/exact'}
        def current_project_url(self):return 'https://flow.google.com/project/exact'
        def close(self):pass
    f=Factory.__new__(Factory);f.pm=_ProjectLog()
    f._providers=lambda:{'flow':Flow(),'image':NS()}
    f._remember_flow_project_url=lambda job,url:url
    f._pause_pending_flow=lambda *a,**kw:pytest.fail('Must finish the batch before pausing')
    f._generate_economy_frames_parallel=lambda *a,**kw:pytest.fail('Batch must keep the existing serial project journals')
    m=NS(job_id='job',profile='STORYBOARD_ECONOMY',target_seconds=45,
         shots=[_shot(f'shot_{i:03d}',provider='flow',coverage='insert') for i in range(1,4)])
    D={'root':str(root),'storyboard':str(storyboard),'flow':str(root/'flow')}
    settings={'frame_source':'flow','flow_image_workers':3,'flow_reuse_project_media':False,
              'flow_frame_retries':1,'flow_project_url':'https://flow.google.com/project/exact',
              'flow_continue_unresolved_frames':True,'flow_pause_on_unresolved_request':True}
    return f,m,D,settings,calls


def test_blocked_close_keeps_other_frames_and_resume_retries_only_missing(tmp_path):
    blocked={'shot_001_close.jpg','shot_003_open.jpg'}
    f,m,D,settings,calls=setup_batch(tmp_path,blocked)
    journal=Path(D['storyboard'])/'shot_001_close.jpg.flow-request.json'
    journal.write_text('{"status":"pending","request_hash":"protected"}')
    original=journal.read_bytes()
    with pytest.raises(FlowFrameBatchPending) as error:
        f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    report=error.value.report
    assert report['valid_frames']==4 and len(report['unresolved'])==2
    assert report['new_replacement_generations']==0 and report['media_substitutions']==0
    assert not report['video_generation_started']
    assert 'shot_002_close.jpg' in calls and 'shot_003_close.jpg' in calls
    assert journal.read_bytes()==original
    assert json.loads((Path(D['root'])/'flow_frame_recovery_batch.json').read_text())==report
    calls.clear()
    with pytest.raises(FlowFrameBatchPending):
        f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    assert calls==['shot_001_close.jpg','shot_003_open.jpg']
    blocked.clear();calls.clear()
    f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    resolved=json.loads((Path(D['root'])/'flow_frame_recovery_batch.json').read_text())
    assert resolved['valid_frames']==6 and not resolved['unresolved']
    assert calls==['shot_001_close.jpg','shot_003_open.jpg']
    assert journal.read_bytes()==original


def test_batch_off_retains_existing_stop_behavior(tmp_path):
    f,m,D,settings,calls=setup_batch(tmp_path,{'shot_001_close.jpg'})
    settings.update(flow_continue_unresolved_frames=False,flow_image_workers=1,
                    flow_pause_on_unresolved_request=False)
    with pytest.raises(RuntimeError):
        f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    assert 'shot_002_open.jpg' not in calls


def test_policy_is_persisted_only_for_supported_existing_jobs(tmp_path):
    f=Factory.__new__(Factory)
    f.pm=NS(load_manifest=lambda job:NS(profile='STORYBOARD_ECONOMY'),job_dir=lambda job:str(tmp_path),log=lambda *a:None)
    f._settings=lambda job:{'frame_source':'flow'}
    assert f.set_flow_frame_batch_recovery('job',True)
    assert json.loads((tmp_path/'settings.json').read_text())['flow_continue_unresolved_frames'] is True
    f._settings=lambda job:{'frame_source':'free'}
    with pytest.raises(ValueError):f.set_flow_frame_batch_recovery('job',True)


def test_saved_parallel_request_keeps_original_project_and_output(tmp_path):
    from engine.planning.frame_prompts import frame_prompt
    f,m,D,settings,calls=setup_batch(tmp_path,set())
    shot=m.shots[0];prompt=frame_prompt(shot,{},False,'open');label='opening frame'
    token=hashlib.sha256(f'{m.job_id}|{shot.shot_id}|{label}|{prompt}|{False}'.encode()).hexdigest()[:16]
    artifact=Path(D['root'])/'.flow-workers/economy-frame-artifacts'/f'{shot.shot_id}_open_{token}.jpg'
    artifact.parent.mkdir(parents=True)
    journal=Path(str(artifact)+'.flow-request.json')
    journal.write_text(json.dumps({'status':'pending','project_url':'https://flow.google.com/project/original-worker'}))
    original=journal.read_bytes();used=[]
    main=f._providers()['flow'];normal=main.generate_image
    def generate(shot,compiled,out,vertical,dry_run=False):
        if out==str(artifact):
            used.append(compiled['project_url']);Image.new('RGB',(96,96),'orange').save(out)
            return {'path':out,'provider':'flow'}
        return normal(shot,compiled,out,vertical,dry_run)
    main.generate_image=generate;f._providers=lambda:{'flow':main,'image':NS()}
    f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    assert used==['https://flow.google.com/project/original-worker']
    assert 'shot_001_open.jpg' not in calls
    assert (Path(D['storyboard'])/'shot_001_open.jpg').read_bytes()==artifact.read_bytes()
    assert journal.read_bytes()==original


def test_pending_parallel_frame_defers_without_new_serial_submission(tmp_path):
    from engine.planning.frame_prompts import frame_prompt
    f,m,D,settings,calls=setup_batch(tmp_path,set())
    shot=m.shots[0];prompt=frame_prompt(shot,{},False,'open');label='opening frame'
    token=hashlib.sha256(f'{m.job_id}|{shot.shot_id}|{label}|{prompt}|{False}'.encode()).hexdigest()[:16]
    artifact=Path(D['root'])/'.flow-workers/economy-frame-artifacts'/f'{shot.shot_id}_open_{token}.jpg'
    artifact.parent.mkdir(parents=True)
    journal=Path(str(artifact)+'.flow-request.json');journal.write_text(json.dumps({'status':'pending','project_url':'https://flow.google.com/project/original-worker'}))
    main=f._providers()['flow'];normal=main.generate_image
    def generate(shot,compiled,out,vertical,dry_run=False):
        if out==str(artifact):raise FlowRequestPending('Worker exact asset unavailable')
        return normal(shot,compiled,out,vertical,dry_run)
    main.generate_image=generate;f._providers=lambda:{'flow':main,'image':NS()}
    with pytest.raises(FlowFrameBatchPending) as result:
        f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    assert 'shot_001_open.jpg' not in calls and 'shot_003_close.jpg' in calls
    assert result.value.report['unresolved'][0]['request_file']==str(journal.relative_to(D['root']))

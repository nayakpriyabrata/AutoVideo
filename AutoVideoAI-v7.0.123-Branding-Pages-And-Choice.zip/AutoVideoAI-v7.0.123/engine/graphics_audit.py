"""Say plainly why on-screen cards or hooks did - or did not - appear (v7.0.107).

Field report: cards were called "not good" and the pop-up card feature "not visible" in the finished
video, and hooks were "missing", while the job log listed graphics. From the outside there was no way to
tell whether cards were switched off, drafted but unused, dropped for overlapping, or lost in the render.

Every render now writes ``production/graphics_audit.json``: what was asked for, what existed on disk, what
was actually placed on the timeline, and - when the master exists - whether each card can be *seen* in the
finished file (frame comparison, see ``engine/render/graphic_visibility.py``). The same report is printed by
``python3 cli.py v3 graphics-audit <job>`` and summarised in the job warnings.

This module is pure bookkeeping: it never renders and never fails a job.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

SCHEMA = "graphics-audit-v1"


def _read(path, default=None):
    try:
        path = Path(path)
        if not path.is_file():
            return default
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def plan_path(job_root):
    """Where this job's overlay plan lives (job root, as the renderer writes it, or production/)."""
    root = Path(job_root)
    for candidate in (root / "graphics_plan.json", root / "production" / "graphics_plan.json"):
        if candidate.is_file():
            return candidate
    return root / "graphics_plan.json"


def _count(kind_map, key):
    return int(kind_map.get(key, 0) or 0)


def _prepared(job_root):
    """What card/hook work already exists on disk before the render places anything."""
    root = Path(job_root)
    speech = _read(root / "production" / "speech_cards.json", {}) or {}
    hooks = _read(root / "production" / "hooks.json", {}) or {}
    return {
        "speech_cards_file": (root / "production" / "speech_cards.json").is_file(),
        "speech_cards_drafted": len(speech.get("cards") or []),
        "speech_series_points": len(((speech.get("series") or {}).get("points")) or []),
        "speech_cards_drafted_at": speech.get("created_at") or speech.get("drafted_at"),
        "hooks_file": (root / "production" / "hooks.json").is_file(),
        "hooks_drafted": len(hooks.get("hooks") or []),
        "hooks_drafted_at": hooks.get("created_at") or hooks.get("drafted_at"),
    }


def _kinds(overlays):
    counts: dict[str, int] = {}
    for event in overlays or []:
        kind = str((event or {}).get("kind") or "unknown")
        counts[kind] = counts.get(kind, 0) + 1
    return dict(sorted(counts.items()))


def build_report(job_root, *, settings=None, overlays=None, errors=None, dropped_hooks=0,
                 prepared=None, verified=None):
    """Every fact needed to explain the on-screen graphics of one job."""
    settings = settings or {}
    overlays = list(overlays or [])
    prepared = dict(prepared if prepared is not None else _prepared(job_root))
    kinds = _kinds(overlays)
    # 'logo' is the persistent channel logo, not a text card (v7.0.109).
    cards_on_timeline = sum(count for kind, count in kinds.items()
                            if kind not in ("watermark", "hook", "logo"))
    hooks_on_timeline = _count(kinds, "hook")
    text_cards = bool(settings.get("text_cards_enabled", settings.get("text_cards", False)))
    speech_cards = bool(settings.get("speech_cards_enabled", False))
    hooks_enabled = bool(settings.get("hooks_enabled", False))
    problems, notes = [], []

    def problem(code, message, fix):
        problems.append({"code": code, "message": message, "fix": fix})

    def note(code, message, fix=""):
        notes.append({"code": code, "message": message, "fix": fix})

    if not text_cards:
        problem("text_cards_off",
                "Text cards were switched off for this job, so the video only carries the channel watermark.",
                "Turn on 'Text cards / speech-timed cards' in Create (Finishing options) and render again.")
    elif cards_on_timeline == 0:
        problem("no_cards_placed",
                "Text cards were requested but not one card reached the timeline.",
                "Open production/graphics_audit.json for the drafting error, then Resume the job to rebuild cards.")
    if not speech_cards and prepared.get("speech_cards_drafted"):
        note("speech_cards_unused",
             f"{prepared.get('speech_cards_drafted', 0)} reviewed speech cards were already prepared, but "
             "'Use speech-timed Gemini cards' is off, so the automatic keypoint cards were used instead.",
             "Tick 'Use speech-timed Gemini cards' to use the prepared cards, or delete "
             "production/speech_cards.json to silence this note.")
    if speech_cards and not prepared.get("speech_cards_drafted"):
        problem("speech_cards_missing",
                "Speech cards are enabled but production/speech_cards.json does not exist or has no cards.",
                "Resume the job: the prepare stage drafts the cards before the render.")
    if not hooks_enabled:
        note("hooks_off",
             "Hook pills were not requested for this job (the option is off by default).",
             "Tick 'Add Gemini Web hooks' when creating the job, or set hooks_enabled and Resume.")
    elif hooks_on_timeline == 0:
        reason = "; ".join(f"{item.get('stage')}: {item.get('error')}" for item in (errors or [])
                           if item.get("stage", "").startswith("hook"))
        problem("hooks_not_placed",
                "Hooks were requested but none reached the timeline."
                + (f" Reason: {reason}" if reason else
                   (f" {dropped_hooks} hook(s) were dropped for overlapping another card." if dropped_hooks
                    else f" production/hooks.json holds {prepared.get('hooks_drafted', 0)} drafted hook(s).")),
                "Resume the job to refresh hooks against the current narration, then render again.")
    elif dropped_hooks:
        note("hooks_dropped",
             f"{dropped_hooks} hook(s) were dropped because they would have covered a card.",
             "Re-draft hooks after the cards settle, or accept the remaining hooks.")
    for item in errors or []:
        problem(item.get("stage", "graphics_error"), str(item.get("error") or "")[:400],
                "Fix that cause and Resume; the render continued without it.")
    report = {
        "schema": SCHEMA,
        "checked_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "requested": {"text_cards": text_cards, "speech_cards": speech_cards, "hooks": hooks_enabled},
        "prepared": prepared,
        "on_timeline": {"total": len(overlays), "by_kind": kinds, "cards": cards_on_timeline,
                        "hooks": hooks_on_timeline},
        "problems": problems,
        "notes": notes,
        "verified_in_video": verified or {"checked": 0, "reason": "not_run"},
    }
    report["verdict"] = ("no_cards" if text_cards and cards_on_timeline == 0
                         else "cards_placed" if cards_on_timeline
                         else "off")
    return report


def write(job_root, report):
    """Save the audit next to the plan; never raise into a render."""
    path = Path(job_root) / "production" / "graphics_audit.json"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        return path
    except OSError:
        return None


def warnings(report):
    """Short lines for the job warnings list; problems first."""
    lines = []
    for item in report.get("problems") or []:
        lines.append(f"On-screen graphics: {item['message']} Fix: {item['fix']}")
    for item in report.get("notes") or []:
        if item.get("code") in ("hooks_off", "speech_cards_unused"):
            lines.append(f"On-screen graphics: {item['message']} {item.get('fix') or ''}".strip())
    seen = report.get("verified_in_video") or {}
    if seen.get("checked"):
        missing = seen.get("missing") or []
        if missing:
            lines.append(
                "On-screen graphics: " + str(len(missing)) + " card(s) could not be found in the finished "
                f"video ({', '.join(missing[:4])}). See production/graphics_audit.json.")
        else:
            lines.append(f"On-screen graphics: all {seen['checked']} sampled card(s) are visible in the "
                         "finished video.")
    return lines


def explain(job_root):
    """The stored audit as readable text, rebuilt from the plan when the audit is missing."""
    root = Path(job_root)
    report = _read(root / "production" / "graphics_audit.json")
    if not report:
        overlays = _read(plan_path(root), []) or []
        report = build_report(root, overlays=overlays)
        report["source"] = "rebuilt from " + str(plan_path(root).relative_to(root)) + " (no audit was written)"
    lines = []
    requested = report.get("requested") or {}
    timeline = report.get("on_timeline") or {}
    prepared = report.get("prepared") or {}
    lines.append("Graphics audit · job " + root.name)
    if report.get("source"):
        lines.append("  source: " + str(report["source"]))
    lines.append("  requested: text cards " + ("on" if requested.get("text_cards") else "off")
                 + " · speech cards " + ("on" if requested.get("speech_cards") else "off")
                 + " · hooks " + ("on" if requested.get("hooks") else "off"))
    lines.append(f"  prepared: {prepared.get('speech_cards_drafted', 0)} speech card(s), "
                 f"{prepared.get('speech_series_points', 0)} series point(s), "
                 f"{prepared.get('hooks_drafted', 0)} hook(s)")
    kinds = ", ".join(f"{kind} x{count}" for kind, count in (timeline.get("by_kind") or {}).items()) or "none"
    lines.append(f"  on the timeline: {timeline.get('total', 0)} overlay(s) · {kinds}")
    for item in report.get("problems") or []:
        lines.append(f"  PROBLEM [{item['code']}] {item['message']}")
        if item.get("fix"):
            lines.append(f"          fix: {item['fix']}")
    for item in report.get("notes") or []:
        lines.append(f"  note    [{item['code']}] {item['message']}")
        if item.get("fix"):
            lines.append(f"          fix: {item['fix']}")
    seen = report.get("verified_in_video") or {}
    if seen.get("checked"):
        lines.append(f"  seen in the video: {seen['checked'] - len(seen.get('missing') or [])}"
                     f"/{seen['checked']} sampled card(s)")
        for name in seen.get("missing") or []:
            lines.append(f"          missing at {name}")
    elif seen.get("reason"):
        lines.append("  seen in the video: not checked (" + str(seen["reason"]) + ")")
    return "\n".join(lines)

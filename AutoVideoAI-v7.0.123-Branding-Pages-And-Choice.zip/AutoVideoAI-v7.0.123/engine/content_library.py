"""Local, versioned original-character library. Never uploads or clones a real person."""
from pathlib import Path
import json
import re
import shutil
import hashlib
import uuid

from PIL import Image
from .production import save, read, digest


class CharacterLibrary:
    def __init__(self, root='data/content/characters'):
        self.root = Path(root).resolve()

    def _folder(self, identifier):
        if not re.fullmatch(r'[a-z0-9-]{1,80}', str(identifier)):
            raise ValueError('Invalid character ID')
        return self.root / identifier

    def create(self, name, description, *, reference_files=(), original_confirmed=False, voice_style='unspecified'):
        if voice_style not in ('unspecified','masculine','feminine'):
            raise ValueError('Choose an explicit character voice style')
        if original_confirmed is not True:
            raise ValueError('Confirm this is your original/authorized fictional character; no impersonation')
        if not str(name).strip() or len(str(description).strip()) < 20:
            raise ValueError('Give the character a name and a detailed original physical description')
        identifier = re.sub(r'[^a-z0-9]+', '-', str(name).lower()).strip('-')[:45] or 'character'
        identifier += '-' + uuid.uuid4().hex[:8]
        folder = self._folder(identifier)
        records = []
        # Validate every supplied image before creating a library entry.
        for filename in reference_files:
            path = Path(filename).expanduser().resolve()
            if not path.is_file() or path.suffix.lower() not in ('.png','.jpg','.jpeg','.webp'):
                raise ValueError('Character references must be local PNG/JPEG/WebP images')
            if path.stat().st_size > 20*1024*1024:
                raise ValueError('Character reference exceeds 20 MB')
            with Image.open(path) as im:
                im.verify()
            records.append((path, digest(path)))
        folder.mkdir(parents=True)
        refs = []
        for source, sha in records:
            target = folder / (sha + source.suffix.lower())
            shutil.copy2(source, target)
            refs.append({'path':target.name, 'sha256':sha})
        value = {'schema_version':1, 'id':identifier, 'name':str(name).strip(),
                 'description':str(description).strip(), 'original_confirmed':True,
                 'references':refs, 'voice_style':voice_style, 'version':1, 'type':'original-fictional-character'}
        save(folder/'character.json', value)
        return self.get(identifier)

    def get(self, identifier):
        value = read(self._folder(identifier)/'character.json')
        if not value:
            raise ValueError('Character not found')
        for reference in value['references']:
            path = Path(reference['path'])
            if not path.is_absolute():path=self._folder(identifier)/path
            if not path.is_file() or not path.resolve().is_relative_to(self._folder(identifier)):
                legacy = Path(reference['path'])
                if legacy.is_absolute() and (legacy.parent.name != identifier or legacy.parent.parent.name != 'characters'):
                    raise ValueError('Character reference is outside the library; reapprove it')
                path=self._folder(identifier)/legacy.name
            path=path.resolve()
            if not path.is_relative_to(self._folder(identifier)) or digest(path) != reference['sha256']:
                raise ValueError('Character reference is outside the library or changed; reapprove it')
            reference['path']=str(path)
        return value

    def set_voice_style(self,identifier,style):
        if style not in ('unspecified','masculine','feminine'):raise ValueError('Invalid voice style')
        self.get(identifier)
        path=self._folder(identifier)/'character.json'
        record=read(path);record['voice_style']=style;save(path,record)
        return self.get(identifier)

    def set_preview_crop(self, identifier, x, y, zoom):
        self.get(identifier)
        if not 0<=float(x)<=1 or not 0<=float(y)<=1 or not 1<=float(zoom)<=8:
            raise ValueError('Invalid preview crop')
        path=self._folder(identifier)/'character.json';record=read(path)
        record['preview_crop']={'x':float(x),'y':float(y),'zoom':float(zoom)}
        save(path,record)
        return self.get(identifier)

    def list(self):
        if not self.root.exists():
            return []
        return [self.get(p.parent.name) for p in sorted(self.root.glob('*/character.json'))
                if not read(p, {}).get('archived')]

    def update(self, identifier, name, description, *, reference_files=None, voice_style='unspecified'):
        """Keep old reference files: already approved jobs retain their exact photos."""
        self.get(identifier)
        if not str(name).strip() or len(str(description).strip()) < 20:
            raise ValueError('Give the character a name and a detailed description')
        if voice_style not in ('unspecified', 'masculine', 'feminine'):
            raise ValueError('Invalid voice style')
        path = self._folder(identifier)/'character.json'
        record = read(path)
        refs = record['references']
        if reference_files is not None:
            validated = []
            for filename in reference_files:
                source = Path(filename).expanduser().resolve()
                if source.suffix.lower() not in ('.png', '.jpg', '.jpeg', '.webp') or source.stat().st_size > 20*1024*1024:
                    raise ValueError('References must be PNG/JPEG/WebP up to 20 MB')
                with Image.open(source) as image:
                    image.verify()
                validated.append((source, digest(source)))
            refs = []
            for source, sha in validated:
                target = path.parent/(sha+source.suffix.lower())
                if source != target:
                    shutil.copy2(source, target)
                refs.append({'path': target.name, 'sha256': sha})
            record.pop('preview_crop', None)
        record.update(name=str(name).strip(), description=str(description).strip(),
                      voice_style=voice_style, references=refs, version=record.get('version', 1)+1)
        save(path, record)
        return self.get(identifier)

    def archive(self, identifier):
        self.get(identifier)
        path = self._folder(identifier)/'character.json'
        record = read(path); record['archived'] = True
        save(path, record)


def character_snapshot(character):
    """Provider-neutral identity contract, retained with each project."""
    return {'id':character['id'], 'version':character['version'], 'name':character['name'],
            'canonical':character['description'], 'references':character['references'], 'voice_style':character.get('voice_style','unspecified'),
            'sha256':hashlib.sha256(json.dumps(character, sort_keys=True).encode()).hexdigest()}

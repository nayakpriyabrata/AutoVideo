# AutoVideoAI 7.0.25 · Readable light and dark themes

This corrects the mixed-theme defect in 7.0.24: pale surfaces were combined with Streamlit's dark-theme white labels and dark widgets. The whole Studio surface now has paired foreground/background colors, including the sidebar, field values, placeholders, dropdown menus, buttons, captions, alerts, uploads, and code panels.

Choose **Appearance → Light or Dark** in the Studio sidebar. The choice stays active while navigating pages in your Studio session. In the private control center, use **Theme** in the top bar; that preference is saved locally in your browser. These options do not change job settings or generation behavior.

## Upgrade

Stop Studio/CLI jobs, extract this build into a fresh folder, then run from the new folder:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.24 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.24 . --apply
python3 -m streamlit run app.py
```

Use your actual old folder name. Review the migration preview and warnings before applying. Jobs, characters, recovery journals, and safe cleanup behavior are preserved. Reload the Studio browser tab after starting the new installation.

## Review and validation

The supplied screenshot was inspected. Automated checks verify Light/Dark switching, navigation with the selected theme, and WCAG AA contrast of at least 4.5:1 for normal text and muted labels on the declared theme surfaces. Control-center checks cover theme switching and existing drafts, start approvals, resume, recovery, and log interactions. Browser visual rendering on Windows/WSL and live external generation remain unverified; these checks do not establish that every browser-rendered pixel or provider workflow has been tested.

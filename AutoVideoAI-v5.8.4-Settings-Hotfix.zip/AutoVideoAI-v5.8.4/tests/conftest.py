"""Shared fixtures: isolated cwd, synthetic videos, fake word timings."""
import os
import cv2
import numpy as np
import pytest


@pytest.fixture()
def workdir(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    return tmp_path


def make_video(path: str, n: int = 48, w: int = 320, h: int = 576,
               mode: str = "motion", fps: int = 24):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    vw = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    for i in range(n):
        if mode == "black":
            fr = np.zeros((h, w, 3), np.uint8)
        elif mode == "frozen":
            fr = np.full((h, w, 3), 120, np.uint8)
        else:  # motion: moving gradient + box
            fr = np.zeros((h, w, 3), np.uint8)
            fr[:] = (60 + i * 2) % 200
            x = int((i / n) * (w - 60))
            cv2.rectangle(fr, (x, h // 3), (x + 60, h // 3 + 120), (255, 255, 255), -1)
            cv2.putText(fr, "test", (30, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        vw.write(fr)
    vw.release()
    return path


def fake_words(n_sent: int = 8, sent_dur: float = 4.0):
    words, t = [], 0.0
    for s in range(n_sent):
        for k in range(10):
            w = f"word{k}." if k == 9 else f"word{k}"
            words.append({"word": w, "start": round(t, 2), "end": round(t + 0.35, 2)})
            t += 0.4
    return words

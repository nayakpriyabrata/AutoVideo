# AutoVideoAI 7.0.26 · Warm theme and light dropdown correction

Choose **Light**, **Warm**, or **Dark** from Appearance in the Studio sidebar. The private control center has the same choices in its top-bar Theme selector.

Warm uses soft beige backgrounds, ivory fields, dark charcoal text, and muted green accents. It offers an alternative to bright white and dark navy. Dark retains its existing palette. Studio remembers your choice while navigating within the active session; the control center saves it in your browser.

The supplied screenshots showed that Light still had native dark dropdown backgrounds. This build adds styling for Streamlit's newer React Aria select controls and their popup menus, alongside the existing Base Web styling. Selected values now have an explicit field background paired with readable text.

## Upgrade

Stop Studio/CLI jobs. Extract into a fresh folder and run from that folder:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.25 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.25 . --apply
python3 -m streamlit run app.py
```

Use your actual previous installation folder. The first command previews migration; review warnings before applying. Reload the browser after restarting Studio. Jobs, accepted media, characters, recovery journals, and cleanup behavior are preserved.

Automated checks cover theme switching and navigation, palette text contrast of at least 4.5:1, and existing control-center interactions. Screenshots were reviewed and the installed Streamlit dropdown implementation was inspected. Windows/WSL browser rendering and live Google provider recovery are not exercised by these checks.

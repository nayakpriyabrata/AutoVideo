"""Channel isolation and bounded render behavior with real local FFmpeg media."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from PIL import Image

SPEC=importlib.util.spec_from_file_location('finish_v763',Path(__file__).parents[1]/'engine'/'finishing_studio.py')
finish=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(finish)


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg required')
class ChannelRenderTest(unittest.TestCase):
    def test_three_channels_share_music_but_not_branding(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            source=root/'source.mp4';music=root/'music.wav'
            subprocess.run(['ffmpeg','-y','-loglevel','error','-f','lavfi','-i','testsrc2=size=320x240:rate=24',
                            '-f','lavfi','-i','sine=frequency=430','-t','1.5','-c:v','libx264','-threads','2','-c:a','aac',str(source)],check=True)
            subprocess.run(['ffmpeg','-y','-loglevel','error','-f','lavfi','-i','sine=frequency=220','-t','2',str(music)],check=True)
            profiles={}
            for lang,color in [('en','red'),('hi','green'),('or','blue')]:
                logo=root/(lang+'.png');Image.new('RGB',(80,80),color).save(logo)
                profiles[lang]=finish.save_profile('Channel '+lang,logo=logo,root=root/'profiles')
            plan=finish.create_plan(source,profiles,languages=profiles,shared_music=music,
                                    shared_music_license='Synthetic audio',output_root=root/'exports')
            data=json.loads(plan.read_text())
            self.assertEqual([data['editions'][x]['channel']['name'] for x in profiles],['Channel en','Channel hi','Channel or'])
            self.assertEqual(len({data['editions'][x]['assets']['logo']['sha256'] for x in profiles}),3)
            finish.set_edition(plan,'en',cards=[],reviewed=True)
            result=finish.render(plan,'en')
            self.assertEqual(json.loads(result.with_suffix('.provenance.json').read_text())['channel']['name'],'Channel en')
            with self.assertRaisesRegex(ValueError,'needs review'):finish.render(plan,'hi')
            finish.save_profile('Channel hi',root=root/'profiles')
            self.assertIn('logo',json.loads(profiles['hi'].read_text())['assets'])

if __name__=='__main__':unittest.main()

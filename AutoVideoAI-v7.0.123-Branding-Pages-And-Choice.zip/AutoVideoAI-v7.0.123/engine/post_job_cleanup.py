"""Post-job cleanup: keep the finished video and its records, free regenerable media.

Two targets:
  * generation jobs  -> media under the job folder (Flow takes, downloads, storyboard
                        frames, references, narration, stock, audio, intermediate renders)
  * clip folders     -> `_clip_work/` (downloaded source video, batch speech/frames)

Rules that apply to every plan:
  * Preview first. `apply` recomputes the plan and refuses if it no longer matches the
    digest the user reviewed, so nothing is deleted from a stale preview.
  * Only media files are removed. JSON, text, subtitles, logs, reports and Flow request
    journals are always kept, so the job stays auditable.
  * The validated final video (`render/*final*.mp4`) is never removed.
  * Symlinks are never followed or removed.
  * A job with pending Flow requests, an unfinished status, a running resume, or an active
    production lock is blocked. Nothing is deleted.

Remote Google Flow media is never touched here; use the storage manager for that.
"""
import hashlib
import json
import os
import shutil
import time
from pathlib import Path

from .production_lock import acquire, release

MEDIA_SUFFIXES = {'.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v',
                  '.jpg', '.jpeg', '.png', '.webp',
                  '.mp3', '.wav', '.m4a', '.aac', '.ogg', '.opus', '.flac'}
INTERRUPTED_PREFIX = '.bounded-'
CLIP_WORK = '_clip_work'
ACTIVE_RESUME_STATES = {'running', 'waiting'}


def _default_validator(path):
    from .providers.flow_browser import FlowBrowserProvider
    return FlowBrowserProvider._is_valid_video_file(path)


def _walk(root):
    """Yield regular files below root without following symlinks."""
    for directory, _dirs, files in os.walk(root, followlinks=False):
        here = Path(directory)
        for name in files:
            item = here / name
            if not item.is_symlink() and item.is_file():
                yield item


def _is_media(path):
    return path.suffix.lower() in MEDIA_SUFFIXES


def _lock_is_free(folder):
    """True when no production run holds the folder lock right now."""
    lock_path = Path(folder) / '.production.lock'
    if lock_path.is_symlink():
        return False
    try:
        handle = lock_path.open('a+b')
    except OSError:
        return False
    try:
        try:
            acquire(handle, blocking=False)
        except BlockingIOError:
            return False
        release(handle)
        return True
    finally:
        handle.close()


def _digest(files, blocked):
    h = hashlib.sha256()
    for item in files:
        h.update(f"{item['path']}\0{item['bytes']}\n".encode('utf-8', 'replace'))
    h.update(('|'.join(sorted(blocked))).encode('utf-8', 'replace'))
    return h.hexdigest()[:24]


def _summarise(job, kept, files, blocked):
    categories = {}
    for item in files:
        slot = categories.setdefault(item['category'], {'files': 0, 'bytes': 0})
        slot['files'] += 1
        slot['bytes'] += item['bytes']
    total = sum(item['bytes'] for item in files)
    return {
        'folder': str(job),
        'kind': 'job',
        'blocked': blocked,
        'allowed': not blocked,
        'kept_videos': kept,
        'categories': categories,
        'files': files,
        'reclaimable_bytes': total,
        'digest': _digest(files, blocked),
    }


def _deliverable_videos(job):
    """Videos the user keeps: branded/edition copies in render/ and every language export folder."""
    job = Path(job)
    found = []
    render = job / 'render'
    if render.is_dir() and not render.is_symlink():
        found += [p for p in render.glob('*-branded.mp4') if p.is_file() and not p.is_symlink()]
        found += [p for p in render.glob('*-edition.mp4') if p.is_file() and not p.is_symlink()]
    for folder in ('language_editions', 'primary_branding'):
        base = job / folder
        if base.is_dir() and not base.is_symlink():
            found += [p for p in base.glob('*/exports/*.mp4') if p.is_file() and not p.is_symlink()]
    return sorted(set(found))


def plan_job(job_directory, *, validate_final=None):
    """Plan cleanup for one generation job. Read-only except the lock probe."""
    job = Path(job_directory).absolute()
    if job.is_symlink() or not job.is_dir():
        raise ValueError('Use an existing real job folder')
    blocked = []
    try:
        manifest = json.loads((job / 'production_manifest.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        raise ValueError('Job manifest is unreadable; nothing changed')
    if manifest.get('status') != 'done':
        blocked.append('Job is not complete; finish or stop it before cleanup')

    render = job / 'render'
    validator = validate_final or _default_validator
    finals = sorted(p for p in render.glob('*final*.mp4') if p.is_file() and not p.is_symlink()) \
        if render.is_dir() and not render.is_symlink() else []
    # v7.0.73: the English branded master, the edition copies in render/ and every
    # edition export are deliverables too. Without this they were treated as media to free.
    valid_finals = [p for p in finals if validator(str(p))]
    kept_paths = valid_finals + [p for p in _deliverable_videos(job) if validator(str(p))]
    kept = [str(p.relative_to(job)) for p in kept_paths]
    if not valid_finals:
        blocked.append('No validated final video in render/. Cleanup would remove the only copy. '
                       'If a final file exists, check that ffprobe is installed and the file plays.')

    for name in ('auto_resume.json', 'pause_state.json'):
        state_file = job / name
        if state_file.is_file() and not state_file.is_symlink():
            try:
                state = str(json.loads(state_file.read_text(encoding='utf-8')).get('state', ''))
            except (OSError, ValueError):
                blocked.append(f'{name} is unreadable; resolve it first')
                continue
            if state in ACTIVE_RESUME_STATES:
                blocked.append(f'{name} shows an automatic resume is {state}')

    for record in _walk(job):
        if not record.name.endswith('.flow-request.json'):
            continue
        try:
            status = json.loads(record.read_text(encoding='utf-8')).get('status')
        except (OSError, ValueError):
            blocked.append(f'Unreadable Flow request journal: {record.relative_to(job)}')
            continue
        if status != 'downloaded':
            blocked.append(f'Pending Flow request: {record.relative_to(job)}')

    if not _lock_is_free(job):
        blocked.append('Production is active for this job; wait for it to finish')

    files = []
    kept_set = set(kept)
    for item in _walk(job):
        rel = item.relative_to(job)
        rel_text = str(rel)
        parts = rel.parts
        in_interrupted = len(parts) >= 2 and parts[0] == 'render' and parts[1].startswith(INTERRUPTED_PREFIX)
        if rel_text in kept_set:
            continue
        if in_interrupted:
            category = 'render/interrupted temp'
        elif _is_media(item):
            category = '/'.join(parts[:-1][:2]) if len(parts) > 1 else 'root'
        else:
            continue
        files.append({'path': rel_text, 'category': category, 'bytes': item.stat().st_size})
    files.sort(key=lambda x: (x['category'], x['path']))
    return _summarise(job, kept, files, blocked)


def plan_clip_folder(folder_path):
    """Plan cleanup for one clip output folder: source downloads and batch work only."""
    folder = Path(folder_path).absolute()
    if folder.is_symlink() or not folder.is_dir():
        raise ValueError('Use an existing real clip folder')
    blocked = []
    highlights = folder / 'highlights.json'
    if not highlights.is_file() or highlights.is_symlink():
        blocked.append('Clip run is not complete (no highlights.json)')
    else:
        try:
            json.loads(highlights.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            blocked.append('highlights.json is unreadable; resolve it first')
    if not _lock_is_free(folder):
        blocked.append('Clip production is active in this folder; wait for it to finish')
    work = folder / CLIP_WORK
    files = []
    if work.is_dir() and not work.is_symlink():
        for item in _walk(work):
            if _is_media(item):
                rel = item.relative_to(folder)
                files.append({'path': str(rel), 'category': 'clip source & batch work',
                              'bytes': item.stat().st_size})
    files.sort(key=lambda x: x['path'])
    kept = sorted(str(p.relative_to(folder)) for p in folder.glob('*.mp4')
                  if p.is_file() and not p.is_symlink())
    result = _summarise(folder, kept, files, blocked)
    result['kind'] = 'clip'
    return result


def _remove_empty_dirs(root, candidates):
    """Remove directories that became empty, deepest first, staying inside root."""
    dirs = set()
    for rel in candidates:
        parent = (root / rel).parent
        while parent != root and root in parent.parents:
            dirs.add(parent)
            parent = parent.parent
    for directory in sorted(dirs, key=lambda p: len(p.parts), reverse=True):
        try:
            if directory.is_dir() and not directory.is_symlink() and not any(directory.iterdir()):
                directory.rmdir()
        except OSError:
            continue


def export_kept_videos(folder_path, kept_videos, destination):
    """Copy each kept video into ``destination`` under its own file name, verified by SHA-256.

    Nothing is overwritten: an existing file with the same name must be byte-identical,
    otherwise the export stops and the caller deletes nothing. The destination must be
    outside the job folder.
    """
    folder = Path(folder_path).absolute()
    target_dir = Path(destination).expanduser().absolute()
    if target_dir == folder or folder in target_dir.parents:
        raise ValueError('Choose a folder outside the job; the videos would be kept inside it')
    target_dir.mkdir(parents=True, exist_ok=True)
    exported = []
    for rel in kept_videos:
        source = folder / rel
        if not source.is_file() or source.is_symlink():
            raise ValueError('Kept video is missing: ' + rel)
        target = target_dir / source.name
        digest = _file_sha256(source)
        if target.exists():
            if _file_sha256(target) != digest:
                raise ValueError('The folder already has a different ' + target.name + '; choose another folder')
            exported.append({'file': target.name, 'status': 'already there', 'sha256': digest})
            continue
        temporary = target.with_name(target.name + '.copying')
        shutil.copy2(source, temporary)
        if _file_sha256(temporary) != digest:
            temporary.unlink(missing_ok=True)
            raise ValueError('Copy verification failed for ' + target.name + '; nothing was deleted')
        os.replace(temporary, target)
        exported.append({'file': target.name, 'status': 'copied', 'sha256': digest})
    return exported


def _file_sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def apply_plan(folder_path, reviewed_digest, *, kind='job', validate_final=None, keep_video_dir=None):
    """Delete exactly the reviewed files. Refuses if the folder changed since review.

    ``keep_video_dir`` copies every kept video (final, branded, language editions)
    there first, verified. If any copy fails, nothing is deleted.
    """
    if keep_video_dir and kind != 'job':
        raise ValueError('Keeping videos in a folder is available for generation jobs')
    folder = Path(folder_path).absolute()
    fresh = plan_clip_folder(folder) if kind == 'clip' else plan_job(folder, validate_final=validate_final)
    if fresh['blocked']:
        raise ValueError('Cleanup blocked: ' + '; '.join(fresh['blocked']))
    if fresh['digest'] != reviewed_digest:
        raise ValueError('Folder changed since the review; review the cleanup again')
    if not _lock_is_free(folder):
        raise ValueError('Production started since review; nothing deleted')
    exported = []
    if keep_video_dir and kind == 'job':
        exported = export_kept_videos(folder, fresh['kept_videos'], keep_video_dir)

    removed, errors, freed = [], [], 0
    for item in fresh['files']:
        target = folder / item['path']
        if target.is_symlink() or not target.is_file():
            continue
        try:
            size = target.stat().st_size
            target.unlink()
            removed.append(item['path'])
            freed += size
        except OSError as error:
            errors.append({'path': item['path'], 'error': type(error).__name__})
    _remove_empty_dirs(folder, [p['path'] for p in fresh['files']])

    report = {
        'created_at': time.strftime('%Y-%m-%dT%H:%M:%S%z'),
        'kind': kind,
        'freed_bytes': freed,
        'removed_count': len(removed),
        'kept_videos': fresh['kept_videos'],
        'exported_videos': exported,
        'categories': fresh['categories'],
        'errors': errors,
    }
    logs = folder / 'logs' if kind == 'job' else folder
    if logs.is_dir() and not logs.is_symlink():
        stamp = time.strftime('%Y%m%d-%H%M%S')
        (logs / f'post_job_cleanup_{stamp}.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    for kept in fresh['kept_videos']:
        if not (folder / kept).is_file():
            errors.append({'path': kept, 'error': 'final video missing after cleanup'})
    report['errors'] = errors
    return report

"""v7.0.103: inspect and repair a job's stills and video Flow projects from the command line.

Field case (job ``20261022-143856-7-small-daily-habits-tha-9729``, 2026-10-27 04:46 IST): a new production run
stopped at the first video shot with

    Video Flow project must differ from storyboard image project

which named neither project, nor where either binding lived, nor what to do. The job stayed ``planned``, so it
looked like it might still be running.

``flow-projects`` prints both roles with the file each value came from, flags a collision, and changes
nothing unless ``--confirm`` is given with exactly one explicit action.
"""
from __future__ import annotations

import json
import os

from .providers.flow_browser import FlowBrowser

SETTINGS = 'settings.json'
VIDEO_FILE = 'flow_video_project.json'


def _settings_path(job_dir):
    return os.path.join(job_dir, SETTINGS)


def _read_json(path):
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_json(path, data):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def describe(factory, job_id) -> dict:
    """Both bindings, their sources and the collision flag. Read-only."""
    return factory.flow_project_bindings(job_id)


def _report(bindings) -> list[str]:
    lines = [f"Job:            {bindings['job_id']}",
             f"Stills project: {bindings['stills_project'] or '(not bound)'}"
             + (f"   from {bindings['stills_source']}" if bindings['stills_source'] else ''),
             f"Video project:  {bindings['video_project'] or '(not bound)'}"
             + (f"   from {bindings['video_source']}" if bindings['video_source'] else '')]
    loose = {role: value for role, value in
             (('settings stills', bindings['stills_candidates']['settings']),
              ('database stills', bindings['stills_candidates']['database']),
              ('settings video', bindings['video_candidates']['settings']),
              ('file video', bindings['video_candidates']['file']))
             if value}
    if len(set(loose.values())) > 1:
        lines.append('')
        lines.append('Stored copies that disagree (only the ones above are used):')
        for role, value in loose.items():
            lines.append(f'  {role}: {value}')
    lines.append('')
    if bindings['conflict']:
        lines.append('COLLISION: both roles point at the same project. A new video could not be told apart '
                     'from the stills in that gallery, so video generation is refused (no credits are spent).')
        lines.append('Repair, one of:')
        lines.append(f'  python3 cli.py v3 flow-projects {bindings["job_id"]} --clear-video --confirm   '
                     '# video gets its own project next time')
        lines.append(f'  python3 cli.py v3 flow-projects {bindings["job_id"]} '
                     '--set-stills https://flow.google.com/project/<storyboard-project-id> --confirm')
    elif not bindings['stills_project']:
        lines.append('No stills project is bound: storyboard frames will open their own project.')
    elif not bindings['video_project']:
        lines.append('No video project is bound: the first video submission will open its own project '
                     '(separate from the stills project).')
    else:
        lines.append('OK: the two roles use different projects.')
    return lines


def run_flow_projects(factory, args) -> int:
    """Print the bindings; apply exactly one explicit change when --confirm is given."""
    job_id = args.job_id
    job_dir = factory.pm.job_dir(job_id)
    actions = {
        '--set-stills': args.set_stills or '',
        '--set-video': args.set_video or '',
        '--clear-stills': bool(args.clear_stills),
        '--clear-video': bool(args.clear_video),
    }
    chosen = [name for name, value in actions.items() if value]
    print('\n'.join(_report(describe(factory, job_id))))
    if not chosen:
        if args.confirm:
            print('\nNothing to change: name one of --set-stills, --set-video, --clear-stills, --clear-video.')
            return 2
        print('\nRead-only. Add --confirm with one of --set-stills URL, --set-video URL, --clear-stills, '
              '--clear-video to change a binding.')
        return 0
    if len(chosen) > 1:
        print('\nRefused: change one binding per command (' + ', '.join(chosen) + '). Nothing was changed.')
        return 2
    if not args.confirm:
        print('\nDry run: add --confirm to apply ' + chosen[0] + '. Nothing was changed.')
        return 0

    settings_path = _settings_path(job_dir)
    settings = _read_json(settings_path)
    action = chosen[0]
    if action in ('--set-stills', '--set-video'):
        url = FlowBrowser.normalize_project_url(actions[action])
        if not url:
            print('\nRefused: expected https://flow.google.com/project/<uuid>. Nothing was changed.')
            return 2
    else:
        url = ''

    if action == '--set-stills':
        settings['flow_project_url'] = url
        _write_json(settings_path, settings)
        factory.db.upsert(job_id, flow_project=url)
        video = describe(factory, job_id)['video_project']
        print(f'\nStills project bound to {url}.')
        if video and video == url:
            print('The video binding still points at the same URL, so the collision remains: run '
                  f'`python3 cli.py v3 flow-projects {job_id} --clear-video --confirm` (or choose another '
                  'stills project).')
        factory.pm.log(job_id, 'flow_project_stills_set', {'url': url})
        return 0

    if action == '--set-video':
        from .flow_project_isolation import persist_project_binding
        try:
            persist_project_binding(os.path.join(job_dir, VIDEO_FILE), url, 'video', job_id)
        except (RuntimeError, ValueError) as error:
            print('\nRefused: ' + str(error) + ' Nothing was changed. Use --clear-video to release the '
                  'existing video binding first.')
            return 2
        if settings.get('flow_video_project_url'):
            settings.pop('flow_video_project_url', None)
            _write_json(settings_path, settings)
        print(f'\nVideo project bound to {url}.')
        factory.pm.log(job_id, 'flow_project_video_set', {'url': url})
        return 0

    if action == '--clear-stills':
        settings.pop('flow_project_url', None)
        _write_json(settings_path, settings)
        factory.db.upsert(job_id, flow_project='')
        print('\nStills binding removed: the next storyboard pass opens its own project.')
        factory.pm.log(job_id, 'flow_project_stills_cleared', {})
        return 0

    # --clear-video
    freed = []
    path = os.path.join(job_dir, VIDEO_FILE)
    if os.path.isfile(path):
        os.replace(path, path + '.cleared')
        freed.append(os.path.basename(path) + ' -> ' + os.path.basename(path) + '.cleared')
    if settings.get('flow_video_project_url'):
        settings.pop('flow_video_project_url', None)
        _write_json(settings_path, settings)
        freed.append('settings.json flow_video_project_url')
    if not freed:
        print('\nNothing to clear: no video binding is stored. Nothing was changed.')
        return 0
    print('\nVideo binding cleared (' + ', '.join(freed) + '). The next video submission opens its own '
          'project, separate from the stills project. Saved request journals keep their own project URLs.')
    factory.pm.log(job_id, 'flow_project_video_cleared', {'freed': freed})
    return 0

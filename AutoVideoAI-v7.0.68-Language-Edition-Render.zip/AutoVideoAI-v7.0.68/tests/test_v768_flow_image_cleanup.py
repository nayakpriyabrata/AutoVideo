"""v7.0.68: image-only Flow projects may be deleted once their local image and
request record are verified; video projects and changed or pending captures stay."""
import json
from pathlib import Path
from types import SimpleNamespace as NS

import pytest

URL = 'https://flow.google.com/project/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'


def _png(path, colour):
    from PIL import Image
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (96, 96), colour).save(path, format='PNG')
    return path


def _record(root, name, *, kind='image', scope='isolated_image_v1', status='downloaded',
            colour=(10, 20, 30), capture_inventory=None, project_url=URL):
    from engine.isolated_frame_regeneration import sha
    out = _png(Path(root) / 'images' / name, colour)
    row = {'kind': kind, 'scope': scope, 'status': status, 'project_url': project_url,
           'media_sha256': sha(out), 'reference_hashes': {}}
    if capture_inventory is not None:
        row['capture_inventory'] = capture_inventory
    (Path(str(out) + '.flow-request.json')).write_text(json.dumps(row))
    return out


def _project(tmp_path, **kw):
    root = tmp_path / 'job'
    root.mkdir()
    _record(root, 'frame-1.png', **kw)
    return root


def _rows(root):
    from engine.flow_project_cleanup import inventory
    return {r['project_url']: r for r in inventory(root)}


# ---- eligibility -----------------------------------------------------------

def test_image_project_without_captured_inventory_is_eligible(tmp_path):
    row = _rows(_project(tmp_path))[URL]
    assert row['eligible'] and row['max_images'] == 1 and not row['exact']


def test_two_image_records_bound_is_their_sum(tmp_path):
    root = _project(tmp_path)
    _record(root, 'frame-2.png', colour=(90, 90, 90))
    row = _rows(root)[URL]
    assert row['eligible'] and row['max_images'] == 2


def test_captured_inventory_is_used_for_exact_match_when_complete(tmp_path):
    root = _project(tmp_path, capture_inventory=['sig-a'])
    row = _rows(root)[URL]
    assert row['eligible'] and row['exact'] and row['signatures'] == ['sig-a']


def test_video_project_stays_protected(tmp_path):
    row = _rows(_project(tmp_path, kind='video'))[URL]
    assert not row['eligible'] and 'Video/recovery project retained' in row['blocked']


def test_pending_image_stays_protected(tmp_path):
    row = _rows(_project(tmp_path, status='pending'))[URL]
    assert not row['eligible'] and any('pending' in b for b in row['blocked'])


def test_changed_local_image_stays_protected(tmp_path):
    root = _project(tmp_path)
    _png(root / 'images' / 'frame-1.png', (1, 1, 1))  # bytes no longer match the journal
    row = _rows(root)[URL]
    assert not row['eligible']


def test_one_video_record_blocks_the_whole_project(tmp_path):
    root = _project(tmp_path)
    _record(root, 'clip.png', kind='video', colour=(5, 5, 5))
    assert not _rows(root)[URL]['eligible']


# ---- live check at deletion ------------------------------------------------

class Loc:
    def __init__(self, text, actions, state):
        self.text, self.actions, self.state = text, actions, state
        self.first = self

    def count(self):
        return 0 if hasattr(self.text, 'pattern') and 'confirm' not in self.actions else 1

    def is_visible(self, **kw):
        return bool(self.count())

    def click(self, **kw):
        self.actions.append(self.text)

    def inner_text(self, **kw):
        return 'Delete this project?'

    def get_by_role(self, *a, **kw):
        return Loc('confirm', self.actions, self.state)

    def wait_for(self, **kw):
        if not self.state['toast']:
            raise RuntimeError('No explicit success confirmation')


def _bridge(assets, toast=True):
    actions, state = [], {'toast': toast}
    page = NS(url=URL, get_by_text=lambda *a, **kw: Loc(a[0], actions, state),
              get_by_role=lambda *a, **kw: Loc('dialog', actions, state))
    bridge = NS(_page=page, ensure_project=lambda *a, **kw: None,
                media_assets=lambda: assets,
                _try_resolve=lambda *a, **kw: Loc('project-menu', actions, state))
    return bridge, actions


def test_delete_without_inventory_accepts_images_within_bound():
    from engine.flow_project_delete import delete
    bridge, actions = _bridge([{'kind': 'image', 'sig': 'x'}])
    assert delete(bridge, URL, None, max_images=1)['status'] == 'deleted'
    assert actions == ['project-menu', 'Delete', 'confirm']


def test_delete_without_inventory_refuses_a_video_asset_before_any_click():
    from engine.flow_project_delete import delete
    from engine.providers.flow_browser import FlowUIChanged
    bridge, actions = _bridge([{'kind': 'image', 'sig': 'x'}, {'kind': 'video', 'sig': 'v'}])
    with pytest.raises(FlowUIChanged, match='non-image'):
        delete(bridge, URL, None, max_images=5)
    assert not actions


def test_delete_without_inventory_refuses_more_images_than_verified_requests():
    from engine.flow_project_delete import delete
    from engine.providers.flow_browser import FlowUIChanged
    bridge, actions = _bridge([{'kind': 'image', 'sig': str(n)} for n in range(3)])
    with pytest.raises(FlowUIChanged, match='more images'):
        delete(bridge, URL, None, max_images=2)
    assert not actions


def test_delete_without_any_evidence_refuses_before_any_click():
    from engine.flow_project_delete import delete
    from engine.providers.flow_browser import FlowUIChanged
    bridge, actions = _bridge([{'kind': 'image', 'sig': 'x'}])
    with pytest.raises(FlowUIChanged, match='nothing deleted'):
        delete(bridge, URL, None)
    assert not actions


def test_delete_with_inventory_still_requires_exact_match():
    from engine.flow_project_delete import delete
    from engine.providers.flow_browser import FlowUIChanged
    bridge, actions = _bridge([{'kind': 'image', 'sig': 'extra'}])
    with pytest.raises(FlowUIChanged, match='captured inventory'):
        delete(bridge, URL, ['exact'], max_images=5)
    assert not actions


def test_delete_without_success_toast_is_not_reported_as_deleted():
    from engine.flow_project_delete import delete
    bridge, _ = _bridge([{'kind': 'image', 'sig': 'x'}], toast=False)
    with pytest.raises(RuntimeError, match='success'):
        delete(bridge, URL, None, max_images=1)


# ---- cleanup dispatch ------------------------------------------------------

def test_delete_selected_passes_bound_only_when_no_inventory(tmp_path):
    from engine.flow_project_cleanup import delete_selected
    calls = []

    class Bridge:
        def delete_exact_project(self, url, expected_signatures=None, max_images=None):
            calls.append((expected_signatures, max_images))
            return {'status': 'deleted'}

    class Provider:
        def _ensure(self):
            return Bridge()

    root = _project(tmp_path)
    delete_selected(root, [_rows(root)[URL]], provider_factory=Provider, lock_held=True)
    assert calls == [(None, 1)]


def test_video_project_is_never_selectable_for_delete(tmp_path):
    from engine.flow_project_cleanup import delete_selected
    root = _project(tmp_path, kind='video')
    with pytest.raises(ValueError):
        delete_selected(root, [_rows(root)[URL]], provider_factory=lambda: pytest.fail('no browser'),
                        lock_held=True)

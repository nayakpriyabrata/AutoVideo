# AutoVideoAI v7.0.47 — mixed B-roll batch approval

Clip Studio can now approve and render a saved B-roll review that contains a mixture of usable assets and unmatched, invalid, or duplicate-rejected search slots.

- Exact SHA-256 validation is still required for every available candidate.
- Unavailable slots are explicitly saved as skipped and never inserted.
- A real candidate whose displayed identity changed still blocks approval.
- The confirmation label reports the number of available assets, while the caption reports how many unavailable slots will be skipped.
- Original highlight clips remain unchanged; approved cutaways render to separate output files.

## Update an existing installation

Stop Studio and any running production job. From the existing runtime folder, run the updater from the extracted v7.0.47 folder:

```bash
python3 ../AutoVideoAI-v7.0.47/tools/update_v743_to_v747.py . --apply
cat VERSION
bash dashboard.sh
```

The updater changes application code only. Existing outputs, saved Clip Studio jobs, B-roll reviews, settings, databases, and browser profiles remain in place.

# AutoVideoAI 7.0.56 — QC retry identity fix

Stop Studio and CLI/runner production. Extract beside your existing installation. From AutoVideoAI-v7:

```bash
python3 ../AutoVideoAI-v7.0.56/tools/update_v755_to_v756.py . --apply
```

This updater requires 7.0.55. It checks file hashes, backs up changed code, refuses unexpected local modifications, and preserves runtime data. The full release includes all 7.0.55 features.

## Confirmed incident evidence

The supplied runtime log shows shot_001 failed native blob transfers twice, then saved a validated 869,318-byte MP4 and reported recovery without new generation. Later shot_009 failed while attaching its two reference images. Subsequent runs repeatedly stopped on shot_001 with a prompt/request mismatch. The supplied support report identifies version 7.0.55, seven accepted shots of nine, and zero pending request journals.

The retry code had a concrete collision: QC rejection appended a correction to the prompt, but the retry reused take_01.mp4 and its old request journal. The safety guard correctly refused the different prompt. Automatic recovery then retried that deterministic conflict needlessly. The supplied report omits QC and retry_count, so the specific QC rejection reason for this job remains unverified.

## Changes

- First attempts retain take_01.mp4 naming. QC retry 1 uses take_r01_01.mp4; retry 2 uses take_r02_01.mp4. Candidate numbers remain separate. A browser interruption within the same retry resumes the same request path.
- Original video bytes, request journals and per-take QC results are retained. Prompts are not rebound to old request records.
- Prompt/request and project-binding conflicts no longer qualify for automatic timed retry.
- Support reports include retry_count, QC threshold, accepted_take, take history, and up to 20 completed video request summaries with local-file existence and QC. Completed prompts are excluded.

## Next step for the Discipline job

Export the expanded diagnostics before another generation attempt:

```bash
python3 cli.py v3 support-report 20261017-113230-discipline-beats-motivat-2c5d
```

Inspect completed_video_requests and shot_001 retry_count/QC. A download being successful does not mean QC accepted its contents. If QC rejected it, Resume can request a NEW replacement video within the existing retry policy and provider approval settings. That is credit-bearing generation, not download-only recovery. Review the saved take first if you want to avoid replacement costs. Do not delete its journal or relabel the rejected take as accepted.

This fixes retry identity collisions and futile retry loops. It does not establish a permanent cure for WSL browser crashes, native blob transfer failures or Flow attachment-picker changes. The reference-upload diagnostic JSON files and corresponding screenshots are needed to investigate the shot_009 selector/attachment issue directly. No new live Flow requests were performed during development.

## Validation

36 focused regression tests passed, including interrupted multi-shot QC retry identity, unchanged original requests, deterministic conflict classification, support-report coverage and existing resilience checks. Release ZIP hashes and a 7.0.55-to-7.0.56 upgrade preserving a runtime sentinel were verified. Tests use mocks/local media; no live Flow download or attachment interaction was verified.

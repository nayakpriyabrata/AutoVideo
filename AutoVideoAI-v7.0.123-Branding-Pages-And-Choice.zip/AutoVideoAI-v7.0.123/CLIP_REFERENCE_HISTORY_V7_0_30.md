# AutoVideoAI 7.0.30 — clip framing, saved history and reference recovery

This update retains the previous 7.0.29 features and fixes the issues reported on 8 October.

## Upgrade

Stop the dashboard and CLI workers. Extract this build into a new directory, then run:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.29 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.29 . --apply
./dashboard.sh
```

Use your actual previous installation directory if different. Migrate the most complete installation: copying only today's outputs cannot recover yesterday's files. The migration copies saved outputs, characters and local configuration; preview its disk estimate first. It preserves/rebases stored paths.

## Face framing and B-roll

Face crop now samples frontal/profile faces throughout the source and updates the crop position when the camera changes. It uses the largest detected face; it does not infer which of two simultaneously visible people is speaking. Missing detection is reported for review. Fit retains the full image.

B-roll edits now use the finished highlight as their visual base. They preserve its crop, original audio, captions and logo outside cutaways. Captions and branding are applied to cutaways themselves rather than duplicated across the whole clip. Captions remain optional.

An existing MP4 that has already cropped a face out cannot restore those missing pixels. Generate a new highlight from the original wide source with Face crop, check the preview, then apply the B-roll. Existing files are preserved; the new export receives a separate filename.

## Clip history

Each new batch saves a separate report under `clip-history/`. Captions and logo overlays also have batch-specific working paths. `highlights.json` remains the latest-batch summary for older integrations; it is no longer the only source of gallery history.

Gallery and AI Recreate also discover old exported MP4s beside known clip reports, including B-roll copies. These recovered legacy files are marked for review, and QC-blocked clips keep their review state. Raw source caches and Flow takes are excluded. Actual deleted or unmigrated videos cannot be recovered by this index change.

Applying an older B-roll review updates its matching saved batch, without assigning its outputs to a newer batch.

## Aanya / Flow references

The supplied log shows the local Aanya photo reached the file chooser. The failure happened while confirming its attachment to the Flow composer. This build clears retained picker searches, recognizes composer thumbnail chips including background-image thumbnails, and allows a bounded 45-second upload/attachment wait. It still requires a verified attachment before submitting any generation.

A failed attachment now persists an upload-attempt record. Resume first checks the exact content-hashed reference, then permits one local-file reattachment rather than repeatedly uploading it on every retry. Migrated recreation approvals can resolve the exact frozen job photo or an identical migrated library photo without changing the approved snapshot. Edited photos are not silently substituted into an already approved job.

The Queue no longer says all shots are accepted when scene planning has not produced any shots.

These changes were validated locally with regression tests and real FFmpeg renders. Signed-in Flow and WSL recovery on your computer remain unverified; this build does not promise zero provider/UI failures. Uncertain video requests remain download-only, and reference attachment failure never authorizes a paid generation.

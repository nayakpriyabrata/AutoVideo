# v7.0.51 — normal Reels, long videos and visual-only planning

## Cause and changes

The music-only audio switch already skipped TTS and speech captions, but the optional Gemini draft still requested a narrated script and word count. It did not receive the selected audio mode. The automatic writer also used the spoken-script path.

This release passes the audio mode through both paths. Music-only and silent plans have `narration: ""`, `voiceover_enabled: false`, and empty scene `text`; actions and camera instructions belong in `visual_intent`. Scene durations determine runtime. A writer response containing speech or the wrong total duration is rejected before generation. Voiceover plans retain the existing narration behavior.

An audio/topic/language/duration change invalidates draft approval. Redraft or correct the plan before using it. Imported visual-only plans cannot be used with voiceover enabled, and their duration must match the job.

Create → **Reels & Long Videos** now has visible choices for **Normal Reel / Short · vertical 9:16** and **Long video · landscape 16:9**. Mini Reels remains a separate single-generation workflow. The general **Cinematic** theme avoids imposing a cartoon or educational treatment on ordinary visual ideas. Music-only defaults text cards off; branding is independent.

## Your 30-second rain dance

1. Open Create → Reels & Long Videos.
2. Choose Normal Reel / Short, 30 seconds, Cinematic theme, Music only.
3. Enter: “An adult woman joyfully dancing in gentle rain on a quiet forest road; cinematic live-action, continuous graceful movement, no dialogue, narration or singing.”
4. Draft and review the scene plan. Expect empty narration and timed visual scenes totalling 30 seconds.
5. Choose instrumental background music; keep text cards off if you want clean footage. Review the motion profile and credit budget before creating production.

Flow Cinematic is intended for generated motion scenes; Storyboard Economy mixes selected generated videos with still-image motion. An image-motion shot cannot reproduce continuous human dancing. The tool does not silently increase your motion budget or start a new paid generation for this update.

A reviewable five-scene example is included at `config/examples/rain-dance-30s-music-only.json`; its approval flags intentionally remain false.

## Update

Extract the ZIP beside the existing installation. Finish active jobs and stop Studio/runner. From the existing installation folder:

```bash
cat VERSION
python3 ../AutoVideoAI-v7.0.51/tools/update_v743_to_v751.py . --apply
./dashboard.sh
```

The updater accepts installed VERSION 7.0.43 through 7.0.50, regardless of folder name. It verifies code hashes, keeps a code backup and preserves jobs, outputs, settings and browser profiles. Restart the runner there too. Updating the Control Center does not install this engine on your PC.

Existing saved jobs are not rewritten or regenerated. For the old rain-dance draft, return to setup and draft again after choosing Music only. This version rejects spoken content instead of silently relabelling it as a visual plan.

Offline checks cover provider prompts, scene timing, stale drafts, invalid imports, a no-TTS dry run and the actual Streamlit controls. Live Gemini/Flow acceptance still depends on your signed-in session. The v7.0.50 limitations, including disabled automatic Flow deletion and Studio-process lifetime, remain applicable.

Release verification: 1,090 offline tests passed (13 deprecation warnings); 24 JavaScript and 18 Python Control Center tests passed, plus syntax checks. No live Google generation was submitted.

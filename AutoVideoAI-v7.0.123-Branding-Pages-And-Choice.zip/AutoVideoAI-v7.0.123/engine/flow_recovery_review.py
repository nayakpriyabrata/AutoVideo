"""Bind an explicitly reviewed gallery prompt to its pending request, offline."""
from pathlib import Path
import hashlib
import json
from .providers.flow_browser import FlowBrowser, FlowBrowserProvider
from .production import save


def candidates(root):
    root=Path(root).resolve();result=[];seen=set()
    for journal in sorted(root.rglob('*.flow-request.json')):
        if journal.is_symlink():continue
        request=json.loads(journal.read_text())
        if request.get('kind')!='image' or request.get('status')!='pending':continue
        if FlowBrowserProvider._bound_recovery_prompt(request):continue
        for evidence in request.get('prompt_candidate_evidence',[]):
            prompt=evidence.get('prompt','')
            sha=hashlib.sha256(FlowBrowser.normalize_generation_prompt(prompt).encode()).hexdigest()
            key=(str(journal),sha)
            if prompt and key not in seen:
                seen.add(key)
                result.append({'journal':str(journal.relative_to(root)), 'request_hash':request.get('request_hash'), 'project_url':request.get('project_url'),
                               'prompt':prompt,'prompt_sha256':sha})
    return result


def bind_reviewed(root, candidate):
    root=Path(root).resolve();journal=(root/candidate['journal']).resolve()
    if not journal.is_relative_to(root) or journal.is_symlink():raise ValueError('Invalid journal path')
    existing=json.loads(journal.read_text())
    if (existing.get('request_hash')==candidate['request_hash'] and existing.get('project_url')==candidate['project_url']
            and FlowBrowserProvider._bound_recovery_prompt(existing)==candidate['prompt']):
        return {'state':'EXACT_PROMPT_ALREADY_BOUND','new_generations':0,'next_action':'Resume the same job for download-only recovery'}
    matched=[c for c in candidates(root) if c==candidate]
    if len(matched)!=1:raise ValueError('Recovery evidence changed; refresh the report before reviewing')
    request=json.loads(journal.read_text())
    backup=journal.with_name(journal.name+'.before-reviewed-binding.json')
    if not backup.exists():backup.write_bytes(journal.read_bytes())
    request['verified_prompt_binding']=FlowBrowserProvider._make_prompt_binding(request,candidate['prompt'],'explicit_gallery_review')
    request['signature']=''
    save(journal,request)
    return {'state':'EXACT_PROMPT_BOUND','new_generations':0,'next_action':'Resume the same job for download-only recovery'}

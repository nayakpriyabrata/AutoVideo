# AutoVideoAI 7.0.79: Gemini Web send check, text cards that do not stop the set, Odia captions

Update from 7.0.78 with `tools/update_v778_to_v779.py`. Code and documentation only. Saved jobs, outputs,
browser profiles, music, characters and channel profiles are never copied, moved or deleted.

## What was wrong (from the 7.0.78 dashboard log)

1. **Gemini Web prompt was pasted but not sent.** The send step treated any click that did not raise as a
   success. An unsent prompt then waited the full 300 seconds for an answer that never came, and the job
   stopped with no error on the dashboard.
2. **One bad text card stopped the whole set.** A card whose spoken anchor was too short or too long raised
   "Choose a spoken anchor lasting 1.5-6 seconds" for every card, so the dashboard stayed at
   "drafting timed cards" with a red box.
3. **Odia captions could not use speech recognition.** Groq rejects Odia (HTTP 400) and the local Whisper
   install fails in the user's environment, so the caption step ended in fallbacks.

## What changed

- **Send is verified.** After the click, the composer is read. If the prompt is still there, Enter is pressed
  once. If it is still there, the run fails at once with a clear Gemini Web message, instead of waiting 300 s.
  An unreadable composer is never treated as sent, unless Gemini shows it is generating an answer.
- **Text cards are dropped one at a time.** An unusable card is removed and its reason is recorded; the rest of
  the set is kept. A long spoken phrase is clamped to 6 seconds instead of rejected. Overlapping cards keep the
  earlier one. If the cards cover too much of the video, the longest are trimmed.
- **Wrong-script cards are dropped in Odia and Hindi editions.** Card copy in the wrong script is removed and
  reported. If every card is in the wrong script and the first answer came back quickly (under 90 s), the
  draft is requested once more with a correction. A slow answer is not asked for again.
- **Saved results that lost every card are retried.** A saved text-card result with no cards left and a
  recorded drop reason is not reused on the next run.
- **Odia captions skip speech recognition in auto mode.** Groq and local Whisper are not called for Odia; the
  timing is estimated from the reviewed script. An explicit Groq or local choice for Odia fails with a clear
  message instead of a silent fallback.

## Limits, stated plainly

- Odia caption timing is **estimated, not measured**. The 2-3 second transcript lag reported for Odia is not
  confirmed fixed by this release. The Odia voice file from the user's job has not been reviewed yet.
- Dropped text cards are shown in the job's `speech_cards.json` under `dropped_cards` and printed in the log.
  They are not yet shown in the dashboard.

## Tests

- `tests/test_v779_submit_cards_timing.py`: 17 tests, all passing. On the 7.0.78 code 16 of them fail (the one
  that passes is the English Groq check, which is expected), so they catch the original bugs.
- Eight older tests were updated to the new behaviour: four anchor checks in `test_v765`, one single-card check
  in `test_v774`, the Odia refusal in `test_v778` (now a drop with a reason), and two Gemini fake-page checks in
  `test_v576` (the fake send step now takes the prompt).
- Known failures that already fail on the untouched 7.0.78 code (not caused by this release): 9 in
  `test_card_typography`, 2 in `test_presentation_dashboard`, 2 in `test_v580_production`, 1 in
  `test_v731_dashboard_uploads`, 2 in `test_v733_publication_review`, 1 in `test_v735_bounded_upload`,
  1 in `test_v753_workflow`, 4 in `test_v758_uploads_picker`. These are not part of the Odia work.
- The full suite needs `ffmpeg` and `ffprobe` on the PATH (some tests render short clips); without them the run is not valid.

## Updating from 7.0.78

    python3 ../AutoVideoAI-v7.0.79/tools/update_v778_to_v779.py .            # dry run
    python3 ../AutoVideoAI-v7.0.79/tools/update_v778_to_v779.py . --apply    # install

Stop the dashboard first and restart it afterwards. From 7.0.77, first run the 7.0.78 updater from the 7.0.78 zip
folder, as the updater's message says. The updater refuses to replace a file you have changed locally.

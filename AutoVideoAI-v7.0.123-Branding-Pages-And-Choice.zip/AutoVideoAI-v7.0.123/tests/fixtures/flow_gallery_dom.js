// Browserless DOM fixture: executes the actual gallery scanner from Python.
const fs=require('fs');const {source}=JSON.parse(fs.readFileSync(0,'utf8'));
class Element {
 constructor(tag,text='',src='',children=[]){this.tagName=tag.toUpperCase();this.text=text;this.src=src;this.currentSrc=src;this.children=children;this.parentElement=null;children.forEach(x=>x.parentElement=this);}
 get innerText(){return this.text+' '+this.children.map(x=>x.innerText).join(' ');}
 getAttribute(key){return key==='alt'?'':null;}
 getBoundingClientRect(){return {width:this.tagName==='IMG'?200:400,height:300,x:0,y:0};}
 querySelectorAll(selector){const nodes=[];const visit=n=>{for(const x of n.children){nodes.push(x);visit(x);}};visit(this);return nodes.filter(n=>selector.split(',').some(s=>s.trim().toUpperCase()===n.tagName));}
 querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
}
const tile=new Element('div','','', [new Element('img','','https://media.test/clip.jpg'),new Element('mat-icon','play_arrow'),new Element('span','360p')]);
const image=new Element('div','', '',[new Element('img','','https://media.test/office.jpg')]);
const queued=new Element('div','Your video has been scheduled and is waiting in the queue due to high demand','',[new Element('img','','https://media.test/clip.jpg'),new Element('mat-icon','play_arrow')]);
const root=new Element('div','', '',[new Element('div','', '',[tile,image]),queued]);
global.document={querySelectorAll:s=>root.querySelectorAll(s)};global.getComputedStyle=()=>({visibility:'visible',display:'block'});
process.stdout.write(JSON.stringify(eval('('+source+')')()));

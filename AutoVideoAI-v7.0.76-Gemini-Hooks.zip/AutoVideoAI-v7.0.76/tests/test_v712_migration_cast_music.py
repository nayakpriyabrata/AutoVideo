import importlib.util
import json
from pathlib import Path
import sqlite3
from types import SimpleNamespace as NS
import pytest
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('migration',ROOT/'tools/migrate_installation.py')
migration=importlib.util.module_from_spec(spec);spec.loader.exec_module(migration)

def installs(tmp_path):
    old=tmp_path/'AutoVideoAI-v7.0.11';new=tmp_path/'AutoVideoAI-v7.0.12'
    for p in (old,new):p.mkdir();(p/'VERSION').write_text('7.0.12')
    return old,new

def test_migration_preserves_source_rebases_state_and_sqlite(tmp_path):
    old,new=installs(tmp_path)
    (old/'data/content/characters/person').mkdir(parents=True)
    image=old/'data/content/characters/person/photo.png';Image.new('RGB',(10,10),'red').save(image)
    character=image.parent/'character.json';character.write_text(json.dumps({'references':[{'path':str(image)}]}))
    job=old/'outputs/job';job.mkdir(parents=True)
    journal=job/'image.flow-request.json';journal.write_text(json.dumps({'request_hash':'same-request','project_url':'https://flow.google.com/project/abc','path':str(job/'image.jpg')}))
    (old/'.env').write_text('TOKEN="secret"\nOUTPUT="'+str(old/'outputs')+'"\n')
    (new/'.env').write_text('TOKEN=default\n')
    with sqlite3.connect(old/'data/jobs.db') as c:
        c.execute('create table jobs(path TEXT,state TEXT)');c.execute('insert into jobs values (?,?)',(str(job),json.dumps({'path':str(image)})))
    original=character.read_bytes();source_journal=journal.read_bytes()
    plan=migration.migrate(old,new);assert plan['copied']==0 and not (new/'data').exists()
    result=migration.migrate(old,new,apply=True)
    assert character.read_bytes()==original and journal.read_bytes()==source_journal
    moved=json.loads((new/'data/content/characters/person/character.json').read_text())
    assert moved['references'][0]['path']==str(new/'data/content/characters/person/photo.png')
    assert 'TOKEN="secret"' in (new/'.env').read_text()
    with sqlite3.connect(new/'data/jobs.db') as c:
        row=c.execute('select * from jobs').fetchone();assert row[0]==str(new/'outputs/job') and str(new) in row[1]
    assert json.loads((new/'outputs/job/image.flow-request.json').read_text())['request_hash']=='same-request'
    assert result['copied']>=5
    (new/'outputs/job/keep.mp4').write_bytes(b'existing');(old/'outputs/job/keep.mp4').write_bytes(b'old')
    migration.migrate(old,new,apply=True);assert (new/'outputs/job/keep.mp4').read_bytes()==b'existing'

def test_migration_disk_preflight_and_symlinks(tmp_path,monkeypatch):
    old,new=installs(tmp_path);(old/'data').mkdir();(old/'data/file').write_text('x')
    monkeypatch.setattr(migration.shutil,'disk_usage',lambda p:NS(free=1))
    with pytest.raises(ValueError,match='No files copied'):migration.migrate(old,new,apply=True)
    assert not (new/'data').exists()
    (new/'data').symlink_to(old/'data')
    with pytest.raises(ValueError,match='symlink'):migration.migrate(old,new,apply=True)

def test_migration_does_not_copy_sqlite_sidecars(tmp_path):
    old,new=installs(tmp_path);(old/'data').mkdir();(old/'data/x.db-wal').write_bytes(b'not-a-db');(old/'data/x.db-shm').write_bytes(b'x')
    assert migration.migrate(old,new)['files']==0

def test_portable_character_and_cast_references(tmp_path):
    from engine.content_library import CharacterLibrary
    from engine.cast import snapshot_cast,register_cast,photo_paths,assign_cast
    from engine.reference_manager import ReferenceManager
    from engine.project.manifest import Shot
    from engine.production import save
    lib=CharacterLibrary(tmp_path/'data/content/characters');photo=tmp_path/'photo.png';Image.new('RGB',(20,20),'red').save(photo)
    c=lib.create('Aanya','Original animated girl wearing a blue shirt',reference_files=[str(photo)],original_confirmed=True)
    record=json.loads((lib._folder(c['id'])/'character.json').read_text())
    assert not Path(record['references'][0]['path']).is_absolute()
    # Legacy path from an earlier installation can resolve its hash-checked local copy.
    record['references'][0]['path']=str(tmp_path/'old/data/content/characters'/c['id']/Path(c['references'][0]['path']).name)
    save(lib._folder(c['id'])/'character.json',record);assert lib.get(c['id'])['references'][0]['path']==c['references'][0]['path']
    root=tmp_path/'job';root.mkdir();save(root/'cast_snapshot.json',{'characters':snapshot_cast([c['id']],lib.root)})
    refs=ReferenceManager(str(root/'references'));cast=register_cast(root,refs)
    shots=[Shot(voice_start=0,voice_end=8,narration='Hi',visual_goal='Hello')]
    assign_cast(shots,cast,[{'start':0,'end':4,'speaker_id':'S1','character_id':c['id']},{'start':4,'end':8,'speaker_id':'S2','character_id':c['id']}])
    assert [s.speaker_id for s in shots]==['S1','S2'] and [s.duration_target for s in shots]==[4,4]
    assert photo_paths(refs,shots[0])==refs.get('character')

def test_speaker_mapping_rejects_changed_transcript():
    from engine.cast import validate_turns
    mapping={'S1':{'character_id':'girl','voice':'voice','provider_voice':'Kore'}}
    assert validate_turns([{'speaker_id':'S1','text':'Hello world'}],mapping,'Hello world')[0]['provider_voice']=='Kore'
    with pytest.raises(ValueError,match='exactly'):validate_turns([{'speaker_id':'S1','text':'Changed'}],mapping,'Hello world')

def test_music_video_import_creates_voice_free_saved_job(tmp_path,monkeypatch):
    import engine.music_video as music
    from engine.factory import Factory
    monkeypatch.chdir(ROOT)
    audio=tmp_path/'song.wav';audio.write_bytes(b'authorized-audio')
    monkeypatch.setattr(music,'probe',lambda p:{'streams':[{'codec_type':'audio'}],'format':{'duration':'61.2'}})
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'jobs.db'))
    result=music.create_music_video(f,str(audio),'Devotional song about kindness',language='hi')
    root=Path(f.pm.job_dir(result['job_id']));settings=json.loads((root/'settings.json').read_text())
    assert settings['voiceover_enabled'] is False and settings['caption_display']=='none'
    assert settings['stock_scenes']==0 and Path(settings['background_music_path']).read_bytes()==audio.read_bytes()
    assert len(json.loads((root/'approved_content_plan.json').read_text())['scenes'])==8
    assert result['new_generations']==0

def test_review_binding_is_exact_and_never_clears_journal(tmp_path):
    from engine.flow_recovery_review import candidates,bind_reviewed
    from engine.providers.flow_browser import FlowBrowserProvider
    record={'kind':'image','status':'pending','request_hash':'request','project_url':'https://flow.google.com/project/abc',
            'submitted_prompt':'original','signature':'stale','prompt_candidate_evidence':[{'prompt':'Actual gallery prompt'}]}
    path=tmp_path/'shot.jpg.flow-request.json';path.write_text(json.dumps(record))
    candidate=candidates(tmp_path)[0];assert bind_reviewed(tmp_path,candidate)['new_generations']==0
    saved=json.loads(path.read_text());assert saved['status']=='pending' and FlowBrowserProvider._bound_recovery_prompt(saved)=='Actual gallery prompt'
    candidate['prompt']='some other tile'
    with pytest.raises(ValueError,match='changed'):bind_reviewed(tmp_path,candidate)

def test_closed_image_event_tries_exact_url_before_browser_rebuild(tmp_path,monkeypatch):
    from engine.providers.flow_browser import FlowBrowser,FlowBrowserClosedError
    browser=FlowBrowser.__new__(FlowBrowser)
    browser._image_artifact_detail='browser_artifact_target_closed'
    monkeypatch.setattr(browser,'_save_browser_image_artifact',lambda d,p:False)
    calls=[]
    monkeypatch.setattr(browser,'_save_image_download_url',lambda d,p:calls.append(d.url) or True)
    event=NS(url='https://storage.googleapis.com/exact-image')
    assert browser._save_download_event(event,str(tmp_path/'frame.jpg')).endswith('frame.jpg')
    assert calls==[event.url]
    monkeypatch.setattr(browser,'_save_image_download_url',lambda d,p:False)
    with pytest.raises(FlowBrowserClosedError):browser._save_download_event(event,str(tmp_path/'frame.jpg'))

def test_multi_speaker_audio_real_concat_and_checkpoints(tmp_path,monkeypatch):
    import engine.audio.tts as tts
    from engine.cast import synthesize_turns
    from engine.production import run,probe
    calls=[]
    def synth(text,voice,out,**kwargs):
        calls.append((voice,kwargs['provider_voice']))
        run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i','sine=frequency=440:duration=1','-c:a','libmp3lame',out])
        return {'duration':1,'words':[]}
    monkeypatch.setattr(tts,'synthesize_narration',synth)
    audio=tmp_path/'audio';audio.mkdir()
    turns=[{'speaker_id':'S1','text':'Hello there','character_id':'girl','voice':'female','provider_voice':'Kore'},
           {'speaker_id':'S2','text':'Welcome back','character_id':'boy','voice':'male','provider_voice':'Puck'}]
    result=synthesize_turns(turns,audio/'voice.mp3','en')
    duration=float(probe(audio/'voice.mp3')['format']['duration'])
    assert 1.9<duration<2.2 and calls==[('female','Kore'),('male','Puck')]
    timeline=json.loads((tmp_path/'speaker_timing.json').read_text())['turns']
    assert [t['character_id'] for t in timeline]==['girl','boy'] and timeline[1]['start']==1
    synthesize_turns(turns,audio/'voice.mp3','en');assert len(calls)==2

def test_older_install_paths_are_relocated_only_to_existing_state(tmp_path):
    old,new=installs(tmp_path);target=new/'data/content/characters/a/photo.png';target.parent.mkdir(parents=True);target.write_bytes(b'photo')
    older=str(tmp_path/'AutoVideoAI-v7.0.10/data/content/characters/a/photo.png')
    assert migration.rebase(older,old,new)==str(target)
    external=str(tmp_path/'external/photo.png');assert migration.rebase(external,old,new)==external

def test_user_cast_photo_wins_over_old_generated_master(tmp_path):
    from engine.reference_manager import ReferenceManager
    from engine.cast import photo_paths
    refs=ReferenceManager(str(tmp_path/'references'))
    image=tmp_path/'photo.jpg';Image.new('RGB',(30,30),'blue').save(image)
    refs.add('character',str(image),'character_master.jpg')
    original=refs.add('character',str(image),'character-aanya-123-0.jpg')
    assert photo_paths(refs)==[original]

def test_serial_flow_scene_request_attaches_saved_photo(tmp_path,monkeypatch):
    from engine.factory import Factory
    from engine.project.manifest import Shot
    from engine.reference_manager import ReferenceManager
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'jobs.db'));job=f.create_job('Original scene',dry_run=True)
    m=f.pm.load_manifest(job);m.shots=[Shot(shot_id='shot_001',compiled_prompt='Show the selected character',character_ids=['girl-123'])]
    D=f.pm.dirs(job);refs=ReferenceManager(D['references'])
    photo=tmp_path/'photo.png';Image.new('RGB',(160,180),'blue').save(photo)
    saved=refs.add('character',str(photo),'character-girl-123-0.png');calls=[]
    def generate(shot,compiled,out,*a,**kw):
        calls.append(compiled);Image.new('RGB',(160,180),'blue').save(out);return {'path':out}
    provider=NS(generate_image=generate,current_project_url=lambda:'')
    monkeypatch.setattr(f,'_providers',lambda:{'flow':provider,'image':NS()})
    f._generate_scene_images(m,D,refs,True,1,lambda *a:None,{'flow_image_workers':1})
    assert calls[0]['reference_paths']==[saved]

def test_character_voice_style_edit_keeps_photo_portable(tmp_path):
    from engine.content_library import CharacterLibrary
    lib=CharacterLibrary(tmp_path/'characters');photo=tmp_path/'photo.png';Image.new('RGB',(20,20),'red').save(photo)
    character=lib.create('Aradhya','Animated original girl in yellow dress',reference_files=[str(photo)],original_confirmed=True)
    edited=lib.set_voice_style(character['id'],'feminine');assert edited['voice_style']=='feminine'
    record=json.loads((lib._folder(character['id'])/'character.json').read_text())
    assert not Path(record['references'][0]['path']).is_absolute()

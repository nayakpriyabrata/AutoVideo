# Approved voices reused by jobs (v7.0.85)

## What was happening

After Create step 4 approves the narration and "Prepare all selected TTS" has built the voices, a job still ran
the script localization and the TTS again for every language. The job log showed:

- `Voice ready via reviewed-prepared-narration` (the master voice from the approved batch was used), then
- `Localizing the approved master script HI` and `OR` (Gemini Web drafts), then
- `Preparing TTS and word timings EN`, `HI` and `OR` (new TTS calls).

Every language's voice was spent twice.

## Cause

When a job attached the approved batch, it reused the voices only if every card and hook setting matched the batch
exactly (text cards, educational, hooks). One difference, for example a text-card or hook checkbox changed after the
batch was prepared, caused the job to build everything again: scripts, then TTS for every language. The narration
text itself was not the cause; the voice check had already passed.

## What changed

- A job reuses the approved voices whenever the audio files and the master narration still match. The text-card,
  educational and hook settings no longer decide whether TTS is repeated.
- When those settings differ, only the cards are drafted again (Gemini Web text, not TTS), and only for the languages
  affected. Hooks are drafted only when they are newly requested.
- If no matching voices exist, the job builds them once, from the approved snapshot.
- The job log says when no approved narration was found for the master, so a repeat can be explained. The line reads:
  `No approved narration found for this master and languages; drafting it for review (no TTS yet)`.

## Still to confirm

- The cause of a repeated localization on a job whose batch was approved has not been reproduced here. If the job log
  still shows the "No approved narration found" line after this update, send `production/language_editions.json` and
  the `speech_preparation/scripts/` folder names from the Create step 4 batch.
- Gemini Web card drafts are still sent again when a card or hook setting changes. These use the Gemini Web
  daily limit, not the TTS limit.

## Files

- `engine/speech_cards.py`: `prepare_selected_editions` (voice reuse), `prepare_batch` (log line when no approved
  narration is found).
- `tests/test_v785_voice_reuse.py` (new, 4 tests).
- `tools/update_v784_to_v785.py`: updater from 7.0.84.

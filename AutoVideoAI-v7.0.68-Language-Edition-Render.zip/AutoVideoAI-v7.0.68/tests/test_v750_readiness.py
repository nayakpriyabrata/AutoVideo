import hashlib
import json
from pathlib import Path
import subprocess
import threading
from types import SimpleNamespace as NS
import pytest


def media(path, size, duration=1):
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',f'color=s={size}:r=5',
        '-f','lavfi','-i','sine=frequency=440:sample_rate=16000','-t',str(duration),
        '-c:v','libx264','-pix_fmt','yuv420p','-threads','1','-c:a','aac',str(path)],check=True,capture_output=True)


def streams(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(path)]))['streams']


@pytest.mark.parametrize('size',['1080x1920','1920x1080','406x720'])
def test_audible_proxy_real_encoder(tmp_path, monkeypatch, size):
    import engine.gemini_transcript as transcript
    import engine.providers.gemini_web as web
    source=tmp_path/'source.mp4';media(source,size)
    monkeypatch.setattr(transcript,'resolve_input',lambda *a,**k:str(source))
    proxies=[]
    def generate(*args,**kwargs):
        proxy=Path(kwargs['attachments'][0]);proxies.append(proxy)
        data=streams(proxy);video=next(s for s in data if s['codec_type']=='video')
        assert not video['width']%2 and not video['height']%2
        assert video['pix_fmt']=='yuv420p' and any(s['codec_type']=='audio' for s in data)
        subprocess.run(['ffmpeg','-v','error','-i',str(proxy),'-f','null','-'],check=True,capture_output=True)
        return json.dumps({'words':[{'word':'नमस्ते','start':0,'end':.5}]})
    monkeypatch.setattr(web,'gemini_web_generate',generate)
    result=transcript.draft_transcript(str(source),str(tmp_path/'draft'),'hi',rights_confirmed=True)
    assert result['language']=='hi' and all(not p.exists() for p in proxies)


def test_silent_proxy_real_encoder(tmp_path, monkeypatch):
    from engine.studio_review import review_recreation_clip
    import engine.providers.gemini_web as web
    monkeypatch.chdir(tmp_path)
    source=tmp_path/'source.mp4';media(source,'406x720',3)
    proxies=[]
    def generate(*args,**kwargs):
        proxy=Path(kwargs['attachments'][0]);proxies.append(proxy)
        data=streams(proxy);assert len(data)==1
        assert data[0]['codec_type']=='video' and not data[0]['width']%2
        return json.dumps({'topic':'Help','narration':'Please help me.', 'scenes':[{'text':'Please help me.', 'visual_intent':'Person requests help in a garden.', 'duration':3}]})
    monkeypatch.setattr(web,'gemini_web_generate',generate)
    result=review_recreation_clip(source,'Please help me.','en')
    assert not result['approved'] and all(not p.exists() for p in proxies)


def test_failed_encode_removes_proxy(tmp_path, monkeypatch):
    import engine.gemini_transcript as module
    source=tmp_path/'clip.mp4';source.write_bytes(b'fixture')
    monkeypatch.setattr(module,'resolve_input',lambda *a,**kw:str(source))
    monkeypatch.setattr(module,'_duration',lambda p:1)
    def fail(command,**kwargs):
        Path(command[-1]).write_bytes(b'partial')
        raise TimeoutError('encode timed out')
    monkeypatch.setattr(module,'_run',fail)
    with pytest.raises(TimeoutError):module.draft_transcript(str(source),str(tmp_path/'draft'))
    assert not list((tmp_path/'draft').glob('**/*.mp4'))


def test_caption_change_invalidates_checkpoint(tmp_path):
    from engine.broll import _clip_render_signature
    clip=tmp_path/'clip.mp4';clip.write_bytes(b'clip')
    ass=tmp_path/'captions.ass';ass.write_text('first captions')
    asset=tmp_path/'stock.mp4';asset.write_bytes(b'asset')
    group=[{'clip_output':str(clip),'caption_ass_path':str(ass),'path':str(asset)}]
    before=_clip_render_signature(group)
    ass.write_text('corrected captions')
    assert _clip_render_signature(group)!=before
    before=_clip_render_signature(group);asset.write_bytes(b'changed asset')
    assert _clip_render_signature(group)!=before


def test_reentrant_review_blocks_second_thread(tmp_path):
    from engine.review_lock import review_transaction
    path=str(tmp_path/'review.json');errors=[]
    def attempt():
        try:
            with review_transaction(path):pass
        except ValueError as e:errors.append(str(e))
    with review_transaction(path):
        with review_transaction(path):pass
        thread=threading.Thread(target=attempt);thread.start();thread.join(2)
        assert errors
    with review_transaction(path):pass


def test_exact_copied_clip_can_reuse_broll_but_changed_asset_cannot(tmp_path):
    from engine.broll import reusable_clip_candidates
    clip=tmp_path/'clip.mp4';clip.write_bytes(b'clip')
    copy=tmp_path/'renamed.mp4';copy.write_bytes(clip.read_bytes())
    asset=tmp_path/'stock.mp4';asset.write_bytes(b'asset')
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    review=tmp_path/'review.json';review.write_text(json.dumps({'schema_version':1,'workflow':'clip_studio','candidates':[{
        'clip_output':str(clip),'clip_output_sha256':digest(clip),'approved':True,'rights_reviewed':True,'path':str(asset),'sha256':digest(asset)}]}))
    assert len(reusable_clip_candidates(review,copy))==1
    asset.write_bytes(b'changed')
    with pytest.raises(ValueError,match='changed'):reusable_clip_candidates(review,copy)


def test_unverified_remote_delete_is_disabled_before_any_mutation():
    from engine.providers.flow_browser import FlowBrowser, FlowUIChanged
    browser=FlowBrowser.__new__(FlowBrowser)
    with pytest.raises(FlowUIChanged,match='disabled'):browser.delete_exact_project('https://flow.google.com/project/example')


@pytest.mark.parametrize('count',[1,2])
def test_attachment_control_uniqueness(count):
    from engine.providers.gemini_web import GeminiWebBrowser, GeminiWebUIChanged
    from tests.test_v731_dashboard_uploads import Nodes
    browser=GeminiWebBrowser.__new__(GeminiWebBrowser)
    browser.ui={'actions':{'attachment_menu':[{}]}}
    browser._build_locator=lambda spec:Nodes([NS(is_visible=lambda **kw:True)]*count)
    if count==1:assert browser._unique_attachment_control('attachment_menu',timeout_ms=1)
    else:
        with pytest.raises(GeminiWebUIChanged,match='ambiguous'):browser._unique_attachment_control('attachment_menu',timeout_ms=1)


def test_reserved_launch_does_not_overwrite_state(tmp_path):
    from engine.clip_render_jobs import start, job_dir
    from engine.production_lock import acquire, release
    review=tmp_path/'review.json';review.write_text('{"candidates": []}')
    root=job_dir(str(review));root.mkdir(parents=True)
    state=root/'state.json';state.write_text('{"preserved": true}')
    with (root/'.launch.lock').open('a+b') as handle:
        acquire(handle,blocking=False)
        try:assert start(str(review)) is False
        finally:release(handle)
    assert json.loads(state.read_text())=={'preserved':True}


def test_folder_lock_prevents_start(tmp_path):
    from engine.clip_render_jobs import start
    from engine.production_lock import acquire, release
    review=tmp_path/'review.json';review.write_text('{"candidates": []}')
    with (tmp_path/'.production.lock').open('a+b') as handle:
        acquire(handle,blocking=False)
        try:assert start(str(review)) is False
        finally:release(handle)

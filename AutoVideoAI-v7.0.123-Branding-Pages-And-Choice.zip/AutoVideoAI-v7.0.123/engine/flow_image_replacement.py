"""User-authorized, bounded image replacement. Never erases the original request."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import secrets
import time
from .production import read, save


def replace_image(provider, shot, compiled, out_path, vertical, *, pending_error=None):
    from .providers.flow_browser import FlowRequestPending
    original = read(out_path + '.flow-request.json', {})
    expected = hashlib.sha256(json.dumps(['image',str(shot.shot_id),compiled.get('prompt',''),vertical],sort_keys=True).encode()).hexdigest()
    if original.get('kind') != 'image' or original.get('request_hash') != expected:
        raise FlowRequestPending('Replacement refused: original image request does not match this shot/prompt')
    bound=compiled.get('project_url')
    if original.get('scope') != 'isolated_image_v1' and bound and original.get('project_url') and bound != original['project_url']:
        raise FlowRequestPending('Replacement refused: main Flow project binding changed')
    reservation = Path(out_path + '.image-replacement.json')
    child = out_path + '.replacement-01.jpg'
    child_journal = Path(child + '.flow-request.json')
    just_reserved = False
    if not reservation.exists():
        if not compiled.get('flow_replace_unresolved_images') or pending_error is None:
            raise FlowRequestPending('No replacement permission; original request retained')
        root = Path(compiled.get('flow_image_replacement_root') or '').resolve()
        if not compiled.get('flow_image_replacement_root') or not Path(out_path).resolve().is_relative_to(root):
            raise FlowRequestPending('Replacement requires a valid job-scoped ledger')
        limit = compiled.get('flow_image_replacement_limit',30)
        if type(limit) is not int or not 1 <= limit <= 100:
            raise FlowRequestPending('Invalid whole-job image replacement cap')
        ledger_dir=root/'flow_image_replacements';ledger_dir.mkdir(parents=True,exist_ok=True)
        # Serialize reservations across processes/parallel workers. Count before
        # opening Flow, and retain the reservation even if the process crashes.
        import fcntl
        with (ledger_dir/'reservation.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            if not reservation.exists():
                ledger=read(ledger_dir/'ledger.json',{'reservations':{}})
                key=str(Path(out_path).resolve().relative_to(root))
                entries=ledger['reservations']
                if key in entries:
                    raise FlowRequestPending('An earlier replacement slot exists without its reservation file; no repeat submission permitted')
                bounded = read(root/'authorized_frame_replacements'/'ledger.json', {}).get('frames', {})
                if len(entries) + len(bounded) >= limit:
                    raise FlowRequestPending(f'Whole-job image replacement cap ({limit}) reached; original requests retained')
                record={'schema_version':1,'original_request_hash':expected,
                        'original_project_url':original.get('project_url',''),
                        'state':'reserved','created_at':time.time(),'per_image_limit':1,
                        'replacement_project_name':'AutoVideo-ImageReplacement-'+secrets.token_hex(10),
                        'reason':str(pending_error)[-1200:],'possible_unused_duplicate':True}
                entries[key]=record
                save(ledger_dir/'ledger.json',ledger)  # crash here still counts the slot
                save(reservation,record)
                just_reserved=True
    record=read(reservation)
    if record.get('original_request_hash') != expected or record.get('original_project_url') != original.get('project_url',''):
        raise FlowRequestPending('Replacement context changed; no new generation submitted')
    if not just_reserved and not child_journal.exists():
        raise FlowRequestPending('Replacement reserved but submission cannot be verified; no second generation permitted')
    child_request=read(child_journal,{})
    replacement_compiled={**compiled,'project_url':child_request.get('project_url') or '',
                          'project':record['replacement_project_name'],
                          'flow_replace_unresolved_images':False,'max_generation_credits':0,
                          'approval':'once',
                          'flow_replacement_request':True}
    # Isolated transactions already own a bounded three-reconnect budget.
    recovery_attempts = 1 if child_request.get('scope') == 'isolated_image_v1' or not child_request else 4
    for attempt in range(recovery_attempts):
        try:
            result=provider._guarded_generation_once(shot,replacement_compiled,None,child,vertical,False,'image')
            break
        except FlowRequestPending:
            # Only a durable child journal authorizes another recovery call.
            # Never retry submission when its outcome is uncertain.
            if attempt + 1 == recovery_attempts or not child_journal.exists():
                raise
    if not result.get('path') or not provider._asset_valid(child,'image'):
        raise FlowRequestPending('Replacement not validated; Resume will recover that exact replacement')
    temporary=out_path+'.replacement-copy.tmp'
    shutil.copy2(child,temporary);os.replace(temporary,out_path)
    record.update(state='downloaded',replacement_sha256=hashlib.sha256(Path(child).read_bytes()).hexdigest())
    save(reservation,record)
    root = Path(compiled['flow_image_replacement_root']).resolve()
    from .isolated_frame_regeneration import write_json
    backup = Path(out_path + '.flow-request.original.json')
    if not backup.exists():
        shutil.copy2(out_path + '.flow-request.json', backup)
    original.update(status='superseded_by_authorized_replacement',
        replacement_file=str(Path(child).resolve().relative_to(root)),
        replacement_target=str(Path(out_path).resolve().relative_to(root)),
        replacement_sha256=record['replacement_sha256'])
    write_json(out_path + '.flow-request.json', original)
    return {**result,'path':out_path,'provider':'flow-image-replacement',
            'replacement_project_url':result.get('project_url',''),
            'project_url':original.get('project_url',''),
            'log':'Using one authorized replacement image; original unresolved journal retained'}


def finish_saved_replacement(root, reservation):
    """Offline commit of a completed child after a restart; never generate."""
    from .isolated_frame_regeneration import image_valid, sha, write_json
    root, reservation = Path(root).resolve(), Path(reservation)
    parent = Path(str(reservation)[:-len('.image-replacement.json')])
    child = Path(str(parent) + '.replacement-01.jpg')
    original_path = Path(str(parent) + '.flow-request.json')
    child_path = Path(str(child) + '.flow-request.json')
    for path in (reservation, parent, child, original_path, child_path):
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError('Replacement path leaves the job')
    record, original, saved = read(reservation), read(original_path), read(child_path, {})
    if (original.get('request_hash') != record.get('original_request_hash')
            or original.get('project_url', '') != record.get('original_project_url', '')):
        raise ValueError('Parent replacement context changed')
    if (saved.get('status') != 'downloaded' or saved.get('kind') != 'image'
            or saved.get('request_hash') != record.get('original_request_hash')
            or not image_valid(child)):
        return False
    digest = sha(child)
    if saved.get('media_sha256') and saved['media_sha256'] != digest:
        raise ValueError('Replacement checksum changed')
    if original.get('status') == 'superseded_by_authorized_replacement' and parent.is_file() and sha(parent) == digest:
        return True
    backup = Path(str(parent) + '.flow-request.original.json')
    if not backup.exists(): shutil.copy2(original_path, backup)
    stage = Path(str(parent) + '.replacement-copy.tmp')
    shutil.copy2(child, stage); os.replace(stage, parent)
    original.update(status='superseded_by_authorized_replacement',
        replacement_file=str(child.relative_to(root)), replacement_target=str(parent.relative_to(root)),
        replacement_sha256=digest)
    write_json(original_path, original)
    record.update(state='downloaded', replacement_sha256=digest)
    write_json(reservation, record)
    return True

"""Channel name and logo decisions for the Create form.

Channel profiles chosen in Language editions are the source of truth. The
Create form asks for a name or logo only for the editions that still have no
profile, and saves those entries as profiles when the production is created.

7.0.95: one profile can carry a logo per language (``assets['logo-en']``,
``assets['logo-hi']``, ``assets['logo-or']``). The Create page shows the three
languages together, saves them into one profile and can hand that profile to
every selected edition, instead of asking for the same channel three times and
keeping only the last uploaded logo.
"""

from .finishing_studio import LANGUAGES


def branding_plan(editions, profiles, primary):
    """Which editions still need a channel name and logo in the Create form.

    ``editions`` lists every selected edition (primary included); ``profiles``
    maps edition codes to chosen profile paths.
    """
    selected = list(editions) or [primary]
    missing = [edition for edition in selected if edition not in profiles]
    return {
        'complete': not missing,
        'primary_missing': primary in missing,
        'inline': [edition for edition in missing if edition != primary],
    }


def logo_entry(profile, language):
    """The logo saved for one language, falling back to the profile's shared logo."""
    assets = (profile or {}).get('assets') or {}
    return assets.get('logo-' + str(language or '')) or assets.get('logo') or None


def logo_path(profile, language):
    """Filesystem path of the logo this language will use, or ''."""
    entry = logo_entry(profile, language)
    if isinstance(entry, dict):
        return str(entry.get('path') or '')
    return ''


def logo_is_language_specific(profile, language):
    assets = (profile or {}).get('assets') or {}
    return bool(assets.get('logo-' + str(language or '')))


def channel_name(profile, language):
    """The channel name in this language, falling back to the profile's own name."""
    if not profile:
        return ''
    return str((profile.get('names') or {}).get(language) or profile.get('name') or '')


def language_rows(editions, profiles, *, read_profile):
    """One row per selected language: profile, name, logo and what is missing.

    ``read_profile(path)`` returns the parsed profile, so the Create page can show
    the three languages without duplicating profile parsing. Every row states
    which logo the edition will actually use, so a shared logo is never mistaken
    for a language-specific one.
    """
    rows = []
    for language in editions:
        path = (profiles or {}).get(language) or ''
        profile = read_profile(path) if path else {}
        entry = logo_entry(profile, language)
        rows.append({
            'language': language,
            'label': LANGUAGES.get(language, language),
            'profile': str(path),
            'profile_name': str((profile or {}).get('name') or ''),
            'channel_name': channel_name(profile, language),
            'logo_path': logo_path(profile, language),
            'logo_source': ('own logo for this language' if logo_is_language_specific(profile, language)
                            else ('shared profile logo' if entry else 'no logo')),
            'intro': bool(((profile or {}).get('assets') or {}).get('intro')),
            'outro': bool(((profile or {}).get('assets') or {}).get('outro')),
            'missing': [] if path else ['no channel profile selected'],
        })
    return rows


def save_language_logos(name, languages, logo_uploads, upload_media, save_profile, *,
                        names=None, intro=None, outro=None):
    """Save one profile holding a logo for each selected language.

    ``logo_uploads`` maps language -> uploaded file (or None). Empty uploads keep
    whatever that language already had, exactly like the per-channel form.
    Returns the profile path.
    """
    name = str(name or '').strip()
    if not name:
        raise ValueError('Enter the channel name for this profile')
    logos = {}
    for language in languages:
        path = upload_media(logo_uploads.get(language), 'logo-' + str(language))
        if path:
            logos[language] = path
    # A single uploaded logo also becomes the profile's shared logo, so the Finishing
    # Studio and one-language productions keep showing it without extra steps.
    shared = next(iter(logos.values())) if len(logos) == 1 else ''
    return str(save_profile(name, names={lang: (names or {}).get(lang) or name for lang in languages} | (names or {}),
                            logo=shared, logos=logos,
                            intro=upload_media(intro, 'intro') if intro else '',
                            outro=upload_media(outro, 'outro') if outro else ''))


def save_missing_profiles(entries, save_profile, upload_media):
    """Save one profile per edition that was given a name; return {edition: path}.

    ``entries`` maps edition -> (name, uploaded_logo_or_None). An edition left
    without a name gets no profile and renders with no channel mark.
    """
    saved = {}
    for edition, (name, logo) in entries.items():
        name = str(name or '').strip()
        if not name:
            continue
        logo_path = upload_media(logo, 'logo')
        saved[edition] = str(save_profile(name, names={edition: name}, logo=logo_path))
    return saved

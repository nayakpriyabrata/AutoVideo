#!/usr/bin/env python3
"""Small v7 Mini Reels adapter; the engine owns provider calls and request journals."""
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def execute(operation, payload):
    from engine import mini_reels
    os.environ['AUTOVIDEO_GEMINI_CHAT_CLEANUP'] = 'keep'
    c = payload['config']
    if operation == 'mini-brief':
        brief = mini_reels.generate_prompt_brief(c['idea'], visual_style=c['visual_style'],
            language=c['language'], audio_mode=c['audio_mode'], category=c['category'])
        prompt = mini_reels.compose_flow_prompt(brief, visual_style=c['visual_style'],
            language=c['language'], audio_mode=c['audio_mode'], model=c['model'])
        return {'brief': brief, 'flow_prompt': prompt}
    if operation == 'mini-generate':
        return mini_reels.generate_flow_reel(payload['reel_id'], brief=payload['brief'],
            **{key: c[key] for key in ('flow_prompt', 'model', 'visual_style', 'audio_mode',
                'language', 'flow_project_url', 'max_generation_credits',
                'flow_capacity_wait_seconds', 'flow_capacity_retries', 'flow_video_recovery_wait_seconds')},
            flow_approval='once',character_ids=c.get('character_ids',[]),
            **({'allow_other_pending':True} if c.get('allow_other_pending') is True else {}))
    if operation == 'mini-recover':
        return mini_reels.recover_flow_reel(payload['reel_id'])
    raise ValueError('Unsupported control-center operation')


def main():
    operation, path = sys.argv[1:]
    result = execute(operation, json.loads(Path(path).read_text(encoding='utf-8')))
    # Keep full prompts out of log tails; only the local result file stores content.
    Path(str(path) + '.result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Control-center operation completed.', flush=True)


if __name__ == '__main__':
    main()

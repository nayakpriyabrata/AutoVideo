import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS

import pytest
from PIL import Image
from engine.providers.flow_browser import FlowBrowser, FlowBrowserProvider


BRIEF = ('STORYBOARD CLOSE FRAME, vertical 9:16. Capture the natural END state '
         'immediately AFTER the described action completes. Subject: Debanshi. '
         'Action context: Debanshi has just finished demonstrating cloud automation. '
         'Ultra detailed still frame, sharp focus, professional photography.')


@pytest.mark.parametrize('tracking', [False, True])
@pytest.mark.parametrize('vertical', [False, True])
def test_flow_reuse_can_return_exact_scene_without_agent_envelope(tracking, vertical):
    sent = FlowBrowser._agent_image_instruction(BRIEF, '9:16' if vertical else '16:9')
    if tracking:
        sent = 'Request tracking label AVREQ_' + 'a'*24 + '; metadata only, never draw or write it in the image. ' + sent
    assert FlowBrowser.same_image_generation_prompt(BRIEF, sent)
    assert FlowBrowser.same_image_generation_prompt(sent, sent)
    assert not FlowBrowser.same_image_generation_prompt(BRIEF.replace('END', 'START'), sent)
    assert not FlowBrowser.same_image_generation_prompt(BRIEF + ' Add a cat.', sent)
    assert not FlowBrowser.same_image_generation_prompt('Debanshi', sent)
    assert not FlowBrowser.same_image_generation_prompt(BRIEF, 'Unknown instruction: ' + sent)


def test_existing_job_recovers_exact_brief_among_four_images_no_submission(tmp_path):
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    out = str(tmp_path / 'shot_001_close.jpg')
    prompt = BRIEF.removesuffix(' Ultra detailed still frame, sharp focus, professional photography.')
    key = hashlib.sha256(json.dumps(['image', 'shot_001', prompt, True], sort_keys=True).encode()).hexdigest()
    provider._save_request(out, {'kind':'image', 'request_hash':key,
        'baseline':['master-person','master-room'], 'signature':'',
        'project_url':'https://flow.google.com/project/test'})
    assets = [{'sig':sig, 'kind':'image'} for sig in ['close', 'open', 'master-person', 'master-room']]
    reads = []
    def read(sig):
        reads.append(sig)
        return BRIEF if sig == 'close' else BRIEF.replace('END', 'START')
    def download(*args, **kwargs):
        assert kwargs['preferred_signature'] == 'close'
        Image.new('RGB', (200, 300), 'blue').save(out)
    bridge = NS(media_assets=lambda:assets, read_asset_generation_prompt=read,
        ensure_project=lambda *a, **k:None, download_latest_asset=download,
        _page=NS(wait_for_timeout=lambda ms:None))
    provider._ensure = lambda:bridge
    provider._generate_image_once = lambda *a, **k:pytest.fail('must not submit or charge')
    result = provider._guarded_generation_once(NS(shot_id='shot_001'),
        {'prompt':prompt}, None, out, True, False, 'image')
    saved = json.loads(Path(out + '.flow-request.json').read_text())
    assert result['credits'] == 0 and saved['status'] == 'downloaded'
    assert saved['signature'] == 'close'
    assert saved['verified_scene_sha256'] == hashlib.sha256(BRIEF.encode()).hexdigest()
    assert set(reads) == {'close', 'open'}


def test_unavailable_reuse_control_reports_evidence_without_guessing():
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    request = {'baseline':[], 'submitted_prompt':FlowBrowser._agent_image_instruction(BRIEF)}
    bridge = NS(media_assets=lambda:[{'sig':'unknown','kind':'image'}],
                read_asset_generation_prompt=lambda sig:None)
    assert not provider._identify_single_fresh_asset(bridge, request, 'image', 0)
    assert request['correlation_probe'] == {'gallery_assets':1, 'fresh_candidates':1,
                                          'readable_prompts':0, 'unreadable_prompts':1}
    assert 'signature' not in request


def test_video_prompt_matching_does_not_strip_image_instructions():
    assert not FlowBrowser.same_generation_prompt(BRIEF, FlowBrowser._agent_image_instruction(BRIEF))

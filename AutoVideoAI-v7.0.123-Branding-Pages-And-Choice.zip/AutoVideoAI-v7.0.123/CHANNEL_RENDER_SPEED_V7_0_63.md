# v7.0.63 · channel selection and render speed

## Finishing Studio

Create **one profile for each actual channel**, such as The Skill Shift Academy, Hunar Setu and Odia Pragati. Upload each channel's logo, intro and outro while saving that profile. When creating a finishing plan, select the channel profile separately for the English, Hindi and Odia editions. The saved plan snapshots the corresponding media for each edition; later edits to a profile cannot silently change an approved render. Existing v7.0.62 plans remain readable.

A reviewed track from the shared music library can be selected **once for all editions**. You can still choose an edition-specific override at review time. Check the track's current permission for all destination platforms. Selecting another language does not translate existing speech: provide a matching reviewed narration track for each dub.

CLI example:

```bash
python3 cli.py v3 channel-profile --name 'The Skill Shift Academy' --logo /path/academy.png --intro /path/academy-intro.mp4
python3 cli.py v3 channel-profile --name 'Hunar Setu' --logo /path/hunar.png --intro /path/hunar-intro.mp4
python3 cli.py v3 channel-profile --name 'Odia Pragati' --logo /path/odia.png --intro /path/odia-intro.mp4
python3 cli.py v3 finish-plan /path/final.mp4 --languages en,hi,or \
  --profile-en /path/channel_profiles/the-skill-shift-academy/profile.json \
  --profile-hi /path/channel_profiles/hunar-setu/profile.json \
  --profile-or /path/channel_profiles/odia-pragati/profile.json \
  --shared-music /path/licensed.ogg --shared-music-license 'Source page and exact permission'
```

## Main video render

New jobs default to **fast** at the requested output size and frame rate. It uses x264 veryfast at CRF 18, which generally cuts CPU encode time at the cost of a potentially larger MP4; `high` remains available with the old slow preset and CRF 17. Previously saved jobs retain their recorded choice. An explicit `--quality fast` is also available for local re-renders. It never changes Flow video generation time or credits.

Large edits still preserve the decoder cap and all approved cutaways. Intermediate renders now use a faster, low-CRF preset, with the selected quality applied to the final encode. The job logs report stage number, elapsed time and a rough remaining estimate. `render/render_stage_timings.json` and `render/render_profile.json` record timings and quality; use them to distinguish B-roll search, staging, final encode and quality-control delays. An estimate based on completed stages is approximate, especially if graphics or cutaway intervals differ greatly in length. Safe QC and recovery are unchanged.

This update was checked with local synthetic media, not a 5-minute video on your WSL machine. Render time still depends on CPU, storage, number of graphics/cutaways and fallback/QC behavior. For a precise diagnosis of your four-hour job, compare its `logs/runtime.log` timestamps and the new timing files from the next render.

## Upgrade

Stop Studio, runner and active jobs. Extract the v7.0.63 ZIP beside an existing v7.0.62 installation, then run from the existing installation:

```bash
python3 ../AutoVideoAI-v7.0.63/tools/update_v762_to_v763.py . --apply
./dashboard.sh
```

The updater changes code only, checks known v7.0.62 hashes, creates code backups, and preserves output jobs, saved plans, profiles and library music. It refuses unexpected local edits to changed code files.

"""Install self-check: is this folder one consistent release? (v7.0.118)

The user's Streamlit app died on `TypeError: Factory.create_job() got an unexpected keyword
argument 'flow_auto_approve_video_requests'`. Nothing in the product could answer the only
question that mattered: *are app.py and engine/ from the same zip?*  This module answers it,
names the file, and prints the exact repair.

Every check is read-only: no browser, no Flow, no credits, no job created.
"""
import inspect
import json
import os

REPAIR = ('install the complete zip for this version over this folder so app.py and engine/ come '
          'from the same release')


def _version():
    try:
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'VERSION'),
                  encoding='utf-8') as handle:
            return handle.read().strip()
    except OSError:
        return ''


def _studio_keys():
    """The keyword arguments the Studio form sends to Factory.create_job()."""
    from . import studio_config
    cfg = dict(studio_config.DEFAULTS)
    cfg.update({"topic": "self-check", "production_mode": "youtube_pro",
                "production_mode_engine": "youtube_pro", "theme": "motivational",
                "duration": 60, "profile": "FLOW_BALANCED", "language": "en",
                "aspect": "16:9", "video_type": "faceless_youtube"})
    return studio_config.config_to_factory_kwargs(cfg)


def create_job_mismatch():
    """Keys the Studio sends that ``Factory.create_job`` does not accept; sorted list."""
    from .factory import Factory
    accepted = set(inspect.signature(Factory.create_job).parameters)
    return sorted(key for key in _studio_keys() if key not in accepted)


def job_settings_keys(job_dir):
    """Keys a real job's settings.json carries that this engine no longer reads back.

    A half-installed engine can create a job and then ignore one of its settings; this names it
    instead of letting the setting disappear silently.
    """
    try:
        with open(os.path.join(str(job_dir), 'settings.json'), encoding='utf-8') as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return []
    from .factory import job_setting_keys
    known = job_setting_keys()
    return sorted(key for key in saved if key not in known)


def rows():
    """Every check as ``{'check', 'ok', 'detail', 'repair'}``."""
    out = []
    version = _version()
    out.append({'check': 'VERSION file', 'ok': bool(version),
                'detail': version or 'VERSION is missing or empty',
                'repair': 'install the complete zip for this version (VERSION sits next to app.py)'})
    try:
        from . import factory  # noqa: F401
        from . import studio_config  # noqa: F401
        import_ok, import_detail = True, 'engine.factory and engine.studio_config import'
    except Exception as error:  # pragma: no cover - broken install
        import_ok, import_detail = False, f'{type(error).__name__}: {error}'
    out.append({'check': 'engine imports', 'ok': import_ok, 'detail': import_detail,
                'repair': REPAIR + '; then run `python3 cli.py v3 self-check`'})
    if import_ok:
        try:
            missing = create_job_mismatch()
            detail = ('the Studio form and Factory.create_job() agree on every setting'
                      if not missing else
                      'this Studio sends ' + ', '.join(missing) + ' but engine/factory.py '
                      'create_job() does not accept it/them, so Create production fails with a TypeError')
            out.append({'check': 'Studio ↔ create_job keywords', 'ok': not missing,
                        'detail': detail,
                        'repair': (REPAIR + '; the mismatch is between app.py/engine/studio_config.py '
                                   'and engine/factory.py')})
        except Exception as error:  # pragma: no cover
            out.append({'check': 'Studio ↔ create_job keywords', 'ok': False,
                        'detail': f'{type(error).__name__}: {error}', 'repair': REPAIR})
    try:
        from . import production, speech_cards, edition_files  # noqa: F401
        card_ok, card_detail = True, 'engine.production, engine.speech_cards, engine.edition_files import'
    except Exception as error:  # pragma: no cover - broken install
        card_ok, card_detail = False, f'{type(error).__name__}: {error}'
    out.append({'check': 'render/edition modules', 'ok': card_ok, 'detail': card_detail,
                'repair': REPAIR})
    return out


def format_report(report=None):
    report = rows() if report is None else report
    lines = ['AutoVideoAI self-check · version ' + (_version() or 'unknown')]
    for row in report:
        lines.append(('OK   ' if row['ok'] else 'FAIL ') + row['check'] + ' · ' + row['detail'])
        if not row['ok']:
            lines.append('     repair: ' + row['repair'])
    failed = [row for row in report if not row['ok']]
    lines.append('')
    lines.append('All checks passed.' if not failed else
                 str(len(failed)) + ' check(s) failed; nothing was created or generated.')
    return '\n'.join(lines)

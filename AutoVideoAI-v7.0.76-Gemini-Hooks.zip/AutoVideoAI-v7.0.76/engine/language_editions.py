"""Render the reviewed language editions of a finished production.

The production's own final render stays the primary-language edition. Each
additional edition is built from the same clean visual master (picture only),
its exact reviewed narration, its timed cards and word-timed captions, and the
channel profile chosen in Create. Nothing here calls Gemini, Flow or any visual
generator, and nothing is overwritten: each export is a new file.

State lives in the job:
  production/language_editions.json       selections saved by Create (inputs)
  production/language_editions_render.json per-language render record (outputs)
"""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path

from . import finishing_studio as finish

STATE_NAME = 'language_editions.json'
RECORD_NAME = 'language_editions_render.json'


def _read(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding='utf8'))


def _label(code):
    return finish.LANGUAGES.get(code, code)


def _production_music(job_root):
    """Reuse the primary production's background track, with its recorded licence."""
    sound = _read(Path(job_root) / 'audio' / 'sound_plan.json', {}) or {}
    music = sound.get('music')
    if isinstance(music, str):
        music = {'path': music}
    if not isinstance(music, dict) or not music.get('path'):
        return None, ''
    path = Path(music['path'])
    if not path.is_file():
        return None, ''
    licence = ' · '.join(str(x) for x in (music.get('source'), music.get('license')) if x) or \
        'Production background track; licence recorded in the job provenance'
    return str(path), licence


def _record_path(job_root):
    return Path(job_root) / 'production' / RECORD_NAME


def _save_record(job_root, record):
    record['updated_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    finish._atomic_json(_record_path(job_root), record)


def requested_languages(job_root):
    """(source_language, additional_languages, state) for a job; empty when single-language."""
    state = _read(Path(job_root) / 'production' / STATE_NAME)
    if not state:
        return None, [], None
    source = str(state.get('source_language') or 'en')
    editions = list(dict.fromkeys(state.get('editions') or [source]))
    return source, [code for code in editions if code != source], state


def _publish_copy(export, destination):
    """Copy a finished export into render/ atomically and verify the bytes."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.stem + '.copying.mp4')
    shutil.copy2(export, temporary)
    if finish._hash(temporary) != finish._hash(export):
        temporary.unlink(missing_ok=True)
        raise ValueError('Copy verification failed for ' + destination.name)
    os.replace(temporary, destination)
    return str(destination)


def edition_render_name(job_root, code):
    """File name of a finished language edition inside the production's render/ folder."""
    return Path(job_root).name + '-' + code + '-edition.mp4'


def _sync_render_copies(job_root, record):
    """Keep every finished edition visible in render/. Idempotent; returns True when the record changed."""
    changed = False
    render_dir = Path(job_root) / 'render'
    for code, entry in (record.get('editions') or {}).items():
        if entry.get('status') != 'exported' or not entry.get('path'):
            continue
        export = Path(entry['path'])
        if not export.is_file():
            continue
        target = render_dir / edition_render_name(job_root, code)
        if target.is_file() and finish._hash(target) == entry.get('sha256'):
            if entry.get('render_copy') != str(target):
                entry['render_copy'] = str(target)
                changed = True
            continue
        try:
            entry['render_copy'] = _publish_copy(export, target)
            entry.pop('render_copy_error', None)
        except Exception as error:  # the export itself is still valid; report the copy problem
            entry['render_copy_error'] = str(error)[:300]
        changed = True
    return changed


def render_primary_branding(job_root, final_path, *, progress=None):
    """Give the primary-language master the profile intro and outro automatically.

    Only multi-language productions are touched, and only when the primary
    language's channel profile has an intro or outro. The picture, captions,
    music and any channel mark are already in the final master, so the logo and
    channel name are not applied a second time. Writes ``<job>-<lang>-branded.mp4``
    into render/ and records the outcome under ``primary`` in the render record.
    """
    job_root = Path(job_root).resolve()
    emit = progress or (lambda label, pct, detail='': None)
    source, _extra, state = requested_languages(job_root)
    if state is None:
        return {'status': 'not_requested'}
    profile_path = (state.get('profiles') or {}).get(source)
    profile = _read(profile_path, {}) if profile_path else {}
    assets = (profile or {}).get('assets') or {}
    if not (assets.get('intro') or assets.get('outro')):
        return {'status': 'no_intro_outro', 'language': source}
    final = Path(final_path)
    if not final.is_file():
        return {'status': 'failed', 'language': source, 'error': 'Primary master is missing: ' + final.name}
    record = _read(_record_path(job_root), {'schema_version': 1, 'editions': {}})
    emit('Adding intro and outro to the ' + _label(source) + ' master', 0, _label(source))
    try:
        plan_path = finish.create_plan(
            final, {source: profile_path}, languages=[source], output_root=job_root / 'primary_branding',
            source_rights='own_content', source_language=source, require_profiles=True,
            fit_narration=False, captions=False, use_clean_master=False)
        plan = _read(plan_path)
        edition = plan['editions'][source]
        # Only intro and outro: no narration, cards, captions, music, logo or channel name are added here.
        edition['assets'] = {k: v for k, v in (edition.get('assets') or {}).items() if k in ('intro', 'outro')}
        edition.update({'channel': {'name': '', 'display_name': ''}, 'narration': None, 'cards': [],
                        'words': None, 'music': None})
        edition.pop('script', None)
        edition.pop('timing_source', None)
        plan['shared_music'] = None
        plan['shared_music_license'] = ''
        finish._atomic_json(plan_path, plan)
        finish.set_edition(plan_path, source, reviewed=True)
        exported = finish.render(plan_path, source, progress=lambda value: emit(
            'Adding intro and outro to the ' + _label(source) + ' master', 100 * float(value), _label(source)))
        target = job_root / 'render' / (job_root.name + '-' + source + '-branded.mp4')
        copied = _publish_copy(exported, target)
        report = {'status': 'exported', 'language': source, 'path': str(exported), 'render_copy': copied,
                  'sha256': finish._hash(exported), 'plan': str(plan_path),
                  'source_master': str(final), 'finished_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    except Exception as error:
        report = {'status': 'failed', 'language': source, 'error': str(error)[:800],
                  'source_master': str(final), 'finished_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    record['primary'] = report
    _save_record(job_root, record)
    return report


def render_job_editions(job_root, *, progress=None):
    """Render every pending additional edition. Returns a status report; never silently English.

    Status values: ``not_requested`` (no language state), ``single_language``,
    ``exported`` (all editions current), ``partial`` or ``failed`` (see ``editions``).
    Raises ValueError only for preconditions the user must fix first.
    """
    job_root = Path(job_root).resolve()
    emit = progress or (lambda label, pct, detail='': None)
    source, extra, state = requested_languages(job_root)
    if state is None:
        return {'status': 'not_requested', 'editions': {}}
    if not extra:
        return {'status': 'single_language', 'editions': {}}

    bundles = state.get('bundles') or {}
    not_ready = [code for code in extra if code not in bundles]
    if not_ready:
        raise ValueError('Approve and prepare the narration for ' + ', '.join(_label(c) for c in not_ready) +
                         ' in Create step 4 before rendering language editions. No English voice is used as a fallback.')
    visual_record = _read(job_root / 'production' / 'visual_master.json')
    if not visual_record:
        raise ValueError('The clean visual master is missing. Render this production again so the language '
                         'editions use the approved picture.')
    visual = Path(visual_record['path'])
    if not visual.is_file() or finish._hash(visual) != visual_record.get('sha256'):
        raise ValueError('The clean visual master changed or is missing. Render this production again.')

    record = _read(_record_path(job_root), {'schema_version': 1, 'editions': {}})
    previous = record.get('editions', {})
    pending = []
    for code in extra:
        bundle_sha = bundles[code].get('audio_sha256')
        entry = previous.get(code, {})
        export = Path(entry.get('path', '')) if entry.get('path') else None
        current = (entry.get('status') == 'exported' and entry.get('audio_sha256') == bundle_sha
                   and export is not None and export.is_file() and finish._hash(export) == entry.get('sha256'))
        if not current:
            pending.append(code)
    if not pending:
        if _sync_render_copies(job_root, record):
            _save_record(job_root, record)
        return {'status': 'exported', 'editions': previous, 'record': str(_record_path(job_root))}

    profiles = state.get('profiles') or {}
    music_path, music_licence = _production_music(job_root)
    plan_path = finish.create_plan(
        visual, {code: profiles.get(code) for code in pending}, languages=pending,
        output_root=job_root / 'language_editions', source_rights='own_content',
        shared_music=music_path, shared_music_license=music_licence,
        source_language=source, require_profiles=False, fit_narration=True, captions=True)
    plan = json.loads(Path(plan_path).read_text(encoding='utf8'))
    for code in pending:
        finish.set_edition(plan_path, code, reviewed=True)

    record.update({'schema_version': 1, 'source_language': source, 'plan': str(plan_path)})
    failures = []
    for index, code in enumerate(pending):
        label = _label(code)
        entry = {'status': 'rendering', 'plan': str(plan_path), 'audio_sha256': bundles[code].get('audio_sha256'),
                 'channel': plan['editions'][code].get('channel', {})}
        record.setdefault('editions', {})[code] = entry
        _save_record(job_root, record)
        emit('Rendering ' + label + ' edition', 100 * index / len(pending), label)

        def edition_progress(value, _index=index, _label=label):
            emit('Rendering ' + _label + ' edition', 100 * (_index + float(value)) / len(pending), _label)
        try:
            exported = finish.render(plan_path, code, progress=edition_progress)
            entry.update(status='exported', path=str(exported), sha256=finish._hash(exported))
            _sync_render_copies(job_root, {'editions': {code: entry}})
        except Exception as error:  # keep the primary edition and every finished edition
            entry.update(status='failed', error=str(error)[:800])
            failures.append(label + ': ' + str(error)[:300])
        entry['finished_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        _save_record(job_root, record)
    emit('Language editions finished', 100)

    statuses = {code: record['editions'][code].get('status') for code in extra}
    if all(status == 'exported' for status in statuses.values()):
        overall = 'exported'
    elif any(status == 'exported' for status in statuses.values()):
        overall = 'partial'
    else:
        overall = 'failed'
    record['status'] = overall
    _save_record(job_root, record)
    return {'status': overall, 'editions': record['editions'], 'record': str(_record_path(job_root)),
            'error': '; '.join(failures)}


def render_language_outputs(job_root, *, progress=None):
    """Everything that makes a multi-language production complete, in order.

    1. the English master with the profile intro/outro (skipped when already current);
    2. every pending extra edition, copied into render/.
    Returns ``{'primary': ..., 'editions': ...}``. Never silently English.
    """
    job_root = Path(job_root).resolve()
    source, _extra, state = requested_languages(job_root)
    if state is None:
        return {'primary': {'status': 'not_requested'}, 'editions': {'status': 'not_requested', 'editions': {}}}
    render_dir = job_root / 'render'
    final = next((p for p in (render_dir / (job_root.name + '-final-broll.mp4'),
                              render_dir / (job_root.name + '-final.mp4')) if p.is_file()), None)
    if final is None:
        primary = {'status': 'failed', 'language': source,
                   'error': 'No final master in render/. Render the production first.'}
    else:
        previous = (_read(_record_path(job_root), {}) or {}).get('primary') or {}
        copy = previous.get('render_copy')
        if (previous.get('status') == 'exported' and previous.get('source_master') == str(final)
                and copy and Path(copy).is_file()):
            primary = previous
        else:
            primary = render_primary_branding(job_root, final, progress=progress)
    editions = render_job_editions(job_root, progress=progress)
    return {'primary': primary, 'editions': editions}

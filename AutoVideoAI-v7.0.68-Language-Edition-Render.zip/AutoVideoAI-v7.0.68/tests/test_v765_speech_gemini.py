import json
from pathlib import Path
from types import SimpleNamespace
import pytest
from engine.speech_cards import anchor_cards, fingerprint
from engine.providers.gemini_video import selected_shots, GeminiVideoProvider, GeminiVideoPending, chat_url


def words():return [{'word':str(i),'start':float(i),'end':i+.7} for i in range(30)]


def test_cards_use_spoken_anchor_without_duration_scaling():
    row=anchor_cards({'cards':[{'text':'Pause before speaking','start_word':10,'end_word':12}]},words(),30)[0]
    assert row['start']==10 and row['end']==12.7 and row['spoken_anchor']=='10 11 12'


@pytest.mark.parametrize('first,last',[(True,2),(-1,2),(0,40),(8,1)])
def test_invalid_anchors_rejected(first,last):
    with pytest.raises(ValueError):anchor_cards({'cards':[{'text':'Test','start_word':first,'end_word':last}]},words(),30)


def test_changed_audio_invalidates_cards(tmp_path):
    audio=tmp_path/'audio';audio.write_bytes(b'first');before=fingerprint(audio,words(),'script')
    audio.write_bytes(b'changed');assert fingerprint(audio,words(),'script')!=before


def test_gemini_cap_excludes_existing_flow_requests_and_is_stable(tmp_path):
    folder=tmp_path/'flow/shots/shot_001';folder.mkdir(parents=True)
    (folder/'take.mp4.flow-request.json').write_text('{}')
    shots=[SimpleNamespace(shot_id=f'shot_{i:03}',provider='flow',accepted_take=None) for i in range(1,9)]
    assert selected_shots(tmp_path,shots,4)==['shot_002','shot_003','shot_004','shot_005']
    assert selected_shots(tmp_path,shots,0)==['shot_002','shot_003','shot_004','shot_005']
    with pytest.raises(ValueError):selected_shots(tmp_path,shots,5)


def test_uncertain_submission_cannot_submit_again(tmp_path):
    folder=tmp_path/'gemini-videos/shot_001';folder.mkdir(parents=True)
    (folder.parent/'selection.json').write_text(json.dumps({'shots':['shot_001']}))
    (folder/'request.json').write_text(json.dumps({'status':'submitting'}))
    class Session:
        _page=object()
        def start_fresh_chat(self):raise AssertionError('must not start new chat')
    provider=GeminiVideoProvider(tmp_path,session_factory=Session,close_session=lambda:None)
    with pytest.raises(GeminiVideoPending,match='uncertain'):
        provider.generate(SimpleNamespace(shot_id='shot_001'),{},{},tmp_path/'take.mp4',False)


@pytest.mark.parametrize('value',['http://gemini.google.com/app/123','https://gemini.google.com.evil/app/123','https://gemini.google.com/app','https://gemini.google.com/app/1/other'])
def test_chat_recovery_rejects_noncanonical_urls(value):assert not chat_url(value)


def test_video_transfer_failure_resumes_same_chat_without_resubmit(tmp_path,monkeypatch):
    import engine.providers.gemini_video as module
    root=tmp_path/'gemini-videos';root.mkdir();(root/'selection.json').write_text(json.dumps({'shots':['shot_001']}));calls=[]
    class Tile:
        def is_visible(self):return True
        def evaluate(self,expression):return True
    class Nodes:
        def count(self):return 1
        def nth(self,n):return Tile()
    class Page:
        url='https://gemini.google.com/app'
        def locator(self,selector):return Nodes()
        def goto(self,url,**kw):calls.append(('goto',url));self.url=url
    page=Page()
    class Send:
        def click(self,**kw):calls.append(('send',));page.url='https://gemini.google.com/app/exact123'
    class Session:
        _page=page
        def start_fresh_chat(self):calls.append(('fresh',))
        def _chat_id(self,url):return url.split('/app/')[1] if '/app/' in url else ''
        def _fill_prompt(self,prompt):pass
        def _try_resolve(self,*args,**kw):return Send()
    provider=GeminiVideoProvider(tmp_path,session_factory=Session,close_session=lambda:None)
    def failed(*args):raise RuntimeError('target closed')
    monkeypatch.setattr(provider,'_download',failed);shot=SimpleNamespace(shot_id='shot_001')
    with pytest.raises(GeminiVideoPending):provider.generate(shot,{'prompt':'Dance'},{},tmp_path/'first.mp4',False)
    saved=json.loads((root/'shot_001/request.json').read_text());assert saved['chat_url']=='https://gemini.google.com/app/exact123'
    def downloaded(session,tile,path):path.write_bytes(b'validated fixture')
    monkeypatch.setattr(provider,'_download',downloaded)
    monkeypatch.setattr(module,'video_info',lambda p:{'duration':8,'width':1280,'height':720})
    result=provider.generate(shot,{'prompt':'Dance'},{},tmp_path/'first.mp4',False)
    assert result['duration']==8
    assert len([c for c in calls if c[0]=='send'])==1 and len([c for c in calls if c[0]=='fresh'])==1
    assert ('goto','https://gemini.google.com/app/exact123') in calls


def test_clean_master_has_no_audio_and_finishing_reuses_it(ffmpeg_media,tmp_path):
    from engine.render.ffmpeg_renderer import render_ffmpeg
    from engine.production import probe,digest
    from engine.finishing_studio import create_plan,save_profile
    root=tmp_path/'job';render=root/'render';render.mkdir(parents=True)
    output=render/'job-final.mp4';clean=render/'visual-master.mp4'
    render_ffmpeg([{'src':ffmpeg_media['video'],'in':0,'dur':4,'hard_cut':True}],ffmpeg_media['voice'],str(output),
                  render_dir=str(render),W=320,H=240,quality='preview',clean_master_path=str(clean),music=ffmpeg_media['music'])
    assert clean.is_file() and not any(s['codec_type']=='audio' for s in probe(clean)['streams'])
    assert any(s['codec_type']=='audio' for s in probe(output)['streams'])
    profile=save_profile('Test channel',root=tmp_path/'profiles')
    plan_path=create_plan(output,profile,output_root=tmp_path/'editions')
    assert json.loads(plan_path.read_text())['source']['sha256']==digest(clean)

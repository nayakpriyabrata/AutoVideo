"""Safe recovery when Flow rotates a pending video's tile fingerprint."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json

import pytest

from engine.providers.flow_browser import FlowBrowserProvider, FlowRequestPending, FlowUIChanged


PROJECT_URL = "https://flow.google.com/project/saved-project"
BASELINE = [
    "IMG|https://media.google/still-one|still|image|320|180",
    "IMG|https://media.google/still-two|still|image|320|180",
]
OLD_VIDEO = "VIDEO|https://media.google/old-video-url|preview|video|320|180"
NEW_VIDEO = "VIDEO|https://media.google/new-video-url|preview|video|320|180"


def _provider(tmp_path, assets, *, allow_download=False):
    class _Bridge:
        _page = SimpleNamespace(wait_for_timeout=lambda _ms: None)

        def __init__(self):
            self.downloads = []

        def ensure_project(self, _project, project_url=None):
            assert project_url == PROJECT_URL

        def media_assets(self):
            return list(assets)

        def download_latest_asset(self, out_path, preferred_signature=None, before_signatures=None):
            self.downloads.append((preferred_signature, set(before_signatures or set())))
            if not allow_download:
                raise FlowUIChanged(
                    "The recorded asset is not visible; refusing to download a different tile")
            assert preferred_signature == NEW_VIDEO
            Path(out_path).write_bytes(b"validated-video")
            return out_path

    bridge = _Bridge()
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    provider.bridge = bridge
    provider._ensure = lambda: bridge
    provider._asset_valid = lambda path, kind: (
        kind == "video" and Path(path).is_file()
        and Path(path).read_bytes() == b"validated-video")
    provider._generate_video_once = lambda *_a, **_k: (_ for _ in ()).throw(
        AssertionError("pending recovery must never submit another generation"))

    shot = SimpleNamespace(shot_id="shot_001", model="omni_draft")
    compiled = {"prompt": "exact pending video prompt", "project": "Flow job",
                "project_url": PROJECT_URL, "flow_image_signature_wait_ms": 0}
    request_hash = hashlib.sha256(json.dumps(
        ["video", shot.shot_id, compiled["prompt"], True], sort_keys=True
    ).encode()).hexdigest()
    output = tmp_path / "take.mp4"
    journal = Path(str(output) + ".flow-request.json")
    journal.write_text(json.dumps({
        "status": "pending", "kind": "video", "project_url": PROJECT_URL,
        "baseline": BASELINE, "signature": OLD_VIDEO,
        "request_hash": request_hash,
    }), encoding="utf-8")
    return provider, bridge, shot, compiled, output, journal


def _asset(signature, kind):
    return {"sig": signature, "kind": kind}


def test_resume_refreshes_stale_video_signature_only_with_complete_baseline_and_one_fresh_video(tmp_path):
    assets = [
        _asset(BASELINE[0], "image"),
        _asset(BASELINE[1], "image"),
        _asset(NEW_VIDEO, "video"),
    ]
    provider, bridge, shot, compiled, output, journal = _provider(
        tmp_path, assets, allow_download=True)

    result = provider._guarded_generation_once(
        shot, compiled, {}, str(output), True, False, "video")

    saved = json.loads(journal.read_text(encoding="utf-8"))
    assert result["path"] == str(output)
    assert saved["status"] == "downloaded"
    assert saved["signature"] == NEW_VIDEO
    refresh = saved["signature_refresh_history"][-1]
    assert refresh["method"] == "unique_fresh_video_with_complete_baseline"
    assert refresh["previous_signature_sha256"] == hashlib.sha256(
        OLD_VIDEO.encode("utf-8")).hexdigest()
    assert bridge.downloads == [(NEW_VIDEO, set(BASELINE))]
    assert output.read_bytes() == b"validated-video"


@pytest.mark.parametrize("case", ["multiple_fresh_videos", "incomplete_baseline"])
def test_resume_does_not_refresh_stale_signature_when_asset_identity_is_ambiguous(
        tmp_path, case):
    assets = [_asset(BASELINE[0], "image")]
    if case == "multiple_fresh_videos":
        assets.extend([
            _asset(BASELINE[1], "image"),
            _asset(NEW_VIDEO, "video"),
            _asset("VIDEO|https://media.google/another-video|preview|video|320|180", "video"),
        ])
    else:
        # One new video is not enough if any saved pre-request tile is missing.
        assets.append(_asset(NEW_VIDEO, "video"))
    provider, bridge, shot, compiled, output, journal = _provider(tmp_path, assets)

    with pytest.raises(FlowRequestPending, match="Generation is blocked to avoid spending again"):
        provider._guarded_generation_once(
            shot, compiled, {}, str(output), True, False, "video")

    saved = json.loads(journal.read_text(encoding="utf-8"))
    assert saved["signature"] == OLD_VIDEO
    assert "signature_refresh_history" not in saved
    # The only attempted download remains bound to the recorded fingerprint.
    assert bridge.downloads == [(OLD_VIDEO, set(BASELINE))]
    assert not output.exists()


def test_exact_recorded_video_wins_even_when_a_new_video_is_also_visible(tmp_path):
    assets = [
        _asset(BASELINE[0], "image"),
        _asset(BASELINE[1], "image"),
        _asset(OLD_VIDEO, "video"),
        _asset(NEW_VIDEO, "video"),
    ]
    provider, bridge, shot, compiled, output, journal = _provider(tmp_path, assets)

    with pytest.raises(FlowRequestPending):
        provider._guarded_generation_once(
            shot, compiled, {}, str(output), True, False, "video")

    saved = json.loads(journal.read_text(encoding="utf-8"))
    assert saved["signature"] == OLD_VIDEO
    assert "signature_refresh_history" not in saved
    assert bridge.downloads == [(OLD_VIDEO, set(BASELINE))]

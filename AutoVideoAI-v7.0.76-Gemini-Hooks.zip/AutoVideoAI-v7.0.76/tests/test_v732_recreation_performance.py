import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest


def test_gallery_and_agent_previews_of_same_image_complete_once(monkeypatch):
    import engine.providers.flow_browser as module
    from tests.test_v609_flow_video_typed_recovery import _Clock,_wait_browser
    clock=_Clock();monkeypatch.setattr(module,'time',clock)
    a='IMG|https://flow.google.com/media/00000000-0000-4000-8000-000000000001|gallery|image|250|200'
    b=a.replace('|gallery|image|250|200','|Agent|image|180|120')
    browser=_wait_browser(clock,lambda:[{'sig':a,'kind':'image'},{'sig':b,'kind':'image'}])
    assert browser.wait_for_agent_generation(before_assets=set(),timeout_s=360,required_kind='image')
    assert clock.now < 10 and browser.last_generated_asset_signature==a


def test_distinct_idle_images_go_to_correlation_without_six_minute_wait(monkeypatch):
    import engine.providers.flow_browser as module
    from tests.test_v609_flow_video_typed_recovery import _Clock,_wait_browser
    clock=_Clock();monkeypatch.setattr(module,'time',clock)
    browser=_wait_browser(clock,lambda:[{'sig':'one','kind':'image'},{'sig':'two','kind':'image'}])
    assert not browser.wait_for_agent_generation(before_assets=set(),timeout_s=360,required_kind='image')
    assert 30 <= clock.now < 40 and browser.last_generated_asset_signature is None


def test_broll_picture_edit_inherits_only_hash_bound_transcript(tmp_path):
    from engine.clip_recreation import inherit_clip_transcript,_transcript_record
    from engine.production import save,digest
    source=tmp_path/'clip.mp4';source.write_bytes(b'original footage')
    output=tmp_path/'clip-broll.mp4';output.write_bytes(b'changed picture same speech')
    save(source.with_suffix('.transcript.json'),{'clip_sha256':digest(source),'text':'Reviewed speech','words':[]})
    assert inherit_clip_transcript(source,output)
    assert _transcript_record(output)[0]=='Reviewed speech'
    source.write_bytes(b'replaced input')
    assert not inherit_clip_transcript(source,tmp_path/'missing.mp4')
    output.write_bytes(b'changed output')
    with pytest.raises(ValueError,match='Draft its transcript'):_transcript_record(output)


def test_production_fifty_slots_are_nonoverlapping_and_scene_contextual():
    from engine.broll import _job_slots
    shots=[NS(shot_id=f'shot_{i}',voice_start=i*90,voice_end=(i+1)*90,
        narration='Technology tools' if i==0 else 'Financial savings',visual_goal='context',stock_query='',subject='',environment='',provider='image',actual_provider='image') for i in range(2)]
    f=NS(pm=NS(load_manifest=lambda _:NS(shots=shots,aspect='16:9')))
    slots,vertical=_job_slots(f,'job',50,2)
    assert len(slots)==50 and not vertical
    assert all(a['start']+a['duration']<=b['start'] for a,b in zip(slots,slots[1:]))
    assert 'technology' in slots[0]['query'] and 'financial' in slots[-1]['query']


def test_auto_broll_skips_missing_and_changed_assets(tmp_path,monkeypatch):
    import engine.broll as m
    video=tmp_path/'valid.mp4';video.write_bytes(b'valid')
    changed=tmp_path/'changed.mp4';changed.write_bytes(b'changed')
    report=tmp_path/'review.json'
    report.write_text(json.dumps({'schema_version':1,'workflow':'production','candidates':[
        {'candidate_id':'valid','path':str(video),'sha256':m.sha256_file(video),'start':0,'duration':2,'timeline_duration':10},
        {'candidate_id':'changed','path':str(changed),'sha256':'old','start':3,'duration':2},
        {'candidate_id':'missing','path':'','sha256':''}]}))
    monkeypatch.setattr(m,'_file_duration',lambda p:10)
    monkeypatch.setattr(m,'_file_dimensions',lambda p:(1920,1080))
    with pytest.raises(ValueError):m.auto_select_production_review(report)
    result=m.auto_select_production_review(report,source_permission=True)
    assert [c['decision'] for c in result['candidates']]==['approved','skipped','skipped']
    assert m.validate_review_decisions(str(report),workflow='production')


def test_character_card_opens_original_photo_details_and_edit(tmp_path,monkeypatch):
    from PIL import Image
    import engine.content_library as m
    from tests.test_presentation_dashboard import dashboard,navigate
    photo=tmp_path/'face.png';Image.new('RGB',(100,200),'orange').save(photo)
    library=m.CharacterLibrary(tmp_path/'characters')
    library.create('Aradhya','Original cheerful host.',reference_files=[str(photo)],original_confirmed=True)
    monkeypatch.setattr(m,'CharacterLibrary',lambda *a,**kw:library)
    _,app=dashboard(tmp_path,monkeypatch);navigate(app,'CHARACTER LIBRARY')
    next(b for b in app.button if b.label=='Aradhya').click().run()
    assert not app.exception
    assert any(b.label=='Save character changes' for b in app.button)
    assert any(x.value=='Original cheerful host.' for x in app.text_area)


def test_recreation_missing_transcript_is_explained_before_launch(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard,navigate
    import engine.content_library as m
    library=m.CharacterLibrary(tmp_path/'characters')
    library.create('Aanya','Original friendly host.',original_confirmed=True)
    monkeypatch.setattr(m,'CharacterLibrary',lambda *a,**kw:library)
    _,app=dashboard(tmp_path,monkeypatch);navigate(app,'AI RECREATE')
    next(x for x in app.radio if x.label=='Recreation source').set_value('Local video file').run()
    clip=tmp_path/'local.mp4';clip.write_bytes(b'local')
    next(x for x in app.text_input if x.label.startswith('Local video path')).set_value(str(clip)).run()
    assert not app.exception
    assert any('Prepare speech first' in x.value for x in app.info)
    assert next(x for x in app.button if x.label=='Review video + propose recreation scenes').disabled
    assert next(x for x in app.button if x.label=='Create recreation storyboard — no generation').disabled
    assert any(x.label=='Draft English transcript from video' for x in app.button)

from pathlib import Path
import json
import pytest
from engine.providers.flow_browser import FlowBrowserProvider, FlowRequestPending


def test_unreadable_gallery_stops_rescans_and_does_not_replace(tmp_path, monkeypatch):
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    frame = tmp_path / 'shot_001_open.jpg'
    journal = Path(str(frame) + '.flow-request.json')
    journal.write_text(json.dumps({
        'project_url': 'https://flow.google.com/project/recorded',
        'correlation_probe': {
            'fresh_candidates': 2, 'unreadable_prompts': 2,
            'readable_prompts': 0,
        },
        'status': 'pending',
    }))
    calls = []
    def pending(*args, **kwargs):
        calls.append('attempt')
        raise FlowRequestPending('Ambiguous gallery asset')
    provider._guarded_generation_once = pending
    monkeypatch.setattr('engine.flow_image_replacement.replace_image',
                        lambda *args, **kwargs: pytest.fail('Must not regenerate'))
    class Shot:
        shot_id = 'shot_001'
    with pytest.raises(FlowRequestPending):
        provider._guarded_generation(Shot(), {
            'flow_image_auto_recover': True,
            'flow_replace_unresolved_images': True,
        }, [], str(frame), False, False, 'image')
    assert calls == ['attempt']
    assert json.loads(journal.read_text())['status'] == 'pending'

"""Speech batches from Create step 4, shown and resumable from Jobs & Recovery (7.0.83).

A batch is prepared before a job exists. Until 7.0.83 a batch that stopped during TTS lived only in the
shared speech_preparation folder, so Jobs & Recovery could not show it, and a job that failed the script
check had no place to correct its narration. This module lists those batches, saves a corrected narration
into the approved snapshot, and resumes a batch. Finished languages are reused: voice files are cached by
script and provider, so a resume only sends the languages that are not finished.
"""
from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path

from .finishing_studio import shared_root
from .languages import language_pack
from .speech_cards import localization_key, reviewed_scripts_for


def batches_root() -> Path:
    return shared_root() / 'speech_preparation'


def _read(folder: Path) -> dict:
    return json.loads((Path(folder) / 'batch.json').read_text(encoding='utf-8'))


def _row(folder: Path, origin: str) -> dict | None:
    file = folder / 'batch.json'
    try:
        state = _read(folder)
    except (OSError, ValueError):
        return None
    editions = list(state.get('editions') or [])
    bundles = state.get('bundles') or {}
    done = [code for code in editions
            if isinstance(bundles.get(code), dict) and Path(str(bundles[code].get('audio', ''))).is_file()]
    scripts = dict(state.get('scripts') or {})
    if not scripts and state.get('source_script') and state.get('source_language') and editions:
        try:
            scripts = reviewed_scripts_for(state['source_script'], state['source_language'], editions) or {}
        except Exception:
            scripts = {}
    request = state.get('request') or {}
    stamp = _stamp(state, file)
    bundles = {code: dict(bundle) for code, bundle in bundles.items() if isinstance(bundle, dict)}
    return {
        'key': folder.name,
        'origin': origin,
        'path': str(folder),
        'source_language': state.get('source_language', ''),
        'source_script': state.get('source_script', ''),
        'editions': editions,
        'phase': state.get('phase', ''),
        'ready': state.get('phase') in ('voices_ready', 'ready_for_review') and len(done) == len(editions),
        'done': done,
        'error': state.get('error', ''),
        'scripts': scripts,
        'request': request,
        # v7.0.122: the saved characters this narration was written for, recorded when the batch was made.
        'character_ids': [str(identifier) for identifier in (request.get('character_ids') or [])],
        # v7.0.119: a batch used to be listed as "Create step 4 · English, Hindi, Odia · ready" with nothing
        # that told one session apart from another. Topic, exact time and where its voices ended up do.
        'topic': str(request.get('topic') or '').strip(),
        'created': stamp['label'],
        'created_ts': stamp['ts'],
        'bundles': bundles,
        'audio_sha256': {str(bundle.get('audio_sha256') or '') for bundle in bundles.values()
                         if bundle.get('audio_sha256')},
        'updated': file.stat().st_mtime,
    }


def _stamp(state: dict, file: Path) -> dict:
    """When this batch was made: recorded time when present, else the file's own timestamp."""
    raw = str(state.get('created_at') or state.get('saved_at') or '').strip()
    moment = None
    if raw:
        try:
            moment = datetime.datetime.fromisoformat(raw.replace('Z', '+00:00'))
        except ValueError:
            moment = None
    ts = file.stat().st_mtime
    if moment is not None:
        ts = moment.timestamp()
        return {'ts': ts, 'label': moment.astimezone().strftime('%Y-%m-%d %H:%M')}
    return {'ts': ts,
            'label': datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M')}


def list_speech_batches(job_dirs=(), limit: int = 60, include_finished=()) -> list[dict]:
    """Batches from Create step 4 (shared folder) and unfinished batches inside jobs, newest first.

    v7.0.97: ``include_finished`` names job folders whose *finished* batch must still be listed, so the
    queue can show the batch that belongs to the Active job (a plain job list only shows unfinished ones).
    Names and states only; no key values.
    """
    keep = {str(Path(folder).resolve()) for folder in include_finished if folder}
    rows = []
    root = batches_root()
    if root.is_dir():
        for folder in root.iterdir():
            if folder.is_symlink() or not (folder / 'batch.json').is_file():
                continue
            row = _row(folder, 'Create step 4')
            if row:
                rows.append(row)
    for job in job_dirs:
        folder = Path(job)
        if folder.is_symlink() or not (folder / 'batch.json').is_file():
            continue
        row = _row(folder, 'Job ' + folder.name)
        # A finished job batch is not listed unless the caller asks for that exact job.
        if row and (str(folder.resolve()) in keep or not (row['ready'] and not row['error'])):
            rows.append(row)
    rows.sort(key=lambda row: -row['updated'])
    return rows[:limit]


def partition_for_job(rows, job_dir=None):
    """Split listed batches into (this job's own batch, batches from elsewhere). 7.0.97.

    The queue panel used to list every batch of the installation, so the batch that belongs to the
    Active job was buried among sessions from earlier days.
    """
    rows = list(rows or [])
    if not job_dir:
        return rows, []
    root = Path(job_dir).resolve()
    own, others = [], []
    for row in rows:
        try:
            Path(row['path']).resolve().relative_to(root)
            own.append(row)
        except (ValueError, OSError):
            others.append(row)
    return own, others


def job_audio_shas(job_dir) -> set:
    """Voice fingerprints a job already holds, read from its own saved snapshots (no hashing)."""
    root = Path(job_dir)
    shas = set()
    for name, key in (('production/prepared_speech.json', None),
                      ('production/language_editions.json', 'bundles')):
        path = root / name
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            continue
        records = [data] if key is None else list((data.get(key) or {}).values())
        for record in records:
            if isinstance(record, dict) and record.get('audio_sha256'):
                shas.add(str(record['audio_sha256']))
    return shas


def job_stage(job_dir) -> dict:
    """What a saved job already has, so a stopped TTS run can be judged against it (v7.0.121)."""
    root = Path(job_dir)
    try:
        manifest = json.loads((root / 'production_manifest.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        manifest = {}
    from . import narration_assets
    voices = narration_assets.voices(root)
    return {'status': str(manifest.get('status') or ''),
            'shots': len(manifest.get('shots') or []),
            'narrated': bool(voices), 'voices': [row['label'] for row in voices],
            'prepared': (root / 'production' / 'prepared_speech.json').is_file()}


def stale_reason(row, job_dirs=()) -> str:
    """Why this stopped batch is no longer on the way to a video, or '' when it still is.

    A Create step 4 batch that stopped during TTS and lives inside a job is listed for ever otherwise: the
    job can finish with other voices (or its own narration), and the abandoned run keeps asking to be resumed.
    Nothing is deleted - the batch is only described truthfully and moved out of the to-do list.
    """
    origin = str(row.get('origin') or '')
    if not origin.startswith('Job ') or row.get('ready'):
        return ''
    job_id = origin[4:]
    folder = next((Path(job) for job in job_dirs if Path(job).name == job_id), None)
    if folder is None or not folder.is_dir():
        return ''
    stage = job_stage(folder)
    if stage['shots'] or stage['status'] in ('narrated', 'planned', 'generating', 'review', 'rendering', 'done'):
        narrated = (' Its narration is already saved (' + ' · '.join(stage['voices']) + ').'
                    if stage['narrated'] else '')
        return ('This job is already past narration (status "' + (stage['status'] or 'planned') + '", '
                + str(stage['shots']) + ' scene(s) planned).' + narrated + ' This stopped TTS run is not needed '
                'to resume the job; it is kept here, nothing was deleted. Use “Resume / continue job” on the job '
                'itself.')
    return ''


def with_attachments(rows, job_dirs=()) -> list[dict]:
    """Say which job (if any) already contains each batch's voices (v7.0.119).

    A batch prepared in Create step 4 is *not* a job: until it is attached, there is nothing to Resume, and
    its voices live only in the shared folder. The list used to leave that out entirely, so prepared narration
    looked like a job that had lost its audio.
    """
    owners = {}
    for job in job_dirs:
        folder = Path(job)
        if not folder.is_dir():
            continue
        for sha in job_audio_shas(folder):
            owners.setdefault(sha, set()).add(folder.name)
    rows = list(rows or [])
    for row in rows:
        attached = set()
        for sha in row.get('audio_sha256') or set():
            attached |= owners.get(sha, set())
        row['attached_to'] = sorted(attached)
        row['attached'] = bool(attached)
        row['stale_reason'] = stale_reason(row, job_dirs)
        row['stale'] = bool(row['stale_reason'])
    return rows


def actionable(rows) -> list[dict]:
    """Batches that are still the way to a video: ready to use, or stopped for a reason worth fixing."""
    return [row for row in rows or [] if not row.get('stale')]


def usable_now(rows) -> list[dict]:
    """Ready batches whose voices no job holds yet, newest first: the ones a job can be made from."""
    ready = [row for row in rows or [] if row.get('ready') and not row.get('attached') and not row.get('stale')]
    return sorted(ready, key=lambda row: -(row.get('created_ts') or 0))


def pickable(rows) -> list[dict]:
    """Every ready batch a job can be made from, newest first, unused ones before copies (v7.0.122).

    ``usable_now`` answers "what is still waiting for a job" and hides a batch as soon as one job holds its
    voices. That is the wrong question for the picker: a finished narration whose voices were already copied
    into one job is still prepared narration you may want for a second video, and hiding it made the picker
    look as if only the newest session existed. They are listed after the unused ones, never instead of them.
    """
    ready = [row for row in rows or [] if row.get('ready') and not row.get('stale')]
    return sorted(ready, key=lambda row: (bool(row.get('attached')), -(row.get('created_ts') or 0)))


def display_label(row, *, newest=False) -> str:
    """One identifying line for a batch: time, topic, languages, state, and whether a job holds it."""
    parts = [row.get('origin') or 'Create step 4', row.get('created') or 'time not recorded']
    if row.get('topic'):
        parts.append('"' + row['topic'][:60] + '"')
    parts.append(', '.join(language_label(code) for code in row.get('editions') or []))
    state = 'ready' if row.get('ready') else ('stopped' if row.get('error') else (row.get('phase') or 'pending'))
    parts.append(state + ' · voices ' + str(len(row.get('done') or [])) + '/' + str(len(row.get('editions') or [])))
    owner = row.get('origin') or ''
    if row.get('attached'):
        parts.append('voices in job ' + ', '.join(row['attached_to']))
    elif owner.startswith('Job '):
        # This batch lives inside that job already; only the copied voices are missing.
        parts.append('saved in ' + owner[4:] + ' · voices not copied into the job yet')
    else:
        parts.append('not part of any job yet')
    if newest:
        parts.append('newest')
    return ' · '.join(parts)


def correct_speech_scripts(folder, edited: dict, approvals: dict) -> dict:
    """Save corrected narration for a batch and the approved snapshot shared with Create and jobs (7.0.83).

    The check is the same as Create step 4 (words outside the language's script are refused). The master
    script is not edited here. Corrected batches lose their voice files until resumed, so an old voice file
    for the old text can never be attached.
    """
    from .production import save
    from .speech_cards import approve_localized_scripts
    folder = Path(folder)
    state = _read(folder)
    editions = list(state['editions'])
    source = state['source_language']
    master = state['source_script']
    key = localization_key(master, source, editions)
    snapshot_dir = batches_root() / 'scripts' / key
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    snapshot = {'fingerprint': key, 'source_language': source, 'source_script': master, 'editions': editions}
    edited = dict(edited or {})
    approvals = dict(approvals or {})
    edited[source] = master
    approvals[source] = True
    result = approve_localized_scripts(snapshot_dir, snapshot, edited, approvals)
    scripts = {code: str(result['scripts'][code]).strip() for code in editions}
    state.update(scripts=scripts,
                 scripts_sha256=hashlib.sha256(json.dumps(scripts, sort_keys=True, ensure_ascii=False).encode()).hexdigest(),
                 bundles={}, phase='scripts_corrected', error='')
    save(folder / 'batch.json', state)
    return scripts


def resume_speech_batch(folder, *, provider=None, progress=None) -> dict:
    """Continue a batch with its saved scripts and settings. Finished voices are reused (7.0.83)."""
    from .speech_cards import prepare_batch
    folder = Path(folder)
    state = _read(folder)
    editions = list(state['editions'])
    scripts = dict(state.get('scripts') or {})
    if not scripts:
        scripts = reviewed_scripts_for(state['source_script'], state['source_language'], editions) or {}
    if not scripts:
        raise ValueError('This batch has no saved narration. Open Create step 4 and prepare the language scripts again.')
    request = dict(state.get('request') or {})
    chosen = provider if provider is not None else request.get('provider', 'auto')
    audio = str(request.get('audio_path') or '')
    audio_path = audio if audio and Path(audio).is_file() else None
    return prepare_batch(
        folder, state['source_script'], state['source_language'], editions,
        draft_cards=request.get('draft_cards', True),
        provider=chosen, audio_path=audio_path, cleanup=request.get('cleanup', 'delete-after-read'),
        progress=progress, localized_scripts=scripts, text_cards=request.get('text_cards', True),
        educational=request.get('educational', False), topic=request.get('topic', ''),
        card_provider=request.get('card_provider', 'gemini-web'), hooks=request.get('hooks', False),
        character_ids=request.get('character_ids') or None)


def language_label(code: str) -> str:
    return language_pack(code).label

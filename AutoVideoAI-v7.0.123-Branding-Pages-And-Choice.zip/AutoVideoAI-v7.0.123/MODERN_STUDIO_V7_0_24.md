# AutoVideoAI 7.0.24 · Modern Studio

The WSL Studio and private control center now share a cleaner indigo and slate interface, clearer typography, compact cards, and responsive layouts. Guided Studio starts with your topic, video format, duration, and generation profile. Optional script review, cast, imports, and advanced controls are expandable. All existing production workspaces remain available in the sidebar.

## Upgrade

Stop running Studio and CLI jobs. Extract this build into a fresh folder, then run from the new folder:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.23 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.23 . --apply
python3 -m streamlit run app.py
```

Replace the old folder name with your actual installation. The first command previews migration. The second copies saved outputs, settings, and character references and rebases local paths. Review migration warnings before resuming. The upgrade does not alter the old installation.

## UI fixes

- Reels changes duration defaults immediately, outside the submit-only form. Each production mode keeps its own duration choice.
- Script drafting uses the current topic and duration instead of a separate stale review topic.
- Editing the reviewed JSON, topic, or language clears script approval so changed content must be reviewed again.
- Clip-only controls stay enabled only for their selected task, including after switching modes or loading drafts.
- Clip music file paths survive saving and reopening drafts.
- Existing TTS settings load safely; current supported providers remain selectable.
- Cleanup timeouts, failed commands, and invalid reports display an error instead of crashing Settings.
- Failed or paused production no longer forces the progress bar to 100%.
- Audio and branding edits, clip music, and logos remain optional and expandable.
- Keyboard focus, contrast, and small-screen spacing are improved. Media previews remain compact.

## Validation scope

Automated engine regressions and browserless control-center interaction tests cover configuration, drafts, job dispatch approvals, exact saved-job resume/recovery, and logs. Streamlit interaction testing checks all 19 pages and reactive production controls without calling providers. Live WSL Google Flow/Gemini recovery and browser visual layout remain to be verified on your machine. This release improves the UI; it does not guarantee that external generation services cannot fail.

Automatic safe worker cleanup from 7.0.23 is retained. Settings → Disk cleanup can preview and apply eligible cleanup. Final videos, accepted media, characters, primary login profiles, and unfinished request journals remain protected.

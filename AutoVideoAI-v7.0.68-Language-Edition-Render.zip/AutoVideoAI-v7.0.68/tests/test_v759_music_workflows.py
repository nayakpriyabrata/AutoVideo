import hashlib
import json
import math
from pathlib import Path
import struct
import shutil
import subprocess
import wave

import pytest

from engine.audio import music_library, music_provider
from engine.audio.music_brief import draft_music_brief


def audio_bytes(path):
    with wave.open(str(path),'wb') as handle:
        handle.setnchannels(1);handle.setsampwidth(2);handle.setframerate(16000)
        samples=(struct.pack('<h',int(5000*math.sin(i/10))) for i in range(32000))
        handle.writeframes(b''.join(samples))
    return path.read_bytes()


def test_import_and_theme_selection_with_provenance(tmp_path):
    folder=tmp_path/'shared-music';data=audio_bytes(tmp_path/'song.wav')
    confidence=music_library.import_track(data,'song.wav','Hope','motivation confidence',
        'https://commons.wikimedia.org/wiki/File:Hope.ogg','CC0',folder)
    assert Path(confidence['path']).exists()
    assert music_library.select_theme('a self-confidence story',folder)['title']=='Hope'
    assert music_library.select_theme('an underwater documentary',folder) is None
    assert music_library.list_tracks(folder)[0]['sha256']==hashlib.sha256(data).hexdigest()
    assert json.loads((folder/'manifest.json').read_text())['tracks'][0]['license']=='CC0'
    Path(confidence['path']).write_bytes(b'changed')
    with pytest.raises(ValueError,match='changed after review'):
        music_library.select_theme('confidence',folder)


def test_local_provider_prefers_reviewed_theme_and_keeps_rights_metadata(tmp_path,monkeypatch):
    folder=tmp_path/'library';data=audio_bytes(tmp_path/'track.wav')
    row=music_library.import_track(data,'track.wav','Gentle rain','calm nature rain',
        'https://commons.wikimedia.org/wiki/File:Gentle.ogg','CC0',folder)
    monkeypatch.setattr(music_library,'root',lambda:folder)
    result=music_provider.ensure_background_music('rainy forest story',str(tmp_path),mode='local')
    assert result['path']==row['path'] and result['source']=='reviewed-shared-library'
    assert result['license']=='CC0' and result['page_url'].startswith('https://commons.wikimedia.org/')


def test_gemini_music_draft_is_text_only_and_reviewable(monkeypatch):
    from engine.providers import gemini_web
    sent=[]
    monkeypatch.setattr(gemini_web,'gemini_web_generate',lambda system,user,**kw:
        sent.append((system,user,kw)) or json.dumps({'music_prompt':'Instrumental piano pulses and a quiet string counterline for a changing scene; increase energy near the middle, settle at the end.',
        'opening_hook':'three ascending notes','section_plan':['intro','turn','resolution'],
        'lyric_draft':'','search_mood':'calm cinematic'}))
    result=draft_music_brief('Confidence','cinematic','en','background',90)
    assert result['opening_hook']=='three ascending notes'
    assert 'no speech or singing' in sent[0][1]
    assert sent[0][2]['cleanup']=='delete-after-read'


def test_existing_video_gets_separate_music_copy(tmp_path,monkeypatch):
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        pytest.skip('FFmpeg required')
    from engine.audio.music_overlay import add_music_copy
    song=tmp_path/'song.wav';data=audio_bytes(song);folder=tmp_path/'library'
    row=music_library.import_track(data,song.name,'Theme','motivation confidence',
        'https://commons.wikimedia.org/wiki/File:Theme.ogg','CC0',folder)
    monkeypatch.setattr(music_library,'root',lambda:folder)
    source=tmp_path/'original.mp4'
    subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=320x180:r=24:d=2',
        '-f','lavfi','-i','sine=frequency=800:duration=2','-map','0:v','-map','1:a',
        '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(source)],check=True)
    original=hashlib.sha256(source.read_bytes()).hexdigest()
    output=Path(add_music_copy(source,row['path']))
    assert output!=source and output.is_file() and source.is_file()
    assert hashlib.sha256(source.read_bytes()).hexdigest()==original
    assert add_music_copy(source,row['path'])==str(output)

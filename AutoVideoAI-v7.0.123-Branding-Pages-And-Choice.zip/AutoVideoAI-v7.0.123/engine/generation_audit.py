"""Report storyboard substitutions as well as final motion substitutions."""
import json
from pathlib import Path


def frame_fallbacks(root, shots, frame_source='auto'):
    if frame_source == 'free':
        return []
    found = {}
    for shot in shots:
        for phase in ('opening', 'closing'):
            source = str(getattr(shot, phase + '_frame_source', '') or '')
            if source in ('free', 'image', 'local-opening-fallback'):
                key = (shot.shot_id, phase + ' frame')
                found[key] = {'shot_id':key[0], 'label':key[1], 'actual':source}
    try:
        rows = json.loads((Path(root) / 'generation_log.json').read_text())
    except (OSError, ValueError):
        rows = []
    for row in rows:
        event = row.get('event')
        if event in ('master_location', 'master_character') and row.get('source') == 'free':
            label = event.replace('master_', '') + ' master'
            if not any(k[1] == label for k in found):
                found[('', label)] = {'shot_id':'', 'label':label, 'actual':'free'}
    from .production import digest
    for receipt in Path(root).rglob('*.free-image.json'):
        try:
            row = json.loads(receipt.read_text())
            path = receipt.with_name(receipt.name[:-len('.free-image.json')])
            if path.is_file() and digest(path) == row['sha256']:
                key = (row.get('shot_id', ''), row.get('label', 'image'))
                if key[1].endswith(' master'):
                    for old in list(found):
                        if old[1] == key[1]: del found[old]
                found[key] = {'shot_id':key[0], 'label':key[1], 'actual':'free'}
        except (OSError, ValueError, KeyError, TypeError):
            continue
    return list(found.values())

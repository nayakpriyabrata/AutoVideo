import hashlib
import json
from pathlib import Path
import pytest
from PIL import Image


def review(tmp_path):
    from engine.broll import _write_json, sha256_file
    path=tmp_path/'review.json';asset=tmp_path/'asset.mp4';asset.write_bytes(b'asset')
    rows=[{'candidate_id':f'c{i}','clip_output':f'clip{i//10}.mp4','path':str(asset),
           'sha256':sha256_file(asset),'clip_duration':60,'start':i%10*4,'duration':2,
           'decision':'pending'} for i in range(50)]
    _write_json(path,{'schema_version':1,'workflow':'clip_studio','review_id':'test','candidates':rows})
    return str(path),rows


def test_fifty_insert_approvals_are_one_explicit_exact_file_batch(tmp_path):
    from engine.broll import save_batch_decisions,validate_review_decisions
    path,rows=review(tmp_path)
    saved=save_batch_decisions(path,[r['candidate_id'] for r in rows],'approve',rights_confirmed=True,
          expected_review_id='test',expected_hashes={r['candidate_id']:r['sha256'] for r in rows})
    assert len([r for r in saved['candidates'] if r['approved'] and r['rights_reviewed']])==50
    assert len(saved['batch_decisions'])==1
    validate_review_decisions(path,workflow='clip_studio')


def test_batch_requires_confirmation_and_rejects_replaced_suggestions(tmp_path):
    from engine.broll import save_batch_decisions
    path,rows=review(tmp_path);before=Path(path).read_bytes()
    with pytest.raises(ValueError,match='Confirm'):
        save_batch_decisions(path,['c0'],'approve',expected_review_id='test')
    with pytest.raises(ValueError,match='changed'):
        save_batch_decisions(path,['c0'],'approve',rights_confirmed=True,expected_review_id='old')
    with pytest.raises(ValueError,match='changed'):
        save_batch_decisions(path,['c0'],'approve',rights_confirmed=True,expected_review_id='test',expected_hashes={'c0':'other'})
    assert Path(path).read_bytes()==before


def test_batch_skips_changed_assets_and_preserves_other_clip_decisions(tmp_path):
    from engine.broll import save_batch_decisions
    path,rows=review(tmp_path);Path(rows[0]['path']).write_bytes(b'changed')
    saved=save_batch_decisions(path,['c0'],'approve',rights_confirmed=True,
          expected_review_id='test',expected_hashes={'c0':rows[0]['sha256']})
    assert saved['candidates'][0]['decision']=='skipped' and not saved['candidates'][0]['approved']
    assert saved['candidates'][10]['decision']=='pending'


def test_batch_approves_available_assets_and_skips_unavailable_slots(tmp_path):
    from engine.broll import _write_json, save_batch_decisions, sha256_file, validate_review_decisions
    path = tmp_path / 'mixed-review.json'
    asset = tmp_path / 'candidate.mp4'
    asset.write_bytes(b'exact available asset')
    digest = sha256_file(asset)
    rows = [{
        'candidate_id': f'ready-{index}', 'status': 'ready', 'path': str(asset),
        'sha256': digest, 'clip_duration': 120, 'start': index * 3, 'duration': 2,
        'decision': 'pending', 'approved': False, 'rights_reviewed': False,
    } for index in range(40)]
    rows.extend({
        'candidate_id': f'missing-{index}', 'status': 'not_found', 'path': '',
        'search_error': 'Duplicate asset rejected: reuse limit or scene context differs.',
        'decision': 'pending', 'approved': False, 'rights_reviewed': False,
    } for index in range(80))
    _write_json(path, {
        'schema_version': 1, 'workflow': 'clip_studio', 'review_id': 'mixed',
        'candidates': rows,
    })

    saved = save_batch_decisions(
        path, [row['candidate_id'] for row in rows], 'approve', rights_confirmed=True,
        expected_review_id='mixed',
        expected_hashes={row['candidate_id']: row['sha256'] for row in rows if row.get('sha256')},
    )

    assert sum(row['decision'] == 'approved' for row in saved['candidates']) == 40
    assert sum(row['decision'] == 'skipped' for row in saved['candidates']) == 80
    validate_review_decisions(path, workflow='clip_studio')


def test_disabled_logo_ignores_old_path_and_enabled_logo_validates(tmp_path):
    from engine.clip_branding import validate_clip_logo,prepare_clip_logo,clip_logo_path
    assert validate_clip_logo(False,'missing') is None
    assert prepare_clip_logo(None,tmp_path,320,180)=={}
    with pytest.raises(ValueError):validate_clip_logo(True,'missing')
    image=tmp_path/'logo.png';Image.new('RGBA',(50,50),'red').save(image)
    branding=prepare_clip_logo(validate_clip_logo(True,str(image),.2,'top-right'),tmp_path/'work',320,180)
    with Image.open(branding['overlay_path']) as im:
        assert im.size==(320,180)
        assert im.getpixel((300,12))[0]>200 and im.getpixel((50,50))[3]==0
    assert clip_logo_path(branding)==branding['overlay_path']
    Path(branding['overlay_path']).write_bytes(b'changed')
    with pytest.raises(ValueError,match='changed'):clip_logo_path(branding)


@pytest.mark.parametrize("with_music", [False,True])
def test_real_highlight_and_broll_renders_retain_optional_logo(tmp_path,ffmpeg_media,monkeypatch,with_music):
    import subprocess,numpy as np
    import engine.clipping as c
    from engine.broll import _render_clip_studio_cutaway
    logo=tmp_path/'logo.png';Image.new('RGBA',(60,60),'red').save(logo)
    source=tmp_path/'source-with-voice.mp4'
    subprocess.run(['ffmpeg','-y','-v','error','-i',ffmpeg_media['video'],'-i',ffmpeg_media['voice'],'-c:v','copy','-c:a','aac','-shortest',str(source)],check=True)
    monkeypatch.setattr(c,'_transcribe_in_chunks',lambda *a,**k:[{'word':'Meaningful','start':.5,'end':1}, {'word':'moment','start':1,'end':2}])
    monkeypatch.setattr(c,'rank_highlights',lambda *a,**k:[{'start':0,'end':4,'duration':4,'title':'A useful moment','text':'Meaningful moment','score':90}])
    result=c.create_highlight_clips(str(source),str(tmp_path/'clips'),count=1,min_seconds=1,max_seconds=5,
          framing='fit',ranking_provider='local',background_music_enabled=with_music,
          background_music=ffmpeg_media['music'] if with_music else '',background_music_source='local',
          show_channel_logo=True,channel_logo_path=str(logo),channel_logo_size=.2)
    h=result['highlights'][0];assert not h.get('render_error'),h
    original=h['output'];branding=h['branding'];assert branding['enabled']
    output=_render_clip_studio_cutaway({'candidate_id':'combined','source_video':str(source),
        'clip_output':original,'path':ffmpeg_media['video'],'caption_ass_path':h['caption_ass_path'],
        'source_start':0,'clip_duration':4,'start':1,'duration':1,'framing':'fit','branding':branding})
    for path in [original,output]:
        raw=subprocess.run(['ffmpeg','-v','error','-ss','1.5','-i',path,'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True).stdout
        frame=np.frombuffer(raw,dtype=np.uint8).reshape(180,320,3)
        red=frame[10:20,295:305].mean(axis=(0,1))
        assert red[0]>180 and red[1]<80 and red[2]<80
    assert output!=original and Path(original).exists()
    for path in [original,output]:
        audio=subprocess.run(['ffprobe','-v','error','-select_streams','a','-show_entries','stream=codec_type','-of','csv=p=0',path],capture_output=True,text=True,check=True)
        assert 'audio' in audio.stdout


def test_clip_studio_batch_controls_and_preview_pagination(tmp_path,monkeypatch):
    from streamlit.testing.v1 import AppTest
    from engine.factory import Factory
    import engine.factory as factory_module,engine.project.database as db_module
    from engine.broll import load_review
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'jobs.db'))
    monkeypatch.setattr(factory_module,'Factory',lambda *a,**k:f)
    monkeypatch.setattr(db_module,'JobDB',lambda *a,**k:f.db)
    path,rows=review(tmp_path)
    app=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py'),default_timeout=30).run()
    next(w for w in app.sidebar.selectbox if w.label=='Workspace').set_value('Content & Delivery').run()
    next(w for w in app.sidebar.radio if w.label=='Page').set_value('CLIP STUDIO').run()
    assert not app.exception
    assert not next(w for w in app.checkbox if w.label=='Show my channel logo on clips').value
    app.session_state['last_clip_result']={'highlights':[{'output':'clip0.mp4'}]}
    app.session_state['clip_broll_review_path']=path
    next(w for w in app.checkbox if w.label=='Prepare related stock B-roll suggestions for these highlights').check().run()
    assert not app.exception,[e.message for e in app.exception]
    assert len([w for w in app.radio if w.label=='Decision for this suggestion'])==6
    assert next(w for w in app.button if w.label=='Approve all & render').disabled
    next(w for w in app.checkbox if w.label.startswith('I approve the listed B-roll')).check().run()
    next(w for w in app.button if w.label=='Approve available batch').click().run()
    assert not app.exception,[e.message for e in app.exception]
    assert all(x.get('approved') for x in load_review(path)['candidates'])
    assert all(w.value=='approve' for w in app.radio if w.label=='Decision for this suggestion')

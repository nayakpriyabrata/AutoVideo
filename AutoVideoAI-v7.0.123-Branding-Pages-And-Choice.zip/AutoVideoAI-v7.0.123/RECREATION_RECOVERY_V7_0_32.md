# AutoVideoAI 7.0.32

Stop the dashboard and CLI jobs before upgrading. Extract into a fresh folder, then migrate the installation:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.31 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.31 . --apply
./dashboard.sh
```

The first migration command previews the copy; the second applies it. Substitute your actual old folder. Existing media and credentials are excluded from this download.

## Recreation

Recreation requires speech text before visual review or planning. For a saved highlight with a matching transcript sidecar, confirm the transcript and adaptation rights, optionally ask Gemini to review the visuals, then create the storyboard. For a local video or older B-roll copy without a transcript, open **Gemini Web · transcript and correction**, authorize the upload, draft the transcript, review the words/timestamps, and approve it. You can instead paste a reviewed transcript. English, Hindi and Odia are supported by the same controls. Missing transcripts are shown before launching visual review.

New B-roll exports inherit a transcript only from an unchanged, hash-verified original highlight. Their sidecar is bound to the new export's hash. This does not repair unknown legacy exports by guessing which transcript belongs to them.

## Flow image recovery and performance

The same generated asset can appear in both the gallery and the Agent response. These previews now count as one candidate when their strict media identities match. Distinct images remain separate: an unchanged ambiguous gallery moves to exact journal correlation after 30 seconds of idle stability rather than spending the whole six-minute image window polling it.

A newly reserved replacement image reuses its original saved project. Existing replacement journals keep their recorded project. The original journal remains intact, each original image still has at most one replacement, and the whole-job cap remains enforced. No uncertain video request is regenerated. Paid replacement image confirmation remains blocked.

Independent Economy frames and candidate stills can use the configured workers while image replacement is enabled. Worker profiles and projects remain isolated; continuity-linked openings remain ordered. Master references must finish before dependent frames. Continue-unresolved-frames and local closing guidance retain their ordered recovery path.

The supplied October 8 log recorded 13 replacement attempts, 14 project captures and zero saved downloads. This was a detection/recovery problem, not normal three-worker generation throughput. These fixes were validated using local browser fixtures and regression tests; live Google/WSL recovery and actual production completion time are not yet verified. Repeated previews with different unrecognized URLs may still require exact prompt correlation.

Resume the same saved job after migration. Existing child requests recover their recorded projects; this build does not delete the old Flow projects or journals.

## Character cards

Click a character card to see its full original photos, description and voice preference. Open **Edit character** there to change its name, description, voice or photos. Selected cast cards also appear in casting and recreation. Existing approved jobs retain their frozen character references.

## Production B-roll

In **Render & B-roll**, long videos and reels can request up to 50 contextual cutaways, spread across the timeline without overlapping. Enable **Automatically select valid B-roll and skip unavailable assets** before searching if you want the tool to save the batch decisions. This selection operates under your permission for the configured stock sources, checks exact file hashes, playable duration and picture dimensions, and records its policy. It does not certify source rights or semantic relevance. Preview the final video. Individual editing remains available in pages of six previews.

B-roll is inserted during rendering over accepted visuals. Adding cutaways does not eliminate the preceding storyboard/Flow work. To reduce new generation, choose a production recipe that allows contextual stock and limit the requested Flow motion scenes; use character-based scenes where identity matters.

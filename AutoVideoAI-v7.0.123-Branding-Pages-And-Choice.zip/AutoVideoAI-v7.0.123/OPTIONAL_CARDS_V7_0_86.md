# AutoVideo 7.0.86 — voices first, text cards optional

## What changed for you

- **Create step 4 now generates the voices only.** The button is "Generate all selected voices (TTS only)". It spends TTS requests and no Gemini Web card requests.
- **Text cards are your choice.** Once the voices are ready, the batch shows "Draft text cards for these voices (optional · Gemini Web)". Press it when you want the cards, or leave it out. Drafting the cards uses Gemini Web and does not spend TTS.
- **A job drafts its own cards if you skip the step.** If you attach a voices-only batch and leave text cards on, the job drafts the cards for its own settings from those approved voices, without calling TTS again.
- **Text cards off means no card request.** With "Include text cards" off, no Gemini Web card request is sent, including the master script's cards.
- **Jobs & Recovery** shows a voices-only batch as "Voices are ready; text cards are optional". It is not listed as a failure.
- **Resume keeps your choice.** A resumed batch keeps the text-card setting it was created with.

## Technical notes

- `app.py`, Clip Studio recreation review: the "Review video + propose recreation scenes" button read the B-roll reuse checkbox before it was defined, so the page raised NameError once a clip was confirmed. The review does not depend on B-roll reuse, so that condition was removed.

- `engine/production.py`: `stage_repairs` used `final_path` without declaring it (NameError on the repair path). It now takes `final_path=None`; existing callers are unchanged.

- `engine/speech_cards.py`: `prepare_batch(..., draft_cards=True)`. With `draft_cards=False` the batch stops at phase `voices_ready`, and each bundle gets `cards_ready=False`. The new `draft_batch_cards(folder)` drafts the cards for bundles that are not ready, makes no TTS call, and ends at `ready_for_review`. `attach_prepared_batch` accepts `voices_ready`.
- `engine/factory.py`: master-card drafting now also requires `presentation.text_cards`.
- `engine/speech_batches.py`: resume passes the saved `draft_cards` flag; voices-only batches count as ready.
- `app.py`: step 4 button and draft button; wording for voices-only batches.

## Chunk size (unchanged, stated for the record)

Gemini TTS narration is split into parts of **2400 characters** by default (`GEMINI_TTS_CHUNK_CHARS`). This is the default and has not been confirmed by you.

## Tests

- `tests/test_v786_optional_cards.py` (6 tests): voices-only batch makes zero card calls; drafting cards makes zero TTS calls; a job attaches the voices and drafts its cards with zero TTS; text cards off makes no card call; resume keeps the choice; cards cannot be drafted before voices.
- `tests/test_v785_voice_reuse.py`: the fake card drafter now sets `cards_ready=True`, as the real function does.
- `tests/test_v767_language_editions.py`: asserts the new step 4 button label.

## Upgrade

From a 7.0.85 installation, run `python3 ../AutoVideoAI-v7.0.86/tools/update_v785_to_v786.py .` for a dry run, then add `--apply`. Stop the dashboard first.

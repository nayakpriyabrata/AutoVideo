"""Integrity and boundary regressions for Flow's signed-URL download recovery."""
import struct

import requests

import engine.providers.flow_browser as flow_module
from engine.providers.flow_browser import FlowBrowser


class _Download:
    def __init__(self, url):
        self.url = url


class _Response:
    def __init__(self, body=b"", *, status=200, headers=None):
        self.status_code = status
        self.headers = headers or {}
        self.body = body
        self.closed = False
        self.iterated = False

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}")

    def iter_content(self, _chunk_size):
        self.iterated = True
        if callable(self.body):
            yield from self.body()
        else:
            # Deliberately yield small pieces to cover chunk boundaries in ftyp.
            for offset in range(0, len(self.body), 7):
                yield self.body[offset:offset + 7]

    def close(self):
        self.closed = True


class _Session:
    def __init__(self, responses):
        self.responses = list(responses)
        self.trust_env = True
        self.calls = []

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def get(self, url, **kwargs):
        assert self.trust_env is False
        self.calls.append((url, kwargs))
        return self.responses.pop(0)


def _install_session(monkeypatch, responses):
    session = _Session(responses)
    monkeypatch.setattr(requests, "Session", lambda: session)
    return session


def _mp4_bytes():
    payload = b"video-payload"
    ftyp = struct.pack(">I", 16) + b"ftyp" + b"isom" + b"\x00\x00\x02\x00"
    mdat = struct.pack(">I", 8 + len(payload)) + b"mdat" + payload
    return ftyp + mdat


def _browser():
    return FlowBrowser.__new__(FlowBrowser)


def _assert_no_partial_files(directory):
    assert sorted(path.name for path in directory.iterdir()) == ["take.mp4"]


def test_mp4_ftyp_requires_valid_first_box_size_and_supports_extended_size():
    normal = _mp4_bytes()
    extended = (b"\x00\x00\x00\x01ftyp" + struct.pack(">Q", 24)
                + b"isom\x00\x00\x02\x00")

    assert FlowBrowser._has_mp4_file_type_box(normal[:64], len(normal))
    assert FlowBrowser._has_mp4_file_type_box(extended, len(extended))
    assert not FlowBrowser._has_mp4_file_type_box(b"junk ftyp isom" + b"\x00" * 8, 22)
    assert not FlowBrowser._has_mp4_file_type_box(b"\x00\x00\x00\x08ftypisom", 16)
    assert not FlowBrowser._has_mp4_file_type_box(
        b"\x00\x00\x00\x20ftypisom" + b"\x00" * 8, 16)


def test_video_recovery_follows_only_allowlisted_redirects_and_saves_atomically(
        tmp_path, monkeypatch):
    data = _mp4_bytes()
    start = "https://storage.googleapis.com/flow/signed.mp4?sig=redacted"
    end = "https://lh3.googleusercontent.com/flow/final.mp4?sig=redacted"
    redirect = _Response(status=302, headers={"Location": end})
    final = _Response(data, headers={
        "Content-Type": "video/mp4; charset=binary",
        "Content-Length": str(len(data)),
    })
    session = _install_session(monkeypatch, [redirect, final])
    output = tmp_path / "take.mp4"

    saved = _browser()._save_video_download_url(_Download(start), str(output))

    assert saved == str(output)
    assert output.read_bytes() == data
    assert redirect.closed and final.closed
    assert [call[0] for call in session.calls] == [start, end]
    assert all(call[1]["stream"] is True and call[1]["allow_redirects"] is False
               for call in session.calls)
    _assert_no_partial_files(tmp_path)


def test_video_recovery_does_not_follow_redirect_outside_google_hosts(tmp_path, monkeypatch):
    start = "https://storage.googleapis.com/flow/signed.mp4?sig=redacted"
    redirect = _Response(status=302, headers={"Location": "https://evil.invalid/clip.mp4"})
    session = _install_session(monkeypatch, [redirect])
    output = tmp_path / "take.mp4"
    output.write_bytes(b"previous verified output")

    saved = _browser()._save_video_download_url(_Download(start), str(output))

    assert saved is None
    assert output.read_bytes() == b"previous verified output"
    assert [call[0] for call in session.calls] == [start]
    assert redirect.closed
    assert sorted(path.name for path in tmp_path.iterdir()) == ["take.mp4"]


def test_video_recovery_rejects_non_mp4_payload_without_replacing_output(tmp_path, monkeypatch):
    url = "https://storage.googleapis.com/flow/signed.mp4?sig=redacted"
    # Contains the magic word, but not as the type field of a valid first box.
    body = b"\x00\x00\x00\x08freeftypisom" + b"\x00" * 32
    response = _Response(body, headers={"Content-Type": "video/mp4"})
    _install_session(monkeypatch, [response])
    output = tmp_path / "take.mp4"
    output.write_bytes(b"previous verified output")

    saved = _browser()._save_video_download_url(_Download(url), str(output))

    assert saved is None
    assert output.read_bytes() == b"previous verified output"
    assert response.closed
    _assert_no_partial_files(tmp_path)


def test_video_recovery_rejects_truncated_content_length_without_replacing_output(
        tmp_path, monkeypatch):
    url = "https://storage.googleapis.com/flow/signed.mp4?sig=redacted"
    data = _mp4_bytes()
    response = _Response(data, headers={
        "Content-Type": "video/mp4", "Content-Length": str(len(data) + 1),
    })
    _install_session(monkeypatch, [response])
    output = tmp_path / "take.mp4"
    output.write_bytes(b"previous verified output")

    saved = _browser()._save_video_download_url(_Download(url), str(output))

    assert saved is None
    assert output.read_bytes() == b"previous verified output"
    assert response.closed
    _assert_no_partial_files(tmp_path)


def test_video_recovery_rejects_oversized_content_length_before_streaming(
        tmp_path, monkeypatch):
    monkeypatch.setattr(flow_module, "_FLOW_VIDEO_DOWNLOAD_MAX_BYTES", 64)
    url = "https://storage.googleapis.com/flow/signed.mp4?sig=redacted"

    def should_not_read():
        raise AssertionError("oversized Content-Length must be rejected before reading")
        yield b"unreachable"

    response = _Response(should_not_read, headers={
        "Content-Type": "video/mp4", "Content-Length": "65",
    })
    _install_session(monkeypatch, [response])
    output = tmp_path / "take.mp4"
    output.write_bytes(b"previous verified output")

    saved = _browser()._save_video_download_url(_Download(url), str(output))

    assert saved is None
    assert not response.iterated
    assert output.read_bytes() == b"previous verified output"
    assert response.closed
    assert sorted(path.name for path in tmp_path.iterdir()) == ["take.mp4"]


def test_video_recovery_enforces_stream_size_limit_and_cleans_partial_file(tmp_path, monkeypatch):
    monkeypatch.setattr(flow_module, "_FLOW_VIDEO_DOWNLOAD_MAX_BYTES", 32)
    url = "https://storage.googleapis.com/flow/signed.mp4?sig=redacted"
    response = _Response(_mp4_bytes(), headers={"Content-Type": "video/mp4"})
    _install_session(monkeypatch, [response])
    output = tmp_path / "take.mp4"
    output.write_bytes(b"previous verified output")

    saved = _browser()._save_video_download_url(_Download(url), str(output))

    assert saved is None
    assert output.read_bytes() == b"previous verified output"
    assert response.closed
    _assert_no_partial_files(tmp_path)


def test_video_download_url_rejects_nonstandard_ports():
    assert not FlowBrowser._is_trusted_flow_download_url(
        "https://storage.googleapis.com:8443/clip.mp4")
    assert FlowBrowser._is_trusted_flow_download_url(
        "https://storage.googleapis.com:443/clip.mp4")

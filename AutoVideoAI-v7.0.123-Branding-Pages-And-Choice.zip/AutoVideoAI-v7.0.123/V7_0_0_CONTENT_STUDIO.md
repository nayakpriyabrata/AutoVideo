# AutoVideoAI v7.0.0 — Content Studio & publishing preparation

Version 7 is a separate, installable release based on v6.0.19. Keep the v6 ZIP and its job folders; extract this ZIP to a **new folder**. The product goal is distinctive, reviewable video in English, Hindi and Odia—not unattended volume, copied articles, or a promise of virality.

## What's new in v7

- **Factozone in Mini Reels:** the supported feed is `https://factozone.com/feed/` (with the “o”). TechniVella remains available. Only RSS titles/excerpts are fetched; they are unverified inspiration, not permission to reuse an article, image or video. Factozone and Technivella terms were not verified as reuse licences.
- **Category-aware Gemini Web briefs:** AI/content creation, learning, self-care, personality development, investment, health/fitness, cooking, business ideas, motivation, devotional/cultural stories, original cartoons, kids’ stories, farming/gardening and general topics receive different editorial prompts. The selector is a guardrail, not fact-checking or professional advice.
- **Indic metadata integrity:** release packets preserve Odia and Hindi copy, including combining marks in hashtags.
- **Destination export packet:** PUBLISHING DESK and `export-delivery` can save a separate destination MP4, `.release.json`, and copy/paste `.upload.txt` packet with title, caption, description, hashtags, chapters, reviewed source URLs and content category.
- **Review lock:** the local approval fingerprint covers the delivery video hash, source hash, destination profile, account, language, title, post metadata and review choices. A changed packet or post record blocks a local schedule reminder until it is reviewed again.
- **Facebook Reels recipe:** the application export profile uses the documented Facebook Reels Publishing API range of 3–90 seconds. This API-specific recipe is not a universal limit for every Facebook upload surface.

The PUBLISHING DESK **does not log in, upload, publish or schedule to Instagram, Facebook or YouTube**. It creates local files and a local reminder only. Verify every field in the platform's own upload screen.

## Install in a clean folder

Requirements: Python 3.10+, FFmpeg/FFprobe on PATH, and a supported browser for browser-based providers. First installation needs internet access for Python packages and optional browser/model downloads.

```bash
# Run these from the extracted AutoVideoAI-v7.0.0 folder
python3 -m venv .venv
source .venv/bin/activate             # Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m playwright install chromium # only for bundled browser mode
cp .env.example .env                  # Windows: copy .env.example .env
streamlit run app.py
```

Use `setup_windows.bat` / `run_windows.bat` on Windows if preferred. Add only services you will actually use to `.env`; do not put API keys, cookies, browser profiles or social passwords in a Git commit or in an uploaded prompt. Read the existing [README](README.md) for WSL, browser, and recovery setup.

## Recommended working loop

### 1. Choose a specific audience and one useful idea

Use **MINI REELS** for an eight-second visual micro-story, not a complete tutorial. Pick a language (English `en`, Hindi `hi`, Odia `or`) and content category. You can enter an idea manually, select a Google Trends topic, or refresh a supported RSS feed. Google Trends measures search interest/trending search topics; it is **not** an Instagram/Facebook/YouTube virality feed.

For a source article, read the original page yourself. Keep the citation/provenance, extract only the fact or question you need, then create a new angle, script, examples, visuals and narration. A source link is not a copyright licence. Never tell a model to reproduce a publisher's wording or another creator's distinctive format.

### 2. Refine with a model, then review the result

Mini Reels uses the visible signed-in **Gemini Web** session for its editable concept brief; it does not silently switch to a different model or API. For broader research, you may compare drafts with Gemini, ChatGPT, Grok or another service whose current terms and licence fit your intended use. Arena is not included as a production/API backend; read the current terms and the [research plan](V7_RESEARCH_AND_PRODUCT_PLAN_2026_10_04.md) before using any output for monetized publishing.

A useful review sequence is: (1) create a few distinct hooks, (2) identify every factual claim, (3) verify material claims in primary/qualified sources, (4) rewrite naturally for the selected language and region, (5) make the script sound right aloud, (6) make each scene do a clear job, and (7) check rights, audience and disclosure. A category prompt does not replace these checks.

### 3. Generate the right kind of video

- **MINI REELS:** one reviewed Gemini Web brief → one explicitly approved, eight-second Flow/Veo portrait generation. Flow availability, model access and credits are controlled by Google and can change. This is not a multi-scene long-form pipeline.
- **STUDIO / CREATE:** for tutorials, explainers and stories, plan a multi-scene piece in English, Hindi or Odia, review the script/storyboard, then explicitly run the existing generation/render workflow. A native-language reviewer should check pronunciation, idioms, captions and factual phrasing.
- **Long-form YouTube:** develop an evidence-backed outline, examples/demonstration, measured narration and chapters. Do not pad a short idea into a long video. The research plan suggests an initial 6–8 minute test only when the subject warrants it; that is an editorial starting point, not a platform rule.
- **Kids and cartoons:** use original characters and age-appropriate stories. A cartoon or family-friendly topic does not automatically answer YouTube’s audience-designation question; choose the real intended audience in the native upload flow.

### 4. Create a destination copy and manual metadata packet

In **PUBLISHING DESK**, select the local source MP4, a separate output folder, destination, language and framing. Add the title, caption, description, hashtags, optional chapter text, content category, and source/attribution URLs you have reviewed. Press **Encode destination delivery + upload packet (local only)**.

The output folder receives:

- a new destination-specific MP4; the source video is not overwritten;
- a `.release.json` review record; and
- a `.upload.txt` packet for manual copy/paste.

You can also create it from a terminal:

```bash
python cli.py export-delivery outputs/JOB/render/JOB-final.mp4 \
  --folder outputs/deliveries \
  --destination youtube_short \
  --language or \
  --title "ଘର ବଗିଚାର ଏକ ସହଜ ଟିପ୍" \
  --caption "ଛୋଟ ଆରମ୍ଭରୁ ସୁନ୍ଦର ବଗିଚା।" \
  --hashtags "#Odia #Gardening" \
  --source-url "https://example.org/reviewed-source" \
  --category "farming and gardening"
```

The CLI command creates files, but does not approve them. In the dashboard, open **PUBLISHING DESK**, paste the `.release.json` path, choose the exact account/channel, and complete rights, facts/story, native-language, intended-audience and AI-disclosure checks. Use **Add local manual-upload reminder** only after the exact file and metadata are approved. A reminder is not a remote schedule.

Before manual upload, check the platform's current duration/format rules, cover crop, captions, copyright/audio results, audience setting and disclosure fields. YouTube requires disclosure for some realistic or meaningfully AI-altered/generated content; a generic animated scene or help writing a script may be treated differently. Use YouTube's current [altered/synthetic content guidance](https://support.google.com/youtube/answer/14328491?hl=en).

## Language review checklist

- Write for the audience rather than translating word-for-word. Local idiom, measurement units, examples and devotional/cultural details matter.
- Check Odia/Devanagari script, vowel signs and line breaks on an actual phone. Listen to the complete voice track; do not infer that an available TTS voice is native-sounding.
- Match subtitles to the spoken wording. Explicitly flag estimated timing, names, pronunciation and any code-switching.
- Review titles, captions, calls to action and hashtags separately for each language. Preserve source meaning but do not lift source phrasing.
- Keep health, finance and farming advice general and sourced. Avoid personalized investment advice, guaranteed outcomes, invented pesticide/yield instructions, diagnoses or cure claims.

## Platform and rights boundaries

- **Instagram:** API publishing requires eligible professional-account setup, OAuth/access tokens and permissions; it is not implemented by this package. The official API documentation currently describes a rolling API-publishing limit. Manual publishing through Instagram is a different workflow.
- **Facebook:** the Reels Publishing API is Page-based, requires Page access/permissions and has documented upload/publishing constraints. The included 3–90 second profile follows that API route, not necessarily every native Facebook surface.
- **YouTube:** API upload requires OAuth and an application. The included release desk does not upload. Shorts, Content ID, made-for-kids, altered-content disclosure and monetization policies are separate decisions; check the current YouTube Studio workflow.
- **Music and stock:** a track or image found online is not automatically licensed for all platforms, territories, edits or monetization. Keep licence/source evidence with the job. A platform's in-app music licence may not transfer to the other platforms.
- **Originality:** make the creator's demonstration, explanation, performance or story the value. Minimal edits to someone else's post, generic repeated templates and mass-produced content are not a sustainable differentiation strategy.

## What is not included

No connected Instagram/Facebook/YouTube OAuth publishing, remote scheduler, automatic competitor scraping, web-wide crawler, automatic fact verification, automatic translation approval, public Arena API integration, guaranteed free video generation, or claim of viral/monetization success. User-exported owned-account metrics can be imported, but AutoVideoAI does not scrape social analytics.

## Validation note for this build

- The complete archive was extracted into a clean folder; `compileall` and the CLI metadata-export help path succeeded. Focused Mini Reels / Content Studio / delivery / package tests from that extracted ZIP: **68 passed**.
- The full offline suite reports **588 passed, 5 skipped, 8 failed**. The eight failures are pre-existing clip/B-roll render checks that require system `ffmpeg`/`ffprobe`; those binaries are not on PATH in this build sandbox. Install both before using video-render/export features and rerun the media tests.

For the feature assessment, platform-source register, category strategy, free/paid tool choices and staged roadmap, see [V7 research and product plan](V7_RESEARCH_AND_PRODUCT_PLAN_2026_10_04.md).

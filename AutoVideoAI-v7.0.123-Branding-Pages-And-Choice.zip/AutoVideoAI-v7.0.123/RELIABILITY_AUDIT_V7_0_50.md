# AutoVideoAI v7.0.50 — reliability audit

This is a targeted reliability release, not a certification that every browser/provider workflow is failure-free. Existing completed videos, approved assets and request journals remain valuable; do not delete them to make Resume bypass an unresolved request.

## What changed

- **Audible and silent Gemini proxies:** H264 output is padded to even dimensions, has square pixels and uses yuv420p. The reported 203×360 encoding failure is covered by real portrait encoding regressions. Audible proxies retain AAC speech. Temporary proxies are removed on encode or provider failure.
- **Gemini attachment controls:** configurable English/Hindi upload labels and composer-scoped add icons, bounded waits, ambiguity rejection and structural diagnostics. A visible attached filename is still required before submitting the review prompt. This needs live validation with your current signed-in Gemini UI.
- **Exact B-roll reuse:** the recreation picker lists only eligible approved reviews. An exact byte-identical moved/copied clip may reuse its review; altered clips/assets remain rejected. Eligibility is checked before job creation so invalid review selection does not create an orphan recreation job.
- **Render recovery:** completed outputs are reused only when current clip, source, captions, logo and cutaway hashes match the render signature. Editing captions invalidates the old render checkpoint.
- **Concurrency:** each review has a cross-process edit/render lock. Background render launch is reserved before queueing and holds its output-folder lock until completion. A second Studio process cannot overwrite its saved job state. A review edited while queued must be reloaded before rendering.
- **Readiness check:** Settings has a local readiness report; `python3 tools/production_preflight.py --output-dir outputs` checks dependencies, disk and a real portrait H264/AAC encode without opening Google or submitting generation. `--media /path/clip.mp4` optionally checks its streams.

## Upgrade an existing installation

Extract this ZIP beside your current installation. Let active jobs finish and stop Studio and the runner. From the **current installation folder**, run:

```bash
cat VERSION
python3 ../AutoVideoAI-v7.0.50/tools/update_v743_to_v750.py . --apply
python3 tools/production_preflight.py --output-dir outputs
./dashboard.sh
```

The updater accepts installed VERSION 7.0.43 through 7.0.49; the directory can still be named `AutoVideoAI-v7.0.42`. It checks release hashes, backs up replaced code and preserves runtime data, outputs, profiles and user settings. It does not install missing Python dependencies. Restart the runner from this same upgraded installation. Do not run production concurrently from old and new installations.

### Dependency compatibility

The audit found that a newly resolved PyArrow build requires NumPy 2 while this media pipeline uses NumPy 1.x. Requirements now pin the tested PyArrow 20.0.0 and constrain OpenCV accordingly. If Settings/Queue fails with a NumPy/PyArrow import error, use your existing Python environment to run `python3 -m pip install "pyarrow==20.0.0" "numpy>=1.26,<2" "opencv-python-headless>=4.8,<4.12"` and restart Studio.

## Progress, closing windows and cleanup

Clip Studio and Queue retain saved render state, stage progress, logs and completed/remaining clip counts. Percent is stage-weighted; it is not a guaranteed wall-clock ETA. Closing the browser tab does not stop a worker in the Studio process. Closing/killing Studio, WSL or the computer **can interrupt rendering**; reopen the saved review and Resume to reuse verified completed clips.

Local cleanup remains explicit: select jobs/clip folders, review the owned files/dependencies, then confirm deletion. Active or queued rendering blocks deletion. Shared inputs and external source files are protected by ownership/dependency checks.

**Automatic Google Flow project deletion is disabled.** The earlier navigation-based check could not prove that deletion succeeded. Saved exact project links remain visible for manual review. Preserve the links before local cleanup, which removes local recovery metadata. This release does not promise remote cleanup.

## Verification and remaining work

The release is checked with offline regression tests, real FFmpeg proxy encoding, source compilation, release hash verification and an in-place upgrade smoke test. Verified in this run: 1,081 offline tests passed (13 deprecation warnings); the focused recovery/proxy/locking run passed 16 tests. Control Center passed 24 JavaScript and 18 Python tests plus syntax checks.

Signed-in Gemini uploading, Google Flow generation matching/download recovery, browser reconnection on your WSL installation, multi-hour operation and editorial visual/audio quality still require live acceptance testing. Offline mocks do not prove those workflows. No live Google generation was submitted during this audit.

The next architectural milestone is a supervised background worker service with a durable queue, heartbeat and restart recovery, followed by platform export/quality acceptance checks. The present worker still belongs to Studio. Adding paid provider APIs, replacing an uncertain paid request or publishing to social accounts requires an explicit product decision; this release does not silently enable them.

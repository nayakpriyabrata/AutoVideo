"""Pre-render exposure budget. Looping is not a repair for missing coverage."""
import hashlib
import os
import json
import shutil


def copy_source_provenance(source, destination):
    """Carry source metadata with accepted footage; remove stale prior metadata."""
    src, dst = str(source) + ".source.json", str(destination) + ".source.json"
    if os.path.isfile(src):
        shutil.copy2(src, dst)
    elif os.path.isfile(dst):
        os.unlink(dst)


def source_identity(path):
    """Identity from recorded stock provenance, independent of encoding."""
    try:
        with open(path + ".source.json", encoding="utf-8") as f:
            record = json.load(f)
        source, asset = record.get("source"), record.get("asset_id")
        if source and asset is not None and str(asset).strip():
            return str(source) + ":" + str(asset)
        if source == "local-stock" and record.get("local_source"):
            return "local-stock:" + os.path.normcase(os.path.realpath(record["local_source"]))
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    return None


def audit_coverage(segments, total):
    issues, exposures, details = [], {}, []
    origins = {}
    hashes = {}
    for segment in segments:
        shot = segment.get("shot_id", "unknown")
        duration = float(segment.get("dur", 0)) + float(segment.get("freeze", 0))
        extension = float(segment.get("freeze", 0))
        path = os.path.realpath(segment["src"])
        if path not in hashes:
            digest = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    digest.update(chunk)
            hashes[path] = digest.hexdigest()
        key = hashes[path]
        exposures[key] = exposures.get(key, 0) + duration
        origin = source_identity(path)
        if origin:
            origins[origin] = origins.get(origin, 0) + duration
        details.append({"shot_id": shot, "source": path, "sha256": key,
                        "duration": round(duration, 3), "extension": round(extension, 3),
                        "source_identity": origin})
        if segment.get("borrowed_visual"):
            issues.append(f"{shot}: missing accepted media; neighbouring footage is not an editorial replacement")
        # Long-form single-take movies/interviews are legitimate; repeated short
        # media is not. Apply length cap only when extending a short source.
        if extension > max(3.0, float(segment.get("dur", 0)) * .5):
            issues.append(f"{shot}: {duration:.1f}s window exceeds source by {extension:.1f}s; supply longer relevant media or replan")
    for key, exposure in exposures.items():
        rows = [x for x in details if x["sha256"] == key]
        if total >= 60 and len(rows) > 1 and exposure / total > .20:
            issues.append(f"Repeated source occupies {exposure/total:.0%} of timeline in " +
                          ", ".join(x["shot_id"] for x in rows))
    for origin, exposure in origins.items():
        rows = [x for x in details if x['source_identity'] == origin]
        # Exact-byte duplication above already reports identical copies.
        if total >= 60 and len(rows) > 1 and len({x['sha256'] for x in rows}) > 1 and exposure/total > .20:
            issues.append(f"Repeated stock asset occupies {exposure/total:.0%} of timeline in " +
                          ", ".join(x['shot_id'] for x in rows) + "; choose relevant distinct footage")
    return {"passed": not issues, "issues": issues, "sources": details,
            "note": "Exact-file and recorded stock-source repetition plus extension checks; legacy footage without provenance still requires visual review; not a semantic relevance guarantee."}

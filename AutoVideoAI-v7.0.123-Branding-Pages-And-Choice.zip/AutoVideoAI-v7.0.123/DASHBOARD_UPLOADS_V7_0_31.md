# AutoVideoAI 7.0.31 — dashboard monitoring and GUI image/video uploads

Includes the fixes and features from 7.0.30.

## What the reported logs mean

The Streamlit/Uvicorn startup lines, WSL poll watcher message and Groq timing progress are normal. The workspace default/session-state warning was a navigation setup issue. The duplicate `capture-logs` widget exception was a real monitor crash: Queue mounted its monitor, then Resume mounted a second copy with the same keys. This update mounts one monitor in Queue and namespaces launch-page controls. Captured text remains stable while live logs update.

## Edited character photos

Uploading replacement photos in the character editor now saves them when you click Update character, even without ticking the older Replace reference photos checkbox. An empty replacement still requires an explicit removal choice. Choosing both uploaded photos and Remove photos produces a clear validation message instead of discarding the upload.

Image suffixes now come from the verified image bytes, rather than a browser MIME hint. The Flow bridge also corrects the upload alias suffix for old misnamed references, without modifying their approved image bytes. PNG data saved under a JPEG name can therefore reach Flow with the correct format.

Old approved jobs retain their exact saved reference photos. Editing a library card affects future jobs; it does not silently replace a photo in an already approved recreation. Migrated references are recovered only when their hashes match, as in 7.0.30.

The supplied logs show the local Aanya photo reached the upload step, but cannot establish that all edited-photo failures share one cause. These changes fix reproducible local defects; signed-in Flow attachment remains unverified on the user's WSL machine.

## Gemini video review

The local AI Recreate review follows the visible Gemini `+` menu, then `Upload files`, and uses the resulting file chooser. It no longer selects a generic hidden file input that could belong to image creation. It accepts common labels such as Open upload file menu, with a visible add-icon fallback. The uploaded proxy filename must appear before any review prompt is submitted. No generation is started if the menu or attachment is unavailable.

## Upgrade

Stop dashboard/CLI workers, extract into a fresh directory, and migrate your most complete previous installation:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.30 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.30 . --apply
./dashboard.sh
```

Use `../AutoVideoAI-v7.0.29` instead if that is where your complete outputs and character library are stored. Do not delete older installations until the migrated jobs and Gallery have been checked.

For the existing failed Aanya job, keep its saved job and resume it after upgrading. The normal verified attachment and recovery checks still apply; no video request is blindly regenerated and no paid Google generation was used for testing.

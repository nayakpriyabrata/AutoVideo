"""Compact Streamlit cast previews and local image imports."""
import base64
import hashlib
import html
import io
from pathlib import Path
from PIL import Image, ImageOps


def face_thumbnail(source, size=(140,160), face_boxes=None, focus=None):
    """Presentation thumbnail only; never modifies original reference photos."""
    image=ImageOps.exif_transpose(source).convert('RGB')
    if focus:
        cx,cy,zoom=[float(focus[k]) for k in ('x','y','zoom')]
        cw=image.width/max(1,min(8,zoom));ch=cw*size[1]/size[0]
        if ch>image.height:ch=image.height;cw=ch*size[0]/size[1]
        left=min(max(0,image.width*cx-cw/2),image.width-cw)
        top=min(max(0,image.height*cy-ch/2),image.height-ch)
        return image.crop((int(left),int(top),int(left+cw),int(top+ch))).resize(size,Image.Resampling.LANCZOS)
    if face_boxes is None:
        face_boxes=[]
        try:
            import cv2
            import numpy as np
            probe=image.copy();probe.thumbnail((800,800))
            detector=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
            found=detector.detectMultiScale(cv2.cvtColor(np.asarray(probe),cv2.COLOR_RGB2GRAY),1.1,4)
            gray=cv2.cvtColor(np.asarray(probe),cv2.COLOR_RGB2GRAY)
            eyes=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_eye.xml')
            sx,sy=image.width/probe.width,image.height/probe.height
            # Reject flower/background false positives that have no visible eyes.
            face_boxes=[(x*sx,y*sy,w*sx,h*sy) for x,y,w,h in found
                        if len(eyes.detectMultiScale(gray[y:y+int(h*.7),x:x+w],1.1,3))>=1]
        except Exception: pass
    if face_boxes:
        x,y,w,h=max(face_boxes,key=lambda b:b[2]*b[3])
        # Include head and shoulders around the largest detected face.
        cw=max(w*2.2,h*2.2*size[0]/size[1]);ch=cw*size[1]/size[0]
        scale=min(1,image.width/cw,image.height/ch);cw*=scale;ch*=scale
        left=min(max(0,x+w/2-cw/2),image.width-cw)
        top=min(max(0,y+h*.45-ch*.42),image.height-ch)
        image=image.crop((int(left),int(top),int(left+cw),int(top+ch)))
    if not face_boxes:
        return ImageOps.pad(image,size,method=Image.Resampling.LANCZOS,color='#182335')
    return ImageOps.fit(image,size,method=Image.Resampling.LANCZOS,centering=(.5,0))


def character_cards(st, characters, key='library'):
    """A keyboard-accessible card button opens the original photos and editor."""
    @st.dialog('Character details', width='large')
    def details(character):
        from .content_library import CharacterLibrary
        st.subheader(character['name'])
        st.write(character['description'])
        st.caption('Voice: '+character.get('voice_style','unspecified'))
        for reference in character.get('references',[]):
            if Path(reference['path']).is_file():
                st.image(reference['path'],width=420)
        with st.expander('Edit character'):
            with st.form(key+'-detail-edit-'+character['id']):
                name=st.text_input('Name',value=character['name'])
                description=st.text_area('Description',value=character['description'])
                styles=['unspecified','masculine','feminine']
                voice=st.selectbox('Voice presentation',styles,index=styles.index(character.get('voice_style','unspecified')))
                photos=st.file_uploader('Replacement reference photos',type=['png','jpg','jpeg','webp'],accept_multiple_files=True)
                clear=st.checkbox('Remove reference photos for future jobs')
                if st.form_submit_button('Save character changes'):
                    try:
                        if clear and photos:raise ValueError('Choose replacement photos or removal, not both')
                        refs=[] if clear else [save_uploaded_image(p,'data/content/photo_imports') for p in photos] if photos else None
                        CharacterLibrary().update(character['id'],name,description,reference_files=refs,voice_style=voice)
                        st.rerun()
                    except ValueError as error:st.error(str(error))
            st.caption('Existing approved jobs retain their original character snapshot.')
    for offset in range(0,len(characters),4):
        for column,character in zip(st.columns(4),characters[offset:offset+4]):
            image_url=''
            for ref in character.get('references',[]):
                try:
                    with Image.open(ref['path']) as source:
                        thumb=face_thumbnail(source,focus=character.get('preview_crop'))
                        buffer=io.BytesIO();thumb.save(buffer,format='JPEG',quality=85)
                    image_url='data:image/jpeg;base64,'+base64.b64encode(buffer.getvalue()).decode()
                    break
                except (OSError,ValueError):continue
            scope='char-'+hashlib.sha256((key+character['id']).encode()).hexdigest()[:16]
            height='200px' if image_url else '65px'
            background=f'url("{image_url}") center top / 140px 160px no-repeat,' if image_url else ''
            st.markdown('<style>.st-key-'+scope+' button{height:'+height+';width:156px;max-width:100%;'
                'margin:8px auto 18px;display:flex;align-items:flex-end;justify-content:center;'
                'padding-bottom:8px;border:2px solid #a855f7;border-radius:14px;'
                'background:'+background+'linear-gradient(135deg,#201539,#193a4a)!important;'
                'color:white!important;box-shadow:3px 3px 0 #fbbf24;transition:transform .18s;}'
                '.st-key-'+scope+' button p{color:white!important;}'
                '.st-key-'+scope+' button:hover{transform:scale(1.12);z-index:50;}'
                '@media(prefers-reduced-motion:reduce){.st-key-'+scope+' button{transition:none;}}</style>',unsafe_allow_html=True)
            with column.container(key=scope):
                if st.button(character['name'],key=scope+'-open',help='View full photos, details and edit'):
                    details(character)


def cast_picker(st, key, label='Choose saved characters (optional, up to three)'):
    from .content_library import CharacterLibrary
    characters=CharacterLibrary().list()
    st.subheader('Your cast · optional')
    st.caption('Leave empty for a new cast. Selected reference photos travel with the job; cartoon recipes preserve the same identity in a stylized character. Review the generated likeness.')
    selected=st.multiselect(label,[c['id'] for c in characters],max_selections=3,key=key,
        format_func=lambda i:next(c['name'] for c in characters if c['id']==i))
    if selected: character_cards(st,[c for c in characters if c['id'] in selected],key=key)
    if not characters: st.info('Save characters in Character Library to reuse them here.')
    return selected


def save_uploaded_image(upload, folder='data/branding'):
    content=upload.getvalue()
    if len(content)>20*1024*1024: raise ValueError('Image exceeds 20 MB')
    with Image.open(io.BytesIO(content)) as image:
        if image.format not in ('PNG','JPEG','WEBP') or image.width*image.height>25_000_000:
            raise ValueError('Use PNG/JPEG/WebP up to 25 megapixels')
        image.verify()
    # Browser MIME hints and the user's filename can disagree with the bytes.
    # Flow receives the saved suffix, so derive it from the verified decoder.
    with Image.open(io.BytesIO(content)) as image:
        suffix={'PNG':'.png','JPEG':'.jpg','WEBP':'.webp'}[image.format]
    root=Path(folder).resolve();root.mkdir(parents=True,exist_ok=True)
    path=root/(hashlib.sha256(content).hexdigest()+suffix)
    if not path.exists() or path.read_bytes()!=content: path.write_bytes(content)
    return str(path)


def flow_music_picker(st, key, prompt=''):
    """Shared song/background workflow; only explicit approval can submit music."""
    from .flow_music import new_request, list_requests, run_browser, completed_track, bind_session, login_status
    st.caption('Flow Music opens a separate visible Chromium session. Sign in there. Your account may charge credits; approval covers one request, which can return two versions. Recovery only rescans/downloads that request.')
    if st.button('Open Flow Music login browser',key=key+'-login'):
        try:
            with st.spinner('Opening the sign-in window…'):
                st.json(run_browser('login'))
        except Exception as error: st.error(str(error))
    status=login_status()
    if status and status.get('state') not in ('closed','failed'):
        st.info('Flow Music login window is open. Finish signing in there, then Generate; the signed-in profile is handed off without submitting another request.')
        if st.button('Close Flow Music login window',key=key+'-close-login'):
            try:
                run_browser('close-login')
                st.rerun()
            except RuntimeError as error:
                st.warning(str(error))
    if status.get('state')=='sign-in-blocked':
        st.warning('Google rejected this sign-in browser. Retrying the same automated login cannot guarantee access. Use your normal browser and import the downloaded track below; no security settings need disabling.')
    with st.expander('Manual Flow Music sign-in and track import',expanded=status.get('state')=='sign-in-blocked'):
        st.caption('Open Flow Music in your normal browser, sign in yourself, then generate and download the chosen track. Importing it here makes no new music request.')
        if st.button('Open Flow Music in my normal browser',key=key+'-manual-browser'):
            from .flow_music import open_manual_music
            try:open_manual_music();st.info('Use the opened browser and import the downloaded track here.')
            except RuntimeError as error:st.error(str(error))
        track=st.file_uploader('Downloaded music file',type=['mp3','wav','m4a','ogg','flac'],key=key+'-manual-track')
        allowed=st.checkbox('I have permission to use this music',key=key+'-manual-permission')
        if track is not None and allowed:
            from .flow_music import import_music
            try:
                chosen=import_music(track.getvalue(),track.name)
                st.audio(chosen);st.success('Imported track selected; production can use this local file.')
                return chosen
            except Exception as error:st.error(str(error))
    draft=st.text_area('Reviewed Flow Music prompt' ,value=prompt,key=key+'-prompt')
    if st.button('Save a new music request — no generation',key=key+'-draft',disabled=not draft.strip()):
        try: st.session_state[key+'-journal']=new_request(draft);st.rerun()
        except Exception as error: st.error(str(error))
    requests=list_requests()
    if not requests: return ''
    ids=[r['journal'] for r in requests]
    desired=st.session_state.get(key+'-journal')
    journal=st.selectbox('Saved music requests',ids,index=ids.index(desired) if desired in ids else 0,
        format_func=lambda i:next(r['prompt'][:65]+' · '+r['state']+' · '+r['id'][-6:] for r in requests if r['journal']==i),key=key+'-select')
    data=next(r for r in requests if r['journal']==journal)
    st.code(data['prompt'])
    if data['state']=='draft':
        approved=st.checkbox('I approve one Flow Music request at my account’s current cost',key=key+'-approve-'+data['id'])
        if st.button('Generate music once',disabled=not approved,key=key+'-generate'):
            try:
                with st.spinner('Generating one music request; journal saved before submission…'):
                    run_browser('generate',journal,approved=True)
                st.rerun()
            except Exception as error: st.error(str(error))
    else:
        if not data.get('session_url'):
            url=st.text_input('Exact submitted Flow Music session URL',key=key+'-session')
            if st.button('Save recovery session URL',key=key+'-bind'):
                try: bind_session(journal,url);st.rerun()
                except Exception as error:st.error(str(error))
        if st.button('Rescan saved songs — no new generation',key=key+'-scan'):
            try:
                with st.spinner('Looking for this request’s song candidates…'): run_browser('scan',journal)
                st.rerun()
            except Exception as error:st.error(str(error))
        candidates=data.get('candidates',[])
        if candidates:
            candidate=st.selectbox('Choose a song version',[r['key'] for r in candidates],
                format_func=lambda k:next(str(i+1)+' · '+r['label'] for i,r in enumerate(candidates) if r['key']==k),key=key+'-candidate-'+data['id'])
            if st.button('Download selected MP3',key=key+'-download'):
                try:
                    with st.spinner('Downloading and validating the exact selected song…'):run_browser('download',journal,key=candidate)
                    st.rerun()
                except Exception as error:st.error(str(error))
        if data['state']=='downloaded':
            try:
                path=completed_track(journal);st.audio(path)
                st.caption('Selected track is validated and saved locally. Music-video jobs copy it into their own audio folder.')
                return path
            except Exception as error:st.error(str(error))
    return ''


def broll_settings(st,key,values=None):
    """Explicit per-job render policy, independent of base storyboard routing."""
    values=values or {}
    with st.expander('Contextual B-roll · optional',expanded=False):
        enabled=st.checkbox('Add contextual B-roll during rendering',value=bool(values.get('broll_count',0)),key=key+'-enabled')
        st.caption('Base stock scenes and B-roll are different. Selected cast can make base stock zero; optional cutaways are still searched from each narration/action beat. Count is a maximum: short videos fit fewer non-overlapping cutaways. Unavailable assets are skipped, never padded with unrelated footage.')
        count=st.number_input('Maximum B-roll cutaways',1,150,int(values.get('broll_count') or 50),key=key+'-count',disabled=not enabled)
        duration=st.slider('B-roll seconds per cutaway',.5,6.,float(values.get('broll_duration',2.)),.5,key=key+'-duration',disabled=not enabled)
        uses=st.selectbox('Maximum uses of the same B-roll asset',[1,2,3],index=int(values.get('broll_max_uses',1))-1,key=key+'-uses',disabled=not enabled)
        auto=st.checkbox('Automatically select valid assets from my permitted stock sources',value=bool(values.get('broll_auto',True)),key=key+'-auto',disabled=not enabled)
        hint=st.text_input('B-roll search hint (optional)',value=values.get('broll_query_hint',''),key=key+'-hint',disabled=not enabled)
        st.caption('Fresh assets are preferred. Repeats need the same scene context, at least 30 seconds and a different cutaway between uses. Your choice is a maximum. AI/external video shots are protected from B-roll. Automatic checks validate files, not semantic relevance or legal rights; preview the finished video.')
    return dict(broll_count=int(count) if enabled else 0,broll_duration=float(duration),broll_max_uses=int(uses),broll_query_hint=hint,broll_auto=bool(enabled and auto))

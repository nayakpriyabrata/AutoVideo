from types import SimpleNamespace as NS
import hashlib
import json
from pathlib import Path
import pytest
from engine.providers.flow_browser import FlowBrowser, FlowBrowserProvider, FlowRequestPending


def bridge(assets, prompts):
    return NS(media_assets=lambda:assets, read_asset_generation_prompt=lambda sig:prompts.get(sig),
              _page=NS(wait_for_timeout=lambda ms:None))


def test_resume_resolves_two_fresh_images_from_exact_prompt_without_tile_order():
    p=FlowBrowserProvider.__new__(FlowBrowserProvider)
    assets=[{'sig':'old','kind':'image'},{'sig':'wrong','kind':'image'},{'sig':'right','kind':'image'}]
    request={'baseline':['old'],'submitted_prompt':'Create a cloud scene'}
    result=p._identify_single_fresh_asset(bridge(assets,{'wrong':'Create a beach','right':'Create a cloud scene'}),request,'image',0)
    assert result=='right' and request['correlation_method']=='exact_reused_prompt'
    assert request['verified_equivalent_assets']==1


def test_identical_request_variants_can_recover_after_legacy_replacement():
    p=FlowBrowserProvider.__new__(FlowBrowserProvider)
    request={'baseline':['old'],'submitted_prompt':'Create a cloud scene','prompt_correlation_legacy':True}
    assets=[{'sig':'second','kind':'image'},{'sig':'first','kind':'image'}]
    result=p._identify_single_fresh_asset(bridge(assets,{'first':'Create a cloud scene','second':'Create a cloud scene'}),request,'image',0)
    assert result=='first' and request['verified_equivalent_assets']==2
    assert request['verified_prompt_sha256']==hashlib.sha256(b'Create a cloud scene').hexdigest()


@pytest.mark.parametrize('actual',['Create a cloud scene with a cat','AVREQ_same','',None])
def test_title_or_partial_prompt_or_unavailable_ui_cannot_authorize_image(actual):
    p=FlowBrowserProvider.__new__(FlowBrowserProvider)
    request={'baseline':[],'submitted_prompt':'Create a cloud scene'}
    assert not p._identify_single_fresh_asset(bridge([{'sig':'candidate','kind':'image'}],{'candidate':actual}),request,'image',0)
    assert 'correlation_method' not in request


def test_prompt_comparison_only_normalizes_whitespace_and_unicode():
    assert FlowBrowser.same_generation_prompt('Create\n a café','Create a cafe\u0301')
    assert not FlowBrowser.same_generation_prompt('Create a café landscape','Create a café portrait')
    assert not FlowBrowser.same_generation_prompt('', '')


def test_flow_thumbnail_resize_keeps_content_identity_only_on_flow_asb():
    from engine.providers.flow_browser import media_signature_matches
    token='A'*50
    def sig(host,size,token=token):return f'IMG|https://{host}/asb/{token}=s{size}-rw|tile|image|141|250'
    assert media_signature_matches(sig('flow.google.com',512),sig('flow.google.com',256))
    assert not media_signature_matches(sig('other.example',512),sig('other.example',256))
    assert not media_signature_matches(sig('flow.google.com',512),sig('flow.google.com',512,'B'*50))


def test_read_reuse_prompt_restores_existing_draft_and_never_submits():
    b=FlowBrowser.__new__(FlowBrowser);fills=[];draft={'text':'my unrelated unsent draft'}
    sig='exact';src='https://flow.google.com/asb/content'
    b.media_assets=lambda:[{'sig':sig,'src':src,'dom_index':0}]
    b._resolve=lambda *a,**k:NS(inner_text=lambda **kw:draft['text'])
    def fill(key,value):fills.append(value);draft['text']=value
    b._fill_editor_box=fill
    class Media:
        def hover(self,**k):pass
        def evaluate(self,code,**k):
            if code.startswith('el => el.currentSrc'):return src
            assert 'reuse prompt' in code.lower()
            draft['text']='the exact submitted prompt';return True
    b._page=NS(locator=lambda q:NS(nth=lambda i:Media()),wait_for_timeout=lambda ms:None)
    assert b.read_asset_generation_prompt(sig)=='the exact submitted prompt'
    assert fills==['','my unrelated unsent draft'] and draft['text']=='my unrelated unsent draft'


def test_failed_restore_stops_recovery_instead_of_leaking_a_draft():
    from engine.providers.flow_browser import FlowUIChanged
    b=FlowBrowser.__new__(FlowBrowser)
    b.media_assets=lambda:[{'sig':'exact','src':'a','dom_index':0}]
    b._resolve=lambda *a,**k:NS(inner_text=lambda **kw:'preserve')
    b._page=NS(locator=lambda q:NS(nth=lambda i:NS(evaluate=lambda *a,**k:'changed')))
    b._fill_editor_box=lambda *a:(_ for _ in ()).throw(RuntimeError('closed'))
    with pytest.raises(FlowUIChanged,match='restore'):
        b.read_asset_generation_prompt('exact')


def test_legacy_pending_request_reconstructs_exact_prompt_then_records_verified_recovery(tmp_path):
    from PIL import Image
    p=FlowBrowserProvider.__new__(FlowBrowserProvider)
    out=str(tmp_path/'close.jpg');prompt='A woman at a computer';url='https://flow.google.com/project/test'
    key=hashlib.sha256(json.dumps(['image','shot_001',prompt,True],sort_keys=True).encode()).hexdigest()
    p._save_request(out,{'kind':'image','request_hash':key,'baseline':['old'],'signature':'','project_url':url})
    expected=FlowBrowser._agent_image_instruction(prompt+' Ultra detailed still frame, sharp focus, professional photography.','9:16',1)
    b=bridge([{'sig':'other','kind':'image'},{'sig':'correct','kind':'image'}],{'other':'unrelated','correct':expected})
    b.ensure_project=lambda *a,**k:None
    def download(*a,**k):
        assert k['preferred_signature']=='correct'
        Image.new('RGB',(200,200),'blue').save(out)
    b.download_latest_asset=download
    p._ensure=lambda:b
    p._generate_image_once=lambda *a,**k:pytest.fail('Resume must not generate')
    result=p._guarded_generation_once(NS(shot_id='shot_001'),{'prompt':prompt},None,out,True,False,'image')
    saved=json.loads(Path(out+'.flow-request.json').read_text())
    assert result['path']==out and saved['status']=='downloaded' and saved['signature']=='correct'
    assert saved['correlation_method']=='exact_reused_prompt'

# AutoVideoAI 7.0.71 — Flow duplicate-spend guard

## What went wrong (7.0.70)

The Flow job `20261020-112139-how-to-stop-overthinking-8715` (shot_026, take 1) was
retried through automatic recovery and job restarts. Flow's chat showed the same
generation request several times, and each one was charged. Code review of 7.0.70
found these ways a Flow video prompt could be sent again:

1. **Standard/legacy editor path had no request journal.** A submission there was
   not recorded, so a later retry could not see that it had already been sent.
2. **The factory's "no usable media" retry called the provider again** when the
   provider returned an error dictionary instead of raising. Only the journal stopped
   this, and the legacy path did not write one.
3. **Nothing compared a new prompt with prompts already in the Flow chat.**
4. **Approval clicks were not tied to a request the app had just sent.** With
   "Always approve" selected, Flow approves each card, so a repeated prompt is paid
   for at once.
5. **Resume reconciled image replacement by default** (`--replace-unresolved-images`
   defaulted to on), which can start a second credit-bearing image request.

The exact number of repeated sends per shot is not confirmed by the logs in this
release. The fixes below cover every path listed above.

## What 7.0.71 changes

* **Write-ahead submit ledger, per take** (`<take>.mp4.submit-ledger.jsonl`). An
  `intent` line is fsynced before the Send action, and `submitted` after it. Any
  `intent`, `submitted` or unreadable line blocks every later submission for that
  take file, including after a restart. A saved `.flow-request.json` also blocks.
* **Per-job ledger and cap** (`flow_submission_ledger.jsonl`). Default cap: 20 intents
  per job. To raise it, run `python3 cli.py v3 resume <job_id> --flow-submission-cap N`.
  The new value is written to `flow_submission_cap.json` and logged.
* **Check mode.** `engine/flow_submit_guard.check_only()` is process-wide. While it
  is active, no new video prompt is sent and no approval card is clicked.
* **Single gate before any browser action.** Every video request is checked first.
  A take that has a recorded or unknown submission is recovered by download only.
* **Duplicate-prompt check.** If the exact instruction is already visible in the Flow
  chat and this job has no ledger record of that prompt, nothing is sent. The saved
  request must be inspected instead. Sibling takes of the same shot, which share a
  prompt, are still allowed because the job ledger already accounts for them.
  A different job that reuses the same project and prompt text is blocked; clear the
  chat or use a different project to continue.
* **Approval only for the request the app sent.** A card is clicked only while that
  request is awaiting approval, and each click is logged in the take ledger.
* **Factory retries** run only when the take has never started a submission.
* **Image replacement is off during resume.** Any job with saved Flow requests has
  its replacement permission cleared when `run_job` starts. `--replace-unresolved-images`
  on resume is ignored with a notice. Resume recovery never sets replacement on.
* **Recovering a saved request never reaches the send step.** The recovery branch
  returns the file or raises; it has no path to a new prompt.

## What it does not do

* It does not restart, edit or re-download the saved shot_026 request. Recovery of
  that take is a separate, explicit step, and it requires the local Flow session.
* It cannot prove that Flow's own "Always approve" setting will not approve a card
  that the app did not send. The guard prevents the app from sending the request in
  the first place. Turning "Always approve" off is a separate user decision.
* It has no live Flow test in this environment. Behaviour is covered by the fake-bridge
  tests in `tests/test_v771_flow_submit_guard.py`.

## Install

From the 7.0.70 installation folder, after extracting the 7.0.71 zip beside it:

    python3 ../AutoVideoAI-v7.0.71/tools/update_v770_to_v771.py .            # dry run
    python3 ../AutoVideoAI-v7.0.71/tools/update_v770_to_v771.py . --apply

Stop the dashboard before `--apply`. Only code and this document are replaced.
Outputs, saved jobs, browser profiles and channel profiles are never touched.

from pathlib import Path
import json
import pytest
from engine.factory import Factory
from engine.media_gallery import gallery_items,deletion_preview,delete_export
from engine.production_lock import production_slot


def setup(tmp_path):
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'data/jobs.db'))
    job=f.create_job('Saved cartoon',dry_run=True)
    path=Path(f.pm.job_dir(job))/'render'/(job+'-final.mp4');path.write_bytes(b'export')
    f.db.upsert(job,status='done',render_status='done',final_path=str(path))
    return f,job,path


def test_gallery_finds_migrated_finals_and_mini_reels_without_valid_db_path(tmp_path):
    f,job,path=setup(tmp_path)
    f.db.upsert(job,final_path='/old/install/render/missing.mp4')
    reel=Path(f.pm.root)/'mini_reels/reel-12345';reel.mkdir(parents=True)
    (reel/'mini_reel.json').write_text(json.dumps({'topic':'Mini reel','status':'complete'}))
    (reel/'mini-reel.mp4').write_bytes(b'mini')
    groups=gallery_items(f,f.db.list(),[])
    paths=[i['path'] for rows in groups.values() for i in rows]
    assert str(path) in paths and str(reel/'mini-reel.mp4') in paths
    assert len(paths)==2


def test_delete_only_export_preserves_job_and_updates_index(tmp_path):
    f,job,path=setup(tmp_path)
    take=Path(f.pm.job_dir(job))/'flow/shots/accepted.mp4';take.write_bytes(b'accepted')
    item=next(i for rows in gallery_items(f,f.db.list(),[]).values() for i in rows)
    result=delete_export(f,deletion_preview(item),f.db.list(),[],[f.pm.root])
    assert result['freed_bytes']==6 and not path.exists() and take.exists()
    assert Path(f.pm.manifest_path(job)).exists()
    assert f.db.get(job)['status']=='output_deleted' and f.db.get(job)['final_path']==''


def test_changed_file_and_non_gallery_take_cannot_be_deleted(tmp_path):
    f,job,path=setup(tmp_path)
    item=next(i for rows in gallery_items(f,f.db.list(),[]).values() for i in rows)
    preview=deletion_preview(item);path.write_bytes(b'new export')
    with pytest.raises(ValueError,match='changed'):delete_export(f,preview,f.db.list(),[],[f.pm.root])
    take=Path(f.pm.job_dir(job))/'flow/shots/take.mp4';take.write_bytes(b'take')
    with pytest.raises(ValueError,match='outside'):delete_export(f,deletion_preview({'path':str(take)}),f.db.list(),[],[f.pm.root])
    assert take.exists() and path.exists()


def test_saved_recreation_source_and_active_jobs_are_protected(tmp_path):
    f,job,path=setup(tmp_path)
    clip=Path(f.pm.root)/'my-clips/clip.mp4';clip.parent.mkdir();clip.write_bytes(b'clip')
    clips=[{'path':str(clip)}];item=gallery_items(f,f.db.list(),clips)['Clips'][0]
    (Path(f.pm.job_dir(job))/'recreation.json').write_text(json.dumps({'source_clip':str(clip)}))
    with pytest.raises(ValueError,match='source of saved'):delete_export(f,deletion_preview(item),f.db.list(),clips,[f.pm.root])
    with production_slot(f.pm.job_dir(job)):
        with pytest.raises(ValueError,match='Production is active'):delete_export(f,deletion_preview(item),f.db.list(),clips,[f.pm.root])
    assert clip.exists()


def test_delete_refuses_output_outside_allowed_roots(tmp_path):
    f,job,path=setup(tmp_path);clip=tmp_path/'outside.mp4';clip.write_bytes(b'clip')
    clips=[{'path':str(clip)}];item=gallery_items(f,f.db.list(),clips)['Clips'][0]
    with pytest.raises(ValueError,match='outside'):delete_export(f,deletion_preview(item),f.db.list(),clips,[f.pm.root])
    assert clip.exists()


def test_gallery_shortcut_shows_download_and_confirmed_delete(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard
    f,app=dashboard(tmp_path,monkeypatch)
    job=f.create_job('Saved video',dry_run=True)
    path=Path(f.pm.job_dir(job))/'render'/(job+'-final.mp4');path.write_bytes(b'export')
    f.db.upsert(job,status='done',final_path=str(path))
    next(w for w in app.sidebar.button if w.label=='Gallery & Downloads').click().run()
    assert not app.exception
    assert app.session_state['autovideo_current_page']=='HISTORY'
    assert any(w.value=='Gallery & Downloads' for w in app.title)
    next(w for w in app.button if w.label=='Delete exported video').click().run()
    assert path.exists()
    assert next(w for w in app.button if w.label=='Confirm permanent deletion').disabled
    next(w for w in app.checkbox if w.label=='I confirm deletion of this file').check().run()
    next(w for w in app.button if w.label=='Confirm permanent deletion').click().run()
    assert not app.exception and not path.exists()


def test_unfinished_clip_batch_cannot_lose_earlier_completed_clip(tmp_path):
    f,job,path=setup(tmp_path)
    clip=Path(f.pm.root)/'my-clips/clip.mp4';clip.parent.mkdir();clip.write_bytes(b'clip')
    clips=[{'path':str(clip)}]
    (clip.parent/'highlights.partial.json').write_text(json.dumps({'completed_count':1,'selected_count':5}))
    item=gallery_items(f,f.db.list(),clips)['Clips'][0]
    with pytest.raises(ValueError,match='batch is unfinished'):delete_export(f,deletion_preview(item),f.db.list(),clips,[f.pm.root])
    assert clip.exists()

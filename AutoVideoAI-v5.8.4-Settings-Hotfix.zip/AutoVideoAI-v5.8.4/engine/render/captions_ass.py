"""
Caption system - 7 templates, safe zones, narration-timed (word timings in).
Outputs .ass (burn-in) + .srt (sidecar/upload).
"""
from __future__ import annotations
import os
import re

# ASS colors are &HAABBGGRR
TEMPLATES = {
    "MINIMAL":    {"Fontsize": 64, "Primary": "&H00FFFFFF", "Outline": 1, "Shadow": 1, "Bold": 0, "Back": "&H99000000", "word_events": False},
    "HORMOZI":    {"Fontsize": 84, "Primary": "&H00FFFFFF", "Active": "&H0025D1FF", "Outline": 3, "Shadow": 0, "Bold": 1, "word_events": True},
    "DOCUMENTARY":{"Fontsize": 58, "Primary": "&H00F2E8D5", "Outline": 1, "Shadow": 1, "Bold": 0, "word_events": False},
    "CINEMATIC":  {"Fontsize": 62, "Primary": "&H00E8DCC8", "Outline": 2, "Shadow": 2, "Bold": 0, "word_events": False},
    "KARAOKE":    {"Fontsize": 80, "Primary": "&H00FFFFFF", "Active": "&H0025D1FF", "Outline": 3, "Shadow": 0, "Bold": 1, "karaoke": True},
    "TECH":       {"Fontsize": 66, "Primary": "&H00FFD75A", "Outline": 2, "Shadow": 0, "Bold": 1, "word_events": False},
    "KIDS":       {"Fontsize": 88, "Primary": "&H0033CCFF", "Outline": 4, "Shadow": 2, "Bold": 1, "word_events": True, "Active": "&H0042F587"},
    "OPUS":       {"Fontsize": 88, "Primary": "&H00FFFFFF", "Active": "&H004BE36D", "Outline": 4, "Shadow": 2, "Bold": 1, "word_events": True},
}

SAFE_ZONES = {
    "9:16": {"MarginV": 340, "MarginL": 60, "MarginR": 60},   # clear of Reels/Shorts/TikTok UI
    "16:9": {"MarginV": 110, "MarginL": 80, "MarginR": 80},
}


def _fmt_ass(t: float) -> str:
    t = max(0, t)
    h, m = int(t // 3600), int(t % 3600 // 60)
    return f"{h}:{m:02d}:{t % 60:05.2f}"


def _fmt_srt(t: float) -> str:
    t = max(0, t)
    return f"{int(t//3600):02d}:{int(t%3600//60):02d}:{int(t%60):02d},{int(t%1*1000):03d}"


def words_to_phrases(words: list[dict], max_chars: int = 34, max_gap: float = 0.5) -> list[dict]:
    """Punctuation-aware grouping: [{words, start, end, text}]."""
    phrases, cur = [], []
    for w in words:
        if cur and (w["start"] - cur[-1]["end"] > max_gap or
                     len(" ".join(x["word"] for x in cur)) + len(w["word"]) > max_chars or
                     re.search(r"[.!?…]$", cur[-1]["word"])):
            phrases.append(_pack(cur))
            cur = []
        cur.append(w)
    if cur:
        phrases.append(_pack(cur))
    return phrases


def _pack(cur):
    return {"words": cur, "start": cur[0]["start"], "end": cur[-1]["end"],
            "text": " ".join(x["word"] for x in cur)}


def _wrap2(text: str, width: int = 18) -> str:
    words = text.split()
    if len(text) <= width:
        return text
    best, best_diff = 1, 1e9
    for i in range(1, len(words)):
        a, b = " ".join(words[:i]), " ".join(words[i:])
        d = abs(len(a) - len(b)) + (0 if len(a) <= width and len(b) <= width else 50)
        if d < best_diff:
            best, best_diff = i, d
    return " ".join(words[:best]) + "\\N" + " ".join(words[best:])


def build_captions(words: list[dict], out_base: str, template: str = "HORMOZI",
                   aspect: str = "9:16", W: int = 1080, H: int = 1920,
                   keyword_color: str | None = None) -> dict:
    """Writes out_base.ass + out_base.srt. Returns {ass, srt, events}."""
    os.makedirs(os.path.dirname(os.path.abspath(out_base)), exist_ok=True)
    T = TEMPLATES.get(template.upper(), TEMPLATES["HORMOZI"])
    sz = SAFE_ZONES.get(aspect, SAFE_ZONES["9:16"])
    phrases = words_to_phrases(words or [])
    # ASS v4+ requires exactly 23 fields in the Style row, in the same order as
    # the Format declaration below. Older builds accidentally emitted 25 fields
    # (Outline/Shadow were shifted into Spacing/Angle and two extra margins were
    # inserted). libass 0.15.x rejects/mis-parses that row, which is why the
    # primary FFmpeg renderer repeatedly failed and MoviePy became the fallback.
    style = (f"Style: Cap,DejaVu Sans,{T['Fontsize']},{T['Primary']},&H000000FF,"
             f"&H00000000,{T.get('Back','&H00000000')},{-1 if T.get('Bold') else 0},0,0,0,100,100,"
             f"0,0,1,{T.get('Outline',2)},{T.get('Shadow',0)},2,"
             f"{sz['MarginL']},{sz['MarginR']},{sz['MarginV']},1")
    head = ("[Script Info]\nScriptType: v4.00+\nPlayResX: %d\nPlayResY: %d\nWrapStyle: 2\n\n"
            "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
            "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, "
            "Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n%s\n\n"
            "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
            % (W, H, style))
    events, srt = [], []
    active = T.get("Active", "&H0025D1FF")
    for pi, p in enumerate(phrases):
        next_start = phrases[pi + 1]["start"] if pi + 1 < len(phrases) else p["end"] + 0.4
        hard_end = next_start - 0.03  # never overlap the next phrase
        if T.get("word_events"):
            for j, w in enumerate(p["words"]):
                end = p["words"][j+1]["start"] if j + 1 < len(p["words"]) else min(p["end"] + 0.15, p["end"] + 0.4)
                end = min(end, hard_end)
                if end - w["start"] < 0.08:
                    end = min(w["start"] + 0.15, hard_end)
                parts = []
                for k, x in enumerate(p["words"]):
                    c = active if k == j else T["Primary"]
                    parts.append(f"{{\\c{c}}}{x['word']}")
                events.append((_fmt_ass(w["start"]), _fmt_ass(end), _wrap2(" ".join(parts))))
        elif T.get("karaoke"):
            k = "".join(f"{{\\k{max(8,int((x['end']-x['start'])*100))}}}{x['word']} " for x in p["words"])
            events.append((_fmt_ass(p["start"]), _fmt_ass(min(p["end"] + 0.15, hard_end)), _wrap2(f"{{\\c{active}}}{k}")))
        else:
            txt = p["text"]
            if keyword_color:
                for kw in re.findall(r"[A-Za-z]{5,}", txt)[:2]:
                    txt = txt.replace(kw, f"{{\\c{keyword_color}}}{kw}{{\\c{T['Primary']}}}", 1)
            events.append((_fmt_ass(p["start"]), _fmt_ass(min(p["end"] + 0.2, hard_end)), _wrap2(txt)))
        srt.append((p["start"], p["end"], p["text"]))
    with open(out_base + ".ass", "w", encoding="utf-8") as f:
        f.write(head)
        for s, e, t in events:
            f.write(f"Dialogue: 0,{s},{e},Cap,,0,0,0,,{t}\n")
    with open(out_base + ".srt", "w", encoding="utf-8") as f:
        for i, (s, e, t) in enumerate(srt, 1):
            f.write(f"{i}\n{_fmt_srt(s)} --> {_fmt_srt(e)}\n{t}\n\n")
    return {"ass": out_base + ".ass", "srt": out_base + ".srt", "events": len(events)}

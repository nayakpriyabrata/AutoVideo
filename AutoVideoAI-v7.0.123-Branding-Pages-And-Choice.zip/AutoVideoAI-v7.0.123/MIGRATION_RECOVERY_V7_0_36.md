# AutoVideoAI v7.0.36 · migration and storyboard repair

## Recover from the interrupted v7.0.35 migration

Stop Studio and any CLI jobs. Keep your v7.0.35 folder; do not delete it until the new installation has been verified. Unzip v7.0.36 next to it and run from the new folder:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.35 . --apply
python3 tools/migrate_installation.py --repair-paths . --apply
```

The first command copies existing state without altering the source. The second repairs older installation paths whose exact copied counterparts exist, without requiring the deleted v7.0.34 folder. It writes `path-repair-report.json` and backs up changed documents/databases under `migration-backups`.

The interrupted migration copied files before rewriting paths. If those copies remain in v7.0.35, this procedure can reconnect them. If `missing_approved_assets` is not empty, some reviewed B-roll bytes are missing or changed: restore the exact original files from a backup, or explicitly review replacements. The patch never bypasses approved asset hashes and cannot recover deleted files that were never copied.

After the report shows no missing approved assets for this job, render only:

```bash
python3 cli.py v3 render 20261009-192205-why-discipline-beats-mot-15dd
```

No new Flow image/video generation is requested by these commands. The repair preserves existing review decisions and media hashes. Commands stored in diagnostics are retained as historical records; they are not interpreted as filenames or executed.

## Other changes

- Workspace/page selections default to a valid option after session/theme reruns, fixing the attached `KeyError: None`.
- The generative image provider no longer substitutes Pexels photographs into AI storyboards. It sends the full scene prompt (up to the provider's bounded prompt length), preserving cartoon/style/action instructions. Unavailable AI images stop with a clear error rather than publishing an offline placeholder.
- Existing accepted images/videos are preserved. This patch does not replace unrelated footage already accepted in previous jobs. Review and repair those shots before rendering again.
- All v7.0.35 upload preparation, cast attachment pause, Flow Music import, and bounded B-roll rendering changes remain included.

## Review of the attached Kanha output

The output is 44.25 seconds, 1080×1920, with video and audio. The runtime log finishes at NEEDS_REVIEW, with eight image-motion shots and one Flow shot; one requested Flow shot fell back. B-roll was configured to zero for this job. Sampled frames show repeated phone footage and an unrelated live-action woman mixed with cartoon Kanha/Radha. This output should not be treated as a completed faithful cartoon story. Speech caption timing was estimated after ASR timing repair; lip/word sync requires review.

The run took about 73 minutes. Logs explicitly record DNS resolution failures for Flow/Pexels, repeated browser closures during artifact downloads, reference picker problems, and recovery delays. This release fixes the locally reproduced migration/UI/generative fallback defects. It does not claim to have fixed the cause of live WSL Chromium closures or DNS outages; those require live diagnostics. Pending uncertain videos remain download-only and paid generation is not blindly retried.

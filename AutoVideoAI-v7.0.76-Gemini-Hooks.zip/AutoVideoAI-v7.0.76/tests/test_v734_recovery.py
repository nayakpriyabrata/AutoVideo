from types import SimpleNamespace as NS
import json
import pytest


def test_broll_bounds_and_explicit_opt_in():
    from engine.broll import validate_broll_options
    assert validate_broll_options()['broll_count']==0
    assert validate_broll_options(150,2,3,'money saving',True)['broll_max_uses']==3
    for bad in [-1,151,True]:
        with pytest.raises(ValueError):validate_broll_options(broll_count=bad)
    for bad in [0,4,True]:
        with pytest.raises(ValueError):validate_broll_options(broll_max_uses=bad)


def test_saved_broll_review_does_not_search_again(tmp_path,monkeypatch):
    from engine import broll
    path=tmp_path/'broll_review.json';path.write_text(json.dumps({'schema_version':1,'candidates':[]}))
    monkeypatch.setattr(broll,'load_review',lambda p:json.loads(path.read_text()))
    monkeypatch.setattr(broll,'prepare_job_review',lambda *a,**kw:pytest.fail('rerender searched again'))
    f=NS(pm=NS(dirs=lambda job:{'render':str(tmp_path)}))
    assert broll.prepare_saved_production_broll(f,'job',{'broll_count':150},lambda *a:None)['candidates']==[]


def test_exhausted_reference_prevents_any_picker_action(tmp_path):
    from engine.providers.flow_browser import FlowBrowser,FlowReferenceUnavailable
    path=tmp_path/'photo.jpg';path.write_bytes(b'exact original')
    b=FlowBrowser.__new__(FlowBrowser)
    url='https://flow.google.com/project/30b788b0-6d77-4f10-874b-3ff80babd21c'
    b.current_project_url=lambda:url
    alias=b._media_upload_alias(str(path))
    b._unavailable_reference_aliases={(url,alias)}
    b._agent_reference_names=lambda:pytest.fail('opened exhausted picker')
    with pytest.raises(FlowReferenceUnavailable,match='exhausted'):
        b.attach_agent_media([str(path)])


def test_login_stays_open_until_owned_handoff(tmp_path):
    from engine.flow_music import wait_for_manual_login
    ticks=[]
    def wait(ms):
        ticks.append(ms)
        if len(ticks)==2:
            (tmp_path/'.autovideo-login-control.json').write_text(json.dumps({'token':'owned','action':'handoff'}))
    browser=NS(page=NS(is_closed=lambda:False,wait_for_timeout=wait),composer=lambda:None)
    result=wait_for_manual_login(browser,tmp_path,token='owned',seconds=10)
    assert result['auth_ready'] and ticks==[1000,1000]
    assert json.loads((tmp_path/'.autovideo-login.json').read_text())['state']=='closed'


def test_unsigned_login_handoff_is_rejected_without_closing(monkeypatch):
    from engine import flow_music
    monkeypatch.setattr(flow_music,'login_status',lambda:{'state':'login-open','auth_ready':False})
    with pytest.raises(RuntimeError,match='window remains open'):
        flow_music.finish_login(require_ready=True)


def test_exact_picker_filename_can_be_image_alt():
    from engine.providers.flow_browser import FlowBrowser
    b=FlowBrowser.__new__(FlowBrowser);selectors=[];row=object()
    b._page=NS(get_by_text=lambda *a,**kw:NS(count=lambda:0),locator=lambda s:selectors.append(s) or row)
    assert b._exact_reference_rows('AV_123_character.jpg') is row
    assert any('img[alt="AV_123_character.jpg"]' in selector for selector in selectors)


def test_large_broll_request_spreads_nonoverlapping_cuts():
    from engine.broll import _job_slots
    shot=NS(shot_id='s1',voice_start=0,voice_end=100,narration='saving money',visual_goal='counting money',stock_query='',provider='image',actual_provider='image')
    f=NS(pm=NS(load_manifest=lambda job:NS(shots=[shot],aspect='16:9')))
    slots,vertical=_job_slots(f,'job',150,2)
    assert len(slots)==40 and not vertical
    assert all(a['start']+a['duration']<=b['start'] for a,b in zip(slots,slots[1:]))
    assert slots[-1]['start']+slots[-1]['duration']<=100


def test_broll_reuses_only_same_query_and_stops_at_cap(tmp_path,monkeypatch):
    from engine import broll
    from engine.providers.stock_provider import StockProvider
    monkeypatch.setattr(StockProvider,'_pick_local',classmethod(lambda cls,*a,**kw:None))
    stock=tmp_path/'original.mp4';stock.write_bytes(b'v'*60000)
    calls=[]
    def search(*a,**kw):
        calls.append(a)
        return {'clips':[str(stock)],'metadata':[{'source':'test','asset_id':'one'}]} if len(calls)==1 else {'clips':[]}
    monkeypatch.setattr('engine.stock_video.get_stock_videos',search)
    monkeypatch.setattr(broll,'_file_duration',lambda p:5)
    slots=[{'candidate_id':f'c{i}','query':'counting money' if i<4 else 'ocean','duration':2,'max_uses_per_asset':3} for i in range(5)]
    rows=broll._fetch_candidates(slots,str(tmp_path/'assets'),False)
    assert [r['status'] for r in rows]==['ready','not_found','not_found','not_found','not_found']
    assert [r['asset_use_number'] for r in rows[:3]]==[1,2,3]
    assert len(calls)==5  # Always seek a new asset before using an existing one.


def test_character_background_beats_global_theme(tmp_path):
    from engine.studio_widgets import character_cards
    from PIL import Image
    from contextlib import nullcontext
    p=tmp_path/'photo.png';Image.new('RGB',(140,160),'red').save(p)
    styles=[]
    st=NS(columns=lambda n:[NS(container=lambda **kw:nullcontext())]*n,markdown=lambda value,**kw:styles.append(value),dialog=lambda *a,**kw:lambda fn:fn,button=lambda *a,**kw:False)
    character_cards(st,[{'id':'test','name':'Face','references':[{'path':str(p)}]}])
    background=styles[0].split('background:',1)[1].split(';color:',1)[0]
    assert 'data:image/jpeg;base64,' in background and background.endswith('!important')
    # Card rule follows the global theme rule at equal specificity/importance.
    assert '.st-key-char-' in styles[0] and 'button p{color:white!important' in styles[0]


def test_uploads_tab_is_scoped_to_reference_picker():
    from engine.providers.flow_browser import FlowBrowser
    b=FlowBrowser.__new__(FlowBrowser);clicked=[]
    tab=NS(is_visible=lambda **kw:True,click=lambda **kw:clicked.append('picker-uploads'))
    picker=NS(get_by_text=lambda name,**kw:NS(count=lambda:1,nth=lambda i:tab))
    selectors=[]
    b._page=NS(evaluate=lambda js:'Search assets' in js,locator=lambda s:selectors.append(s) or picker,wait_for_timeout=lambda ms:None)
    b._click_text_action=lambda *a,**kw:pytest.fail('clicked global sidebar')
    assert b._picker_uploads() and clicked==['picker-uploads']
    assert selectors==['[data-av-reference-picker="true"]']


def test_factory_reads_saved_broll_and_leaves_legacy_off(tmp_path,monkeypatch):
    from engine.factory import Factory
    f=Factory.__new__(Factory)
    root=tmp_path/'job';root.mkdir()
    f.pm=NS(job_dir=lambda job:str(root))
    # _settings accepts a minimal saved JSON without submitting any providers.
    (root/'settings.json').write_text(json.dumps({'broll_count':150,'broll_max_uses':3,'broll_auto':True}))
    options=f._settings('job')
    assert options['broll_count']==150 and options['broll_max_uses']==3 and options['broll_auto']
    (root/'settings.json').write_text('{}')
    assert f._settings('job')['broll_count']==0

"""Separate Gemini Web editorial card draft and deterministic render handoff."""
import json
import math
from pathlib import Path


def validate_cards(data, duration):
    cards = data.get('cards') if isinstance(data, dict) else None
    if not isinstance(cards, list) or len(cards) > 18:
        raise ValueError('Use at most 18 reviewed cards')
    checked = []
    for row in cards:
        if not isinstance(row, dict):
            raise ValueError('Each card needs start, end and text')
        start, end = row.get('start'), row.get('end')
        text = row.get('text')
        if (type(start) not in (int, float) or type(end) not in (int, float)
                or not math.isfinite(start) or not math.isfinite(end)
                or not 0 <= start < end <= duration or end-start > 6):
            raise ValueError('Card timings must fit the requested duration and last at most six seconds')
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 80 or '\n' in text:
            raise ValueError('Keep each card to one short line (at most 80 characters)')
        if checked and start < checked[-1]['end'] + .15:
            raise ValueError('Cards must be ordered and cannot overlap')
        checked.append({'start': float(start), 'end': float(end), 'text': text.strip()})
    return checked


def draft_cards(script, duration, language, cleanup='delete-after-read'):
    from .finishing_studio import propose_cards
    result = propose_cards(script, duration, language, cleanup=cleanup)
    return {'cards': validate_cards(result, duration), 'duration': float(duration),
            'language': language, 'source': 'gemini-web-reviewed-draft'}


def render_reviewed_cards(root, actual_duration, width, height, style):
    path = Path(root) / 'production' / 'reviewed_cards.json'
    if not path.is_file():
        return None
    data = json.loads(path.read_text(encoding='utf-8'))
    requested = float(data['duration'])
    if requested <= 0:
        raise ValueError('Invalid reviewed card duration')
    cards = validate_cards(data, requested)
    from .render.graphics import OverlayEvent, render_overlay_png
    overlays = []
    for i, card in enumerate(cards):
        start, end = (card[k] * actual_duration / requested for k in ('start', 'end'))
        event = OverlayEvent('keypoint', start, end, card['text'], anchor='top-left')
        target = Path(root) / 'render' / 'graphics' / f'reviewed-card-{i:02d}.png'
        render_overlay_png(event, str(target), int(width), int(height), style=style)
        overlays.append(event.to_dict())
    return overlays

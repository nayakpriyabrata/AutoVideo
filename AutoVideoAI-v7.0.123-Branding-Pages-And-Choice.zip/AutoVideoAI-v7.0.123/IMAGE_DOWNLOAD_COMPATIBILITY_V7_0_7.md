# v7.0.7 — Browser-managed Flow image recovery

The supplied v7.0.6 log finds the exact location-master asset and receives its download event, then rejects saving within the same second. That is a compatibility/save failure, not evidence that generation never happened. The screenshot confirms that a location image is present; neither attachment discloses the event URL or browser artifact error.

## Correction

v7.0.6 removed browser-managed image saving to avoid an unbounded save call. Its independent HTTPS-only path cannot handle a browser-local blob URL or an endpoint that needs the signed-in browser context. This was a regression. v7.0.7 first saves the exact browser Download artifact on its owning Playwright loop with a 120-second timeout. Only a timed-out download is cancelled, with a separate bounded 3-second cancellation wait. No Flow generation is cancelled or resubmitted.

The saved image is checked for size, dimensions, integrity and full decoding before atomic replacement. Invalid or incomplete files cannot replace the target. If browser saving fails, the existing bounded, validated Google HTTPS fallback remains available. Blob URLs are never fetched outside the browser; browser credentials are never copied into a separate HTTP request. Error messages contain a safe failure category and URL scheme, never a signed URL.

This uses a small, capability-checked sync/async Playwright adapter because the synchronous save method has no timeout option. Regression tests exercise it with the actual Playwright event-loop/sync bridge and async Download wrapper; a browser or signed-in Google session is not required for those checks. If an incompatible Playwright release removes that bridge, the adapter reports unavailable and uses the HTTPS fallback rather than making an unbounded call.

## Recover this saved recreation

1. Stop Studio and any CLI/runner producer once. Back up the installation and job before upgrading.
2. Keep the old installation path and preserve `outputs`, `data`, local configuration, `.env`, browser profiles, worker bindings, `.flow-request.json` and `.recovery.json` files. Update application source to v7.0.7 using the same WSL Python environment, then restart Studio. `cat VERSION` must show 7.0.7.
3. Resume the same job in Queue or run:

   python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6

Resume first recovers `storyboard/location_master.jpg` from the recorded project and exact saved request. Already generated requests keep their journals; you do not need to create a replacement job, delete the journal, change the image source, or click Generate again in Flow.

If you want automatic pausing, check the Queue option and click **Save Flow recovery choice** before Resume. Merely checking the form does not save the choice. Queue now displays the actual saved policy and current job status. Opening Queue no longer writes a synthetic legacy pause record. An old legacy record does not override a failed manifest or claim that pausing is enabled.

Expected successful log: `Exact browser image artifact validated and saved; no HTTP re-download needed.` If it still fails, the new message distinguishes artifact timeout, unavailable adapter, invalid/storage error or save failure, and identifies whether the event used HTTPS/blob/another scheme. Keep the request journal and send that new failure detail.

## Limits

Live Google Flow, the user's Windows/WSL session and this job's actual Download object were not accessed. The patch covers the confirmed v7.0.6 regression and tests browser-local/authenticated artifact saving, but cannot guarantee external provider availability. All prior v7.0.5/v7.0.6 features remain included. No provider generation, credit approval, external upload or public publication was performed.

## v7.0.7 validation

The complete engine suite passed: 691 tests (12 existing dependency deprecation warnings). Control-center checks passed: 27 tests and the configured syntax/check command. Native image-save tests exercised the installed Playwright sync bridge and async Download wrapper with controlled artifacts, including browser-local and authenticated HTTPS event URLs, timeout cancellation, invalid data, and preservation of an existing target. These tests did not launch Chromium or verify the user’s live WSL/Google session.

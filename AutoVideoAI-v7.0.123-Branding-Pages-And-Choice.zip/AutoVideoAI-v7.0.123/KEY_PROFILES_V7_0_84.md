# Gemini key profiles from .env (v7.0.84)

## What was reported

Two extra keys were added to `.env` as `GEMINI_API_KEY_<NAME>`. Create step 4 showed only the default key and one
extra profile.

## Causes addressed

1. **Keys added after the dashboard started were not seen.** `.env` was read once, at start-up.
2. **Some names were silently ignored.** Only uppercase names with letters, digits and underscores were accepted.
   Lowercase names, hyphens, and digits written straight after `GEMINI_API_KEY` (for example `GEMINI_API_KEY2`) were
   not.
3. **Two entries with the same name collapsed into one profile.** For example, `GEMINI_API_KEY_ASUS` and
   `gemini_api_key_asus`. Only one is used.

## What changed

- Key profiles are read from the process environment and from the `.env` files on each page refresh. A new key
  appears without restarting the dashboard.
- Names are matched without regard to case. `GEMINI_API_KEY_<NAME>`, `GEMINI_API_KEY-<NAME>` and `GEMINI_API_KEY<digits>`
  are all accepted. `GEMINI_API_KEYS_X` is not, because it is not a profile name.
- When two entries define the same profile, the uppercase `GEMINI_API_KEY_<NAME>` spelling is used.
- Create step 4 shows a line under the route pickers for every entry that is not used, with the name and the reason.
  Values are never shown.
- A value already loaded at start-up is not changed by a later edit to `.env`. Restart the dashboard after editing the
  value of an existing key.

## Files

- `engine/audio/tts.py`: `gemini_env_files`, `gemini_key_profiles`, `gemini_key_problems`, `gemini_api_key`.
- `app.py`: route pickers show ignored entries.
- `tests/test_v784_key_profiles.py` (new): 6 tests.
- `tests/test_v782_tts_routes.py`: its fixture keeps real `.env` files out of the tests.
- `tools/update_v783_to_v784.py`: updater from 7.0.83.

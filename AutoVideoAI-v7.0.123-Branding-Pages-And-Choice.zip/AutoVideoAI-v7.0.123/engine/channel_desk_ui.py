"""A channel-manager workflow over local evidence, not a virality score."""
import json
from pathlib import Path
from . import channel_desk as desk
from .finishing_studio import shared_root
from .production import read,save,digest


def show(st):
    st.title('Channel Desk')
    st.caption('Plan the promise → watch the export → learn from your own channel. No automatic posting or generation credits.')
    root=shared_root()/'channel_desk';root.mkdir(parents=True,exist_ok=True)
    tabs=st.tabs(['Editorial brief','Watch & listen review','Channel performance'])
    with tabs[0]:
        title=st.text_input('Working title',key='cd-title')
        audience=st.text_input('Who is this for?',placeholder='For example: first-job professionals preparing for interviews',key='cd-audience')
        promise=st.text_area('What useful outcome will this video deliver?',key='cd-promise')
        script=st.text_area('Reviewed script / source transcript',height=220,key='cd-script',help='Gemini receives text only. This does not inspect your video.')
        language=st.selectbox('Copy language',['en','hi','or'],key='cd-language')
        destination=st.selectbox('Editorial destination',list(desk.PROFILES),key='cd-destination')
        cleanup=st.selectbox('Draft chat cleanup',['delete-after-read','keep'],key='cd-cleanup')
        if st.button('Ask Gemini Web for three title, hook and thumbnail briefs',key='cd-draft'):
            try:
                from .production_lock import production_slot
                import uuid
                target=root/'briefs'/(uuid.uuid4().hex+'.json')
                with production_slot(root/'draft-session'),st.spinner('Preparing grounded alternatives from your script'):
                    desk.draft_package(dict(title=title,audience=audience,promise=promise,script=script,language=language,destination=destination),target,cleanup)
                st.session_state['cd-brief-path']=str(target)
            except Exception as exc:st.error(str(exc))
        drafts=sorted((root/'briefs').glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True) if (root/'briefs').exists() else []
        if drafts:
            chosen=st.selectbox('Saved editorial draft',drafts,format_func=lambda p:p.stem,key='cd-saved-brief')
            data=read(chosen)
            for index,row in enumerate(data['draft']['variants'],1):
                with st.expander('Alternative '+str(index)+' · '+row['title'],expanded=index==1):
                    st.write('Opening: '+row['hook']);st.write('Thumbnail design brief: '+row['thumbnail_brief']);st.caption('Script evidence: '+row['evidence_quote'])
            st.write('Closing action: '+data['draft']['closing_action']);st.write(data['draft']['editor_notes'])
            st.download_button('Download editorial draft',chosen.read_bytes(),file_name=chosen.name,mime='application/json')
            st.info('These are unapproved suggestions. Review before copying into the script or Publishing Desk. No video edit or native A/B test has been started.')
    with tabs[1]:
        from .studio_review import discover_clips
        choices={r['path']:r['label'] for r in discover_clips()}
        output=shared_root()/'outputs'
        if output.is_dir():
            for p in output.glob('*/render/*-final*.mp4'):choices[str(p.resolve())]=p.parent.parent.name+' / '+p.name
        selection=st.selectbox('Saved export',['Choose local path']+list(choices),format_func=lambda p:choices.get(p,p),key='cd-export')
        source=st.text_input('Exact local MP4/MOV path',value='' if selection=='Choose local path' else selection,key='cd-source-'+str(selection))
        destination=st.selectbox('Review for destination',list(desk.PROFILES),key='cd-review-destination')
        expected=st.checkbox('This export should contain audible sound',value=True,key='cd-audio')
        if st.button('Build watch/listen review pack',key='cd-review'):
            bar=st.progress(0);status=st.empty()
            def progress(message,pct,detail=''):
                bar.progress(max(0,min(100,int(pct))));status.write(message+(' · '+detail if detail else ''))
            try:
                result=desk.review_video(source,root/'reviews',destination,audio_expected=expected,progress=progress)
                st.session_state['cd-review-path']=result['review_path']
            except Exception as exc:st.error(str(exc))
        reviews=sorted((root/'reviews').glob('*/review.json'),key=lambda p:p.stat().st_mtime,reverse=True) if (root/'reviews').exists() else []
        if reviews:
            chosen=st.selectbox('Saved review packs',reviews,format_func=lambda p:read(p).get('source',''),key='cd-saved-review')
            data=read(chosen)
            try:current=Path(data['source']).is_file() and digest(data['source'])==data['source_sha256']
            except OSError:current=False
            if not current:st.error('Source is missing or changed. This review is stale; rebuild it.')
            st.caption(data['status']+' · '+data['destination']+' · '+str(round(data['duration'],1))+' seconds')
            a,b=st.columns(2)
            with a:st.write('First 30 seconds');st.video(data['previews']['opening'])
            with b:st.write('Final 15 seconds');st.video(data['previews']['closing'])
            st.image(data['contact_sheet'],caption='Timestamped samples only; watch the full export before signoff.')
            st.json(data['analysis'])
            if data['issues']:st.dataframe(data['issues'],use_container_width=True)
            else:st.info('No configured technical warning was detected. Editorial, music and language review still remain.')
            with st.expander('Shot pacing and music trace'):
                try:st.json(desk.job_context(data['source']))
                except Exception as exc:st.warning('Saved plan context unavailable: '+str(exc))
            checks={k:st.checkbox(v,key='cd-check-'+chosen.parent.name+'-'+k) for k,v in desk.REVIEW_CHECKS.items()}
            notes=st.text_area('Review notes / explain any intentional measured warnings',key='cd-notes-'+chosen.parent.name)
            if st.button('Record editorial signoff for this exact file',disabled=not current,key='cd-sign-'+chosen.parent.name):
                try:desk.editorial_signoff(chosen,checks,notes);st.success('Editorial signoff saved. Rights and disclosure choices remain in Publishing Desk.')
                except Exception as exc:st.error(str(exc))
            st.download_button('Download review evidence JSON',chosen.read_bytes(),file_name='channel-review.json',mime='application/json')
    with tabs[2]:
        st.write('Compare like-for-like posts within each channel, destination, language, duration group and reporting window.')
        st.caption('Use the normalized template below. Map your own platform export columns first. views and watch_seconds must refer to the same population/window (for example engaged views and their watch time). This is not a universal native CSV importer.')
        st.download_button('Download metrics CSV template',desk.METRICS_TEMPLATE,file_name='channel-metrics-template.csv',mime='text/csv')
        uploaded=st.file_uploader('Normalized owned-channel metrics CSV',type=['csv'],key='cd-metrics')
        if st.button('Import metric snapshot',disabled=uploaded is None,key='cd-import'):
            try:
                if uploaded.size>10*1024*1024:raise ValueError('CSV limit is 10 MB')
                rows=desk.parse_metrics(uploaded.getvalue().decode('utf-8-sig'))
                # Replace the current analysis dataset explicitly, preserve timestamped imports.
                import uuid
                save(root/'metrics'/('import-'+uuid.uuid4().hex+'.json'),{'rows':rows})
                save(root/'metrics/current.json',{'rows':rows});st.success('Imported '+str(len(rows))+' rows; previous imports retained.')
            except Exception as exc:st.error(str(exc))
        current=read(root/'metrics/current.json',{})
        if current:
            minimum=st.number_input('Minimum views per post for this comparison',min_value=1,max_value=1000000000,value=100,key='cd-minviews')
            summary=desk.metrics_summary(current['rows'],minimum)
            st.dataframe(summary['cohorts'],use_container_width=True);st.caption(summary['notice'])
            st.write('Posts excluded for low views: '+str(summary['excluded_low_views']))
            st.info('Use low opening retention to investigate title/hook mismatch; inspect drop-offs before adding effects. These observational comparisons cannot establish which change caused an outcome.')

# AutoVideoAI 7.0.15 — character reference reuse and complete scene briefs

The supplied WSL log confirms shot 4 recovered after browser-download retries,
shot 5 downloaded, and shot 6’s closing frame then failed exact matching.
The saved character and location references were successfully reused at shot 6.
No character-upload rejection appears in that failing request. The screenshot
also shows a Chromium crash-recovery notice; the crash's root cause is unknown.

A reference must be attached to each prompt so Flow can use its identity. This
is different from uploading the same file again. Skipping reference verification
would risk selecting an unrelated character. This build records successful
uploads per exact project and content-hashed filename; when an already recorded
reference cannot be selected, it blocks duplicate uploading and reports that
specific picker problem before generation. Reuse still needs the exact asset
available in the project's media picker. A new project or changed photo gets
its own upload. New records start with this build; older picker reuse remains.
Local photo hashes do not disable any checks performed by Flow itself.

For photo-backed storyboard prompts, this build replaces the repeated long
character-description block with the character ID and original-photo authority.
It retains OPEN/CLOSE timing, action, location, narrative, camera and style.
Unknown templates are retained. Oversized image prompts now stop before sending
instead of silently truncating. Existing submitted requests and their saved
prompts are unchanged, so Resume does not submit a modified replacement.

## Current job limitation

The report contains a wide OPEN frame for scene 6. Its other visible CLOSE
candidate describes teaching script pattern/tone and uses medium framing;
it does not prove the requested wide scene-6 closing frame. Four media prompts
could not be read. This build does not bind either image by resemblance, nor
claim that the unresolved request has recovered. Exact asset review may still
be needed if a fresh Resume cannot read and match that saved closing frame.

## Upgrade

Stop Studio, runner and CLI jobs. In the new extracted directory:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.14 . --apply
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6
```

Resume remains download-only for the pending request. The improvements apply to
future frame submissions and all workflows using this shared Flow provider.
Keep the previous installation until the migration and the new run are verified.

"""One pop-up card on screen at a time (v7.0.116).

Field report, Odia edition: a video frame showed **two cards overlapping** - one bold KEY POINT panel with Odia text,
and, a fraction of a second out of step, a second panel of the same shape carrying the rest of the sentence. The
screenshot showed both at once, the second half-hidden behind the first.

Both were real, drawn by the same render from two different sources:

* the **job's copied cards** - ``bundle['cards']``, written by the original English card draft and stored on the
  language's narration. ``render()`` draws each one as an image over the whole frame;
* the **edition's own drafted cards** - ``production/speech_cards.json``, drafted for this language from its own
  reviewed narration, and drawn by ``speech_cards.render()``.

Both sets are anchored to the same spoken sentence, so when their windows differ by a few tenths of a second they
overlap - two panels on screen, one over the other. Nothing checked: the copied cards were drawn in their own loop,
the drafted cards in another, and only hooks were ever compared against cards.

This module is that check. It is pure - windows in, windows out - so the rule can be tested without a video:

* only one **card** may occupy the screen at a time (``CARD_KINDS``: keypoint, takeaway, tip, warning, points);
* hooks are not cards: they are small pills in their own band and are never dropped here;
* when two cards collide, the one drawn from the language's *own drafted file* wins, because that is the one
  written for this narration, in this language; the other is reported, not silently discarded;
* a card keeps a short gap from its neighbours, so a card cannot be replaced by another mid-fade.
"""
from __future__ import annotations

CARD_KINDS = frozenset({'keypoint', 'takeaway', 'tip', 'warning', 'points'})

#: Clear screen between two cards, in seconds. Both card renderers fade over 0.22s, so this is a visible beat.
MIN_GAP = 0.15

#: Preference between two colliding cards. Higher wins.
PRIORITY = {'the edition card file': 3, 'the job card copy': 2, 'a hook': 0}


def is_card(kind) -> bool:
    return str(kind or '').strip().lower() in CARD_KINDS


def _window(entry):
    try:
        start = float(entry.get('start'))
        end = float(entry.get('end'))
    except (TypeError, ValueError, AttributeError):
        return None
    if end <= start:
        return None
    return start, end


def conflicts(entries, *, gap=MIN_GAP):
    """Every pair of cards that share the screen, with how long they share it."""
    rows = []
    for entry in entries or []:
        window = _window(entry)
        if window:
            rows.append((window, entry))
    rows.sort(key=lambda pair: pair[0])
    found = []
    for index, (first, one) in enumerate(rows):
        for second, other in rows[index + 1:]:
            if second[0] >= first[1] + gap:
                break
            shared = round(min(first[1], second[1]) - max(first[0], second[0]), 3)
            found.append({'first': _text(one), 'second': _text(other),
                          'first_window': [round(first[0], 3), round(first[1], 3)],
                          'second_window': [round(second[0], 3), round(second[1], 3)],
                          'shared_seconds': max(0.0, shared)})
    return found


def _text(entry):
    return ' '.join(str(entry.get('title') or entry.get('text') or entry.get('spoken_anchor') or '')
                    .split())[:120]


def resolve(entries, *, gap=MIN_GAP, report=None):
    """Return the cards that may be drawn: the same dicts, in time order, never overlapping.

    Pass **cards only** (``is_card``); hooks are a different band and are placed against the cards elsewhere.

    ``report`` (a dict, when given) receives ``considered``, ``kept``, ``dropped`` and one ``conflicts`` row per
    card that gave way - what it was, what kept the screen, and how much they would have shared.
    """
    rows = []
    for index, entry in enumerate(entries or []):
        window = _window(entry)
        if window is None:
            if report is not None:
                report.setdefault('dropped', []).append(
                    {'text': _text(entry), 'reason': 'it has no usable time on screen'})
            continue
        rows.append((window[0], window[1], index, entry))
    rows.sort(key=lambda row: (row[0], -row[1], -PRIORITY.get(str(row[3].get('source') or ''), 1), row[2]))
    kept = []
    dropped = []
    for start, end, _index, entry in rows:
        if kept:
            last_start, last_end, _i, last = kept[-1]
            if start < last_end + gap:
                kept_seconds = round(last_end - start, 3) if start < last_end else 0.0
                dropped.append({'text': _text(entry), 'reason': 'the screen still showed the card before it',
                                'kept': _text(last), 'would_share_seconds': max(0.0, kept_seconds),
                                'start': round(start, 3), 'end': round(end, 3)})
                continue
        kept.append((start, end, _index, entry))
    if report is not None:
        report['considered'] = len(rows)
        report['kept'] = len(kept)
        report['dropped_count'] = len(dropped)
        report.setdefault('dropped', []).extend(dropped)
    return [entry for _start, _end, _index, entry in kept]


def max_at_once(entries, *, gap=0.0):
    """How many of these cards can be on screen at the same instant. After ``resolve`` this must be 1."""
    rows = sorted(window for window in (_window(entry) for entry in entries or []) if window)
    highest = 0
    for index, (start, _end) in enumerate(rows):
        live = sum(1 for other_start, other_end in rows
                   if other_start <= start + gap and other_end > start + gap)
        highest = max(highest, live)
    return highest


def describe(report) -> str:
    """One sentence for the job record: what was drawn, and what gave way."""
    report = report or {}
    dropped = list(report.get('dropped') or [])
    if not dropped:
        return ''
    first = dropped[0]
    shared = f" ({first['would_share_seconds']:.1f}s of overlap)" if first.get('would_share_seconds') else ''
    if str(first.get('text') or '').strip() == str(first.get('kept') or '').strip():
        sentence = ('The same card was scheduled twice for this moment - once by the job card copy and once by the '
                    'edition card file - so it was drawn once' + shared + ', from the edition card file')
    else:
        sentence = ('Two cards would have been on screen at the same time, so only one was drawn: '
                    + str(first.get('text') or 'a card') + ' was dropped because '
                    + str(first.get('kept') or 'another card') + ' was already showing' + shared)
    if len(dropped) == 2:
        sentence += '; one more card was dropped for the same reason'
    elif len(dropped) > 2:
        sentence += '; ' + str(len(dropped) - 1) + ' more cards were dropped for the same reason'
    return sentence + '. Nothing else was re-recorded or re-rendered.'

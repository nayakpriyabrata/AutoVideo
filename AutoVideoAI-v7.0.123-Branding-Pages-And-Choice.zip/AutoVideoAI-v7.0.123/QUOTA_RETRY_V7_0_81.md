# AutoVideo 7.0.81 — Gemini daily limit stops the run at once

Update from 7.0.80 with `python3 ../AutoVideoAI-v7.0.81/tools/update_v780_to_v781.py . --apply`
(dry run first without `--apply`; stop the dashboard before applying).

## What happened

The error was `HTTP 429 … Rate limit exceeded for model gemini-3.8-flash-tts (limit: 10 requests per day on Free Tier)`.

- That is a **daily** limit, counted per Google Cloud project and per model. Google resets it at midnight Pacific time.
- 7.0.80 retried every 429 three times. Each retry is a counted request, so one exhausted daily quota cost three
  requests per failing part. This was a bug in 7.0.80.
- A narration is sent in parts of up to 1200 characters, and each language is its own set of requests. A three-language
  batch can need more than 10 requests before any retry.

## What changed

- `engine/audio/tts.py`
  - A 429 whose body says "per day" raises `GeminiQuotaExceeded` immediately. No retry is sent.
  - A per-minute 429 waits 65 seconds before the next attempt (up to 3 attempts), because a shorter wait hits the same window.
  - The error states how many parts are saved. Saved parts are kept in `<narration>.parts/`, so the next run continues from the
    first unsaved part and does not resend finished parts.
  - For Odia, a quota error is reported as a quota error, not as a missing native voice file.
  - In the auto chain, a quota error on `gemini` still falls back to `gemini-lite`. That model has its own daily limit.
- `tests/test_v781_quota_retry.py`: five tests (daily limit sent once; per-minute wait then retry; partial run resumes with
  only the unsaved parts; Odia quota message; other 400 errors still fail at once).

## Options to get more Gemini TTS capacity

1. **Do not add several Google accounts or keys to get around the limit.** Limits are per project, so extra keys in the same
   project add nothing. Using several accounts to get past a quota is likely a breach of Google's terms. Keep to one account.
2. **Link billing to the project (Tier 1) and request a higher TTS limit.** Google's rate-limit page shows the live limit per project in Google AI Studio. Third-party reports from October 2026 say the TTS daily limit
   stayed at 100 on Tier 1 until an increase was requested, so check the limit shown in Google AI Studio after linking billing. Those reports say increases are requested through Google's application form.
3. **Choose `gemini-lite` in the TTS setting** when `gemini` is exhausted. It has its own daily limit. Check the Odia voice
   quality on a short test before relying on it.
4. **Sarvam Bulbul v3 supports Odia (`od-IN`).** It is a separate API with its own key and pricing, and it would need a new
   provider in the code. Not implemented in 7.0.81.
5. **Import a native Odia voice file.** Still not available per language (see 7.0.80 notes).

## Not verified

- Whether a 429 for the daily limit also counts against the quota. It was assumed, and sending no retries is safe either way.
- Live Gemini behaviour from the build sandbox. The 429 and retry paths are tested with a fake server.

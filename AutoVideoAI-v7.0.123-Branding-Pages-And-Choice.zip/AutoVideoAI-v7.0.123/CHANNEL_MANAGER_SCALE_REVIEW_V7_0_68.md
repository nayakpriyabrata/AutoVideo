# AutoVideoAI: scale review for large channel operations (v7.0.68)

Reviewed 20 October 2026 against the v7.0.68 source. Target operations for this review:

- one YouTube channel with about 100 million views, or the equivalent scale of audience;
- one Instagram account with about 10 million followers;
- one Facebook page with about 10 million followers.

The question was not whether the tool can make attractive videos. It was: **what would break, or create platform risk, if an operator used it to run channels at that scale?**

## Verdict

AutoVideoAI is a supervised production workstation. It is not yet an operations platform for channels of that size. Three things block that use, in order of importance:

1. **No native publishing or analytics.** The tool exports files and records a local schedule. It does not upload to YouTube, Instagram or Facebook, and it does not pull platform analytics. Channel Desk only imports a CSV you prepare. At 10 million followers, every publish decision needs platform-side evidence (watch time, retention, reach, comments and policy notices), and the tool cannot read any of it.
2. **Browser-driven generation is a dependency, not a service.** Flow and Gemini Web are driven through a signed-in Chrome profile. Their UI changes without notice. The tool now has conservative recovery and resume rules, but no account-level monitor, no alerting, and no way to run unattended safely.
3. **Single-owner local state.** Jobs, journals and ledgers are JSON files on one Windows/WSL machine, with a single production lock. There is no role-based approval, no audit log that survives tampering, and no backup or restore procedure beyond copying the folder.

## Platform constraints that shape the design

- **YouTube upload quota.** Google's quota page lists `videos.insert` at 100 calls per day per Google Cloud project, counted in its own bucket. A 100-million-view operation publishing across several channels therefore needs deliberate quota planning, such as separate projects or an approved quota extension. The tool has no quota ledger, so it cannot warn before a batch hits the limit. Source: [Google Developers, videos.insert quota](https://developers.google.com/youtube/v3/docs/videos/insert) and [quota calculator](https://developers.google.com/youtube/data/determine_quota_cost). Check the current quota page before relying on these numbers.
- **Identical content across channels.** Reusing one rendered file on several channels, or near-identical files with a changed title, can trigger platform spam or duplicate-content review. I have not verified current platform thresholds. The tool records a SHA-256 for exports and review packs, but it does not compare those hashes across channels or destinations. The 7.0.68 guard (`engine/delivery_duplicates.py`) now runs when a delivery is approved or scheduled; see the first P0 item.
- **Platform terms and disclosure.** Synthetic or altered content, paid promotion and music rights are platform-specific. Channel Desk records rights and disclosure as operator fields. It does not check them against current platform rules.

## What is already useful (verified in code)

| Area | Evidence | Assessment at scale |
|---|---|---|
| Flow and Gemini request journals | `engine/flow_project_cleanup.py`, `engine/providers/gemini_video.py` | Conservative. A request is not resubmitted after an uncertain click. Good for cost control. |
| Final-file QC | v7.0.66 Channel Desk review (see `CHANNEL_MANAGER_AUDIT_V7_0_66.md`) | Good. Reviews the exact export and records the hash. |
| Metrics import | `engine/channel_desk.py` (`parse_metrics`, `metrics_summary`) | Useful for a monthly CSV. Not a substitute for live analytics. |
| Language editions | v7.0.67 and v7.0.68 | Works for English, Hindi and Odia. Needs one live Flow/Gemini test per language. |

## Changes made in v7.0.68 for this review

1. **Gemini Web video downloads wait for a loaded tile.** Gemini shows "I'm generating your video" before the file exists, and the tile can appear as a placeholder. The old check accepted metadata only (`readyState >= 1`). The download now starts only after the video is decoded (`readyState >= 3`), has a duration, and its source has not changed for 2 seconds. Covered by `tests/test_v768_gemini_video_settle.py`.
2. **Flow project cleanup remains gated.** This review did not loosen deletion rules. See "Open decisions" below.

## Ranked feature list (what I would build next, with acceptance tests)

| Rank | Feature | Why it matters at scale | Acceptance test |
|---|---|---|---|
| P0 | **Cross-channel duplicate guard.** Before a delivery is recorded, compare its SHA-256 and near-duplicate fingerprint against every other delivery in the same workspace. | Prevents accidental reuse of one file across several channels. | Two channels given the same export are flagged; a re-export with changed content is not. **Status (7.0.68): implemented at approval and scheduling, not at export.** Identical bytes approved or scheduled for another account are blocked. A near-duplicate (8 sampled frames, 9x8 dHash, mean Hamming distance at most 10 of 64 bits, durations within 2%) needs explicit acknowledgment. The threshold is a proposal, checked only on synthetic footage. Records written before 7.0.68 are compared at their next approval or schedule. |
| P0 | **Per-project upload budget ledger.** Track uploads per Cloud project and day against the documented quota, and block a batch that would exceed it. | Stops a batch from failing halfway through. | A batch of 101 uploads on one project is refused before any upload starts. |
| P0 | **Browser-session health check** for Flow and Gemini Web: sign-in state, profile age, and the last successful run. | Most failures at scale will come from an expired session or a UI change. | Check reports `signed-out`, `ui-changed` or `ok` without submitting a prompt. |
| P1 | **Platform analytics connectors** (YouTube Analytics, Meta Graph) with explicit scopes and read-only use. | Needed for retention, reach and comment review at 10 million followers. | Read-only scope verified; no write permission requested. |
| P1 | **Approval audit log** with append-only records and per-user identity. | Needed before more than one editor works on the same channel. | Every publish-approval change produces one record that cannot be edited in place. |
| P2 | **Multi-channel brand isolation** (separate profiles, logos, languages and destinations per account) with a single view of schedules. | Reduces the risk of posting the wrong language or logo to the wrong account. | Posting a Hindi edition to the English account is refused. |

## Open decisions for you

1. **Flow project deletion.** The tool already has an exact-project delete path (`engine/flow_project_delete.py`). It is available only from the Dashboard panel "Clean downloaded Flow image projects · optional", and only for image-only projects that pass all of these checks:
   - the project records an image request, with a verified local copy;
   - the project has a complete captured gallery inventory;
   - no earlier cleanup of that project is recorded as uncertain.
   Projects that do not meet all three are listed with the reason. If your photo projects are not appearing as eligible, that reason is the first thing to check. I did not loosen these checks. The cleanup panel states that remote deletion removes the Flow copy; local media and resume records stay on disk. Flow's project menu also has a bin, but I have not verified how long deleted projects remain recoverable. Should a downloaded, locally verified image project be deletable without the captured inventory?
2. **Which P0 feature to build first.** The duplicate guard is the smallest change. The quota ledger needs your Google Cloud project list.
3. **Control Center deployment.** The hosted Control Center (`autovideoai-control…chatgpt.site`) is not in this repository, and I cannot deploy to it from this workspace. I updated the local documentation only. To update the hosted Site, I need its source or the deployment method you use.

## Validation and limits

- Code paths reviewed: `engine/flow_project_cleanup.py`, `engine/flow_project_delete.py`, `engine/providers/gemini_video.py`, `engine/channel_desk.py`, and the v7.0.66 audit.
- New tests: `tests/test_v768_gemini_video_settle.py` (5 tests, fake clock; no live Gemini session).
- Not tested live: Gemini Web upload and download, Flow project deletion, and any platform upload or analytics call. These need a signed-in browser on your machine.

import asyncio
import json
from pathlib import Path
from types import SimpleNamespace as NS
import subprocess
import pytest
from engine.providers.flow_browser import FlowBrowser, FlowBrowserProvider, FlowUIChanged

@pytest.fixture
def mp4(tmp_path):
    dest=tmp_path/'exact.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=green:s=128x128:r=24',
                    '-t','1','-c:v','libx264','-pix_fmt','yuv420p',str(dest)],check=True)
    assert FlowBrowserProvider._is_valid_video_file(str(dest))
    return dest


def install(monkeypatch, artifact):
    from playwright import async_api
    monkeypatch.setattr(async_api,'Download',artifact)
    return NS(_impl_obj=object(),_sync=asyncio.run,url='blob:https://flow.google.com/private-token')


def test_complete_bytes_survive_target_close(tmp_path,mp4,monkeypatch):
    class Artifact:
        def __init__(self,impl):pass
        async def save_as(self,path):
            Path(path).write_bytes(mp4.read_bytes());raise RuntimeError('Target page, context or browser has been closed')
    b=FlowBrowser.__new__(FlowBrowser);out=tmp_path/'result.mp4'
    assert b._save_browser_video_artifact(install(monkeypatch,Artifact),str(out))==str(out)
    assert out.read_bytes()==mp4.read_bytes()


def test_exact_artifact_path_is_recovered(tmp_path,mp4,monkeypatch):
    class Artifact:
        def __init__(self,impl):pass
        async def save_as(self,path):raise RuntimeError('save callback closed')
        async def path(self):return str(mp4)
    b=FlowBrowser.__new__(FlowBrowser);out=tmp_path/'result.mp4'
    assert b._save_browser_video_artifact(install(monkeypatch,Artifact),str(out))==str(out)
    assert out.read_bytes()==mp4.read_bytes()


def test_partial_bytes_never_replace_valid_output(tmp_path,mp4,monkeypatch):
    class Artifact:
        def __init__(self,impl):pass
        async def save_as(self,path):Path(path).write_bytes(b'partial');raise RuntimeError('closed')
        async def path(self):return None
    b=FlowBrowser.__new__(FlowBrowser);out=tmp_path/'result.mp4';out.write_bytes(mp4.read_bytes())
    assert b._save_browser_video_artifact(install(monkeypatch,Artifact),str(out)) is None
    assert out.read_bytes()==mp4.read_bytes()
    assert not list(tmp_path.glob('.flow-browser-video-*'))


def test_error_reports_native_cause_and_blob_fallback(tmp_path,monkeypatch):
    class Artifact:
        def __init__(self,impl):pass
        async def save_as(self,path):raise RuntimeError('Target page, context or browser has been closed')
        async def path(self):raise RuntimeError('closed')
    b=FlowBrowser.__new__(FlowBrowser);out=tmp_path/'result.mp4'
    with pytest.raises(FlowUIChanged,match='URL scheme=blob'):
        b._save_download_event(install(monkeypatch,Artifact),str(out))
    diagnostic=Path(str(out)+'.download-diagnostic.json').read_text()
    assert 'target_closed' in diagnostic and 'unsupported_or_untrusted_url' in diagnostic
    assert 'private-token' not in diagnostic and 'https://' not in diagnostic


def test_no_unbounded_sync_path_retry(tmp_path):
    def blocked():pytest.fail('must not invoke unbounded synchronous Download.path')
    b=FlowBrowser.__new__(FlowBrowser)
    assert b._recover_download_save(NS(path=blocked),str(tmp_path/'result.mp4')) is None


def test_native_timeout_is_explicit(tmp_path,monkeypatch):
    class Artifact:
        def __init__(self,impl):pass
        async def save_as(self,path):raise asyncio.TimeoutError()
        async def cancel(self):pass
    b=FlowBrowser.__new__(FlowBrowser)
    assert b._save_browser_video_artifact(install(monkeypatch,Artifact),str(tmp_path/'result.mp4')) is None
    assert 'native_timeout' in b._video_artifact_detail


def test_download_event_survives_click_callback_exception(tmp_path,mp4):
    b=FlowBrowser.__new__(FlowBrowser);callbacks={};calls=[]
    b._page=NS(url='',on=lambda event,cb:callbacks.update({event:cb}),
               remove_listener=lambda *a:None)
    b._ensure_project_guard_page=lambda *a:True
    def click(*a):
        callbacks['download'](object());raise RuntimeError('Target closed after event')
    b._click_download_control=click
    def save(event,path):
        calls.append(event);Path(path).write_bytes(mp4.read_bytes());return path
    b._save_download_event=save
    output=str(tmp_path/'saved.mp4')
    assert b._download_from_tile_button(object(),output)==output
    assert len(calls)==1

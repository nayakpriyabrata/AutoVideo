# AutoVideoAI v7.0.21 — automatic image recovery and Gemini Odia transcripts

Stop Studio/CLI and the local runner, extract the new build, then migrate:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.20 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.20 . --apply
```

Use your actual old folder name. Existing jobs now adopt automatic image recovery, including old jobs that stored the previous off default. No extra option is required:

```bash
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6
```

The shared Factory applies this to YouTube, shorts/Reels, cartoons, music videos and AI recreation whenever they generate Flow images. Clip edits and Mini Reels video requests have no image-generation stage to replace.

After the original scan plus three download-only recovery retries, the engine may submit one isolated replacement image. The original journal remains intact; a later Resume recovers the saved replacement instead of regenerating it. The existing whole-job cap remains 30, one per image. Counters survive migration and Resume. Paid replacement confirmations are never approved automatically. Videos remain download-only. Ambiguous submission state, failed authentication, exhausted cap or failed replacement can still pause; this is not a zero-failure guarantee. Replacement mode serializes Flow image work for deterministic recovery.

If you intentionally disable automatic replacement through Queue or `--no-replace-unresolved-images`, that choice is saved using the new policy version and remains disabled. Older false defaults are migrated to on.

## Odia / Oriya with Gemini Web

Clip Studio highlights, local editing and AI Recreate now offer a **Gemini Web · Odia transcript and correction** panel. Local editing also has a Gemini Web transcript option.

1. Select the video source and Odia language. For local editing choose Gemini Web, or upload a timed JSON transcript under Reviewed.
2. Permit sending the footage/transcript to Gemini, then click Draft. A local video or permitted URL is supported. Your signed-in AutoVideoAI Chromium Gemini session is required.
3. Gemini receives compact proxies that retain audio, in chunks up to five minutes; videos up to one hour are supported. Word timing and spelling are estimates. Review the editable JSON against the source.
4. Optionally click Correct wording. It preserves every timestamp and entry count, rejecting changes to timing. For major rewrites that add/remove words, retime the transcript rather than assigning guessed timestamps.
5. Approve the exact edited words/times before rendering. Download the draft for reuse. Source hashes prevent applying a generated transcript to a different video. Correction does not overwrite the original transcript.

Temporary transcript chats default to delete-after-read; Keep is optional. Nothing is submitted by a page rerun. None still disables transcription/captions for local edits. Gemini spelling, timing and live WSL browser operation are not certified by mock tests.

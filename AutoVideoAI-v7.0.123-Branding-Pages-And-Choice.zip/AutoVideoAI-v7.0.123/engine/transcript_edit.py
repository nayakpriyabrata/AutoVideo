"""Edit the words a burned transcript shows, without touching the narration (v7.0.110).

Field report: the Odia transcript's words were right and its spellings were not. v7.0.109 made the caption
text follow the reviewed script, and switched Odia transcripts off by default. This module is the third,
optional route: let the user read the exact words that would be burned, fix them, and render that.

The important constraint is that **the audio never changes here** - no text-to-speech, no video request, no
Flow credit. The narration file and its measured word times stay byte-identical; only the text drawn on screen
changes. That is why a correction is safe to make after the video exists.

A correction is stored per language in ``production/transcripts/<language>.json``::

    {"schema": "transcript-edit-v1", "language": "or",
     "source_words": ".../words.json", "source_sha256": "...",
     "timing": "unchanged", "edited_at": "...",
     "words": [{"word": "...", "start": 0.0, "end": 0.0}, ...]}

The renderer reads it for captions only. Cards and hooks keep using the saved word timings they were drafted
from, so a spelling fix cannot move a card.

Rules, stated in every message instead of raising a bare error:

* the text is edited word by word, so **the number of words stays the same** and every measured timing is kept;
* if the word count changes (a word split or merged), the timing has to be re-estimated, and that is reported
  as ``timing: estimated`` so the user knows before rendering;
* a correction that matches the reviewed script is not needed at all - ``--script`` clears it.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

SCHEMA = "transcript-edit-v1"


def _read(path, default=None):
    try:
        path = Path(path)
        if not path.is_file():
            return default
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _atomic(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".saving")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)
    return path


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def edit_path(job_root, language):
    return Path(job_root) / "production" / "transcripts" / (str(language) + ".json")


def languages(job_root):
    """Languages this job can offer a transcript editor for, and where their words live."""
    root = Path(job_root)
    state = _read(root / "production" / "language_editions.json") or {}
    found = {}
    for code, bundle in (state.get("bundles") or {}).items():
        words = str(bundle.get("words") or "")
        if words and Path(words).is_file():
            found[str(code)] = {"kind": "edition", "words": words,
                                "audio": str(bundle.get("audio") or ""),
                                "script": str(bundle.get("script") or "")}
    primary = root / "narration" / "voice.mp3.words.json"
    if primary.is_file():
        code = str(state.get("source_language") or "en")
        found.setdefault(code, {"kind": "primary", "words": str(primary),
                                "audio": str(root / "narration" / "voice.mp3"),
                                "script": str(_read(root / "script.md", "") or "")[:0]})
    return found


def _words_path(job_root, language):
    entry = languages(job_root).get(str(language))
    if not entry:
        raise ValueError(
            "No narration word timings are saved for " + str(language) + " in this job, so there is nothing to "
            "edit. Saved languages: " + (", ".join(sorted(languages(job_root))) or "none") +
            ". Prepare the language narration first (Create step 4, or Jobs & Recovery > Speech batches).")
    return Path(entry["words"]), entry


def source_words(job_root, language):
    """The measured words exactly as the narration produced them."""
    path, _entry = _words_path(job_root, language)
    words = _read(path) or []
    return [{"word": str(w.get("word", "")), "start": float(w.get("start", 0) or 0),
             "end": float(w.get("end", 0) or 0)} for w in words if str(w.get("word", "")).strip()]


def state(job_root, language):
    """Everything the editor and the CLI need to describe one language's transcript."""
    path, entry = _words_path(job_root, language)
    saved = _read(edit_path(job_root, language))
    edited = (saved or {}).get("words") or []
    words = edited or source_words(job_root, language)
    return {
        "language": str(language),
        "kind": entry["kind"],
        "words_file": str(path),
        "words_sha256": _sha(path),
        "edit_file": str(edit_path(job_root, language)),
        "edited": bool(edited),
        "edited_at": (saved or {}).get("edited_at", ""),
        "timing": (saved or {}).get("timing", "measured"),
        "source_sha256": (saved or {}).get("source_sha256", ""),
        "words": words,
        "word_count": len(words),
        "text": " ".join(w["word"] for w in words),
    }


def caption_lines(words, max_words=6, max_seconds=3.2):
    """The transcript split the way it appears on screen, so the editor shows captions, not a word soup."""
    lines, current = [], []
    for index, word in enumerate(words or []):
        current.append({'index': index, 'word': str(word.get('word', ''))})
        long_enough = len(current) >= int(max_words)
        held = (current and float(word.get('end', 0) or 0) - float(words[index - len(current) + 1].get('start', 0) or 0)
                >= float(max_seconds))
        ends_sentence = str(word.get('word', '')).rstrip().endswith(('.', '?', '!', '।'))
        if long_enough or held or ends_sentence:
            lines.append(current)
            current = []
    if current:
        lines.append(current)
    return lines


def _validate(words):
    cleaned, previous_end = [], 0.0
    for index, word in enumerate(words or []):
        text = " ".join(str(word.get("word", "")).split())
        if not text:
            continue
        try:
            start = float(word.get("start", 0) or 0)
            end = float(word.get("end", start) or start)
        except (TypeError, ValueError):
            raise ValueError("Word " + str(index + 1) + " (" + text + ") has a timing that is not a number. "
                             "Fix it in the editor and save again; nothing was changed.")
        if start < 0 or end < start:
            raise ValueError("Word " + str(index + 1) + " (" + text + ") ends before it starts (" +
                             f"{start:.2f}s → {end:.2f}s). Fix its timing and save again; nothing was changed.")
        if start < previous_end - 0.02:
            raise ValueError("Word " + str(index + 1) + " (" + text + ") starts before the word before it ends (" +
                             f"{start:.2f}s after {previous_end:.2f}s). Keep the words in order and save again; "
                             "nothing was changed.")
        cleaned.append({"word": text, "start": round(start, 3), "end": round(end, 3)})
        previous_end = end
    if not cleaned:
        raise ValueError("An empty transcript cannot be saved; nothing was changed. Use `--clear` to remove a "
                         "correction and go back to the measured words.")
    return cleaned


def save_words(job_root, language, words, *, note="", timing="unchanged"):
    """Store a corrected word list for one language; returns the new state."""
    job_root = Path(job_root)
    clean = _validate(words)
    source, _entry = _words_path(job_root, language)
    payload = {
        "schema": SCHEMA, "language": str(language), "edited_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "source_words": str(source), "source_sha256": _sha(source),
        "timing": str(timing or "unchanged"), "note": str(note or "")[:300], "words": clean,
    }
    _atomic(edit_path(job_root, language), payload)
    return state(job_root, language)


def save_text(job_root, language, text, *, note=""):
    """Save a corrected transcript given as plain text, one caption line per line.

    The common case - fixing spellings - keeps the word count, so every measured timing is kept exactly. A
    different word count is accepted but reported as estimated timing, because the audio cannot be re-timed to
    text that has more or fewer words in it.
    """
    from .captions import align_words_to_script
    original = source_words(job_root, language)
    tokens = str(text or "").split()
    if not tokens:
        raise ValueError("The corrected transcript is empty. Use `--clear` to remove the correction instead.")
    if len(tokens) == len(original):
        corrected = [{"word": token, "start": w["start"], "end": w["end"]} for token, w in zip(tokens, original)]
        return save_words(job_root, language, corrected, note=note, timing="unchanged")
    duration = max([float(w["end"]) for w in original] + [0.0])
    aligned = align_words_to_script(" ".join(tokens), original, duration) or []
    if not aligned:
        raise ValueError("This text has " + str(len(tokens)) + " words but the narration has " +
                         str(len(original)) + ", and it could not be timed against it. Keep the same number of "
                         "words (fix spellings only) and save again; nothing was changed.")
    return save_words(job_root, language, aligned, note=note, timing="estimated")


def clear(job_root, language):
    """Remove a correction and go back to the measured words."""
    path = edit_path(job_root, language)
    path.unlink(missing_ok=True)
    return state(job_root, language)


def words_for_render(job_root, language):
    """The words a render should burn for this language: the correction when there is one.

    Returns ``(words, report)`` where ``report`` names the file the text came from, so an export can say which
    words it burned.
    """
    path = edit_path(job_root, language)
    saved = _read(path)
    if saved and saved.get("words"):
        return [{"word": str(w["word"]), "start": float(w["start"]), "end": float(w["end"])}
                for w in saved["words"]], {"source": "edited", "file": str(path),
                                            "edited_at": saved.get("edited_at", ""),
                                            "timing": saved.get("timing", "unchanged")}
    measured = source_words(job_root, language)
    return measured, {"source": "measured", "file": str(_words_path(job_root, language)[0]), "timing": "measured"}


def snapshot_for_plan(job_root, language, dest):
    """Write the words a render must burn to ``dest`` and return ``(path, sha, report)``.

    The renderer plans work from immutable snapshots, so an in-place edit while a render runs cannot change its
    output halfway through.
    """
    words, report = words_for_render(job_root, language)
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(words, ensure_ascii=False), encoding="utf-8")
    report = dict(report, sha256=_sha(dest), words=len(words))
    return dest, report

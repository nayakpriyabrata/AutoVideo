# AutoVideoAI 7.0.23 — automatic safe disk cleanup

The earlier build only cleaned individual temporary downloads/render resources. It retained cloned Flow worker profiles. The supplied WSL disk report shows 33 GB in `.flow-workers`, with many 1.6 GB worker clones; the final job's render folder was only about 37 MB.

## Automatic behavior

- New worker profiles do not copy Chromium HTTP/code/GPU caches from the main profile. Cookies, login stores, preferences and identity data remain available.
- Each worker closes its browser before trimming regenerable caches. Its report is saved in `logs/worker_cleanup-*.json`.
- At the end of a production run, cleanup runs on success, failure or pause. Its report is saved in `logs/cleanup.json`.
- An entire worker clone is removed only for a `done` job with a validated final video and no unresolved Flow request journal. Failed/paused jobs and completed jobs with pending fallback requests keep their worker login/recovery stores.
- Worker profiles that may still be active, including ambiguous Chromium lock files, are skipped. Cleanup errors do not invalidate the video/job.
- Temporary Gemini transcript/recreation upload proxies are removed after the provider call, including failures. Original source videos, raw responses and reviewed transcript/plan files stay intact.

This cleanup preserves final videos, accepted takes, storyboard images, narration/music, characters, main Flow/Gemini login profiles, project bindings, recovery/request journals and QC/review reports. Browser storage such as IndexedDB, Local Storage, Sessions, Service Worker and File System is preserved when trimming a resumable worker profile. Files reached through symlinked directories are not followed.

## Upgrade

Stop existing productions, extract into a fresh folder and migrate:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.22 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.22 . --apply
./dashboard.sh
```

All v7.0.22 features remain included. Read BROWSER_STABILITY_V7_0_22.md for Quiet mode and recovery limitations.

## Reclaim old worker space

After migration, use **Settings → Disk cleanup → Preview cleanup of saved jobs**. Inspect the report, then **Apply safe cleanup**. The apply action rechecks state; the preview is not a deletion authorization for files whose eligibility has changed. Wait for running/queued jobs first.

CLI equivalent from the new installation:

```bash
python3 tools/cleanup_jobs.py
python3 tools/cleanup_jobs.py --apply
```

Optional single-job preview:

```bash
python3 tools/cleanup_jobs.py --job 20261006-121745-debanshi--ai-recreation-4af6
```

Use `--outputs PATH` to inspect another installation's saved jobs. Use `--worker-root PATH/.flow-workers` only if you deliberately configured a different worker-profile location. Preview is the default. Active production blocks the command. An unknown/unmigrated job's worker directories are not removed; supply the installation containing that job's manifest. Original/base profiles are never cleaned by this tool.

The eligible byte count comes from the files actually found; 33 GB is the supplied report's total, not a promise that all of it can be safely reclaimed. Pending jobs and ambiguous locks can reduce the reclaimable amount. Do not delete lock files to bypass this protection while a browser may be open.

Old installation folders, migration backups, model packages and retained output media are not automatically removed. This tool does not compact the WSL virtual disk or change Windows disk settings. Keep or archive finished job media deliberately; safe temporary cleanup alone cannot cap storage from an unlimited history of videos.

Gemini chat deletion remains controlled separately by the saved chat-cleanup option. It does not clear local browser/profile caches.

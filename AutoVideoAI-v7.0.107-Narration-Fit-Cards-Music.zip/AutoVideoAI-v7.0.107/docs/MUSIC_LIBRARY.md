# Background music you can actually publish on YouTube

This guide answers one question: **which royalty-free tracks should I keep locally for which kind of video,
and what licence do they carry?** It is a companion to `music_library/`, the folder the app reads local music
from, and to `python3 cli.py v3 music-suggest`.

Nothing in this repository re-hosts, bundles or downloads music. You download the files yourself, once, and
the app reuses them for every video.

---

## 1. The three licences that matter

| Licence | Credit line | Monetised YouTube | Notes |
| --- | --- | --- | --- |
| **YouTube Audio Library licence** | Not required for tracks filtered as *Attribution not required* | Yes (YouTube Partner Program) | YouTube states these tracks are copyright-safe and will not be claimed through Content ID. The safety promise is **YouTube-only**. |
| **Pixabay Content License** | Not required | Yes | Free for commercial use, no royalty. Tracks with a **shield icon are Content ID registered** — avoid those for monetised videos. You may not resell the track as a file. |
| **CC BY 4.0** (Scott Buckley, Kevin MacLeod, most of Free Music Archive) | **Required**, in the exact published wording, in the video description | Yes | Credit is a licence condition, not a courtesy. Missing it is how CC-BY tracks produce claims. |
| **CC0 1.0** (Monplaisir and much of Free Music Archive) | Not required | Yes | Public-domain dedication; the simplest option to reuse forever. |

Never use **CC BY-NC** (no commercial use) or **CC BY-ND** (no edits — and ducking/trimming is an edit) on a
monetised channel. Re-check the licence page before you publish: terms change, and a track you downloaded
last year may since have been registered with Content ID.

---

## 2. Recommendations by video type

Start with the CC0 track you already have (`Monplaisir - Free To Use 1.ogg`) and add one track per mood, so a
45-video backlog never repeats the same bed.

### Education, explainers, how-to, habits, wellbeing
| Track | Artist | Licence | Why |
| --- | --- | --- | --- |
| Free To Use 1 | Monplaisir | CC0 — no credit | Already local. Calm, unobtrusive, survives ducking. Default bed. |
| Amberlight | Scott Buckley | CC BY 4.0 — credit | Warm piano and strings; hopeful, never sugary. |
| Life In Motion | Scott Buckley | CC BY 4.0 — credit | Neoclassical and introspective; good under a personal-story opener. |
| Midvinter | Scott Buckley | CC BY 4.0 — credit | A very gentle piano lullaby; use quietly under slow, calm narration. |
| Search *"calm piano"* / *"inspiring ambient"* | YouTube Audio Library | filter **Attribution not required** | Zero obligations, four or five usable beds per search. |

### Motivation, self-improvement, discipline
| Track | Artist | Licence | Why |
| --- | --- | --- | --- |
| Free To Use 1 | Monplaisir | CC0 — no credit | Steady pulse without a drop that fights the narration. |
| Amberlight | Scott Buckley | CC BY 4.0 — credit | Builds without a hard climax, so the payoff line still lands. |
| Echoes | Scott Buckley | CC BY 4.0 — credit | Solo cello; use the first half only, before it builds at ~3:10. |

### Documentary, story and cinematic narration
| Track | Artist | Licence | Why |
| --- | --- | --- | --- |
| Discovery | Scott Buckley | CC BY 4.0 — credit | Optimistic hybrid orchestra; excellent under an opening hook. |
| Echoes | Scott Buckley | CC BY 4.0 — credit | Emotional strings with a late climax — cut the video around it. |
| Search *"cinematic documentary"* | Pixabay Music | Content License, no credit | Large choice; check each track for the Content ID shield. |

### Technology, AI and science
| Track | Artist | Licence | Why |
| --- | --- | --- | --- |
| Origami | Scott Buckley | CC BY 4.0 — credit | Electro-jazz groove; upbeat without being childish. |
| Discovery | Scott Buckley | CC BY 4.0 — credit | Synth arpeggios read as "future" without a sci-fi cliché. |
| Search *"technology corporate"* | YouTube Audio Library | filter **Attribution not required** | Clean, neutral beds for tool walk-throughs. |

### Business, finance, career
| Track | Artist | Licence | Why |
| --- | --- | --- | --- |
| Origami | Scott Buckley | CC BY 4.0 — credit | Confident, not aggressive. |
| Life In Motion | Scott Buckley | CC BY 4.0 — credit | Credible and human for case studies and interviews. |
| Search *"corporate motivation"* | Pixabay Music | Content License, no credit | Big library of neutral corporate beds. |

### Kids, cartoons, stories
| Track | Artist | Licence | Why |
| --- | --- | --- | --- |
| Midvinter | Scott Buckley | CC BY 4.0 — credit | A gentle bed under bedtime-style stories. |
| Search *"kids playful"* | Pixabay Music | Content License, no credit | Brighter, toy-like beds — pick tracks without the Content ID shield. |

Get the same list in the terminal, with the current URLs:

```bash
python3 cli.py v3 music-suggest --content-type education
python3 cli.py v3 music-suggest --content-type documentary --theme cinematic
python3 cli.py v3 music-suggest --sources          # licence terms per library
python3 cli.py v3 music-suggest --json             # machine-readable
```

The credit block to paste into a description is printed with every suggestion, and is also returned as
`credit_block` in the JSON.

---

## 3. Download once, keep it locally

1. Download the MP3/OGG/WAV from the platform's own page (not from a re-upload — a re-upload has no licence).
2. Keep the download page URL, the licence name and the artist next to the file (a note or the
   `music_library/manifest.json` entry does this).
3. Check the file before importing:

   ```bash
   python3 cli.py v3 music-check ~/Downloads/ambient-calm.mp3
   ```

   It prints the size, SHA-256 and a ready-to-fill `manifest.json` snippet, and refuses files that are not
   playable audio.

4. Import it:

   * **In the app** — Create → **Music library** → upload the file with a title, theme tags, the HTTPS source
     page and the exact licence label. The app writes `manifest.json` and tags the track.
   * **By hand** — copy the file into `music_library/` and add an entry to `music_library/manifest.json`:

     ```json
     {"schema_version": 1, "tracks": [
       {"file": "ambient-calm.mp3", "sha256": "<from music-check>",
        "title": "Amberlight", "tags": ["calm", "motivation"],
        "source_url": "https://www.scottbuckley.com.au/library/amberlight/",
        "license": "CC BY 4.0 — credit required"}
     ]}
     ```

   * **Elsewhere on disk** — point `AUTOVIDEO_MUSIC_LIBRARY` at that folder instead.

5. Tags decide which videos get the track. The library understands `motivation`, `calm`, `upbeat`,
   `cinematic` and `technology`; `python3 cli.py v3 music-suggest --content-type <type>` prints the tags for
   that video type.

---

## 4. How the app mixes the music now (v7.0.107)

* The bed starts at the video's `music_volume` (default 0.10–0.12), **fades in** over 1 s and **fades out**
  over the last 2.5 s instead of stopping dead.
* While the narrator speaks, a sidechain compressor pulls the bed down by about **13 dB** (12:1 ratio at a
  0.02 threshold) with a 15 ms attack and a 550 ms release, so the music **returns in every pause**.
* The finished mix is normalised to **−14 LUFS**, the same target as the English master, so language editions
  are not quieter than the original.
* Sound effects are mixed at 0.65 of their planned level so they sit under the voice.

Tune any of it without touching code:

```bash
python3 cli.py v3 tune <job_id> --show                    # current values
python3 cli.py v3 tune <job_id> --duck-ratio 16 --duck-release-ms 700
python3 cli.py v3 tune <job_id> --music-fade-out 4 --sfx-gain 0.5
python3 cli.py v3 render <job_id>                          # same takes, no Flow credits
```

If the music still feels loud under speech, raise `--duck-ratio` (12 → 16 → 20) or lower the job's music
volume. If it feels like it disappears, lower the ratio to 8 and lengthen the fade-out.

---

## 5. A five-minute checklist before publishing

- [ ] Every track is either CC0 / Audio Library *attribution not required* / Pixabay without a shield icon,
      **or** its exact credit line is in the description.
- [ ] The credit text was copied from the licence page or the track page, word for word.
- [ ] No CC BY-NC or CC BY-ND track anywhere.
- [ ] The track page URL is saved with the file.
- [ ] The video was uploaded as **Unlisted** first and the Copyright column checked before going public.

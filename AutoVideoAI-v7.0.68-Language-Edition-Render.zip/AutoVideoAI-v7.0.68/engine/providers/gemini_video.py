"""Optional Gemini Web video shots: one durable request per selected shot."""
import json
import math
import re
import shutil
import time
from pathlib import Path
from urllib.parse import urlparse
from ..production import save, digest, probe, run


class GeminiVideoPending(RuntimeError):
    pass


def chat_url(value):
    p=urlparse(str(value or ''))
    if p.scheme=='https' and p.netloc=='gemini.google.com' and re.fullmatch(r'/app/[A-Za-z0-9_-]+',p.path):
        return 'https://gemini.google.com'+p.path
    return ''


def selected_shots(root,shots,count):
    if type(count) is not int or not 0<=count<=4:raise ValueError('Gemini video cap must be zero to four')
    target=Path(root)/'gemini-videos/selection.json'
    if target.is_file():
        ids=json.loads(target.read_text())['shots']
        if not isinstance(ids,list) or len(ids)>4 or len(ids)!=len(set(ids)):
            raise ValueError('Invalid saved Gemini video selection')
        return ids
    if not count:return []
    ids=[]
    for shot in shots:
        journals=list(Path(root).glob(f'flow/shots/{shot.shot_id}/*.flow-request.json'))
        if shot.provider=='flow' and not shot.accepted_take and not journals:
            ids.append(shot.shot_id)
            if len(ids)==count:break
    save(target,{'shots':ids,'requested_seconds':10,'cap':count})
    return ids


def video_info(path):
    data=probe(path)
    videos=[s for s in data.get('streams',[]) if s.get('codec_type')=='video']
    if len(videos)!=1:raise ValueError('Downloaded file needs exactly one video stream')
    duration=float(data.get('format',{}).get('duration') or videos[0].get('duration') or 0)
    if not math.isfinite(duration) or not 1<=duration<=60 or min(videos[0].get('width',0),videos[0].get('height',0))<64:
        raise ValueError('Downloaded video duration or dimensions are invalid')
    run(['ffmpeg','-v','error','-xerror','-i',str(path),'-map','0:v:0','-f','null','-'],timeout=120)
    return {'duration':duration,'width':videos[0]['width'],'height':videos[0]['height']}


def unique_visible(nodes):
    rows=[nodes.nth(i) for i in range(min(nodes.count(),50)) if nodes.nth(i).is_visible()]
    return rows[0] if len(rows)==1 else None


class GeminiVideoProvider:
    def __init__(self,root,progress=None,session_factory=None,close_session=None,timeout=600):
        self.root=Path(root);self.progress=progress or (lambda *a:None)
        self.session_factory=session_factory;self.close_session=close_session;self.timeout=timeout

    def close(self):pass

    def generate(self,shot,compiled,refs,out_path,vertical,dry_run=False):
        if dry_run:raise ValueError('Gemini video generation is disabled in dry run')
        selection=json.loads((self.root/'gemini-videos/selection.json').read_text())['shots']
        if shot.shot_id not in selection or len(selection)>4:raise ValueError('Shot is outside saved Gemini approval cap')
        folder=self.root/'gemini-videos'/shot.shot_id;folder.mkdir(parents=True,exist_ok=True)
        journal,media=folder/'request.json',folder/'video.mp4'
        row=json.loads(journal.read_text()) if journal.is_file() else None
        if row and row.get('status')=='downloaded':
            if not media.is_file() or digest(media)!=row.get('sha256'):
                raise GeminiVideoPending('Captured Gemini video is missing/changed. Restore it before Resume.')
            video_info(media)
            return self._result(media,out_path,row)
        from .gemini_web import get_shared_session,close_shared_session
        session=None
        try:
            session=(self.session_factory or get_shared_session)();page=session._page
            if row:
                url=chat_url(row.get('chat_url'))
                if not url:
                    raise GeminiVideoPending('Submission outcome is uncertain and no chat URL was saved. Use Gemini history to locate the request; no new prompt was sent. See '+str(journal))
                page.goto(url,wait_until='domcontentloaded',timeout=90000)
                if chat_url(page.url)!=url:raise GeminiVideoPending('Saved Gemini conversation is unavailable; sign in or restore it')
            else:
                paths=[]
                for value in [refs.get('start'),refs.get('end'),refs.get('character')]:
                    if value and str(Path(value).resolve()) not in paths:paths.append(str(Path(value).resolve()))
                prompt=('Create one original video, approximately 10 seconds, '+('portrait 9:16' if vertical else 'landscape 16:9')+
                        '. Use attached images as visual references. No speech, captions or added music. '+str(compiled.get('prompt',''))+'\nAvoid: '+str(compiled.get('negative','')))
                row={'status':'preparing','shot_id':shot.shot_id,'prompt':prompt,
                     'references':[{'path':p,'sha256':digest(p)} for p in paths],'requested_seconds':10}
                session.start_fresh_chat()
                if session._chat_id(page.url):raise GeminiVideoPending('A fresh Gemini chat could not be opened')
                if paths:session._attach_generation_images(paths)
                session._fill_prompt(prompt)
                send=session._try_resolve('send_button',timeout_ms=3000)
                if send is None:raise GeminiVideoPending('Gemini Send is unavailable; no request submitted')
                row['status']='submitting';save(journal,row)
                send.click(timeout=5000)  # Never press Enter after an uncertain click.
            deadline=time.monotonic()+self.timeout;last_notice=0
            while time.monotonic()<deadline:
                url=chat_url(page.url)
                if url and not row.get('chat_url'):
                    row.update(chat_url=url,status='pending');save(journal,row)
                if row.get('chat_url') and url!=row['chat_url']:raise GeminiVideoPending('Gemini conversation changed during recovery')
                if time.monotonic()-last_notice>15:
                    self.progress('Waiting for Gemini video',30,shot.shot_id+' · waiting for a playable video tile; no new prompt')
                    last_notice=time.monotonic()
                tile=unique_visible(page.locator('model-response video'))
                if tile is not None and row.get('chat_url'):
                    ready=tile.evaluate('(v) => Boolean(v.currentSrc || v.src) && v.readyState >= 1 && Number.isFinite(v.duration) && v.duration > 0')
                    if ready:
                        self._download(session,tile,media)
                        info=video_info(media);row.update(status='downloaded',sha256=digest(media),**info);save(journal,row)
                        self.progress('Gemini video saved',30,shot.shot_id+f" · measured {info['duration']:.1f}s")
                        return self._result(media,out_path,row)
                page.wait_for_timeout(1500)
            raise GeminiVideoPending('Gemini video is still pending. Resume recovers the saved chat; no new prompt will be sent.')
        except Exception as error:
            if row and row.get('status')!='preparing':
                try:
                    if session is not None and not row.get('chat_url'):row['chat_url']=chat_url(session._page.url)
                    row['last_error']=str(error)[:400];save(journal,row)
                except Exception:pass
            raise GeminiVideoPending(str(error)) from error
        finally:(self.close_session or close_shared_session)()

    def _download(self,session,tile,media):
        page=session._page
        response=tile.locator('xpath=ancestor::model-response[1]')
        if response.count()!=1:raise GeminiVideoPending('Gemini video response container changed; saved chat retained')
        action=unique_visible(response.get_by_role('button',name=re.compile(r'^Download video$',re.I)))
        if action is None:
            more=unique_visible(response.get_by_role('button',name=re.compile(r'^(?:More|More options|Show more options)$',re.I)))
            if more is None:raise GeminiVideoPending('Video response menu is unavailable; saved chat retained')
            more.click(timeout=5000);menu=page.get_by_role('menu');menu.first.wait_for(state='visible',timeout=5000)
            action=unique_visible(menu.get_by_role('menuitem',name=re.compile(r'^Download video$',re.I)))
            if action is None:raise GeminiVideoPending('Unique Download video action is unavailable')
        with page.expect_download(timeout=30000) as event:action.click(timeout=5000)
        if not session._save_browser_video_artifact(event.value,str(media)):
            raise GeminiVideoPending('Video transfer interrupted. Resume downloads the same saved Gemini request.')

    @staticmethod
    def _result(media,target,row):
        Path(target).parent.mkdir(parents=True,exist_ok=True)
        if Path(media).resolve()!=Path(target).resolve():shutil.copy2(media,target)
        return {'path':str(target),'provider':'gemini-web','model':'Gemini Web selected model','credits':0,
                'quota_usage':'account-defined','duration':row['duration'],'project_url':row.get('chat_url'),
                'log':'Exact saved Gemini video; measured duration'}

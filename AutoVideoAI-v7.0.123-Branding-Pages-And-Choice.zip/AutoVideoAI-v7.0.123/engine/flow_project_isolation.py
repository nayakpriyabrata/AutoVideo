"""Conservative Flow project binding for isolated workers and video production.

Never infer a project by visible title or most recent gallery tile.
"""
import json
import os
from pathlib import Path
import tempfile


def canonical_project_url(url):
    from .providers.flow_browser import FlowBrowser
    return FlowBrowser.normalize_project_url(url)


def assert_project_binding(expected, observed, worker):
    expected = canonical_project_url(expected)
    observed = canonical_project_url(observed)
    if not expected or not observed or expected != observed:
        raise RuntimeError(
            f"Flow project isolation violation for {worker}: "
            f"expected={expected or '<none>'}, observed={observed or '<none>'}; "
            "generation stopped to prevent cross-project asset attribution")
    return expected


def persist_project_binding(path, url, role, job_id):
    """Persist immutable role/project pairs; require manual action on a mismatch."""
    project = canonical_project_url(url)
    if not project:
        raise ValueError("Cannot bind a noncanonical Flow project URL")
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        data = json.loads(target.read_text(encoding="utf-8"))
        existing = canonical_project_url(data.get("project_url", ""))
        if existing and existing != project:
            raise RuntimeError(f"Flow {role} project changed for {job_id}; refusing to rebind")
        return project
    payload = {"project_url": project, "role": role, "job_id": job_id}
    fd, tmp = tempfile.mkstemp(prefix=".flow-binding-", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        # caller holds job production lock; do not overwrite a newly existing file
        if target.exists():
            return persist_project_binding(target, url, role, job_id)
        os.replace(tmp, target)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return project

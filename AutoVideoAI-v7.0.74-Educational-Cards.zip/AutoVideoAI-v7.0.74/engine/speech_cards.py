"""Cards anchored to measured speech tokens, never global duration scaling.

7.0.74: for educational videos Gemini Web may also return single-point cards
(takeaway, tip, warning) and five-point lists (points). Other video types keep
the one-line keypoint cards exactly as before.
"""
import hashlib
import json
import math
from pathlib import Path

from .render.educational_cards import EDUCATIONAL_KINDS, SINGLE_KINDS, LIST_KIND, MIN_POINTS, MAX_POINTS, MAX_POINT_CHARS

EDUCATIONAL_VARIANT = 'educational-v1'
BASE_PROMPT = (
    'You are an editorial video producer. Suggest sparse, useful transparent pop-up cards. '
    'Use the supplied narration words for exact anchors, not guessed seconds. '
    'Return JSON {"cards":[{"text":"short takeaway","start_word":0,"end_word":5}]}. '
    'Choose at most 18 cards, roughly one per 20–35 seconds, no overlapping anchors, '
    'each 2–6 seconds and at most 80 characters. Keep total coverage below 25%. '
    'Do not repeat entire subtitles. No invented facts, statistics, or generic numbered headings. '
    'Use the target language and exact zero-based word IDs. Cards should reinforce the opening promise, '
    'useful actions and payoff. Empty cards is allowed if none is useful.')
EDUCATIONAL_PROMPT = (
    'You are an editorial video producer for an educational video. Suggest sparse, useful transparent cards. '
    'Use the supplied narration words for exact anchors, not guessed seconds. '
    'Return JSON {"cards":[{"kind":"takeaway","text":"short copy","start_word":0,"end_word":5}]}. '
    'Every card needs "kind". Kinds: "takeaway" = one key idea; "tip" = one practical action the viewer can take; '
    '"warning" = one common mistake to avoid; "points" = a list of 3 to 5 short points, with "text" as the list title '
    'and a "points" array of strings (each at most 60 characters), anchored across the whole spoken list so it lasts 6 to 14 seconds. '
    'Single-point copy is at most 80 characters and lasts 2 to 6 seconds. '
    'Choose at most 18 cards, roughly one per 20–35 seconds, no overlapping anchors, and keep total coverage below 30%. '
    'Use only facts stated in the narration: no invented facts, statistics or numbers. '
    'Use the target language and exact zero-based word IDs. Empty cards is allowed if none is useful.')


def fingerprint(audio, words, script, variant=''):
    h = hashlib.sha256()
    with Path(audio).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    h.update(json.dumps(words, sort_keys=True, ensure_ascii=False).encode())
    h.update(str(script).encode())
    if variant:
        h.update(variant.encode())
    return h.hexdigest()


def validate_words(words, duration):
    if not isinstance(words, list) or not words:
        raise ValueError('Speech cards require saved narration word timestamps')
    previous = 0.0
    for word in words:
        start, end = word.get('start'), word.get('end')
        if (not isinstance(word.get('word'), str) or not word['word'].strip()
                or any(type(v) not in (int, float) or not math.isfinite(v) for v in (start, end))
                or not 0 <= start < end <= duration + .1 or start < previous - .05):
            raise ValueError('Narration word timings are invalid or unordered')
        previous = start


def _card_kind(row, educational):
    """Return (kind, points). Non-educational videos always get plain keypoint cards."""
    if not educational:
        return 'keypoint', None
    kind = row.get('kind') or ('points' if row.get('points') is not None else 'takeaway')
    if kind == LIST_KIND:
        points = row.get('points')
        if not isinstance(points, list) or not MIN_POINTS <= len(points) <= MAX_POINTS:
            raise ValueError(f'A points card needs {MIN_POINTS} to {MAX_POINTS} points')
        cleaned = []
        for point in points:
            if (not isinstance(point, str) or not 1 <= len(point.strip()) <= MAX_POINT_CHARS
                    or '\n' in point):
                raise ValueError(f'Each point must be one short line of at most {MAX_POINT_CHARS} characters')
            cleaned.append(point.strip())
        return LIST_KIND, cleaned
    if kind in SINGLE_KINDS:
        return kind, None
    raise ValueError('Educational card kind must be takeaway, tip, warning or points')


def anchor_cards(draft, words, duration, educational=False):
    validate_words(words, duration)
    rows = draft.get('cards') if isinstance(draft, dict) else None
    if not isinstance(rows, list) or len(rows) > 18:
        raise ValueError('Gemini must return at most 18 sparse cards')
    cards = []
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError('Each card must be an object')
        first, last = row.get('start_word'), row.get('end_word')
        text = row.get('text')
        if any(type(i) is not int for i in (first, last)) or not 0 <= first <= last < len(words):
            raise ValueError('Card refers to an invalid speech word index')
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 80 or '\n' in text:
            raise ValueError('Card copy must be a short single line, at most 80 characters')
        kind, points = _card_kind(row, educational)
        start, end = float(words[first]['start']), float(words[last]['end'])
        if kind == LIST_KIND:
            end = min(duration, max(end, start + 6.0))
            if end-start < 6.0 or end-start > 14:
                raise ValueError('Choose a spoken anchor lasting 6–14 seconds for a points card')
        else:
            end = min(duration, max(end, start + 2.0, start + len(text.split()) / 2.8))
            if end-start < 1.5 or end-start > 6:
                raise ValueError('Choose a spoken anchor lasting 1.5–6 seconds')
        card = {'text': text.strip(), 'start': round(start, 3), 'end': round(end, 3),
                'start_word': first, 'end_word': last, 'kind': kind,
                'spoken_anchor': ' '.join(w['word'] for w in words[first:last+1])}
        if points is not None:
            card['points'] = points
        cards.append(card)
    cards.sort(key=lambda c: c['start'])
    for before, after in zip(cards, cards[1:]):
        if after['start'] < before['end'] + .15:
            raise ValueError('Speech cards overlap; use fewer cards or different spoken anchors')
    if sum(c['end']-c['start'] for c in cards) > max(6, duration*.30):
        raise ValueError('Cards cover too much of the video; keep them sparse')
    return cards


def prepare(root, audio, words, script, duration, language, cleanup='delete-after-read', timing_source='measured',
            educational=False):
    from .production import save
    root = Path(root)
    target = root / 'production' / 'speech_cards.json'
    variant = EDUCATIONAL_VARIANT if educational else ''
    key = fingerprint(audio, words, script, variant)
    if target.is_file():
        prior = json.loads(target.read_text(encoding='utf-8'))
        if prior.get('fingerprint') == key:
            anchor_cards(prior, words, duration, educational)
            return prior
    validate_words(words, duration)
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    indexed = [{'id': i, 'word': w['word'], 'start': w['start'], 'end': w['end']} for i,w in enumerate(words)]
    raw = gemini_web_generate(
        EDUCATIONAL_PROMPT if educational else BASE_PROMPT,
        f'Language: {language}\nMeasured duration: {duration:.3f}s\nReviewed script:\n{script}\n'
        'Timed narration words:\n'+json.dumps(indexed, ensure_ascii=False), cleanup=cleanup)
    save(target.with_name('speech_cards-draft.json'), {'response': raw, 'fingerprint': key})
    draft = _extract_json(raw)
    cards = anchor_cards(draft, words, duration, educational)
    result = {'schema_version': 2 if educational else 1, 'source': 'gemini-web-speech-anchors', 'fingerprint': key,
              'duration': duration, 'language': language, 'timing_source': timing_source,
              'review_required': True, 'educational': bool(educational), 'cards': cards}
    save(target, result)
    return result


def render(root, audio, words, script, duration, width, height, style, educational=False):
    path = Path(root) / 'production' / 'speech_cards.json'
    if not path.is_file():
        return None
    data = json.loads(path.read_text(encoding='utf-8'))
    variant = EDUCATIONAL_VARIANT if educational else ''
    if data.get('fingerprint') != fingerprint(audio, words, script, variant):
        raise ValueError('Narration or timings changed after card drafting. Resume to refresh speech cards before rendering.')
    from .render.graphics import OverlayEvent, render_overlay_png
    from .render.educational_cards import render_card_png
    overlays = []
    for index, card in enumerate(anchor_cards(data, words, duration, educational)):
        target = Path(root) / 'render' / 'graphics' / f'speech-card-{index:02d}.png'
        if educational:
            overlays.append(render_card_png(card, target, int(width), int(height), style=style))
            continue
        event = OverlayEvent('keypoint', card['start'], card['end'], card['text'], anchor='top-left')
        render_overlay_png(event, str(target), int(width), int(height), style=style)
        overlays.append(event.to_dict())
    return overlays


def prepare_edition(root, script, language, *, provider='auto', audio_path=None, cleanup='delete-after-read', draft_cards=True):
    """Reusable narration/card bundle for a reviewed language script or uploaded voice."""
    from .production import save, probe, digest
    from .languages import default_voice, language_pack
    from .audio.tts import synthesize_narration, _audio_to_mp3
    from .captions import get_word_timestamps_resilient
    language = language_pack(language).code
    if not str(script).strip():
        raise ValueError('Provide the reviewed script for this language')
    source_hash = fingerprint(audio_path, [], script) if audio_path else ''
    key = hashlib.sha256(json.dumps([script, language, provider, source_hash], ensure_ascii=False).encode()).hexdigest()[:24]
    folder = Path(root) / 'speech-editions' / language / key
    folder.mkdir(parents=True, exist_ok=True)
    audio, word_path = folder/'voice.mp3', folder/'words.json'
    if not audio.is_file():
        if audio_path:
            if Path(audio_path).suffix.lower() == '.mp3':
                import shutil
                shutil.copy2(audio_path, audio)
            else:
                _audio_to_mp3(str(audio_path), str(audio))
            source_words=Path(str(audio_path)+'.words.json')
            native=json.loads(source_words.read_text()) if source_words.is_file() else []
        else:
            result = synthesize_narration(script, default_voice(language), str(audio), provider=provider, language=language)
            native = result.get('words') or []
        if native:
            save(word_path, native)
            source_meta=Path(str(audio_path)+'.words.meta.json') if audio_path else None
            metadata=json.loads(source_meta.read_text()) if source_meta and source_meta.is_file() else {'timing_source': 'native-tts' if not audio_path else 'unverified'}
            save(str(audio)+'.words.meta.json', metadata)
    duration = float(probe(audio)['format']['duration'])
    if word_path.is_file():
        words = json.loads(word_path.read_text())
    else:
        words = get_word_timestamps_resilient(str(audio), script_text=script, language=language, audio_duration=duration) or []
        save(word_path, words)
    meta_path = Path(str(audio)+'.words.meta.json')
    meta = json.loads(meta_path.read_text()) if meta_path.is_file() else {}
    result = {'audio': str(audio), 'words': str(word_path), 'duration': duration, 'audio_sha256': digest(audio),
              'script': script, 'language': language, 'cards': [],
              'timing_source': meta.get('timing_source', meta.get('engine', 'unverified')), 'review_required': True}
    validate_words(words,duration)
    if draft_cards:
        result = complete_edition_cards(result,cleanup)
    else:
        save(folder/'narration.json', result)
    return result


def complete_edition_cards(bundle,cleanup='delete-after-read'):
    from .production import digest,save
    audio=Path(bundle['audio']);folder=audio.parent
    if digest(audio)!=bundle['audio_sha256']:raise ValueError('Prepared narration changed; prepare TTS again')
    words=json.loads(Path(bundle['words']).read_text())
    cards=prepare(folder,audio,words,bundle['script'],bundle['duration'],bundle['language'],cleanup=cleanup,timing_source=bundle['timing_source'])
    result=dict(bundle,cards=cards['cards'])
    save(folder/'bundle.json',result)
    return result


def batch_key(script,source_language,languages,provider,audio_path=''):
    from .production import digest
    payload=[script.strip(),source_language,sorted(set(languages)),provider,digest(audio_path) if audio_path else '']
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False).encode()).hexdigest()[:24]


def localization_key(script,source_language,languages):
    payload=[script.strip(),source_language,sorted(set(languages))]
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False).encode()).hexdigest()[:24]


def prepare_localized_scripts(root,source_script,source_language,languages,*,cleanup='delete-after-read',progress=None):
    """Create language editions from one approved master without making audio or visuals."""
    from .production import save
    from .languages import language_pack,script_language
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    editions=list(dict.fromkeys(language_pack(x).code for x in languages))
    source_language=language_pack(source_language).code
    if not source_script.strip() or not editions:raise ValueError('Approve a master script and select at least one output language')
    if source_language not in editions:raise ValueError('The master language must remain one of the output editions')
    expected=localization_key(source_script,source_language,editions)
    target=root/'localized_scripts.json'
    if target.is_file():
        saved=json.loads(target.read_text(encoding='utf-8'))
        if saved.get('fingerprint')==expected and all(saved.get('scripts',{}).get(x,'').strip() for x in editions):return saved
    emit=progress or (lambda *args:None)
    scripts={source_language:source_script.strip()}
    for index,language in enumerate(x for x in editions if x!=source_language):
        emit('Localizing the approved master script',int(95*index/max(1,len(editions)-1)),language.upper())
        raw=gemini_web_generate(
            'Localize the approved master narration for a separate language edition. Preserve every fact, name, '
            'claim, story beat and ordering. Write natural spoken language rather than a literal translation. '
            'Do not add or remove ideas. Keep approximately the same spoken duration. Return JSON '
            '{"narration":"..."}. This draft will be reviewed by a human before TTS.',
            f'Source language: {source_language}\nTarget: {language}\nApproved master narration:\n{source_script}',cleanup=cleanup)
        translated=_extract_json(raw)
        narration=translated.get('narration','') if isinstance(translated,dict) else ''
        if not isinstance(narration,str) or not narration.strip():raise ValueError('Localization did not return narration for '+language.upper())
        if script_language(narration)!=language:raise ValueError('Localized script language differs from '+language.upper())
        scripts[language]=narration.strip()
    result={'schema_version':1,'phase':'scripts_approved' if editions==[source_language] else 'review_scripts','fingerprint':expected,'source_language':source_language,
            'source_script':source_script.strip(),'editions':editions,'scripts':scripts,'reviewed':{source_language:True}}
    save(target,result);emit('Localized scripts ready for review',100)
    return result


def approve_localized_scripts(root,state,edited_scripts,approvals):
    """Save the exact scripts the user reviewed; later TTS must consume this snapshot."""
    from .production import save
    from .languages import script_language
    root=Path(root);editions=state.get('editions',[]);source_language=state.get('source_language')
    expected=localization_key(state.get('source_script',''),source_language,editions)
    if state.get('fingerprint')!=expected:raise ValueError('Master script or language selection changed; prepare localization again')
    scripts={}
    for language in editions:
        value=str(edited_scripts.get(language,'')).strip()
        if not value:raise ValueError('The '+language.upper()+' narration is empty')
        if language!=source_language and script_language(value)!=language:raise ValueError('Reviewed script language differs from '+language.upper())
        if not approvals.get(language):raise ValueError('Review and approve the '+language.upper()+' narration')
        scripts[language]=value
    result=dict(state,phase='scripts_approved',scripts=scripts,reviewed={x:True for x in editions})
    save(root/'localized_scripts.json',result)
    return result


def prepare_batch(root,source_script,source_language,languages,*,provider='auto',audio_path=None,cleanup='delete-after-read',progress=None,localized_scripts=None):
    """One action, two phases: every language voice first, then separate card requests."""
    from .production import save
    from .languages import language_pack
    root=Path(root);editions=list(dict.fromkeys(language_pack(x).code for x in languages))
    source_language=language_pack(source_language).code
    if not source_script.strip() or not editions:raise ValueError('Approve a script and select at least one language')
    if localized_scripts is None:
        localized=prepare_localized_scripts(root,source_script,source_language,editions,cleanup=cleanup,progress=progress)
        scripts=localized['scripts']
    else:
        scripts={language:str(localized_scripts.get(language,'')).strip() for language in editions}
        if any(not scripts[x] for x in editions):raise ValueError('Every selected language needs a reviewed localized script before TTS')
        if scripts.get(source_language)!=source_script.strip():raise ValueError('Reviewed master script changed; prepare the language scripts again')
    scripts_hash=hashlib.sha256(json.dumps(scripts,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    state={'source_language':source_language,'source_script':source_script,'editions':editions,'scripts_sha256':scripts_hash,'bundles':{},'phase':'tts'}
    emit=progress or (lambda *args:None)
    # No text-card call can occur in this first loop.
    for index,language in enumerate(editions):
        script=scripts[language]
        emit('Preparing TTS and word timings',int(45*index/len(editions)),language.upper())
        state['bundles'][language]=prepare_edition(root,script,language,provider=provider,audio_path=audio_path if language==source_language else None,cleanup=cleanup,draft_cards=False)
        save(root/'batch.json',state)
    state['phase']='cards';save(root/'batch.json',state)
    for index,language in enumerate(editions):
        emit('All voices ready · drafting timed cards',50+int(45*index/len(editions)),language.upper())
        state['bundles'][language]=complete_edition_cards(state['bundles'][language],cleanup)
        save(root/'batch.json',state)
    state['phase']='ready_for_review';save(root/'batch.json',state);emit('All selected language bundles ready',100)
    return state


def attach_prepared_batch(job_root,batch):
    """Snapshot preflight assets into the job so later cleanup cannot break Resume."""
    import shutil
    from .production import save,digest
    job_root=Path(job_root);bundles={}
    if batch.get('phase')!='ready_for_review':raise ValueError('Finish all voices and cards first')
    for language,bundle in batch['bundles'].items():
        source=Path(bundle['audio']).parent
        if digest(bundle['audio'])!=bundle['audio_sha256']:raise ValueError('Prepared voice changed')
        target=job_root/'speech-editions'/language/source.name
        if source.resolve()!=target.resolve():shutil.copytree(source,target,dirs_exist_ok=True)
        result=dict(bundle,audio=str(target/'voice.mp3'),words=str(target/'words.json'))
        validate_words(json.loads(Path(result['words']).read_text()),result['duration'])
        bundles[language]=result
    source_language=batch['source_language']
    if source_language not in bundles:raise ValueError('Include the production language in the batch')
    save(job_root/'production/prepared_speech.json',bundles[source_language])
    cards=Path(bundles[source_language]['audio']).parent/'production/speech_cards.json'
    save(job_root/'production/speech_cards.json',json.loads(cards.read_text()))
    return bundles


def prepare_selected_editions(root, source_script, source_language, settings, progress=None):
    """Prepare selected language narration bundles before spending on visuals."""
    from .production import save
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    from .languages import script_language, language_pack
    path = Path(root)/'production/language_editions.json'
    if not path.is_file():return
    data = json.loads(path.read_text())
    if not data.get('prepare_audio'):return
    editions = list(dict.fromkeys(language_pack(lang).code for lang in data.get('editions', [])))
    from .production import digest
    existing=data.get('bundles',{})
    if (all(lang in existing and Path(existing[lang]['audio']).is_file()
            and digest(existing[lang]['audio'])==existing[lang]['audio_sha256'] for lang in editions)
            and existing.get(source_language,{}).get('script','').strip()==source_script.strip()):
        return
    audio=Path(root)/'narration/voice.mp3'
    result=prepare_batch(root,source_script,source_language,editions,provider=settings.get('tts_provider','auto'),
                         audio_path=audio if audio.is_file() else None,cleanup=settings.get('gemini_chat_cleanup','keep'),
                         progress=(lambda label,pct,detail='':progress(label,14+3*pct/100,detail)) if progress else None)
    if source_language in result['bundles'] and audio.is_file():
        primary=result['bundles'][source_language]
        card_file=Path(primary['audio']).parent/'production/speech_cards.json'
        source_words=Path(str(audio)+'.words.json')
        if card_file.is_file() and source_words.is_file():
            card_data=json.loads(card_file.read_text())
            if card_data.get('fingerprint')==fingerprint(audio,json.loads(source_words.read_text()),source_script):
                save(Path(root)/'production/speech_cards.json',card_data)
    data['bundles']=result['bundles'];data['status']='all voices first, then all cards; review required'
    save(path,data)

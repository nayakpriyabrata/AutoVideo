#!/usr/bin/env python3
"""Preview safe worker-cache/completed-profile cleanup. --apply performs it."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine.job_cleanup import cleanup_job
from engine.production_lock import acquire, release


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--outputs',default='outputs')
    parser.add_argument('--job',help='One saved job ID; omitted means all known jobs')
    parser.add_argument('--worker-root',help='Override the isolated .flow-workers root')
    parser.add_argument('--apply',action='store_true',help='Remove the files shown by the same preview')
    args=parser.parse_args()
    outputs=Path(args.outputs).resolve()
    jobs=[outputs/args.job] if args.job else sorted(p.parent for p in outputs.glob('*/production_manifest.json'))
    if args.job and (Path(args.job).name!=args.job or not (jobs[0]/'production_manifest.json').is_file()):
        parser.error('Choose an existing job ID inside --outputs')
    service=Path.home()/'.local/share/autovideoai';service.mkdir(parents=True,exist_ok=True)
    reports=[]
    with open(service/'production.lock','a+b') as global_lock:
        try:acquire(global_lock,blocking=False)
        except BlockingIOError:parser.error('Production is active; stop/wait for it before cleanup')
        try:
            for job in jobs:
                with open(job/'.production.lock','a+b') as job_lock:
                    try:acquire(job_lock,blocking=False)
                    except BlockingIOError:
                        reports.append({'job_id':job.name,'warnings':['Job is running or queued; preserved']});continue
                    try:reports.append(cleanup_job(job,args.worker_root,apply=args.apply))
                    finally:release(job_lock)
        finally:release(global_lock)
    print(json.dumps({'apply':args.apply,'eligible_bytes':sum(r.get('eligible_bytes',0) for r in reports),
        'freed_bytes':sum(r.get('freed_bytes',0) for r in reports),'jobs':reports},indent=2))

if __name__=='__main__':main()

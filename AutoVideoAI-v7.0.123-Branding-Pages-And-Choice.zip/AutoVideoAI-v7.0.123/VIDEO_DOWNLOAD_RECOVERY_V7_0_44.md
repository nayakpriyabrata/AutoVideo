# v7.0.44 — preserve video downloads after browser closure

The supplied Mini Reel log confirms that Flow recognized a video and emitted download events. Saves failed within 2–4 seconds, but the old generic message incorrectly suggested an elapsed transfer timeout. The log does not contain the underlying native-save exception or HTTPS fallback reason.

This update fixes a verified code defect: if save_as writes a complete MP4 and then raises on browser closure, the saver now validates and keeps those bytes. If incomplete, it attempts the same Download event's artifact path with a bounded wait. It never substitutes a different file or submits another generation. Partial files cannot overwrite validated output. The fallback no longer calls unbounded synchronous Download.path after exhausting the bounded save.

If both native saving and signed-URL recovery fail, the error reports native failure category, HTTP/fallback category and URL scheme. The adjacent `.download-diagnostic.json` contains these codes without signed URLs or cookies. Blob download URLs cannot be fetched outside their original browser; if the browser dies before any bytes are available, recovery may still need attention. This build does not claim that the hidden failure in the supplied log has been conclusively identified.

## Update the existing installation

Stop Studio and the local runner. Extract the v7.0.44 ZIP alongside the existing folder. From the existing `AutoVideoAI-v7.0.42` folder (whose VERSION currently says 7.0.43), run:

```bash
python3 ../AutoVideoAI-v7.0.44/tools/update_v743_to_v744.py . --apply
cat VERSION
bash dashboard.sh
```

VERSION should say 7.0.44. The updater changes code only and backs up affected files. It preserves shared outputs, profiles, settings and request journals.

## Recover the saved Mini Reel

Use Mini Reels → Recover a saved Flow request → select `20261014-121927-16a2278f` → Recover. Alternatively, from the existing installation with Studio idle:

```bash
python3 -c "from engine.mini_reels import recover_flow_reel; print(recover_flow_reel('20261014-121927-16a2278f').get('status'))"
```

This uses the saved project and journal. Do not create the reel again or approve another generation. If recovery fails, share the new error and this small diagnostic file:

`outputs/mini_reels/20261014-121927-16a2278f/mini-reel.mp4.download-diagnostic.json`

## Validation

27 focused regression tests passed. Checks cover a real synthetic MP4 saved before a target-close exception, exact artifact-path recovery, preservation of existing output after partial downloads, native timeout classification, and removal of the unbounded path retry. Existing HTTPS download hardening and browser-stability checks are also run. No live Google Flow session or WSL installation is available here; the exact failure on your machine remains to be verified.

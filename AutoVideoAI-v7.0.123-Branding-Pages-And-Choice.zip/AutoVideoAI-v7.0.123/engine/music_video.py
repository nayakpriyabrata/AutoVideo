"""Music-first storyboard jobs; Flow Music creation remains a visible user handoff."""
from pathlib import Path
import math
import shutil
from .production import probe, digest, save
from .content_plan import validate_plan


def music_prompt(topic, language='en', genre='devotional', *, background=False, lyrics=''):
    languages={'en':'English','hi':'Hindi','or':'Odia'}
    if language not in languages:raise ValueError('Choose English, Hindi or Odia')
    if not str(topic).strip():raise ValueError('Describe the song or background mood')
    return (f"Create {'instrumental background music, no vocals' if background else languages[language]+' song'} "
            f"for: {topic}. Genre: {genre}. Clear melodic phrasing, coherent beginning and ending. "
            + ('Keep it soft and leave space for narration. ' if background else 'Natural native-language pronunciation. ')
            + ('Use these reviewed lyrics exactly: '+lyrics if lyrics.strip() and not background else ''))


def create_music_video(factory, music_path, topic, *, language='en', genre='devotional', lyrics='',
                       character_ids=None, max_credits=50, allow_stock=False, aspect='9:16'):
    path=Path(music_path).expanduser().resolve()
    if not path.is_file():raise ValueError('Import the downloaded, authorized song first')
    media=probe(path)
    if not any(s.get('codec_type')=='audio' for s in media.get('streams',[])):
        raise ValueError('Song has no playable audio stream')
    duration=float(media.get('format',{}).get('duration') or 0)
    if not math.isfinite(duration) or not 10<=duration<=600:
        raise ValueError('Music videos support songs of 10–600 seconds')
    if type(max_credits)!=int or not 0<=max_credits<=5000:raise ValueError('Invalid credit ceiling')
    music_prompt(topic,language,genre)
    job=factory.create_job(topic,video_type='shorts' if aspect=='9:16' else 'faceless_youtube',
        target_seconds=int(math.ceil(duration)),aspect=aspect,language=language,profile='STORYBOARD_ECONOMY',
        content_type='story',voiceover_enabled=False,caption_display='none',text_cards_enabled=False,
        sound_effects_enabled=False,ambience_enabled=False,background_music='local',
        background_music_path=str(path),music_volume=1.0,frame_source='auto',images_per_shot=0,
        stock_share=.25 if allow_stock else 0,stock_scenes=None if allow_stock else 0,
        character_ids=character_ids or [],budgets={'MAX_CREDITS_PER_VIDEO':max_credits})
    root=Path(factory.pm.job_dir(job));audio=root/'audio';audio.mkdir(exist_ok=True)
    imported=audio/('music-source'+path.suffix.lower());shutil.copy2(path,imported)
    import json
    settings=json.loads((root/'settings.json').read_text());settings['background_music_path']=str(imported)
    save(root/'settings.json',settings)
    # Authored scene notes are visual guidance; never synthesized as narration.
    notes=[s.strip() for s in lyrics.splitlines() if s.strip()] or [topic]
    scenes=[]
    for i in range(max(len(notes),int(math.ceil(duration/8)))):
        note=notes[i%len(notes)]
        scenes.append({'name':f'Music scene {i+1}','text':note,'duration':min(8,duration),
            'visual_intent':f'{genre} music video: meaningful visual support for {note}. Keep consistent setting and cast; no unrelated people.',
            'image_prompt':f'{genre} music video, {topic}. Depict {note}. Respect devotional iconography when relevant; no captions or logos.',
            'motion_prompt':f'Gentle musical visual motion illustrating {note}; consistent cast and setting.'})
    plan=validate_plan({'schema_version':1,'topic':topic,'language':language,'narration':' '.join(s['text'] for s in scenes),
         'scenes':scenes,'approved':True,'rights':{'declaration':'own_content','adaptation_confirmed':True},
         'provenance':{'music_sha256':digest(imported),'music_source':'user-imported Flow Music or licensed track','genre':genre}})
    factory.import_content_plan(job,plan)
    save(root/'music_video.json',{'duration':duration,'music_sha256':digest(imported),'genre':genre,'language':language})
    return {'job_id':job,'state':'PLAN_READY','new_generations':0,'duration':duration,'next_action':'Review the storyboard, then Resume in Queue'}

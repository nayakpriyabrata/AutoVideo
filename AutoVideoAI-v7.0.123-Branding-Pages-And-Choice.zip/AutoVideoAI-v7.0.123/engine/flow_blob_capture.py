"""Capture only the exact UI download blob, within its live browser context."""
import asyncio
import base64
import os
from pathlib import Path
import tempfile

SCRIPT = r'''async ({url,limit}) => {
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),15000);
 try {
  const response=await fetch(url,{signal:controller.signal});
  if(!response.ok || !response.body)return null;
  const reader=response.body.getReader();let size=0;const chunks=[];
  while(true){const {done,value}=await reader.read();if(done)break;
   size+=value.length;if(size>limit){await reader.cancel();return null;}chunks.push(value);}
  const bytes=new Uint8Array(size);let offset=0;
  for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  let binary='';for(let i=0;i<size;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return {bytes:size,data:btoa(binary)};
 } finally {clearTimeout(timer);}
}'''


def capture(bridge, download, output):
    """Try the exact blob inside its own page. Returns the output path, or None.

    v7.0.88: every None return records a reason code and one summary line is
    logged, so a silent miss is visible. The return value is unchanged.
    """
    url=str(getattr(download,'url','') or '')
    if not url.startswith(('blob:https://flow.google.com/','blob:https://labs.google/')):
        _report_miss(['not_flow_blob_url'], url)
        return None
    limit=128*1024*1024
    from playwright.async_api import Page
    reasons=[]
    for name in ('page','guard'):
        page=getattr(bridge,'_page' if name=='page' else '_guard_page',None)
        try:
            if page is None:
                reasons.append(name+':none');continue
            if page.is_closed():
                reasons.append(name+':closed');continue
            current=str(page.url or '')
            if not current.startswith(('https://flow.google.com/','https://labs.google/')):
                reasons.append(name+':not_flow_page');continue
            if not getattr(page,'_impl_obj',None) or not callable(getattr(page,'_sync',None)):
                reasons.append(name+':no_sync_adapter');continue
            async def read():
                return await asyncio.wait_for(Page(page._impl_obj).evaluate(SCRIPT,{'url':url,'limit':limit}),timeout=20)
            payload=page._sync(read())
            if payload is None:
                reasons.append(name+':blob_not_fetchable_in_page');continue
            if not isinstance(payload,dict) or type(payload.get('bytes')) is not int or not 0<payload['bytes']<=limit:
                reasons.append(name+':payload_invalid');continue
            data=base64.b64decode(payload['data'],validate=True)
            if len(data)!=payload['bytes']:
                reasons.append(name+':payload_size_mismatch');continue
            parent=Path(output).resolve().parent;parent.mkdir(parents=True,exist_ok=True)
            fd,temp=tempfile.mkstemp(prefix='.flow-exact-blob-',suffix=Path(output).suffix,dir=parent)
            try:
                with os.fdopen(fd,'wb') as handle:handle.write(data)
                from .providers.flow_browser import FlowBrowserProvider
                kind='video' if str(output).lower().endswith('.mp4') else 'image'
                validator=FlowBrowserProvider.__new__(FlowBrowserProvider)
                if not validator._asset_valid(temp,kind):
                    reasons.append(name+':asset_invalid');continue
                os.replace(temp,output)
                print('[Flow] Saved and validated the exact download blob while its browser context was alive.')
                return output
            finally:
                if os.path.isfile(temp):os.remove(temp)
        except Exception as error:
            from .flow_download_diagnostics import describe_exception
            reasons.append(name+':error '+describe_exception(error,limit=160))
            continue
    _report_miss(reasons, url)
    return None


def _report_miss(reasons, url):
    from .flow_download_diagnostics import diag, url_shape
    diag('in-page blob capture did not save (' + url_shape(url) + '): ' + ('; '.join(reasons) or 'no page tried'))

# AutoVideoAI v7.0.76: Gemini Web hooks

## What changed

- **Hooks are drafted by Gemini Web** after the narration words and text cards are ready. The
  draft runs in the prepare stage and is saved to `production/hooks.json`. The raw reply is kept in
  `production/hooks-draft.json`.
- **Opt-in.** Create has a new checkbox, "Add Gemini Web hooks where the narration needs them".
  It is off by default and needs a voiceover. The setting is `hooks_enabled`.
- **Limits.** At most 6 hooks. Each is at most 60 characters on one line. Each is shown for
  2.5 to 3.5 seconds (3.0 seconds by default, clipped at the end of the video). Hooks are at least
  10 seconds apart. Each is anchored to a spoken word, so it appears when the narrator reaches that
  moment.
- **Placement.** A hook is a pop pill near the top centre of the frame. A hook that would cover a
  text card, a points series or any other non-watermark overlay is dropped and logged as
  `hooks_dropped_overlap`.
- **Failure handling.** If Gemini Web is not signed in or returns an invalid draft, the job logs
  `hooks_skipped` and continues without hooks. The render also logs `hooks_render_skipped` and
  continues if the saved hooks no longer match the narration.
- **Staleness.** Hooks are cached by a fingerprint over the voice audio, the words, the script,
  the topic and the language. If any of these change, the saved hooks are refused until the
  job is resumed and hooks are redrafted.

## Files

- `engine/video_hooks.py`: prompt, validation, drafting, cache, render-time placement.
- `engine/render/hook_cards.py`: pill PNG renderer (fits text to two lines, portrait and landscape).
- `engine/factory.py`: draft step after speech cards; overlay step before `graphics_plan.json` is saved.
- `engine/studio_config.py`, `app.py`: `hooks_enabled` setting and checkbox.
- `tests/test_v776_hooks.py`: 23 offline tests.

## Install

Install from 7.0.75 with `tools/update_v775_to_v776.py` (dry run first, then `--apply`). Stop the
dashboard before `--apply`. Outputs, saved jobs and browser profiles are never touched.

## Not yet verified

- A live Gemini Web hook draft has not been run in this build.
- A full job render with hooks on the user's footage has not been run.

"""Log-only diagnostics for Flow image downloads (v7.0.88).

Nothing here changes what a download does. It records which party closed a
target, what Playwright actually raised, and which in-page capture step gave
up and why, so one failing run can show the cause. Blob, signed and data URLs
are never logged: only the scheme and host are kept.
"""
from __future__ import annotations

import re
import time
from urllib.parse import urlsplit

from .runtime_log import runtime_print

_URL_RE = re.compile(r"(?:blob|https?|data|wss?):[^\s'\"<>]*", re.IGNORECASE)


def diag(message: str) -> None:
    """One diagnostic line in the job runtime log."""
    runtime_print(f"[Flow][diag] {message}")


def describe_exception(exc: BaseException, limit: int = 200, log_limit: int = 700) -> str:
    """Exception class plus a URL-free, length-capped message.

    v7.0.89: Playwright appends the browser's own stderr after "Browser logs:". That
    tail is where a browser crash names itself, so the last lines are kept (capped),
    not dropped with the rest of the message.
    """
    raw = str(exc)
    head, marker, tail = raw.partition("Browser logs:")
    text = _URL_RE.sub("<url>", " ".join(head.split()))[:limit]
    name = type(exc).__name__
    out = f"{name}: {text}" if text else name
    if marker:
        lines = [line.strip() for line in tail.splitlines() if line.strip()]
        shown = _URL_RE.sub("<url>", " | ".join(lines[-10:]))[:log_limit]
        if shown:
            out += " | browser logs (last lines): " + shown
    return out


def url_shape(url) -> str:
    """Scheme and host only, for example 'blob:flow.google.com'."""
    try:
        parts = urlsplit(str(url or ""))
    except Exception:
        return "unavailable"
    scheme = parts.scheme.lower()
    if scheme == "blob":
        origin = urlsplit(parts.path)
        host = origin.netloc.lower() if origin.scheme.lower() in ("https", "http") else "other"
        return f"blob:{host}"
    if scheme in ("https", "http"):
        return f"{scheme}://{parts.netloc.lower()}"
    if scheme in ("", None):
        return "none"
    return "other"


def page_state(page) -> str:
    if page is None:
        return "none"
    try:
        return "closed" if page.is_closed() else "open"
    except Exception as exc:
        return "unknown:" + type(exc).__name__


def browser_state(bridge) -> str:
    cdp = getattr(bridge, "_cdp", None)
    if cdp is None:
        return "none"
    try:
        return "connected" if cdp.is_connected() else "disconnected"
    except Exception as exc:
        return "unknown:" + type(exc).__name__


def download_page_state(download, clicked_page) -> str:
    """Whether the download's own page is the page that was clicked, and whether it is open."""
    try:
        owner = download.page
    except Exception as exc:
        return "page-unavailable:" + type(exc).__name__
    relation = "clicked-page" if owner is clicked_page else "other-page"
    return f"{relation},{page_state(owner)}"


class PageWatch:
    """Record page, context and browser close, crash and disconnect events during one download.

    Listeners are removed on exit. A missing event is itself evidence: if none
    of these fire, the target was not closed through Playwright's page or context.
    """

    def __init__(self, bridge, page, label: str):
        self.bridge = bridge
        self.page = page
        self.label = label
        self.started = time.monotonic()
        self.events: list[str] = []
        self._attached: list[tuple] = []

    def __enter__(self):
        self._hook(self.page, "close", "page closed")
        self._hook(self.page, "crash", "page crashed")
        self._hook(getattr(self.bridge, "_ctx", None), "close", "browser context closed")
        self._hook(getattr(self.bridge, "_cdp", None), "disconnected", "browser disconnected")
        return self

    def __exit__(self, *exc_info):
        for obj, event, callback in self._attached:
            try:
                obj.remove_listener(event, callback)
            except Exception:
                pass
        self._attached = []
        return False

    def elapsed(self) -> float:
        return time.monotonic() - self.started

    def _hook(self, obj, event: str, what: str) -> None:
        if obj is None:
            return

        def callback(*_args):
            moment = self.elapsed()
            self.events.append(f"{what} +{moment:.1f}s")
            diag(f"{what} while saving {self.label} (+{moment:.1f}s after the click)")

        try:
            obj.on(event, callback)
            self._attached.append((obj, event, callback))
        except Exception as exc:
            diag(f"could not watch '{event}' for {self.label}: {describe_exception(exc)}")

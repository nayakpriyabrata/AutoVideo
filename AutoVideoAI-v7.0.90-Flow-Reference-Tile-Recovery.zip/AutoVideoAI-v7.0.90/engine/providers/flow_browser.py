"""
Google Flow Browser Bridge (experimental provider).

- Playwright + persistent Chromium profile. First run: visible browser, USER logs
  into Google manually. Never automates passwords. Session reused afterwards.
- Operates normal visible UI only. No private APIs, no CAPTCHA/limit bypass,
  no credit manipulation, no SynthID removal.
- Config-driven selectors (config/flow_ui.yaml). Any UI drift -> Assisted Flow Mode.
- DRY RUN exercises orchestration without clicking Generate (no credits).
"""
from __future__ import annotations
import os
from pathlib import Path
import re
import glob
import time
import json
import shutil
import subprocess
import hashlib
import secrets
import yaml
from ..runtime_log import runtime_print as print
from ..flow_download_diagnostics import (PageWatch, browser_state, describe_exception, diag,
                                        download_page_state, page_state, url_shape)
from .base import VideoProvider, ProviderStatus, FlowState

_FLOW_VIDEO_DOWNLOAD_TIMEOUT_S = 120
_FLOW_VIDEO_DOWNLOAD_MAX_BYTES = 512 * 1024 * 1024
_FLOW_VIDEO_DOWNLOAD_CHUNK_BYTES = 128 * 1024
_FLOW_VIDEO_DOWNLOAD_MAX_REDIRECTS = 3
_FLOW_IMAGE_DOWNLOAD_TIMEOUT_S = 120


def media_signature_matches(left, right, *, ignore_kind: bool = False):
    """Compare media identity independent of tile size and label.

    Old journals include viewport dimensions. Never match on a generic prompt,
    DOM position or newest tile. Signed URL normalization requires a stable ID.
    ``ignore_kind`` is reserved for diagnosing a stale queued-thumbnail signature;
    it must not be used to authorize downloading or accepting an asset.
    """
    if left == right and left:
        return True
    from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
    def identity(sig):
        try:
            tag, src, tail = str(sig).split('|', 2)
            _, kind, width, height = tail.rsplit('|', 3)
            if tag not in ('IMG', 'VIDEO') or kind not in ('image', 'video', 'pending') or not src:
                return None
            float(width); float(height)
            u = urlsplit(src)
            query = parse_qsl(u.query, keep_blank_values=True)
            # Only remove signing parameters when an independent content ID exists.
            if (u.scheme == "https" and u.hostname == "flow.google.com"
                    and re.fullmatch(r"/asb/[A-Za-z0-9_-]{40,}(?:=(?:s\d+(?:-[A-Za-z0-9-]+)?|mm,\d+,\d+))?", u.path)):
                u = u._replace(path=re.sub(r"=(?:s\d+(?:-[A-Za-z0-9-]+)?|mm,\d+,\d+)$", "", u.path))
                src = urlunsplit(u)
            stable_id = bool(re.search(r'[0-9a-f]{8}-[0-9a-f-]{27,}', u.path, re.I)) or any(
                k.lower() in ('id', 'assetid', 'mediaid', 'asset_id', 'media_id') and v for k, v in query)
            if stable_id:
                query = [(k,v) for k,v in query if not k.lower().startswith('x-goog-') and
                         k.lower() not in ('signature', 'expires', 'googleaccessid',
                                           'w', 'h', 'width', 'height', 'sz')]
                src = urlunsplit((u.scheme, u.netloc, u.path, urlencode(sorted(query)), u.fragment))
            return src, kind
        except (ValueError, TypeError):
            return None
    a, b = identity(left), identity(right)
    if a is None or b is None:
        return False
    return a[0] == b[0] if ignore_kind else a == b


def video_reference_plan(compiled, refs):
    """Return byte-unique references and labels bound to their actual positions.

    Never call the character photo an end frame when a duplicate closing frame
    was removed. Reserve slots for the user's cast before optional environment.
    """
    cast = [p for p in compiled.get('reference_paths', []) if p and 'character-' in os.path.basename(p)]
    cast = cast or ([refs['character']] if refs.get('character') else [])
    frames_only = compiled.get('flow_video_mode') == 'frames'
    if frames_only:
        for path in cast:
            if not os.path.isfile(path):
                raise FlowReferenceUnavailable('Selected cast photo is missing locally; no video generation submitted')
    candidates = [('START', refs.get('start'))]
    if frames_only or len(cast) <= 2:
        candidates.append(('END', refs.get('end')))
    if not frames_only:
        candidates += [('IDENTITY', p) for p in cast] + [('LOCATION', refs.get('location'))]
    paths, indexes, roles = [], {}, []
    for role, path in candidates:
        if not path or not os.path.isfile(path):
            if role == 'IDENTITY' and path:
                raise FlowReferenceUnavailable('Selected cast photo is missing locally; no video generation submitted')
            continue
        h = hashlib.sha256()
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(1024*1024), b''):
                h.update(chunk)
        key = h.hexdigest()
        if key not in indexes:
            if len(paths) >= 4:
                if role == 'IDENTITY':
                    raise FlowUIChanged('Cast needs more than four distinct references; no video generation submitted')
                continue
            paths.append(path)
            indexes[key] = len(paths)
        roles.append((role, indexes[key]))
    labels = []
    for role, index in roles:
        if role in ('START', 'END'):
            labels.append(f'Use attached image {index} as the exact {role} frame.')
        elif role == 'IDENTITY':
            labels.append(f'Preserve the identity and wardrobe in attached image {index} exactly.')
        elif role == 'LOCATION':
            labels.append(f'Use attached image {index} for environment continuity.')
    return paths, ' '.join(labels)


def media_signature_kind(signature):
    """Return the typed media kind encoded in a Flow tile signature, if known."""
    try:
        tag, src, tail = str(signature).split('|', 2)
        _, kind, width, height = tail.rsplit('|', 3)
        if tag.upper() not in ('IMG', 'VIDEO') or kind.lower() not in ('image', 'video', 'pending') or not src:
            return None
        float(width)
        float(height)
        return kind.lower()
    except (ValueError, TypeError):
        return None


_FLOW_QUEUE_STATUS_RE = re.compile(
    r"(?:"
    r"(?:video|image|generation|request).{0,100}(?:scheduled|queued|waiting\s+(?:in\s+)?the\s+queue)|"
    r"(?:scheduled|queued).{0,100}(?:waiting\s+(?:in\s+)?the\s+queue|high\s+demand)|"
    r"waiting\s+(?:in\s+)?the\s+queue|(?:queued|in\s+the\s+queue)\s+due\s+to\s+high\s+demand|"
    r"scheduled\s+and\s+waiting\s+in\s+queue|"
    r"your\s+video\s+has\s+been\s+scheduled"
    r")",
    re.I,
)


def _is_flow_queue_status(text: str) -> bool:
    """Recognize Flow's accepted-but-not-rendered queue cards.

    The Agent may render the queue card with an image thumbnail. That thumbnail
    is not a playable clip and must not be promoted to a video merely because the
    surrounding card says "your video".
    """
    return bool(_FLOW_QUEUE_STATUS_RE.search(str(text or "")))


def find_system_chrome() -> str | None:
    """Locate an installed Chrome/Chromium (incl. Windows Chrome visible from WSL)."""
    cands = []
    for c in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser",
              "microsoft-edge", "microsoft-edge-stable"):
        try:
            p = shutil.which(c)
        except Exception:
            p = None
        if p:
            cands.append(p)
    cands += [
        "/mnt/c/Program Files/Google/Chrome/Application/chrome.exe",
        "/mnt/c/Program Files (x86)/Google/Chrome/Application/chrome.exe",
        "C:/Program Files/Google/Chrome/Application/chrome.exe",
        "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/usr/bin/chromium",
    ]
    for p in cands:
        try:
            if p and os.path.exists(p):
                return p
        except Exception:
            pass
    return None


def to_windows_path(p: str) -> str | None:
    """/mnt/c/Users/x -> C:\\Users\\x. None when not convertible (native Linux fs)."""
    import re
    m = re.match(r"^/mnt/([a-zA-Z])/(.*)$", os.path.abspath(p))
    if not m:
        return None
    return f"{m.group(1).upper()}:" + "\\" + m.group(2).replace("/", "\\")


def is_windows_exe(exe: str) -> bool:
    el = (exe or "").lower()
    return el.endswith(".exe") or el.startswith("/mnt/") or (len(el) > 2 and el[1] == ":")


def is_wsl() -> bool:
    try:
        with open("/proc/version", encoding="utf-8", errors="ignore") as f:
            return "microsoft" in f.read().lower()
    except Exception:
        return False


def default_profile_dir() -> str:
    """Browser profile home. Under WSL this MUST be on the Linux filesystem:
    Chromium lock files / SQLite break on /mnt/c (DrvFs) and the browser dies
    at launch with 'Target page, context or browser has been closed'."""
    if is_wsl():
        return os.path.join(os.path.expanduser("~"), ".local", "share",
                            "autovideoai", "flow-profile")
    return os.path.abspath(".flow-profile")


PROFILE_DIR = default_profile_dir()


def maybe_migrate_profile() -> str | None:
    """One-time: copy a session from legacy ./.flow-profile to the WSL home dir."""
    if not is_wsl():
        return None
    legacy = os.path.abspath(".flow-profile")
    if os.path.isdir(legacy) and os.listdir(legacy) and not os.path.exists(PROFILE_DIR):
        try:
            import shutil
            shutil.copytree(legacy, PROFILE_DIR)
            return PROFILE_DIR
        except Exception:
            return None
    return None


def has_native_linux_chrome() -> bool:
    return any(shutil.which(c) for c in ("google-chrome", "google-chrome-stable",
                                        "chromium", "chromium-browser"))


def short_browser_error(e: BaseException, limit: int = 700) -> str:
    """One-line summary PLUS the 'Browser logs' tail (the part that names the cause).

    Playwright buries the reason after a 'Browser logs:' marker - naive [:140]
    truncation throws the diagnosis away, so preserve that section explicitly.
    """
    txt = str(e)
    head = txt.split("Browser logs:")[0].strip().splitlines()
    head = head[0][:160] if head else txt[:160]
    logs = ""
    if "Browser logs:" in txt:
        logs = txt.split("Browser logs:", 1)[1].strip()
        logs = "\n".join(logs.splitlines()[:12])[: max(0, limit - len(head) - 12)]
    return head if not logs else f"{head} | logs: {logs}"


def missing_shared_libs(exe_path: str) -> list[str]:
    """Parse `ldd` for 'not found' entries. [] = deps ok (or ldd unavailable)."""
    try:
        r = subprocess.run(["ldd", exe_path], capture_output=True, text=True, timeout=30)
        out = (r.stdout or "") + (r.stderr or "")
        return sorted({ln.split("=>")[0].strip() for ln in out.splitlines()
                       if "not found" in ln})
    except Exception:
        return []


def probe_cdp(url: str, timeout: int = 5) -> dict:
    """Check a Chrome remote-debugging endpoint. Returns {ok, browser?, error?}."""
    import requests
    try:
        r = requests.get(url.rstrip("/") + "/json/version", timeout=timeout)
        if r.status_code == 200:
            j = r.json()
            return {"ok": True, "browser": j.get("Browser", "?"),
                    "ws": bool(j.get("webSocketDebuggerUrl"))}
        return {"ok": False, "error": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)[:160]}


def cdp_is_live(url: str, timeout: int = 5) -> bool:
    """Bool wrapper (a result dict is always truthy - never `if probe_cdp()`)."""
    try:
        return bool(probe_cdp(url, timeout=timeout).get("ok"))
    except Exception:
        return False


def doctor_report() -> str:
    """Human-readable diagnostics for Flow browser setup. No browser is launched."""
    import sys
    import platform as _plat
    lines = []
    lines.append(f"Python {sys.version.split()[0]} on {_plat.system()} {_plat.release()} | WSL={is_wsl()}")
    try:
        import playwright
        lines.append(f"playwright pip package: {getattr(playwright, '__version__', 'installed')}")
    except ImportError:
        lines.append("playwright pip package: MISSING (pip install playwright)")
    bundled = sorted(glob.glob(os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux*/chrome")))
    if bundled:
        miss = missing_shared_libs(bundled[0])
        if miss:
            lines.append(f"bundled chromium: {bundled[0]}")
            lines.append(f"bundled chromium MISSING LIBS ({len(miss)}): {', '.join(miss[:8])}")
            lines.append("  -> run: python3 -m playwright install --with-deps chromium")
        else:
            lines.append(f"bundled chromium: {bundled[0]} (deps ok)")
    else:
        lines.append("bundled chromium: NOT DOWNLOADED (python3 -m playwright install chromium)")
    if is_wsl():
        lines.append(f"WSLg display: DISPLAY={os.getenv('DISPLAY') or '-'} "
                     f"WAYLAND_DISPLAY={os.getenv('WAYLAND_DISPLAY') or '-'} "
                     f"{'(no GUI transport - run wsl --update + wsl --shutdown from PowerShell)' if not os.getenv('DISPLAY') and not os.getenv('WAYLAND_DISPLAY') else ''}".rstrip())
    sys_chrome = find_system_chrome()
    if sys_chrome and is_wsl() and is_windows_exe(sys_chrome):
        lines.append(f"Windows Chrome visible from WSL: {sys_chrome}")
        lines.append("launchable system chrome: none (Linux Playwright cannot drive a "
                     "Windows .exe - use CDP mode or bundled; see FLOW_SETUP.md)")
    else:
        lines.append(f"system chrome: {sys_chrome or 'not found'}")
    prof = PROFILE_DIR
    lines.append(f"profile dir: {prof}")
    try:
        ui = yaml.safe_load(open("config/flow_ui.yaml", encoding="utf-8"))
        bcfg = resolve_browser_cfg(ui)
    except Exception:
        bcfg = {}
    lines.append(f"browser mode: {(bcfg.get('mode') or 'auto')} | channel={bcfg.get('channel', 'chrome')} | "
                 f"exe={bcfg.get('executable') or '-'} | cdp={bcfg.get('cdp_url') or '-'}")
    cands = []
    if bcfg.get("cdp_url"):
        cands.append(bcfg["cdp_url"])
    for u in ("http://localhost:9222", "http://127.0.0.1:9222"):
        if u not in cands:
            cands.append(u)
    any_cdp = False
    for u in cands:
        r = probe_cdp(u, timeout=3)
        if r.get("ok"):
            any_cdp = True
        lines.append(f"CDP {u}: {'OK ' + r.get('browser', '') if r['ok'] else 'unreachable (' + r.get('error', '?') + ')'}")
    if is_wsl() and not any_cdp:
        lines.append("WSL hint: if Chrome IS running with --remote-debugging-port=9222 on "
                     "Windows but CDP is unreachable, it is WSL networking (NAT vs mirrored) - "
                     "see FLOW_SETUP.md, or use bundled: python3 -m playwright install chromium")
    return "\n".join(lines)


def browser_test_verdict(variants: list[dict]) -> str:
    """Sentence from a browser_self_test variant list. Pure -> unit-tested."""
    headed = [v for v in variants if v.get("headed")]
    headless_ok = any(v["ok"] for v in variants if not v.get("headed"))
    if any(v["ok"] for v in headed):
        first = next(v["name"] for v in headed if v["ok"])
        return (f"Headed launch WORKS ({first}). If the app still fails, compare the "
                f"REAL-profile variant: if only that one fails, delete {PROFILE_DIR} "
                f"(stale lock) and log in again.")
    details = " ".join(v.get("detail", "") for v in headed)
    if "without having a XServer running" in details:
        return ("No X server is answering (DISPLAY is set but WSLg's GUI layer is "
                "down). Fix: PowerShell (admin) -> wsl --update -> wsl --shutdown -> "
                "reopen WSL. Verify with: ls /mnt/wslg/ /tmp/.X11-unix/ (sockets must "
                "exist). Corporate VPN/firewall can also block WSLg - retry off-VPN. "
                "Alternative that needs no WSLg at all: CDP to Windows Chrome "
                "(FLOW_SETUP.md: mirrored networking + chrome-debug.bat).")
    if headless_ok:
        return ("Engine works HEADLESS but no headed variant launched: this is a "
                "display/GPU issue (WSLg). From PowerShell run wsl --update, "
                "wsl --shutdown, reopen WSL and retry. Screenshots: logs/flow/.")
    return ("Even headless failed: Playwright/Chromium install is broken. Run "
            "python3 -m playwright install --with-deps chromium (full output, "
            "allow sudo), then retry.")


def browser_self_test(log_dir: str = "logs/flow", url: str = "https://example.com") -> dict:
    """Launch bundled Chromium with progressive flag sets; report what works.

    Returns {"variants": [{name, ok, detail, screenshot?}], "verdict": str}.
    Uses throwaway profiles (except the real-profile probe) - never touches
    saved logins. Worst case takes a few minutes (each variant has timeouts).
    """
    import tempfile
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return {"variants": [], "verdict": "playwright pip package missing (pip install playwright)"}
    os.makedirs(log_dir, exist_ok=True)
    base = ["--disable-dev-shm-usage", "--no-first-run", "--no-default-browser-check"]
    # (name, headless, extra_args, real_profile, wayland_env)
    variants = [
        ("headed clean-profile, default flags", False, [], False, False),
        ("headed clean-profile + --disable-gpu", False, ["--disable-gpu"], False, False),
        ("headed clean-profile + --disable-gpu --no-sandbox", False,
         ["--disable-gpu", "--no-sandbox"], False, False),
        ("headed clean-profile, native Wayland (bypasses X)", False,
         ["--ozone-platform=wayland"], False, True),
        ("headed REAL profile, native Wayland", False,
         ["--ozone-platform=wayland"], True, True),
        ("headed REAL profile, default X11 flags", False, [], True, False),
        ("headless clean-profile (engine sanity)", True, [], False, False),
    ]
    out: list[dict] = []
    pw = sync_playwright().start()
    try:
        for i, (name, headless, extra, real_prof, wl) in enumerate(variants, 1):
            prof = PROFILE_DIR if real_prof else tempfile.mkdtemp(prefix="av-browsertest-")
            shot = os.path.join(log_dir, f"browser-test-{i}.png")
            rec: dict = {"name": name, "headed": not headless, "ok": False,
                         "detail": "", "screenshot": ""}
            ctx = None
            try:
                kw: dict = {}
                if wl:
                    env = dict(os.environ)
                    env.pop("DISPLAY", None)
                    env["WAYLAND_DISPLAY"] = os.environ.get("WAYLAND_DISPLAY", "wayland-0")
                    rtd = f"/run/user/{os.getuid()}"
                    env["XDG_RUNTIME_DIR"] = rtd if os.path.isdir(rtd) else env.get(
                        "XDG_RUNTIME_DIR", rtd)
                    kw["env"] = env
                ctx = pw.chromium.launch_persistent_context(
                    prof, headless=headless, args=base + extra, timeout=30000, **kw)
                pg = ctx.pages[0] if ctx.pages else ctx.new_page()
                pg.goto(url, timeout=20000)
                rec["ok"] = True
                rec["detail"] = f"title={pg.title()!r} url={pg.url}"
                try:
                    pg.screenshot(path=shot)
                    rec["screenshot"] = shot
                except Exception:
                    pass
            except Exception as e:
                rec["detail"] = short_browser_error(e, limit=400)
            finally:
                try:
                    if ctx:
                        ctx.close()
                except Exception:
                    pass
                if not real_prof:
                    try:
                        import shutil as _sh
                        _sh.rmtree(prof, ignore_errors=True)
                    except Exception:
                        pass
            out.append(rec)
    finally:
        try:
            pw.stop()
        except Exception:
            pass
    return {"variants": out, "verdict": browser_test_verdict(out)}


def resolve_browser_cfg(ui: dict) -> dict:
    """flow_ui.yaml browser: < user_settings.yaml < FLOW_* env vars."""
    cfg = dict((ui.get("browser") or {}))
    try:
        if os.path.exists("config/user_settings.yaml"):
            g = yaml.safe_load(open("config/user_settings.yaml", encoding="utf-8")) or {}
            for k, v in ((g.get("browser") or {}).items()):
                if v or k == 'quiet':
                    cfg[k] = v
    except Exception:
        pass
    for env, key in (("FLOW_BROWSER_MODE", "mode"), ("FLOW_BROWSER_CHANNEL", "channel"),
                     ("FLOW_BROWSER_EXE", "executable"), ("FLOW_CDP_URL", "cdp_url")):
        if os.getenv(env):
            cfg[key] = os.getenv(env)
    cfg.setdefault("mode", "auto")
    cfg.setdefault("channel", "chrome")
    return cfg


class FlowAuthNeeded(Exception):
    pass


# Flow paints a placeholder or 360p preview first and prepares the real file in
# the background. These checks let the downloader wait for the loaded element.
_MEDIA_READY_JS = r"""el => {
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    const visible = r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
    const loaded = el.tagName === 'VIDEO'
        ? (el.readyState >= 2 && el.videoWidth > 0)
        : (el.complete && el.naturalWidth > 0);
    const scope = el.parentElement;
    const busy = !!el.closest('[aria-busy="true"]') || !!(scope && scope.querySelector(
        ':scope > [role="progressbar"], :scope > mat-spinner, :scope > mat-progress-spinner, :scope > .spinner'));
    return {ready: visible && loaded && !busy && !el.error, src: el.currentSrc || el.src || el.poster || ''};
}"""

_MEDIA_PICK_JS = r"""() => {
    let best = -1, area = 0;
    document.querySelectorAll('video,img').forEach((el, i) => {
        const r = el.getBoundingClientRect(), s = getComputedStyle(el);
        if (r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden' && r.width * r.height > area) {
            area = r.width * r.height;
            best = i;
        }
    });
    return best;
}"""


class FlowUIChanged(Exception):
    """A selector failed -> caller should switch to Assisted Flow Mode."""
    pass


class FlowReferenceUnavailable(FlowUIChanged):
    """Pre-submit reference attachment exhausted its bounded recovery.

    Repeating the entire frame/video immediately cannot repair a picker whose
    byte-identical reattachment allowance has already been used. No prompt sent.
    """
    pass


class FlowRequestPending(FlowUIChanged):
    """A request was submitted; download failure must not authorize generation."""
    pass


class FlowTransientNetworkError(Exception):
    """Temporary connectivity/browser transport failure. Safe to pause and retry."""
    pass


class FlowServiceBusy(Exception):
    """Flow Agent is temporarily at capacity/high demand. No prompt defect implied."""
    pass


class FlowBrowserClosedError(Exception):
    """The Playwright page/context/browser disappeared during a recoverable operation."""
    pass


def launch_fix_hint(errors: list[str]) -> str:
    """Contextual next-steps based on WHY the launch failed. Pure -> tested."""
    blob = " | ".join(errors)
    parts = ["FIX: run `python3 cli.py v3 doctor` + `python3 cli.py v3 browser-test` for diagnosis."]
    if "without having a XServer running" in blob:
        if is_wsl():
            parts.append("X11/Xwayland is unavailable. AutoVideoAI now tries native Wayland first; "
                         "if Wayland also failed, run `python3 cli.py v3 browser-test` and inspect "
                         "the native-Wayland result before changing WSL settings.")
        else:
            parts.append("No X server is available for a headed browser.")
    if is_wsl():
        parts.append("NO-WSLg ROUTE: on Windows run chrome-debug.bat, then from WSL test "
                     "`curl http://127.0.0.1:9222/json/version` (expect JSON). If JSON: app "
                     "SETTINGS -> Browser mode = cdp. If unreachable: mirrored networking "
                     "(.wslconfig networkingMode=mirrored + wsl --shutdown) or stay on bundled.")
    parts.append("Just want a video NOW with no browser? CREATE -> one-click FREE test "
                 "video (FREE_HYBRID).")
    return " ".join(parts)


class FlowQuotaExceeded(Exception):
    pass


class FlowBrowser:
    """Low-level Flow session. One instance per job (or shared, then close())."""

    def __init__(self, ui_cfg_path: str = "config/flow_ui.yaml",
                 profile_dir: str = PROFILE_DIR, headless: bool = False,
                 state_cb=None):
        try:
            maybe_migrate_profile()
        except Exception:
            pass
        self.ui = yaml.safe_load(open(ui_cfg_path, encoding="utf-8"))
        self.profile_dir = profile_dir
        self.headless = headless
        self.state_cb = state_cb
        self.state = FlowState.IDLE
        self._pw = self._ctx = self._page = self._cdp = None
        self._own_context = False
        self._guard_page = None  # stable project tab kept alive during fragile media-editor/download operations
        self._owns_page = False
        self._owns_guard_page = False
        self._isolated_worker = (
            os.path.basename(os.path.dirname(os.path.abspath(profile_dir or ""))) == ".flow-workers"
        )
        self.bcfg = resolve_browser_cfg(self.ui)
        self.active_browser = "?"
        self.log_dir = "logs/flow"
        os.makedirs(self.log_dir, exist_ok=True)
        self._project_ready: str | None = None  # logical AutoVideoAI project key
        self._project_url: str | None = None    # actual Flow /project/<uuid> URL
        self.last_generated_asset_signature: str | None = None
        self._generation_baseline_signatures: set[str] = set()
        # Snapshot of Agent failure-text counts immediately before the current
        # request is submitted. Flow keeps historical turns in the DOM; without
        # this, an old "generation failed"/"blocked" card can poison a later
        # image request and make wait_for_agent_generation() return False at once.
        self._agent_failure_baseline: dict[str, int] = {}

    # ---------- lifecycle ----------
    def _set(self, s: FlowState):
        self.state = s
        if self.state_cb:
            try:
                self.state_cb(s.value)
            except Exception:
                pass

    def _launch_options(self) -> list[dict]:
        mode = (self.bcfg.get("mode") or "auto").lower()
        from engine.quiet_browser import quiet_enabled
        if quiet_enabled(self.bcfg):
            if mode == "cdp":
                raise RuntimeError("Quiet mode cannot attach a visible CDP browser")
            mode = "bundled"
        self._launch_skipped: list[str] = []
        opts = []
        if mode in ("auto", "system"):
            if is_wsl() and not has_native_linux_chrome():
                self._launch_skipped.append(
                    "channel: skipped (no native Linux Chrome in WSL - use CDP or bundled)")
            else:
                opts.append({"kind": "channel", "channel": self.bcfg.get("channel", "chrome")})
            exe = self.bcfg.get("executable") or find_system_chrome()
            if exe:
                if is_wsl() and is_windows_exe(exe):
                    # Linux Playwright cannot drive a Windows .exe (cross-OS stdio):
                    # it always dies with "Target page, context or browser has been
                    # closed". Never attempt it - CDP or bundled instead.
                    self._launch_skipped.append(
                        f"exe: skipped {exe} (Windows Chrome is not launchable from WSL "
                        f"- use CDP mode with chrome-debug.bat, or bundled)")
                else:
                    opts.append({"kind": "exe", "executable": exe})
        if mode in ("auto", "bundled"):
            opts.append({"kind": "bundled"})
        return opts

    def _launch_persistent(self, opt: dict):
        """Launch a persistent context using the GUI transport that actually works.

        Important for WSLg: Chromium can have a healthy Wayland socket while the X11
        compatibility socket is unavailable.  browser_self_test already probes this,
        so the production launcher must mirror that behaviour instead of always
        assuming X11.  On WSL headed sessions we therefore try native Wayland first
        and only then fall back to the historical X11 flags.
        """
        kwargs: dict = {}
        profile = self.profile_dir
        if opt["kind"] == "channel":
            kwargs["channel"] = opt["channel"]
        elif opt["kind"] == "exe":
            exe = opt["executable"]
            kwargs["executable_path"] = exe
            if is_windows_exe(exe):
                # Windows Chrome cannot parse WSL/Linux paths -> translate.
                w = to_windows_path(profile)
                if not w:
                    raise RuntimeError(
                        f"Windows Chrome cannot use Linux profile path {profile}. "
                        f"Move the project under /mnt/<drive>/, or use CDP mode (FLOW_SETUP.md).")
                profile = w

        os.makedirs(self.profile_dir, exist_ok=True)
        common_args = ["--disable-blink-features=AutomationControlled",
                       "--disable-dev-shm-usage",
                       "--no-first-run", "--no-default-browser-check"]

        if is_wsl() and not self.headless:
            common_args += ["--disable-gpu", "--disable-background-timer-throttling",
                            "--disable-renderer-backgrounding"]
        # (transport label, extra args, optional environment)
        strategies: list[tuple[str, list[str], dict | None]] = []
        from engine.quiet_browser import quiet_enabled, browser_environment
        if quiet_enabled(self.bcfg):
            strategies.append(("quiet-x11", ["--ozone-platform=x11", "--disable-gpu"], browser_environment()))
        elif is_wsl() and not self.headless:
            # Native Wayland is the most reliable WSLg route and is exactly the
            # variant used by browser-test when it reports "native Wayland" PASS.
            env = dict(os.environ)
            env.pop("DISPLAY", None)  # prevent Chromium silently choosing X11
            env["WAYLAND_DISPLAY"] = os.environ.get("WAYLAND_DISPLAY", "wayland-0")
            rtd = f"/run/user/{os.getuid()}"
            env["XDG_RUNTIME_DIR"] = rtd if os.path.isdir(rtd) else env.get(
                "XDG_RUNTIME_DIR", rtd)
            # WSLg Wayland can terminate a long download with Broken pipe.
            # Prefer the available X11 transport; retain Wayland as fallback.
            if os.environ.get("DISPLAY"):
                strategies.append(("x11", ["--ozone-platform=x11", "--disable-gpu"], None))
            strategies.append(("wayland", ["--ozone-platform=wayland"], env))
        else:
            strategies.append(("headless" if self.headless else "native", [], None))

        launch_errors: list[str] = []
        for transport, extra_args, launch_env in strategies:
            try:
                launch_kwargs = dict(kwargs)
                if launch_env is not None:
                    launch_kwargs["env"] = launch_env
                self._ctx = self._pw.chromium.launch_persistent_context(
                    profile,
                    headless=False if quiet_enabled(self.bcfg) else self.headless,
                    accept_downloads=True,
                    args=common_args + extra_args,
                    **launch_kwargs,
                )
                self._own_context = True
                self._page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()
                self._prune_owned_blank_tabs()
                base = {"channel": f"system {opt.get('channel')}",
                        "exe": f"system ({opt.get('executable')})",
                        "bundled": "playwright chromium"}.get(opt["kind"], "?")
                self.active_browser = f"{base} [{transport}]"
                # v7.0.89: record which launch transport ran, so a browser crash can be matched to it.
                diag("browser launched: " + self.active_browser
                     + "; display=" + ("set" if os.getenv("DISPLAY") else "unset")
                     + "; wayland=" + ("set" if os.getenv("WAYLAND_DISPLAY") else "unset"))
                return
            except Exception as e:
                launch_errors.append(f"{transport}: {short_browser_error(e, limit=450)}")
                try:
                    if self._ctx:
                        self._ctx.close()
                except Exception:
                    pass
                self._ctx = self._page = None

        raise RuntimeError("; ".join(launch_errors) if launch_errors else "browser launch failed")

    def _prune_owned_blank_tabs(self):
        """Remove restored recovery blanks only in our dedicated browser context."""
        if not getattr(self, '_own_context', False):return
        pages=list(getattr(self._ctx, 'pages', []) or [])
        flow=[]
        for page in pages:
            try:
                if not page.is_closed() and self.normalize_project_url(getattr(page,'url','')):
                    flow.append(page)
            except Exception:continue
        if flow:self._page=flow[-1]
        for page in pages:
            if page is self._page or page is getattr(self,'_guard_page',None):continue
            try:
                if not page.is_closed() and str(page.url or '') in ('','about:blank'):
                    page.close()
            except Exception:pass

    def _connect_cdp(self, url: str):
        self._cdp = self._pw.chromium.connect_over_cdp(url, timeout=15000)
        ctxs = self._cdp.contexts
        if ctxs:
            self._ctx = ctxs[0]
            self._own_context = False  # never close the user's own tabs
        else:
            self._ctx = self._cdp.new_context(accept_downloads=True)
            self._own_context = True
        if getattr(self, "_isolated_worker", False):
            # CDP workers share Google's logged-in browser context but get their
            # own tab; never navigate the user's tab or another worker's tab.
            self._page = self._ctx.new_page()
            self._owns_page = True
            print("[Flow] Parallel image worker attached to CDP in a dedicated tab.")
        else:
            # A resumed job often attaches to a Chrome session with several tabs,
            # including an initial about:blank tab. Prefer an existing Flow tab;
            # otherwise reuse a blank tab before creating anything. Never
            # commandeer an unrelated user tab (mail/docs/etc.) just because it
            # happens to be pages[0].
            try:
                candidates = list(self._ctx.pages or [])
            except Exception:
                candidates = []
            pages = []
            for pg in candidates:
                try:
                    if not pg.is_closed():
                        pages.append(pg)
                except Exception:
                    continue

            def page_url(pg):
                try:
                    return str(getattr(pg, "url", "") or "").strip()
                except Exception:
                    return ""

            try:
                from urllib.parse import urlsplit
                flow_pages = [pg for pg in pages
                              if urlsplit(page_url(pg)).hostname == "flow.google.com"]
            except Exception:
                flow_pages = []
            blank_pages = [pg for pg in pages
                           if page_url(pg).lower() in ("", "about:blank", "chrome://newtab/", "edge://newtab/")]
            if flow_pages:
                self._page = flow_pages[-1]
                self._owns_page = False
                print("[Flow] Reusing an existing Google Flow tab from the attached browser.")
            elif blank_pages:
                self._page = blank_pages[-1]
                self._owns_page = False
                print("[Flow] Reusing an existing blank tab for Flow; no additional tab opened.")
            else:
                self._page = self._ctx.new_page()
                # This tab lives inside the user's CDP context. Keep the single
                # dedicated Flow tab open after a provider call so the next
                # resumed shot can reuse it instead of opening/closing about:blank
                # tabs repeatedly. Parallel worker tabs above remain owned and are
                # still closed when their worker finishes.
                self._owns_page = False
                print("[Flow] Opened a reusable Flow tab; existing non-Flow tabs were left untouched.")
        self.active_browser = f"attached browser ({url})"

    def ensure_session(self, visible_login_seconds: int = 240):
        """Attach/launch a browser; user logs in manually on first run."""
        from playwright.sync_api import sync_playwright
        self._pw = sync_playwright().start()
        # Workers isolate their Flow tabs/projects. In configured CDP mode keep
        # the already-authenticated Windows/WSL Chrome session; otherwise launch
        # a persistent worker profile as usual.
        mode = (self.bcfg.get("mode") or "auto").lower()
        from engine.quiet_browser import quiet_enabled
        if quiet_enabled(self.bcfg):
            if mode == "cdp":
                raise RuntimeError("Quiet mode needs a local Linux browser. Select bundled or system instead of CDP.")
            mode = "bundled"  # never attach a visible desktop CDP browser
        if self._isolated_worker:
            print("[Flow] Isolated image worker: using a dedicated project and browser tab/profile.")
        errors: list[str] = []
        cdp_configured = (self.bcfg.get("cdp_url") or "").strip()
        if mode in ("auto", "cdp") and cdp_configured:
            try:
                self._connect_cdp(cdp_configured)
                return self._post_connect(visible_login_seconds)
            except Exception as e:
                errors.append(f"CDP {cdp_configured}: {short_browser_error(e)}")
                if mode == "cdp":
                    raise RuntimeError("CDP attach failed. Is Chrome running with "
                                       "--remote-debugging-port? See FLOW_SETUP.md. "
                                       f"({'; '.join(errors)})")
        if mode in ("auto", "cdp") and not cdp_configured:
            # Zero-config: is there a debug Chrome already listening?
            for u in ("http://127.0.0.1:9222", "http://localhost:9222"):
                try:
                    if probe_cdp(u, timeout=2).get("ok"):
                        self._connect_cdp(u)
                        return self._post_connect(visible_login_seconds)
                except Exception:
                    pass
        for opt in self._launch_options():
            try:
                self._launch_persistent(opt)
                return self._post_connect(visible_login_seconds)
            except FlowAuthNeeded:
                raise  # Login timeout must not start another browser/profile.
            except Exception as e:
                errors.append(f"{opt['kind']}: {short_browser_error(e)}")
        errors += getattr(self, "_launch_skipped", [])
        raise RuntimeError(
            "Could not start any browser. " + (" | ".join(errors) if errors else "no launch options") +
            " " + launch_fix_hint(errors))

    def _post_connect(self, visible_login_seconds: int):
        self._set(FlowState.WAITING_FOR_UI)
        current_url = str(getattr(self._page, "url", "") or "")
        try:
            from urllib.parse import urlsplit
            already_on_flow = urlsplit(current_url).hostname == "flow.google.com"
        except Exception:
            already_on_flow = False
        if not already_on_flow:
            self._page.goto(self.ui.get("flow_url", "https://flow.google.com/"), timeout=60000)
        else:
            # Keep the user's existing project route. ensure_project() will bind
            # the saved job URL after attachment; navigating to Flow home first
            # caused needless route churn (and blank-tab flicker) on Resume.
            print("[Flow] Attached on an existing Flow tab; preserving its current route.")
        # A Flow landing-page sign-in wall is not an authenticated session.
        deadline = time.monotonic() + max(1, visible_login_seconds)
        while time.monotonic() < deadline:
            if self.is_logged_in():
                return True
            if self._page.is_closed():
                raise FlowAuthNeeded("Login browser was closed. Reopen Flow Session and complete sign-in manually.")
            self._page.wait_for_timeout(1000)
        raise FlowAuthNeeded("Google login not completed. Complete sign-in in the opened browser, then retry.")

    def is_logged_in(self) -> bool:
        from urllib.parse import urlsplit
        try:
            if not self._page or self._page.is_closed():
                return False
            url = urlsplit(str(self._page.url or ""))
            if url.hostname != "flow.google.com":
                return False
            signin = self._page.get_by_text(re.compile(r"^\s*(?:sign in(?: with google)?|log in(?: with google)?)\s*$", re.I))
            if any(signin.nth(i).is_visible(timeout=100) for i in range(signin.count())):
                return False
            if url.path.startswith('/project/'):
                return True
            projects = self._page.get_by_text('New project', exact=True)
            if any(projects.nth(i).is_visible(timeout=100) for i in range(projects.count())):
                return True
            for selector in ("[contenteditable='true']", "button:has-text('New project')"):
                controls = self._page.locator(selector)
                if any(controls.nth(i).is_visible(timeout=100) for i in range(controls.count())):
                    return True
            return False
        except Exception:
            return False

    def close(self):
        """Release our Playwright resources without killing a user-owned CDP browser.

        Older builds unconditionally closed ``self._ctx``. When attached over CDP
        this could close the visible Chrome session the user is interacting with.
        CDP contexts are left alive; their ordinary Flow tab is deliberately kept
        open for reuse across resumed shots. Isolated parallel-worker tabs are
        owned and closed, while Playwright simply disconnects from the CDP browser.
        """
        # Close only tabs explicitly owned by this worker. In a shared CDP context
        # the dedicated normal Flow tab is intentionally marked reusable, avoiding
        # a new about:blank tab on each provider reconnect.
        for page, owned in ((getattr(self, "_page", None), getattr(self, "_owns_page", False)),
                            (getattr(self, "_guard_page", None), getattr(self, "_owns_guard_page", False))):
            if owned and page is not None:
                try:
                    if not page.is_closed():
                        page.close()
                except Exception:
                    pass
        try:
            if self._ctx and self._own_context:
                self._ctx.close()
        except Exception:
            pass
        try:
            if self._pw:
                self._pw.stop()
        except Exception:
            pass
        self._pw = self._ctx = self._page = self._cdp = None
        self._guard_page = None
        self._owns_page = self._owns_guard_page = False
        self._set(FlowState.IDLE)

    # ---------- locator helpers (config-driven) ----------
    def _candidates(self, action: str):
        cands = self.ui.get("actions", {}).get(action, [])
        return cands if isinstance(cands, list) else [cands]

    def _build_locator(self, c: dict):
        by = c.get("by")
        if by == "role":
            if c.get('name_exact'):
                return self._page.get_by_role(c['role'], name=c['name_exact'], exact=True)
            name_contains = c.get("name_contains")
            if name_contains:
                return self._page.get_by_role(
                    c["role"], name=re.compile(re.escape(name_contains), re.I)
                )
            return self._page.get_by_role(c["role"])
        if by == "text":
            return self._page.get_by_text(c["text"], exact=bool(c.get('exact', False)))
        if by == "placeholder":
            return self._page.get_by_placeholder(c.get("text_contains", ""))
        if by == "css":
            return self._page.locator(c["selector"])
        return None

    def _resolve(self, action: str, timeout_ms: int = 8000, fmt: dict | None = None):
        """Resolve an action within ONE total timeout budget.

        Older builds accidentally waited the full timeout for every selector
        candidate. With five candidates and timeout_ms=12000 that could look
        frozen for about a minute before trying the selector that actually
        matched. This implementation polls all candidates rapidly until the
        shared deadline expires.
        """
        cands = self._candidates(action)
        deadline = time.time() + max(0.25, timeout_ms / 1000.0)
        errs = []
        while time.time() < deadline:
            for c in cands:
                try:
                    loc = self._build_locator(c)
                    if loc is None:
                        continue
                    for index in range(min(loc.count(), 30)):
                        candidate = loc.nth(index)
                        if candidate.is_visible(timeout=100):
                            return candidate
                except Exception as e:
                    msg = str(e).replace("\n", " ")[:90]
                    if msg and msg not in errs:
                        errs.append(msg)
            self._page.wait_for_timeout(150)
        detail = '; '.join(errs[:3])[:220]
        raise FlowUIChanged(f"UI element not found: {action}" + (f" ({detail})" if detail else ""))

    def _try_resolve(self, action: str, timeout_ms: int = 1500):
        try:
            return self._resolve(action, timeout_ms=timeout_ms)
        except FlowUIChanged:
            return None

    def _click_text(self, text: str, timeout_ms: int = 8000):
        try:
            loc = self._page.get_by_text(text, exact=False).first
            loc.wait_for(timeout=timeout_ms)
            loc.click()
        except Exception as e:
            raise FlowUIChanged(f"Cannot click '{text}': {e}")

    def snapshot_failure(self, job_id: str, shot_id: str, err: Exception):
        """Screenshot + page dump so a selector miss is diagnosable (and user-shareable)."""
        stamp = time.strftime("%Y%m%d-%H%M%S")
        safe_job = "".join(c for c in str(job_id) if c.isalnum() or c in "-_")[:60]
        base = os.path.join(self.log_dir, f"{safe_job}_{shot_id}_{stamp}")
        try:
            self._page.screenshot(path=base + ".png")
        except Exception:
            pass
        dump: dict = {"url": getattr(self._page, "url", "?"), "job": job_id,
                      "shot": shot_id, "error": str(err)[:2000]}
        try:
            dump["page_text"] = (self._page.inner_text("body") or "")[:3000]
        except Exception:
            pass
        for role in ("tab", "button"):
            try:
                els = self._page.get_by_role(role).all()[:40]
                dump[role + "s"] = [(e.inner_text() or "").strip()[:60] for e in els]
            except Exception:
                pass
        try:
            dump["contenteditables"] = self._page.locator("[contenteditable='true']").count()
            dump["settings_trigger_count"] = self._page.locator(".settings-trigger-button").count()
            dump["overlay_count"] = self._page.locator(".cdk-overlay-pane").count()
        except Exception:
            pass
        try:
            with open(base + ".json", "w", encoding="utf-8") as f:
                json.dump(dump, f, indent=2)
        except Exception:
            pass
        return base + ".png"

    # ---------- resilient Flow UI helpers ----------
    @staticmethod
    def _looks_like_network_error(err) -> bool:
        txt = str(err or "").lower()
        tokens = (
            "err_internet_disconnected", "err_network_changed", "err_name_not_resolved",
            "err_connection", "networkerror", "network error", "internet disconnected",
            "no internet", "connection reset", "connection refused", "connection closed",
            "net::err_", "dns_probe", "temporarily unavailable",
        )
        return any(t in txt for t in tokens)

    @staticmethod
    def _looks_like_browser_closed_error(err) -> bool:
        txt = str(err or "").lower()
        tokens = (
            "target page, context or browser has been closed",
            "targetclosederror",
            "browser has been closed",
            "page has been closed",
            "context has been closed",
            "connection closed while reading from the driver",
        )
        return any(t in txt for t in tokens)

    def network_issue_detected(self, err=None) -> bool:
        """Best-effort detection of a temporary loss of Internet/Flow transport."""
        if self._looks_like_network_error(err):
            return True
        try:
            body = (self._page.inner_text("body") or "").lower()
            if any(t in body for t in (
                "err_internet_disconnected", "no internet", "you are offline",
                "this site can’t be reached", "this site can't be reached",
                "network changed", "dns_probe",
            )):
                return True
        except Exception:
            pass
        try:
            online = self._page.evaluate("() => navigator.onLine")
            if online is False:
                return True
        except Exception:
            pass
        return False

    def wait_for_network_recovery(self, timeout_s: int = 300) -> bool:
        """Pause instead of failing a production when the Internet drops briefly.

        Once connectivity comes back, reload the current Flow page and invalidate
        the cached project state so the next operation re-verifies the composer.
        """
        deadline = time.time() + max(5, int(timeout_s))
        announced = False
        while time.time() < deadline:
            if not announced:
                print(f"[Flow] Network interruption detected; waiting up to {int(timeout_s)}s for recovery...")
                announced = True
            online = True
            try:
                online = bool(self._page.evaluate("() => navigator.onLine"))
            except Exception:
                pass
            if online:
                try:
                    self._page.reload(wait_until="domcontentloaded", timeout=15000)
                    self._page.wait_for_timeout(900)
                    if not self.network_issue_detected():
                        self._project_ready = None
                        try:
                            self.return_to_project(timeout_ms=7000)
                        except Exception:
                            pass
                        print("[Flow] Network restored; browser session recovered.")
                        return True
                except Exception:
                    pass
            try:
                self._page.wait_for_timeout(5000)
            except Exception:
                time.sleep(5)
        print("[Flow] Network did not recover before timeout.")
        return False

    def _click_text_action(self, label: str, timeout_ms: int = 2500) -> bool:
        """Click a visible action even when Flow does not expose button semantics.

        The 2026 Flow Agent confirmation rows (Approve/Always approve/Reject) and
        some editor controls are sometimes rendered as clickable containers rather
        than accessibility-role=button elements. Exact visible text is therefore a
        required fallback.
        """
        deadline = time.time() + max(0.2, timeout_ms / 1000.0)
        pat = re.compile(rf"^\s*{re.escape(label)}\s*$", re.I)
        while time.time() < deadline:
            # Accessible button path first.
            try:
                loc = self._page.get_by_role("button", name=pat).first
                if loc.is_visible(timeout=120):
                    loc.click(timeout=min(timeout_ms, 1500))
                    return True
            except Exception:
                pass
            # Flow Agent often uses a clickable div/list row with exact child text.
            try:
                loc = self._page.get_by_text(label, exact=True).first
                if loc.is_visible(timeout=120):
                    try:
                        loc.click(timeout=min(timeout_ms, 1500))
                    except Exception:
                        try:
                            parent = loc.locator("xpath=ancestor-or-self::*[self::button or @role='button' or @tabindex][1]")
                            parent.click(timeout=min(timeout_ms, 1500))
                        except Exception:
                            raise
                    return True
            except Exception:
                pass
            try:
                self._page.wait_for_timeout(150)
            except Exception:
                time.sleep(0.15)
        return False

    def _adopt_live_flow_page(self, project_url: str | None = None) -> bool:
        """Adopt another still-open Flow tab after the current editor tab closes.

        Flow's media editor can close/recreate its page target when leaving a detail
        view.  In CDP mode that should not be treated as the whole browser dying.
        Prefer the exact project URL, otherwise the newest open flow.google.com tab.
        """
        wanted = self.normalize_project_url(project_url)
        try:
            pages = list(getattr(self._ctx, "pages", []) or [])
        except Exception:
            pages = []
        fallback = None
        for pg in reversed(pages):
            try:
                if pg.is_closed():
                    continue
                url = str(pg.url or "")
                norm = self.normalize_project_url(url)
                if wanted and norm == wanted:
                    was_owned = ((pg is getattr(self, "_page", None) and getattr(self, "_owns_page", False))
                                 or (pg is getattr(self, "_guard_page", None)
                                     and getattr(self, "_owns_guard_page", False)))
                    self._page = pg
                    self._owns_page = was_owned
                    self._project_url = wanted
                    return True
                if "flow.google.com" in url and fallback is None:
                    fallback = pg
            except Exception:
                continue
        if getattr(self, "_isolated_worker", False) and self._ctx is not None and wanted:
            pg = None
            old = getattr(self, '_page', None)
            old_owned = getattr(self, '_owns_page', False)
            try:
                pg = self._ctx.new_page()
                self._page = pg
                self._owns_page = True
                pg.goto(wanted, wait_until="domcontentloaded", timeout=18000)
                pg.wait_for_timeout(500)
                self._project_url = wanted
                return True
            except Exception:
                if pg is not None:
                    try:pg.close()
                    except Exception:pass
                self._page = old
                self._owns_page = old_owned
                return False
        if fallback is not None:
            self._page = fallback
            self._owns_page = False
            cur = self.normalize_project_url(getattr(fallback, "url", ""))
            if cur:
                self._project_url = cur
            return True
        return False

    def _keep_shared_cdp_tabs(self) -> bool:
        """Keep normal Flow tabs in a user-owned CDP context for later resumes."""
        return bool(getattr(self, "_cdp", None) is not None
                    and not getattr(self, "_own_context", False)
                    and not getattr(self, "_isolated_worker", False))

    def _ensure_project_guard_page(self, project_url: str | None = None) -> bool:
        """Keep one stable project tab alive while media editor/download tabs may close.

        Flow occasionally destroys the active detail/editor page after a generated
        asset is opened or downloaded. If that was the only page, older recovery
        code escalated to a full browser restart. In a user-owned CDP context, reuse
        an existing canonical project tab before opening a guard, and retain any
        dedicated guard for later resume calls.
        """
        wanted = self.normalize_project_url(project_url) or self.current_project_url()
        if not wanted or not self._ctx:
            return False
        gp = None
        try:
            gp = self._guard_page
            if gp is not None and not gp.is_closed() and self.normalize_project_url(getattr(gp, 'url', '')) == wanted:
                return True
            if (gp is not None and gp is not self._page and not gp.is_closed()
                    and getattr(self, '_owns_guard_page', False)):
                # One app-owned guard is sufficient across image projects. Old
                # guards used to accumulate a fully loaded Flow page per frame.
                gp.goto(wanted, wait_until='domcontentloaded', timeout=18000)
                return True
        except Exception:
            if gp is not None and gp is not self._page and getattr(self, '_owns_guard_page', False):
                try: gp.close()
                except Exception: pass
            self._guard_page = None
        if self._keep_shared_cdp_tabs():
            try:
                candidates = list(self._ctx.pages or [])
            except Exception:
                candidates = []
            for candidate in reversed(candidates):
                try:
                    if candidate is self._page or candidate.is_closed():
                        continue
                    if self.normalize_project_url(getattr(candidate, "url", "")) == wanted:
                        self._guard_page = candidate
                        self._owns_guard_page = False
                        return True
                except Exception:
                    continue
        gp = None
        try:
            gp = self._ctx.new_page()
            gp.goto(wanted, wait_until='domcontentloaded', timeout=18000)
            gp.wait_for_timeout(500)
            self._guard_page = gp
            self._owns_guard_page = True  # this guard was created by AutoVideoAI
            return True
        except Exception:
            if gp is not None:
                try:gp.close()
                except Exception:pass
            self._guard_page = None
            return False

    def recover_project_page(self, project_url: str | None = None, timeout_ms: int = 12000) -> bool:
        """Recover from a closed Flow *page* without restarting the browser.

        This is the preferred v4.9 recovery path.  It first adopts any surviving
        project/guard tab; if none exists but the browser context is still alive,
        it opens a new project tab in that same context.  Only callers that cannot
        do this should escalate to a full browser relaunch.
        """
        wanted = self.normalize_project_url(project_url) or getattr(self, '_project_url', '') or ''
        if self._adopt_live_flow_page(wanted):
            try:
                if self._composer_visible(min(7000, timeout_ms)):
                    self._project_url = self.normalize_project_url(getattr(self._page, 'url', '')) or wanted
                    return True
            except Exception:
                pass
            # If the exact saved project tab is already alive but its composer is
            # not ready, do not open another tab on every Resume poll. Let the
            # caller surface/retry the same target instead of spawning more blank
            # tabs while the SPA/auth page is still loading.
            if self.normalize_project_url(getattr(self._page, "url", "")) == wanted:
                return False
        if not wanted or not self._ctx:
            return False
        pg = None
        old = getattr(self, '_page', None)
        old_owned = getattr(self, '_owns_page', False)
        try:
            pg = self._ctx.new_page()
            pg.goto(wanted, wait_until='domcontentloaded', timeout=max(7000, timeout_ms))
            pg.wait_for_timeout(600)
            old = self._page
            old_owned = getattr(self, "_owns_page", False)
            self._page = pg
            self._owns_page = not self._keep_shared_cdp_tabs()
            self.dismiss_onboarding(rounds=1)
            if self._composer_visible(min(7000, timeout_ms)):
                self._project_url = wanted
                self._project_ready = None
                # Keep a separate guard if possible. Do not close the old page here;
                # it may be the last surviving target while Flow finishes cleanup.
                self._ensure_project_guard_page(wanted)
                return True
            self._page = old
            self._owns_page = old_owned
            try:
                pg.close()
            except Exception:
                pass
        except Exception:
            if pg is not None:
                try:pg.close()
                except Exception:pass
            self._page = old
            self._owns_page = old_owned
            return False
        return False

    def return_to_project(self, timeout_ms: int = 10000) -> bool:
        """Leave Flow's media editor without touching its fragile Done control.

        In the Sep-2026 Flow UI an image detail/editor can replace or close the
        current page target when the app navigates back to the project.  Driving
        that same target with ``goto``/``Done`` therefore still produced
        TargetClosedError in v4.6.  v4.7 prefers a *fresh tab in the same browser
        context*, verifies the project composer there, then adopts that tab.
        """
        try:
            url = str(getattr(self._page, "url", "") or "")
        except Exception as e:
            if self._looks_like_browser_closed_error(e) and self._adopt_live_flow_page(getattr(self, "_project_url", "")):
                return self._composer_visible(5000)
            raise
        project_url = self.normalize_project_url(url) or getattr(self, "_project_url", "")
        if "/edit/" not in url:
            return False
        print("[Flow] Returning from image editor to project...")

        # First reuse an already-open project tab if Flow left one behind.
        current = self._page
        if project_url:
            try:
                pages = list(getattr(self._ctx, "pages", []) or [])
            except Exception:
                pages = []
            for pg in reversed(pages):
                if pg is current:
                    continue
                try:
                    if pg.is_closed():
                        continue
                    if self.normalize_project_url(getattr(pg, "url", "")) != project_url:
                        continue
                    self._page = pg
                    if self._composer_visible(min(5000, timeout_ms)):
                        self._project_ready = None
                        self._project_url = project_url
                        print("[Flow] Reused an already-open project tab.")
                        return True
                except Exception:
                    pass
                finally:
                    if self._page is pg and not self._composer_visible(200):
                        self._page = current

        # Preferred v4.7 path: open the canonical project route in a new target.
        # This avoids the editor target's self-destruction during SPA navigation.
        if project_url:
            fresh = None
            try:
                fresh = self._ctx.new_page()
                fresh.goto(project_url, wait_until="domcontentloaded",
                           timeout=min(18000, max(7000, timeout_ms)))
                fresh.wait_for_timeout(700)
                old = self._page
                self._page = fresh
                self.dismiss_onboarding(rounds=1)
                if self._composer_visible(min(7000, timeout_ms)):
                    self._project_ready = None
                    self._project_url = project_url
                    print("[Flow] Returned to project in a fresh tab.")
                    try:
                        if old is not fresh and not old.is_closed():
                            old.close()
                    except Exception:
                        pass
                    return True
                self._page = old
                try:
                    fresh.close()
                except Exception:
                    pass
            except Exception as e:
                if fresh is not None:
                    try:
                        if not fresh.is_closed():
                            fresh.close()
                    except Exception:
                        pass
                self._page = current
                if self._looks_like_browser_closed_error(e):
                    if self._adopt_live_flow_page(project_url):
                        try:
                            if self._composer_visible(5000):
                                self._project_ready = None
                                self._project_url = project_url
                                return True
                        except Exception:
                            pass
                    raise FlowBrowserClosedError(str(e))

        # Last-resort compatibility path. Prefer Back over Done because Done is the
        # control most often associated with Flow closing/replacing the editor page.
        clicked = False
        try:
            back = self._page.get_by_role("button", name=re.compile("Back", re.I)).first
            if back.is_visible(timeout=500):
                back.click()
                clicked = True
        except Exception:
            pass
        if not clicked:
            try:
                self._page.go_back(wait_until="domcontentloaded", timeout=8000)
            except Exception as e:
                if self._looks_like_browser_closed_error(e) and self._adopt_live_flow_page(project_url):
                    return self._composer_visible(5000)
                raise

        deadline = time.time() + max(1.0, timeout_ms / 1000.0)
        while time.time() < deadline:
            try:
                cur = str(getattr(self._page, "url", "") or "")
                if "/edit/" not in cur:
                    self._project_ready = None
                    self.current_project_url()
                    self._page.wait_for_timeout(350)
                    return True
                self._page.wait_for_timeout(200)
            except Exception as e:
                if self._looks_like_browser_closed_error(e) and self._adopt_live_flow_page(project_url):
                    if self._composer_visible(5000):
                        return True
                raise
        return False

    # ---------- project ops ----------
    def _composer_visible(self, timeout_ms: int = 1200) -> bool:
        # The public Flow landing page contains an Agent demo prompt, and Flow's
        # generated-media editor also contains prompt-like controls.  Neither is
        # the project composer.  A usable composer must be on the canonical
        # /project/<uuid> route, never /edit/<asset-id>.
        try:
            url = str(getattr(self._page, "url", "") or "")
            if "/project/" not in url or "/edit/" in url:
                return False
        except Exception:
            pass
        return self._try_resolve("prompt_box", timeout_ms=timeout_ms) is not None

    def enter_flow_app(self) -> bool:
        """Best-effort transition from a Flow marketing/landing page into the app."""
        loc = self._try_resolve("enter_flow", timeout_ms=1800)
        if not loc:
            return False
        try:
            loc.click()
            self._page.wait_for_load_state("domcontentloaded", timeout=15000)
        except Exception:
            pass
        return True

    @staticmethod
    def normalize_project_url(url: str | None) -> str:
        """Return a stable Flow project URL (without edit/query fragments)."""
        raw = str(url or "").strip()
        m = re.search(r"https://flow\.google\.com/project/([A-Za-z0-9-]+)", raw)
        return f"https://flow.google.com/project/{m.group(1)}" if m else ""

    def current_project_url(self) -> str:
        try:
            cur = self.normalize_project_url(getattr(self._page, "url", ""))
            if cur:
                self._project_url = cur
        except Exception:
            pass
        return getattr(self, "_project_url", None) or ""

    def delete_exact_project(self, project_url, expected_signatures=None, max_images=None):
        from engine.flow_project_delete import delete
        return delete(self, project_url, expected_signatures, max_images=max_images)


    def create_project(self, name: str):
        print("[Flow] Clicking New project...")
        self._resolve("new_project", timeout_ms=12000).click()
        self._page.wait_for_timeout(1200)
        # Current Flow uses a date/time title and does not reliably expose a
        # rename field. `name` remains our logical job key; the actual project
        # identity is the /project/<uuid> URL captured below.
        try:
            box = self._resolve("project_name_input", timeout_ms=1800)
            box.fill(name)
            self._page.keyboard.press("Enter")
        except FlowUIChanged:
            pass

    def open_project(self, name: str):
        self._click_text(name, timeout_ms=5000)

    def dismiss_onboarding(self, rounds: int = 3) -> int:
        """Click through first-visit welcome/Labs dialogs. Returns clicks made."""
        texts = self.ui.get("actions", {}).get("onboarding_dismiss", []) or []
        clicked = 0
        for _ in range(rounds):
            round_clicks = 0
            for t in texts:
                try:
                    loc = self._page.get_by_text(t, exact=False).first
                    loc.wait_for(timeout=1200)
                    loc.click()
                    round_clicks += 1
                    time.sleep(0.8)
                except Exception:
                    pass
            clicked += round_clicks
            if round_clicks == 0:
                break
        return clicked

    def create_isolated_image_project(self, name):
        """Create explicitly; never reuse a composer discovered by ensure_project."""
        previous = self.current_project_url()
        self._page.goto(self.ui.get('flow_url', 'https://flow.google.com/'),
                        wait_until='domcontentloaded', timeout=20000)
        self._project_ready = self._project_url = None
        self.dismiss_onboarding(rounds=1)
        self.create_project(name)
        if not self._composer_visible(20000):
            raise FlowUIChanged('New isolated image project has no usable composer')
        project = self.current_project_url()
        if not project or project == previous:
            raise FlowUIChanged('Flow did not create a distinct image project')
        self._project_ready = name
        return project

    def ensure_project(self, name: str, project_url: str | None = None):
        """Enter a usable Flow project and prefer an exact persisted project URL.

        Google Flow currently names projects with date/time labels, so the logical
        AutoVideoAI name cannot be used as a durable lookup key.  The /project/UUID
        URL is the canonical identity.  When supplied, it is opened directly; when
        a project is created or discovered, its URL is captured for persistence.
        """
        name = (name or "AutoVideoAI").strip() or "AutoVideoAI"
        wanted_url = self.normalize_project_url(project_url)

        # Never accept a media-detail /edit/ route as the project composer.  Sep-2026
        # Flow leaves prompt-like controls in that page, which previously fooled
        # _composer_visible() and sent the legacy standard path looking for a
        # nonexistent generate_button.  First leave the editor; if Flow refuses,
        # recover the canonical project page in the same browser context.
        try:
            raw_url = str(getattr(self._page, "url", "") or "")
        except Exception:
            raw_url = ""
        if "/edit/" in raw_url:
            canonical = self.normalize_project_url(raw_url) or wanted_url or getattr(self, "_project_url", "")
            left = False
            try:
                left = bool(self.return_to_project(timeout_ms=10000))
            except FlowBrowserClosedError:
                left = False
            except Exception:
                left = False
            try:
                still_edit = "/edit/" in str(getattr(self._page, "url", "") or "")
            except Exception:
                still_edit = True
            if (not left or still_edit) and canonical:
                if not self.recover_project_page(canonical, timeout_ms=12000):
                    raise FlowUIChanged(
                        f"Could not return from Flow media editor to project composer: {canonical}")
                self._project_ready = None
                self._project_url = canonical

        current_url = self.current_project_url()

        # Explicit/stored URL wins. This is what makes resume/browser recovery
        # deterministic and lets a new job intentionally reuse an older Flow project.
        if wanted_url and current_url != wanted_url:
            print(f"[Flow] Opening persisted project URL: {wanted_url}")
            try:
                self._page.goto(wanted_url, wait_until="domcontentloaded", timeout=20000)
                self._page.wait_for_timeout(900)
                self.dismiss_onboarding(rounds=1)
            except Exception as e:
                if self._looks_like_browser_closed_error(e):
                    raise FlowBrowserClosedError(str(e))
                raise FlowUIChanged(f"Could not open configured Flow project URL {wanted_url}: {e}")
            if not self._composer_visible(20000):
                raise FlowUIChanged(
                    f"Configured Flow project URL opened but composer was not found: {wanted_url}")
            self._project_ready = name
            self._project_url = wanted_url
            print("[Flow] Persisted Flow project is ready.")
            return

        if self._project_ready == name:
            if not hasattr(self, "_page"):
                return
            try:
                if "/edit/" in (getattr(self._page, "url", "") or ""):
                    self.return_to_project(timeout_ms=10000)
            except Exception:
                pass
            if self._composer_visible(1800):
                self.current_project_url()
                return
            self._project_ready = None

        print(f"[Flow] Current page: {getattr(getattr(self, '_page', None), 'url', '(test/mock)')}")
        print("[Flow] Looking for an open project/composer...")
        self.dismiss_onboarding()

        if self._composer_visible(1600):
            print("[Flow] Composer already open; reusing current project.")
            self._project_ready = name
            self.current_project_url()
            return

        if self.enter_flow_app():
            self.dismiss_onboarding(rounds=1)
            if self._composer_visible(6000):
                self._project_ready = name
                self.current_project_url()
                return

        # Legacy/older cohorts may still expose a user-defined project title.
        print(f"[Flow] Looking for existing project named {name!r}...")
        try:
            self.open_project(name)
            if self._composer_visible(12000):
                self._project_ready = name
                self.current_project_url()
                return
        except FlowUIChanged:
            pass

        print("[Flow] Existing named project not found; creating a fresh project.")
        self.create_project(name)
        print("[Flow] Waiting for the project composer...")
        if not self._composer_visible(20000):
            raise FlowUIChanged(
                f"Project opened/created but Flow prompt box was not found. url={self._page.url}")
        self._project_ready = name
        self.current_project_url()
        if getattr(self, "_project_url", None):
            print(f"[Flow] Project URL captured: {self._project_url}")
        print("[Flow] Project composer is ready.")

    def detect_editor_mode(self) -> str:
        """Return ``standard`` or ``agent`` for the canonical Flow project page.

        Media-detail pages under ``/edit/`` can expose controls that resemble both
        composer variants.  They are not generation composers, so normalize back
        to the project route before probing UI selectors.
        """
        try:
            url = str(getattr(self._page, "url", "") or "")
        except Exception:
            url = ""
        if "/edit/" in url:
            canonical = self.normalize_project_url(url) or getattr(self, "_project_url", "")
            try:
                if not self.return_to_project(timeout_ms=10000):
                    self.recover_project_page(canonical, timeout_ms=12000)
            except Exception:
                try:
                    self.recover_project_page(canonical, timeout_ms=12000)
                except Exception:
                    pass
            try:
                if "/edit/" in str(getattr(self._page, "url", "") or ""):
                    return "unknown"
            except Exception:
                return "unknown"

        if self._try_resolve("migrated_settings_trigger", timeout_ms=1200):
            return "standard"
        if self._try_resolve("agent_prompt_box", timeout_ms=1200):
            return "agent"
        return "unknown"

    @staticmethod
    def _agent_video_instruction(prompt: str, aspect: str = "9:16",
                                 model_label: str = "", duration: int = 8,
                                 count: int = 1) -> str:
        orientation = "portrait" if aspect == "9:16" else "landscape"
        model = model_label.strip() or "Veo 3.1 - Lite"
        return (
            f"Create exactly {max(1, int(count))} VIDEO clip{'s' if int(count) != 1 else ''}. "
            f"Do not create a still image. Use {orientation} orientation ({aspect}), "
            f"approximately {int(duration)} seconds, using {model}. Generate the media from "
            f"this scene description exactly as the creative brief: {prompt.strip()}"
        )[:4000]

    @staticmethod
    def _agent_image_instruction(prompt: str, aspect: str = "9:16", count: int = 1) -> str:
        orientation = "portrait" if aspect == "9:16" else "landscape"
        return (
            f"Create exactly {max(1, int(count))} STILL IMAGE{'S' if int(count) != 1 else ''}, not a video. "
            f"Use {orientation} orientation ({aspect}) and the no-charge Nano Banana 2 Lite image model when available. "
            f"Create this image exactly from the creative brief: {prompt.strip()}"
        )[:4000]

    @staticmethod
    def normalize_generation_prompt(value):
        import unicodedata
        return " ".join(unicodedata.normalize("NFC", str(value or "")).split())

    @staticmethod
    def same_generation_prompt(actual, expected):
        expected = FlowBrowser.normalize_generation_prompt(expected)
        return bool(expected and FlowBrowser.normalize_generation_prompt(actual) == expected)

    @staticmethod
    def image_creative_brief(submitted):
        """Extract only our complete, known Agent envelope; never fuzzy-match scenes.

        Flow's Reuse prompt can return the creative brief without the Agent
        routing instructions. Older request journals retain the full envelope.
        Parse that envelope strictly so old requests can correlate safely too.
        """
        text = FlowBrowser.normalize_generation_prompt(submitted)
        pattern = (r"(?:Request tracking label AVREQ_[a-f0-9]{24}; metadata only, never draw or write it in the image\. )?"
                   r"Create exactly 1 STILL IMAGE, not a video\. Use (?:portrait orientation \(9:16\)|landscape orientation \(16:9\)) "
                   r"and the no-charge Nano Banana 2 Lite image model when available\. "
                   r"Create this image exactly from the creative brief: (.+)")
        match = re.fullmatch(pattern, text)
        return match.group(1) if match else None

    @staticmethod
    def same_image_generation_prompt(actual, submitted):
        if FlowBrowser.same_generation_prompt(actual, submitted):
            return True
        brief = FlowBrowser.image_creative_brief(submitted)
        return bool(brief and FlowBrowser.same_generation_prompt(actual, brief))

    def read_asset_generation_prompt(self, signature):
        """Read one exact tile's visible Reuse prompt action without submitting.

        Some Flow cohorts do not expose this action. Return None and retain the
        request rather than guessing from title, resemblance or gallery order.
        """
        draft = None
        editor = None
        try:
            assets = self.media_assets()
            matches = [a for a in assets if media_signature_matches(a.get("sig"), signature)]
            if len(matches) != 1:
                return None
            editor = self._resolve("agent_prompt_box", timeout_ms=2000)
            draft = editor.inner_text(timeout=2000)
            media = self._page.locator("img,video").nth(int(matches[0]["dom_index"]))
            # Recheck identity immediately before clicking a tile-local action.
            src = media.evaluate("el => el.currentSrc || el.src || el.poster || ''", timeout=2000)
            if src != matches[0].get("src"):
                return None
            self._fill_editor_box("agent_prompt_box", "")
            media.hover(timeout=2000)
            clicked = media.evaluate(r"""el => {
                const visible = n => { const r=n.getBoundingClientRect(),s=getComputedStyle(n);
                    return r.width>0 && r.height>0 && s.display!=='none' && s.visibility!=='hidden'; };
                let node=el;
                for(let depth=0;node && depth<8;depth++,node=node.parentElement){
                    if(['BODY','HTML','MAIN'].includes(node.tagName)) break;
                    if(Array.from(node.querySelectorAll('img,video')).some(n=>n!==el && visible(n) &&
                        n.getBoundingClientRect().width>=80 && n.getBoundingClientRect().height>=60)) break;
                    const controls=Array.from(node.querySelectorAll('button,[role="button"]')).filter(visible)
                        .filter(n=>/reuse prompt/i.test([n.getAttribute('aria-label')||'',n.getAttribute('title')||'',
                            n.getAttribute('data-tooltip')||'',n.innerText||''].join(' ')));
                    if(controls.length===1){controls[0].click();return true;}
                    if(controls.length>1) return false;
                }
                return false;
            }""", timeout=2000)
            if not clicked:
                # Some Flow layouts place Reuse prompt in the tile's menu.
                # Open only this already-verified tile, never a global menu.
                if not self._open_asset_tile_download_menu(media):
                    return None
                reuse = self._page.get_by_role('menuitem', name=re.compile(r'^Reuse prompt$', re.I))
                visible = [reuse.nth(i) for i in range(min(reuse.count(), 8))
                           if reuse.nth(i).is_visible(timeout=100)]
                if len(visible) != 1:
                    self._page.keyboard.press('Escape')
                    return None
                visible[0].click(timeout=2000)
            # The composer was cleared first: stale text cannot count as proof.
            for _ in range(8):
                text = editor.inner_text(timeout=1500)
                if text:
                    return text
                self._page.wait_for_timeout(250)
            return None
        except Exception as exc:
            if self._looks_like_browser_closed_error(exc):
                raise FlowBrowserClosedError(str(exc))
            return None
        finally:
            if draft is not None:
                try:
                    self._fill_editor_box("agent_prompt_box", draft)
                except Exception as exc:
                    # Stop on failed draft restoration; a changed composer must
                    # not leak into a subsequent generation step.
                    raise FlowUIChanged("Could not restore Flow draft after read-only prompt correlation; request preserved") from exc

    def _agent_reference_names(self):
        """Names exposed on attachment chips beside the live composer, not gallery rows."""
        return self._page.evaluate(r"""() => {
            const visible = n => {const r=n.getBoundingClientRect();return r.width>0&&r.height>0;};
            const boxes=Array.from(document.querySelectorAll('[contenteditable="true"]')).filter(visible);
            const names=[];
            for(const box of boxes){
                let node=box.parentElement;
                for(let depth=0;node&&depth<6&&node!==document.body;depth++,node=node.parentElement){
                    for(const el of node.querySelectorAll('img,[style*="background-image"]')){
                        if(!visible(el)||el.closest('[role="dialog"],[role="menu"],[role="listbox"]'))continue;
                        {
                            let chip=el.parentElement;
                            for(let hop=0;chip&&hop<4;hop++,chip=chip.parentElement){
                                if(chip.querySelector('[contenteditable="true"],input[placeholder*="Search" i]'))break;
                                const remove=Array.from(chip.querySelectorAll('button,[role="button"]')).some(b=>
                                    /^(?:close|cancel|remove)$/i.test((b.innerText||'').trim()) ||
                                    /^(?:close|cancel|remove)$/i.test(b.getAttribute('aria-label')||'') ||
                                    /(?:remove|delete|close) (?:image|photo|media|reference|attachment)/i.test(b.getAttribute('aria-label')||''));
                                if(remove){
                                    for(const name of ['alt','title','aria-label']){
                                        const value=el.getAttribute(name)||chip.getAttribute(name)||'';
                                        if(value.includes('AV_'))names.push(value);
                                    }
                                    const src=el.currentSrc||el.src||getComputedStyle(el).backgroundImage;
                                    if(src&&src!=='none')names.push('@chip:'+src);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            return names;
        }""")

    def _media_picker_open(self):
        fields = self._page.locator("input[placeholder*='Search assets' i], input[aria-label*='Search assets' i]")
        return any(fields.nth(i).is_visible(timeout=100) for i in range(fields.count()))

    def _dismiss_media_picker(self):
        # The Angular add/download menu can leave a transparent backdrop after
        # its search field disappears. Escape the real menu; never remove DOM
        # overlays or force a click through a blocking dialog.
        for _ in range(3):
            if not (self._media_picker_open() or self._transient_menu_overlay_open()):
                return
            self._page.keyboard.press('Escape')
            self._page.wait_for_timeout(200)
        if self._media_picker_open() or self._transient_menu_overlay_open():
            raise FlowUIChanged("Flow media picker still covers the composer; no prompt submitted")

    def _transient_menu_overlay_open(self):
        try:
            backdrops = self._page.locator('.cdk-overlay-backdrop.cdk-overlay-transparent-backdrop.cdk-overlay-backdrop-showing')
            return any(backdrops.nth(i).is_visible(timeout=100) for i in range(backdrops.count()))
        except Exception:
            return False

    def _exact_reference_rows(self, basename):
        # Some picker cohorts expose the filename only as image alt/title text.
        # Exact hash-bearing names remain mandatory; no generic thumbnail click.
        scope = self._page
        # Prefer the active picker over duplicate titles in the project gallery.
        try:
            pickers = self._page.locator('[data-av-reference-picker="true"]')
            for i in range(pickers.count()):
                if pickers.nth(i).is_visible(timeout=100):
                    scope = pickers.nth(i)
                    break
        except AttributeError:
            pass  # Legacy adapter without scoped picker locators.
        text = scope.get_by_text(basename, exact=True)
        if text.count():
            return text
        value = json.dumps(basename)
        return scope.locator(f'img[alt={value}],img[title={value}],[data-filename={value}],[aria-label={value}]')

    def _click_exact_reference_row(self, basename, deadline):
        """A transient click timeout consumes this poll, not the whole upload."""
        from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
        rows = self._exact_reference_rows(basename)
        for i in range(rows.count()):
            remaining = int((deadline - time.monotonic()) * 1000)
            if remaining <= 0:
                return False
            row = rows.nth(i)
            try:
                if not row.is_visible(timeout=min(100, remaining)):
                    continue
                # An earlier timed-out click can have selected the row already.
                if row.get_attribute('aria-selected', timeout=min(100, remaining)) == 'true':
                    return True
                row.click(timeout=min(1500, remaining))
                return True
            except PlaywrightTimeoutError:
                return False  # Recheck composer chips and refresh locators next poll.
        return False

    def _finish_agent_media_picker(self, basename: str = "", timeout_ms: int = 45000) -> bool:
        deadline = time.monotonic() + max(1.0, timeout_ms / 1000)
        selected = False
        # Flow retains a previous exact-name search, which can hide a new upload.
        self._clear_media_picker_search()
        self._picker_uploads()
        while time.monotonic() < deadline:
            names = self._agent_reference_names()
            fresh_chips = {n for n in names if n.startswith('@chip:')} - getattr(self, '_reference_baseline', set())
            if basename and (any(basename in name for name in names) or len(fresh_chips) == 1):
                self._dismiss_media_picker()
                return True
            if basename and not selected:
                selected = self._click_exact_reference_row(basename, deadline)
            remaining = int((deadline - time.monotonic()) * 1000)
            if remaining <= 0:
                break
            if selected:
                self._click_text_action('Add to prompt', timeout_ms=min(300, remaining))
            self._page.wait_for_timeout(min(250, max(1, int((deadline-time.monotonic())*1000))))
        # Absence of Add to prompt is not evidence of an attachment.
        return False

    def _open_agent_add_menu(self):
        self._dismiss_media_picker()
        adds = self._page.locator("button:has(mat-icon:text-is('add'))")
        btn = None
        try:
            for i in range(adds.count() - 1, -1, -1):
                cand = adds.nth(i)
                if cand.is_visible(timeout=120):
                    btn = cand
                    break
        except Exception:
            btn = None
        if btn is None:
            btn = self._resolve("agent_add_media_button", timeout_ms=2500)
        btn.click(timeout=2500)
        self._page.wait_for_timeout(250)

    @staticmethod
    def _media_upload_alias(path: str) -> str:
        """Stable Flow-library name derived from file content.

        Using only ``shot_001_open.jpg`` is unsafe across reused projects because a
        later job can have a different shot 001.  The short content hash makes the
        uploaded project-media name collision resistant and lets future runs reuse
        the exact same file already stored in the Flow project.
        """
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                h.update(chunk)
        base = re.sub(r"[^A-Za-z0-9._-]+", "_", os.path.basename(path))
        # GUI MIME hints and old reference names may have the wrong extension.
        # Keep approved bytes unchanged, but give Flow their real file format.
        try:
            from PIL import Image
            with Image.open(path) as image:
                suffix = {'JPEG':'.jpg', 'PNG':'.png', 'WEBP':'.webp'}.get(image.format)
                if suffix and os.path.splitext(base)[1].lower() not in (
                        ('.jpg', '.jpeg') if suffix == '.jpg' else (suffix,)):
                    base = os.path.splitext(base)[0]+suffix
        except (OSError, ValueError):
            pass
        return f"AV_{h.hexdigest()[:12]}_{base}"

    def _clear_media_picker_search(self):
        try:
            fields = self._page.locator("input[placeholder*='Search' i], input[aria-label*='Search' i]")
            for i in range(fields.count()):
                if fields.nth(i).is_visible(timeout=100):
                    fields.nth(i).fill("")
        except Exception:
            pass

    def _picker_uploads(self):
        """Select Uploads inside the visible media picker, never the main sidebar."""
        try:
            scope = self._page.evaluate(r"""() => {
                for (const el of document.querySelectorAll('[data-av-reference-picker]')) el.removeAttribute('data-av-reference-picker');
                const input=Array.from(document.querySelectorAll('input[placeholder*="Search assets" i],input[aria-label*="Search assets" i]')).find(e=>e.getClientRects().length);
                for(let node=input?.parentElement;node&&node!==document.body;node=node.parentElement){
                    const names=Array.from(node.querySelectorAll('button,a,[role="button"],span,div')).filter(e=>e.getClientRects().length).map(e=>(e.innerText||'').trim());
                    if(names.includes('Uploads') && names.includes('Upload media')){node.setAttribute('data-av-reference-picker','true');return true;}
                }
                return false;
            }""")
        except Exception:
            return False
        if not scope:
            return self._click_text_action('Uploads', timeout_ms=700)
        picker=self._page.locator('[data-av-reference-picker="true"]')
        tabs=picker.get_by_text('Uploads',exact=True)
        for i in range(tabs.count()):
            if tabs.nth(i).is_visible(timeout=100):
                tabs.nth(i).click(timeout=1500)
                self._page.wait_for_timeout(200)
                return True
        return False

    def _try_attach_existing_project_media(self, display_name: str, timeout_ms: int = 3500) -> bool:
        """Best-effort attach of an already-uploaded Flow project asset by exact name.

        This never chooses a fuzzy/semantic match. If the media picker or exact
        fingerprinted filename is not available, the caller simply uploads the file.
        """
        try:
            self._open_agent_add_menu()
            self._clear_media_picker_search()
            # Uploaded references live in Uploads in the current Flow picker.
            self._picker_uploads()
        except Exception:
            return False
        deadline = time.time() + max(0.8, timeout_ms / 1000.0)
        search_deadline = time.time() + max(0.4, timeout_ms / 2000.0)
        try:
            while time.time() < deadline:
                # Some Flow cohorts provide a Search assets box. Narrowing first
                # avoids selecting an old similarly named media item.
                try:
                    searches = self._page.locator("input[placeholder*='Search' i], input[aria-label*='Search' i]")
                    if searches.count():
                        q = searches.last
                        if q.is_visible(timeout=80):
                            # Some Flow cohorts index prompt text rather than
                            # uploaded filenames. Try the exact alias first,
                            # then clear search and inspect the Uploads rows.
                            q.fill(display_name if time.time() < search_deadline else '')
                            self._page.wait_for_timeout(180)
                except Exception:
                    pass
                try:
                    if self._click_exact_reference_row(display_name, time.monotonic() + max(0, deadline-time.time())):
                        self._page.wait_for_timeout(180)
                        if self._finish_agent_media_picker(display_name, timeout_ms=2500):
                            print(f"[Flow] Reused existing project media: {display_name}")
                            return True
                except Exception:
                    pass
                self._page.wait_for_timeout(180)
        except Exception:
            pass
        # Flow retains this search between picker openings, including uploads.
        self._clear_media_picker_search()
        # Close any picker/menu we opened; upload path will reopen what it needs.
        try:
            self._page.keyboard.press("Escape")
            self._page.wait_for_timeout(150)
        except Exception:
            pass
        return False

    def _aliased_upload_path(self, path: str, alias: str) -> str:
        """Create/reuse a local upload alias so Flow stores a deterministic name."""
        root = os.path.abspath(os.path.join("data", "flow_media_uploads"))
        os.makedirs(root, exist_ok=True)
        dst = os.path.join(root, alias)
        try:
            from engine.production import digest
            if not os.path.exists(dst) or digest(dst) != digest(path):
                shutil.copy2(path, dst)
            return dst
        except Exception:
            return path

    def attach_agent_media(self, paths: list[str], reuse_existing: bool = True) -> int:
        """Attach references to the live Flow Agent composer.

        v4.6 first looks for the exact content-fingerprinted asset already present
        in the Flow project. Only a byte-identical media alias can be reused; if it
        is absent, the file is uploaded once under that stable alias. This avoids
        repeatedly uploading/recreating the same first/last frames on a reused
        project while preventing generic ``shot_001.jpg`` collisions.
        """
        paths = [os.path.abspath(p) for p in (paths or []) if p and os.path.exists(p)]
        from engine.flow_upload_media import prepare_reference
        paths=[prepare_reference(p) for p in paths]
        from engine.flow_reference_policy import reference_episode_id
        episode = reference_episode_id()
        if getattr(self, '_reference_recovery_episode', episode) != episode:
            self._unavailable_reference_aliases = set()
        self._reference_recovery_episode = episode
        failures = getattr(self, '_unavailable_reference_aliases', set())
        project_url = self.normalize_project_url(self.current_project_url())
        if any((project_url, self._media_upload_alias(p)) in failures for p in paths):
            raise FlowReferenceUnavailable('A required reference exhausted exact picker/upload recovery in this browser session; no prompt submitted. Reopen the saved project after resolving the upload; approved photos remain unchanged.')
        if not paths:
            return 0
        attached = 0
        errors = []
        for path in paths:
            basename = os.path.basename(path)
            try:
                alias = self._media_upload_alias(path)
                composer_names = self._agent_reference_names()
                self._reference_baseline = {n for n in composer_names if n.startswith('@chip:')}
                from engine.flow_reference_policy import upload_record, reference_upload_attempt
                project_url = self.normalize_project_url(self.current_project_url())
                if any(alias in name for name in composer_names):
                    self._dismiss_media_picker()
                    upload_record(project_url, alias, record=True)
                    attached += 1
                    print(f"[Flow] Exact reference is already attached to this composer: {basename}")
                    continue
                known_upload = upload_record(project_url, alias)
                if reuse_existing and self._try_attach_existing_project_media(alias):
                    upload_record(project_url, alias, record=True)
                    attached += 1
                    continue
                if reuse_existing and (known_upload or reference_upload_attempt(project_url, alias)):
                    from engine.flow_reference_policy import reserve_reference_reattach
                    if not reserve_reference_reattach(project_url, alias):
                        if not hasattr(self, '_unavailable_reference_aliases'):
                            self._unavailable_reference_aliases = set()
                        self._unavailable_reference_aliases.add((project_url, alias))
                        raise FlowReferenceUnavailable("Exact uploaded reference remains unavailable after one local-file reattachment; no generation submitted. Saved references and request journals are preserved.")
                    print(f"[Flow] Picker reuse unavailable; reattaching the same verified local reference once: {basename}")
                self._clear_media_picker_search()
                upload_path = self._aliased_upload_path(path, alias)
                upload_name = os.path.basename(upload_path)

                self._dismiss_media_picker()
                self._open_agent_add_menu()
                self._clear_media_picker_search()
                with self._page.expect_file_chooser(timeout=5000) as fc:
                    self._resolve("agent_upload_option", timeout_ms=4000).click(timeout=4000)
                reference_upload_attempt(project_url, alias, record=True)
                fc.value.set_files(upload_path)
                self._page.wait_for_timeout(500)
                if not self._finish_agent_media_picker(upload_name):
                    raise FlowUIChanged(
                        f"Reference file was sent, but no verified composer attachment appeared within 45s: {upload_name}. "
                        "The photo exists locally; Flow upload/attachment needs recovery. No generation submitted.")
                upload_record(project_url, alias, record=True)
                attached += 1
                print(f"[Flow] Added reference to prompt: {basename} ({alias[:15]}…)")
            except Exception as e:
                errors.append(f"{basename}: {e}")
                # Preserve the actual upload error and file properties locally;
                # no authenticated transport URLs or whole-page text are logged.
                try:
                    from engine.support_report import redact
                    from PIL import Image
                    upload_info={'file':basename,'alias':alias,'bytes':os.path.getsize(path),
                                 'error_type':type(e).__name__,'error':redact(str(e)),'project_url':project_url}
                    with Image.open(path) as uploaded_image:
                        upload_info.update(format=uploaded_image.format,mode=uploaded_image.mode,size=uploaded_image.size)
                    folder=Path('logs/flow');folder.mkdir(parents=True,exist_ok=True)
                    diagnostic=folder/('reference-upload-'+hashlib.sha256((project_url+alias).encode()).hexdigest()[:16]+'.json')
                    diagnostic.write_text(json.dumps(upload_info,indent=2),encoding='utf-8')
                    errors[-1]+=f' [diagnostic: {diagnostic}]'
                except Exception:
                    pass
                # Close a stuck picker before trying the next reference.
                try:
                    self._page.keyboard.press("Escape")
                except Exception:
                    pass
        if attached == 0:
            raise FlowReferenceUnavailable("Could not attach Agent reference media: " + "; ".join(errors)[-700:])
        if attached < len(paths):
            raise FlowReferenceUnavailable(f"Attached {attached}/{len(paths)} required references; no generation submitted: " + "; ".join(errors)[-1600:])
        return attached

    @staticmethod
    def _classify_media_kind(tag, src="", alt="", hints="", has_play=False,
                            has_resolution=False, has_video_node=False,
                            queue_context: bool | None = None) -> str:
        """Classify a Flow tile from tile-local status and video evidence.

        Flow's chat can retain a high-demand queue message after the generated
        video appears in the project gallery. Callers that can scope DOM context
        should pass ``queue_context`` from the tile's own card; broad page/chat
        text must not demote an unrelated playable tile.
        """
        text = " ".join(str(value or "") for value in (src, alt, hints)).lower()
        video_url = bool(re.search(r"\.(?:mp4|webm|mov|m4v)(?:$|[?#])", str(src or ""), re.I))
        tag_is_video = str(tag or "").lower() == "video"
        # Direct callers without scoped DOM evidence retain the conservative
        # behavior; media_assets() supplies queue_context based on nearby card
        # ancestors and uses narrower text for video-label classification.
        tile_is_queued = (_is_flow_queue_status(text) if queue_context is None
                          else bool(queue_context))
        if tile_is_queued and not tag_is_video:
            return "pending"
        # A surrounding gallery heading/Agent message often contains the bare
        # word "video". It is not tile identity: 15 ordinary 16:9 thumbnails
        # were previously promoted by that text during the user's recovery scan.
        # Require media-specific evidence; a play icon alone can also belong to
        # the queued chat thumbnail. Require a play control plus resolution badge,
        # a playable URL/node, or an explicit tile label for a generated clip.
        video_hint = bool(re.search(
            r"video\s+(?:preview|clip|asset)|generated video|play video|"
            r"smart[_\s-]?display|(?:^|\W)movie(?:\W|$)", text, re.I))
        if (tag_is_video or has_video_node or video_url or video_hint
                or (has_play and has_resolution)):
            return "video"
        return "image"

    def media_assets(self) -> list[dict]:
        """Return fingerprints for large visible image/video assets in DOM order.

        Flow often exposes a generated video as an ``img`` poster card rather
        than a literal ``<video>`` element. The Material ``play_arrow`` icon is
        captured as a diagnostic signal, but is not sufficient by itself: queue
        thumbnails also have play buttons. Prefer a video node/URL, resolution
        badge, or explicit video label. A plain fresh image never counts as a
        completed video.
        """
        try:
            raw_assets = self._page.evaluate(r"""() => Array.from(document.querySelectorAll('img,video')).map((el, i) => {
                const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
                const label = (el.getAttribute('alt') || el.getAttribute('aria-label') || '');
                const galleryTile = /tile displaying/i.test(label);
                if (r.width < (galleryTile ? 80 : 140) || r.height < (galleryTile ? 60 : 90) || s.visibility === 'hidden' || s.display === 'none') return null;
                const src = el.currentSrc || el.src || el.poster || '';
                const alt = el.getAttribute('alt') || el.getAttribute('aria-label') || '';

                // Walk ancestors because Flow places play icons and resolution
                // badges next to posters. Keep broad diagnostics, but scope queue
                // status and text labels to the tile's nearby card ancestors.
                const queuePattern = /(?:(?:video|image|generation|request).{0,100}(?:scheduled|queued|waiting\s+(?:in\s+)?the\s+queue)|(?:scheduled|queued).{0,100}(?:waiting\s+(?:in\s+)?the\s+queue|high\s+demand)|waiting\s+(?:in\s+)?the\s+queue|queued\s+due\s+to\s+high\s+demand|scheduled\s+and\s+waiting\s+in\s+queue|your\s+video\s+has\s+been\s+scheduled)/i;
                let node = el, hints = '', tileHints = '', depth = 0, queueContext = false;
                let hasPlay = false, hasVideoNode = el.tagName.toLowerCase() === 'video';
                let hasResolution = false;
                while (node && depth < 6) {
                    try {
                        if (['BODY', 'HTML', 'MAIN'].includes(node.tagName)) break;
                        // A gallery/row can contain another tile's video badge or
                        // an old queued Agent preview. Never borrow that evidence.
                        const largeMedia = node.querySelectorAll ?
                            Array.from(node.querySelectorAll('img,video')).filter(n => {
                                const box = n.getBoundingClientRect(), style = getComputedStyle(n);
                                const labelled = /tile displaying/i.test(n.getAttribute('alt') || n.getAttribute('aria-label') || '');
                                return box.width >= (labelled ? 80 : 140) && box.height >= (labelled ? 60 : 90) &&
                                       style.visibility !== 'hidden' && style.display !== 'none';
                            }) : [];
                        if (largeMedia.some(n => n !== el)) break;
                        const aria = node.getAttribute && (node.getAttribute('aria-label') || '');
                        const title = node.getAttribute && (node.getAttribute('title') || '');
                        const txt = (node.innerText || '').trim();
                        const local = (aria + ' ' + title + ' ' + (txt.length < 900 ? txt : '')).trim();
                        hints += ' ' + local;
                        if (depth <= 2) tileHints += ' ' + local;
                        if (depth <= 4 && queuePattern.test(local)) queueContext = true;
                        if (/(?:^|[^a-z0-9])(?:play(?:[_\s-]?(?:arrow|circle|circle_filled))?|smart[_\s-]?display)(?:$|[^a-z0-9])|play video|video preview/i.test(local)) hasPlay = true;
                        if (/\b(?:360|480|720|1080|1440|2160)p\b/i.test(local)) hasResolution = true;
                        if (node.querySelector) {
                            if (node.querySelector('video')) hasVideoNode = true;
                            const labelled = Array.from(node.querySelectorAll('[aria-label],[title],[data-testid],[data-tooltip],[data-icon],mat-icon'))
                                .slice(0, 24);
                            for (const n of labelled) {
                                const h = [n.getAttribute('aria-label') || '', n.getAttribute('title') || '',
                                           n.getAttribute('data-testid') || '', n.getAttribute('data-tooltip') || '',
                                           n.getAttribute('data-icon') || '', n.innerText || ''].join(' ');
                                hints += ' ' + h;
                                if (depth <= 2) tileHints += ' ' + h;
                                if (/(?:^|[^a-z0-9])(?:play(?:[_\s-]?(?:arrow|circle|circle_filled))?|smart[_\s-]?display)(?:$|[^a-z0-9])|play video|video preview/i.test(h)) hasPlay = true;
                                if (/\b(?:360|480|720|1080|1440|2160)p\b/i.test(h)) hasResolution = true;
                            }
                        }
                    } catch (_) {}
                    node = node.parentElement; depth++;
                }
                return {src, alt, tag: el.tagName, dom_index: i, width: Math.round(r.width),
                        height: Math.round(r.height), x: r.x, y: r.y, hint: hints.slice(0,600),
                        tile_hint: tileHints.slice(0,600), queue_context: queueContext,
                        hasPlay, hasResolution, hasVideoNode};
            }).filter(Boolean)""") or []
            assets = []
            for asset in raw_assets:
                if not isinstance(asset, dict):
                    continue
                kind = self._classify_media_kind(
                    asset.get("tag"), asset.get("src"), asset.get("alt"),
                    asset.get("tile_hint", asset.get("hint")),
                    asset.get("hasPlay"), asset.get("hasResolution"), asset.get("hasVideoNode"),
                    asset.get("queue_context"))
                asset["kind"] = kind
                asset["sig"] = "|".join(str(value or "") for value in (
                    str(asset.get("tag") or "IMG").upper(), asset.get("src"), asset.get("alt"), kind,
                    asset.get("width"), asset.get("height")))
                assets.append(asset)
            return assets
        except Exception as e:
            if self._looks_like_browser_closed_error(e):
                raise FlowBrowserClosedError(str(e))
            return []

    def media_asset_signatures(self) -> set[str]:
        return {str(x.get("sig")) for x in self.media_assets() if x.get("sig")}

    def media_asset_count(self) -> int:
        """Backward-compatible count used by older tests/callers."""
        return len(self.media_assets())

    def detect_service_busy(self) -> str | None:
        """Return the matching Flow Agent capacity message, if currently visible.

        Agent history remains in the DOM, so inspect the tail of the visible page text
        rather than the beginning. This reduces false positives from older messages.
        """
        try:
            body = (self._page.inner_text("body") or "")[-6000:].lower()
        except Exception as e:
            if self._looks_like_browser_closed_error(e):
                raise FlowBrowserClosedError(str(e))
            return None
        newest_busy = (-1, None)
        for t in self.ui.get("actions", {}).get("service_busy_texts", []):
            idx = body.rfind(str(t).lower())
            if idx > newest_busy[0]:
                newest_busy = (idx, str(t))
        if newest_busy[0] < 0:
            return None

        # A previous high-demand card can remain in the conversation history even
        # after Try again has successfully started a new request. If a newer
        # progress marker appears after the capacity message, treat the request as
        # running rather than repeatedly clicking an old Retry card.
        progress_markers = (
            "generation in progress", "creating video", "creating image",
            "generating", "pending", "waiting in the queue",
            "scheduled and is waiting", "scheduled and waiting", "queued due to high demand", "in the queue due to high demand",
        )
        newest_progress = max((body.rfind(x) for x in progress_markers), default=-1)
        if newest_progress > newest_busy[0]:
            return None
        return newest_busy[1]

    def recover_service_busy(self, max_wait_s: int | None = None,
                             max_retries: int | None = None) -> bool:
        """Retry a Flow Agent request that was rejected only because of high demand.

        Uses Flow's existing ``Try again``/``Retry`` control, so the original prompt
        is not resubmitted and a normal frame retry is not consumed. Backoff is
        bounded; persistent capacity pressure returns False so the job can pause.
        """
        timeouts = self.ui.get("timeouts", {})
        actions = self.ui.get("actions", {})
        max_wait_s = max(5, int(max_wait_s if max_wait_s is not None
                                else timeouts.get("service_busy_wait", 900)))
        max_retries = max(1, int(max_retries if max_retries is not None
                                 else timeouts.get("service_busy_retries", 8)))
        delays = actions.get("service_busy_retry_delays", [0, 30, 60, 90, 120, 180]) or [0]
        retry_labels = actions.get("service_retry_buttons", ["Try again", "Retry"]) or ["Try again"]
        deadline = time.time() + max_wait_s

        for attempt in range(max_retries):
            # A hard account/usage limit can share the words "try again later"
            # with temporary capacity cards. Stop immediately instead of spending
            # 10-15 minutes clicking Retry against a condition that cannot clear.
            self.detect_failure()
            if not self.detect_service_busy():
                return True
            delay = float(delays[min(attempt, len(delays) - 1)] or 0)
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            delay = min(delay, max(0.0, remaining))
            if delay > 0:
                retry_at = time.strftime("%H:%M:%S", time.localtime(time.time() + delay))
                print(f"[Flow] Agent is at capacity; waiting {int(delay)}s before retry "
                      f"({attempt + 1}/{max_retries}); next attempt at {retry_at}...")
                try:
                    self._page.wait_for_timeout(int(delay * 1000))
                except Exception as e:
                    if self._looks_like_browser_closed_error(e):
                        raise FlowBrowserClosedError(str(e))
                    time.sleep(delay)
            else:
                print(f"[Flow] Agent is at capacity; retrying now ({attempt + 1}/{max_retries})...")

            self.detect_failure()
            clicked = False
            for label in retry_labels:
                if self._click_text_action(str(label), timeout_ms=1800):
                    print(f"[Flow] Capacity recovery: clicked {label!r}.")
                    clicked = True
                    break
            if not clicked:
                print("[Flow] Capacity retry control is not visible yet; continuing to wait.")

            try:
                self._page.wait_for_timeout(1500)
            except Exception as e:
                if self._looks_like_browser_closed_error(e):
                    raise FlowBrowserClosedError(str(e))
            if not self.detect_service_busy():
                return True

        return not bool(self.detect_service_busy())

    def wait_for_agent_generation(self, before_assets=0, timeout_s: int | None = None,
                                  service_busy_wait_s: int | None = None,
                                  service_busy_retries: int | None = None,
                                  required_kind: str | None = None,
                                  video_ready_grace_s: int | None = None,
                                  approval: str = "once",
                                  max_generation_credits: int | None = None,
                                  image_request: dict | None = None,
                                  transactional_images: bool = False) -> bool:
        """Wait for the current Agent request to produce a genuinely new asset.

        v7.0.90: ``transactional_images`` is used only by the isolated image journal. Several fresh
        images then mean "classify them now": the journal downloads each candidate and excludes uploaded
        references by checksum. The wait returns True instead of failing, so no output is guessed.

        Video requests require explicit video evidence. Flow can show an
        intermediate image/poster before the playable/downloadable video is ready;
        an untyped image is never promoted to a completed video after a timer. We
        keep polling within the normal generation timeout until an explicit video
        card remains stable briefly, then the provider validates the downloaded
        container and duration.
        """
        timeout_s = timeout_s or self.ui["timeouts"]["generation"]
        deadline = time.time() + timeout_s
        if isinstance(before_assets, (set, list, tuple)):
            baseline = {str(x) for x in before_assets}
        else:
            baseline = None
            try:
                before_count = int(before_assets or 0)
            except Exception:
                before_count = 0
        self._generation_baseline_signatures = set(baseline or ())
        self.last_generated_asset_signature = None
        self.last_agent_queue_observed = False
        self.last_agent_failure = ''
        self.last_agent_queue_elapsed_s = 0.0
        wanted = str(required_kind or "").strip().lower() or None
        saw_busy = False
        queue_wait_started_at = None
        last_queue_heartbeat = 0.0
        untyped_ready_at = None
        video_candidate_sig = None
        video_candidate_since = None
        announced_wait = False
        grace = max(5, int(video_ready_grace_s if video_ready_grace_s is not None else 20))
        untyped_warning_logged = False
        last_approval_probe = 0.0
        generic_failure_since = None
        ambiguous_images_since = None
        ambiguous_images_key = None
        approval_resolved = bool((getattr(self, "last_agent_confirmation", {}) or {}).get("clicked"))

        while time.time() < deadline:
            # Quota/usage-limit messages are more specific than the generic
            # "please try again later" capacity marker, so classify them first.
            fail = self.detect_failure()
            if fail:
                generic = str(fail).lower() == "something went wrong"
                if not generic or (generic_failure_since is not None and time.time() - generic_failure_since >= 20):
                    self.last_agent_failure = str(fail)
                    print(f'[Flow] Current request failure marker detected: {fail!r}; preserving its journal')
                    return False
                if generic_failure_since is None:
                    generic_failure_since = time.time()
                    print("[Flow] Generic UI error observed; scanning the saved request for 20 seconds before concluding failure. No replacement generation.")
            else:
                generic_failure_since = None

            capacity = self.detect_service_busy()
            if capacity:
                ok = self.recover_service_busy(max_wait_s=service_busy_wait_s,
                                               max_retries=service_busy_retries)
                if not ok:
                    raise FlowServiceBusy(
                        f"Flow Agent remained at high demand after capacity recovery timeout "
                        f"(matched: {capacity!r}).")
                deadline = time.time() + timeout_s
                continue

            # On a brand-new Flow project the credit card can arrive well after
            # the prompt was submitted. Probe throughout the wait, not just once
            # during the first few seconds. "once" still never clicks the
            # persistent Always-approve control.
            now = time.time()
            confirmation_configured = bool(
                self.ui.get("actions", {}).get("agent_confirmation_buttons"))
            if (confirmation_configured and approval != "manual"
                    and now - last_approval_probe >= 2.0):
                last_approval_probe = now
                self.confirm_agent_generation(
                    timeout_s=1, approval=approval,
                    max_credits=max_generation_credits)
                confirm = getattr(self, "last_agent_confirmation", {}) or {}
                if confirm.get("blocked"):
                    return False
                approval_resolved = bool(confirm.get("clicked"))
            body = ""
            try:
                body = (self._page.inner_text("body") or "")[-7000:].lower()
            except Exception as e:
                if self._looks_like_browser_closed_error(e):
                    raise FlowBrowserClosedError(str(e))
            busy = any(x in body for x in (
                "pending", "generating", "creating video", "creating image",
                "generation in progress", "rendering video", "making your video"))

            matching = []
            new_assets = []
            queue_assets = []
            if baseline is not None:
                assets = self.media_assets()
                new_assets = [a for a in assets if a.get("sig") and not any(
                    media_signature_matches(a["sig"], old) for old in baseline)]
                matching = FlowBrowserProvider._fresh_asset_candidates(assets, baseline)
                if wanted:
                    matching = [a for a in matching if str(a.get("kind", "")).lower() == wanted]
                queue_assets = [a for a in new_assets
                                if str(a.get("kind", "")).lower() == "pending"]

            # The Flow Agent can show a thumbnail inside an "accepted / waiting in
            # queue" card. That thumbnail is not a completed asset. Only wait on
            # a queue card when no requested-kind media is present; an actual new
            # playable video tile is allowed to proceed even if old queue text is
            # still visible elsewhere in the project history.
            queue_pending = bool(not matching and (
                queue_assets or (wanted == "video" and _is_flow_queue_status(body))))
            if queue_pending:
                busy = True
                saw_busy = True
                self.last_agent_queue_observed = True
                if queue_wait_started_at is None:
                    queue_wait_started_at = now
                    print("[Flow] Flow accepted the request but it is still scheduled in the high-demand queue. "
                          "Waiting for this same request to finish; no download or replacement generation will be attempted while queued.")
                elapsed = max(0.0, now - queue_wait_started_at)
                self.last_agent_queue_elapsed_s = elapsed
                if now - last_queue_heartbeat >= 30.0:
                    remaining = max(0, int(deadline - now))
                    print(f"[Flow] Queue wait heartbeat: elapsed={int(elapsed)}s remaining={remaining}s; "
                          "the queued thumbnail is not treated as a generated video.")
                    last_queue_heartbeat = now
                video_candidate_sig = None
                video_candidate_since = None
            else:
                queue_wait_started_at = None

            saw_busy = saw_busy or busy

            # Multiple distinct stills require journal/prompt correlation, not
            # six minutes of polling the unchanged gallery. Repeated previews of
            # one asset have already been collapsed using strict media identity.
            if wanted == 'image' and len(matching) > 1 and not busy:
                identities=tuple(sorted(str(a.get('sig')) for a in matching))
                if identities != ambiguous_images_key:
                    ambiguous_images_key=identities
                    ambiguous_images_since=now
                    print(f'[Flow] {len(matching)} distinct fresh images; waiting 30s for stability before exact journal correlation.')
                elif now-ambiguous_images_since >= 30:
                    if transactional_images:
                        print(f'[Flow] {len(matching)} fresh images are stable; exact journal classification will decide.')
                        return True
                    self.last_agent_failure='Multiple distinct images require exact request correlation'
                    return False
            else:
                ambiguous_images_since=None
                ambiguous_images_key=None

            if matching and not (wanted == "image" and len(matching) != 1 and image_request is None):
                if wanted == "video":
                    untyped_ready_at = None
                    untyped_warning_logged = False
                sig = str(matching[-1].get("sig"))
                if wanted in ("video", "image"):
                    # A real media card should stop changing before we click
                    # into it/download it. This is a small stability window,
                    # not an additional generation timeout.
                    if not media_signature_matches(sig, video_candidate_sig):
                        video_candidate_sig = sig
                        video_candidate_since = now
                        if not announced_wait:
                            print(f"[Flow] Explicit {wanted} tile detected; checking this exact asset after a brief stability window...")
                            announced_wait = True
                    elif video_candidate_since is not None and now - video_candidate_since >= 3.0:
                        # A new, typed video tile is stronger evidence than broad
                        # page text such as "pending" or "generating". The Agent
                        # keeps old turns/status cards in its DOM, so requiring the
                        # *entire page* to become idle can strand an already-present
                        # video until the 15-minute generation timeout. Continue to
                        # the exact-signature download and media validation instead;
                        # if it is not playable yet, bounded download-only recovery
                        # will retain the request without submitting another video.
                        if wanted == 'image' and image_request is not None:
                            verifier = FlowBrowserProvider.__new__(FlowBrowserProvider)
                            verified = verifier._identify_single_fresh_asset(
                                self, image_request, 'image', timeout_ms=0, fresh_only=True)
                            if not verified:
                                # An upload/old tile can arrive late after the baseline.
                                # Stability and image type are not generation proof.
                                self._page.wait_for_timeout(1000)
                                continue
                            sig = verified
                        self.last_generated_asset_signature = sig
                        self._set(FlowState.GENERATION_COMPLETE)
                        return True
                elif saw_busy or not busy:
                    self.last_generated_asset_signature = sig
                    self._set(FlowState.GENERATION_COMPLETE)
                    return True

            # Flow may add a still/poster before it exposes the video card.
            # Keep polling, but never turn that image into the identity of the
            # pending video request, even after the grace period.
            if wanted == "video" and new_assets and not busy and not matching:
                if untyped_ready_at is None:
                    untyped_ready_at = now
                    if not announced_wait:
                        print(f"[Flow] Fresh media appeared; waiting up to {grace}s for an explicit video tile...")
                        announced_wait = True
                elif (now - untyped_ready_at >= grace and not untyped_warning_logged):
                    print("[Flow] Fresh media is still image-only/untyped; it is not eligible as a video. Continuing to wait for explicit video evidence.")
                    untyped_warning_logged = True
            elif wanted != "video":
                untyped_ready_at = None

            if baseline is not None and not new_assets:
                untyped_ready_at = None
                untyped_warning_logged = False
                video_candidate_sig = None
                video_candidate_since = None
            elif baseline is None:
                now_assets = self.media_asset_count()
                if now_assets > before_count and wanted != "video" and (saw_busy or not busy):
                    self._set(FlowState.GENERATION_COMPLETE)
                    return True
                if saw_busy and not busy and now_assets >= before_count and wanted != "video":
                    self._set(FlowState.GENERATION_COMPLETE)
                    return True

            try:
                self._page.wait_for_timeout(max(500, int(self.ui["timeouts"].get("poll_interval", 8) * 1000 / 2)))
            except Exception as e:
                if self._looks_like_browser_closed_error(e):
                    raise FlowBrowserClosedError(str(e))
                raise
        return False

    @staticmethod
    def _salvage_playwright_download(download, out_path: str) -> str | None:
        """Best-effort salvage when Playwright download.save_as() fails after page closure.

        Flow sometimes finishes the download, then destroys/replaces the page
        target before ``save_as`` completes.  In that case the ``Download``
        handle can still expose a temporary file via ``path()``.  v4.8 copies
        that file into ``out_path`` instead of discarding the generated media.
        """
        try:
            if download is None:
                return None
            tmp = None
            try:
                tmp = download.path()
            except Exception:
                tmp = None
            if not tmp or not os.path.exists(tmp):
                return None
            os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
            shutil.copyfile(tmp, out_path)
            return out_path if os.path.exists(out_path) else None
        except Exception:
            return None

    def _open_asset_tile_download_menu(self, media_locator) -> bool:
        """Open the kebab menu belonging to a project-grid media tile.

        Downloading from Flow's full-screen media viewer is fragile: the viewer
        destroys its own page target as the browser download starts.  The project
        grid exposes the same Download choices from the tile's three-dot menu and
        keeps the canonical project page alive, so prefer that route.
        """
        try:
            media_locator.hover(timeout=2500)
        except Exception:
            pass
        try:
            clicked = media_locator.evaluate(r"""el => {
                const visible = n => {
                    if (!n) return false;
                    const r = n.getBoundingClientRect(), s = getComputedStyle(n);
                    return r.width > 0 && r.height > 0 && s.display !== 'none' &&
                           s.visibility !== 'hidden';
                };
                let node = el;
                for (let depth = 0; node && depth < 8; depth++, node = node.parentElement) {
                    if (['BODY', 'HTML', 'MAIN'].includes(node.tagName)) break;
                    const otherMedia = Array.from(node.querySelectorAll('img,video')).some(n => {
                        const box = n.getBoundingClientRect();
                        const labelled = /tile displaying/i.test(n.getAttribute('alt') || n.getAttribute('aria-label') || '');
                        return n !== el && visible(n) && box.width >= (labelled ? 80 : 140) && box.height >= (labelled ? 60 : 90);
                    });
                    if (otherMedia) break;
                    const controls = Array.from(node.querySelectorAll('button,[role="button"]'))
                        .filter(visible);
                    let more = controls.find(b => {
                        const hint = [b.getAttribute('aria-label') || '',
                                      b.getAttribute('title') || '',
                                      b.getAttribute('data-testid') || '',
                                      b.innerText || ''].join(' ').toLowerCase();
                        return /(?:more|menu|option|action|kebab|three.?dot|more_vert|more_horiz)/.test(hint);
                    });
                    // Flow's current tile has play + remix + kebab buttons; the
                    // kebab is the final control and sometimes has no accessible name.
                    if (more) { more.click(); return true; }
                }
                return false;
            }""", timeout=2500)
            if clicked:
                self._page.wait_for_timeout(350)
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def _click_download_control(control, timeout=3000):
        """Only for already-resolved download controls, never generation buttons."""
        try:
            control.click(timeout=timeout, no_wait_after=True)
        except Exception as exc:
            # Angular menu animations can prevent Playwright's stability check.
            # Do not bypass visibility/disabled checks or retry a detached page.
            if "not stable" not in str(exc).lower():
                raise
            if not control.is_visible() or not control.is_enabled():
                raise
            control.click(timeout=timeout, force=True, no_wait_after=True)

    def download_reviewed_editor_video(self, asset_url, out_path, project_url):
        """Only an operator-reviewed editor URL, never a newest-tile guess."""
        from urllib.parse import urlsplit
        u = urlsplit(asset_url)
        if (u.scheme != 'https' or u.hostname not in ('flow.google.com', 'labs.google')
                or u.username or u.password or u.query or u.fragment or u.port not in (None, 443)
                or not re.fullmatch(r'/project/[A-Za-z0-9_-]+/edit/[A-Za-z0-9_-]+', u.path)
                or self.normalize_project_url(asset_url) != self.normalize_project_url(project_url)):
            raise ValueError('Use the reviewed video editor URL from this job’s saved Flow project')
        self._ensure_project_guard_page(project_url)
        self._page.goto(asset_url, wait_until='domcontentloaded', timeout=45000)
        self._page.wait_for_timeout(1000)
        current = urlsplit(str(self._page.url))
        if current.hostname != u.hostname or current.path != u.path:
            raise FlowUIChanged('Flow did not open the reviewed video editor; download was not attempted')
        self._page.keyboard.press('Escape')
        self._wait_for_largest_media_ready()
        # The global menu's Download project is a different operation. Only
        # the asset toolbar's download control is eligible here.
        selectors = ["button[aria-label*='download' i]:not([aria-label*='project' i])",
                     "button[title*='download' i]:not([title*='project' i])",
                     "button:has(mat-icon:text-is('download'))",
                     "button:has(mat-icon:text-is('download_2'))"]
        candidates = [self._page.get_by_role('button', name=re.compile(r'^download(?: video)?$', re.I))]
        candidates.extend(self._page.locator(selector) for selector in selectors)
        for controls in candidates:
            visible = [controls.nth(i) for i in range(controls.count())
                       if controls.nth(i).is_visible(timeout=100)]
            if len(visible) == 1:
                os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
                return self._download_from_tile_button(visible[0], out_path)
        raise FlowUIChanged('The reviewed editor has no unique asset download button; Download project was not used')

    def _save_image_download_url(self, download, out_path):
        """Fetch the URL exposed by the browser's Download event, not a private API.

        Image save_as/path can wait indefinitely for a browser download. Use
        the exact event URL with bounded reads instead. Never copy cookies,
        log a signed URL, or switch to another asset. Validate before replace.
        """
        if not str(out_path).lower().endswith((".jpg", ".jpeg", ".png")):
            return None
        from threading import Thread, Event
        from queue import Queue, Empty
        import tempfile
        temporary = None
        cancelled = Event()
        result = Queue(maxsize=1)
        # Read the public Playwright property on its owning thread. The HTTP
        # reader below never touches Playwright, files, or job state.
        url = str(getattr(download, "url", "") or "")
        if not self._is_trusted_flow_download_url(url):
            return None
        def read_bytes():
            try:
                data = self._read_image_download_url(url, cancelled)
            except Exception:
                data = None
            if not cancelled.is_set():
                result.put(data)
        reader = Thread(target=read_bytes, name="flow-image-download", daemon=True)
        try:
            reader.start()
            data = result.get(timeout=_FLOW_IMAGE_DOWNLOAD_TIMEOUT_S)
            if data is None:
                return None
            os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
            fd, temporary = tempfile.mkstemp(prefix=".flow-image-", suffix=".download.tmp",
                                             dir=os.path.dirname(os.path.abspath(out_path)))
            os.close(fd)
            with open(temporary, "wb") as handle:
                handle.write(data)
            os.replace(temporary, out_path)
            print("[Flow] Saved the exact image from its browser download event URL.")
            return out_path
        except (Empty, OSError, RuntimeError):
            return None
        finally:
            cancelled.set()
            if temporary and os.path.isfile(temporary):
                os.remove(temporary)

    def _read_image_download_url(self, url, cancelled):
        """Return validated bytes only; a late HTTP reader cannot write media."""
        import io
        from urllib.parse import urljoin
        import requests
        from PIL import Image
        response = None
        try:
            if not self._is_trusted_flow_download_url(url):
                return None
            deadline = time.monotonic() + _FLOW_IMAGE_DOWNLOAD_TIMEOUT_S
            data = bytearray()
            with requests.Session() as session:
                session.trust_env = False
                for redirect_count in range(4):
                    remaining = deadline - time.monotonic()
                    if remaining <= 0 or cancelled.is_set():
                        return None
                    response = session.get(url, stream=True, timeout=(min(10, remaining), min(15, remaining)),
                                           allow_redirects=False)
                    headers = response.headers or {}
                    if 300 <= response.status_code < 400:
                        location = headers.get("Location")
                        response.close()
                        response = None
                        if not location or redirect_count >= 3:
                            return None
                        url = urljoin(url, str(location))
                        if not self._is_trusted_flow_download_url(url):
                            return None
                        continue
                    response.raise_for_status()
                    declared = headers.get("Content-Length")
                    if declared is not None and not 0 < int(declared) <= 32 * 1024 * 1024:
                        return None
                    for chunk in response.iter_content(65536):
                        if time.monotonic() >= deadline or cancelled.is_set():
                            raise TimeoutError("Image transfer deadline exceeded")
                        data.extend(chunk)
                        if len(data) > 32 * 1024 * 1024:
                            raise ValueError("Image download exceeds 32 MB")
                    if (declared is not None and str(headers.get("Content-Encoding", "")).lower() in ("", "identity")
                            and len(data) != int(declared)):
                        return None
                    break
                else:
                    return None
            with Image.open(io.BytesIO(data)) as image:
                if image.width < 140 or image.height < 90:
                    raise ValueError("Downloaded image is too small")
                image.verify()
            with Image.open(io.BytesIO(data)) as image:
                image.load()
            return bytes(data) if not cancelled.is_set() else None
        except Exception:
            return None
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass

    def _save_download_event(self, download, out_path):
        from engine.flow_blob_capture import capture
        if capture(self, download, out_path): return out_path
        if str(out_path).lower().endswith((".jpg", ".jpeg", ".png")):
            print("[Flow] Saving exact browser image artifact with a bounded wait (120s).")
            if self._save_browser_image_artifact(download, out_path):
                return out_path
            native_detail = getattr(self, "_image_artifact_detail", "browser_artifact_unavailable")
            if native_detail == "browser_artifact_target_closed":
                # v7.0.88: the Playwright error class and text show whether the page, context,
                # browser or the download itself ended. URLs are removed before logging.
                diag("save_as error: " + (getattr(self, "_image_artifact_error", "") or "none")
                     + "; download owner " + download_page_state(download, getattr(self, "_page", None))
                     + "; browser " + browser_state(self))
                # The event's exact HTTPS URL can outlive its browser target.
                # Attempt that bounded transfer before discarding the event.
                if self._save_image_download_url(download, out_path):
                    return out_path
                # v7.0.87: scheme code only (never the URL) to show why the HTTPS fallback could not run.
                try:
                    from urllib.parse import urlsplit
                    scheme = urlsplit(str(getattr(download, "url", "") or "")).scheme.lower()
                except Exception:
                    scheme = "unavailable"
                scheme = scheme if scheme in ("https", "blob", "data", "unavailable") else "other"
                raise FlowBrowserClosedError("Image download target closed (URL scheme=" + scheme + "); "
                                             "reconnect and recover the saved exact request")
            print(f"[Flow] Browser image artifact needs fallback: {native_detail}")
            if not self._save_image_download_url(download, out_path):
                from urllib.parse import urlsplit
                scheme = urlsplit(str(getattr(download, "url", "") or "")).scheme.lower()
                scheme = scheme if scheme in ("https", "blob", "data") else "other"
                raise FlowUIChanged(f"Exact image save failed: {native_detail}; URL scheme={scheme}; "
                                    "bounded HTTPS fallback unavailable or invalid; "
                                    "saved request retained for download-only Resume")
            return out_path
        if self._save_browser_video_artifact(download, out_path):
            return out_path
        if self._save_video_download_url(download, out_path):
            return out_path
        from urllib.parse import urlsplit
        scheme = urlsplit(str(getattr(download, 'url', '') or '')).scheme.lower()
        scheme = scheme if scheme in ('https', 'blob', 'data') else 'other'
        detail = {'native': getattr(self, '_video_artifact_detail', 'unavailable'),
                  'fallback': getattr(self, '_video_url_detail', 'unavailable'), 'url_scheme': scheme}
        try:
            self._save_video_download_diagnostic(out_path, detail)
        except OSError:
            pass
        raise FlowUIChanged('Exact video save failed: native=' + detail['native']
            + '; fallback=' + detail['fallback'] + '; URL scheme=' + scheme
            + '. Saved request retained for download-only recovery.')

    @staticmethod
    def _save_video_download_diagnostic(out_path, detail):
        # Codes only: never save cookies, download URLs or exception messages.
        target = out_path + '.download-diagnostic.json'
        with open(target + '.tmp', 'w', encoding='utf-8') as handle:
            json.dump(detail, handle, indent=2)
        os.replace(target + '.tmp', target)

    def _save_browser_video_artifact(self, download, out_path):
        """Save or salvage this exact Download event within one native budget."""
        import asyncio
        import tempfile
        from playwright.async_api import Download as AsyncDownload
        impl = getattr(download, '_impl_obj', None)
        sync = getattr(download, '_sync', None)
        self._video_artifact_detail = 'adapter_unavailable'
        if impl is None or not callable(sync):
            return None
        parent = os.path.dirname(os.path.abspath(out_path))
        os.makedirs(parent, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix='.flow-browser-video-', suffix='.mp4', dir=parent)
        os.close(fd)
        started = time.monotonic()
        def valid(path):
            return (os.path.isfile(path) and 0 < os.path.getsize(path) <= _FLOW_VIDEO_DOWNLOAD_MAX_BYTES
                    and FlowBrowserProvider._is_valid_video_file(path))
        try:
            artifact = AsyncDownload(impl)
            async def save():
                try:
                    await asyncio.wait_for(artifact.save_as(temporary), timeout=_FLOW_VIDEO_DOWNLOAD_TIMEOUT_S)
                    return 'saved'
                except asyncio.TimeoutError:
                    try: await asyncio.wait_for(artifact.cancel(), timeout=3)
                    except Exception: pass
                    return 'native_timeout'
                except Exception as error:
                    return ('target_closed' if self._looks_like_browser_closed_error(error)
                            else 'native_save_' + type(error).__name__)
            self._video_artifact_detail = sync(save())
            # save_as can finish writing before its target closes. Validate the
            # actual bytes even when the browser callback raised an exception.
            if not valid(temporary):
                remaining = _FLOW_VIDEO_DOWNLOAD_TIMEOUT_S - (time.monotonic() - started)
                if remaining > 0 and callable(getattr(artifact, 'path', None)):
                    async def exact_path():
                        return await asyncio.wait_for(artifact.path(), timeout=min(15, remaining))
                    try:
                        saved_path = sync(exact_path())
                        if saved_path and valid(saved_path):
                            shutil.copyfile(saved_path, temporary)
                            self._video_artifact_detail = 'exact_download_path_recovered'
                    except Exception as error:
                        self._video_artifact_detail += '; path_' + type(error).__name__
            if not valid(temporary):
                self._video_artifact_detail += '; no_valid_video_bytes'
                return None
            os.replace(temporary, out_path)
            print('[Flow] Exact browser video artifact validated and saved; no re-download needed.')
            self._video_artifact_detail = 'validated_native_artifact'
            return out_path
        except Exception as error:
            self._video_artifact_detail = 'local_save_' + type(error).__name__
            return None
        finally:
            if os.path.isfile(temporary): os.remove(temporary)

    def _save_browser_image_artifact(self, download, out_path):
        """Save this exact browser artifact on its owning Playwright loop.

        The narrow sync/async adapter is capability-checked: Playwright exposes
        no sync save timeout. It does not pass Playwright objects to threads,
        fetch a blob URL outside its browser, or copy browser credentials.
        """
        import asyncio
        import tempfile
        from playwright.async_api import Download as AsyncDownload
        from PIL import Image
        impl = getattr(download, "_impl_obj", None)
        sync = getattr(download, "_sync", None)
        self._image_artifact_detail = "browser_artifact_adapter_unavailable"
        self._image_artifact_error = ""  # v7.0.88: exception class and redacted message, for diagnostics
        if impl is None or not callable(sync):
            return None
        temporary = None
        try:
            parent = os.path.dirname(os.path.abspath(out_path))
            os.makedirs(parent, exist_ok=True)
            fd, temporary = tempfile.mkstemp(prefix=".flow-browser-image-", suffix=".tmp", dir=parent)
            os.close(fd)
            async_download = AsyncDownload(impl)
            async def save():
                try:
                    await asyncio.wait_for(async_download.save_as(temporary),
                                           timeout=_FLOW_IMAGE_DOWNLOAD_TIMEOUT_S)
                except asyncio.TimeoutError:
                    # Cancel only this download, never a Flow generation request.
                    try:
                        await asyncio.wait_for(async_download.cancel(), timeout=3)
                    except Exception:
                        pass
                    raise
            sync(save())
            if not 0 < os.path.getsize(temporary) <= 32 * 1024 * 1024:
                self._image_artifact_detail = "browser_artifact_size_invalid"
                return None
            with Image.open(temporary) as image:
                if image.width < 140 or image.height < 90:
                    self._image_artifact_detail = "browser_artifact_dimensions_invalid"
                    return None
                image.verify()
            with Image.open(temporary) as image:
                image.load()
            os.replace(temporary, out_path)
            self._image_artifact_detail = "browser_artifact_saved"
            print("[Flow] Exact browser image artifact validated and saved; no HTTP re-download needed.")
            return out_path
        except asyncio.TimeoutError:
            self._image_artifact_detail = "browser_artifact_timeout"
            self._image_artifact_error = "TimeoutError: save_as exceeded its bounded wait"
            return None
        except (OSError, ValueError) as exc:
            self._image_artifact_detail = "browser_artifact_invalid_or_storage_error"
            self._image_artifact_error = describe_exception(exc)
            return None
        except Exception as exc:
            self._image_artifact_error = describe_exception(exc)
            self._image_artifact_detail = ("browser_artifact_target_closed" if self._looks_like_browser_closed_error(exc)
                                           else "browser_artifact_save_failed_" + type(exc).__name__)
            return None
        finally:
            if temporary and os.path.isfile(temporary):
                os.remove(temporary)

    @staticmethod
    def _is_trusted_flow_download_url(url: str) -> bool:
        """Accept only HTTPS URLs on Google-owned hosts for UI download recovery."""
        from urllib.parse import urlsplit
        try:
            parsed = urlsplit(str(url or ""))
            host = (parsed.hostname or "").lower().rstrip(".")
            allowed = ("google", "google.com", "googleapis.com", "googleusercontent.com",
                       "googlevideo.com", "gstatic.com")
            # A signed browser download should use the normal HTTPS endpoint;
            # don't let an unusual port turn an allowlisted hostname into a
            # different service. Accessing .port also rejects malformed ports.
            port = parsed.port
            return (parsed.scheme.lower() == "https" and port in (None, 443)
                    and not parsed.username and not parsed.password
                    and any(host == domain or host.endswith("." + domain)
                            for domain in allowed))
        except Exception:
            return False

    @staticmethod
    def _has_mp4_file_type_box(prefix: bytes, total_bytes: int) -> bool:
        """Check for a complete, correctly-sized ISO BMFF ``ftyp`` first box.

        Looking for the word ``ftyp`` anywhere in a few bytes also accepts HTML,
        error documents, and arbitrary payloads. This inexpensive structural
        check filters those out; the provider still runs full media validation
        (including duration) before accepting the downloaded clip.
        """
        try:
            if len(prefix) < 16 or int(total_bytes) < 16 or prefix[4:8] != b"ftyp":
                return False
            box_size = int.from_bytes(prefix[:4], "big")
            if box_size == 1:
                # Large-size box: 32-bit size, type, 64-bit size, then the
                # mandatory major-brand and minor-version fields.
                if len(prefix) < 24 or int(total_bytes) < 24:
                    return False
                box_size = int.from_bytes(prefix[8:16], "big")
                minimum_size = 24
            else:
                # A zero-sized ftyp would consume the rest of the file and
                # cannot describe a playable MP4 container.
                if box_size == 0:
                    return False
                minimum_size = 16
            return minimum_size <= box_size <= int(total_bytes)
        except (TypeError, ValueError, OverflowError):
            return False

    def _save_video_download_url(self, download, out_path: str) -> str | None:
        """Stream the exact browser-triggered video URL if save_as lost its target.

        This is the URL supplied by Playwright's Download event after the user
        selected a specific project tile and resolution; it is not a private Flow
        API. Signed URLs are never printed or persisted. Only Google HTTPS hosts
        and complete MP4 file-type boxes are accepted. The result is written to a
        unique same-directory temporary file and atomically replaces ``out_path``;
        full media validation must still pass before a request is marked complete.
        """
        if not str(out_path).lower().endswith(".mp4"):
            return None
        import tempfile
        import requests
        from urllib.parse import urljoin
        self._video_url_detail = 'not_started'
        temporary = None
        response = None
        try:
            current_url = str(getattr(download, "url", "") or "")
            if not self._is_trusted_flow_download_url(current_url):
                self._video_url_detail = 'unsupported_or_untrusted_url'
                return None
            output_dir = os.path.dirname(os.path.abspath(out_path))
            os.makedirs(output_dir, exist_ok=True)
            fd, temporary = tempfile.mkstemp(
                prefix=f".{os.path.basename(out_path)}.", suffix=".download.tmp",
                dir=output_dir)
            os.close(fd)
            prefix = bytearray()
            byte_count = 0
            deadline = time.monotonic() + _FLOW_VIDEO_DOWNLOAD_TIMEOUT_S
            with requests.Session() as session:
                # A signed URL is self-authorizing; do not forward ambient proxy
                # settings or browser credentials/cookies to the URL or redirects.
                session.trust_env = False
                for redirect_count in range(_FLOW_VIDEO_DOWNLOAD_MAX_REDIRECTS + 1):
                    remaining_s = deadline - time.monotonic()
                    if remaining_s <= 0:
                        return None
                    timeout = (min(10.0, remaining_s), min(20.0, remaining_s))
                    response = session.get(current_url, stream=True, timeout=timeout,
                                           allow_redirects=False)
                    headers = getattr(response, "headers", {}) or {}
                    status = int(getattr(response, "status_code", 200) or 200)
                    if 300 <= status < 400:
                        location = headers.get("Location")
                        try:
                            response.close()
                        except Exception:
                            pass
                        response = None
                        if not location or redirect_count >= _FLOW_VIDEO_DOWNLOAD_MAX_REDIRECTS:
                            return None
                        current_url = urljoin(current_url, str(location))
                        if not self._is_trusted_flow_download_url(current_url):
                            return None
                        continue
                    self._video_url_detail = 'http_' + str(status)
                    response.raise_for_status()
                    content_type = str(headers.get("Content-Type", "")).split(";", 1)[0].strip().lower()
                    if content_type and not (content_type.startswith("video/")
                                              or content_type in ("application/mp4",
                                                                  "application/octet-stream")):
                        self._video_url_detail = 'unexpected_content_type'
                        return None
                    content_length = headers.get("Content-Length")
                    declared_bytes = None
                    if content_length is not None:
                        try:
                            declared_bytes = int(str(content_length).strip())
                        except (TypeError, ValueError):
                            return None
                        if declared_bytes < 0 or declared_bytes > _FLOW_VIDEO_DOWNLOAD_MAX_BYTES:
                            return None
                    with open(temporary, "wb") as output:
                        for chunk in response.iter_content(_FLOW_VIDEO_DOWNLOAD_CHUNK_BYTES):
                            if not chunk:
                                continue
                            if time.monotonic() > deadline:
                                raise TimeoutError(
                                    f"video download exceeded {_FLOW_VIDEO_DOWNLOAD_TIMEOUT_S} seconds")
                            if byte_count + len(chunk) > _FLOW_VIDEO_DOWNLOAD_MAX_BYTES:
                                raise ValueError("video download exceeds the configured size limit")
                            byte_count += len(chunk)
                            if len(prefix) < 64:
                                prefix.extend(chunk[:64 - len(prefix)])
                            output.write(chunk)
                    content_encoding = str(headers.get("Content-Encoding", "")).strip().lower()
                    if (declared_bytes is not None and content_encoding in ("", "identity")
                            and byte_count != declared_bytes):
                        return None
                    break
                else:
                    return None
            if not self._has_mp4_file_type_box(prefix, byte_count):
                self._video_url_detail = 'invalid_mp4_header'
                return None
            os.replace(temporary, out_path)
            temporary = None
            print("[Flow] Recovered the exact video from the browser download URL after save_as failed.")
            return out_path
        except Exception as error:
            self._video_url_detail += '; ' + type(error).__name__
            return None
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass
            if temporary and os.path.isfile(temporary):
                try:
                    os.remove(temporary)
                except OSError:
                    pass


    def _recover_download_save(self, download, out_path: str) -> str | None:
        """Recover the exact UI-triggered download through temp file or its signed URL."""
        if str(out_path).lower().endswith((".jpg", ".jpeg", ".png")):
            return self._save_image_download_url(download, out_path)
        if str(out_path).lower().endswith('.mp4'):
            # _save_download_event already exhausted the exact event's bounded
            # native/path/HTTPS attempts. Do not hide it in another unbounded path().
            return None
        salvaged = self._salvage_playwright_download(download, out_path)
        if salvaged:
            return salvaged
        if str(out_path).lower().endswith(".mp4"):
            return self._save_video_download_url(download, out_path)
        return self._save_image_download_url(download, out_path)

    def _download_from_tile_button(self, button, out_path: str) -> str:
        """Listen BEFORE the first click: image menus can download immediately."""
        downloads = []
        save_attempted = False
        event_blob_saved = []
        page = self._page
        # Playwright caches its wrapper on the Python callback. Built-in
        # list.append cannot hold that attribute (including on WSL/Python 3.10).
        def on_download(download):
            downloads.append(download)
            if str(out_path).lower().endswith('.mp4') and str(getattr(download, 'url', '') or '').startswith('blob:'):
                try:
                    from engine.flow_blob_capture import capture as capture_exact_blob
                    recovered = capture_exact_blob(self, download, out_path)
                    if recovered:
                        event_blob_saved.append(recovered)
                except Exception:
                    pass

        # Keep an owned project tab alive for grid downloads too: Flow can close
        # their target after firing the event, not only editor targets.
        self._ensure_project_guard_page(getattr(self, '_project_url', '') or getattr(page, 'url', ''))
        page.on("download", on_download)
        from engine.flow_ui_blob import arm
        validator = FlowBrowserProvider.__new__(FlowBrowserProvider)
        capture = arm(page, out_path, lambda path: validator._asset_valid(
            path, 'video' if str(out_path).lower().endswith('.mp4') else 'image'))
        label = "/".join(os.path.abspath(out_path).replace("\\", "/").split("/")[-3:])
        # v7.0.88: log-only watch for page, context and browser close, crash or disconnect.
        watch = PageWatch(self, page, label)
        watch.__enter__()
        try:
            print(f"[Flow] Waiting for a download event: {label}")
            try:
                self._click_download_control(button)
            except Exception:
                if not downloads and not (capture and capture.done):
                    raise
            # Flow's grid Download row opens a nested submenu on hover.
            # No event exists until Original size / 360p is selected.
            if not downloads and not (capture and capture.done):
                try:
                    button.hover(timeout=2000)
                except Exception:
                    pass
                if not downloads and not (capture and capture.done):
                    page.wait_for_timeout(500)
            if not downloads and not (capture and capture.done):
                video_download = str(out_path).lower().endswith('.mp4')
                option = self._try_resolve('download_video_original_option' if video_download else "download_original_option", timeout_ms=2000)
                if not downloads and option is not None:
                    self._click_download_control(option)
                elif not downloads and not (capture and capture.done):
                    # Scoped visible resolution items only, never another tile.
                    labels = ("Original size", "Download original", "Original", "MP4") if video_download else ("Original size", "Download original", "Original", "1K")
                    for label in labels:
                        options = page.get_by_text(label, exact=True)
                        if options.count() == 1 and options.first.is_visible(timeout=100):
                            self._click_download_control(options.first, timeout=2000)
                            break
            deadline = time.monotonic() + 30
            while not downloads and not (capture and capture.done) and time.monotonic() < deadline:
                page.wait_for_timeout(250)
            if capture and capture.done:
                print(f"[Flow] Exact UI blob saved and validated before download target closure: {label}")
                return out_path
            if event_blob_saved:
                return event_blob_saved[0]
            if not downloads and not (capture and capture.done):
                raise FlowUIChanged("No download event or validated UI blob within 30s; request retained for recovery")
            print(f"[Flow] Download event received; saving {label}")
            diag("download event: owner " + download_page_state(downloads[0], page)
                 + "; url " + url_shape(getattr(downloads[0], "url", "")) + "; watch "
                 + (", ".join(watch.events) or "no close or crash seen") + "; " + f"+{watch.elapsed():.1f}s after the click")
            save_attempted = True
            self._save_download_event(downloads[0], out_path)
            if not os.path.isfile(out_path):
                raise FlowUIChanged("Download event completed without a local file")
            print(f"[Flow] Download saved: {label} ({os.path.getsize(out_path)} bytes)")
            return out_path
        except Exception as exc:
            # Flow may close the target as its download fires. Preserve that
            # exact event instead of discarding it and regenerating the image.
            if downloads:
                try:
                    recovered = (self._recover_download_save(downloads[0], out_path) if save_attempted
                                 else self._save_download_event(downloads[0], out_path))
                    if recovered:
                        return recovered
                except Exception:
                    pass
            from ..support_report import redact
            print(f"[Flow] Download failed: {label}: {type(exc).__name__}: {redact(str(exc))}")
            raise
        finally:
            if capture: capture.close()
            try:
                page.remove_listener("download", on_download)
            except Exception:
                pass
            diag("download window for " + label + " closed: watch "
                 + (", ".join(watch.events) or "no close or crash seen")
                 + "; clicked page " + page_state(page) + "; browser " + browser_state(self)
                 + "; " + f"{watch.elapsed():.1f}s total")
            watch.__exit__(None, None, None)

    def _settle_exact_video_tile(self, signature: str):
        """Allow Flow's matched video to settle, then rebind its exact tile.

        A project grid can paint a 360p thumbnail before its download blob is
        prepared. The original tile locator may detach during that interval.
        Never switch to the newest tile if the saved identity disappears.
        """
        print("[Flow] Waiting 15s for the exact video tile to finish loading before download.")
        self._page.wait_for_timeout(15000)
        asset = self._wait_for_media_signature(signature, timeout_ms=15000)
        if not asset or str(asset.get('kind', '')).lower() != 'video':
            raise FlowUIChanged('The recorded video tile changed while loading; request retained for exact recovery')
        try:
            index = int(asset.get('dom_index', -1))
            tiles = self._page.locator('video, img')
            if index < 0 or index >= tiles.count() or not tiles.nth(index).is_visible(timeout=300):
                raise FlowUIChanged('The recorded video tile is no longer visible; request retained for exact recovery')
            return asset, tiles.nth(index)
        except FlowUIChanged:
            raise
        except Exception as exc:
            if self._looks_like_browser_closed_error(exc):
                raise FlowBrowserClosedError(str(exc))
            raise FlowUIChanged('The recorded video tile detached before download; request retained for exact recovery') from exc

    def _wait_for_media_ready(self, locator, kind: str, timeout_s: float = 90.0) -> None:
        """Return only after one Flow image/video element has fully loaded.

        The element must be visible, decoded, not busy, and unchanged for 2 s
        (so a placeholder swapped for the real file restarts the wait). Starting
        a download earlier saved partial media or closed the page. After the
        timeout the request is retained for exact recovery rather than downloaded.
        """
        print(f"[Flow] Waiting for the {kind} to finish loading before download.")
        deadline = time.monotonic() + max(1.0, float(timeout_s))
        stable_src = None
        stable_since = None
        while True:
            try:
                state = locator.evaluate(_MEDIA_READY_JS, timeout=2000)
            except Exception as exc:
                if self._looks_like_browser_closed_error(exc):
                    raise FlowBrowserClosedError(str(exc))
                state = {"ready": False, "src": ""}
            now = time.monotonic()
            if state.get("ready"):
                src = str(state.get("src") or "")
                if stable_since is None or src != stable_src:
                    stable_src, stable_since = src, now
                if now - stable_since >= 2.0:
                    print(f"[Flow] The {kind} finished loading; starting download.")
                    return
            else:
                stable_since = None
            if now >= deadline:
                raise FlowUIChanged(f"The {kind} was still loading after {int(timeout_s)}s; download not started, request retained for exact recovery")
            try:
                self._page.wait_for_timeout(500)
            except Exception as exc:
                if self._looks_like_browser_closed_error(exc):
                    raise FlowBrowserClosedError(str(exc))
                raise

    def _wait_for_largest_media_ready(self, timeout_s: float = 90.0) -> None:
        """Wait for the dominant visible image/video on an open viewer or card."""
        deadline = time.monotonic() + max(1.0, float(timeout_s))
        while True:
            try:
                index = int(self._page.evaluate(_MEDIA_PICK_JS))
            except Exception as exc:
                if self._looks_like_browser_closed_error(exc):
                    raise FlowBrowserClosedError(str(exc))
                index = -1
            if index >= 0:
                break
            # The viewer may still be rendering its media; poll until the deadline.
            if time.monotonic() >= deadline:
                raise FlowUIChanged("No visible image or video is loaded to download; download not started")
            self._page.wait_for_timeout(500)
        locator = self._page.locator("video, img").nth(index)
        kind = "video" if str(locator.evaluate("el => el.tagName")).upper() == "VIDEO" else "image"
        self._wait_for_media_ready(locator, kind, max(1.0, deadline - time.monotonic()))

    def _wait_for_media_signature(self, signature: str, timeout_ms: int = 15000):
        """Poll a loaded project gallery for one exact asset identity."""
        deadline = time.monotonic() + max(0, int(timeout_ms)) / 1000.0
        announced = False
        while True:
            for asset in self.media_assets():
                candidate = str(asset.get("sig", "") or "")
                if candidate and media_signature_matches(candidate, signature):
                    return asset
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            if not announced:
                print("[Flow] Waiting for the recorded media asset to appear in the recovered project gallery.")
                announced = True
            try:
                self._page.wait_for_timeout(min(500, max(50, int(remaining * 1000))))
            except Exception as exc:
                if self._looks_like_browser_closed_error(exc):
                    raise FlowBrowserClosedError(str(exc))
                raise

    def download_latest_asset(self, out_path: str, preferred_signature: str | None = None,
                              before_signatures: set[str] | None = None) -> str:
        """Download the newly generated Agent asset and automatically exit editor.

        ``preferred_signature`` comes from ``wait_for_agent_generation``.  If a
        baseline is supplied we refuse to silently download an older tile, fixing
        the repeated-single-image failure seen when Flow keeps historical media in
        the project grid.
        """
        baseline = set(before_signatures or ())
        candidates = []
        try:
            # Reuse media_assets() as the single fingerprint authority. Older
            # code rebuilt a shorter signature here (omitting `kind`), so a video
            # could be detected successfully and then become impossible to match
            # one line later during download.
            if preferred_signature:
                exact_asset = self._wait_for_media_signature(preferred_signature, timeout_ms=15000)
                assets = [exact_asset] if exact_asset else []
            else:
                assets = self.media_assets()
            els = self._page.locator("video, img")
            for asset in assets:
                i = int(asset.get("dom_index", -1))
                if i < 0 or i >= els.count():
                    continue
                el = els.nth(i)
                try:
                    if not el.is_visible(timeout=80):
                        continue
                    box = el.bounding_box()
                    gallery_tile = "tile displaying" in str(asset.get("alt", "")).lower()
                    if not box or box.get("width", 0) < (80 if gallery_tile else 140) or box.get("height", 0) < (60 if gallery_tile else 90):
                        continue
                    candidates.append((box.get("y", 0), box.get("x", 0),
                                       str(asset.get("sig", "")), el,
                                       str(asset.get("kind", "image")).lower()))
                except Exception as exc:
                    if self._looks_like_browser_closed_error(exc):
                        raise FlowBrowserClosedError(str(exc))
                    pass
        except FlowBrowserClosedError:
            raise
        except Exception:
            pass

        chosen = None
        if preferred_signature:
            for cand in candidates:
                if media_signature_matches(cand[2], preferred_signature):
                    chosen = cand
                    break
            if chosen is None:
                raise FlowUIChanged("The recorded asset is not visible; refusing to download a different tile")
        if chosen is None and baseline:
            fresh = [c for c in candidates if c[2] and not any(
                media_signature_matches(c[2], old, ignore_kind=(c[4] == "video"))
                for old in baseline)]
            if fresh:
                videos = [c for c in fresh if c[4] == "video"]
                if videos:
                    fresh = videos
                fresh.sort(key=lambda x: (x[0], x[1]))
                chosen = fresh[-1]
        if chosen is None and not baseline and candidates:
            candidates.sort(key=lambda x: (x[0], x[1]))
            chosen = candidates[-1]
        if chosen is None and baseline:
            raise FlowUIChanged(
                "Generation completed but no media distinct from the pre-generation assets was found; "
                "refusing to download an old Flow image")

        if chosen is not None and preferred_signature and chosen[2] == preferred_signature:
            print(f"[Flow] Matched the newly generated {chosen[4]} asset; preparing its tile download menu.")

        # If the exact recorded media is already open in its editor, use the
        # asset toolbar directly. Do not return to a grid or click another tile.
        current_url = str(getattr(self._page, 'url', '') or '')
        if (chosen is not None and chosen[4] == 'video' and preferred_signature
                and media_signature_matches(chosen[2], preferred_signature)
                and '/edit/' in current_url):
            return self.download_reviewed_editor_video(
                current_url, out_path, getattr(self, '_project_url', '') or current_url)

        if (chosen is not None and chosen[4] == 'video' and preferred_signature):
            settled, element = self._settle_exact_video_tile(preferred_signature)
            chosen = (chosen[0], chosen[1], str(settled['sig']), element, 'video')

        # Images load in the grid too. Never open a tile's download menu while
        # the tile is still a placeholder: that download was saved partially or
        # closed the page.
        if chosen is not None:
            self._wait_for_media_ready(chosen[3], chosen[4])

        # Stay on the canonical project page.  This avoids the Flow media viewer
        # target-closing race that made Download.save_as fail repeatedly on WSL.
        direct_tile_menu = False
        if "/edit/" not in str(getattr(self._page, "url", "") or "") and chosen is not None:
            print("[Flow] Opening the matched asset tile menu (bounded locator actions).")
            direct_tile_menu = self._open_asset_tile_download_menu(chosen[3])
            if direct_tile_menu:
                print("[Flow] Opened the project tile menu; downloading without entering the media viewer.")

        # Keep a sacrificial/stable project tab alive before opening a media editor.
        # Flow may close the active detail page after Download; the guard prevents
        # that tab-level close from becoming a visible full-browser restart.
        if not direct_tile_menu:
            try:
                print("[Flow] Tile menu unavailable; preserving project tab before exact asset viewer.")
                self._ensure_project_guard_page(getattr(self, "_project_url", "") or getattr(self._page, "url", ""))
            except Exception:
                pass

        if (not direct_tile_menu and
                "/edit/" not in str(getattr(self._page, "url", "") or "") and chosen is not None):
            try:
                chosen[3].click(timeout=2500)
                self._page.wait_for_timeout(800)
            except Exception:
                pass

        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        saved = None
        last_err = None
        try:
            btn = self._resolve("download_button", timeout_ms=5000)
            if direct_tile_menu:
                return self._download_from_tile_button(btn, out_path)
            try:
                if not saved:
                    with self._page.expect_download(timeout=1800) as dl:
                        btn.click()
                    d = dl.value
                    try:
                        self._save_download_event(d, out_path)
                        saved = out_path
                    except Exception as e:
                        last_err = e
                        if str(out_path).lower().endswith((".jpg", ".jpeg", ".png")):
                            raise
                        salvaged = self._recover_download_save(d, out_path)
                        if salvaged:
                            print('[Flow] Recovered the exact asset after the browser target closed during download.')
                            saved = salvaged
                        elif self._looks_like_browser_closed_error(e):
                            raise FlowBrowserClosedError(
                                f"Generated asset was detected but the browser/page closed during download: {e}")
            except Exception as e:
                last_err = e
                if str(out_path).lower().endswith((".jpg", ".jpeg", ".png")) and isinstance(e, FlowUIChanged):
                    raise
                if self._looks_like_browser_closed_error(e):
                    raise FlowBrowserClosedError(
                        f"Generated asset was detected but the browser/page closed during download: {e}")

            if not saved:
                try:
                    if not self._try_resolve("download_original_option", timeout_ms=1000):
                        btn.click()
                        self._page.wait_for_timeout(250)
                except Exception:
                    pass
                option = self._try_resolve("download_original_option", timeout_ms=3500)
                if option is None:
                    # Prefer Flow's native export; an "Original size" item may
                    # carry a smaller 360p label beside an upscaled 720p option.
                    for label in ("Original size", "Download original", "Original",
                                  "MP4", "1K", "360p", "720p", "1080p"):
                        try:
                            cand = self._page.get_by_text(label, exact=True).first
                            if cand.is_visible(timeout=400):
                                option = cand
                                break
                        except Exception:
                            pass
                if option is None:
                    raise FlowUIChanged(
                        "Download menu opened but the 1K/Original size option was not found")
                with self._page.expect_download(timeout=self.ui["timeouts"]["download"] * 1000) as dl:
                    option.click()
                d = dl.value
                try:
                    self._save_download_event(d, out_path)
                    saved = out_path
                except Exception as e:
                    last_err = e
                    if str(out_path).lower().endswith((".jpg", ".jpeg", ".png")):
                        raise
                    salvaged = self._recover_download_save(d, out_path)
                    if salvaged:
                        print('[Flow] Recovered the exact asset after the browser target closed during download.')
                        saved = salvaged
                    elif self._looks_like_browser_closed_error(e):
                        raise FlowBrowserClosedError(
                            f"Generated asset was detected but the browser/page closed during download: {e}")

            if not saved or not os.path.exists(saved):
                raise FlowUIChanged(f"Flow download did not produce {out_path}: {last_err}")
            return saved
        except Exception as e:
            if self._looks_like_browser_closed_error(e):
                raise FlowBrowserClosedError(
                    f"Generated asset was detected but the browser/page closed during download: {e}")
            if self.network_issue_detected(e):
                raise FlowTransientNetworkError(f"Flow download interrupted by network: {e}")
            if isinstance(e, (FlowUIChanged, FlowBrowserClosedError)):
                raise
            raise FlowUIChanged(f"Generated asset found but automatic Download control was not found: {e}")
        finally:
            try:
                page_closed = False
                try:
                    if self._page is None:
                        page_closed = True
                    elif hasattr(self._page, "is_closed"):
                        page_closed = bool(self._page.is_closed())
                    else:
                        page_closed = False
                except Exception:
                    page_closed = True
                if page_closed and self._adopt_live_flow_page(getattr(self, "_project_url", "")):
                    print("[Flow] Media/editor tab closed; continued on the preserved project tab.")
                elif not page_closed and not self.return_to_project(timeout_ms=10000):
                    if "/edit/" in str(getattr(self._page, "url", "") or ""):
                        print("[Flow] WARNING: could not leave media editor automatically; next operation will retry recovery.")
            except Exception:
                try:
                    self._adopt_live_flow_page(getattr(self, "_project_url", ""))
                except Exception:
                    pass

    def _fill_editor_box(self, action: str, text: str, timeout_ms: int = 12000):
        # Expanded Agent sessions can contain more than one historical/editor
        # contenteditable. Prefer the last visible one, which is the live composer
        # at the bottom-right of the panel.
        box = None
        if action == "agent_prompt_box":
            self._dismiss_media_picker()
            try:
                eds = self._page.locator("[contenteditable='true']")
                for i in range(eds.count() - 1, -1, -1):
                    cand = eds.nth(i)
                    if cand.is_visible(timeout=120):
                        box = cand
                        break
            except Exception:
                box = None
        if box is None:
            box = self._resolve(action, timeout_ms=timeout_ms)
        box.click(timeout=timeout_ms)
        try:
            box.fill(text[:4000], timeout=timeout_ms)
        except Exception:
            # Current Flow's migrated composer is contenteditable.
            try:
                box.press("Control+A")
            except Exception:
                self._page.keyboard.press("Control+A")
            try:
                box.type(text[:4000], delay=1)
            except Exception:
                self._page.keyboard.type(text[:4000], delay=1)
        if action == 'agent_prompt_box':
            self._last_agent_prompt_box = box
        return box

    def configure_migrated_text_video(self, aspect: str = "9:16",
                                       model_label: str = "", duration: int = 8,
                                       count: int = 1):
        """Configure the Sep-2026 flow.google.com standard Angular editor.

        This intentionally uses the editor's structural controls rather than the
        removed ``Text to Video`` tab.  It is a normal UI path; no private API is
        called by AutoVideoAI.
        """
        trigger = self._resolve("migrated_settings_trigger", timeout_ms=5000)
        trigger.click()
        self._page.wait_for_timeout(350)

        # Video mode.
        video = self._try_resolve("migrated_video_radio", timeout_ms=3000)
        if video:
            try:
                if video.get_attribute("aria-checked") != "true":
                    video.click()
                    self._page.wait_for_timeout(300)
            except Exception:
                video.click()

        # Aspect ratio.
        akey = "migrated_aspect_portrait" if aspect == "9:16" else "migrated_aspect_landscape"
        ar = self._try_resolve(akey, timeout_ms=3000)
        if ar:
            try:
                if ar.get_attribute("aria-checked") != "true":
                    ar.click()
            except Exception:
                ar.click()

        # Model picker lives inside the settings overlay.  Keep the current model
        # when no label was requested.
        if model_label:
            mp = self._try_resolve("migrated_model_picker", timeout_ms=2500)
            if mp:
                mp.click()
                try:
                    opt = self._page.get_by_role(
                        "menuitem", name=re.compile(re.escape(model_label), re.I)
                    ).first
                    opt.wait_for(timeout=5000)
                    opt.click()
                except Exception as e:
                    # Close the model menu before surfacing a clean warning.
                    try:
                        self._page.keyboard.press("Escape")
                    except Exception:
                        pass
                    raise FlowUIChanged(f"Video model not found: {model_label}: {e}")

        # Duration / output count use exact numeric labels in the live editor.
        try:
            radios = self._page.locator(".cdk-overlay-pane [role='radio']")
            dur = radios.filter(has_text=re.compile(rf"^\s*{int(duration)}s\s*$", re.I)).first
            if dur.is_visible(timeout=800):
                dur.click()
        except Exception:
            pass
        try:
            radios = self._page.locator(".cdk-overlay-pane [role='radio']")
            cnt = radios.filter(has_text=re.compile(rf"^\s*x{max(1, int(count))}\s*$", re.I)).first
            if cnt.is_visible(timeout=800):
                cnt.click()
        except Exception:
            pass

        # Close settings and return to composer.
        try:
            self._page.keyboard.press("Escape")
        except Exception:
            pass
        self._page.wait_for_timeout(250)

    def prepare_text_video(self, aspect: str = "9:16", model_label: str = "",
                           duration: int = 8, count: int = 1) -> str:
        """Prepare text-to-video and return the active UI strategy.

        ``standard`` configures the migrated editor controls.  ``agent`` deliberately
        skips obsolete Text-to-Video tabs; the requested video settings are encoded
        into the Agent instruction instead.
        """
        mode = self.detect_editor_mode()
        if mode == "standard":
            self.configure_migrated_text_video(aspect, model_label, duration, count)
            return mode
        if mode == "agent":
            # The Agent composer can retain the preceding image mode (especially
            # after storyboard stills). Prefer an explicit UI mode switch whenever
            # Flow exposes its current-generation picker; the prompt instruction is
            # only a fallback for cohorts without that control.
            self.select_agent_generation_type("video")
            return mode

        # Older cohorts may still expose the pre-migration controls.
        self.select_video_mode("text")
        if model_label:
            self.select_model(model_label)
        try:
            self.set_aspect_ratio(aspect)
        except FlowUIChanged:
            pass
        self.set_duration(duration)
        self.set_output_count(count)
        return "legacy"

    def fill_text_video_prompt(self, prompt: str, strategy: str, aspect: str = "9:16",
                               model_label: str = "", duration: int = 8, count: int = 1):
        if strategy == "agent":
            text = self._agent_video_instruction(prompt, aspect, model_label, duration, count)
            return self._fill_editor_box("agent_prompt_box", text)
        return self._fill_editor_box("prompt_box", prompt)

    def agent_submission_state(self, prompt):
        """Visible composer plus non-editable conversation evidence; no network API."""
        return self._page.evaluate("""(prompt) => {
            const norm = s => (s || '').normalize('NFC').replace(/\\s+/g, ' ').trim();
            const visible = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
            const editable = [...document.querySelectorAll('[contenteditable="true"]')].filter(visible);
            const editors = editable.length ? editable : [...document.querySelectorAll('textarea')].filter(visible);
            const editor = editors[editors.length - 1];
            const composer = norm(editor ? (editor.value ?? editor.innerText) : '');
            const clone = document.body.cloneNode(true);
            clone.querySelectorAll('[contenteditable="true"],textarea,input,script,style').forEach(e => e.remove());
            const history = norm(clone.textContent);
            const wanted = norm(prompt);
            const occurrences = wanted ? history.split(wanted).length - 1 : 0;
            return {composer_matches: composer === wanted, composer_empty: !composer,
                    prompt_occurrences: occurrences};
        }""", prompt)

    def wait_for_submission_ack(self, prompt, before, timeout_s=30):
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            state = self.agent_submission_state(prompt)
            if state['prompt_occurrences'] > before.get('prompt_occurrences', 0):
                return True
            self._page.wait_for_timeout(500)
        return False

    def submit_prepared_text_video(self, strategy: str):
        self._set(FlowState.SUBMITTING)
        # v4.8.2: remember which failure strings already existed before this
        # request. Agent history is persistent, so only a newly-added failure is
        # relevant to the request we are about to submit.
        try:
            body_before = (self._page.inner_text("body") or "").lower()
            self._agent_failure_baseline = {
                str(t).lower(): body_before.count(str(t).lower())
                for t in self.ui.get("actions", {}).get("failure_texts", [])
                if str(t).strip()
            }
        except Exception:
            self._agent_failure_baseline = {}
        if strategy == "standard":
            self._resolve("migrated_submit_button", timeout_ms=10000).click()
        elif strategy == "agent":
            btn = self._try_resolve("agent_send_button", timeout_ms=2500)
            if btn:
                btn.click()
            else:
                # Focus the live composer explicitly. A media-picker/gallery
                # focus must never receive the send keystroke.
                box = getattr(self, "_last_agent_prompt_box", None) or self._resolve("agent_prompt_box", timeout_ms=2500)
                box.click(timeout=2500)
                box.press("Enter", timeout=2500)
        else:
            self._resolve("generate_button", timeout_ms=10000).click()
        self._set(FlowState.GENERATING)

    def _log_approval_click(self, label) -> None:
        journal = getattr(self, "_approval_journal", None)
        if not journal or not str(journal).endswith(".flow-request.json"):
            return
        out_path = str(journal)[:-len(".flow-request.json")]
        try:
            from ..flow_submit_guard import job_ledger_for, record
            record(out_path, job_ledger_for(out_path), "approval",
                   request_id=getattr(self, "_awaiting_request_id", "") or "",
                   label=str(label)[:80])
        except OSError as error:
            print(f"[Flow] Approval click could not be logged ({type(error).__name__}).")

    def confirm_agent_generation(self, timeout_s: int = 12, approval: str = "once",
                                 max_credits: int | None = None) -> bool:
        """Approve only a *currently clickable* Flow credit card.

        Flow keeps old Agent turns and old action text in the DOM.  v4.6 could
        therefore see a historical/non-clickable ``Approve``/generic action and
        eventually report ``credit confirmation blocked`` even though the newest
        turn already said ``I'm going to generate...``.  v4.7 never treats plain
        text as an approval control: the exact approval label must resolve to an
        enabled clickable element (button/role=button/clickable ancestor).
        """
        self.last_agent_confirmation = {"approval": approval, "cost": None,
                                        "clicked": None, "blocked": False}
        from ..flow_submit_guard import check_mode_active
        if check_mode_active():
            self.last_agent_confirmation.update(blocked=True, reason="check mode: approval refused")
            return False
        if getattr(self, "_approval_journal", None) and not getattr(self, "_awaiting_request_id", None):
            self.last_agent_confirmation.update(blocked=True, reason="no outstanding request; unsolicited approval refused")
            return False
        if approval == "manual":
            self.last_agent_confirmation["blocked"] = True
            self.last_agent_confirmation["reason"] = "manual approval requested"
            return False

        # Deliberately ignore generic Generate/Create/Continue/Yes controls. They
        # occur elsewhere in Flow and are not reliable credit-approval signals.
        configured = self.ui.get("actions", {}).get("agent_confirmation_buttons", []) or []
        approve_labels = [x for x in configured if "approve" in str(x).lower()]
        if approval == "always":
            labels = ["Always approve", "Approve", "Approve once"]
        else:
            labels = ["Approve", "Approve once"]
        for x in approve_labels:
            if x not in labels and not (approval != "always" and str(x).lower() == "always approve"):
                labels.append(x)

        def reserve_card():
            journal = getattr(self, '_approval_journal', None)
            if not journal:
                return True  # legacy unjournaled adapter compatibility
            from engine.flow_approval import reserve
            try:
                allowed = reserve(journal, body_raw, self.last_agent_confirmation.get('cost'),
                                  max_credits, getattr(self, '_approval_card_limit', 1))
                if not allowed:
                    self.last_agent_confirmation['reason'] = 'This approval card is already reserved; no duplicate click'
                return allowed
            except (OSError, ValueError, KeyError) as error:
                self.last_agent_confirmation.update(blocked=True, reason=str(error))
                print('[Flow] Approval stopped: '+str(error))
                return False

        def clickable_action(label: str):
            pat = re.compile(rf"^\s*{re.escape(label)}\s*$", re.I)
            # Best case: a real accessible button.
            try:
                locs = self._page.get_by_role("button", name=pat)
                if hasattr(locs, "count") and hasattr(locs, "nth"):
                    candidates = [locs.nth(i) for i in range(locs.count() - 1, -1, -1)]
                else:
                    candidates = [getattr(locs, "first", locs)]
                for loc in candidates:
                    if loc.is_visible(timeout=100):
                        try:
                            if loc.is_enabled(timeout=100):
                                return loc
                        except Exception:
                            return loc
            except Exception:
                pass

            # Some Flow cohorts render the text inside a clickable div.  Require a
            # clickable ancestor; never return the raw historical text node.
            try:
                texts = self._page.get_by_text(label, exact=True)
                if hasattr(texts, "count") and hasattr(texts, "nth"):
                    text_candidates = [texts.nth(i) for i in range(texts.count() - 1, -1, -1)]
                else:
                    text_candidates = [getattr(texts, "first", texts)]
                for txt in text_candidates:
                    if not txt.is_visible(timeout=80):
                        continue
                    try:
                        anc = txt.locator(
                            "xpath=ancestor-or-self::*[self::button or @role='button' or @tabindex or @href][1]"
                        )
                        if (not hasattr(anc, "count") or anc.count()) and anc.is_visible(timeout=80):
                            disabled = (anc.get_attribute("disabled") is not None or
                                        str(anc.get_attribute("aria-disabled") or "").lower() == "true")
                            if not disabled:
                                return anc
                    except Exception:
                        continue
            except Exception:
                pass
            return None

        deadline = time.time() + max(1, int(timeout_s))
        saw_clickable = False
        while time.time() < deadline:
            try:
                if self.network_issue_detected():
                    raise FlowTransientNetworkError(
                        "network unavailable while waiting for Flow credit approval")
                body_raw = self._page.inner_text("body") or ""
            except FlowTransientNetworkError:
                raise
            except Exception as e:
                if self._looks_like_browser_closed_error(e):
                    raise FlowBrowserClosedError(str(e))
                body_raw = ""

            tail = body_raw[-4200:]
            tail_lower = tail.lower()
            questions = list(re.finditer(r'would you like me to (?:kick off|start|create|generate)', tail, re.I))
            credit_text = tail[questions[-1].start():] if questions else tail

            # If the newest Agent response says the generation is already starting,
            # leave immediately. This must take precedence over stale approval text.
            progress_markers = (
                "generating", "creating video", "generation in progress",
                "i'm going to generate", "i’m going to generate",
                "going to generate a", "video interpolation between",
                "i'll generate", "i’ll generate", "starting the video",
            )
            progress_pos = max((tail_lower.rfind(x) for x in progress_markers), default=-1)
            confirmation_phrases = (
                "would you like me to kick off", "would you like me to start",
                "would you like me to generate", "costing", "credits",
            )
            confirm_pos = max((tail_lower.rfind(x) for x in confirmation_phrases), default=-1)
            if progress_pos >= 0 and progress_pos >= confirm_pos:
                self.last_agent_confirmation["reason"] =                     "generation already started/no visible approval required"
                return False

            visible = []
            for label in labels:
                loc = clickable_action(label)
                if loc is not None:
                    visible.append((label, loc))
            if visible:
                m = re.search(r"cost(?:ing|s)?\s+([0-9][0-9,]*)\s+(?:ai\s+)?credits?", credit_text, re.I)
                if not m:
                    m = re.search(r"([0-9][0-9,]*)\s+(?:ai\s+)?credits?", credit_text, re.I)
                if m:
                    cost = int(m.group(1).replace(",", ""))
                    self.last_agent_confirmation["cost"] = cost
                    if max_credits is not None and cost > int(max_credits):
                        self.last_agent_confirmation.update(
                            blocked=True, reason=f"credit guard: {cost} > {int(max_credits)}")
                        print(f"[Flow] Credit guard blocked generation: {cost} > {int(max_credits)} credits")
                        return False

                # Prefer Always approve only when explicitly requested.
                if approval == "always":
                    visible.sort(key=lambda x: 0 if x[0].lower() == "always approve" else 1)
                if not m:
                    self._page.wait_for_timeout(300)
                    continue
                saw_clickable = True
                if not reserve_card(): return False
                for label, loc in visible:
                    try:
                        try:
                            loc.click(timeout=1200)
                        except TypeError:
                            loc.click()
                        self.last_agent_confirmation["clicked"] = label
                        self._log_approval_click(label)
                        print(f"[Flow] Credit confirmation: clicked {label!r}"
                              + (f" ({self.last_agent_confirmation.get('cost')} credits)"
                                 if self.last_agent_confirmation.get('cost') is not None else ""))
                        self._page.wait_for_timeout(600)
                        return True
                    except Exception as e:
                        if self._looks_like_browser_closed_error(e):
                            raise FlowBrowserClosedError(str(e))
                        # A short-lived overlay can steal a click; keep polling.
                        pass

            # Compatibility for Flow cohorts where Approve is a clickable div
            # without button/role/tabindex semantics. Only attempt this when the
            # *newest* Agent text is an explicit current credit question; never
            # because generic page text says Generate/Create/Continue.
            explicit_confirmation = bool(re.search(
                r"would you like me to (?:kick off|start|create|generate).*?(?:credits?|generation)",
                tail, re.I | re.S))
            if explicit_confirmation and confirm_pos > progress_pos:
                m = re.search(r"cost(?:ing|s)?\s+([0-9][0-9,]*)\s+(?:ai\s+)?credits?", credit_text, re.I)
                if not m:
                    m = re.search(r"([0-9][0-9,]*)\s+(?:ai\s+)?credits?", credit_text, re.I)
                if m:
                    cost = int(m.group(1).replace(",", ""))
                    self.last_agent_confirmation["cost"] = cost
                    if max_credits is not None and cost > int(max_credits):
                        self.last_agent_confirmation.update(
                            blocked=True, reason=f"credit guard: {cost} > {int(max_credits)}")
                        print(f"[Flow] Credit guard blocked generation: {cost} > {int(max_credits)} credits")
                        return False
                raw_labels = (["Always approve", "Approve", "Approve once"]
                              if approval == "always" else ["Approve", "Approve once"])
                if not m:
                    self._page.wait_for_timeout(300)
                    continue
                if not reserve_card(): return False
                for label in raw_labels:
                    try:
                        if self._click_text_action(label, timeout_ms=450):
                            self.last_agent_confirmation["clicked"] = label
                            self._log_approval_click(label)
                            print(f"[Flow] Credit confirmation: clicked nonsemantic {label!r}"
                                  + (f" ({self.last_agent_confirmation.get('cost')} credits)"
                                     if self.last_agent_confirmation.get('cost') is not None else ""))
                            self._page.wait_for_timeout(600)
                            return True
                    except Exception as e:
                        if self._looks_like_browser_closed_error(e):
                            raise FlowBrowserClosedError(str(e))

            try:
                self._page.wait_for_timeout(300)
            except Exception as e:
                if self._looks_like_browser_closed_error(e):
                    raise FlowBrowserClosedError(str(e))

        if saw_clickable:
            # Only a genuinely clickable approval action can produce a blocked
            # result. Historical text or generic page controls can never do so.
            self.last_agent_confirmation.update(
                blocked=True,
                reason="a clickable Flow approval control remained visible but could not be activated")
        else:
            self.last_agent_confirmation["reason"] =                 "no clickable credit approval is present; continue waiting for generation"
        return False

    def select_agent_generation_type(self, media_kind: str, timeout_ms: int = 1200) -> bool:
        """Select Image/Video in the visible Flow type picker before an Agent send.

        The picker is absent in some conversational-only Flow cohorts; those still
        receive a type-specific instruction. If a picker is present but its option
        cannot be selected, fail before submitting a credit-bearing prompt instead
        of silently generating in the previously selected mode.
        """
        kind = str(media_kind or "").strip().lower()
        if kind not in ("image", "video"):
            raise ValueError(f"Unsupported Flow Agent generation type: {media_kind}")
        picker = self._try_resolve("generation_type_picker", timeout_ms=timeout_ms)
        if picker is None:
            print(f"[Flow] No explicit generation-type picker is visible; using a {kind}-only Flow Agent instruction.")
            return False
        try:
            picker.click()
        except Exception as exc:
            if self._looks_like_browser_closed_error(exc):
                raise FlowBrowserClosedError(str(exc))
            raise FlowUIChanged(f"Could not open Flow's generation-type picker: {exc}") from exc
        action = "video_option" if kind == "video" else "image_option"
        try:
            option = self._resolve(action, timeout_ms=5000)
            option.click()
        except Exception as exc:
            try:
                self._page.keyboard.press("Escape")
            except Exception:
                pass
            if self._looks_like_browser_closed_error(exc):
                raise FlowBrowserClosedError(str(exc))
            raise FlowUIChanged(
                f"Flow's generation-type picker opened but its {kind} option could not be selected; "
                "the prompt was not submitted") from exc
        try:
            self._page.wait_for_timeout(250)
        except Exception as exc:
            if self._looks_like_browser_closed_error(exc):
                raise FlowBrowserClosedError(str(exc))
        print(f"[Flow] Selected {kind.title()} mode in Flow's generation-type picker.")
        return True

    def select_video_mode(self, mode: str = "text"):
        # Rebuilt Flow no longer exposes Text-to-Video as a fixed top-level tab.
        # Official UI: click the current model name (Nano Banana by default),
        # choose Video, then configure model/aspect/duration.
        if mode == "text":
            if self.select_agent_generation_type("video", timeout_ms=3500):
                return
            # Legacy fallback. We do NOT silently continue merely because a prompt
            # box exists: the new default is Image and that could spend credits on
            # the wrong media type.
            self._resolve("text_to_video_tab", timeout_ms=3500).click()
            return

        action = {"frames": "frames_to_video_tab",
                  "ingredients": "ingredients_tab"}.get(mode)
        if not action:
            raise FlowUIChanged(f"Unsupported Flow video mode: {mode}")
        self._resolve(action).click()

    def select_image_mode(self):
        picker = self._try_resolve("generation_type_picker", timeout_ms=3500)
        if picker:
            try:
                picker.click()
                self._resolve("image_option", timeout_ms=5000).click()
                return
            except FlowUIChanged:
                pass
        self._resolve("image_tab").click()

    def submit_image_prompt(self, prompt: str):
        try:
            url = str(getattr(self._page, "url", "") or "")
        except Exception:
            url = ""
        if "/edit/" in url:
            canonical = self.normalize_project_url(url) or getattr(self, "_project_url", "")
            if not self.recover_project_page(canonical, timeout_ms=12000):
                raise FlowUIChanged(
                    "Flow is still on a generated-media /edit/ page; refusing to submit an image prompt there")
        self._set(FlowState.SUBMITTING)
        box = self._resolve("prompt_box")
        box.click()
        box.fill(prompt[:4000])
        self._resolve("generate_button").click()
        self._set(FlowState.GENERATING)

    def select_model(self, model_label: str):
        self._set(FlowState.SETTING_MODEL)
        try:
            self._resolve("model_picker").click()
        except FlowUIChanged:
            pass
        self._click_text(model_label)

    def set_aspect_ratio(self, aspect: str):
        self._resolve("aspect_portrait" if aspect == "9:16" else "aspect_landscape").click()

    def set_duration(self, seconds: int):
        try:
            self._click_text(str(seconds))
        except FlowUIChanged:
            pass

    def set_output_count(self, count: int):
        try:
            self._click_text(str(count))
        except FlowUIChanged:
            pass

    def upload_reference(self, path: str):
        self._set(FlowState.UPLOADING_REFERENCE)
        with self._page.expect_file_chooser(timeout=self.ui["timeouts"]["upload"] * 1000) as fc:
            self._resolve("upload_button").click()
        fc.value.set_files(path)

    def set_first_frame(self, path: str):
        try:
            self._resolve("first_frame_slot").click()
            with self._page.expect_file_chooser(timeout=30000) as fc:
                self._page.keyboard.press("Enter")
            fc.value.set_files(path)
        except Exception as e:
            raise FlowUIChanged(f"first-frame slot: {e}")

    def set_last_frame(self, path: str):
        try:
            self._resolve("last_frame_slot").click()
            with self._page.expect_file_chooser(timeout=30000) as fc:
                self._page.keyboard.press("Enter")
            fc.value.set_files(path)
        except Exception as e:
            raise FlowUIChanged(f"last-frame slot: {e}")

    def submit_prompt(self, prompt: str):
        self._set(FlowState.SUBMITTING)
        box = self._resolve("prompt_box")
        box.click()
        box.fill(prompt[:4000])
        self._resolve("generate_button").click()
        self._set(FlowState.GENERATING)

    def detect_failure(self) -> str | None:
        try:
            # Flow keeps historical Agent turns in the DOM.  Use the full body
            # for occurrence counts and a tail window only for recency checks.
            body_raw = self._page.inner_text("body") or ""
            body = body_raw.lower()
            tail = body[-9000:]
        except Exception as e:
            if self._looks_like_browser_closed_error(e):
                raise FlowBrowserClosedError(str(e))
            return None

        progress_markers = (
            "pending", "generating", "creating image", "creating video",
            "generation in progress", "rendering video", "making your video",
            "i'm going to generate", "i’m going to generate",
            "waiting in the queue", "scheduled and is waiting",
            "scheduled and waiting", "queued due to high demand",
        )
        newest_progress = max((tail.rfind(x) for x in progress_markers), default=-1)

        # Usage-limit cards also persist in Agent history. Raise only when the
        # newest relevant state is still the limit; a later progress marker means
        # the account recovered and a newer request is already running.
        newest_quota = (-1, None)
        for t in self.ui["actions"].get("quota_texts", []):
            marker = str(t).lower()
            pos = tail.rfind(marker) if marker else -1
            if pos > newest_quota[0]:
                newest_quota = (pos, str(t))
        if newest_quota[0] >= 0 and newest_progress <= newest_quota[0]:
            raise FlowQuotaExceeded(
                f"Flow reports an account usage/rate limit ({newest_quota[1]!r}). "
                "Existing project media is safe; no automatic retry was submitted.")

        baseline = getattr(self, "_agent_failure_baseline", {}) or {}

        newest_failure = (-1, None)
        for t in self.ui["actions"].get("failure_texts", []):
            marker = str(t).lower().strip()
            if not marker:
                continue
            pos = tail.rfind(marker)
            if pos < 0:
                continue
            current_count = body.count(marker)
            prior_count = int(baseline.get(marker, 0) or 0)
            # If this exact failure string was already present before the current
            # submission and no new occurrence appeared, it is stale history.
            if baseline and current_count <= prior_count:
                continue
            if pos > newest_failure[0]:
                newest_failure = (pos, str(t))

        if newest_failure[0] < 0:
            return None
        # A newer progress marker means Flow has already moved on from the failure
        # card (e.g. user clicked Try again / Always approve manually).
        if newest_progress > newest_failure[0]:
            return None
        if str(newest_failure[1]).lower() == "something went wrong" and _is_flow_queue_status(tail):
            return None  # Queue wait remains bounded by the existing request deadline.
        return newest_failure[1]

    def wait_for_generation(self, timeout_s: int | None = None,
                            indicator_key: str = "generating_indicator") -> bool:
        timeout_s = timeout_s or self.ui["timeouts"]["generation"]
        poll = self.ui["timeouts"]["poll_interval"]
        deadline = time.time() + timeout_s
        seen_busy = False
        while time.time() < deadline:
            fail = self.detect_failure()
            if fail:
                self._set(FlowState.FAILED)
                return False
            # generating indicator gone (after having been seen) => complete
            try:
                inds = self.ui["actions"].get(indicator_key) or []
                n = 0
                for ind in inds:
                    n += self._page.get_by_text(ind.get("text", "Generating"), exact=False).count()
                if n > 0:
                    seen_busy = True
                elif seen_busy:
                    self._set(FlowState.GENERATION_COMPLETE)
                    return True
            except Exception:
                pass
            time.sleep(poll)
        return False

    def wait_for_image(self, timeout_s: int | None = None) -> bool:
        return self.wait_for_generation(timeout_s or 300, "image_generating_indicator")

    def download_image(self, card_index: int, out_path: str):
        self._set(FlowState.DOWNLOADING)
        return self.download_generation(card_index, out_path)

    def collect_generation_cards(self) -> list:
        try:
            cands = self._candidates("generation_card")
            loc = self._page.locator(cands[0].get("selector", "[data-generation-card]")) if cands and cands[0].get("by") == "css" else None
            if loc is None:
                return []
            return [loc.nth(i) for i in range(min(loc.count(), 6))]
        except Exception:
            return []

    def download_generation(self, card_index: int, out_path: str):
        self._set(FlowState.DOWNLOADING)
        cards = self.collect_generation_cards()
        if cards and card_index < len(cards):
            cards[card_index].click()
            # The card opens a viewer whose media loads after the click. Wait for
            # the loaded element before Download, otherwise the download starts early.
            self._wait_for_largest_media_ready()
        with self._page.expect_download(timeout=self.ui["timeouts"]["download"] * 1000) as dl:
            self._resolve("download_button").click()
        d = dl.value
        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        try:
            self._save_download_event(d, out_path)
        except Exception as exc:
            recovered = self._recover_download_save(d, out_path)
            if recovered:
                print("[Flow] Recovered the exact generated asset after browser download failure.")
                return recovered
            if self._looks_like_browser_closed_error(exc):
                raise FlowBrowserClosedError(str(exc))
            raise
        return out_path

    def request_upscale(self):
        self._resolve("upscale_button").click()
        self._set(FlowState.GENERATING)

    # ---------- assisted mode ----------
    @staticmethod
    def watch_folder(folder: str, known: set[str], timeout_s: int = 600, poll: int = 5) -> str | None:
        """Return newest finished video file appearing in folder (assisted mode)."""
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            files = []
            for ext in ("*.mp4", "*.webm", "*.mov"):
                files += glob.glob(os.path.join(folder, ext))
            fresh = sorted([f for f in files if f not in known and os.path.getsize(f) > 100000],
                           key=os.path.getmtime)
            if fresh:
                cand = fresh[-1]
                s1 = os.path.getsize(cand)
                time.sleep(4)  # ensure download finished (size stable)
                if os.path.getsize(cand) == s1:
                    return cand
            time.sleep(poll)
        return None


class FlowBrowserProvider(VideoProvider):
    """v3 provider wrapper around FlowBrowser (subscription, no API billing)."""
    name = "flow"

    def __init__(self, headless: bool = False, profile_dir: str | None = None):
        self.bridge: FlowBrowser | None = None
        self.headless = headless
        self.profile_dir = profile_dir
        self._last_video_baseline: set[str] = set()
        self._last_video_project_url: str = ""
        self._last_video_request_at: float = 0.0
        self._last_video_shot_id: str = ""

    def status(self) -> ProviderStatus:
        try:
            import playwright  # noqa
        except ImportError:
            return ProviderStatus(False, "playwright pip package missing (pip install playwright)")
        try:
            ui = yaml.safe_load(open("config/flow_ui.yaml", encoding="utf-8"))
            bcfg = resolve_browser_cfg(ui)
        except Exception:
            bcfg = {"mode": "auto"}
        sys_chrome = find_system_chrome()
        bits = [f"mode={bcfg.get('mode', 'auto')}"]
        bits.append(f"system-chrome={'yes' if sys_chrome else 'no'}")
        if sys_chrome:
            bits.append(sys_chrome)
        if bcfg.get("cdp_url"):
            bits.append(f"cdp={bcfg['cdp_url']}")
        if os.path.isdir(PROFILE_DIR) and os.listdir(PROFILE_DIR):
            bits.append("saved-session=yes")
        return ProviderStatus(True, " | ".join(bits))

    def _ensure(self):
        """Return a fully initialized Flow bridge, never a half-started one.

        Older builds assigned ``self.bridge`` before ``ensure_session()``.  If
        Playwright startup failed once, retries reused that poisoned object with
        ``_page=None`` and produced misleading ``NoneType.wait_for_timeout``
        errors.  Build the bridge transactionally and discard it on any startup
        failure so the next retry performs a real fresh launch.
        """
        if self.bridge is not None and getattr(self.bridge, "_page", None) is None:
            try:
                self.bridge.close()
            except Exception:
                pass
            self.bridge = None

        if self.bridge is None:
            if self.profile_dir:
                candidate = FlowBrowser(headless=self.headless, profile_dir=self.profile_dir)
            else:
                candidate = FlowBrowser(headless=self.headless)
            try:
                candidate.ensure_session()
            except Exception:
                try:
                    candidate.close()
                except Exception:
                    pass
                self.bridge = None
                raise
            self.bridge = candidate
        return self.bridge

    def is_transient_network_error(self, err) -> bool:
        try:
            b = self._ensure()
            return b._looks_like_network_error(err) or b.network_issue_detected(err)
        except Exception:
            return FlowBrowser._looks_like_network_error(err)

    def recover_network(self, project: str, timeout_s: int = 300, project_url: str | None = None) -> bool:
        b = self._ensure()
        if not b.wait_for_network_recovery(timeout_s=timeout_s):
            return False
        try:
            try:
                b.ensure_project(project, project_url=project_url)
            except TypeError:  # older bridge/test compatibility
                b.ensure_project(project)
            return True
        except Exception:
            return False

    def is_browser_closed_error(self, err) -> bool:
        return FlowBrowser._looks_like_browser_closed_error(err)

    def recover_browser(self, project: str, project_url: str | None = None) -> bool:
        """Recover a Flow page first; restart the browser only when the context is dead."""
        print("[Flow] Flow page closed unexpectedly; attempting soft page recovery...")
        try:
            b = self._ensure()
            if b.recover_project_page(project_url=project_url):
                try:
                    b.ensure_project(project, project_url=project_url)
                except TypeError:
                    b.ensure_project(project)
                print("[Flow] Page recovered without restarting the browser.")
                return True
        except Exception:
            pass

        print("[Flow] Browser context is not recoverable; rebuilding Flow session...")
        try:
            self.close()
            self.bridge = None
        except Exception:
            self.bridge = None
        try:
            b = self._ensure()
            b.ensure_project(project, project_url=project_url)
            print("[Flow] Browser session recovered.")
            return True
        except Exception as e:
            print(f"[Flow] Browser recovery failed: {str(e)[:220]}")
            return False

    def current_project_url(self) -> str:
        try:
            return self._ensure().current_project_url()
        except Exception:
            return ""

    def _ensure_live_recovery_project(self, project: str, project_url: str | None = None):
        """Return a live Flow bridge positioned on the canonical project page.

        Recovery waits are useful only while we actually have a browser/project
        page to inspect.  Older builds swallowed page/context failures and then
        slept for the full recovery timeout while no usable Flow window existed.
        v5.3.3 validates the page/context before every recovery poll and rebuilds
        the session immediately when necessary.
        """
        wanted = FlowBrowser.normalize_project_url(project_url) or self._last_video_project_url or ""

        def page_is_live(b):
            try:
                pg = getattr(b, "_page", None)
                if pg is None or pg.is_closed():
                    return False
                ctx = getattr(b, "_ctx", None)
                if ctx is None:
                    return False
                pages = list(getattr(ctx, "pages", []) or [])
                if not any(not x.is_closed() for x in pages):
                    return False
                return True
            except Exception:
                return False

        b = self._ensure()
        must_recover = not page_is_live(b)
        if not must_recover:
            try:
                raw = str(getattr(b._page, "url", "") or "")
                cur = FlowBrowser.normalize_project_url(raw)
                if "/edit/" in raw or (wanted and cur != wanted):
                    must_recover = True
            except Exception:
                must_recover = True

        if must_recover:
            print("[Flow] Recovery poll has no live canonical Flow project page; reopening it now...")
            if not self.recover_browser(project, project_url=wanted or project_url):
                return None
            b = self._ensure()

        try:
            try:
                b.ensure_project(project, project_url=wanted or project_url)
            except TypeError:
                b.ensure_project(project)
        except Exception as e:
            if FlowBrowser._looks_like_browser_closed_error(e):
                print("[Flow] Recovery project page disappeared; rebuilding before continuing the wait...")
                if not self.recover_browser(project, project_url=wanted or project_url):
                    return None
                b = self._ensure()
                try:
                    b.ensure_project(project, project_url=wanted or project_url)
                except TypeError:
                    b.ensure_project(project)
            else:
                return None

        # When running headed, make the fact that recovery is active visible to
        # the operator. This also wakes some Chromium/SPA rendering paths.
        if not self.headless:
            try:
                b._page.bring_to_front()
            except Exception:
                pass
        return b

    @staticmethod
    def _is_valid_video_file(path: str) -> bool:
        """Return True only for a time-based video, not a still image in disguise.

        v5.1 only checked ffprobe's ``codec_type=video``. A JPEG also has a video
        stream when probed as ``jpeg_pipe``, which allowed a single poster image
        to be saved as ``take_01.mp4`` and later exploded the renderer with an
        invalid/undefined duration. v5.2 requires a real container *and* finite
        positive duration.
        """
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
        except Exception:
            return False

        ffprobe = shutil.which("ffprobe")
        if ffprobe:
            try:
                import json as _json, math as _math
                cp = subprocess.run(
                    [ffprobe, "-v", "error", "-show_entries",
                     "format=format_name,duration:stream=codec_type,codec_name,duration,nb_frames,avg_frame_rate",
                     "-of", "json", path],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20)
                if cp.returncode != 0:
                    return False
                data = _json.loads(cp.stdout or "{}")
                fmt = data.get("format") or {}
                fmt_name = str(fmt.get("format_name") or "").lower()
                # Still-image demuxers are never acceptable as generated video.
                if any(x in fmt_name for x in ("image2", "jpeg_pipe", "png_pipe", "bmp_pipe", "gif")):
                    return False
                streams = [x for x in (data.get("streams") or []) if str(x.get("codec_type")) == "video"]
                if not streams:
                    return False
                durations = []
                for raw in [fmt.get("duration")] + [x.get("duration") for x in streams]:
                    try:
                        v = float(raw)
                        if _math.isfinite(v) and v > 0:
                            durations.append(v)
                    except Exception:
                        pass
                if not durations or max(durations) < 0.5:
                    return False
                return True
            except Exception:
                return False

        # Lightweight fallback only when ffprobe is unavailable. Require a real
        # container magic header; ordinary JPEG/PNG bytes are rejected.
        try:
            with open(path, "rb") as f:
                head = f.read(32)
            if len(head) >= 12 and head[4:8] == b"ftyp":
                return True
            if head.startswith(b"\x1aE\xdf\xa3"):
                return True
        except Exception:
            pass
        return False


    def _download_after_browser_recovery(self, project: str, out_path: str,
                                         project_url: str | None = None,
                                         preferred_signature: str | None = None,
                                         before_signatures: set[str] | None = None,
                                         attempts: int = 2) -> str:
        """Reconnect to the same project and re-download the already-generated newest asset.

        v4.8 strengthens the post-generation recovery path used when Flow closes
        the editor/page target during download.  We reconnect to the bound
        project URL, re-locate the newest asset using the same preferred
        signature/baseline that were captured before the original download
        attempt, and retry a small bounded number of times.
        """
        last_err = None
        tries = max(1, int(attempts or 1))
        for _ in range(tries):
            if not self.recover_browser(project, project_url=project_url):
                last_err = FlowBrowserClosedError(
                    'Could not rebuild Flow browser session after generation completed')
                continue
            b = self._ensure()
            try:
                b.ensure_project(project, project_url=project_url)
                # A thumbnail URL can rotate across browser sessions. Re-bind
                # the saved exact prompt before downloading; the old URL alone
                # is not a durable asset identifier.
                if str(out_path).lower().endswith(('.jpg', '.jpeg', '.png')):
                    journal = out_path + '.flow-request.json'
                    if os.path.isfile(journal):
                        with open(journal, encoding='utf-8') as handle:
                            request = json.load(handle)
                        assets = b.media_assets()
                        if preferred_signature and not any(media_signature_matches(a.get('sig', ''), preferred_signature) for a in assets):
                            request['signature'] = ''
                            signature = self._identify_single_fresh_asset(b, request, 'image', timeout_ms=15000)
                            self._save_request(out_path, request)
                            if not signature:
                                raise FlowRequestPending('Reopened project has no exact prompt-bound image match; original request retained, no generation submitted')
                            request['signature'] = signature
                            self._save_request(out_path, request)
                            preferred_signature = signature
                return b.download_latest_asset(
                    out_path,
                    preferred_signature=preferred_signature,
                    before_signatures=before_signatures,
                )
            except FlowBrowserClosedError as e:
                last_err = e
                time.sleep(1)
                continue
        if last_err is not None:
            raise last_err
        raise FlowBrowserClosedError('Could not rebuild Flow browser session after generation completed')

    def rescue_recent_project_video(self, project: str, out_path: str,
                                    project_url: str | None = None,
                                    max_candidates: int = 8,
                                    wait_s: int = 0,
                                    baseline_signatures: set[str] | None = None,
                                    deadline_ts: float | None = None) -> dict | None:
        """Wait for/download an already-submitted Flow video without re-generating.

        v5.3.3 makes this a *project-page poll*, not an editor-click loop.  We
        require a live canonical Flow browser page before sleeping, never probe
        poster images as if they might be videos, and share one absolute deadline
        across the whole recovery call.  This prevents the old behaviour where
        the terminal printed a 179s wait while the browser was actually gone.
        """
        started_at = time.time()
        deadline = float(deadline_ts) if deadline_ts else started_at + max(0, int(wait_s or 0))
        baseline = set(baseline_signatures if baseline_signatures is not None
                       else (self._last_video_baseline or set()))
        announced = False
        tried_at: dict[str, float] = {}
        last_heartbeat = 0.0
        consecutive_reopen_failures = 0

        while True:
            now = time.time()
            if now >= deadline:
                return None

            b = self._ensure_live_recovery_project(project, project_url=project_url)
            if b is None:
                consecutive_reopen_failures += 1
                if consecutive_reopen_failures >= 3:
                    print("[Flow] Recovery aborted: could not reopen a live Flow project page after 3 attempts.")
                    return None
                time.sleep(min(5, max(1, deadline - time.time())))
                continue
            consecutive_reopen_failures = 0

            try:
                assets = b.media_assets()
            except FlowBrowserClosedError:
                # Do not silently sleep against a dead page. The next iteration
                # must visibly reopen/recover the canonical project page first.
                self.recover_browser(project, project_url=project_url)
                continue
            except Exception:
                assets = []

            fresh = [a for a in assets if str(a.get("sig", "") or "") and
                     (not baseline or not any(media_signature_matches(a.get('sig'), old, ignore_kind=True) for old in baseline))]
            pool = fresh if fresh else ([] if baseline else assets)
            explicit_video = [a for a in pool if str(a.get("kind", "")).lower() == "video"]

            # Crucial v5.3.3 change: never click an untyped/image poster during
            # recovery. Opening those cards is what repeatedly drove Flow into
            # /edit/, closed targets, and produced hundreds of return-to-project
            # messages. Wait until Flow exposes an actual playable video tile.
            for a in list(reversed(explicit_video))[:max(1, int(max_candidates or 1))]:
                sig = str(a.get("sig", "") or "")
                if not sig:
                    continue
                if sig in tried_at and time.time() - tried_at[sig] < 20:
                    continue
                tried_at[sig] = time.time()
                try:
                    if os.path.exists(out_path):
                        os.remove(out_path)
                except Exception:
                    pass
                try:
                    b.download_latest_asset(out_path, preferred_signature=sig,
                                            before_signatures=(baseline or None))
                except FlowBrowserClosedError:
                    self.recover_browser(project, project_url=project_url)
                    continue
                except Exception:
                    continue
                if self._is_valid_video_file(out_path):
                    print("[Flow] Recovered the already-generated video from the Flow project; no new generation was submitted.")
                    return {"path": out_path, "provider": "flow", "model": "project-recovery",
                            "credits": -1, "dry_run": False,
                            "project_url": self.current_project_url(),
                            "log": "flow project video recovery"}
                try:
                    if os.path.exists(out_path):
                        os.remove(out_path)
                except Exception:
                    pass

            now = time.time()
            remaining = max(0, int(deadline - now))
            if not announced:
                print(f"[Flow] Existing video request may still be rendering; waiting up to {remaining}s for the already-generated video before any retry...")
                announced = True
            if now - last_heartbeat >= 15:
                try:
                    url = str(getattr(b._page, "url", "") or "")
                except Exception:
                    url = "(unavailable)"
                print(f"[Flow] Recovery heartbeat: browser=live project={FlowBrowser.normalize_project_url(url) or url} fresh_media={len(fresh)} video_tiles={len(explicit_video)} remaining={remaining}s")
                last_heartbeat = now

            # Wait only on a confirmed live page. If it dies during this sleep the
            # next loop reopens it instead of silently burning the timeout.
            sleep_s = min(5.0, max(0.2, deadline - time.time()))
            try:
                b._page.wait_for_timeout(int(sleep_s * 1000))
            except Exception:
                self.recover_browser(project, project_url=project_url)


    MODEL_LABELS = {
        "omni_draft": "Gemini Omni Flash 360p",
        "omni_standard": "Gemini Omni Flash 720p",
        "veo_lite": "Veo 3.1 - Lite",
        "veo_fast": "Veo 3.1 - Fast",
        "veo_quality": "Veo 3.1 - Quality",
    }

    @staticmethod
    def _save_request(out_path, data):
        target = out_path + ".flow-request.json"
        os.makedirs(os.path.dirname(os.path.abspath(target)), exist_ok=True)
        with open(target + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(target + ".tmp", target)

    def _record_submission(self, out_path, project_url, baseline, kind, **evidence):
        request = {
            "status": "pending", "kind": kind, "project_url": project_url,
            "baseline": sorted(baseline), "signature": "", "submitted_at": time.time(),
            "request_hash": getattr(self, "_active_request_hash", ""),
            **evidence,
        }
        if request.get("request_marker"):
            request["request_marker_context_sha256"] = self._request_marker_context(request)
        self._save_request(out_path, request)

    def recover_recorded_video(self, project, out_path, request_path, *, project_url,
                               wait_s=120, asset_url=''):
        """Download only this shot's journal or an explicitly reviewed editor URL."""
        with open(request_path, encoding='utf-8') as handle:
            request = json.load(handle)
        if (request.get('kind') != 'video'
                or FlowBrowser.normalize_project_url(request.get('project_url')) != FlowBrowser.normalize_project_url(project_url)):
            raise ValueError('The saved video request does not belong to this Flow project')
        b = self._ensure()
        b.ensure_project(project, project_url=project_url)
        if asset_url:
            b.download_reviewed_editor_video(asset_url, out_path, project_url)
            request['operator_selected_asset_url'] = asset_url
            request['operator_selection_at'] = time.time()
        else:
            self._discard_wrong_kind_signature(request, 'video')
            signature = request.get('signature')
            if signature and any(media_signature_matches(signature, old, ignore_kind=True)
                                 for old in request.get('baseline', [])):
                request.setdefault('rejected_signatures', []).append(signature)
                request['signature_rejection_reason'] = 'Recorded video identity existed before this request'
                request['signature'] = signature = ''
                self._save_request(str(request_path)[:-len('.flow-request.json')], request)
            if signature and not any(media_signature_matches(signature, a.get('sig'))
                                     for a in b.media_assets()):
                signature = self._reidentify_exact_video(b, request)
            if not signature:
                signature = self._identify_single_fresh_asset(b, request, 'video',
                    timeout_ms=max(0, int(wait_s)) * 1000)
            if not signature:
                self._save_recovery_diagnostic(out_path, request, b.media_assets(), 'No unique fresh video')
                raise FlowUIChanged('No unique completed video matches the request. Review the exact editor URL or export support diagnostics')
            request['signature'] = signature
            b.download_latest_asset(out_path, preferred_signature=signature,
                before_signatures=set(request.get('baseline') or []))
        if not self._is_valid_video_file(out_path):
            raise FlowUIChanged('Downloaded media is not a valid time-based video; request stays unresolved')
        original = str(request_path)[:-len('.flow-request.json')]
        request['recovery_download_path'] = out_path
        self._save_request(original, request)
        return {'path': out_path, 'project_url': project_url, 'credits': 0}

    def _record_asset(self, out_path, signature):
        with open(out_path + ".flow-request.json", encoding="utf-8") as f:
            request = json.load(f)
        request["signature"] = str(signature or "")
        self._save_request(out_path, request)
        # Flow Agent can rewrite the creative brief. Preserve the prompt attached
        # to the asset identified during the original generation, before download.
        # This is evidence from that generation, not a similarity-based guess.
        bridge = getattr(self, "bridge", None)
        if request.get("kind") == "image" and signature and bridge is not None:
            read = getattr(bridge, "read_asset_generation_prompt", None)
            if callable(read):
                actual = read(signature)
                if actual:
                    request["verified_prompt_binding"] = self._make_prompt_binding(
                        request, actual, "observed_original_generation")
                    self._save_request(out_path, request)

    @staticmethod
    def _make_prompt_binding(request, prompt, source):
        normalized = FlowBrowser.normalize_generation_prompt
        return {
            "request_hash": request.get("request_hash"),
            "project_url": FlowBrowser.normalize_project_url(request.get("project_url")),
            "submitted_prompt_sha256": hashlib.sha256(normalized(request.get("submitted_prompt")).encode()).hexdigest(),
            "prompt": prompt,
            "prompt_sha256": hashlib.sha256(normalized(prompt).encode()).hexdigest(),
            "source": source, "bound_at": time.time(),
        }

    @staticmethod
    def _bound_recovery_prompt(request):
        binding = request.get("verified_prompt_binding")
        if not isinstance(binding, dict) or request.get("kind") != "image":
            return None
        if (not request.get("request_hash") or
                binding.get("request_hash") != request.get("request_hash") or
                not binding.get("project_url") or
                binding.get("project_url") != FlowBrowser.normalize_project_url(request.get("project_url"))):
            return None
        digest = lambda value: hashlib.sha256(FlowBrowser.normalize_generation_prompt(value).encode()).hexdigest()
        prompt = binding.get("prompt")
        if (not prompt or binding.get("submitted_prompt_sha256") != digest(request.get("submitted_prompt")) or
                binding.get("prompt_sha256") != digest(prompt)):
            return None
        return prompt

    def _record_queue_observation(self, out_path, elapsed_s: float = 0):
        """Persist that Flow exposed an accepted queue card for this request."""
        journal = out_path + ".flow-request.json"
        try:
            with open(journal, encoding="utf-8") as handle:
                request = json.load(handle)
            request["queue_detected"] = True
            request["last_queue_observed_at"] = time.time()
            request["queue_wait_elapsed_s"] = max(
                int(request.get("queue_wait_elapsed_s", 0) or 0), int(elapsed_s or 0))
            self._save_request(out_path, request)
        except (OSError, ValueError, TypeError):
            # A missing journal is not permission to resubmit; the outer request
            # guard will report the unresolved provider result independently.
            return

    def _asset_valid(self, path, kind):
        if kind == "video":
            return self._is_valid_video_file(path)
        try:
            from PIL import Image
            with Image.open(path) as im:
                im.verify()
            return True
        except Exception:
            return False

    @staticmethod
    def _fresh_asset_candidates(assets, baseline, kind=None):
        """Return distinct post-baseline assets using Flow's strict URL identity."""
        baseline = list(baseline or [])
        candidates = []
        for asset in assets or []:
            signature = asset.get("sig")
            if (not signature or (kind and str(asset.get("kind", "")).lower() != kind)
                    or any(media_signature_matches(signature, old, ignore_kind=(kind == "video")) for old in baseline)):
                continue
            if not any(media_signature_matches(signature, item.get("sig")) for item in candidates):
                candidates.append(asset)
        return candidates

    @staticmethod
    def _discard_wrong_kind_signature(request, requested_kind):
        """Retain but disqualify a journal signature whose typed kind cannot match the request."""
        signature = str(request.get("signature") or "")
        recorded_kind = media_signature_kind(signature)
        requested_kind = str(requested_kind or "").strip().lower()
        if (requested_kind == "video" and signature and any(
                media_signature_matches(signature, old, ignore_kind=True)
                for old in request.get("baseline", []))):
            request.setdefault("rejected_signatures", []).append(signature)
            request["signature"] = ""
            request["signature_rejection_reason"] = "Recorded video identity existed before this request"
            return "preexisting_video"
        if not signature or not recorded_kind or recorded_kind == requested_kind:
            return None
        rejected = list(request.get("rejected_signatures") or [])
        if signature not in rejected:
            rejected.append(signature)
        request["rejected_signatures"] = rejected[-8:]
        request["signature"] = ""
        request["signature_kind_rejected"] = recorded_kind
        request["signature_rejection_reason"] = (
            f"saved {recorded_kind} signature cannot satisfy requested {requested_kind}")
        return recorded_kind

    @staticmethod
    def _request_marker_context(request):
        value=[request.get('kind'),request.get('request_hash'),
               FlowBrowser.normalize_project_url(request.get('project_url')),
               FlowBrowser.normalize_generation_prompt(request.get('submitted_prompt')),
               request.get('request_marker')]
        return hashlib.sha256(json.dumps(value,ensure_ascii=False).encode()).hexdigest()

    @staticmethod
    def _verified_request_marker(request):
        """Accept only a persisted label derived from this exact image request."""
        key=str(request.get('request_hash') or '')
        marker=str(request.get('request_marker') or '')
        if (request.get('kind') != 'image' or not re.fullmatch(r'[0-9a-f]{64}',key)
                or not re.fullmatch(r'AVREQ_[0-9a-f]{24}',marker) or not request.get('project_url')):
            return None
        proof=request.get('request_marker_context_sha256')
        if proof:
            if proof != FlowBrowserProvider._request_marker_context(request):return None
        elif marker != 'AVREQ_'+key[:24]:
            return None  # Compatibility for the v7.0.12 deterministic labels only.
        labels=re.findall(r'(?<![A-Za-z0-9_])AVREQ_[0-9a-f]{24}(?![A-Za-z0-9_])',str(request.get('submitted_prompt') or ''))
        return marker if set(labels)=={marker} else None

    @classmethod
    def _matches_request_marker(cls,request,prompt):
        marker=cls._verified_request_marker(request)
        labels=re.findall(r'(?<![A-Za-z0-9_])AVREQ_[0-9a-f]{24}(?![A-Za-z0-9_])',str(prompt or ''))
        return bool(marker and set(labels)=={marker})

    def _identify_single_fresh_asset(self, bridge, request, kind, timeout_ms=15000, *, fresh_only=False):
        """Recover by saved identity or exact reused prompt; never tile order."""
        baseline = request.get("baseline") or []
        if isinstance(baseline, str):
            baseline = [baseline]
        deadline = time.monotonic() + max(0, int(timeout_ms)) / 1000.0
        checked = set()
        unreadable = set()
        prompt_evidence = {e.get('asset_fingerprint'):e for e in request.get('prompt_candidate_evidence',[]) if e.get('asset_fingerprint')}
        while True:
            assets = bridge.media_assets()
            candidates = self._fresh_asset_candidates(assets, baseline, kind=kind)
            request["correlation_probe"] = {
                "gallery_assets": len(assets), "fresh_candidates": len(candidates),
                "readable_prompts": len(checked), "unreadable_prompts": len(unreadable)}
            if kind == "video" and len(candidates) > 1:
                # Multiple results require exact saved-prompt evidence. Never
                # choose a video's tile order or an image creative-brief match.
                expected_video = request.get("submitted_prompt")
                verified_video = []
                for asset in candidates[:50]:
                    sig = str(asset.get("sig") or "")
                    actual = bridge.read_asset_generation_prompt(sig) if expected_video else None
                    if actual is None:
                        unreadable.add(sig)
                    else:
                        checked.add(sig)
                        unreadable.discard(sig)
                        if FlowBrowser.same_generation_prompt(actual, expected_video):
                            verified_video.append(sig)
                request["correlation_probe"].update(
                    readable_prompts=len(checked), unreadable_prompts=len(unreadable))
                if len(verified_video) == 1:
                    request["correlation_method"] = "unique_exact_saved_video_prompt"
                    request["correlation_at"] = time.time()
                    return verified_video[0]
            expected = request.get("submitted_prompt") if kind == "image" else None
            bound_prompt = self._bound_recovery_prompt(request) if kind == "image" else None
            marker = self._verified_request_marker(request) if kind == 'image' else None
            if (bound_prompt or marker) and not fresh_only:
                candidates = self._fresh_asset_candidates(assets, [], kind=kind)
            if kind != "image" and len(candidates) == 1 and not bound_prompt and not marker:
                return str(candidates[0].get("sig") or "")
            if (expected or bound_prompt or marker) and hasattr(bridge, "read_asset_generation_prompt"):
                verified = []
                marker_matches = {}
                gallery_key=hashlib.sha256(json.dumps([a.get('sig') for a in candidates]).encode()).hexdigest()
                cursor=int(request.get('prompt_scan_cursor',0) or 0)
                cursor=cursor % max(1,len(candidates))
                ordered=candidates[cursor:]+candidates[:cursor]
                batch=ordered[:12]
                request['prompt_scan_gallery']=gallery_key
                for index,asset in enumerate(batch):
                    if timeout_ms>0 and index and time.monotonic()>=deadline:break
                    request['prompt_scan_cursor']=(cursor+index+1) % max(1,len(candidates))
                    sig = str(asset.get("sig") or "")
                    if sig in checked:
                        continue
                    actual = bridge.read_asset_generation_prompt(sig)
                    if actual is not None:
                        checked.add(sig)
                        unreadable.discard(sig)
                        fingerprint=hashlib.sha256(sig.encode()).hexdigest()
                        prompt_evidence[fingerprint] = {
                            "asset_fingerprint": fingerprint,
                            "prompt": str(actual)[:6000]}
                        request["prompt_candidate_evidence"] = list(prompt_evidence.values())[-120:]
                    else:
                        unreadable.add(sig)
                    if actual and self._matches_request_marker(request,actual):
                        marker_matches[sig]=actual
                        verified.append(sig)
                    elif actual and (FlowBrowser.same_image_generation_prompt(actual, expected) or
                                   (bound_prompt and FlowBrowser.same_generation_prompt(actual, bound_prompt))):
                        verified.append(sig)
                if verified:
                    # Identical creative instruction variants are interchangeable
                    # for this frame request. Persist proof before download; normal
                    # image validation/continuity checks still apply afterwards.
                    chosen = sorted(marker_matches or verified)[0]
                    if chosen in marker_matches:
                        request['verified_prompt_binding']=self._make_prompt_binding(request,marker_matches[chosen],'exact_request_marker')
                    request["correlation_method"] = ("exact_request_marker" if chosen in marker_matches else
                                                      "exact_bound_reused_prompt" if bound_prompt else "exact_reused_prompt")
                    request["verified_prompt_sha256"] = hashlib.sha256(
                        FlowBrowser.normalize_generation_prompt(expected).encode()).hexdigest()
                    request["verified_scene_sha256"] = hashlib.sha256(
                        FlowBrowser.normalize_generation_prompt(
                            FlowBrowser.image_creative_brief(expected) or expected).encode()).hexdigest()
                    request["verified_equivalent_assets"] = len(verified)
                    request["correlation_at"] = time.time()
                    print(f"[Flow] Verified {len(verified)} image candidate(s) against the saved exact generation prompt; recovering without a new generation.")
                    return chosen
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                request["correlation_probe"].update(
                    readable_prompts=len(checked), unreadable_prompts=len(unreadable))
                print(f"[Flow] Exact {kind} recovery scan: {len(assets)} gallery assets, "
                      f"{len(candidates)} fresh candidates, {len(checked)} readable prompts, "
                      f"{len(unreadable)} unavailable prompt controls; no verified match.")
                return ""
            bridge._page.wait_for_timeout(min(500, max(50, int(remaining * 1000))))

    def _reidentify_exact_video(self, bridge, request):
        """A rotated thumbnail may be rebound only to a unique exact saved prompt."""
        expected = request.get('submitted_prompt')
        if not expected or FlowBrowser.normalize_project_url(bridge.current_project_url()) != request.get('project_url'):
            return ''
        matches = []
        for asset in self._fresh_asset_candidates(bridge.media_assets(), request.get('baseline', []), 'video')[:50]:
            actual = bridge.read_asset_generation_prompt(asset['sig'])
            if actual and FlowBrowser.same_generation_prompt(actual, expected):
                matches.append(asset['sig'])
        return matches[0] if len(matches) == 1 else ''

    def _guarded_generation(self, shot, compiled, refs, out_path, vertical, dry_run, kind):
        if kind != "image" or dry_run:
            return self._guarded_generation_once(shot, compiled, refs, out_path, vertical, dry_run, kind)
        from engine.flow_image_replacement import replace_image
        if os.path.isfile(out_path + '.image-replacement.json'):
            return replace_image(self,shot,compiled,out_path,vertical)
        # Retry the durable journal, not submission. Existing jobs inherit this
        # recovery policy. Legacy replacement reservations remain protected.
        archive = out_path + ".flow-request.before-regeneration.json"
        if os.path.exists(archive) and not os.path.exists(out_path + ".flow-request.json"):
            raise FlowRequestPending("Image replacement was reserved but submission is uncertain; automatic regeneration blocked. Inspect the saved replacement record.")
        transaction_journal = out_path + '.flow-request.json'
        saved_scope = None
        if os.path.isfile(transaction_journal):
            try:
                with open(transaction_journal, encoding='utf-8') as handle:
                    saved_scope = json.load(handle).get('scope')
            except (OSError, ValueError, AttributeError) as error:
                raise FlowRequestPending('Image journal is unreadable; no new generation allowed') from error
        if not os.path.exists(transaction_journal) or saved_scope == 'isolated_image_v1':
            # The transaction owns its three reconnect attempts. Do not multiply
            # that budget by the legacy outer recovery loop.
            try:
                return self._guarded_generation_once(shot, compiled, refs, out_path, vertical, False, kind)
            except FlowRequestPending as error:
                if (compiled.get('flow_replace_unresolved_images') and os.path.isfile(transaction_journal)
                        and json.loads(Path(transaction_journal).read_text()).get('phase') == 'submitted'):
                    return replace_image(self, shot, compiled, out_path, vertical, pending_error=error)
                raise
        attempts = 3 if compiled.get("flow_image_auto_recover", True) else 0
        last = None
        unverifiable_gallery = False
        for attempt in range(attempts + 1):
            try:
                return self._guarded_generation_once(shot, compiled, refs, out_path, vertical, False, kind)
            except FlowRequestPending as exc:
                last = exc
                if attempt == attempts:
                    break
                print(f"[Flow] Automatic image download recovery {attempt + 1}/{attempts}; no new generation.")
                try:
                    with open(out_path + ".flow-request.json", encoding="utf-8") as f:
                        request = json.load(f)
                    if not request.get("project_url"):
                        break
                    # A visible gallery with unreadable prompt controls cannot be
                    # correlated safely by rescanning the same tiles. Stop this
                    # automatic retry episode, retain the original journal, and
                    # require a later assisted review; never silently substitute.
                    probe = request.get("correlation_probe") or {}
                    if (int(probe.get("fresh_candidates", 0) or 0) > 0
                            and int(probe.get("unreadable_prompts", 0) or 0) > 0
                            and int(probe.get("readable_prompts", 0) or 0) == 0):
                        unverifiable_gallery = True
                        print("[Flow] Gallery has generated image candidates but prompt controls are unreadable. "
                              "Stopping redundant automatic rescans; request remains pending for assisted review.")
                        break
                    if FlowBrowser._looks_like_browser_closed_error(exc):
                        if not self.recover_browser(compiled.get("project") or "AutoVideoAI",
                                                    project_url=request["project_url"]):
                            break
                    else:
                        # Wrapped failures can omit the original close marker.
                        # Inspect the actual page before another bounded scan.
                        bridge = getattr(self, 'bridge', None)
                        page = getattr(bridge, '_page', None)
                        if page is not None and callable(getattr(page, 'is_closed', None)) and page.is_closed():
                            if not self.recover_browser(compiled.get('project') or 'AutoVideoAI',
                                                        project_url=request['project_url']):break
                    # download_latest_asset now polls the live project for this
                    # exact signature; do not burn a blind delay between scans.
                    print("[Flow] Will rescan the saved project for the exact signature (or one unique fresh image if the signature is blank); no prompt will be submitted.")
                except Exception:
                    pass
        # A visible/virtualized gallery cannot prove that a submitted request
        # failed. Even two unchanged scans can miss a late asset. Keep the
        # original journal: automatic replacement created duplicate candidates.
        if attempts == 3 and compiled.get('flow_replace_unresolved_images') and not unverifiable_gallery:
            print('[Flow] Three image recovery retries exhausted. Applying saved permission for ONE replacement image; original journal retained.')
            return replace_image(self,shot,compiled,out_path,vertical,pending_error=last)
        print("[Flow] Image request retained for download-only recovery; gallery absence does not authorize another generation.")
        raise last

    def _guarded_generation_once(self, shot, compiled, refs, out_path, vertical, dry_run, kind):
        generate_once = self._generate_video_once if kind == "video" else self._generate_image_once
        args = (shot, compiled, refs, out_path, vertical) if kind == "video" else (shot, compiled, out_path, vertical)
        if dry_run:
            return generate_once(*args, dry_run=True)
        request_identity = [kind, str(getattr(shot, "shot_id", "")),
                            compiled.get("prompt", ""), vertical]
        flow_video_mode = str(compiled.get("flow_video_mode", "frames") or "frames").lower()
        # Preserve the v6.0.14 fingerprint for the default continuity-frame mode
        # so existing pending requests can still Resume. Prompt-only requests get
        # a distinct journal identity and cannot be confused with frame-guided work.
        if kind == "video" and flow_video_mode not in ("", "frames"):
            request_identity.append(f"flow_video_mode:{flow_video_mode}")
        key = hashlib.sha256(json.dumps(request_identity, sort_keys=True).encode()).hexdigest()
        self._active_request_hash = key
        journal = out_path + ".flow-request.json"
        if kind == "image":
            fallback_archives = glob.glob(out_path + ".flow-request.fallback*.json")
            if fallback_archives:
                if self._asset_valid(out_path, kind):
                    return {"path": out_path, "provider": "image", "model": "free_fallback",
                            "credits": 0, "log": "Using the committed free fallback for an abandoned Flow request"}
                raise FlowRequestPending(
                    "A prior Flow request was abandoned for a free image fallback, but the fallback file is missing; "
                    "restore or recreate the local image instead of submitting another Flow prompt")
        try:
            if kind == "image":
                from engine.flow_image_transaction import generate, SCOPE
                saved = {}
                if os.path.exists(journal):
                    with open(journal, encoding="utf-8") as f:
                        saved = json.load(f)
                if not saved or saved.get("scope") == SCOPE:
                    return generate(self, shot, compiled, out_path, vertical, key)
            if os.path.exists(journal):
                with open(journal, encoding="utf-8") as f:
                    request = json.load(f)
                if request.get("request_hash") != key or request.get("kind") != kind:
                    raise FlowRequestPending("Recorded Flow request differs from this prompt; review the request record before replacing anything")
                bound = FlowBrowser.normalize_project_url(compiled.get("project_url"))
                if bound and request.get("project_url") and bound != request["project_url"]:
                    raise FlowRequestPending("Recorded request belongs to a different Flow project; restore its project binding")
                if kind == "image" and not self._bound_recovery_prompt(request):
                    from engine.flow_reviewed_legacy import reviewed_legacy_prompt
                    reviewed_prompt = reviewed_legacy_prompt(request)
                    if reviewed_prompt:
                        backup = journal + ".before-reviewed-binding.json"
                        if not os.path.exists(backup):
                            with open(backup, "xb") as handle:
                                with open(journal, "rb") as original_handle:
                                    handle.write(original_handle.read())
                                handle.flush()
                                os.fsync(handle.fileno())
                        request["verified_prompt_binding"] = self._make_prompt_binding(
                            request, reviewed_prompt, "reviewed_support_report_20261006_shot004")
                        request["signature"] = ""
                        self._save_request(out_path, request)
                        print("[Flow] Applied the reviewed legacy shot-4 prompt binding; recovering the exact gallery prompt without generation.")
                if not self._asset_valid(out_path, kind):
                    b = self._ensure()
                    url = request.get("project_url")
                    if not url:
                        raise FlowRequestPending("Request has no saved project URL; use assisted recovery, not regeneration")
                    print(f"[Flow] Download-only recovery of pending {kind}; no new prompt will be submitted: {url}")
                    b.ensure_project(compiled.get("project") or "AutoVideoAI", project_url=url)
                    try:
                        current_assets = b.media_assets()
                    except AttributeError:
                        # Compatibility for older bridge adapters that can still
                        # download a recorded exact signature but expose no gallery
                        # scanner. They cannot classify a queue card, so never infer
                        # an asset from DOM order or invent a replacement request.
                        current_assets = None
                    fresh_assets = (self._fresh_asset_candidates(
                        current_assets, request.get("baseline") or [])
                        if current_assets is not None else [])
                    queued_fresh = [a for a in fresh_assets
                                    if str(a.get("kind", "")).lower() == "pending"]
                    ready_fresh_videos = [a for a in fresh_assets
                                          if str(a.get("kind", "")).lower() == "video"]
                    if kind == "video" and queued_fresh and not ready_fresh_videos:
                        old_signature = str(request.get("signature") or "")
                        if old_signature:
                            rejected = list(request.get("rejected_signatures") or [])
                            if old_signature not in rejected:
                                rejected.append(old_signature)
                            request["rejected_signatures"] = rejected[-8:]
                            request["signature"] = ""
                            request["signature_kind_rejected"] = "queued-thumbnail"
                            request["signature_rejection_reason"] = (
                                "saved video fingerprint now resolves to an accepted-but-queued Flow card")
                        request["queue_detected"] = True
                        request["last_queue_observed_at"] = time.time()
                        self._save_request(out_path, request)
                        print("[Flow] This saved video request is still queued in Flow; its thumbnail is not downloadable media. "
                              "No Generate action will be resubmitted.")
                    rejected_kind = self._discard_wrong_kind_signature(request, kind)
                    if rejected_kind:
                        self._save_request(out_path, request)
                        print(f"[Flow] Rejected the saved {rejected_kind} signature for this {kind} request; scanning only for one unique fresh {kind} asset. No generation will be submitted.")
                    bound_prompt = self._bound_recovery_prompt(request) if kind == "image" else None
                    if kind == "image" and request.get("signature") and request.get("submitted_prompt"):
                        actual = (b.read_asset_generation_prompt(request["signature"])
                                  if hasattr(b, "read_asset_generation_prompt") else None)
                        if not (self._matches_request_marker(request, actual) or
                                FlowBrowser.same_image_generation_prompt(actual, request["submitted_prompt"]) or
                                (bound_prompt and FlowBrowser.same_generation_prompt(actual, bound_prompt))):
                            request.setdefault("rejected_signatures", []).append(request["signature"])
                            request["signature"] = ""
                            self._save_request(out_path, request)
                    if bound_prompt and request.get("signature"):
                        actual = b.read_asset_generation_prompt(request["signature"])
                        if not FlowBrowser.same_generation_prompt(actual, bound_prompt):
                            # Thumbnail URLs may rotate after reopening Flow. A
                            # recorded, scoped prompt lets us safely re-identify
                            # the asset; never substitute by position or title.
                            request["signature"] = ""
                            self._save_request(out_path, request)
                            print("[Flow] Saved image fingerprint is stale or no longer verified; rescanning the exact bound Flow prompt without generation.")
                    if kind == "image" and not request.get("submitted_prompt"):
                        still = compiled.get("prompt", "") + " Ultra detailed still frame, sharp focus, professional photography."
                        request["submitted_prompt"] = FlowBrowser._agent_image_instruction(
                            still, "9:16" if vertical else "16:9", 1)
                        request["prompt_correlation_legacy"] = True
                    if not request.get("signature"):
                        request["signature"] = self._identify_single_fresh_asset(
                            b, request, kind, timeout_ms=int(compiled.get("flow_image_signature_wait_ms", 15000)))
                        if not request["signature"]:
                            self._save_request(out_path, request)
                            if kind == "video" and queued_fresh:
                                raise FlowRequestPending(
                                    "Flow accepted this video request but still shows only its high-demand queue card; "
                                    "there is no completed downloadable video yet. The exact request is saved. Wait for Flow to finish, "
                                    "then Resume this same job; do not click Generate again.")
                            raise FlowRequestPending(
                                "Existing request still has no single identifiable asset after bounded gallery scans; "
                                "no recovery click submitted")
                        self._save_request(out_path, request)
                    if not request.get("signature"):
                        raise FlowRequestPending("No unambiguous recorded asset; assisted recovery is required")
                    try:
                        b.download_latest_asset(out_path, preferred_signature=request["signature"],
                                                 before_signatures=set(request.get("baseline", [])))
                    except FlowUIChanged as error:
                        assets = b.media_assets()
                        # Keep full evidence locally; only a concise reason goes into runtime logs.
                        self._save_recovery_diagnostic(out_path, request, assets, str(error))
                        exact = self._reidentify_exact_video(b, request) if kind == 'video' else ''
                        if not exact:
                            raise
                        request['previous_signature'] = request['signature']
                        request['signature'] = exact
                        request['correlation_method'] = 'exact_saved_video_prompt'
                        self._save_request(out_path, request)
                        b.download_latest_asset(out_path, preferred_signature=exact,
                                                before_signatures=set(request.get('baseline', [])))
                if not self._asset_valid(out_path, kind):
                    raise FlowRequestPending("Recovered file did not pass media validation")
                request["status"] = "downloaded"
                self._save_request(out_path, request)
                return {"path": out_path, "provider": "flow", "model": getattr(shot, "model", "imagen_flow"),
                        "credits": 0, "project_url": request.get("project_url"),
                        "log": "Recovered recorded Flow request; no new generation"}
            result = generate_once(*args, dry_run=False)
            if os.path.exists(journal):
                if not result.get("path") or not self._asset_valid(out_path, kind):
                    detail = str(result.get("error") or result.get("log") or "").strip()
                    detail = f"; Flow adapter reported: {detail[:360]}" if detail else ""
                    raise FlowRequestPending(
                        f"Submitted Flow request has no validated local {kind} asset{detail}")
                with open(journal, encoding="utf-8") as f:
                    request = json.load(f)
                request["status"] = "downloaded"
                self._save_request(out_path, request)
            return result
        except Exception as exc:
            if os.path.exists(journal):
                # Initial post-submission failures previously advertised a
                # recovery.json that only a later resume attempt would create.
                # Capture evidence now without opening/restarting a browser.
                diagnostic = out_path + ".recovery.json"
                try:
                    self._record_failure_diagnostic(out_path, exc)
                except Exception as diagnostic_error:
                    print(f"[Flow] Could not save recovery diagnostic: {type(diagnostic_error).__name__}; request retained")
                details = (f"Recovery details: {diagnostic}. " if os.path.isfile(diagnostic)
                           else "Recovery diagnostic unavailable; inspect pause_state.json and the saved request. ")
                if kind == "video":
                    guidance = ("Resume/recover this exact video with download-only recovery. "
                                "Do not manually associate a different MP4 or click Generate again.")
                else:
                    guidance = ("Resume/recover this exact image using its recorded media signature; "
                                "do not substitute a different image file.")
                raise FlowRequestPending(
                    f"Flow {kind} request is saved at {journal}. Generation is blocked to avoid spending again. "
                    f"{guidance} {details}Cause: {type(exc).__name__}: {str(exc)[:360]}") from exc
            raise

    def _record_failure_diagnostic(self, out_path, error):
        with open(out_path + ".flow-request.json", encoding="utf-8") as handle:
            request = json.load(handle)
        assets, available, source, scan_error = [], False, "unavailable", ""
        bridge = getattr(self, "bridge", None)
        if bridge is not None:
            try:
                assets = bridge.media_assets()
                available, source = True, "current_page"
            except Exception as exc:
                scan_error = type(exc).__name__
        if not available and os.path.isfile(out_path + ".recovery.json"):
            try:
                with open(out_path + ".recovery.json", encoding="utf-8") as handle:
                    previous = json.load(handle)
                if previous.get("expected_signature") == request.get("signature"):
                    assets = previous.get("visible_assets") or []
                    source = "previous_diagnostic"  # Explicitly mark stale snapshots.
            except (OSError, ValueError):
                pass
        self._save_recovery_diagnostic(
            out_path, request, assets, f"{type(error).__name__}: {error}",
            visible_assets_available=available, asset_snapshot_source=source, asset_scan_error=scan_error)

    def generate(self, shot, compiled, refs, out_path, vertical, dry_run=False):
        return self._guarded_generation(shot, compiled, refs, out_path, vertical, dry_run, "video")

    @staticmethod
    def _save_recovery_diagnostic(out_path, request, assets, reason, **context):
        target = out_path + ".recovery.json"
        with open(target + ".tmp", "w", encoding="utf-8") as handle:
            json.dump({'kind': request.get('kind'), 'expected_signature': request.get('signature'),
                       'project_url': request.get('project_url'), 'visible_assets': assets,
                       'reason': reason, 'observed_at': time.time(), 'diagnostic_only': True,
                       'correlation_probe': request.get('correlation_probe'),
                       'prompt_candidate_evidence': request.get('prompt_candidate_evidence', []),
                       'submission_journal_present': True, 'new_generations': 0, **context}, handle, indent=2)
        os.replace(target + ".tmp", target)

    def generate_image(self, shot, compiled, out_path, vertical, dry_run=False):
        return self._guarded_generation(shot, compiled, {}, out_path, vertical, dry_run, "image")

    def _generate_video_once(self, shot, compiled: dict, refs: dict, out_path: str,
                 vertical: bool, dry_run: bool = False) -> dict:
        try:
            return self._generate_video_body(shot, compiled, refs, out_path, vertical, dry_run)
        finally:
            # Approval clicks are valid only while this request is awaiting one.
            self._set_awaiting(None)

    def _submission_gate(self, out_path: str):
        """v7.0.71: refuse before any browser action if this take may already have been sent."""
        from ..flow_submit_guard import SubmissionBlocked, gate
        try:
            return gate(out_path)
        except SubmissionBlocked as error:
            raise FlowRequestPending(f"Flow video submission blocked, no prompt sent: {error}") from error

    def _chat_duplicate_gate(self, bridge, instruction: str, job_ledger=None, prompt_sha: str = ""):
        """v7.0.71: an unexplained identical prompt in the Flow chat blocks a send.

        Sibling takes of one shot legitimately share a prompt, so when this job's
        ledger already records that prompt the exact ledgers decide. Otherwise a
        prompt already visible in the chat is treated as a possible prior send.
        """
        state_fn = getattr(bridge, "agent_submission_state", None)
        if not callable(state_fn) or not instruction:
            return
        if job_ledger and prompt_sha:
            from ..flow_submit_guard import read_events
            if any(e.get("event") == "intent" and e.get("prompt_sha256") == prompt_sha
                   for e in read_events(job_ledger)):
                return
        try:
            occurrences = int((state_fn(instruction) or {}).get("prompt_occurrences", 0) or 0)
        except Exception:
            occurrences = 0
        if occurrences > 0:
            raise FlowRequestPending(
                "Flow video submission blocked: this exact prompt is already in the Flow chat "
                f"({occurrences}x). No prompt was sent; inspect the saved request instead of repeating it.")

    def _record_intent(self, out_path: str, job_ledger, **fields) -> str:
        from ..flow_submit_guard import SubmissionBlocked, record_intent
        try:
            request_id = record_intent(out_path, job_ledger, **fields)
        except SubmissionBlocked as error:
            raise FlowRequestPending(f"Flow video submission blocked, no prompt sent: {error}") from error
        self._set_awaiting(request_id)
        return request_id

    def _set_awaiting(self, request_id) -> None:
        """Mark the in-flight request on this provider and on its live bridge.

        ``_ensure()`` returns a separate bridge instance, and the approval click
        runs on that bridge, so the marker must be visible there.
        """
        self._awaiting_request_id = request_id
        bridge = getattr(self, "bridge", None)
        if bridge is not None and bridge is not self:
            bridge._awaiting_request_id = request_id

    def _record_submitted(self, out_path: str, job_ledger, request_id: str) -> None:
        from ..flow_submit_guard import record
        try:
            record(out_path, job_ledger, "submitted", request_id=request_id)
        except OSError as error:
            print(f"[Flow] Could not write the submission ledger ({type(error).__name__}); the saved request journal still blocks resubmission.")

    def _generate_video_body(self, shot, compiled: dict, refs: dict, out_path: str,
                 vertical: bool, dry_run: bool = False) -> dict:
        if dry_run:
            return {"path": None, "provider": "flow", "model": shot.model, "seed": None,
                    "credits": 0, "dry_run": True,
                    "log": f"DRY RUN: would generate {shot.shot_id} via Flow/{shot.model} (no credits)"}
        job_ledger = self._submission_gate(out_path)
        b = self._ensure()
        project = (compiled.get("project") or "AutoVideoAI").strip() or "AutoVideoAI"
        project_url = FlowBrowser.normalize_project_url(compiled.get("project_url"))
        aspect = "9:16" if vertical else "16:9"
        model_label = self.MODEL_LABELS.get(shot.model, "Gemini Omni Flash 360p")
        duration = int(shot.gen_duration or 8)
        flow_video_mode = str(compiled.get("flow_video_mode", "frames") or "frames").lower()
        if flow_video_mode == "prompt":
            # Use a pure prompt-to-video clip when requested. Storyboard stills
            # remain available to the image-motion fallback and final QC, but are
            # not attached to this Flow video request.
            refs = {}
            print("[Flow] Prompt-only video mode selected; no storyboard/master images will be attached.")
        approval = str(compiled.get("approval", "once") or "once")
        cap = compiled.get("max_generation_credits", 10)
        recovery_wait_s = max(0, int(compiled.get("flow_video_recovery_wait_seconds", 180) or 0))
        try:
            if compiled.get("flow_dedicated_video_project") and not project_url:
                # Do not allow ensure_project() to silently reuse the stills composer.
                # Never create a new project when an unresolved request exists: the
                # guarded-generation journal recovery owns that request.
                previous = FlowBrowser.normalize_project_url(b.current_project_url())
                b.create_project(project)
                if not b._composer_visible(20000):
                    raise FlowUIChanged("New dedicated video project has no composer")
                project_url = FlowBrowser.normalize_project_url(b.current_project_url())
                stills = FlowBrowser.normalize_project_url(compiled.get("flow_stills_project_url"))
                if not project_url or project_url in (previous, stills):
                    raise FlowUIChanged("Dedicated video project was not created; refusing to use image gallery")
                from ..flow_project_isolation import persist_project_binding
                binding = compiled.get("flow_video_project_binding_path")
                if binding:
                    persist_project_binding(binding, project_url, "video", compiled.get("flow_job_id", ""))
                compiled["project_url"] = project_url
            try:
                b.ensure_project(project, project_url=project_url)
            except TypeError:  # older bridge/test compatibility
                b.ensure_project(project)
            try:
                project_url = b.current_project_url() or project_url
            except Exception:
                pass
            if compiled.get("flow_dedicated_video_project"):
                from ..flow_project_isolation import assert_project_binding
                assert_project_binding(project_url, b.current_project_url(), "video")
                stills = FlowBrowser.normalize_project_url(compiled.get("flow_stills_project_url"))
                if stills and project_url == stills:
                    raise FlowUIChanged("Video project matches still-image project")

            # A factory retry re-enters generate(). Before submitting another
            # credit-bearing request, perform one short final scan for the video
            # produced by the immediately previous request for this same shot.
            if (self._last_video_shot_id == getattr(shot, "shot_id", "")
                    and self._last_video_request_at > 0
                    and time.time() - self._last_video_request_at < 15 * 60):
                pre_retry_wait = min(30, recovery_wait_s)
                if pre_retry_wait > 0:
                    print(f"[Flow] Retry guard: checking the existing project for up to {pre_retry_wait}s before submitting another video request...")
                    rescued = self.rescue_recent_project_video(
                        project, out_path, project_url=project_url, max_candidates=8,
                        wait_s=pre_retry_wait, baseline_signatures=self._last_video_baseline)
                    if rescued and rescued.get("path"):
                        self._last_video_shot_id = ""
                        return rescued

            if not hasattr(b, "prepare_text_video"):
                # Compatibility with older/mock bridge implementations.
                has_frames = bool(refs.get("start"))
                b.select_video_mode("frames" if has_frames else "text")
                b.select_model(model_label)
                b.set_aspect_ratio(aspect)
                b.set_duration(duration)
                if refs.get("start"):
                    try: b.set_first_frame(refs["start"])
                    except Exception: b.upload_reference(refs["start"])
                if refs.get("end"):
                    try: b.set_last_frame(refs["end"])
                    except Exception: pass
                request_id = self._record_intent(out_path, job_ledger, shot_id=str(getattr(shot, "shot_id", "")),
                                                 strategy="compat")
                b.submit_prompt(compiled.get("prompt", shot.visual_goal))
                self._record_submitted(out_path, job_ledger, request_id)
                if not b.wait_for_generation():
                    return {"path": None, "provider": "flow", "model": shot.model, "error": "generation failed/rejected in Flow"}
                b.download_generation(0, out_path)
                return {"path": out_path, "provider": "flow", "model": shot.model, "credits": -1, "dry_run": False}
            strategy = b.prepare_text_video(aspect=aspect, model_label=model_label,
                                            duration=duration, count=1)
            prompt = compiled.get("prompt", shot.visual_goal)

            if strategy == "agent":
                attach, labels = video_reference_plan(compiled, refs)
                if attach:
                    attached = b.attach_agent_media(attach, reuse_existing=bool(compiled.get("flow_reuse_project_media", True)))
                    if attached != len(attach):
                        raise FlowReferenceUnavailable("Required video references could not all attach; no video generation submitted")
                    prompt = labels + " " + prompt
                # Snapshot *after* reference thumbnails are attached. Otherwise
                # those thumbnails look like newly generated media and can make
                # the Agent wait return early before a video exists.
                before_assets = b.media_asset_signatures()
                self._last_video_baseline = set(before_assets)
                self._last_video_project_url = str(project_url or b.current_project_url() or "")
                self._last_video_request_at = time.time()
                self._last_video_shot_id = str(getattr(shot, "shot_id", "") or "")
                b.fill_text_video_prompt(prompt, strategy, aspect=aspect,
                                         model_label=model_label, duration=duration, count=1)
                instruction = FlowBrowser._agent_video_instruction(prompt, aspect, model_label, duration, 1)
                instruction_sha = hashlib.sha256(instruction.encode("utf-8")).hexdigest()
                self._chat_duplicate_gate(b, instruction, job_ledger, instruction_sha)
                # Ledger intent first: a refused intent must never overwrite a saved request.
                request_id = self._record_intent(out_path, job_ledger, shot_id=str(getattr(shot, "shot_id", "")),
                                                 strategy=strategy, prompt_sha256=instruction_sha)
                self._record_submission(out_path, project_url, before_assets, "video",
                    submitted_prompt=instruction)
                b.submit_prepared_text_video(strategy)
                self._record_submitted(out_path, job_ledger, request_id)
                # First-use projects can take noticeably longer to display the
                # one-time credit approval card. Give the initial card a fair
                # window; wait_for_agent_generation also keeps probing safely.
                b._approval_journal = out_path + '.flow-request.json'
                b._approval_card_limit = int(compiled.get('flow_approval_cards', 1))
                clicked = b.confirm_agent_generation(timeout_s=30, approval=approval,
                                                       max_credits=int(cap) if cap is not None else None)
                info = getattr(b, "last_agent_confirmation", {}) or {}
                if info.get("blocked"):
                    return {"path": None, "provider": "flow", "model": shot.model,
                            "credits": 0, "dry_run": False,
                            "error": f"Flow credit confirmation blocked: {info.get('reason')}"}
                # clicked can be False when Flow is configured not to ask.
                if not b.wait_for_agent_generation(
                        before_assets=before_assets,
                        service_busy_wait_s=compiled.get("flow_capacity_wait_seconds"),
                        service_busy_retries=compiled.get("flow_capacity_retries"),
                        required_kind="video",
                        video_ready_grace_s=compiled.get("flow_video_ready_grace_seconds", 20),
                        approval=approval,
                        max_generation_credits=int(cap) if cap is not None else None):
                    info = getattr(b, "last_agent_confirmation", {}) or info
                    if getattr(b, "last_agent_queue_observed", False):
                        elapsed = int(getattr(b, "last_agent_queue_elapsed_s", 0) or 0)
                        self._record_queue_observation(out_path, elapsed)
                        error = (
                            "Flow accepted the video request and showed a high-demand queue card "
                            f"during the bounded wait (last observed interval {elapsed}s), but no completed "
                            "playable/downloadable video became available. No download was attempted and "
                            "no replacement generation was submitted; the exact request remains saved "
                            "for Resume after Flow finishes."
                        )
                    else:
                        marker = getattr(b, 'last_agent_failure', '')
                        error = 'Flow Agent generation did not reach a detectable completed asset' + (
                            f'; failure marker: {marker}' if marker else '; bounded wait ended without a typed completed video')
                    return {"path": None, "provider": "flow", "model": shot.model,
                            "credits": info.get("cost", 0) or 0, "dry_run": False,
                            "error": error}
                # A late first-project approval may have been clicked inside the
                # generation wait. Preserve its cost/action in the result.
                info = getattr(b, "last_agent_confirmation", {}) or info
                try:
                    reserved = json.loads(Path(out_path+'.flow-request.json').read_text()).get('approval_credit_total_reserved')
                    if reserved is not None: info['cost'] = reserved
                except (OSError, ValueError): pass
                # One recovery budget per submitted request. Older builds could
                # enter two or three separate 179s recovery loops here (and the
                # factory added another), turning a 3-minute setting into tens of
                # minutes while sometimes no browser page was alive.
                recovery_deadline = time.time() + recovery_wait_s
                download_error = None
                self._record_asset(out_path, b.last_generated_asset_signature)
                try:
                    b.download_latest_asset(out_path,
                                            preferred_signature=b.last_generated_asset_signature,
                                            before_signatures=before_assets)
                except Exception as e:
                    download_error = e

                if not self._is_valid_video_file(out_path):
                    try:
                        if os.path.exists(out_path):
                            os.remove(out_path)
                    except Exception:
                        pass
                    rescued = None
                    if recovery_wait_s > 0:
                        rescued = self.rescue_recent_project_video(
                            project, out_path, project_url=project_url, max_candidates=8,
                            wait_s=recovery_wait_s, baseline_signatures=before_assets,
                            deadline_ts=recovery_deadline)
                    if not rescued:
                        detail = f": {str(download_error)[:160]}" if download_error else ""
                        return {"path": None, "provider": "flow", "model": shot.model,
                                "credits": info.get("cost", 0) or 0, "dry_run": False,
                                "error": "Flow produced media but no valid time-based video became downloadable within the single recovery window" + detail}
                self._last_video_shot_id = ""
                observed_cost = info.get("cost")
                if not observed_cost:
                    observed_cost = -1  # factory records configured model estimate when Flow did not expose cost
                return {"path": out_path, "provider": "flow", "model": shot.model,
                        "seed": None, "credits": observed_cost, "dry_run": False,
                        "project_url": b.current_project_url(),
                        "log": f"flow-agent ok ({info.get('clicked') or 'no-confirmation'})"}

            # Standard/legacy editor. References are added best-effort; if the
            # migrated UI changes, the economy profile will fall back to images.
            if refs.get("start"):
                try:
                    b.set_first_frame(refs["start"])
                except FlowUIChanged:
                    try: b.upload_reference(refs["start"])
                    except Exception: pass
            elif refs.get("storyboard") or refs.get("character"):
                try: b.upload_reference(refs.get("storyboard") or refs["character"])
                except Exception: pass
            if refs.get("end"):
                try: b.set_last_frame(refs["end"])
                except FlowUIChanged: pass
            b.fill_text_video_prompt(prompt, strategy, aspect=aspect,
                                     model_label=model_label, duration=duration, count=1)
            try:
                standard_baseline = set(b.media_asset_signatures())
            except Exception:
                standard_baseline = set()
            self._last_video_baseline = standard_baseline
            self._last_video_project_url = str(project_url or b.current_project_url() or "")
            request_id = self._record_intent(out_path, job_ledger, shot_id=str(getattr(shot, "shot_id", "")),
                                             strategy=strategy,
                                             prompt_sha256=hashlib.sha256(str(prompt).encode("utf-8")).hexdigest())
            self._record_submission(out_path, project_url, standard_baseline, "video",
                                    submitted_prompt=prompt)
            b.submit_prepared_text_video(strategy)
            self._record_submitted(out_path, job_ledger, request_id)
            ok = b.wait_for_generation()
            if not ok:
                return {"path": None, "provider": "flow", "model": shot.model, "seed": None,
                        "credits": 0, "dry_run": False, "error": "generation failed/rejected in Flow"}
            b.download_generation(0, out_path)
            return {"path": out_path, "provider": "flow", "model": shot.model,
                    "seed": None, "credits": -1, "dry_run": False, "log": "flow standard ok"}
        except (FlowUIChanged, FlowAuthNeeded, FlowQuotaExceeded, FlowServiceBusy, FlowBrowserClosedError) as e:
            try:
                snap = b.snapshot_failure(project, shot.shot_id, e)
            except Exception:
                snap = ""
            if snap:
                raise type(e)(f"{e} [snapshot: {snap}]")
            raise
        except Exception as e:
            try:
                b.snapshot_failure(project, shot.shot_id, e)
            except Exception:
                pass
            return {"path": None, "provider": "flow", "model": shot.model, "seed": None,
                    "credits": 0, "dry_run": False, "error": str(e)[:300]}

    def _generate_image_once(self, shot, compiled: dict, out_path: str,
                       vertical: bool, dry_run: bool = False) -> dict:
        if dry_run:
            return {"path": None, "provider": "flow", "model": "imagen_flow",
                    "dry_run": True, "log": f"DRY RUN: would generate image for {shot.shot_id}"}
        b = self._ensure()
        project = (compiled.get("project") or "AutoVideoAI").strip() or "AutoVideoAI"
        project_url = FlowBrowser.normalize_project_url(compiled.get("project_url"))
        aspect = "9:16" if vertical else "16:9"
        try:
            if compiled.get('flow_replacement_request') and not project_url:
                # A different logical name alone does not isolate a request:
                # ensure_project normally reuses any open composer. Only a NEW
                # reserved replacement goes home first. Journaled child requests
                # always keep their exact persisted project for download recovery.
                b._page.goto(b.ui.get('url', 'https://flow.google.com/'),
                             wait_until='domcontentloaded', timeout=20000)
                b._project_ready = None
                b._project_url = None
            try:
                b.ensure_project(project, project_url=project_url)
            except TypeError:  # older bridge/test compatibility
                b.ensure_project(project)
            try:
                project_url = b.current_project_url() or project_url
            except Exception:
                pass
            still = (compiled.get("prompt", "") +
                     " Ultra detailed still frame, sharp focus, professional photography.")
            mode = b.detect_editor_mode()
            if compiled.get('flow_replacement_request') and mode != 'agent':
                raise FlowUIChanged('Bounded image replacement requires the journaled Flow Agent editor; no prompt submitted')
            if mode == "agent":
                b.select_agent_generation_type("image")
                reference_paths = compiled.get("reference_paths") or []
                if reference_paths and b.attach_agent_media(reference_paths, reuse_existing=True) != len(reference_paths):
                    raise FlowReferenceUnavailable("Image worker could not attach all master references; generation not submitted")
                before_assets = b.media_asset_signatures()
                if any("character-" in os.path.basename(p) for p in reference_paths):
                    still = "Use the attached original character photos as the identity authority; preserve their faces instead of inventing a description-based lookalike. " + still
                from engine.flow_reference_policy import compact_photo_brief
                still = compact_photo_brief(compiled.get("prompt", ""), reference_paths) + " Ultra detailed still frame, sharp focus, professional photography."
                marker = "AVREQ_" + secrets.token_hex(12)
                # Build the full instruction first; never cut a character/scene
                # mid-sentence. The saved request records exactly what is sent.
                envelope = b._agent_image_instruction(still, aspect, 1)
                instruction = f"Request tracking label {marker}; metadata only, never draw or write it in the image. " + envelope
                if len(instruction) > 4000 or not envelope.endswith(still.strip()):
                    raise FlowUIChanged("Flow image brief exceeds 4000 characters. Shorten the character description or use a saved character photo; no prompt submitted.")
                b._fill_editor_box("agent_prompt_box", instruction)
                self._record_submission(out_path, project_url, before_assets, "image",
                                        submitted_prompt=instruction, request_marker=marker)
                with open(out_path + ".flow-request.json", encoding="utf-8") as handle:
                    image_request = json.load(handle)
                b.submit_prepared_text_video("agent")  # same Agent send action; instruction says STILL IMAGE
                if not b.wait_for_agent_generation(
                        before_assets=before_assets, timeout_s=360,
                        service_busy_wait_s=compiled.get("flow_capacity_wait_seconds"),
                        service_busy_retries=compiled.get("flow_capacity_retries"), required_kind="image",
                        approval=compiled.get('approval','once'),max_generation_credits=compiled.get('max_generation_credits',0),
                        image_request=image_request):
                    return {"path": None, "provider": "flow", "model": "imagen_flow",
                            "error": "Flow Agent image generation did not reach a detectable completed asset"}
                image_request["signature"] = b.last_generated_asset_signature
                self._save_request(out_path, image_request)
                try:
                    b.download_latest_asset(out_path,
                                            preferred_signature=b.last_generated_asset_signature,
                                            before_signatures=before_assets)
                except FlowBrowserClosedError:
                    # The image already exists in Flow. Reconnect to the exact
                    # persisted project instead of creating a date-stamped project.
                    self._download_after_browser_recovery(project, out_path, project_url=project_url,
                        preferred_signature=b.last_generated_asset_signature,
                        before_signatures=before_assets, attempts=1)
                from engine.flow_reference_validation import quarantine_reference_copy
                if quarantine_reference_copy(out_path, reference_paths):
                    raise FlowRequestPending('Downloaded image was an uploaded reference copy; journal retained for exact request recovery')
                return {"path": out_path, "provider": "flow", "model": "imagen_flow",
                        "dry_run": False, "credits": 0, "project_url": b.current_project_url(),
                        "log": "flow-agent image ok"}

            try:
                b.select_image_mode()
                b.set_aspect_ratio(aspect)
            except FlowUIChanged:
                pass
            b.submit_image_prompt(still)
            if not b.wait_for_image():
                return {"path": None, "provider": "flow", "model": "imagen_flow",
                        "error": "image generation failed/rejected in Flow"}
            b.download_image(0, out_path)
            return {"path": out_path, "provider": "flow", "model": "imagen_flow",
                    "dry_run": False, "credits": 0, "log": "flow image ok"}
        except (FlowUIChanged, FlowAuthNeeded, FlowQuotaExceeded,
                FlowServiceBusy, FlowBrowserClosedError) as e:
            try:
                snap = b.snapshot_failure(project, shot.shot_id, e)
            except Exception:
                snap = ""
            if snap:
                raise type(e)(f"{e} [snapshot: {snap}]")
            raise

    def close(self):
        if self.bridge:
            self.bridge.close()
            self.bridge = None

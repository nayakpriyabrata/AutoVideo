# AutoVideo 7.0.87: automatic resume after an interrupted Flow image download

## What was wrong

Job `20261024-101502-7-small-daily-habits-tha-debf` stopped with "automatic pause is disabled" after
`shot_006` failed. The log showed `FlowBrowserClosedError: Image download target closed` on every
download attempt, and each time the browser target closed about two seconds after the download event.
Auto-resume never started, for three reasons:

1. **The retry decision looked at the wrong error.** The image recovery wraps the browser-closed error in
   `FlowRequestPending("Image recovery checkpoint retained: ...")`. The strict frame failure treated every
   `FlowRequestPending` as final, so the job failed immediately.
2. **A blocked saved request was never retried.** Even after a retry, `run_job` reconciled the saved
   request, found the download still interrupted, and stopped with "Saved request unresolved". That stop was
   not recorded as recoverable, so the Studio supervisor never picked the job up.
3. **Manual runs did not record the wait.** `cli.py v3 resume` and the automation helpers called `run_job`
   directly. Only the Studio job thread recorded the stop, so a manual run could never hand over to the
   supervisor.

## What changed

- **Download-only retry.** A saved image whose download was interrupted (browser closed, network, or service
  busy) is retried automatically. The retry only reopens the exact saved project, waits, and downloads. It
  never uploads, fills, or sends a prompt, and never spends credits.
- **Blocked but recoverable requests wait.** When the only blocker is such a download interruption, the job
  records an automatic-resume wait and returns `paused`. Studio's supervisor retries it with backoff
  (2, 5, 10, 20, 30, 60 minutes, up to 8 automatic resumes), while Studio is running and the computer is awake.
- **Unchanged protections.** A submitted request whose download is unknown still stops for a manual decision.
  Sign-in, quota, approval and missing-file stops are never retried. A pending request with no recoverable
  cause still stops with no wait.
- **Every caller records the outcome.** The CLI create and resume commands and the automation helpers call
  the same recording step as the Studio job thread.
- **Diagnostic.** The "Image download target closed" message now includes the download URL scheme
  (`https`, `blob`, `data`, `other`, or `unavailable`). It never shows the URL. The scheme shows why the HTTPS
  fallback could not run. Please send it with the next runtime log.

## Still open

- The download target closes right after the download event. The cause is not confirmed. The scheme
  diagnostic will show whether the browser hands over a `blob:` URL, which the HTTPS fallback cannot read.
- The storyboard scan also treats temporary `*.probe-*.jpg` download files as frames. A probe that matches a
  reference image is quarantined, which is correct. The behaviour is noisy but not the cause of this failure.
- Video recovery has the same wrapper pattern but is not covered by this automatic retry. The change is limited
  to image downloads.

## For the failed job (20261024-101502-7-small-daily-habits-tha-debf)

Nothing needs to change in the job. Its saved request is download-only. Either run
`python3 cli.py v3 resume 20261024-101502-7-small-daily-habits-tha-debf` once Chrome is open and Flow is signed in,
or keep Studio open and let the automatic resume run.

## Upgrade

From a 7.0.86 installation, run `python3 ../AutoVideoAI-v7.0.87/tools/update_v786_to_v787.py .` for a dry run,
then add `--apply`. Stop the dashboard first. Chunk size for Gemini TTS remains 2400 characters by default.

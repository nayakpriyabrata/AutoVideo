"""Version 7 content discovery, metadata packets, and approval integrity."""
from pathlib import Path
from types import SimpleNamespace

import pytest

from engine import publishing


def test_all_requested_editorial_areas_have_specific_guardrails():
    from engine.mini_reels import CONTENT_CATEGORIES

    labels = {item["label"] for item in CONTENT_CATEGORIES.values()}
    for expected in (
        "AI & content creation", "Learning & explainers", "Self-care & wellbeing",
        "Personality development", "Investment & money education", "Health & fitness",
        "Cooking & food", "Business ideas", "Motivation", "Devotional & cultural stories",
        "Original cartoons", "Kids’ stories", "Farming & gardening",
    ):
        assert expected in labels
    assert "guaranteed returns" in CONTENT_CATEGORIES["investment"]["guidance"]
    assert "pesticide" in CONTENT_CATEGORIES["farming_gardening"]["guidance"]


def test_metadata_normalization_keeps_indic_copy_and_rejects_unsafe_source_links():
    metadata, title = publishing._normalize_post_metadata(
        title="ଓଡ଼ିଆ ଗାର୍ଡେନ୍ ଟିପ୍ସ", caption="ପ୍ରତିଦିନ ଗଛକୁ ଦେଖନ୍ତୁ।\x00",
        hashtags="#Odia #ଗାର୍ଡେନ୍ #odia", chapters="00:00 ପରିଚୟ\n01:15 ଉଦାହରଣ",
        source_urls=["https://factozone.com/garden/"], category="gardening")
    assert title.startswith("ଓଡ଼ିଆ")
    assert "\x00" not in metadata["caption"]
    assert metadata["hashtags"] == ["#Odia", "#ଗାର୍ଡେନ୍"]
    assert metadata["source_urls"] == ["https://factozone.com/garden/"]
    assert "01:15" in metadata["chapters"]
    with pytest.raises(ValueError, match="public HTTPS URLs"):
        publishing._normalize_post_metadata(source_urls=["http://localhost/private"])
    with pytest.raises(ValueError, match="public HTTPS URLs"):
        publishing._normalize_post_metadata(source_urls=["https://127.0.0.1/private"])


def test_export_creates_manual_upload_packet_and_metadata_is_approval_locked(tmp_path, monkeypatch):
    import engine.delivery_duplicates as _dd; monkeypatch.setattr(_dd,'check',lambda *a,**k:{'blocked':[],'warnings':[],'skipped':[]})  # fake encoder; guard covered in test_v768_delivery_duplicates
    source = tmp_path / "master.mp4"
    source.write_bytes(b"original master video")
    import engine.render.ffmpeg_renderer as renderer

    monkeypatch.setattr(renderer, "ffmpeg_exe", lambda: "ffmpeg")
    monkeypatch.setattr(renderer, "_probe_av_durations", lambda _path: {"video": 8.0, "format": 8.0})

    def fake_run(command, **_kwargs):
        Path(command[-1]).write_bytes(b"encoded destination video" * 256)
        return SimpleNamespace(returncode=0, stderr="")

    monkeypatch.setattr(publishing.subprocess, "run", fake_run)
    record = publishing.export_delivery(
        source, tmp_path / "deliveries", "instagram_reel", language="or", duration=8,
        title="ଆମ ବଗିଚା", caption="ଛୋଟ ଆରମ୍ଭ, ସୁନ୍ଦର ବଗିଚା।",
        description="ଏହା ଏକ ମୂଳ ଓଡ଼ିଆ ଭିଡିଓ।", hashtags="#Odia #Garden #odia",
        source_urls=["https://factozone.com/story/"], category="farming and gardening")

    assert record["state"] == "REVIEW_REQUIRED"
    assert record["publishing_adapter"] == "manual-export"
    packet = Path(record["upload_packet"])
    packet_text = packet.read_text(encoding="utf-8")
    assert "AUTOVIDEOAI — MANUAL UPLOAD PACKET" in packet_text
    assert "ଛୋଟ ଆରମ୍ଭ" in packet_text
    assert "#Odia #Garden" in packet_text
    assert "does not log in, upload, schedule remotely" in packet_text

    release_path = Path(record["video"]).with_suffix(".release.json")
    approved = publishing.approve_release(
        release_path, account_id="instagram:creator-page", rights_confirmed=True,
        facts_reviewed=True, language_reviewed=True, made_for_kids=False,
        ai_disclosure_required=True)
    assert approved["state"] == "APPROVED_FOR_MANUAL_UPLOAD"
    assert len(approved["approval_sha256"]) == 64
    assert publishing.schedule_release(release_path, "2099-01-01T10:00:00+05:30")["state"] == "SCHEDULED_MANUAL_REMINDER"


def test_upload_packet_or_caption_edit_requires_fresh_approval(tmp_path, monkeypatch):
    import engine.delivery_duplicates as _dd; monkeypatch.setattr(_dd,'check',lambda *a,**k:{'blocked':[],'warnings':[],'skipped':[]})  # placeholder video bytes; guard covered in test_v768_delivery_duplicates
    video = tmp_path / "delivery.mp4"
    video.write_bytes(b"approved render")
    release = tmp_path / "delivery.release.json"
    import engine.production as production

    production.save(release, {
        "schema_version": 1, "id": "delivery", "video": str(video),
        "sha256": production.digest(video), "source_sha256": "source",
        "destination": "youtube_long", "language": "hi", "title": "Hindi story",
        "post_metadata": {"caption": "Original", "description": "Reviewed", "hashtags": [],
                          "chapters": "00:00 Intro", "source_urls": [], "category": "story"},
        "profile": publishing.destination_profile("youtube_long"), "duration": 60,
        "state": "REVIEW_REQUIRED", "account_id": "", "made_for_kids": None,
        "ai_disclosure_required": None, "rights_confirmed": False,
        "facts_reviewed": False, "language_reviewed": False,
    })
    publishing.approve_release(
        release, account_id="youtube:channel-1", rights_confirmed=True,
        facts_reviewed=True, language_reviewed=True, made_for_kids=False,
        ai_disclosure_required=False)

    record = production.read(release)
    record["post_metadata"]["caption"] = "Changed after approval"
    production.save(release, record)
    with pytest.raises(ValueError, match="changed after approval"):
        publishing.schedule_release(release, "2099-01-01T10:00:00+05:30")

    # Re-approval updates the packet. Editing the text packet itself is caught too.
    publishing.approve_release(
        release, account_id="youtube:channel-1", rights_confirmed=True,
        facts_reviewed=True, language_reviewed=True, made_for_kids=False,
        ai_disclosure_required=False)
    packet = Path(publishing._upload_packet_path(release))
    packet.write_text(packet.read_text(encoding="utf-8") + "\nchanged\n", encoding="utf-8")
    with pytest.raises(ValueError, match="changed after approval"):
        publishing.schedule_release(release, "2099-01-01T10:00:00+05:30")

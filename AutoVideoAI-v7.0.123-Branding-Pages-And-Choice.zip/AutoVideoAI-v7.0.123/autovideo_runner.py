#!/usr/bin/env python3
"""AutoVideoAI control-center loopback runner. Python 3.10+, standard library only.

Run in the same virtual environment as AutoVideoAI. No engine source is patched.
Only explicitly approved requests from the configured Site origin execute CLI jobs.
"""
from __future__ import annotations
import argparse
import base64
import ast
import datetime as dt
import fcntl
import hashlib
import hmac
import math
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

MODES = {"youtube", "reels", "cartoon", "clip", "mini"}
VIDEO_CHOICES = {
    "production_mode": {"youtube_pro", "reels_pro"}, "video_type": {"faceless_youtube", "shorts"},
    "theme": {"motivational", "cartoon_story", "kids_cartoon", "devotional_cartoon", "devotional_real", "cooking", "health", "personal_finance", "personality_development", "ai_learning", "self_care", "business_ideas", "farming_gardening"},
    "profile": {"STORYBOARD_ECONOMY", "FLOW_BALANCED", "FLOW_CINEMATIC", "LOCAL_FREE"},
    "script_provider": {"gemini-web", "groq", "auto", "gemini", "ollama"},
    "tts_provider": {"auto", "edge", "gemini", "kokoro", "gtts"},
    "caption_provider": {"groq", "auto", "local", "script-timed"},
    "render_quality": {"high", "standard", "preview"}, "frame_source": {"flow", "auto", "free"},
    "flow_reuse_mode": {"exact", "topic", "project"}, "flow_approval": {"once", "manual", "always"},
    "gemini_chat_cleanup": {"keep", "delete-after-read"}, "script_quality": {"publish"},
    "caption_display": {"auto", "full", "none"}, "preset": {"cartoon_3d"},
    "language": {"en", "hi", "or"}, "text_card_style": {"auto", "bold", "playful", "clean"},
    "background_music": {"off", "local", "auto", "browser", "generated", "reliable"},
    "flow_video_mode": {"frames", "prompt"},
}
RANGES = {"gemini_video_count": (0,4), "duration": (10, 7200), "flow_scenes": (0, 100), "max_flow_scenes": (0, 100),
          "max_credits": (0, 1000), "max_generation_credits": (0, 100), "flow_approval_cards": (1, 3), "flow_image_workers": (1, 3),
          "flow_capacity_wait_seconds": (0, 3600), "flow_capacity_retries": (0, 20),
          "flow_video_ready_grace_seconds": (0, 600), "flow_video_recovery_wait_seconds": (0, 1800),
          "flow_video_retries": (0, 0), "broll_count": (0,150), "broll_max_uses": (1,3)}
BOOL_KEYS = {"speech_cards_enabled", "flow_auto_cleanup_images", "broll_auto","plan_only", "flow_reuse_project_media", "voiceover_enabled", "text_cards_enabled", "sound_effects_enabled", "ambience_enabled", "flow_pause_on_unresolved_request"}
PATH_KEYS = {"approved_plan_path", "narration_input_path", "background_music_path"}
VIDEO_KEYS = set(VIDEO_CHOICES) | set(RANGES) | BOOL_KEYS | PATH_KEYS | {"topic", "flow_project_url", "character_id", "character_ids", "broll_duration", "broll_query_hint"}
CLIP_KEYS = {"task", "segment_seconds", "transcript", "transcript_path", "captions_enabled", "background_music", "music_volume", "input", "count", "min_seconds", "max_seconds", "source_rights", "framing", "ranking_provider", "caption_provider", "language", "show_channel_logo", "channel_logo_path", "channel_logo_text", "channel_logo_palette", "channel_logo_size", "channel_logo_position"}
MINI_KEYS = {"allow_other_pending", "character_ids", "idea", "language", "visual_style", "audio_mode", "category", "model", "brief_id", "flow_prompt", "flow_project_url", "max_generation_credits", "flow_capacity_wait_seconds", "flow_capacity_retries", "flow_video_recovery_wait_seconds"}
RIGHTS = {"unknown", "own_content", "written_permission", "licensed_content", "creative_commons", "public_domain", "private_draft_only"}

def now():
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")

def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {} if default is None else default

def atomic_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)

def redact(text):
    text = re.sub(r"(?i)((?:api[_-]?key|access_token|token|signature|credential|password)\s*[=:]\s*)[^\s&\"']+", r"\1[redacted]", str(text))
    return re.sub(r"(?i)(bearer\s+)[A-Za-z0-9._-]+", r"\1[redacted]", text)

def tail(path, limit=120_000):
    try:
        with open(path, "rb") as handle:
            handle.seek(0, 2)
            size = handle.tell()
            handle.seek(max(0, size - limit))
            text = handle.read().decode("utf-8", "replace")
        if size > limit:
            text = text.split("\n", 1)[-1]
        return [redact(line) for line in text.splitlines()[-600:]]
    except OSError:
        return []

def flow_url(value):
    if not value:
        return True
    u = urlparse(value)
    return u.scheme == "https" and u.hostname in {"flow.google.com", "labs.google"} and "/project/" in u.path and not u.username and not u.password

def integer(value, low, high, name):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{name} must be a whole number between {low} and {high}.")

def validate(mode, config):
    if mode not in MODES or not isinstance(config, dict):
        raise ValueError("Choose a supported job mode and configuration.")
    keys = MINI_KEYS if mode == "mini" else CLIP_KEYS if mode == "clip" else VIDEO_KEYS
    if set(config) - keys:
        raise ValueError("Unsupported configuration fields: " + ", ".join(sorted(set(config) - keys)))
    c = dict(config)
    if mode != 'clip':
        ids=c.get('character_ids',[])
        if not isinstance(ids,list) or len(ids)>3 or len(ids)!=len(set(ids)) or any(not isinstance(i,str) or not re.fullmatch(r'[a-z0-9-]{1,80}',i) for i in ids):
            raise ValueError('Select up to three distinct saved character IDs.')
    if mode == "mini":
        if "allow_other_pending" in c and type(c["allow_other_pending"]) is not bool:
            raise ValueError("Separate pending-reel choice must be true or false")
        if not isinstance(c.get("idea"), str) or not 1 <= len(c["idea"].strip()) <= 300:
            raise ValueError("Mini Reel idea must contain 1–300 characters.")
        for key, choices in {"language": {"en", "hi", "or"}, "visual_style": {"miniature-diorama", "miniature-stop-motion", "macro-realism", "cinematic-short", "playful-3d"}, "audio_mode": {"flow-voiceover", "flow-ambience", "silent"}, "model": {"veo_lite", "veo_fast", "veo_quality"}, "category": {"general", "ai_creation", "learning", "self_care", "personality_development", "investment", "health_fitness", "cooking", "business_ideas", "motivation", "devotional", "cartoons", "kids_stories", "farming_gardening"}}.items():
            if not isinstance(c.get(key), str) or c[key] not in choices:
                raise ValueError(f"Invalid {key}.")
        for key in ("max_generation_credits", "flow_capacity_wait_seconds", "flow_capacity_retries", "flow_video_recovery_wait_seconds"):
            integer(c.get(key), *RANGES[key], key)
        if not isinstance(c.get("flow_project_url", ""), str) or not flow_url(c.get("flow_project_url", "")):
            raise ValueError("Use a valid Google Flow project URL.")
        if c.get("brief_id"):
            if not isinstance(c["brief_id"], str) or not re.fullmatch(r"run-[A-Za-z0-9_-]{8,100}", c["brief_id"]):
                raise ValueError("Choose a saved Gemini brief.")
            if not isinstance(c.get("flow_prompt"), str) or not 1 <= len(c["flow_prompt"].strip()) <= 3900:
                raise ValueError("Review a Flow prompt of 1–3900 characters.")
        return c
    if mode == "clip":
        source = c.get("input", "")
        if not isinstance(source, str) or not source.strip() or len(source) > 4000 or "\x00" in source:
            raise ValueError("A source video URL or local WSL path is required.")
        for key, bounds in {"count": (1, 20), "min_seconds": (5, 180), "max_seconds": (5, 180)}.items():
            integer(c.get(key), *bounds, key)
        if c["min_seconds"] > c["max_seconds"]:
            raise ValueError("Minimum clip length cannot exceed maximum.")
        for key, choices in {"source_rights": RIGHTS, "framing": {"face-crop", "fit"},
                             "ranking_provider": {"auto", "gemini-hybrid", "gemini-web-hybrid", "local"},
                             "caption_provider": {"auto", "groq", "local"}}.items():
            if c.get(key) not in choices:
                raise ValueError(f"Invalid {key}.")
        if urlparse(source).scheme in {"http", "https"} and c["source_rights"] == "unknown":
            raise ValueError("Choose a source-rights declaration for URL input.")
        if type(c.get('show_channel_logo', False)) is not bool:
            raise ValueError('Show channel logo must be true or false')
        if c.get('show_channel_logo'):
            logo=c.get('channel_logo_path','')
            text=c.get('channel_logo_text','')
            if not isinstance(text,str) or len(text)>80 or any(ord(ch)<32 for ch in text):
                raise ValueError('Logo text must be up to 80 characters on one line')
            if c.get('channel_logo_palette','Ocean') not in {'Ocean','Sunset','Forest'}:
                raise ValueError('Choose a supported logo palette')
            if not text.strip() and (not isinstance(logo,str) or not logo.strip() or len(logo)>4000 or '\x00' in logo):
                raise ValueError('Choose a local channel logo image path or logo text')
            size=c.get('channel_logo_size',.12)
            if type(size) not in (int,float) or not math.isfinite(size) or not .05<=size<=.25:
                raise ValueError('Logo size must be 5–25 percent')
            if c.get('channel_logo_position','top-right') not in {'top-right','top-left','bottom-right','bottom-left'}:
                raise ValueError('Choose a logo corner')
        task=c.get('task','highlights')
        if task not in {'highlights','convert','split'}:raise ValueError('Choose a Clip Studio task')
        if type(c.get('captions_enabled',True)) is not bool:raise ValueError('Captions must be true or false')
        if c.get('transcript','none') not in {'none','automatic','reviewed'}:raise ValueError('Choose a transcript option')
        if task=='split':integer(c.get('segment_seconds',30),1,600,'Segment seconds')
        if c.get('language','en') not in {'en','hi','or'}:raise ValueError('Choose English, Hindi or Odia')
        if c.get('language')=='or' and (task=='highlights' or c.get('transcript')=='automatic') and not c.get('transcript_path'):
            raise ValueError('Clip transcription supports English and Hindi automatically. Odia needs an imported timed transcript.')
        if c.get('transcript')=='reviewed' and not c.get('transcript_path'):raise ValueError('Choose a reviewed transcript file')
        for key in ('transcript_path','background_music'):
            if key in c and (not isinstance(c[key],str) or len(c[key])>4000 or '\x00' in c[key]):raise ValueError('Invalid local file path')
        if type(c.get('music_volume',.08)) not in (int,float) or not math.isfinite(c.get('music_volume',.08)) or not 0<=c.get('music_volume',.08)<=.35:raise ValueError('Music volume must be 0–0.35')
        return c
    if not isinstance(c.get("topic"), str) or not c["topic"].strip() or len(c["topic"]) > 2000:
        raise ValueError("A topic of up to 2000 characters is required.")
    for key, bounds in RANGES.items():
        if key in c:
            integer(c[key], *bounds, key)
    for key, choices in VIDEO_CHOICES.items():
        if key in c and (not isinstance(c[key], str) or c[key] not in choices):
            raise ValueError(f"Invalid {key}.")
    for key in BOOL_KEYS:
        if key in c and type(c[key]) is not bool:
            raise ValueError(f"{key} must be true or false.")
    for key in PATH_KEYS | {"character_id"}:
        if key in c and (not isinstance(c[key], str) or len(c[key]) > 4000 or "\x00" in c[key]):
            raise ValueError(f"Invalid {key}.")
    ids=c.get('character_ids',[])
    if not isinstance(ids,list) or len(ids)>3 or any(not isinstance(i,str) or not re.fullmatch(r'[a-z0-9-]{1,80}',i) for i in ids) or len(ids)!=len(set(ids)):
        raise ValueError('Select up to three distinct saved character IDs.')
    if c.get("language") == "or" and c.get("voiceover_enabled", True) and not c.get("narration_input_path") and c.get("tts_provider", "auto") not in {"auto", "gemini"}:
        raise ValueError("Odia narration needs Gemini TTS or an imported native narration.")
    if c.get("background_music") == "local" and not c.get("background_music_path"):
        raise ValueError("Select a local music path.")
    for key in ("duration", "flow_scenes", "max_credits", "max_generation_credits", "flow_image_workers"):
        if key not in c:
            raise ValueError(f"Missing {key}.")
    if c["max_generation_credits"] > c["max_credits"]:
        raise ValueError("Per-generation cap cannot exceed total credit cap.")
    if not isinstance(c.get("flow_project_url", ""), str) or not flow_url(c.get("flow_project_url", "")):
        raise ValueError("Use a valid Google Flow project URL.")
    expected = "reels_pro" if mode == "reels" else "youtube_pro"
    if c.get("production_mode") != expected:
        raise ValueError("Job mode and production mode do not match.")
    if 'broll_duration' in c and (type(c['broll_duration']) not in (int,float) or not math.isfinite(c['broll_duration']) or not .5<=c['broll_duration']<=6):
        raise ValueError('B-roll duration must be 0.5–6 seconds')
    if 'broll_query_hint' in c and (not isinstance(c['broll_query_hint'],str) or len(c['broll_query_hint'])>500):
        raise ValueError('B-roll hint must be up to 500 characters')
    # Keep explicit control-center defaults authoritative over engine defaults.
    c.setdefault("gemini_chat_cleanup", "keep")
    c["flow_video_retries"] = 0
    c["max_flow_scenes"] = c["flow_scenes"]
    return c

class Controller:
    def __init__(self, root):
        self.root = Path(root).resolve()
        if not (self.root / "cli.py").is_file():
            raise ValueError("--root must point to an AutoVideoAI folder containing cli.py.")
        self.folder = self.root / ".autovideo-control"
        self.folder.mkdir(mode=0o700, exist_ok=True)
        self.index_path = self.folder / "jobs.json"
        self.requests_path = self.folder / "requests.json"
        self.requests = read_json(self.requests_path, {})
        self.records = read_json(self.index_path, {})
        if not isinstance(self.records, dict):
            self.records = {}
        self.lock = threading.RLock()
        self.active = None
        self.process = None
        self.version = (self.root / "VERSION").read_text().strip() if (self.root / "VERSION").exists() else "unknown"
        for r in self.records.values():
            if r.get("status") == "running":
                r["status"] = "interrupted"
                r["error"] = "The local runner was restarted. Check the engine process before resuming."
        self.save()

    def characters(self):
        root=(self.root/'data/content/characters').resolve()
        rows=[]
        for file in sorted(root.glob('*/character.json'))[:100]:
            if not file.resolve().is_relative_to(root):continue
            try:
                value=read_json(file,{})
                identifier=value.get('id','')
                if not re.fullmatch(r'[a-z0-9-]{1,80}',identifier) or identifier!=file.parent.name:continue
                preview=''
                for reference in value.get('references',[]):
                    source=Path(reference.get('path',''))
                    if not source.is_absolute():source=file.parent/source
                    if not source.is_file():source=file.parent/source.name
                    if not source.resolve().is_relative_to(file.parent.resolve()) or not source.is_file() or source.stat().st_size>1024*1024:continue
                    content=source.read_bytes()
                    if hashlib.sha256(content).hexdigest()!=reference.get('sha256'):continue
                    mime={'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'}.get(source.suffix.lower())
                    if mime:
                        # Optional Pillow from the engine keeps local card transfers small.
                        # The runner itself still works without this dependency.
                        try:
                            import io
                            from PIL import Image,ImageOps
                            with Image.open(io.BytesIO(content)) as im:
                                if im.width*im.height>25_000_000:continue
                                thumbnail=ImageOps.pad(ImageOps.exif_transpose(im).convert('RGB'),(180,180),color='#201539')
                                buffer=io.BytesIO();thumbnail.save(buffer,format='JPEG',quality=80)
                                content=buffer.getvalue();mime='image/jpeg'
                        except ImportError:
                            if len(content)>200000:continue
                        except (OSError,ValueError):continue
                        preview='data:'+mime+';base64,'+base64.b64encode(content).decode();break
                rows.append({'id':identifier,'name':str(value.get('name',identifier))[:120],'preview':preview})
            except (OSError,ValueError,TypeError):continue
        return rows

    def save(self):
        with self.lock:
            atomic_json(self.index_path, self.records)

    def engine_folder(self, engine_id):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,200}", engine_id or ""):
            raise ValueError("Invalid engine job ID.")
        base = (self.root / "outputs").resolve()
        path = (base / engine_id).resolve()
        if path.parent != base:
            raise ValueError("Invalid job path.")
        return path

    def scan(self):
        with self.lock:
            base = self.root / "outputs"
            if not base.exists():
                return
            known = {r.get("engine_id") for r in self.records.values()}
            for path in sorted(base.glob("*/production_manifest.json"), reverse=True)[:200]:
                eid = path.parent.name
                if eid in known or not re.fullmatch(r"[A-Za-z0-9_-]{1,200}", eid):
                    continue
                try:
                    folder = self.engine_folder(eid)
                except ValueError:
                    continue
                m = read_json(folder / "production_manifest.json")
                s = read_json(folder / "settings.json")
                mode = "reels" if m.get("aspect") == "9:16" else "cartoon" if "cartoon" in m.get("preset", "") else "youtube"
                self.records[eid] = {"id": eid, "engine_id": eid, "mode": mode, "title": m.get("topic", eid),
                                     "config": s, "status": "imported", "updated_at": now()}
            known_reels = {r.get("reel_id") for r in self.records.values()}
            for path in sorted((base / "mini_reels").glob("*/mini_reel.json"), reverse=True)[:200]:
                eid = path.parent.name
                if eid in known_reels or not re.fullmatch(r"[A-Za-z0-9_-]{8,80}", eid) or path.parent.is_symlink():
                    continue
                meta = read_json(path)
                rid = "mini-" + eid
                self.records[rid] = {"id": rid, "reel_id": eid, "mode": "mini", "title": meta.get("title", eid), "config": meta, "status": "interrupted", "updated_at": meta.get("updated_at", now())}
            self.save()

    def detail(self, rid, logs=True):
        with self.lock:
            if rid not in self.records:
                raise KeyError("Job not found. Refresh local jobs first.")
            r = dict(self.records[rid])
        progress, pause, manifest = {}, {}, {}
        stdout_lines = tail(self.folder / (rid + ".log"))
        lines = stdout_lines if logs else []
        folder = self.root / r["clip_output"] if r.get("clip_output") else self.root / "outputs/mini_reels" / r["reel_id"] if r.get("reel_id") else self.engine_folder(r["engine_id"]) if r.get("engine_id") else None
        if r["mode"] == "mini":
            meta = read_json(folder / "mini_reel.json") if folder else {}
            if meta:
                if meta.get("status") == "complete":
                    r["status"] = "completed"
                    progress = {"percent": 100, "stage": "Mini Reel complete · review audio and video"}
                elif meta.get("status") == "flow_request_pending":
                    r["status"] = "paused"
                    pause = {"kind": "flow_existing_video_recovery", "reason": meta.get("error", "Saved Flow request needs recovery"), "safe_automatic_recovery": (folder / "mini-reel.mp4.flow-request.json").is_file(), "flow_project_url": meta.get("flow_project_url")}
                elif meta.get("status") == "failed":
                    r["status"] = "failed"
                    r["error"] = meta.get("error", "Mini Reel failed")
            if r.get("brief") and r["status"] == "brief":
                progress = {"stage": "Gemini brief ready · review the prompt before Flow generation"}
        if folder and r["mode"] != "mini":
            progress = read_json(folder / "logs/progress.json")
            pause = read_json(folder / "pause_state.json")
            manifest = read_json(folder / "production_manifest.json")
            pending_video = []
            for shot in manifest.get('shots', []):
                sid = shot.get('shot_id', '')
                if shot.get('accepted_take') or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', sid):
                    continue
                for journal in (folder / 'flow/shots' / sid).glob('take_*.mp4.flow-request.json'):
                    request = read_json(journal)
                    if request.get('kind') == 'video':
                        pending_video.append((sid, request))
            if len(pending_video) == 1:
                sid, request = pending_video[0]
                pause = {**pause, 'shot_id': sid, 'kind': 'flow_existing_video_recovery',
                         'safe_automatic_recovery': True,
                         'reason': pause.get('reason') or 'Saved Flow video request needs exact download recovery.',
                         'flow_project_url': request.get('project_url')}
            if logs:
                # Engine file is durable across resumes; stdout retains CLI-only errors.
                runtime = tail(folder / "logs/runtime.log")
                lines = (runtime + ["[Runner stdout] " + line for line in lines[-60:]])[-700:]
            r["title"] = manifest.get("topic", r.get("title", rid))
        active = self.active == rid
        if active:
            r["status"] = "running"
            text = " ".join((progress.get("stage", ""), progress.get("info", ""))).lower()
            latest_wait = next((line for line in reversed(stdout_lines[-5:]) if re.search(r"capacity.*wait|high demand.*wait|next attempt at", line, re.I)), None)
            if latest_wait:
                text += " capacity waiting"
                progress = {**progress, "info": latest_wait, "stage": "Waiting for Flow capacity"}
            if re.search(r"capacity|waiting|high demand", text):
                r["status"] = "waiting"
        elif r["mode"] != "mini" and r.get("last_action") == "recover" and r.get("exit_code") == 0:
            r["status"] = "paused"
            recovered = pause.get("resolved") is True
            progress = {**progress, "stage": "Media recovered · resume to continue" if recovered else "Recovery did not pass engine quality checks · review diagnostics"}
            if not recovered:
                r["error"] = "Recovery exited successfully, but the engine did not accept the media. The request remains unresolved."
        elif manifest.get("status") == "done":
            r["status"] = "completed"
        elif r.get("status") == "failed":
            pass
        elif pause and not pause.get("resolved") and manifest.get("status") in {"paused", "assisted"}:
            r["status"] = "paused"
        elif r.get("status") == "imported":
            r["status"] = "failed" if manifest.get("status") == "failed" else "paused" if manifest.get("status") in {"paused", "assisted"} else "planned" if manifest.get("status") == "created" else "interrupted"
        r["percent"] = progress.get("percent", 100 if r.get("status") == "completed" else None)
        r["stage"] = progress.get("stage", "Clip processing" if active and r["mode"] == "clip" else r.get("status", "Unknown"))
        if r["mode"] == "clip" and not active and r["status"] == "completed" and folder:
            reports=sorted(folder.glob('edit-*/edits.json')) if r['config'].get('task') in {'convert','split'} else []
            report = read_json(reports[-1] if reports else folder / "highlights.json")
            if reports:
                r['stage']=report.get('summary','Local edit completed')
            if report.get("partial_result"):
                r["stage"] = report.get("summary") or f"Partial result · {report.get('actual_count', '?')}/{report.get('requested_count', '?')} clips saved"
                r["partial_result"] = True
        r["info"] = redact(progress.get("info", ""))
        r["elapsed"] = progress.get("elapsed", "")
        r["updated_at"] = progress.get("ts", r.get("updated_at"))
        r["pause"] = {k: v for k, v in pause.items() if k not in {"baseline_signatures", "actions"}}
        if r["pause"].get("reason"):
            r["pause"]["reason"] = redact(r["pause"]["reason"])
        r["logs"] = lines
        if active and not progress:
            match = re.findall(r"(?:\[|\s)(\d{1,3}(?:\.\d+)?)%", "\n".join(lines))
            if match:
                r["percent"] = min(100, float(match[-1]))
        outputs = []
        output_folder = self.root / r["clip_output"] if r.get("clip_output") else folder if r["mode"] == "mini" else folder / "render" if folder else None
        if output_folder and output_folder.exists():
            outputs = [str(p) for p in sorted(output_folder.glob("edit-*/*.mp4" if r.get("config",{}).get("task") in {"convert","split"} else "*.mp4")) if not p.name.endswith(".partial.mp4")][:1000]
        r["output_paths"] = outputs
        delivery = self.folder / "delivery" / rid
        r["delivery_paths"] = [str(p) for p in sorted(delivery.glob("*")) if p.suffix in {".mp4", ".json", ".txt"}][:30] if delivery.exists() else []
        return r

    def list_jobs(self):
        self.scan()
        with self.lock:
            ids = list(self.records)
        jobs = [self.detail(rid, logs=False) for rid in ids]
        return sorted(jobs, key=lambda j: j.get("updated_at", ""), reverse=True)

    def other_engine_running(self):
        for item in Path("/proc").glob("[0-9]*/cmdline"):
            try:
                argv = item.read_bytes().decode("utf-8", "replace").split("\0")
                if not any(Path(a).name in {"cli.py", "streamlit", "control_center_adapter.py"} for a in argv):
                    continue
                cwd = (item.parent / "cwd").resolve()
                if cwd == self.root or str(self.root / "cli.py") in argv:
                    return True
            except OSError:
                continue
        return False

    def ensure_idle(self):
        if self.active or self.other_engine_running():
            raise RuntimeError("Another engine job or Studio process is active. Finish it before starting a control-center command.")

    def start(self, mode, config):
        c = validate(mode, config)
        with self.lock:
            self.ensure_idle()
            if mode == "mini":
                if not (self.root / "tools/control_center_adapter.py").is_file():
                    raise ValueError("Install the reviewed v7.0.1 build to use Mini Reels.")
                if c.get("brief_id"):
                    rid = c["brief_id"]
                    job = self.detail(rid)
                    if job["mode"] != "mini" or job["status"] != "brief" or not job.get("brief"):
                        raise ValueError("Use a ready Gemini brief. Existing Flow requests must be recovered before changing their prompt.")
                    for key in ("idea", "language", "visual_style", "audio_mode", "category"):
                        if c[key] != job["config"][key]:
                            raise ValueError("Idea, language, style, audio or category changed. Create a new Gemini brief first.")
                    self.records[rid].update(config=c, reel_id=rid)
                    self.launch_adapter(rid, "mini-generate", {"config": c, "reel_id": rid, "brief": job["brief"]})
                    return {"id": rid}
                rid = "run-" + dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
                self.records[rid] = {"id": rid, "mode": mode, "config": c, "title": c["idea"], "status": "running", "updated_at": now()}
                self.launch_adapter(rid, "mini-brief", {"config": c})
                return {"id": rid}
            if mode != "clip":
                # Inspect accepted keys without importing the engine or loading providers.
                config_source = self.root / "engine/studio_config.py"
                if not config_source.exists():
                    raise ValueError("This runner needs the create-config workflow (tested with AutoVideoAI 7.0.1).")
                tree = ast.parse(config_source.read_text(encoding="utf-8"))
                defaults = next((ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "DEFAULTS" for t in n.targets)), {})
                if set(c) - set(defaults):
                    raise ValueError("Installed engine does not support: " + ", ".join(sorted(set(c) - set(defaults))))
            rid = "run-" + dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
            self.records[rid] = {"id": rid, "mode": mode, "config": c, "title": c.get("topic") or c["input"], "status": "running", "updated_at": now()}
            payload = dict(c)
            for key in PATH_KEYS:
                if payload.get(key):
                    path_value = (self.root / Path(payload[key]).expanduser()).resolve()
                    if not path_value.is_file():
                        self.records.pop(rid, None)
                        raise ValueError(f"{key} file not found in WSL: {path_value}")
                    payload[key] = str(path_value)
            if mode == "clip":
                payload["source"] = payload.pop("input")
                if not urlparse(payload["source"]).scheme:
                    payload["source"] = str((self.root / Path(payload["source"]).expanduser()).resolve())
                payload["output"] = "outputs/control-clips/" + rid
                payload["gemini_chat_cleanup"] = "keep"
                self.records[rid]["clip_output"] = payload["output"]
            path = self.folder / (rid + ".json")
            atomic_json(path, payload)  # JSON is accepted by the engine's YAML loader.
            args = ["clip-config" if mode == "clip" else "create-config", str(path)]
            self.launch(rid, args, "start")
            return {"id": rid}

    def submit(self, request_id, operation, arguments):
        if not isinstance(request_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{16,100}", request_id):
            raise ValueError("A valid request ID is required. Reload the control center if it is out of date.")
        digest = hashlib.sha256(json.dumps([operation, arguments], sort_keys=True).encode()).hexdigest()
        with self.lock:
            previous = self.requests.get(request_id)
            if previous:
                if previous["digest"] != digest:
                    raise ValueError("Request ID was already used for a different action.")
                return {"id": previous["id"], "deduplicated": True}
            result = self.start(*arguments) if operation == "start" else self.delivery(*arguments) if operation == "delivery" else self.action(*arguments)
            self.requests[request_id] = {"digest": digest, "id": result["id"]}
            atomic_json(self.requests_path, self.requests)
            return result

    def action(self, rid, action, options=None):
        with self.lock:
            self.ensure_idle()
            job = self.detail(rid)
            if job["mode"] == "clip":
                raise ValueError("Interrupted clips cannot fully resume in this engine version. Create a fresh clip job.")
            if job["mode"] == "mini":
                if action != "recover" or not job.get("reel_id") or not job.get("pause", {}).get("safe_automatic_recovery"):
                    raise ValueError("Review a ready brief to generate, or recover the exact pending Mini Reel request.")
                self.launch_adapter(rid, "mini-recover", {"config": job["config"], "reel_id": job["reel_id"]})
                return {"id": rid}
            eid = job.get("engine_id")
            if not eid:
                raise ValueError("The engine did not create a resumable job. Review its startup error.")
            if job["status"] == "completed":
                raise ValueError("This job is already completed.")
            if action == "recover":
                pause = job.get("pause", {})
                if not pause.get("safe_automatic_recovery") or pause.get("resolved"):
                    raise ValueError("No unresolved video request with a saved recovery baseline. Review the media-detection diagnostics instead.")
                args = ["recover-flow-video", eid, "--wait-seconds", "120"]
                if options:
                    if not isinstance(options, dict) or set(options) != {'asset_url', 'asset_reviewed'} or options.get('asset_reviewed') is not True or not isinstance(options.get('asset_url'), str):
                        raise ValueError('Review the exact video editor URL for this shot first.')
                    asset_url = options['asset_url']
                    u = urlparse(asset_url)
                    project = urlparse(pause.get('flow_project_url', ''))
                    if (u.scheme != 'https' or u.hostname not in {'flow.google.com', 'labs.google'} or u.username or u.password or u.query or u.fragment or u.port not in {None, 443}
                            or not re.fullmatch(r'/project/[A-Za-z0-9_-]+/edit/[A-Za-z0-9_-]+', u.path)
                            or u.path.split('/edit/')[0] != project.path.rstrip('/')):
                        raise ValueError('Editor URL must belong to this job’s saved Flow project.')
                    args += ['--asset-url', asset_url, '--asset-reviewed']
                shot = pause.get("shot_id")
                if shot:
                    if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", shot):
                        raise ValueError("Invalid pending shot ID.")
                    args += ["--shot-id", shot]
            elif action == "resume":
                args = ["resume", eid]
                if options:
                    if (not isinstance(options, dict) or set(options)-{'local_closing_fallback','replace_unresolved_images','image_replacement_limit'}
                            or any(type(options[k]) is not bool for k in ('local_closing_fallback','replace_unresolved_images') if k in options)):
                        raise ValueError('Invalid resume recovery options.')
                    if options.get('local_closing_fallback'):
                        version = tuple(int(n) for n in re.findall(r'\d+',self.version)[:3])
                        if version < (7, 0, 18):
                            raise ValueError('Local closing guidance requires engine v7.0.18 or newer.')
                        args += ['--local-closing-fallback']
                    if options.get('replace_unresolved_images'):
                        version = tuple(int(n) for n in re.findall(r'\d+',self.version)[:3])
                        if version < (7,0,19):
                            raise ValueError('Bounded image replacement requires engine v7.0.19 or newer.')
                        cap=options.get('image_replacement_limit',30)
                        integer(cap,1,100,'Image replacement cap')
                        args += ['--replace-unresolved-images','--image-replacement-limit',str(cap)]
            else:
                raise ValueError("Unsupported job action.")
            self.launch(rid, args, action)
            return {"id": rid}

    def delivery(self, rid, options):
        with self.lock:
            self.ensure_idle()
            job = self.detail(rid)
            if not isinstance(options, dict) or set(options) - {"index", "destination", "title", "framing"}:
                raise ValueError("Invalid delivery options.")
            integer(options.get("index"), 0, max(0, len(job["output_paths"]) - 1), "Output selection")
            if not job["output_paths"]:
                raise ValueError("This job has no local video to export.")
            if options.get("destination") not in {"youtube_long", "youtube_short", "instagram_reel", "facebook_reel"} or options.get("framing") not in {"fit", "crop"}:
                raise ValueError("Choose a supported destination and framing.")
            title = options.get("title", "")
            if not isinstance(title, str) or len(title) > 100:
                raise ValueError("Delivery title must be at most 100 characters.")
            folder = self.folder / "delivery" / rid
            args = ["export-delivery", job["output_paths"][options["index"]], "--folder", str(folder), "--destination", options["destination"], "--framing", options["framing"], "--language", job.get("config", {}).get("language", "en"), "--title", title]
            self.launch(rid, args, "delivery")
            return {"id": rid}

    def launch_adapter(self, rid, operation, payload):
        path = self.folder / (rid + "-" + operation + ".json")
        atomic_json(path, payload)
        result_path = Path(str(path) + ".result.json")
        result_path.unlink(missing_ok=True)
        self.records[rid]["adapter_result"] = str(result_path)
        self.launch(rid, [operation, str(path)], operation, adapter=True)

    def launch(self, rid, args, action, adapter=False):
        self.active = rid
        self.records[rid].update(status="running", updated_at=now(), last_action=action)
        self.records[rid].pop("error", None)
        self.save()
        threading.Thread(target=self.run, args=(rid, args, adapter), daemon=True).start()

    def run(self, rid, args, adapter=False):
        log_path = self.folder / (rid + ".log")
        try:
            env = os.environ.copy()
            env["PYTHONUNBUFFERED"] = "1"
            with log_path.open("a", encoding="utf-8") as logfile:
                logfile.write(f"[{now()}] [Runner] Explicitly approved {self.records[rid]['last_action']} command.\n")
                logfile.flush()
                command = [sys.executable, "-u", str(self.root / "tools/control_center_adapter.py"), *args] if adapter else [sys.executable, "-u", str(self.root / "cli.py"), "v3", *args]
                proc = subprocess.Popen(command, cwd=self.root, env=env,
                                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
                self.process = proc
                for line in proc.stdout:
                    logfile.write(redact(line))
                    logfile.flush()
                    match = re.match(r"JOB:\s*([A-Za-z0-9_-]+)", line)
                    if match:
                        with self.lock:
                            self.records[rid]["engine_id"] = match.group(1)
                            self.save()
                proc.stdout.close()
                code = proc.wait()
                logfile.write(f"[{now()}] [Runner] Command exited with code {code}.\n")
            with self.lock:
                r = self.records[rid]
                r["exit_code"] = code
                r["status"] = "paused" if code == 2 else "failed" if code else "planned" if r["config"].get("plan_only") else "completed" if r["mode"] == "clip" else "finished"
                if adapter and code == 0:
                    result = read_json(r["adapter_result"])
                    if r["last_action"] == "mini-brief" and result.get("brief") and result.get("flow_prompt"):
                        r.update(status="brief", brief=result["brief"], flow_prompt=result["flow_prompt"])
                    elif result.get("status") == "complete":
                        r["status"] = "completed"
                    else:
                        r.update(status="failed", error="The adapter did not return a validated result. Review the logs.")
                if code not in {0, 2}:
                    r["error"] = "Engine command failed. See the final stdout lines for the exact error."
        except Exception as e:
            with self.lock:
                self.records[rid].update(status="failed", error=redact(str(e)))
        finally:
            with self.lock:
                self.records[rid]["updated_at"] = now()
                self.active = None
                self.process = None
                self.save()

class RunnerHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

def handler(controller, origin, token):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Never print the bearer credential or user content in HTTP logs.

        def allowed_origin(self):
            host = urlparse("http://" + self.headers.get("Host", "")).hostname
            return self.headers.get("Origin") == origin and host in {"127.0.0.1", "localhost", "::1"}

        def response(self, code, data):
            body = json.dumps(data, ensure_ascii=False).encode()
            self.send_response(code)
            if self.allowed_origin():
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
                self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def auth(self):
            if not self.allowed_origin():
                self.response(403, {"error": "This origin or host is not allowed. Use the configured private Site on this PC."})
                return False
            supplied = self.headers.get("Authorization", "")
            if not hmac.compare_digest(supplied, "Bearer " + token):
                self.response(401, {"error": "Invalid runner token. Paste the token printed in WSL."})
                return False
            return True

        def do_OPTIONS(self):
            if not self.allowed_origin():
                self.response(403, {"error": "Origin not allowed."})
                return
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
            self.send_header("Vary", "Origin")
            self.end_headers()

        def do_GET(self):
            if not self.auth():
                return
            path = urlparse(self.path).path
            try:
                if path == "/api/health":
                    data = {"version": controller.version, "root": str(controller.root), "runner_version": "1.1", "active_job": controller.active}
                elif path == "/api/characters":
                    data = {"characters":controller.characters()}
                elif path == "/api/jobs":
                    data = {"jobs": controller.list_jobs()}
                elif path.startswith("/api/jobs/"):
                    data = controller.detail(unquote(path[len('/api/jobs/'):]))
                else:
                    self.response(404, {"error": "Endpoint not found."})
                    return
                self.response(200, data)
            except KeyError as e:
                self.response(404, {"error": str(e)})
            except (ValueError, OSError) as e:
                self.response(400, {"error": redact(str(e))})

        def do_POST(self):
            if not self.auth():
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 32000:
                    raise ValueError("Invalid request size.")
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict) or data.get("approved") is not True:
                    raise ValueError("Review and explicitly approve the action in the control center first.")
                path = urlparse(self.path).path
                if path == "/api/jobs":
                    result = controller.submit(data.get("request_id"), "start", [data.get("mode"), data.get("config")])
                else:
                    match = re.fullmatch(r"/api/jobs/([A-Za-z0-9_-]+)/(resume|recover|delivery)", path)
                    if not match:
                        self.response(404, {"error": "Endpoint not found."})
                        return
                    rid, operation = match.groups()
                    result = controller.submit(data.get("request_id"), "delivery", [rid, data.get("options")]) if operation == "delivery" else controller.submit(data.get("request_id"), "action", [rid, operation, data.get('options')])
                self.response(202, result)
            except RuntimeError as e:
                self.response(409, {"error": str(e)})
            except KeyError as e:
                self.response(404, {"error": str(e)})
            except (ValueError, TypeError, OSError, SyntaxError, StopIteration) as e:
                self.response(400, {"error": redact(str(e))})
    return Handler

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=".", help="Existing AutoVideoAI directory")
    parser.add_argument("--origin", required=True, help="Exact deployed private Site origin")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    u = urlparse(args.origin)
    if u.scheme not in {"https", "http"} or not u.hostname or u.path not in {"", "/"} or u.query or u.fragment or u.username or u.password:
        parser.error("--origin must be an exact Site origin with no path or credentials.")
    if u.scheme == "http" and u.hostname not in {"localhost", "127.0.0.1"}:
        parser.error("Production Site origins must use HTTPS.")
    origin = args.origin.rstrip("/")
    try:
        root = Path(args.root).resolve()
        if not (root / "cli.py").is_file():
            raise ValueError("--root must point to an AutoVideoAI folder containing cli.py.")
        folder = root / ".autovideo-control"
        folder.mkdir(mode=0o700, exist_ok=True)
        lock_handle = (folder / "runner.lock").open("w")
        fcntl.flock(lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        controller = Controller(root)
        token = secrets.token_urlsafe(32)
        server = RunnerHTTPServer(("127.0.0.1", args.port), handler(controller, origin, token))
    except (ValueError, OSError) as e:
        parser.exit(1, f"Runner could not start: {e}\n")
    print(f"AutoVideoAI {controller.version} · local control runner", flush=True)
    print(f"Site origin: {origin}\nRunner: http://127.0.0.1:{args.port}", flush=True)
    print(f"Connection token: {token}", flush=True)
    print("Keep this terminal open. No engine commands run until you approve them in the Site.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        if controller.process and controller.process.poll() is None:
            print("Stopping the runner and interrupting its active CLI job. Saved engine assets remain.", flush=True)
            controller.process.terminate()
    finally:
        server.server_close()

if __name__ == "__main__":
    main()

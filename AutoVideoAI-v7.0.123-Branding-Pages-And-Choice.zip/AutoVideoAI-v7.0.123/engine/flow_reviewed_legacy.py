"""Narrow compatibility binding for a legacy Flow request reviewed from diagnostics.

This is not fuzzy scene matching. Only the recorded request, project, legacy
marker, submitted prefix and exact reviewed gallery prompt qualify. The live
asset must still expose this exact prompt before download.
"""
import hashlib

REQUEST_HASH = '8acbc45b41414e6431dfdac90fc3ae6af6a87d14a8566f4a39b7f4cc93e8dfe4'
PROJECT = 'https://flow.google.com/project/30b788b0-6d77-4f10-874b-3ff80babd21c'
SUBMITTED_PREFIX_SHA256 = "fc314429a8bbc6f2870e154b8164f7adc5d838ff14128f48b4d6ee1320b1aca8"
REVIEWED_PROMPT = 'STORYBOARD CLOSE FRAME, vertical 9:16. Capture the natural END state immediately AFTER the described action completes. Subject: Debanshi, a young adult Indian woman with a softly rounded oval face, warm golden undertones, expressive dark brown almond-shaped eyes, and very long, thick, voluminous dark brown curly hair styled with crown volume and face-framing curls. She wears a large deep-pink fabric flower in her hair, a tiny black bindi, and large pink hoop earrings. She is in a sleeveless deep raspberry-pink dress with black floral prints. Environment: sleek tech studio, dark surfaces, soft blue accent light, laptop close by. Action context: Debanshi has just finished sharing scripts on the platform that were performed well. Framing: macro insert. Lighting: motivated natural light, soft shadows, warm highlights, gentle contrast. Look: photorealistic cinematic realism, natural skin texture, subtle film grain, warm cinematic grade, teal-shadow balance, natural saturation. Ultra detailed still frame, sharp focus, professional photography.'


def reviewed_legacy_prompt(request):
    from .providers.flow_browser import FlowBrowser
    if (request.get("kind") != "image" or request.get("status") != "pending"
            or request.get("request_hash") != REQUEST_HASH
            or FlowBrowser.normalize_project_url(request.get("project_url")) != PROJECT
            or request.get("request_marker") != "AVREQ_" + REQUEST_HASH[:24]
            or request.get("request_marker_context_sha256")
            or hashlib.sha256(str(request.get("submitted_prompt", ""))[:4000].encode()).hexdigest()
                != SUBMITTED_PREFIX_SHA256):
        return None
    # Require the evidence collected from this user's existing request. Never
    # introduce a prompt from another project's report or bind by tile order.
    if not any(FlowBrowser.same_generation_prompt(e.get("prompt"), REVIEWED_PROMPT)
               for e in request.get("prompt_candidate_evidence", []) if isinstance(e, dict)):
        return None
    return REVIEWED_PROMPT

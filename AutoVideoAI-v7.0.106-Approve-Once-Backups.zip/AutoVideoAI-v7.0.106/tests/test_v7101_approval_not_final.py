"""v7.0.101: "no approval click recorded" must not be read as "no video exists".

Field case (job 20261022-143856-7-small-daily-habits-tha-9729, 2026-10-26): the CLI approve command failed on a
job-id path, so the operator pressed Approve in the Flow UI by hand. Flow answered in the chat with

    "Your video generation has been scheduled and is waiting in the queue due to high demand."

and the clip was ready about a minute later (the thumbnail was in the project). That chat turn is a snapshot
from submit time and stays in the chat afterwards.

v7.0.99/v7.0.100 said the opposite of what was true: "no approval click is recorded ... no video exists yet and
another wait cannot find one", and v7.0.100 told the user to wait when the video was already there. These tests
pin the corrected wording: a missing click is evidence, not proof, and the free download always comes first.

No browser, no Flow request, no credits.
"""
import json

import pytest

from engine import flow_pending_approval as fpa
from engine.flow_resume_safety import FlowResumeBlocked, check_job
from tools import flow_resume_preflight as preflight

JOB = '20261022-143856-7-small-daily-habits-tha-9729'
PROJECT = 'https://flow.google.com/project/37d8cf57-12b4-4a85-9934-5580e90d3781'


def _job(tmp_path):
    job = tmp_path / JOB
    (job / 'flow' / 'shots' / 'shot_014').mkdir(parents=True)
    (job / 'production_manifest.json').write_text('{"shots": []}')
    journal = job / 'flow' / 'shots' / 'shot_014' / 'take_01.mp4.flow-request.json'
    journal.write_text(json.dumps({'kind': 'video', 'scope': 'video_flow_v1', 'phase': 'submitted',
                                   'status': 'pending', 'project_url': PROJECT}))
    journal.with_name('take_01.mp4.submit-ledger.jsonl').write_text(
        json.dumps({'event': 'submitted'}) + '\n')
    return job


def test_the_evidence_admits_a_manual_approval(tmp_path):
    row = fpa.evidence_for(_job(tmp_path) / 'flow' / 'shots' / 'shot_014' / 'take_01.mp4.flow-request.json')
    assert row['suspected_pending'] is True           # still worth saying
    assert 'waiting on its Approve/Reject card' in row['reason']
    assert 'approved directly in the browser' in row['reason']   # ... but not as a fact


def test_the_blocked_message_downloads_first_and_approves_only_if_there_is_nothing(tmp_path):
    message = str(FlowResumeBlocked(check_job(_job(tmp_path))))
    assert 'no video exists until that card is approved' in message
    assert 'If you have already approved it in the saved project' in message
    assert 'download the video first, it is free' in message
    # the approve command is still offered, just not as the only move
    assert 'approve-request' in message and 'recover-flow-video' in message
    assert message.index('approve-request') < message.index('recover-flow-video')


def test_the_preflight_says_the_click_may_be_unrecorded(tmp_path, capsys):
    argv = __import__('sys').argv
    __import__('sys').argv = ['flow_resume_preflight.py', str(_job(tmp_path))]
    try:
        assert preflight.main() == 3
    finally:
        __import__('sys').argv = argv
    printed = capsys.readouterr().out
    assert 'no approval click is recorded' in printed
    assert 'approved it in the browser yourself' in printed
    assert 'download the ' in printed and 'video first (free)' in printed


def test_a_queued_chat_note_is_described_as_a_snapshot_not_the_state():
    from pathlib import Path
    source = Path('engine/factory.py').read_text(encoding='utf-8')
    assert 'is a snapshot from' in source
    assert 'do not read it' in source
    assert 'media grid' in source
    assert '--asset-url' in source


def test_the_no_video_error_does_not_say_to_wait_for_the_queue_alone():
    from pathlib import Path
    source = Path('engine/factory.py').read_text(encoding='utf-8')
    start = source.index('No downloadable video tile became available')
    block = source[start:start + 1200]
    assert 'nothing was submitted (waiting costs no credits)' in block
    assert 'check the project' in block
    assert '--asset-reviewed' in block


def test_the_panel_note_offers_the_stale_explanation():
    from pathlib import Path
    source = Path('app.py').read_text(encoding='utf-8')
    assert 'If you approved it in the Flow UI yourself, this ' in source
    assert 'note is stale' in source
    assert 'run the free download first' in source


def test_the_diagnosis_action_downloads_before_approving(tmp_path):
    from types import SimpleNamespace
    from engine.factory import Factory
    from engine.project.manager import ProjectManager

    job = _job(tmp_path)
    factory = Factory.__new__(Factory)
    factory.pm = SimpleNamespace(job_dir=lambda job_id: str(job),
                                 load_manifest=lambda job_id: (_ for _ in ()).throw(FileNotFoundError()))
    diagnosis = Factory.flow_journal_diagnosis(factory, JOB)
    assert diagnosis['pending_approval'] is True
    action = diagnosis['next_action']
    assert 'Either Flow is still waiting' in action
    assert 'approved it directly in the Flow UI' in action
    assert 'Run the free download first' in action
    assert diagnosis['video_recovery_command'].endswith('--wait-seconds 180')

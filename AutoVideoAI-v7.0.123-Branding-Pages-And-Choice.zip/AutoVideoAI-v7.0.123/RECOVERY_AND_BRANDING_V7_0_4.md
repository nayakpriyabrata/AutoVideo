# AutoVideoAI 7.0.4 — parallel recovery and channel branding

Stop Studio/runner/CLI before upgrading. Back up your installation and overlay
source files in the same existing folder to preserve absolute job paths. Keep
outputs, data, .env, browser profiles and config/user_settings.yaml. Review config
defaults before replacing custom configuration. Restart Studio and the runner.

## Long video: recover the saved plan

The parallel frame retry loop used an exception variable after Python cleared it.
This hid the original Flow error and could append duplicate frame results. The
exception is now retained safely; bootstrap failure records only unfinished tasks.
Cached valid images remain reusable. Completed-frame progress cannot duplicate
those outcomes. Free-provider failure still blocks missing images rather than
claiming the storyboard is complete.

After upgrading, select the existing job in Queue and Resume, or run:

    python3 cli.py v3 resume 20261005-103535-7-ai-skills-that-will-be-05aa

Do not create the plan again. Resume preserves saved script, narration, cached
frames and accepted takes; remaining generation may still use credits.

## Re-render branding and captions without generating visuals

In Queue, open Audio & text cards. Enter Skill Soft Pro as the channel name,
enable Show channel watermark, choose playful Card style, OPUS Speech caption
style and full Speech captions. Save, then use Render now. Accepted visuals and
pending Flow journals stay unchanged. Narration timing must already be present.
Avoid changing the audio mode if you only want captions/branding.

The playful watermark is a small cyan/pink/gold badge. It starts with a closed
eye icon, opens to the channel name, fades out and returns periodically. It sits
above the title-card area and is independent of the text-card switch. Other card
styles retain subtle text branding. Long channel names are fitted to the badge.
It begins at five seconds and stays clear of the final six seconds; very short
videos (12 seconds or less) retain the existing no-watermark behavior.

OPUS uses larger bold white phrases with a green active-word highlight, matching
Clip Studio. It uses the existing word timing; this is a style change, not a new
transcript. Vertical video auto style now uses OPUS. Full controls burn-in; none
disables it. YouTube auto still defaults to sidecar captions.

## Flow request for shot_002

The supplied screenshot says the video is queued under high demand; it does not
prove that shot_002 has a completed asset. The log confirms shot_001 was downloaded.
A generic Something went wrong message now receives a 20-second existing-request
scan before failure. If a queue status is visible, bounded queue waiting continues.
Specific generation/safety/quota failures remain failures. This does not click
Generate again or clear journals. Wait, then recover/Resume the same job:

    python3 cli.py v3 resume 20261005-124407-lyra-vance--ai-recreatio-ebb6

If fingerprint recovery fails but you can visually identify the correct generated
video, use Queue's reviewed /edit/ URL recovery. Check the shot content yourself;
an arbitrary MP4 or newest tile must not be associated with the saved request.

## Verification limits

Tests exercise retry after worker error, unique frame outcomes, progress bounds,
queue/error classification, branding controls and opening/closing badge assets.
The badge was also composited into a real encoded sample and visually checked.
The original uploaded videos were not changed. Current Google UI, your WSL sign-in,
provider availability and paid generation remain unverified here.

Validation: 662 complete-suite tests passed (12 dependency deprecation warnings).

import pytest
from engine.studio_ui import THEME_TOKENS, theme_css


def luminance(hex_color):
    channels=[int(hex_color[i:i+2],16)/255 for i in (1,3,5)]
    linear=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in channels]
    return sum(c*w for c,w in zip(linear,(.2126,.7152,.0722)))


@pytest.mark.parametrize('theme', ['Light','Warm','Dark'])
def test_normal_text_and_muted_labels_have_readable_contrast(theme):
    tokens=THEME_TOKENS[theme]
    for fg in ('ink','muted'):
        for bg in ('bg','surface','field','soft','code'):
            a,b=sorted([luminance(tokens[fg]),luminance(tokens[bg])])
            assert (b+.05)/(a+.05)>=4.5,(theme,fg,bg)


@pytest.mark.parametrize('theme', ['Light','Warm','Dark'])
def test_theme_covers_the_screenshot_failure_surfaces(theme):
    css=theme_css(theme)
    assert '[data-testid="stWidgetLabel"] *' in css
    assert '.stApp input' in css and '-webkit-text-fill-color:var(--studio-ink)' in css
    assert '[role="option"] *' in css
    assert '[data-testid="stSidebar"]' in css
    assert 'color-scheme:'+('dark' if theme=='Dark' else 'light') in css

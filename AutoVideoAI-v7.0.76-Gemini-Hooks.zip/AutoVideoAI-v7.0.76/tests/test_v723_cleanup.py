import json
from pathlib import Path
import pytest
from engine.job_cleanup import cleanup_job,trim_worker_cache,profile_copy_ignore
from engine.providers.flow_browser import FlowBrowserProvider


def setup(tmp_path,status='done',pending=False):
    job=tmp_path/'outputs'/'20261007-test-a123';job.mkdir(parents=True)
    (job/'production_manifest.json').write_text(json.dumps({'status':status}))
    (job/'render').mkdir();(job/'render'/(job.name+'-final.mp4')).write_bytes(b'final')
    (job/'take.mp4').write_bytes(b'accepted')
    if pending:(job/'take.mp4.flow-request.json').write_text(json.dumps({'status':'pending'}))
    root=tmp_path/'.flow-workers';profile=root/(job.name+'-economy-worker-1')
    for path,data in [('Default/Cache/data',b'cached'*100),('Default/Cookies',b'login'),
                      ('Default/IndexedDB/Cache/identity',b'origin-storage')]:
        file=profile/path;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(data)
    return job,root,profile


def test_dry_run_then_completed_cleanup_only_removes_isolated_clone(tmp_path,monkeypatch):
    job,root,profile=setup(tmp_path)
    monkeypatch.setattr(FlowBrowserProvider,'_is_valid_video_file',lambda p:True)
    source=tmp_path/'flow-profile';source.mkdir();(source/'Cookies').write_bytes(b'base-login')
    other=root/'other-job-economy-worker-1';other.mkdir()
    report=cleanup_job(job,root)
    assert report['eligible_bytes']>0 and report['freed_bytes']==0 and profile.exists()
    applied=cleanup_job(job,root,apply=True)
    assert applied['freed_bytes']==report['eligible_bytes'] and not profile.exists()
    assert (source/'Cookies').read_bytes()==b'base-login' and other.exists()
    assert (job/'take.mp4').read_bytes()==b'accepted' and (job/'render'/(job.name+'-final.mp4')).exists()


@pytest.mark.parametrize('status,pending',[('failed',False),('paused',True),('done',True)])
def test_failed_or_pending_jobs_keep_recovery_and_login_but_trim_cache(tmp_path,monkeypatch,status,pending):
    job,root,profile=setup(tmp_path,status,pending)
    monkeypatch.setattr(FlowBrowserProvider,'_is_valid_video_file',lambda p:True)
    report=cleanup_job(job,root,apply=True)
    assert report['freed_bytes']==600 and profile.exists()
    assert (profile/'Default/Cookies').read_bytes()==b'login'
    assert (profile/'Default/IndexedDB/Cache/identity').read_bytes()==b'origin-storage'
    if pending:assert json.loads((job/'take.mp4.flow-request.json').read_text())['status']=='pending'


def test_live_or_ambiguous_worker_lock_blocks_cleanup(tmp_path,monkeypatch):
    job,root,profile=setup(tmp_path)
    monkeypatch.setattr(FlowBrowserProvider,'_is_valid_video_file',lambda p:True)
    (profile/'SingletonLock').symlink_to('/does-not-exist')
    report=cleanup_job(job,root,apply=True)
    assert report['freed_bytes']==0 and (profile/'Default/Cache/data').exists()


def test_symlink_escape_and_main_profile_are_never_trimmed(tmp_path):
    outside=tmp_path/'outside';outside.mkdir();(outside/'important').write_bytes(b'protected')
    root=tmp_path/'.flow-workers';profile=root/'test-economy-worker-1';profile.mkdir(parents=True)
    (profile/'Cache').symlink_to(outside,target_is_directory=True)
    assert trim_worker_cache(profile,apply=True)['freed_bytes']==0
    assert (outside/'important').read_bytes()==b'protected'
    assert trim_worker_cache(tmp_path/'flow-profile',apply=True)['warnings']


def test_unverified_final_keeps_entire_login_profile(tmp_path,monkeypatch):
    job,root,profile=setup(tmp_path)
    monkeypatch.setattr(FlowBrowserProvider,'_is_valid_video_file',lambda p:False)
    cleanup_job(job,root,apply=True)
    assert (profile/'Default/Cookies').exists()


def test_profile_clone_skips_cache_without_excluding_auth():
    names=['Cache','Code Cache','GPUCache','Cookies','IndexedDB','Local Storage','SingletonLock','Preferences']
    assert profile_copy_ignore('/profile/Default',names)==['Cache','Code Cache','GPUCache','SingletonLock']


def test_cli_preview_apply_rechecks_and_does_not_remove_accepted_media(tmp_path):
    import subprocess,sys
    job,root,profile=setup(tmp_path,'failed')
    command=[sys.executable,str(Path(__file__).resolve().parents[1]/'tools/cleanup_jobs.py'),
             '--outputs',str(job.parent),'--worker-root',str(root)]
    result=subprocess.run(command,capture_output=True,text=True,check=True,timeout=10)
    preview=json.loads(result.stdout)
    assert preview['eligible_bytes']==600 and (profile/'Default/Cache/data').exists()
    result=subprocess.run(command+['--apply'],capture_output=True,text=True,check=True,timeout=10)
    assert json.loads(result.stdout)['freed_bytes']==600
    assert (job/'take.mp4').read_bytes()==b'accepted' and (profile/'Default/Cookies').read_bytes()==b'login'


def test_proxy_cleanup_on_provider_failure_preserves_original(tmp_path,monkeypatch):
    from engine.studio_review import review_recreation_clip
    import engine.production as production
    import engine.providers.gemini_web as gemini
    monkeypatch.chdir(tmp_path)
    clip=tmp_path/'original.mp4';clip.write_bytes(b'original')
    monkeypatch.setattr(production,'probe',lambda p:{'format':{'duration':'12'}})
    monkeypatch.setattr(production,'run',lambda args,**kw:Path(args[-1]).write_bytes(b'proxy'))
    attachments=[]
    def fail(*args,**kw):
        attachments.extend(kw['attachments']);assert Path(attachments[0]).exists()
        raise RuntimeError('Browser unavailable')
    monkeypatch.setattr(gemini,'gemini_web_generate',fail)
    with pytest.raises(RuntimeError,match='Browser unavailable'):
        review_recreation_clip(clip,'Exact words here.','en')
    assert not Path(attachments[0]).exists() and clip.read_bytes()==b'original'

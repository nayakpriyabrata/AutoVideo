from pathlib import Path
from types import SimpleNamespace as NS
import json
from PIL import Image
import pytest
from engine.providers.flow_browser import FlowBrowser, FlowBrowserProvider, video_reference_plan
from engine.flow_reference_validation import matching_reference, quarantine_reference_copy
from engine.support_report import build_support_report


def test_generation_wait_ignores_upload_until_prompt_matched_result(monkeypatch):
    import engine.providers.flow_browser as module
    clock = {'now': 0.0}
    monkeypatch.setattr(module.time, 'time', lambda: clock['now'])
    monkeypatch.setattr(module.time, 'monotonic', lambda: clock['now'])
    b = FlowBrowser.__new__(FlowBrowser)
    b.ui = {'timeouts': {'generation': 40, 'poll_interval': 1}, 'actions': {}}
    b.detect_failure = lambda: None; b.detect_service_busy = lambda: None
    b._set = lambda state: None
    b._page = NS(inner_text=lambda _: 'Creating image',
                 wait_for_timeout=lambda ms: clock.update(now=clock['now'] + ms / 1000))
    upload = {'sig': 'upload', 'kind': 'image'}
    result = {'sig': 'generated', 'kind': 'image'}
    b.media_assets = lambda: [upload] + ([result] if clock['now'] >= 12 else [])
    b.read_asset_generation_prompt = lambda sig: ('Create a reader' if sig == 'generated' else 'Create empty street')
    request = {'kind': 'image', 'submitted_prompt': 'Create a reader', 'baseline': []}
    assert b.wait_for_agent_generation(before_assets=set(), timeout_s=40,
        required_kind='image', image_request=request)
    assert clock['now'] >= 12 and b.last_generated_asset_signature == 'generated'
    assert request['correlation_method'] == 'exact_reused_prompt'


def test_late_upload_cannot_satisfy_unique_image_request():
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    request = {'kind': 'image', 'baseline': ['old'], 'submitted_prompt': 'Create a woman reading'}
    assets = [{'sig': 'location-upload', 'kind': 'image'}]
    prompts = {'location-upload': 'Create an empty street'}
    bridge = NS(media_assets=lambda: assets, read_asset_generation_prompt=prompts.get)
    assert not provider._identify_single_fresh_asset(bridge, request, 'image', 0, fresh_only=True)
    assets.append({'sig': 'result', 'kind': 'image'})
    prompts['result'] = 'Create a woman reading'
    assert provider._identify_single_fresh_asset(bridge, request, 'image', 0, fresh_only=True) == 'result'


def test_reference_copy_is_preserved_and_journal_reset(tmp_path):
    ref = tmp_path / 'location_master.jpg'
    Image.new('RGB', (320, 180), 'blue').save(ref)
    frame = tmp_path / 'shot_001_open.jpg'; frame.write_bytes(ref.read_bytes())
    journal = Path(str(frame) + '.flow-request.json')
    journal.write_text(json.dumps({'status': 'downloaded', 'signature': 'uploaded-location', 'request_hash': 'preserved'}))
    result = quarantine_reference_copy(frame, [ref])
    assert result and not frame.exists() and Path(result['backup']).read_bytes() == ref.read_bytes()
    saved = json.loads(journal.read_text())
    assert saved['status'] == 'pending' and saved['signature'] == '' and saved['request_hash'] == 'preserved'
    assert saved['rejected_signatures'] == ['uploaded-location']


def test_generated_frame_with_same_subject_is_not_rejected(tmp_path):
    ref = tmp_path / 'ref.jpg'; frame = tmp_path / 'frame.jpg'
    Image.new('RGB', (320, 180), 'blue').save(ref)
    Image.new('RGB', (320, 180), 'green').save(frame)
    assert not matching_reference(frame, [ref])
    assert not matching_reference(ref, [ref])


def test_frame_mode_attaches_only_two_frames(tmp_path):
    paths = []
    for name in ['start', 'end', 'character-a', 'location']:
        path = tmp_path / (name + '.jpg'); path.write_bytes(name.encode()); paths.append(str(path))
    selected, prompt = video_reference_plan({'flow_video_mode': 'frames', 'reference_paths': [paths[2]]},
        dict(zip(['start', 'end', 'character', 'location'], paths)))
    assert selected == paths[:2]
    assert 'image 1 as the exact START' in prompt and 'image 2 as the exact END' in prompt
    assert 'image 3' not in prompt


def test_long_job_support_report_does_not_fail_on_512kb_manifest(tmp_path):
    manifest = {'job_id': 'long-job', 'shots': [{'shot_id': 'shot_001', 'compiled_prompt': 'private ' * 100000}]}
    (tmp_path / 'production_manifest.json').write_text(json.dumps(manifest))
    report = build_support_report(tmp_path)
    assert report['job']['shot_count'] == 1 and 'private' not in json.dumps(report)


def test_support_report_identifies_missing_manifest_path(tmp_path):
    with pytest.raises(ValueError, match='production_manifest.json'):
        build_support_report(tmp_path)

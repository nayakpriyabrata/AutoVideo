# AutoVideoAI v7.0.20 — local video editing

Upgrade into a fresh folder. Stop Studio/CLI jobs, then run from the new folder:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.19 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.19 . --apply
```

Start Studio and open **Clip Studio**. Choose a task:

- **Find highlights with Gemini**: existing speech-based selection; Include speech captions can now be switched off. Selection still needs a transcript.
- **Convert whole video · face crop 9:16**: reframes the full existing video, retaining its duration and original audio. No clip selection, Gemini or Flow generation.
- **Cut music video into shots**: splits all source footage into consecutive fixed-length segments, including a shorter final segment. It does not automatically identify musical beats or scene changes.

For local editing, transcript/captions default to None. Optional extra music is a local licensed audio file mixed beneath the source soundtrack. Logo upload/path, corner and size are optional. Each run writes to a new directory; original files and prior results are preserved. A failed segment is reported and the remaining segments continue.

**Face crop is a sampled static face center per output**, not dynamic tracking. Review moving subjects and multi-speaker footage. Fit keeps the whole source frame.

English and Hindi can use automatic speech captions. **Odia / Oriya uses a reviewed timed transcript**, because this build does not certify automatic Odia ASR. Upload JSON with source-relative seconds:

```json
{"words":[{"word":"ନମସ୍କାର","start":0.2,"end":0.8}]}
```

Do not use an untimed text file: the editor does not invent word timings. The same reviewed JSON is accepted for Odia highlight selection. None produces no captions; whole-video editing makes no transcription requests when None is selected.

The private control center exposes these tasks under Clips. WSL paths refer to your local files; the hosted site receives no video uploads. Restart its local runner after upgrading.

Character Library now shows small face-focused reference thumbnails that enlarge on hover or keyboard focus. If no face is detected, the thumbnail favors the upper part of the photo. Character pickers elsewhere show names only. Original reference photos used for generation are unchanged.

Existing v7.0.19 image-recovery journals, settings, caps and safeguards are preserved. These local editing changes do not establish that a legacy Flow job will recover successfully in your WSL environment.

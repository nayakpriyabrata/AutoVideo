"""Experimental headed Linux browsers on an authenticated, hidden X display.

Service survives CLI exit; a localhost-only password-protected viewer exposes
this same display on demand. No browser/profile is restarted by Show browser.
"""
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import time


def quiet_enabled(config=None):
    return os.getenv('AUTOVIDEO_QUIET_BROWSER','').lower() in ('1','true','yes') or bool((config or {}).get('quiet'))


def _root():
    root=Path.home()/'.local/share/autovideoai/quiet-browser'
    root.mkdir(parents=True,exist_ok=True);root.chmod(0o700)
    return root


def _live(pid, token):
    try:
        path=Path('/proc')/str(int(pid))
        return path.stat().st_uid==os.getuid() and token.encode() in (path/'cmdline').read_bytes()
    except (OSError,ValueError,TypeError):return False


def _dependencies(names):
    missing=[name for name in names if not shutil.which(name)]
    if missing:raise RuntimeError('Quiet browser dependencies missing: '+', '.join(missing)+
        '. Install: sudo apt install xvfb xauth x11-utils x11vnc tigervnc-viewer. Quiet mode did not open a visible browser.')


def browser_environment():
    if os.name!='posix' or not Path('/proc').exists():
        raise RuntimeError('Quiet browser currently supports Linux/WSL only')
    import fcntl
    _dependencies(['Xvfb','xauth','xdpyinfo'])
    root=_root();state_path=root/'display.json';auth=root/'Xauthority'
    with open(root/'service.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        state=json.loads(state_path.read_text()) if state_path.exists() else {}
        if not _live(state.get('pid'),str(auth)):
            display=next((':'+str(n) for n in range(81,100)
                          if not Path('/tmp/.X11-unix/X'+str(n)).exists() and not Path('/tmp/.X'+str(n)+'-lock').exists()),None)
            if not display:raise RuntimeError('No free private X display; Quiet mode did not open a visible browser')
            auth.touch(mode=0o600);auth.chmod(0o600)
            subprocess.run(['xauth','-f',str(auth),'add',display,'.',secrets.token_hex(16)],check=True,
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5)
            with open(root/'display.log','ab') as log:
                process=subprocess.Popen(['Xvfb',display,'-screen','0','1920x1080x24','-nolisten','tcp','-auth',str(auth)],
                                         stdout=log,stderr=log,start_new_session=True)
            state={'pid':process.pid,'display':display}
            state_path.write_text(json.dumps(state));state_path.chmod(0o600)
        env=dict(os.environ);env.pop('WAYLAND_DISPLAY',None)
        env.update(DISPLAY=state['display'],XAUTHORITY=str(auth))
        deadline=time.monotonic()+6
        while time.monotonic()<deadline:
            if subprocess.run(['xdpyinfo'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=2).returncode==0:
                return env
            time.sleep(.1)
        raise RuntimeError('Private X display did not become ready; check quiet-browser/display.log. No visible fallback was launched.')


def show_browser():
    if os.name!='posix':raise RuntimeError('Quiet browser currently supports Linux/WSL only')
    import fcntl
    _dependencies(['x11vnc','vncviewer'])
    root=_root();state_path=root/'display.json'
    if not state_path.exists():raise RuntimeError('No quiet session yet. Enable Quiet browser in Settings and start a browser job first.')
    state=json.loads(state_path.read_text())
    if not _live(state.get('pid'),str(root/'Xauthority')):raise RuntimeError('Quiet display is no longer running; resume the saved job first.')
    with open(root/'viewer.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        password=root/'vnc-password'
        if not password.exists():
            subprocess.run(['x11vnc','-storepasswd',secrets.token_hex(4),str(password)],check=True,
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5)
            password.chmod(0o600)
        vnc_path=root/'viewer.json';vnc=json.loads(vnc_path.read_text()) if vnc_path.exists() else {}
        if not _live(vnc.get('pid'),str(password)):
            import socket
            with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            env=dict(os.environ);env.update(DISPLAY=state['display'],XAUTHORITY=str(root/'Xauthority'))
            with open(root/'viewer.log','ab') as log:
                process=subprocess.Popen(['x11vnc','-display',state['display'],'-localhost','-rfbauth',str(password),
                    '-rfbport',str(port),'-forever','-shared','-nolookup'],env=env,stdout=log,stderr=log,start_new_session=True)
            vnc={'pid':process.pid,'port':port};vnc_path.write_text(json.dumps(vnc));vnc_path.chmod(0o600)
        subprocess.Popen(['vncviewer','-passwd',str(password),'127.0.0.1::'+str(vnc['port'])],
                         stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)

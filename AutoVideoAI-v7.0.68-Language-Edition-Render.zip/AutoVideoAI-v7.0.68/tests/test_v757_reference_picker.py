from types import SimpleNamespace as NS
import pytest
from playwright.sync_api import TimeoutError as ClickTimeout
from engine.providers import flow_browser as m


class Rows:
    def __init__(self,*rows):self.rows=rows
    def count(self):return len(self.rows)
    def nth(self,i):return self.rows[i]


def setup_browser(monkeypatch, fail_count=1, attach=True, always=False):
    now=[0.0];clicks=[];attached=[False];actions=[]
    monkeypatch.setattr(m.time,'monotonic',lambda:now[0])
    class Row:
        def is_visible(self,**kw):return True
        def get_attribute(self,*a,**kw):return None
        def click(self,**kw):
            clicks.append(kw);now[0]+=kw['timeout']/1000
            if always or len(clicks)<=fail_count:raise ClickTimeout('element not stable')
    b=m.FlowBrowser.__new__(m.FlowBrowser)
    b._clear_media_picker_search=lambda:None;b._picker_uploads=lambda:True
    b._exact_reference_rows=lambda name:Rows(Row())
    b._agent_reference_names=lambda:['AV_exact.jpg'] if attached[0] else []
    b._dismiss_media_picker=lambda:actions.append('dismiss')
    def add(*args,**kw):
        actions.append('Add to prompt');attached[0]=attach;return attach
    b._click_text_action=add
    b._page=NS(wait_for_timeout=lambda ms:now.__setitem__(0,now[0]+ms/1000))
    return b,now,clicks,actions


def test_transient_row_click_timeout_retries_then_confirms_chip(monkeypatch):
    b,now,clicks,actions=setup_browser(monkeypatch)
    assert b._finish_agent_media_picker('AV_exact.jpg',timeout_ms=5000)
    assert len(clicks)==2 and actions==['Add to prompt','dismiss']
    assert all('force' not in call for call in clicks)


def test_permanent_timeout_is_bounded_and_never_clicks_add(monkeypatch):
    b,now,clicks,actions=setup_browser(monkeypatch,always=True)
    assert not b._finish_agent_media_picker('AV_exact.jpg',timeout_ms=5000)
    assert now[0]<=5.01 and len(clicks)>1 and not actions


def test_successful_click_without_composer_attachment_is_not_success(monkeypatch):
    b,now,clicks,actions=setup_browser(monkeypatch,fail_count=0,attach=False)
    assert not b._finish_agent_media_picker('AV_exact.jpg',timeout_ms=5000)
    assert 'dismiss' not in actions


def test_already_attached_reference_needs_no_selection(monkeypatch):
    b,now,clicks,actions=setup_browser(monkeypatch)
    b._agent_reference_names=lambda:['AV_exact.jpg']
    assert b._finish_agent_media_picker('AV_exact.jpg')
    assert not clicks and actions==['dismiss']


def test_scope_excludes_duplicate_gallery_title():
    wanted=Rows(NS())
    picker=NS(is_visible=lambda **kw:True,get_by_text=lambda name,**kw:wanted)
    b=m.FlowBrowser.__new__(m.FlowBrowser)
    b._page=NS(locator=lambda css:Rows(picker),get_by_text=lambda *a,**kw:pytest.fail('gallery used'))
    assert b._exact_reference_rows('AV_exact.jpg') is wanted


def test_hidden_duplicate_is_skipped(monkeypatch):
    b,now,clicks,actions=setup_browser(monkeypatch,fail_count=0)
    good=b._exact_reference_rows('AV_exact.jpg').nth(0)
    b._exact_reference_rows=lambda name:Rows(NS(is_visible=lambda **kw:False),good)
    assert b._finish_agent_media_picker('AV_exact.jpg')
    assert len(clicks)==1

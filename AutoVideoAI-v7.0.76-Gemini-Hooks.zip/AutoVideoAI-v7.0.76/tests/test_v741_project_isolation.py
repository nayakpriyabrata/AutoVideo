import json
import pytest
from engine.flow_project_isolation import assert_project_binding, persist_project_binding

A = 'https://flow.google.com/project/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
B = 'https://flow.google.com/project/bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'

def test_matching_project():
    assert assert_project_binding(A, A + '?x=1', 'worker-1') == A

def test_wrong_or_missing_project_blocks():
    with pytest.raises(RuntimeError, match='isolation violation'):
        assert_project_binding(A, B, 'worker-1')
    with pytest.raises(RuntimeError):
        assert_project_binding(A, '', 'worker-1')

def test_binding_is_immutable(tmp_path):
    path = tmp_path / 'video.json'
    assert persist_project_binding(path, A, 'video', 'job') == A
    assert json.loads(path.read_text())['role'] == 'video'
    assert persist_project_binding(path, A, 'video', 'job') == A
    with pytest.raises(RuntimeError, match='refusing to rebind'):
        persist_project_binding(path, B, 'video', 'job')

"""Reviewable shot-bound external video plans and explicit local imports."""
import hashlib,json,os,shutil,time
from pathlib import Path
from .production import save
from .production_lock import production_slot

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def export_plan(factory,job_id,shot_ids=None):
    m=factory.pm.load_manifest(job_id);root=Path(factory.pm.job_dir(job_id)).resolve()
    ids=set(shot_ids or [s.shot_id for s in m.shots if s.provider in ('flow','movieflow')])
    if not ids or ids-set(s.shot_id for s in m.shots):raise ValueError('Choose existing planned video shots')
    rows=[]
    for shot in m.shots:
        if shot.shot_id not in ids:continue
        prompt=shot.compiled_prompt or shot.visual_goal
        refs=[]
        for attr in ('opening_frame','closing_frame','start_frame','end_frame'):
            value=getattr(shot,attr,None)
            if value and Path(value).is_file() and value not in [r['path'] for r in refs]:refs.append({'path':str(Path(value).resolve()),'sha256':digest(value)})
        for value in list(getattr(shot,'reference_assets',[]) or []) + [str(p) for p in (root/'references').glob('character-*.png')]:
            if value and Path(value).is_file() and value not in [r['path'] for r in refs]:refs.append({'path':str(Path(value).resolve()),'sha256':digest(value)})
        row={'shot_id':shot.shot_id,'prompt':prompt,'seconds':shot.gen_duration,'aspect':m.aspect,
             'timeline_start':getattr(shot,'voice_start',0),'timeline_end':getattr(shot,'voice_end',0),
             'target_seconds':getattr(shot,'duration_target',shot.gen_duration),
             'references':refs,'accepted':bool(shot.accepted_take),'required_path':str(root/'external_video'/'incoming'/f'{shot.shot_id}.mp4')}
        row['binding']=hashlib.sha256(json.dumps({k:v for k,v in row.items() if k not in ('accepted','required_path')},sort_keys=True).encode()).hexdigest()
        rows.append(row)
    report={'schema':1,'job_id':job_id,'topic':m.topic,'shots':rows,'new_generations':0}
    path=root/'external_video'/'plan.json';save(path,report)
    (path.parent/'incoming').mkdir(exist_ok=True)
    text=['# External video shot plan',f'Job: {job_id}', 'Generate each listed shot on your chosen platform. Review it, then import it by shot ID.']
    for row in rows:text.extend([f"\n## {row['shot_id']} · {row['seconds']} seconds · {row['aspect']}",f"Timeline insert: {row['timeline_start']}–{row['timeline_end']} seconds; target {row['target_seconds']} seconds.",row['prompt'],f"\nCLI incoming path: {row['required_path']}"])
    (path.parent/'prompts.md').write_text('\n\n'.join(text))
    return report

def configure(factory,job_id,shot_ids,enabled):
    with production_slot(factory.pm.job_dir(job_id)):
        if type(enabled) is not bool:raise ValueError('Explicit external-mode choice required')
        report=export_plan(factory,job_id,shot_ids)
        p=Path(factory.pm.job_dir(job_id))/'settings.json';settings=json.loads(p.read_text())
        settings['external_video_shots']=[r['shot_id'] for r in report['shots']] if enabled else []
        settings['external_video_mode']=enabled
        save(p,settings)
        return report

def import_clip(factory,job_id,shot_id,source,*,reviewed=False,platform='',replace_pending=False):
    if reviewed is not True:raise ValueError('Review the external clip for this exact shot first')
    root=Path(factory.pm.job_dir(job_id)).resolve();src=Path(source).resolve()
    if not src.is_file() or src.suffix.lower()!='.mp4' or not 0<src.stat().st_size<=512*1024*1024:raise ValueError('Expected a completed MP4 up to 512 MiB')
    with production_slot(root):
        plan=json.loads((root/'external_video'/'plan.json').read_text())
        row=next((r for r in plan['shots'] if r['shot_id']==shot_id),None)
        if not row:raise ValueError('Export this shot plan before import')
        m=factory.pm.load_manifest(job_id);shot=next(s for s in m.shots if s.shot_id==shot_id)
        if shot.accepted_take:raise ValueError('Accepted shot is preserved; choose an unaccepted shot')
        current=export_plan(factory,job_id,[r['shot_id'] for r in plan['shots']])
        now=next(r for r in current['shots'] if r['shot_id']==shot_id)
        if now['binding']!=row['binding']:raise ValueError('Shot plan or reference changed; review the newly exported plan')
        journals=list((root/'flow'/'shots'/shot_id).glob('*.flow-request.json'))
        pending=[p for p in journals if json.loads(p.read_text()).get('status') not in ('downloaded','superseded_by_authorized_replacement')]
        if pending and not replace_pending:raise ValueError('A Flow request is pending. Explicitly confirm replacing it with this reviewed external clip')
        result=factory.associate_download(job_id,shot_id,str(src))
        accepted=result.get('qc',{}).get('decision') in ('ACCEPT','REVIEW')
        if accepted:
            m=factory.pm.load_manifest(job_id);shot=next(s for s in m.shots if s.shot_id==shot_id)
            shot.actual_provider='external';shot.fallback_reason='Reviewed external video imported';factory.pm.update_shot(job_id,shot)
            accepted_path=Path(shot.accepted_take).resolve();checksum=digest(accepted_path)
            for p in pending:
                request=json.loads(p.read_text());shutil.copy2(p,str(p)+'.before-external-import-'+str(time.time_ns()))
                request.update(status='superseded_by_authorized_replacement',replacement_file=str(accepted_path.relative_to(root)),replacement_target=str(accepted_path.relative_to(root)),replacement_sha256=checksum)
                save(p,request)
            save(root/'external_video'/f'{shot_id}.receipt.json',{'binding':row['binding'],'platform':str(platform)[:200],'sha256':checksum,'qc':result['qc'],'at':time.time(),'new_credits':0})
        return {'accepted':accepted,'new_credits':0,**result}

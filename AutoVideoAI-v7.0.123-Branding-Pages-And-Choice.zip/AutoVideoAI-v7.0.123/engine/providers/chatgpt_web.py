"""ChatGPT web drafting provider for AutoVideoAI (signed-in browser session).

Works like the Gemini Web provider: a visible browser with a persistent profile,
where you sign in to ChatGPT once. Each draft is one prompt in a fresh chat. The
provider waits until the reply stops changing and returns its visible text.
Publish-quality JSON validation stays in engine/planning/script_engine.py.

Nothing here reads passwords, cookies or private endpoints, and no CAPTCHA or
quota is bypassed. The default draft uses a ChatGPT temporary chat, so it is not
saved to your history. Cleanup 'keep' saves it.

The selectors are written for ChatGPT's current web app. They have not been
verified against a live session in this environment. They are kept in one place
(SELECTORS) so they can be adjusted quickly if the page changes.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

from .flow_browser import FlowBrowser, FlowState, is_wsl

CHATGPT_URL = "https://chatgpt.com/"
COMPOSER_WAIT_SECONDS = 60
TEMPORARY_CHAT_URL = "https://chatgpt.com/?temporary-chat=true"
_UI_CONFIG = str(Path(__file__).resolve().parents[2] / "config" / "chatgpt_ui.yaml")

SELECTORS = {
    "composer": ["#prompt-textarea", "div[contenteditable='true'][id='prompt-textarea']",
                 "textarea[name='prompt-textarea']"],
    "send": ["button[data-testid='send-button']", "button[aria-label*='Send' i]"],
    "stop": ["button[data-testid='stop-button']", "button[aria-label*='Stop' i]"],
    "assistant": "[data-message-author-role='assistant']",
    "login": ["[data-testid='login-button']", "button:has-text('Log in')"],
}


class ChatGPTWebAuthNeeded(RuntimeError):
    """The ChatGPT session needs a manual sign-in in the AutoVideo browser window."""


class ChatGPTWebUIChanged(RuntimeError):
    """A visible ChatGPT control or reply could not be identified safely."""


def default_chatgpt_profile_dir() -> str:
    if is_wsl():
        return os.path.join(os.path.expanduser("~"), ".local", "share", "autovideoai", "chatgpt-profile")
    return os.path.abspath(".chatgpt-profile")


def _first_visible(page, selectors, timeout_ms: int = 1200):
    for selector in selectors:
        try:
            locator = page.locator(selector).first
            if locator.count() and locator.is_visible(timeout=timeout_ms):
                return locator
        except Exception:
            continue
    return None


def reply_settled(samples, generating: bool, needed: int = 3) -> bool:
    """True when the last ``needed`` readings of the reply are identical and not empty,
    and ChatGPT is no longer showing its stop control."""
    if generating or len(samples) < needed:
        return False
    tail = samples[-needed:]
    return bool(tail[-1]) and len(set(tail)) == 1


class ChatGPTWebBrowser(FlowBrowser):
    """Headed, persistent ChatGPT browser session."""

    def __init__(self, profile_dir: str | None = None, headless: bool = False):
        super().__init__(
            ui_cfg_path=_UI_CONFIG,
            profile_dir=profile_dir or default_chatgpt_profile_dir(),
            headless=headless,
            state_cb=None,
        )
        for env, key in (("CHATGPT_WEB_BROWSER_MODE", "mode"),
                         ("CHATGPT_WEB_BROWSER_CHANNEL", "channel"),
                         ("CHATGPT_WEB_BROWSER_EXE", "executable"),
                         ("CHATGPT_WEB_CDP_URL", "cdp_url")):
            if os.getenv(env):
                self.bcfg[key] = os.getenv(env)
        self.log_dir = "logs/chatgpt"
        os.makedirs(self.log_dir, exist_ok=True)

    def _current_url(self) -> str:
        try:
            return str(getattr(self._page, "url", "") or "").lower()
        except Exception:
            return ""

    def _post_connect(self, visible_login_seconds: int):
        """Wait until the composer is usable; the user signs in here on first run."""
        self._set(FlowState.WAITING_FOR_UI)
        if "chatgpt.com" not in self._current_url():
            self._page.goto(CHATGPT_URL, timeout=90000, wait_until="domcontentloaded")
        deadline = time.time() + max(30, visible_login_seconds)
        while time.time() < deadline:
            url = self._current_url()
            if "auth.openai.com" in url or "/auth/" in url or "login" in url:
                time.sleep(2)
                continue
            if _first_visible(self._page, SELECTORS["composer"], 900):
                self._set(FlowState.READY)
                return True
            time.sleep(1)
        raise ChatGPTWebAuthNeeded(
            "ChatGPT web was not ready. Sign in to ChatGPT in the AutoVideo browser window, "
            "then retry the draft.")

    # --- one prompt, one fresh chat -------------------------------------------------

    def _assistant_count(self) -> int:
        try:
            return int(self._page.locator(SELECTORS["assistant"]).count())
        except Exception:
            return 0

    def _latest_reply(self) -> str:
        try:
            return str(self._page.locator(SELECTORS["assistant"]).last.inner_text(timeout=2000) or "").strip()
        except Exception:
            return ""

    def _generating(self) -> bool:
        return _first_visible(self._page, SELECTORS["stop"], 150) is not None

    def _fill(self, box, prompt: str):
        try:
            box.click(timeout=3000)
        except Exception:
            pass
        try:
            box.fill(prompt, timeout=10000)
        except Exception:
            try:
                self._page.keyboard.press("Control+A")
                self._page.keyboard.insert_text(prompt)
            except Exception as error:
                raise ChatGPTWebUIChanged(f"Could not enter the ChatGPT prompt: {error}") from error

    def _submit(self, box):
        send = _first_visible(self._page, SELECTORS["send"], 1800)
        if send is not None:
            try:
                send.click(timeout=3000)
                return
            except Exception:
                pass
        try:
            box.press("Enter")
        except Exception as error:
            raise ChatGPTWebUIChanged(f"Could not submit the ChatGPT prompt: {error}") from error

    def ask(self, prompt: str, timeout_seconds: int = 240, *, temporary: bool = True) -> str:
        self._page.goto(TEMPORARY_CHAT_URL if temporary else CHATGPT_URL,
                        timeout=90000, wait_until="domcontentloaded")
        # is_visible() does not wait, so poll until the composer renders or 60 s pass.
        composer_deadline = time.time() + COMPOSER_WAIT_SECONDS
        while True:
            box = _first_visible(self._page, SELECTORS["composer"], 500)
            if box is not None or time.time() >= composer_deadline:
                break
            time.sleep(1)
        if box is None:
            if _first_visible(self._page, SELECTORS["login"], 800):
                raise ChatGPTWebAuthNeeded("ChatGPT is signed out. Sign in in the AutoVideo browser window, then retry.")
            raise ChatGPTWebUIChanged("ChatGPT prompt box was not found.")
        before = self._assistant_count()
        self._fill(box, prompt)
        self._submit(box)
        deadline = time.time() + timeout_seconds
        samples: list[str] = []
        while time.time() < deadline:
            time.sleep(1.5)
            if self._assistant_count() <= before:
                continue
            samples.append(self._latest_reply())
            if reply_settled(samples, self._generating()):
                return samples[-1]
        raise ChatGPTWebUIChanged(f"ChatGPT did not finish its reply within {timeout_seconds}s.")


def chatgpt_web_generate(system: str, user: str, model: str = "chatgpt-web", *, cleanup=None) -> str:
    """Draft adapter used by the Create page. ``model`` is provenance only: ChatGPT's model
    is chosen in your ChatGPT account."""
    prompt = (
        "SYSTEM INSTRUCTIONS:\n" + system.strip() +
        "\n\nUSER TASK:\n" + user.strip() +
        "\n\nReturn ONLY the requested JSON object. Do not wrap it in commentary."
    )
    if cleanup not in (None, "keep", "delete-after-read"):
        raise ValueError("Invalid ChatGPT chat cleanup policy")
    timeout = int(os.getenv("CHATGPT_WEB_RESPONSE_TIMEOUT", "300"))
    temporary = cleanup != "keep"
    browser = ChatGPTWebBrowser()
    try:
        browser.ensure_session(visible_login_seconds=int(os.getenv("CHATGPT_WEB_LOGIN_WAIT", "300")))
        return browser.ask(prompt, timeout_seconds=timeout, temporary=temporary)
    finally:
        try:
            browser.close()
        except Exception:
            pass

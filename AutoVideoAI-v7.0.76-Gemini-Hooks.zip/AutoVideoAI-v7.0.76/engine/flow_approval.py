"""Durable approval reservations; one total credit budget per saved request."""
import hashlib
import json
import re
import time
from pathlib import Path
from .production import save


def reserve(journal, body, cost, cap, limit=1):
    path=Path(journal); request=json.loads(path.read_text())
    if type(limit) is not int or not 1 <= limit <= 3:
        raise ValueError('Approval card limit must be 1–3')
    if type(cost) is not int or cost < 0 or type(cap) is not int or cap < 0:
        raise ValueError('A readable exact credit cost and finite request cap are required')
    questions=list(re.finditer(r'would you like me to (?:kick off|start|create|generate)',str(body),re.I))
    if not questions: raise ValueError('No request-specific approval question was found')
    question=' '.join(str(body)[questions[-1].start():].split())
    question=re.split(r'\b(?:Approve|Always approve|Reject)\b',question,flags=re.I)[0].strip()
    # Gallery/chat virtualization changes the number of historical questions
    # in body text. That count is not a new credit card identity.
    key=hashlib.sha256(json.dumps([question,cost]).encode()).hexdigest()
    legacy_keys={hashlib.sha256(json.dumps([question,n,cost]).encode()).hexdigest()
                 for n in range(1, max(512, len(questions))+1)}
    reservations=request.setdefault('approval_reservations',[])
    if any(r.get('key') == key or r.get('key') in legacy_keys for r in reservations):return False
    if len(reservations)>=limit:
        raise ValueError('Additional approval card exceeds the saved request approval-card limit')
    total=sum(r['cost'] for r in reservations)
    if total+cost>cap:raise ValueError(f'Cumulative credit guard: {total}+{cost} exceeds request cap {cap}')
    reservations.append({'key':key,'cost':cost,'status':'reserved','at':time.time()})
    request['approval_credit_total_reserved']=total+cost
    save(path,request)
    return True

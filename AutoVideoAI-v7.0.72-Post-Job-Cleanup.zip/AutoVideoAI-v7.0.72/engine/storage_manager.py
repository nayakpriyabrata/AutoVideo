"""Reviewed deletion of complete local jobs and clip output folders.

Only explicit ownership is eligible. Shared libraries, login profiles and
external source files are never adopted merely because a report mentions them.
"""
from contextlib import ExitStack
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import sqlite3
import uuid

from .production_lock import acquire, release

FLOW_PROJECT_RE = re.compile(r'https://flow\.google\.com/project/[A-Za-z0-9-]+')


def _flow_projects(folder):
    """Collect only canonical project URLs recorded inside owned saved state."""
    folder = Path(folder)
    found = set()
    if not folder.is_dir() or not _real(folder):
        return found
    for pattern in ('*.json', '*.yaml', '*.yml'):
        for record in folder.rglob(pattern):
            if not _real(record) or record.stat().st_size > 8 * 1024 * 1024:
                continue
            try:
                found.update(FLOW_PROJECT_RE.findall(record.read_text(encoding='utf-8', errors='ignore')))
            except OSError:
                continue
    from .providers.flow_browser import FlowBrowser
    return {FlowBrowser.normalize_project_url(url) for url in found if FlowBrowser.normalize_project_url(url)}


def _flow_cleanup_plan(all_rows, selected_rows):
    selected_keys = {row['key'] for row in selected_rows}
    ownership = {row['key']: _flow_projects(row['path']) for row in all_rows}
    selected_urls = sorted(set().union(*(ownership.get(row['key'], set()) for row in selected_rows)))
    shared = {}
    for url in selected_urls:
        users = [row['key'] for row in all_rows
                 if row['key'] not in selected_keys and url in ownership.get(row['key'], set())]
        if users:
            shared[url] = users
    return {'projects': selected_urls, 'shared': shared,
            'deletable': [url for url in selected_urls if url not in shared]}


def _real(path):
    path = Path(path).absolute()
    return not any(p.is_symlink() for p in (path, *path.parents))


def inventory(factory, clip_roots=()):
    root = Path(factory.pm.root).absolute()
    rows = []
    indexed = {j['job_id']: j for j in factory.db.list(100000)}
    for identifier in factory.pm.list_jobs():
        folder = root / identifier
        if not _real(folder):
            continue
        try:
            record = json.loads((folder / 'production_manifest.json').read_text())
        except (OSError, ValueError):
            continue
        row = indexed.get(identifier, {})
        rows.append({'key': 'job:' + identifier, 'kind': 'Job', 'job_id': identifier,
                     'path': str(folder), 'label': record.get('topic') or identifier,
                     'status': row.get('status') or record.get('status', 'saved'),
                     'videos': [str(p) for p in sorted((folder / 'render').glob('*final*.mp4')) if _real(p)]})
    folders = set()
    for value in [root, *map(Path, clip_roots)]:
        value = value.expanduser().absolute()
        if not _real(value) or not value.is_dir():
            continue
        for pattern in ('**/highlights*.json', '**/edits.json'):
            for report in value.glob(pattern):
                folder = report.parent.parent if report.parent.name == 'clip-history' else report.parent
                # outputs itself can contain unrelated jobs; never delete it.
                if folder == root or not _real(folder):
                    continue
                if any((folder / name).exists() for name in ('production_manifest.json',)):
                    continue
                if list(folder.glob('**/production_manifest.json')):
                    continue
                if any(folder.is_relative_to(Path(j['path'])) for j in rows):
                    continue
                folders.add(folder)
    for folder in sorted(folders):
        # Nested reports belong to the outer recognized clip folder.
        if any(folder != other and folder.is_relative_to(other) for other in folders):
            continue
        rows.append({'key': 'clips:' + str(folder), 'kind': 'Clip folder', 'path': str(folder),
                     'label': folder.name, 'status': 'saved / partial batches', 'job_id': None,
                     'videos': [str(p) for p in sorted(folder.glob('*.mp4')) if _real(p)]})
    return rows


def _owned_paths(row, install):
    folder = Path(row['path'])
    paths = [folder]
    if row['kind'] != 'Job':
        return paths
    identifier = row['job_id']
    from .providers.flow_browser import PROFILE_DIR
    worker_roots = {install / '.flow-workers', Path(PROFILE_DIR).absolute().parent / '.flow-workers'}
    pattern = re.compile(re.escape(identifier) + r'-(?:economy|candidate)-worker-[1-9][0-9]*')
    for root in worker_roots:
        if root.is_dir() and _real(root):
            paths.extend(p for p in root.iterdir() if pattern.fullmatch(p.name))
    # Global snapshots use an exact job-id boundary, not a partial topic match.
    logs = install / 'logs'
    if logs.is_dir() and _real(logs):
        pattern = re.compile(r'(?:^|AutoVideo-|[^A-Za-z0-9-])' + re.escape(identifier) + r'(?:$|[_./])')
        paths.extend(p for p in logs.rglob('*') if p.is_file() and pattern.search(p.name))
    backups = install / 'migration-backups'
    if backups.is_dir() and _real(backups):
        paths.extend(p for p in backups.glob('**/outputs/' + identifier) if p.is_dir())
    return sorted(set(paths))


def _snapshot(paths):
    entries = []
    total = 0
    for path in paths:
        if not _real(path):
            raise ValueError('Linked paths are protected: ' + str(path))
        if not path.exists():
            raise ValueError('A selected path disappeared; refresh the review')
        descendants = [path, *sorted(path.rglob('*'))] if path.is_dir() else [path]
        for item in descendants:
            if not _real(item):
                raise ValueError('A selected folder contains a link; nothing deleted: ' + str(item))
            stat = item.stat()
            if item.name == '.production.lock':
                continue
            # Lock files can be opened during verification without changing media.
            entries.append((str(item), stat.st_size if item.is_file() else 0,
                            stat.st_mtime_ns if item.is_file() else 0, stat.st_ino))
            if item.is_file():
                total += stat.st_size
    return hashlib.sha256(json.dumps(entries).encode()).hexdigest(), total


def preview_deletion(factory, keys, clip_roots=(), install=None):
    install = Path(install or Path(__file__).resolve().parents[1]).absolute()
    known = {row['key']: row for row in inventory(factory, clip_roots)}
    if not keys or len(set(keys)) != len(keys) or any(key not in known for key in keys):
        raise ValueError('Select existing jobs or clip folders, then refresh the deletion review')
    rows = [known[key] for key in keys]
    paths = sorted({p for row in rows for p in _owned_paths(row, install)})
    # Remove redundant paths but reject a clip selection containing another job.
    paths = [p for p in paths if not any(p != other and p.is_relative_to(other) for other in paths)]
    fingerprint, size = _snapshot(paths)
    flow = _flow_cleanup_plan(list(known.values()), rows)
    from .flow_project_cleanup import inventory as remote_inventory
    verified = {r['project_url']: r for r in remote_inventory(factory.pm.root)}
    flow['eligible'] = [verified[url] for url in flow['deletable']
                        if url in verified and verified[url]['eligible']]
    flow['retained'] = {url: ('Referenced by another saved item' if url in flow['shared'] else
                        '; '.join(verified[url]['blocked']) if url in verified else
                        'No complete, verified isolated-image capture inventory')
                        for url in flow['projects'] if url not in {r['project_url'] for r in flow['eligible']}}
    return {'keys': list(keys), 'rows': rows, 'paths': [str(p) for p in paths],
            'fingerprint': fingerprint, 'bytes': size, 'install': str(install),
            'clip_roots': list(map(str, clip_roots)), 'flow': flow}


def _dependencies(factory, preview):
    selected = [Path(row['path']).absolute() for row in preview['rows']]
    roots = [Path(factory.pm.root), *map(Path, preview['clip_roots'])]
    def references(value):
        if isinstance(value, dict):
            return any(references(v) for v in value.values())
        if isinstance(value, list):
            return any(references(v) for v in value)
        if isinstance(value, str) and '\n' not in value and len(value) < 4096:
            # Strings with command arguments are not filenames.
            if ' -i ' in value or ' -filter_complex ' in value:
                return False
            path = Path(value).expanduser().absolute()
            return any(path == target or path.is_relative_to(target) for target in selected)
        return False
    seen = set()
    for root in roots:
        for record in root.glob('**/*.json'):
            if record in seen or any(record.is_relative_to(p) for p in selected):
                continue
            seen.add(record)
            if not _real(record):
                raise ValueError('Linked saved state prevents a safe dependency check: ' + str(record))
            try:
                data = json.loads(record.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                raise ValueError('Unreadable saved state; repair it before deletion: ' + str(record))
            if references(data):
                raise ValueError('Another saved job or clip uses selected data: ' + str(record) + '. Include that work in the selection or retain the source.')


def delete_selected(factory, preview, delete_flow_projects=False):
    """Validate the reviewed set, lock production, stage, commit index, then erase."""
    from .job_monitor import _guard, _tasks
    from .job_cleanup import _active
    service = Path.home() / '.local/share/autovideoai'
    service.mkdir(parents=True, exist_ok=True)
    with ExitStack() as stack:
        def lock(path):
            handle = stack.enter_context(path.open('a+b'))
            try:
                acquire(handle, blocking=False)
            except BlockingIOError:
                raise ValueError('Production is active or queued; stop it before deleting saved work')
            stack.callback(release, handle)
        lock(service / 'production.lock')
        for row in preview['rows']:
            lock_path = Path(row['path']) / '.production.lock'
            if not _real(lock_path):
                raise ValueError('Linked lock path is protected')
            lock(lock_path)
        for row in preview['rows']:
            for launch in Path(row['path']).glob('**/.clip-render-jobs/*/.launch.lock'):
                lock(launch)
        with _guard:
            if any(t['thread'].is_alive() for t in _tasks.values()):
                raise ValueError('A Studio task is running or queued; stop it before deletion')
            current = preview_deletion(factory, preview['keys'], preview['clip_roots'], preview['install'])
            if current['fingerprint'] != preview['fingerprint'] or current['paths'] != preview['paths']:
                raise ValueError('Selected data changed after review. Refresh the deletion review; nothing deleted')
            for value in current['paths']:
                path = Path(value)
                if path.parent.name == '.flow-workers' and _active(path):
                    raise ValueError('A selected worker browser is open; close it before deletion')
            _dependencies(factory, current)
            remote_deleted = []
            if delete_flow_projects:
                # Keep local recovery records unless each reviewed remote action
                # has a verified success receipt. The remote ledger prevents a
                # second destructive click after a browser interruption.
                from .flow_project_cleanup import delete_selected as delete_remote
                reviewed = current['flow']['eligible']
                if not reviewed:
                    raise ValueError('No verified isolated-image Flow project can be deleted for this selection')
                if (preview['flow']['eligible'] != reviewed or
                        preview['flow']['projects'] != current['flow']['projects']):
                    raise ValueError('Flow project evidence changed. Refresh the deletion review')
                result = delete_remote(factory.pm.root, reviewed, lock_held=True)
                remote_deleted = [r['project_url'] for r in result if r['status'] == 'deleted']
                if len(remote_deleted) != len(reviewed):
                    raise ValueError('Flow deletion needs review; local data and recovery records were retained. Refresh the project review before retrying.')
            # Renames are reversible until the DB transaction commits. Tombstones
            # stay on the same volume; no multi-GB backup or media duplication.
            staged = []
            try:
                with factory.db._cx() as cx:
                    cx.execute('BEGIN IMMEDIATE')
                    for value in current['paths']:
                        path = Path(value)
                        temporary = path.with_name('.autovideo-delete-' + uuid.uuid4().hex)
                        path.rename(temporary)
                        staged.append((path, temporary))
                    for row in current['rows']:
                        if row.get('job_id'):
                            cx.execute('DELETE FROM jobs WHERE job_id=?', (row['job_id'],))
            except Exception:
                for original, temporary in reversed(staged):
                    temporary.rename(original)
                raise
        # On Windows close job lock handles before erasing the staged tree.
    remaining = []
    for original, temporary in staged:
        try:
            if temporary.is_dir():
                shutil.rmtree(temporary)
            else:
                temporary.unlink()
        except OSError as error:
            remaining.append({'path': str(temporary), 'error': str(error)})
    return {'deleted': current['keys'], 'bytes': current['bytes'], 'remaining': remaining,
            'flow_projects_deleted': remote_deleted if delete_flow_projects else []}


def _cleanup_panel(st, selected, by_key):
    """Free regenerable media after a video is finished. Keeps final videos and records.

    Review first, then confirm; apply refuses if the folder changed since review.
    """
    from engine import post_job_cleanup as pjc
    rows = [by_key[key] for key in selected if by_key[key]['kind'] in ('Job', 'Clip folder')]
    if not rows:
        return
    with st.expander('Free space after finishing · keeps the final video and records', expanded=False):
        st.caption('Removes regenerable media only. Jobs: Flow takes, downloads, storyboard frames, narration and audio, '
                   'stock copies, interrupted render temp files. Clip folders: the downloaded source video and batch work. '
                   'Final videos, JSON, subtitles, logs and Flow request journals stay. Blocked while a job is unfinished, '
                   'a Flow request is pending, or production is active.')
        for row in rows:
            digest_key = 'cleanup-plan-' + hashlib.sha256(row['key'].encode()).hexdigest()[:16]
            kind = 'clip' if row['kind'] == 'Clip folder' else 'job'
            st.markdown(f"**{row['kind']} · {row['label']}**")
            if st.button('Review cleanup', key='cleanup-review-' + digest_key):
                try:
                    st.session_state[digest_key] = (pjc.plan_clip_folder(row['path']) if kind == 'clip'
                                                    else pjc.plan_job(row['path']))
                except (OSError, ValueError) as error:
                    st.session_state.pop(digest_key, None)
                    st.error(str(error))
            plan = st.session_state.get(digest_key)
            if not plan:
                continue
            if plan['blocked']:
                for reason in plan['blocked']:
                    st.warning(reason)
                st.caption('Cleanup is blocked for this item. Nothing will be deleted.')
                continue
            st.info(f"Would free {plan['reclaimable_bytes'] / 1024**3:.2f} GB. Kept: "
                    + (', '.join(plan['kept_videos']) or 'none'))
            st.dataframe([{'category': name, 'files': info['files'], 'MB': round(info['bytes'] / 1024**2, 1)}
                          for name, info in sorted(plan['categories'].items())], hide_index=True)
            confirmed = st.checkbox('I understand the listed media is removed and the final video is kept',
                                    key='cleanup-confirm-' + digest_key + plan['digest'])
            if st.button('Free space now', disabled=not confirmed, key='cleanup-apply-' + digest_key + plan['digest']):
                try:
                    report = pjc.apply_plan(row['path'], plan['digest'], kind=kind)
                    st.session_state.pop(digest_key, None)
                    st.success(f"Freed {report['freed_bytes'] / 1024**3:.2f} GB; removed {report['removed_count']} file(s).")
                    for problem in report['errors']:
                        st.error(f"Not removed: {problem['path']} ({problem['error']})")
                except (OSError, ValueError) as error:
                    st.error(str(error))


def storage_manager(st, factory, clip_roots=()):
    st.subheader('Manage saved jobs & clips')
    st.caption('Select whole jobs or clip output folders. Preview and download videos before deleting. A clip folder includes all batches saved there, its source cache, captions, QC, B-roll and reports. Shared character/music libraries, login profiles and sources outside the selected folders are retained.')
    rows = inventory(factory, clip_roots)
    by_key = {row['key']: row for row in rows}
    if st.session_state.pop('storage-reset-selection', False):
        st.session_state['storage-selected-work'] = []
    statuses = sorted(set(str(row['status']) for row in rows))
    status_filter = st.multiselect('Filter by saved status', statuses, default=statuses,
                                   key='storage-status-filter')
    visible_keys = [row['key'] for row in rows if str(row['status']) in status_filter]
    quick = st.columns(4)
    quick_rules = [('Select failed', ('fail',)), ('Select paused', ('pause',)),
                   ('Select completed', ('complete', 'success')), ('Clear', ())]
    for column, (label, tokens) in zip(quick, quick_rules):
        if column.button(label, key='storage-quick-' + label.lower().replace(' ', '-')):
            st.session_state['storage-selected-work'] = ([] if not tokens else
                [row['key'] for row in rows if any(token in str(row['status']).lower() for token in tokens)])
            st.session_state.pop('storage-work-preview', None)
            st.rerun()
    existing_selection = [key for key in st.session_state.get('storage-selected-work', []) if key in by_key]
    option_keys = list(dict.fromkeys([*visible_keys, *existing_selection]))
    selected = st.multiselect('Select jobs / clip folders', option_keys,
        format_func=lambda key: f"{by_key[key]['kind']} · {by_key[key]['label']} · {by_key[key]['status']} · {Path(by_key[key]['path']).name}",
        key='storage-selected-work')
    for key in selected:
        row = by_key[key]
        with st.expander(row['kind'] + ' · ' + row['label']):
            st.code(row['path'], language='text')
            if not row['videos']:
                st.info('No final video saved. Deletion still includes unfinished media and recovery state.')
            for video in row['videos']:
                path = Path(video)
                st.video(str(path), width=280)
                with path.open('rb') as handle:
                    st.download_button('Download ' + path.name, handle, file_name=path.name,
                        key='storage-download-' + hashlib.sha256(video.encode()).hexdigest()[:20])
    _cleanup_panel(st, selected, by_key)
    if st.button('Review complete deletion', disabled=not selected, key='storage-review-work'):
        try:
            st.session_state['storage-work-preview'] = preview_deletion(factory, selected, clip_roots)
        except (OSError, ValueError) as error:
            st.session_state.pop('storage-work-preview', None)
            st.error(str(error))
    preview = st.session_state.get('storage-work-preview')
    if preview and preview['keys'] == selected:
        st.warning(f"Permanently delete {len(selected)} selected item(s), including all their local job data? Estimated {preview['bytes']/1024**3:.2f} GB. This cannot be resumed after deletion.")
        st.dataframe([{'item': row['label'], 'folder': row['path']} for row in preview['rows']], hide_index=True)
        with st.expander('All associated paths to delete'):
            st.code('\n'.join(preview['paths']), language='text')
        flow = preview.get('flow', {})
        if flow.get('projects'):
            with st.expander(f"Recorded Google Flow projects · {len(flow['projects'])}", expanded=True):
                for project_url in flow['projects']:
                    st.markdown(f"[{project_url}]({project_url})")
                    if project_url in flow.get('shared', {}):
                        st.warning('Retained: also referenced by ' + ', '.join(flow['shared'][project_url]))
            eligible = flow.get('eligible', [])
            if flow.get('retained'):
                st.caption('These Flow projects stay on Google Flow because their exact media or recovery state cannot be verified:')
                st.dataframe([{'project': u, 'reason': reason} for u, reason in flow['retained'].items()], hide_index=True)
            delete_flow = st.checkbox(
                f'Also delete {len(eligible)} verified isolated-image Flow project(s)',
                disabled=not eligible, key='storage-delete-flow-' + preview['fingerprint'])
            st.caption('Remote deletion requires the complete saved gallery inventory and a live confirmation. Video, shared, and pending projects are retained. A failed remote action keeps local job records for recovery.')
        else:
            delete_flow = False
            st.caption('No recorded Google Flow project URLs belong to this selection.')
        confirmed = st.checkbox('I confirm complete deletion of the selected work', key='storage-work-confirm-' + preview['fingerprint'])
        if st.button('Delete selected work permanently', disabled=not confirmed, key='storage-delete-work'):
            try:
                result = delete_selected(factory, preview, delete_flow_projects=delete_flow)
                st.session_state.pop('storage-work-preview', None)
                st.session_state['storage-reset-selection'] = True
                if st.session_state.get('job_id') in [row.get('job_id') for row in preview['rows']]:
                    st.session_state['job_id'] = None
                st.session_state['storage-work-result'] = result
                st.rerun()
            except (OSError, ValueError, sqlite3.Error) as error:
                st.error(str(error))
    result = st.session_state.get('storage-work-result')
    if result:
        if result['remaining']:
            st.error('Removed from the job index, but some files could not be erased. Cleanup is incomplete; these paths still occupy disk space.')
            st.json(result['remaining'])
        else:
            remote = len(result.get('flow_projects_deleted', []))
            suffix = f" and {remote} verified Google Flow project(s)" if remote else ''
            st.success(f"Deleted selected local data ({result['bytes']/1024**3:.2f} GB){suffix}.")

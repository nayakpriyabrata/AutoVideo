# AutoVideoAI 7.0.68 · language editions now render as videos

## What was wrong in 7.0.67

- Create selected English, Hindi and Odia editions, but production rendered **only the primary-language video**. The extra editions stopped at reviewed narration and timed-card bundles. Nothing turned them into videos.
- Language-specific channel profiles chosen in Create were saved in `language_editions.json` and then ignored.
- In Finishing Studio, an edition with no reviewed narration kept the **source video's voice**. Reproduced with a 440 Hz English voice: the Hindi export still spoke English.

## What 7.0.68 does

- After the primary video is rendered, every additional edition selected in Create is rendered automatically from:
  - the approved clean picture (no speech, captions, music or branding from the English render);
  - that edition's **reviewed narration** and measured word timings;
  - the edition's timed text cards and **word-timed captions in its own language**;
  - the channel profile chosen for that language in Create (logo, channel name in that language, optional intro and outro);
  - the primary production's background track, with its recorded licence, when one was used.
- Output: `outputs/<job>/language_editions/<plan>/exports/<lang>-<plan>.mp4`, plus a `.provenance.json` for each export. Each export is a new file and is never overwritten.
- `production/language_editions_render.json` records each language's status. Re-running reuses verified exports, so nothing is re-rendered needlessly.
- **Refusal instead of English.** An edition without its own reviewed narration is refused with a clear message. Nothing falls back to the source voice.
- **Length fit.** If a reviewed Hindi or Odia narration is longer than the approved picture, the picture is slowed by up to 25% so the whole narration is heard. Longer than that, the edition fails with a message asking for a shorter script. Cards and captions stay in narration time, so they remain in sync.
- **Create page.**
  - Extra editions require Voiceover and a reviewed, prepared language batch (step 4, "reuse this exact batch"). Otherwise submission is blocked, so no edition can silently have no voice.
  - Step 3 lets you pick a saved channel profile per language, or create one there: channel name, logo, and optional intro and outro.
  - Under the job, a "Language editions" panel shows each language's status and exports, with a button to render any pending editions. This also works for jobs created before this release.
- **Finishing Studio.** The source video's narration language is now declared. Any other edition needs its own reviewed narration.

## Using it

1. Create → Reels & Long Videos → choose the master language and up to two additional editions.
2. Approve the master script (step 2).
3. Step 3: choose or create a channel profile for each language (logo and name).
4. Step 4: approve each localized narration, click **Prepare all selected TTS → then all language text cards**, review every voice and card, and tick **reuse this exact batch**.
5. Create the production. Each selected language is rendered when the primary video finishes. Check the "Language editions" panel.

## Limits and review points

- Hindi and Odia wording still needs a fluent reviewer before publishing.
- Additional editions use the approved picture with that edition's narration, cards, captions and channel mark. Production-only extras (ambience, sound effects, graphics from the English timeline) are not carried over.
- The primary edition keeps the production render. Its channel logo comes from the Create-page profile, but its intro and outro are not added, to avoid changing the primary video.
- Live Gemini, TTS and browser flows were not exercised in this release. Automated tests use real FFmpeg media and synthetic narration.
- If an edition fails, the primary video is still produced and the job shows a warning naming the failed language.

## Verification

- `tests/test_v768_language_editions_render.py`: 10 tests with real FFmpeg media. They check:
  - each language gets its own narration (660 Hz Hindi and 880 Hz Odia voice fingerprints);
  - the length fit and its 25% limit;
  - refusal of a missing batch and of a voiceless edition;
  - profile-less editions;
  - re-run reuse;
  - the Create and factory wiring.
- Full suite: the same 24 pre-existing failures as v7.0.67 (fonts, browser and UI environment tests), with 10 new passing tests.

## Upgrading an installed 7.0.67 folder

Stop the dashboard first. Extract the 7.0.68 zip beside your installation folder, then run from the installation folder:

```
python3 ../AutoVideoAI-v7.0.68/tools/update_v767_to_v768.py .            # dry run: shows the plan
python3 ../AutoVideoAI-v7.0.68/tools/update_v767_to_v768.py . --apply    # installs the code
```

The updater replaces only the code and documentation files listed in its plan. Outputs, jobs, profiles, music, characters and channel data are never copied, moved or deleted. It refuses to run if a listed file was edited locally, if the installed version is not 7.0.67 (or an already-updated 7.0.68), or if the 7.0.68 zip is incomplete. Before replacing files it saves the previous code under `code-update-backups/v7.0.68-<timestamp>`, and it restores those files if an install step fails. Re-running after success reports "Already up to date" and changes nothing. Restart the dashboard afterwards.

"""Opt-in original sound accents; copy video and retain the source unchanged."""
from pathlib import Path
import json
import math
import subprocess
import tempfile
import wave
from ..production import digest, save

STYLES = ('soft', 'cinematic', 'punchy')


def synthesize(path, style):
    import numpy as np
    if style not in STYLES:
        raise ValueError('Unknown hook sound style')
    rate, seconds = 48000, 1.2
    t = np.arange(int(rate * seconds)) / rate
    rng = np.random.default_rng(752)
    tone = np.sin(2 * np.pi * (90*t + 80*t*t)) * np.exp(-5*t)
    air = rng.normal(0, .1, len(t)) * np.sin(np.pi*t/seconds)**2
    if style == 'soft':
        tone = .35*np.sin(2*np.pi*440*t)*np.exp(-4*t)
    elif style == 'punchy':
        tone += .4*np.sin(2*np.pi*55*t)*np.exp(-10*t)
    audio = (tone + air) * np.minimum(t/.015, 1) * np.minimum((seconds-t)/.08, 1)
    audio = audio / max(1, float(np.max(np.abs(audio)))) * .65
    pcm = np.repeat((audio*32767).astype('<i2')[:, None], 2, axis=1)
    with wave.open(str(path), 'wb') as out:
        out.setnchannels(2); out.setsampwidth(2); out.setframerate(rate)
        out.writeframes(pcm.tobytes())


def export_hooks(source, *, style='soft', opening=True, closing=True, volume=.18):
    if style not in STYLES or type(volume) not in (float, int) or not math.isfinite(volume) or not 0 < volume <= .5:
        raise ValueError('Choose a hook style and gain greater than zero, at most 0.5')
    if type(opening) is not bool or type(closing) is not bool or not (opening or closing):
        raise ValueError('Select an opening or closing accent')
    source = Path(source).expanduser().resolve()
    if not source.is_file():
        raise ValueError('Choose an existing local video')
    probe = subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(source)],
                           capture_output=True, text=True, timeout=30, check=True)
    info = json.loads(probe.stdout)
    if not any(s['codec_type'] == 'video' for s in info['streams']):
        raise ValueError('Source has no video')
    duration = float(info['format']['duration'])
    if not math.isfinite(duration) or not .5 <= duration <= 21600:
        raise ValueError('Unsupported source duration')
    parameters = dict(style=style, opening=opening, closing=closing, volume=float(volume))
    before = digest(source)
    import hashlib
    key = hashlib.sha256(json.dumps([before, parameters], sort_keys=True).encode()).hexdigest()[:16]
    output = source.with_name(source.stem + '-hooks-' + key + '.mp4')
    metadata = Path(str(output) + '.json')
    from ..review_lock import review_transaction
    with review_transaction(str(metadata)):
        if metadata.is_file() and output.is_file():
            saved = json.loads(metadata.read_text())
            if saved.get('output_sha256') == digest(output):
                return str(output)
        with tempfile.TemporaryDirectory(prefix='.hook-export-', dir=source.parent) as scratch:
            sound = Path(scratch)/'accent.wav'; synthesize(sound, style)
            target = Path(scratch)/'result.mp4'
            positions = ([0.0] if opening else [])
            if closing and (not opening or duration >= 3):
                positions.append(max(0, duration - 1.2))
            filters, labels = [], []
            if any(s['codec_type'] == 'audio' for s in info['streams']):
                filters.append('[0:a:0]aresample=48000,aformat=channel_layouts=stereo[original]')
                labels.append('[original]')
            filters.append('[1:a]asplit=' + str(len(positions)) + ''.join(f'[h{i}]' for i in range(len(positions))))
            for i, at in enumerate(positions):
                filters.append(f'[h{i}]volume={volume},adelay={int(at*1000)}:all=1[hook{i}]')
                labels.append(f'[hook{i}]')
            filters.append(''.join(labels) + f'amix=inputs={len(labels)}:normalize=0,alimiter=limit=0.95:level=0,apad,atrim=duration={duration}[mix]')
            command = ['ffmpeg','-v','error','-nostdin','-y','-i',str(source),'-i',str(sound),
                '-filter_complex',';'.join(filters),'-map','0:v:0','-map','[mix]',
                '-c:v','copy','-c:a','aac','-b:a','192k','-t',str(duration),'-movflags','+faststart',str(target)]
            subprocess.run(command, capture_output=True, text=True, timeout=300, check=True)
            if digest(source) != before:
                raise RuntimeError('Source changed during export; retry from the reviewed video')
            from ..providers.flow_browser import FlowBrowserProvider
            if not FlowBrowserProvider._is_valid_video_file(str(target)):
                raise RuntimeError('Sound export failed video validation')
            target.replace(output)
        save(metadata, {'source':str(source),'source_sha256':before, 'output_sha256':digest(output),
             'parameters':parameters,'positions':positions,'provenance':'Original procedural sound, generated locally; no sampled song or Flow request'})
    return str(output)


def hook_panel(st, source, key):
    with st.expander('Opening and closing sound hooks · optional'):
        st.caption('Creates a separate copy with original synthesized accents. Adds audio even if the source is silent; no Flow credits.')
        style = st.selectbox('Sound style', STYLES, key=key+'-style')
        opening = st.checkbox('Opening accent', value=True, key=key+'-open')
        closing = st.checkbox('Closing accent', value=True, key=key+'-close')
        volume = st.slider('Hook gain', .01, .5, .18, .01, key=key+'-gain')
        if st.button('Create copy with sound hooks', key=key+'-export'):
            try:
                with st.spinner('Mixing sound accents into a separate copy…'):
                    st.session_state[key+'-result'] = export_hooks(source, style=style, opening=opening, closing=closing, volume=volume)
            except Exception as error:
                st.error('Sound export failed: '+str(error)[:300])
        output = st.session_state.get(key+'-result')
        if output and Path(output).is_file():
            st.video(output, width=320)
            st.download_button('Download sound-hook copy', Path(output).read_bytes(), file_name=Path(output).name, mime='video/mp4', key=key+'-download')

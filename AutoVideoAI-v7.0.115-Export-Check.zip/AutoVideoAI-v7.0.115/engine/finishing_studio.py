"""Review-gated, non-destructive finishing of existing videos and clips.

The plan is durable. Source and optional assets are snapshotted before rendering;
no Flow generation, social upload, or browser action occurs here.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
import uuid

LANGUAGES = {'en': 'English', 'hi': 'Hindi', 'or': 'Odia'}

# v7.0.107: edition sound defaults. A music bed fades in, dips hard under speech and returns in the pauses,
# then fades out; the finished mix is normalised to the same -14 LUFS target as the English master.
EDITION_SOUND_DEFAULTS = {'fade_in': 1.0, 'fade_out': 2.5, 'threshold': 0.02, 'ratio': 12.0,
                          'attack_ms': 15, 'release_ms': 550}
MEDIA_EXT = {'.mp4', '.mov', '.mkv', '.webm', '.mp3', '.wav', '.m4a', '.ogg', '.flac', '.png', '.jpg', '.jpeg', '.webp'}


def shared_root():
    return Path(os.getenv('AUTOVIDEO_SHARED_ROOT') or Path('outputs').resolve().parent).expanduser().resolve()


def _hash(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def _tool(name):
    """Path to ffmpeg/ffprobe. 7.0.95: ffmpeg falls back to the bundled imageio binary.

    The main renderer always used ``imageio_ffmpeg`` when PATH had no ffmpeg, but
    the finishing/edition renderer called a bare ``ffmpeg`` and failed on those
    machines even though the English master rendered. Editions now find the same
    binary. ffprobe has no bundled equivalent because ffmpeg can report a file
    without it only partially; the clear error below names the missing tool.
    """
    found = shutil.which(name)
    if found:
        return found
    if name == 'ffmpeg':
        try:
            import imageio_ffmpeg
            return imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            pass
    raise RuntimeError(name + ' was not found on PATH. Install FFmpeg (ffmpeg and ffprobe) and restart the dashboard; '
                             'language editions and the finishing studio need both.')


def _probe(path):
    p = subprocess.run([_tool('ffprobe'), '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(path)], capture_output=True, text=True, timeout=30)
    if p.returncode:
        raise ValueError('Media is not readable: ' + str(path))
    info = json.loads(p.stdout)
    return info, float(info.get('format', {}).get('duration') or 0)


def _span(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _stream_seconds(info):
    """How long each track of a file really is, from the streams (v7.0.115).

    ``format.duration`` is the container's opinion, and it is a single number for two tracks that can differ.
    The export check needs them apart: a picture that stops early and a narration that stops early are different
    defects with different repairs, and a container that merely disagrees with both is neither.
    """
    spans = {}
    for stream in (info or {}).get('streams') or []:
        kind = str(stream.get('codec_type') or '')
        if kind not in ('video', 'audio'):
            continue
        seconds = _span(stream.get('duration'))
        if seconds <= 0:
            seconds = _span(stream.get('tags', {}).get('DURATION_TS') if isinstance(stream.get('tags'), dict)
                            else 0)
        if seconds > 0 and seconds > spans.get(kind, 0.0):
            spans[kind] = seconds
    return spans


def _clock(seconds):
    """m:ss, for a message a person reads."""
    seconds = max(0.0, _span(seconds))
    return f'{int(seconds // 60)}:{seconds % 60:04.1f}'


def export_qc_report(path, expected, *, fit_report=None, video_padded=0.0, tolerance=0.8):
    """Compare a finished export's two tracks with the timeline it was built from (v7.0.115).

    The old check was one line - ``if abs(duration - expected) > 0.8 or no audio: raise ValueError('Export QC
    failed: duration or audio')`` - and it threw away the finished file with the temporary folder. After a
    fifty-nine minute render the field report was therefore five words long and the video no longer existed.
    Now the numbers are kept, the file is kept, and the reason is named.

    ``problems`` is what must stop the export; ``notes`` is what is worth saying but does not.
    """
    info, container = _probe(path)
    spans = _stream_seconds(info)
    kinds = {str(stream.get('codec_type') or '') for stream in (info or {}).get('streams') or []}
    container = _span(container)
    # A stream that does not state its own duration is not a broken stream: fall back to the container rather than
    # inventing a defect. Only a track that is *absent* is a finding.
    video = spans.get('video') or (container if 'video' in kinds else 0.0)
    audio = (spans.get('audio') or container) if 'audio' in kinds else None
    problems, notes = [], []
    if audio is None:
        problems.append('the finished file has no audio track')
    if video <= 0:
        problems.append('the finished file has no readable picture')
    duration = round(container, 3)
    if video > 0 and video < expected - tolerance:
        problems.append(f'the picture stops at {_clock(video)} but the timeline runs to {_clock(expected)}')
    if audio is not None and audio < expected - tolerance:
        problems.append(f'the audio stops at {_clock(audio)} but the timeline runs to {_clock(expected)}')
    if not problems and abs(duration - expected) > tolerance:
        # Both tracks are right and only the container's own duration disagrees. That is a muxer quirk, not a
        # broken video, and re-rendering it for an hour would produce the same file.
        notes.append(f'the file header says {_clock(duration)} while its tracks run to {_clock(max(video, audio or 0))}'
                     '; the tracks are what plays')
    fit = dict(fit_report or {})
    report = {'expected_seconds': round(_span(expected), 3), 'container_seconds': duration,
              'video_seconds': round(video, 3), 'audio_seconds': None if audio is None else round(audio, 3),
              'tolerance_seconds': tolerance, 'problems': problems, 'notes': notes,
              'video_padded_seconds': round(_span(video_padded), 3),
              'fit_mode': fit.get('mode'), 'fit_picture_scale': fit.get('picture_scale'),
              'fit_tempo': fit.get('tempo'), 'fit_hold_seconds': fit.get('hold_seconds'),
              'checked_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    return report


def export_qc_message(report, *, language_label='this language', kept_path=''):
    """The sentence a failed export is reported with: the numbers, the cause, and where the file went."""
    problems = list(report.get('problems') or [])
    lines = ['Export QC failed: ' + '; '.join(problems) + '.',
             f'Expected a {_clock(report["expected_seconds"])} {language_label} video and got '
             f'{_clock(report["container_seconds"])} (picture {_clock(report["video_seconds"])}, '
             + ('no audio' if report.get('audio_seconds') is None else 'audio ' + _clock(report['audio_seconds']))
             + ').']
    if report.get('fit_mode') and report.get('fit_mode') != 'none':
        lines.append(f'The narration had been fitted to the picture (picture x{report.get("fit_picture_scale")}, '
                     f'narration x{report.get("fit_tempo")}'
                     + (f', last frame held {report.get("fit_hold_seconds")}s'
                        if report.get('fit_hold_seconds') else '') + ').')
    if report.get('video_padded_seconds'):
        lines.append(f'The picture was already extended by {report["video_padded_seconds"]:.2f}s to meet the '
                     'narration, and it still came up short.')
    if kept_path:
        lines.append('The file this render produced is kept at ' + str(kept_path) +
                     ' - it is complete enough to play, but it is not marked current because it failed this check.')
    lines.append('Nothing was deleted. The check compares the finished file with the timeline it was built from, '
                 'so a language can be rendered again from its saved narration: no voice is re-recorded and no '
                 'Flow credit is spent.')
    return '\n'.join(lines)


def _snapshot(path, folder, kind):
    path = Path(path).expanduser().resolve(strict=True)
    if not path.is_file() or path.is_symlink() or path.suffix.lower() not in MEDIA_EXT or not path.stat().st_size:
        raise ValueError('Invalid ' + kind + ' file')
    if kind.startswith('logo'):
        from PIL import Image
        with Image.open(path) as img: img.verify()
        info, duration = {}, 0
    else:
        info, duration = _probe(path)
    wanted = ('audio' if kind.startswith(('narration', 'music', 'shared-music'))
              else 'video' if kind.startswith(('source', 'intro', 'outro')) else None)
    if wanted and (not any(s.get('codec_type') == wanted for s in info.get('streams', [])) or duration <= 0):
        raise ValueError(kind + ' needs playable ' + wanted)
    sha = _hash(path)
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    dest = folder / (kind + '-' + sha[:20] + path.suffix.lower())
    if not dest.exists():
        tmp = dest.with_name('.' + dest.name + '-' + uuid.uuid4().hex)
        shutil.copyfile(path, tmp)
        os.replace(tmp, dest)
    return {'path': str(dest.resolve()), 'sha256': sha, 'duration': duration}


def _json_snapshot(path, folder, kind):
    """Immutable copy of reviewed word timings; verified like every other asset."""
    path = Path(path).expanduser().resolve(strict=True)
    if not path.is_file() or path.is_symlink():
        raise ValueError('Invalid ' + kind + ' file')
    sha = _hash(path)
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    dest = folder / (kind + '-' + sha[:20] + '.json')
    if not dest.exists():
        tmp = dest.with_name('.' + dest.name + '-' + uuid.uuid4().hex)
        shutil.copyfile(path, tmp)
        os.replace(tmp, dest)
    return {'path': str(dest.resolve()), 'sha256': sha, 'duration': 0}


def save_profile(name, *, names=None, logo='', intro='', outro='', music='', music_license='', root=None,
                 logos=None, slug_suffix=''):
    """Create a shared channel profile; optional media becomes immutable snapshots.

    7.0.95: ``logos`` maps a language code to its own logo file. Each logo is
    stored as ``assets['logo-<lang>']`` next to the shared ``assets['logo']`` so
    one channel can carry an English, Hindi and Odia mark. ``slug_suffix`` keeps
    a per-language variant apart when the same channel name is used three times.
    """
    root = Path(root or shared_root() / 'channel_profiles').resolve()
    slug = re.sub(r'[^a-z0-9-]', '-', name.lower().strip()).strip('-')[:60]
    if slug and slug_suffix:
        slug = re.sub(r'[^a-z0-9-]', '-', (slug + '-' + str(slug_suffix)).lower()).strip('-')[:60]
    if not slug or not name.strip():
        raise ValueError('Enter a channel name')
    folder = root / slug; folder.mkdir(parents=True, exist_ok=True)
    existing = {}
    if (folder / 'profile.json').is_file():
        existing = json.loads((folder / 'profile.json').read_text(encoding='utf8'))
        for asset in existing.get('assets', {}).values(): _verified(asset)
    data = {'schema_version': 1, 'id': slug, 'name': name.strip()[:120],
            'names': {lang: str((names or {}).get(lang) or existing.get('names', {}).get(lang) or name).strip()[:120]
                      for lang in LANGUAGES},
            'assets': dict(existing.get('assets', {}))}
    if music and not str(music_license).strip():
        raise ValueError('Record the music source and permission')
    data['music_license'] = str(music_license or existing.get('music_license', '')).strip()[:500]
    for kind, value in [('logo', logo), ('intro', intro), ('outro', outro), ('music', music)]:
        if value:
            data['assets'][kind] = _snapshot(value, folder / 'assets', kind)
    for language, value in (logos or {}).items():
        language = str(language or '').lower()
        if language not in LANGUAGES:
            raise ValueError('A language logo needs English, Hindi or Odia')
        if value:
            data['assets']['logo-' + language] = _snapshot(value, folder / 'assets', 'logo-' + language)
    _atomic_json(folder / 'profile.json', data)
    return folder / 'profile.json'


def _atomic_json(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.saving-', suffix='.json')
    try:
        with os.fdopen(fd, 'w', encoding='utf8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2); fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)


def profiles(root=None):
    root = Path(root or shared_root() / 'channel_profiles')
    return sorted(root.glob('*/profile.json')) if root.is_dir() else []


def create_plan(source, profile_path, *, languages=('en',), output_root=None,
                source_rights='own_content', shared_music=None, shared_music_license='',
                source_language=None, require_profiles=True, fit_narration=False, captions=False,
                use_clean_master=True, editorial=True, fit_policy=None):
    """A profile may be a single path or a language->profile path mapping.

    ``source_language`` names the language spoken in the source picture's own
    narration. Any other edition must carry its own reviewed narration; render()
    refuses to export it with the source voice. ``fit_narration`` lets a longer
    reviewed narration stretch the approved picture (bounded, see render()).
    ``captions`` burns word-timed captions from each edition's reviewed narration.
    """
    if source_rights not in ('own_content', 'licensed', 'creative_commons'):
        raise ValueError('Review and declare source rights')
    languages = list(dict.fromkeys(languages))
    if not languages or any(lang not in LANGUAGES for lang in languages):
        raise ValueError('Choose English, Hindi or Odia editions')
    if source_language is not None and source_language not in LANGUAGES:
        raise ValueError('Source language must be English, Hindi or Odia')
    selection = profile_path if isinstance(profile_path, dict) else {lang: profile_path for lang in languages}
    if require_profiles and any(lang not in selection or not selection[lang] for lang in languages):
        raise ValueError('Choose an actual channel profile for each language edition')
    original_source = Path(source).resolve()
    job_root = original_source.parent.parent if original_source.parent.name == 'render' else original_source.parent
    clean_record = job_root / 'production' / 'visual_master.json'
    if use_clean_master and clean_record.is_file() and original_source.parent.name == 'render' and ('-final' in original_source.stem or original_source.name == 'visual-master.mp4'):
        record = json.loads(clean_record.read_text(encoding='utf8'))
        if Path(record['path']).is_file() and _hash(record['path']) == record['sha256']:
            source = record['path']
        else:raise ValueError('Clean visual master is missing or changed; render the production again')
    folder = Path(output_root or shared_root() / 'outputs' / 'finishing') / (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
    asset_dir = folder / 'assets'
    source_asset = _snapshot(source, asset_dir, 'source')
    shared = None
    if shared_music:
        if not str(shared_music_license).strip():
            raise ValueError('Record the shared music source and permission')
        shared = _snapshot(shared_music, asset_dir, 'shared-music')
    editions = {}
    for lang in languages:
        if selection.get(lang):
            profile = json.loads(Path(selection[lang]).read_text(encoding='utf8'))
            if profile.get('schema_version') != 1 or not profile.get('name'):
                raise ValueError('Unsupported channel profile for '+lang)
        else:
            # Optional in automatic editions: no logo, name, intro or outro is invented.
            profile = {'schema_version': 1, 'name': '', 'names': {}, 'assets': {}}
        assets = {}
        for kind, entry in profile.get('assets', {}).items():
            if kind in ('logo', 'intro', 'outro', 'music') or kind.startswith('logo-'):
                _verified(entry)
                assets[kind] = _snapshot(entry['path'], asset_dir, kind+'-'+lang)
        editions[lang] = {'channel': {'name': profile['name'], 'display_name': profile.get('names', {}).get(lang) or profile['name']},
                          'assets': assets, 'profile_music_license': profile.get('music_license',''),
                          'cards': [], 'narration': None, 'music': None, 'words': None,
                          'intro': bool(assets.get('intro')), 'outro': bool(assets.get('outro')), 'reviewed': False,
                          'cards_warning': ''}
    edition_file = job_root / 'production' / 'language_editions.json'
    # v7.0.112: one card style for every language - the one the English master drew.
    job_card_style = _job_card_style(job_root)
    if editorial and edition_file.is_file():
        language_state = json.loads(edition_file.read_text(encoding='utf8'))
        job_card_style = _job_card_style(job_root, language_state) or job_card_style
        prepared = language_state.get('bundles', {})
        for lang, edition in editions.items():
            bundle = prepared.get(lang)
            if bundle:
                if _hash(bundle['audio']) != bundle.get('audio_sha256'):
                    raise ValueError('Prepared language narration changed; prepare it again')
                edition['narration'] = _snapshot(bundle['audio'], asset_dir, 'narration-'+lang)
                bundle_folder = Path(bundle['audio']).parent
                want_cards = bool(language_state.get('text_cards', True))
                edition['cards_warning'] = ''
                if want_cards and not bundle.get('text_cards', True):
                    # 7.0.95: a batch prepared without cards used to stop every language.
                    # This edition renders without text cards and says why; the others are unaffected.
                    want_cards = False
                    edition['cards_warning'] = (LANGUAGES[lang] + ' was prepared without text cards, so this '
                                                'edition renders without them. Prepare that language batch again '
                                                'with text cards on to add them.')
                edition['text_cards'] = want_cards
                edition['cards'] = list(bundle.get('cards') or []) if want_cards else []
                edition['educational'] = bool(bundle.get('educational', False)) and want_cards
                edition['topic'] = str(bundle.get('topic', '') or '')
                edition['speech_cards'] = None
                # v7.0.107: any prepared language gets its reviewed speech cards, not only educational
                # videos - the pop-up cards are the whole point of drafting them.
                cards_file = bundle_folder / 'production' / 'speech_cards.json'
                if want_cards and cards_file.is_file():
                    edition['speech_cards'] = _json_snapshot(cards_file, asset_dir, 'speech-cards-' + lang)
                elif edition['educational']:
                    # Missing points file: keep the plain cards, drop the points series.
                    edition['educational'] = False
                    edition['cards_warning'] = (edition['cards_warning'] + ' ' if edition['cards_warning'] else '') + \
                        (LANGUAGES[lang] + ' educational points were not saved, so this edition uses its '
                         'plain text cards. Prepare that language batch again to restore the points series.')
                edition['hooks'] = None
                edition['hook_warning'] = ''
                if language_state.get('hooks_enabled', False):
                    hooks_file = bundle_folder / 'production' / 'hooks.json'
                    if bundle.get('hooks_ready') and hooks_file.is_file():
                        edition['hooks'] = _json_snapshot(hooks_file, asset_dir, 'hooks-' + lang)
                    else:
                        edition['hook_warning'] = str(bundle.get('hooks_error') or
                            'Hooks were not prepared for this language; this edition has no hooks.')
                edition['script'] = bundle['script']
                edition['card_style'] = str(bundle.get('card_style') or job_card_style or '') or None
                edition['captions_burned'] = bool(captions)
                edition['timing_source'] = bundle.get('timing_source','unverified')
                if bundle.get('words') and Path(bundle['words']).is_file():
                    edition['words'] = _json_snapshot(bundle['words'], asset_dir, 'words-'+lang)
                edition['reviewed'] = False
    plan = {'schema_version': 2, 'state': 'draft', 'source_rights': source_rights,
            'source': source_asset, 'shared_music': shared,
            'shared_music_license': str(shared_music_license).strip()[:500],
            'source_language': source_language, 'fit_narration': bool(fit_narration),
            # 7.0.107: bounded retiming budget for a longer narration (see engine/narration_fit.py).
            'fit_policy': dict(fit_policy or {}),
            'captions': bool(captions),
            # v7.0.112: the English master's card style, so a Hindi or Odia card looks like it.
            'card_style': job_card_style or None,
            'editions': editions, 'music_volume': 0.12,
            'branding_motion': True,
            # 7.0.109: editions carry the same animated channel badge as the primary master; set False for the
            # old plain text mark.
            'branding_badge': True,
            'created_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    _atomic_json(folder / 'plan.json', plan)
    return folder / 'plan.json'


CARD_STYLES = ('bold', 'playful', 'clean')


def _job_card_style(job_root, state=None):
    """The card style this job's English master used, so an edition can match it (v7.0.112).

    Read from the saved language state first (when the app wrote it), then from the production's own
    ``publish_readiness.json`` (``text_card_style`` is the resolved style the primary render actually drew).
    Returns ``''`` when neither is known, and the caller falls back to its own default.
    """
    candidates = []
    if isinstance(state, dict):
        candidates.append(state.get('card_style'))
    try:
        readiness = json.loads((Path(job_root) / 'production' / 'publish_readiness.json').read_text(encoding='utf8'))
        candidates.append(readiness.get('text_card_style'))
    except (OSError, ValueError):
        pass
    for value in candidates:
        value = str(value or '').strip().lower()
        if value in CARD_STYLES:
            return value
    return ''


def _edition_card_style(edition):
    """The style one edition draws its cards with: explicit, else the job's, else playful for education."""
    value = str(edition.get('card_style') or '').strip().lower()
    if value in CARD_STYLES:
        return value
    if bool(edition.get('educational')):
        return 'playful'
    return 'bold'


def _job_transcript_choice(plan_path, language):
    """The saved job's transcript choice for one edition, or None when this plan is not part of a saved job.

    v7.0.111: the job's setting is the truth, not the plan's. A plan is a snapshot - one built yesterday with
    captions on can be rendered today, after the transcript was switched off, and it would happily burn the
    captions the user just removed. ``None`` means "this plan is not governed by a job setting" (a standalone
    Finishing Studio plan), and then the plan decides, exactly as before.
    """
    try:
        plan_path = Path(plan_path).resolve()
    except OSError:
        return None
    job = None
    for parent in list(plan_path.parents)[:5]:
        if (parent / 'production' / 'language_editions.json').is_file():
            job = parent
            break
    if job is None:
        return None
    try:
        from engine.language_editions import requested_languages, transcript_for
        _source, extra, state = requested_languages(job)
        if state is None or str(language) not in extra:
            return None
        return transcript_for(state, language)
    except Exception:      # a damaged state file must not silently change what is burned
        return None


def _verified(entry):
    path = Path(entry['path']).resolve(strict=True)
    if path.is_symlink() or _hash(path) != entry['sha256']:
        raise ValueError('Saved media changed; recreate the plan')
    return path


def set_edition(plan_path, language, *, cards=None, narration=None, music=None, intro=None, outro=None,
                reviewed=False, music_license=None):
    plan_path = Path(plan_path).resolve()
    plan = json.loads(plan_path.read_text(encoding='utf8'))
    if language not in plan['editions']:
        raise ValueError('Language was not selected for this plan')
    edition = plan['editions'][language]
    if cards is not None:
        source_duration = plan['source']['duration']
        checked = []
        for row in cards:
            text = str(row.get('text', '')).strip()
            start, end = float(row['start']), float(row['end'])
            if not text or len(text) > 160 or not 0 <= start < end <= source_duration or end-start > 12:
                raise ValueError('Card text or timing is invalid')
            checked.append({'text': text, 'start': start, 'end': end})
        if len(checked) > 30:
            raise ValueError('Too many text cards')
        edition['cards'] = checked
    if narration:
        edition['narration'] = _snapshot(narration, plan_path.parent / 'assets', 'narration-' + language)
    if music == '':
        edition['music'] = None
        edition.pop('music_license', None)
    elif music:
        if not music_license or not str(music_license).strip():
            raise ValueError('Record music source and permission before use')
        edition['music'] = _snapshot(music, plan_path.parent / 'assets', 'music-' + language)
        edition['music_license'] = str(music_license).strip()[:500]
    if intro is not None: edition['intro'] = bool(intro)
    if outro is not None: edition['outro'] = bool(outro)
    edition['reviewed'] = bool(reviewed)
    plan['state'] = 'reviewed' if any(e.get('reviewed') for e in plan['editions'].values()) else 'draft'
    _atomic_json(plan_path, plan)
    return plan_path


def propose_cards(transcript, duration, language, *, cleanup='delete-after-read'):
    """Optional text-only Gemini draft. The user must review/set the timing."""
    if language not in LANGUAGES or not transcript.strip() or not 1 <= duration <= 7200:
        raise ValueError('Provide transcript, language and duration')
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    raw = gemini_web_generate(
        'Suggest sparse, short, useful overlay text cards for an existing video. JSON only. '
        'Never invent claims, sources, rights or download links. Keep the video visible. '
        'Return {"cards":[{"start":0,"end":2,"text":"..."}],"music_mood":"..."}. '
        'Use seconds relative to the supplied video. The result is a draft for human review.',
        'Language: '+LANGUAGES[language]+'\nDuration seconds: '+str(duration)+'\nTranscript/context:\n'+transcript[:18000],
        cleanup=cleanup)
    result = _extract_json(raw)
    if not isinstance(result, dict) or not isinstance(result.get('cards'), list):
        raise ValueError('Gemini did not return cards')
    return result


WRITE_ERRORS = ('input/output error', 'no space left on device', 'error writing', 'cannot write',
                'error opening output', 'no such file or directory', 'permission denied',
                'read-only file system', 'disk quota exceeded')


def disk_note(cmd):
    """v7.0.114: how much room the volume FFmpeg was writing to has right now.

    Field report: the Odia repair render stopped after two minutes with ``av_interleaved_write_frame(): Input/output
    error ... Error writing trailer of ... picture-fit.mp4``. That is what FFmpeg says when the volume cannot take
    the rest of the file - a full disk, a full quota, or a read-only / disconnected folder. The message named the
    temp file and nothing else, so the only thing to do with it was guess. This returns a factual line about the
    volume and, only when the text really is a write error, what it usually means and how to retry.
    """
    target = None
    try:
        target = Path(str(cmd[-1]))
    except (IndexError, ValueError):
        pass
    folder = target.parent if target is not None else None
    while folder is not None and not folder.is_dir():
        folder = folder.parent if folder.parent != folder else None
    if folder is None:
        return ''
    try:
        total, used, free = shutil.disk_usage(str(folder))
    except OSError:
        return ''
    gb = 1024.0 ** 3
    return ('\nThe file being written was ' + str(target) + '. Disk free on that volume: '
            + f'{free / gb:.1f} GB free of {total / gb:.1f} GB (' + str(folder) + ').')


def _write_hint(cmd, err):
    """The volume line, plus what a write error means, for a failed FFmpeg run (v7.0.114)."""
    note = disk_note(cmd)
    lowered = str(err or '').lower()
    if any(marker in lowered for marker in WRITE_ERRORS):
        note += ('\nThis is what a full or read-only volume looks like to FFmpeg ("Input/output error", '
                 '"No space left on device"). Free space there - the earlier exports and the working copies in '
                 'render/ are the biggest files - or point the outputs folder at another disk, then run the same '
                 'command again: finished languages are not redone, no voice is re-recorded and no Flow credit is '
                 'spent.')
    return note


def _run(cmd, progress=None, duration=None):
    if progress and duration:
        cmd = cmd[:-1] + ['-progress', 'pipe:1', '-nostats', cmd[-1]]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        # FFmpeg stderr is bounded by -loglevel error; drain at process completion.
        for line in p.stdout:
            if line.startswith('out_time_ms='):
                try: progress(min(0.99, int(line.split('=', 1)[1]) / 1e6 / duration))
                except (ValueError, TypeError): pass
        err = p.stderr.read(); result = p.wait()
        if result:
            raise RuntimeError('FFmpeg failed: ' + err[-1200:] + _write_hint(cmd, err))
    finally:
        if p.poll() is None:
            p.kill(); p.wait()
        p.stdout.close(); p.stderr.close()


def _fit_picture_cmd(src, dest, *, picture_scale, hold_seconds, seconds):
    """The retimed picture an edition is built from when its narration is longer than the source (v7.0.114).

    This is a working file: it is decoded again a moment later to make the normalised segments, so it is written
    without ``+faststart``. Faststart rewrites the whole file a second time at the end (which is the moment the
    field render failed, "Error writing trailer"), costs another picture-sized write on the exact volume that was
    already short of room, and buys nothing for a file nobody plays.
    """
    chain = f'setpts={picture_scale:.6f}*PTS'
    if hold_seconds > 0:
        chain += f',tpad=stop_mode=clone:stop_duration={hold_seconds:.3f}'
    return [_tool('ffmpeg'), '-y', '-hide_banner', '-loglevel', 'error', '-i', str(src), '-an',
            '-vf', chain, '-t', f'{seconds:.3f}',
            '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', str(dest)]


def _card_image(text, width, height, path, language, *, style='playful', captions=True):
    """Draw one edition card with the same renderer as the English master (v7.0.112).

    The editions used to draw their own navy panel with white text at 72% of the height, while the English master
    used the shared playful card - which is why the two looked different. There is now one card: same palette,
    same accent rail, same type, same band (see ``engine.render.card_band``), for every language.
    """
    from engine.render.graphics import OverlayEvent, render_overlay_png
    event = OverlayEvent('keypoint', 0, 1, ' '.join(str(text or '').split()), anchor='top-left',
                         layout={'captions': bool(captions)})
    try:
        render_overlay_png(event, str(path), width, height, style=style)
    except ValueError as error:
        raise ValueError('Card is too long for the frame (' + str(error) + '): ' + str(text)[:80]) from error
    return event


def _edition_overlays(edition, language, voice, words_path, width, height, tmp_dir, legacy_cards,
                      duration=None, stats=None):
    """Points series, single cards and hook pills for one edition, drawn from its saved reviewed data (7.0.77).

    Uses the same renderers as the main video, into a scratch root inside the export's temporary folder.
    Narration timings are returned; _add_overlays shifts them past any intro. ``stats`` (a dict, when given)
    is filled with what was placed and what was dropped, so the export can explain its own graphics.
    """
    stats = stats if stats is not None else {}
    stats.setdefault('cards', 0)
    stats.setdefault('hooks', 0)
    stats.setdefault('dropped_hooks', 0)
    if not (edition.get('speech_cards') or edition.get('hooks')):
        return []
    if voice is None or words_path is None:
        raise ValueError(LANGUAGES[language] + ' cards and hooks need its reviewed narration and word timings.')
    from engine.speech_cards import render as render_cards
    from engine.video_hooks import build_hook_overlays
    root = Path(tmp_dir) / 'overlay-root'
    (root / 'production').mkdir(parents=True, exist_ok=True)
    words = json.loads(Path(words_path).read_text(encoding='utf8'))
    audio = _verified(voice)
    duration = float(duration if duration is not None else voice['duration'])
    # v7.0.107: the edition keeps its own card kinds and palette; a plain video is not turned educational
    # just because it is being exported in another language.
    educational = bool(edition.get('educational'))
    # v7.0.112: the edition uses the card style the English master used, not a hard-coded 'bold'.
    style = _edition_card_style(edition)
    overlays = []
    if edition.get('speech_cards'):
        shutil.copyfile(_verified(edition['speech_cards']), root / 'production' / 'speech_cards.json')
        overlays = render_cards(root, audio, words, edition['script'], duration, width, height, style,
                                educational=educational, topic=edition.get('topic', ''),
                                language=language, captions=bool(edition.get('captions_burned', True))) or []
    stats['cards'] = len(overlays)
    if edition.get('hooks'):
        shutil.copyfile(_verified(edition['hooks']), root / 'production' / 'hooks.json')
        existing = overlays + [{'kind': 'keypoint', 'start': c['start'], 'end': c['end']} for c in legacy_cards]
        hook_overlays, dropped = build_hook_overlays(root, audio, words, edition['script'], duration, width, height,
                                                     style, existing, topic=edition.get('topic', ''),
                                                     language=language)
        stats['dropped_hooks'] = int(dropped or 0)
        stats['hooks'] = len(hook_overlays)
        overlays = overlays + hook_overlays
    return overlays


def _retime_overlays(overlays, tempo):
    """Move cards and hooks with a sped-up narration (v7.0.108).

    Cards are drafted and anchored against the reviewed narration's own word timings. When that narration is
    sped up to fit the picture, its word times shrink by the same factor - so the placed overlays must shrink
    too. Retiming here (instead of feeding rescaled words to the card renderer) keeps the drafted fingerprint
    valid, which is what broke the Odia edition in 7.0.107.
    """
    tempo = float(tempo or 1.0)
    if abs(tempo - 1.0) < 1e-6:
        return [dict(event) for event in overlays or []]
    retimed = []
    for event in overlays or []:
        row = dict(event)
        for key in ('start', 'end'):
            if isinstance(row.get(key), (int, float)):
                row[key] = round(float(row[key]) / tempo, 3)
        retimed.append(row)
    return retimed


def _add_overlays(cmd, filters, current, inp, overlays, width, height, offset):
    """Add picture-timed PNG overlays with the main renderer's pop/open/close animation and fades."""
    from engine.render.ffmpeg_renderer import _pop_chain
    for index, e in enumerate(overlays):
        cmd += ['-loop', '1', '-framerate', '30', '-i', str(e['path'])]
        st = offset + float(e['start']); en = offset + float(e['end'])
        span = en - st
        fade_in = min(span / 2, float(e.get('fade_in', 0) or 0))
        fade_out = min(span / 2, float(e.get('fade_out', 0) or 0))
        window = f"enable='between(t,{st:.3f},{en:.3f})':shortest=1"
        if e.get('anim') in ('pop', 'open', 'close') and e.get('box'):
            chain, place = _pop_chain(e, st, en, width, height, inp, fade_in, fade_out)
            filters.append(chain + f'[ed{index}]')
            filters.append(f"[{current}][ed{index}]overlay={place}:{window}[v{inp}]")
        else:
            chain = f'[{inp}:v]scale={width}:{height},format=rgba'
            if fade_in:
                chain += f',fade=t=in:st={st:.3f}:d={fade_in:.3f}:alpha=1'
            if fade_out:
                chain += f',fade=t=out:st={en - fade_out:.3f}:d={fade_out:.3f}:alpha=1'
            filters.append(chain + f'[ed{index}]')
            filters.append(f"[{current}][ed{index}]overlay=0:0:{window}[v{inp}]")
        current = f'v{inp}'; inp += 1
    return cmd, filters, current, inp


def render(plan_path, language, *, progress=None, fit_policy=None):
    """Render one edition to a new output. Exact snapshots and reviewed plan required.

    Language editions (``plan['source_language']`` set) never fall back to the
    source video's voice: the edition must carry its own reviewed narration.
    When ``plan['fit_narration']`` is set, a longer reviewed narration is fitted
    onto the approved picture by bounded retiming (``engine/narration_fit.py``):
    the picture is slowed, the narration is sped up with pitch preserved, and -
    only when allowed - the last frame is cloned for the remainder. Word timings
    are divided by the narration speed so cards and captions stay in sync.
    """
    plan_path = Path(plan_path).resolve(); plan = json.loads(plan_path.read_text(encoding='utf8'))
    if plan['state'] != 'reviewed': raise ValueError('Review the plan and approve its cards/assets before render')
    if language not in plan['editions']: raise ValueError('Edition unavailable')
    if not plan['editions'][language].get('reviewed'): raise ValueError('This language edition needs review')
    src = _verified(plan['source']); edition = plan['editions'][language]
    source_language = plan.get('source_language')
    if source_language and language != source_language and not edition.get('narration'):
        raise ValueError(LANGUAGES[language] + ' edition has no reviewed narration. It is not exported with the '
                         + LANGUAGES[source_language] + ' source voice; prepare and approve its narration first.')
    edition_assets = edition.get('assets', plan.get('assets', {}))
    assets = {k:_verified(v) for k,v in edition_assets.items()}
    for key in ('narration','music'):
        if edition.get(key): _verified(edition[key])
    voice = edition.get('narration')
    words_path = _verified(edition['words']) if edition.get('words') and plan.get('captions') else None
    words_src = _verified(edition['words']) if edition.get('words') else None
    # v7.0.110: a corrected transcript (production/transcripts/<language>.json, snapshotted into the plan)
    # replaces the word text for captions only. Cards and hooks keep the timings they were drafted from.
    caption_edit = None
    if words_path and edition.get('caption_words'):
        caption_edit = _verified(edition['caption_words'])
        words_path = caption_edit
    # v7.0.111: the job's transcript setting wins over a stale plan. Never burn captions the job switched off.
    job_captions = _job_transcript_choice(plan_path, language)
    captions_suppressed = ''
    if words_path and job_captions is False:
        words_path = None
        caption_edit = None
        captions_suppressed = ('The transcript is switched off for the ' + LANGUAGES[language] + ' edition of this '
                               'job, so no captions were burned - even though the plan (built before the switch) '
                               'asks for them. Render the edition again from the job panel to rebuild the plan.')
    info, duration = _probe(src)
    vstream = next(s for s in info['streams'] if s['codec_type']=='video')
    width, height = int(vstream['width']), int(vstream['height'])
    width -= width%2; height -= height%2
    if width < 320 or height < 240: raise ValueError('Source resolution too small')
    picture_seconds = float(plan['source']['duration'])
    fit = False
    tempo = 1.0
    picture_scale = 1.0
    hold_seconds = 0.0
    fit_report = None
    if voice:
        from engine.narration_fit import plan as plan_fit
        policy = dict(plan.get('fit_policy') or {})
        policy.update({key: value for key, value in dict(fit_policy or {}).items() if value is not None})
        fit_report = plan_fit(float(voice['duration']), picture_seconds, label=LANGUAGES[language], **policy)
        if fit_report['mode'] == 'refuse':
            # Nothing is exported: the numbers and every repair are in the message.
            try:
                _atomic_json(Path(plan_path).parent / ('fit-' + language + '.json'), fit_report)
            except OSError:
                pass
            raise ValueError(fit_report['message'])
        if fit_report['mode'] != 'none':
            if not plan.get('fit_narration'):
                raise ValueError('Narration exceeds source footage; edit timing or source')
            fit = True
            picture_scale = float(fit_report['picture_scale'])
            tempo = float(fit_report['tempo'])
            hold_seconds = float(fit_report['hold_seconds'])
        if fit_report['mode'] != 'none':
            try:
                _atomic_json(Path(plan_path).parent / ('fit-' + language + '.json'), fit_report)
            except OSError:
                pass
    folder = plan_path.parent / 'exports'; folder.mkdir(exist_ok=True)
    caption_note = ''
    caption_corrected = 0
    dest = folder / (language+'-'+plan_path.parent.name+'.mp4')
    if dest.exists(): raise FileExistsError('Export exists; it will never be overwritten: '+str(dest))
    tmp_dir = Path(tempfile.mkdtemp(dir=plan_path.parent, prefix='.render-'))
    try:
        picture = src
        voice_seconds = float(voice['duration']) / tempo if voice else None
        words_for_render = words_src
        # Cards and hooks are resolved BEFORE the expensive picture retiming, against the reviewed narration
        # and its own word timings - the inputs their drafted fingerprint was made from. A stale card file now
        # fails in seconds instead of after minutes of encoding, and a fitted narration never invalidates it.
        legacy_cards = [] if edition.get('educational') else edition['cards']
        graphics_stats = {}
        overlay_specs = _edition_overlays(edition, language, voice, words_src, width, height, tmp_dir,
                                          legacy_cards, duration=float(voice['duration']) if voice else None,
                                          stats=graphics_stats)
        overlay_specs = _retime_overlays(overlay_specs, tempo)
        if overlay_specs or edition.get('speech_cards') or edition.get('hooks'):
            # 7.0.107: this edition writes down what it drew, so a missing card is explainable later.
            graphics_stats.update({
                'language': language, 'animated': sum(1 for e in overlay_specs if e.get('anim')),
                'kinds': {kind: sum(1 for e in overlay_specs if e.get('kind') == kind)
                          for kind in sorted({str(e.get('kind')) for e in overlay_specs})},
                'speech_cards_prepared': bool(edition.get('speech_cards')),
                'hooks_prepared': bool(edition.get('hooks')),
                'educational': bool(edition.get('educational')),
                'narration_tempo': tempo})
            try:
                _atomic_json(Path(plan_path).parent / ('graphics-' + language + '.json'), graphics_stats)
            except OSError:
                pass
        if fit:
            picture = tmp_dir/'picture-fit.mp4'
            _run(_fit_picture_cmd(src, picture, picture_scale=picture_scale, hold_seconds=hold_seconds,
                                  seconds=voice_seconds))
            picture_seconds = voice_seconds
            if words_src and abs(tempo - 1.0) > 1e-6:
                # Cards and hooks are anchored to the narration, so their word times shrink with it.
                from engine.narration_fit import scale_words
                scaled_source = caption_edit or Path(words_src)
                scaled = scale_words(json.loads(Path(scaled_source).read_text(encoding='utf8')), tempo)
                words_for_render = tmp_dir/'words-fitted.json'
                words_for_render.write_text(json.dumps(scaled, ensure_ascii=False), encoding='utf8')
                # v7.0.113: only hand the retimed words to the caption stage when captions were asked for.
                # Before this, fitting a longer narration set ``words_path`` unconditionally - so a language
                # whose transcript was switched OFF got its captions back as soon as the narration had to be
                # fitted onto the picture. That is exactly the field report: plan says "captions: false", the
                # exported file has them, in the language whose transcript was turned off.
                if words_path is not None:
                    words_path = words_for_render
        # Normalization yields identical codec/timebase for concat, and handles odd source dimensions.
        clips=[]
        for index, kind in enumerate(['intro','source','outro']):
            if kind != 'source' and (not edition.get(kind) or kind not in assets): continue
            source = picture if kind=='source' else assets[kind]
            i, d = _probe(source)
            has_audio = any(s.get('codec_type')=='audio' for s in i['streams'])
            segment=tmp_dir / f'{index}.mp4'
            cmd=[_tool('ffmpeg'),'-y','-hide_banner','-loglevel','error','-i',str(source)]
            if not has_audio: cmd += ['-f','lavfi','-i','anullsrc=r=48000:cl=stereo']
            vf=f'scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p'
            cmd += ['-map','0:v:0','-map','0:a:0' if has_audio else '1:a:0', '-vf',vf,
                    '-c:v','libx264','-preset','veryfast','-crf','21','-c:a','aac','-ar','48000','-ac','2',
                    '-af','aresample=async=1:first_pts=0','-shortest',str(segment)]
            _run(cmd); clips.append((kind,segment,d))
        concat=tmp_dir/'concat.txt'
        concat.write_text(''.join("file '"+str(p.resolve()).replace("'", "'\\''")+"'\n" for _,p,_ in clips))
        joined=tmp_dir/'joined.mp4'
        _run([_tool('ffmpeg'),'-y','-hide_banner','-loglevel','error','-f','concat','-safe','0','-i',str(concat),'-c','copy',str(joined)])
        offset=sum(d for kind,_,d in clips if kind=='intro')
        joined_info, full_duration=_probe(joined)
        # v7.0.115: the timeline, and the picture's own length. If the concatenated picture is even slightly
        # shorter than the container says - the usual cause is an intro/outro whose audio runs past its video, or
        # a fitted picture that lost a few frames - the whole export lands short and, until this release, failed
        # the duration check *after* the expensive encode with no numbers and no file left behind. Extending the
        # last frame to the timeline costs nothing here and makes the check meaningful.
        joined_spans = _stream_seconds(joined_info)
        video_padded = round(max(0.0, _span(full_duration) - joined_spans.get('video', 0.0)), 3)
        if video_padded < 0.04:
            video_padded = 0.0
        cmd=[_tool('ffmpeg'),'-y','-hide_banner','-loglevel','error','-i',str(joined)]
        filters=[]; current='0:v'; inp=1
        if video_padded:
            filters += [f'[0:v]tpad=stop_mode=clone:stop_duration={video_padded:.3f}[vpad]']
            current = 'vpad'
        # No Flow watermark mask or tracking. Branding is an independently placed channel mark.
        # 7.0.95: a profile may carry logo-en / logo-hi / logo-or; the shared logo is the fallback.
        logo_key = next((key for key in ('logo-' + language, 'logo') if key in assets), None)
        if logo_key:
            # v7.0.109: the logo is present for the whole edition, like a channel bug, with a soft fade-in.
            cmd += ['-loop','1','-framerate','30','-i',str(assets[logo_key])]
            size=max(48,round(width*.11))
            filters += [f'[{inp}:v]scale={size}:-1,format=rgba,colorchannelmixer=aa=0.9,'
                        f'fade=t=in:st=0:d=0.6:alpha=1[logo]']
            filters += [f'[{current}][logo]overlay=x=W-w-24:y=H-h-24:shortest=1[v{inp}]']; current=f'v{inp}';inp+=1
        name=edition.get('channel',plan.get('channel',{})).get('display_name') or edition.get('channel',plan.get('channel',{})).get('name','')
        if name:
            # v7.0.109: the same animated badge the English master uses - panel, mark and play glyph that opens
            # and closes - rather than plain white text. Segments are contiguous, so the name never vanishes.
            from engine.render.graphics import OverlayEvent, render_overlay_png, watermark_segments
            badge_style = 'playful' if plan.get('branding_badge', True) else 'clean'
            for index, event in enumerate(watermark_segments(name, 0.0, full_duration, style=badge_style)):
                art = tmp_dir / f'channel-name-{index:02d}.png'
                render_overlay_png(event, str(art), width, height, style=badge_style)
                cmd += ['-loop','1', '-framerate', '30', '-i', str(art)]
                filters += [f"[{current}][{inp}:v]overlay=x=0:y=0:"
                            f"enable='between(t,{event.start:.3f},{event.end:.3f})':shortest=1[v{inp}]"]
                current = f'v{inp}'; inp += 1
        card_style = _edition_card_style(dict(edition, card_style=edition.get('card_style') or plan.get('card_style')))
        for index,card in enumerate(legacy_cards):
            art=tmp_dir/f'card-{index}.png'
            _card_image(card['text'],width,height,art,language, style=card_style, captions=bool(words_path))
            cmd += ['-loop','1','-framerate','30','-i',str(art)]
            start=offset+float(card['start']);end=offset+float(card['end'])
            filters += [f'[{current}][{inp}:v]overlay=0:0:enable=\'between(t,{start:.3f},{end:.3f})\':shortest=1[v{inp}]'];current=f'v{inp}';inp+=1
        cmd, filters, current, inp = _add_overlays(cmd, filters, current, inp, overlay_specs, width, height, offset)
        caption_ass=None
        if words_path:
            # Captions use this edition's own reviewed word timings, shifted past any intro.
            from engine.render.captions_ass import build_captions
            from engine.render.ffmpeg_renderer import has_subtitles_filter, _esc_filter_path, _fontsdir
            if not has_subtitles_filter():
                raise RuntimeError('Captions need FFmpeg with libass subtitles. This edition was not exported without its captions.')
            words=json.loads(words_path.read_text(encoding='utf8'))
            # v7.0.109: burned captions must say exactly what was reviewed. Recognizer spellings (and a
            # machine-translated script) can disagree with the approved script while the word itself is right,
            # which is what the field screenshots showed. Timing comes from the saved word file; the text comes
            # from the reviewed script.
            if caption_edit:
                # The user read these words and fixed them; do not overwrite that with the script again.
                caption_note = 'Caption text from the saved correction (' + str(caption_edit.name) + ').'
                caption_corrected = 0
            elif edition.get('script'):
                from engine.captions import script_accurate_words
                words, caption_report = script_accurate_words(edition['script'], words, picture_seconds)
                caption_note = caption_report.get('note') or ''
                caption_corrected = int(caption_report.get('corrected') or 0)
            shifted=[{'word':w['word'],'start':float(w['start'])+offset,'end':float(w['end'])+offset} for w in words]
            vertical=height>width
            cap=build_captions(shifted,str(tmp_dir/'captions'),template='OPUS' if vertical else 'HORMOZI',
                               aspect='9:16' if vertical else '16:9',W=width,H=height,duration=full_duration)
            caption_ass=cap.get('ass')
            if caption_ass:
                fontsdir=_fontsdir()
                sub=f"subtitles='{_esc_filter_path(caption_ass)}'"+(f":fontsdir='{_esc_filter_path(fontsdir)}'" if fontsdir else '')
                filters += [f'[{current}]{sub}[vcap]']; current='vcap'
        voice_path=None
        if voice:
            # Narration sits on the approved timeline; intro/outro audio is kept and the picture's audio is muted.
            voice_path=_verified(voice)
            cmd += ['-i',str(voice_path)]
            source_end = offset + picture_seconds
            atempo = f'atempo={tempo:.6f},' if abs(tempo - 1.0) > 1e-6 else ''
            filters += [f'[{inp}:a]{atempo}adelay={int(offset*1000)}|{int(offset*1000)},apad,atrim=0:{full_duration:.3f}[voice]',
                        f"[0:a]volume='if(between(t,{offset:.3f},{source_end:.3f}),0,1)':eval=frame[bookends]",
                        '[bookends][voice]amix=inputs=2:duration=first:dropout_transition=0[speech]']
            speech='speech';inp+=1
        else: speech='0:a'
        music=edition.get('music') or plan.get('shared_music') or edition_assets.get('music')
        sound=dict(EDITION_SOUND_DEFAULTS); sound.update({k:v for k,v in (plan.get('sound') or {}).items() if v is not None})
        if music:
            cmd += ['-stream_loop','-1','-i',str(_verified(music))]
            volume=max(0.0,min(.35,float(plan.get('music_volume',.12))))
            if speech != '0:a':
                filters += [f'[{speech}]asplit=2[side][main]']
                side, main = 'side', 'main'
            else:
                side, main = speech, speech
            chain=(f'[{inp}:a]volume={volume:.3f},atrim=0:{full_duration:.3f},asetpts=N/SR/TB')
            # Fades scale with the export length so a short edition never loses most of its music.
            fade_in=min(max(0.0,float(sound['fade_in'])),max(0.0,full_duration*0.05))
            fade_out=(min(max(0.0,float(sound['fade_out'])),max(0.0,full_duration*0.20))
                      if full_duration>=8 else 0.0)
            if fade_in>0.01:
                chain+=f",afade=t=in:st=0:d={fade_in:.3f}"
            if fade_out>0.01 and full_duration>fade_out:
                chain+=f",afade=t=out:st={max(0.0,full_duration-fade_out):.3f}:d={fade_out:.3f}"
            # v7.0.107: the bed now really dips under speech (12:1 ≈ 13 dB) and returns in the pauses;
            # the old 4:1 at -28 dBFS moved the music by only a few dB, which sounded like no ducking at all.
            filters += [chain+'[music]',
                        '[music][{side}]sidechaincompress=threshold={thr:.4f}:ratio={ratio:.2f}:'
                        'attack={attack}:release={release}[duck]'.format(
                            side=side, thr=float(sound['threshold']), ratio=float(sound['ratio']),
                            attack=int(sound['attack_ms']), release=int(sound['release_ms'])),
                        f'[{main}][duck]amix=inputs=2:duration=first:dropout_transition=0,'
                        'loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,alimiter=limit=0.95[aout]']
            audio='aout'
        elif voice:
            # Music can be absent; the narration still lands at the same loudness as the other editions.
            filters += [f'[{speech}]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,alimiter=limit=0.95[aspeech]']
            audio='aspeech'
        else:audio=speech
        if filters:cmd += ['-filter_complex',';'.join(filters)]
        cmd += ['-map',f'[{current}]' if current!='0:v' else '0:v:0', '-map',f'[{audio}]' if audio!='0:a' else '0:a:0',
                '-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p',
                '-c:a','aac','-b:a','192k','-movflags','+faststart','-t',str(full_duration),str(tmp_dir/'result.mp4')]
        _run(cmd,progress,full_duration)
        result=tmp_dir/'result.mp4'
        # v7.0.115: the check now says what it found, and the file it found it in is kept instead of being deleted
        # with the temporary folder - a fifty-nine minute render must not vanish behind five words.
        qc = export_qc_report(result, full_duration, fit_report=fit_report, video_padded=video_padded)
        qc_path = Path(plan_path).parent / ('qc-' + language + '.json')
        if qc['problems']:
            kept_qc = Path(plan_path).parent / ('result-' + language + '.qc-failed.mp4')
            try:
                shutil.copy2(result, kept_qc)
            except OSError:
                kept_qc = result
            qc['kept'] = str(kept_qc)
            qc['message'] = export_qc_message(qc, language_label=LANGUAGES.get(language, language),
                                              kept_path=str(kept_qc))
            try:
                _atomic_json(qc_path, qc)
            except OSError:
                pass
            raise ValueError(qc['message'])
        try:
            _atomic_json(qc_path, qc)
        except OSError:
            pass
        os.replace(result,dest)
        _atomic_json(dest.with_suffix('.provenance.json'), {'plan':str(plan_path),'language':language,'source_sha256':plan['source']['sha256'],
                     'output_sha256':_hash(dest),'music_license':edition.get('music_license') or plan.get('shared_music_license') or edition.get('profile_music_license') or plan.get('profile_music_license'),
                     'channel':edition.get('channel',plan.get('channel')),
                     'duration':qc.get('container_seconds'),
                     'narration_sha256': voice['sha256'] if voice else None,
                     'narration_fitted_picture': fit, 'narration_fit': fit_report,
                     'captions_burned': bool(caption_ass),
                     'captions_from_reviewed_script': bool(caption_ass) and bool(edition.get('script'))
                                                   and not caption_edit,
                     'captions_from_correction': bool(caption_ass) and bool(caption_edit),
                     'captions_requested_by_plan': bool(plan.get('captions')),
                     'captions_job_setting': job_captions,
                     'captions_suppressed': captions_suppressed,
                     'captions_corrected': caption_corrected, 'captions_note': caption_note,
                     'rendered_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                     'music_volume': float(plan.get('music_volume', .12)) if music else 0.0,
                     'music_duck': sound if music else None,
                     'loudness_target_lufs': -14 if music else None,
                     'export_qc': {key: qc.get(key) for key in
                                   ('expected_seconds', 'container_seconds', 'video_seconds', 'audio_seconds',
                                    'video_padded_seconds', 'notes', 'checked_at')}})
        if progress:progress(1.0)
        return dest
    finally:shutil.rmtree(tmp_dir,ignore_errors=True)

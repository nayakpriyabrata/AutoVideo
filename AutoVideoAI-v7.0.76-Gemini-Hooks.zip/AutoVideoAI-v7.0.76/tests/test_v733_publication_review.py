from types import SimpleNamespace as NS
import json
from PIL import Image


def test_deduplicated_end_is_not_mislabeled_character(tmp_path):
    from engine.providers.flow_browser import video_reference_plan
    start=tmp_path/'start.jpg';start.write_bytes(b'same frame')
    end=tmp_path/'end.jpg';end.write_bytes(b'same frame')
    cast=tmp_path/'character-aanya.jpg';cast.write_bytes(b'identity')
    paths,prompt=video_reference_plan({'reference_paths':[str(cast)]},{'start':str(start),'end':str(end),'character':str(cast)})
    assert paths==[str(start),str(cast)]
    assert 'image 1 as the exact END' in prompt
    assert 'identity and wardrobe in attached image 2' in prompt
    assert 'image 2 as the exact END' not in prompt


def test_reference_plan_reserves_three_cast_slots(tmp_path):
    from engine.providers.flow_browser import video_reference_plan
    paths=[]
    for name in ['start','end','character-one','character-two','character-three','location']:
        p=tmp_path/(name+'.jpg');p.write_bytes(name.encode());paths.append(str(p))
    selected,prompt=video_reference_plan({'reference_paths':paths[2:5]},{'start':paths[0],'end':paths[1],'location':paths[-1]})
    assert selected==[paths[0],*paths[2:5]] and 'END' not in prompt


def test_lower_cards_leave_head_area_and_caption_margin(tmp_path):
    from engine.render.graphics import OverlayEvent,render_overlay_png
    for W,H in [(1920,1080),(1080,1920)]:
        e=OverlayEvent('chapter',0,4,'01','Advanced Prompt Engineering')
        p=tmp_path/f'{W}.png';render_overlay_png(e,str(p),W,H,style='playful')
        box=Image.open(p).getbbox()
        assert box[1]>=H*.50 and box[3]<=H*.82
        assert all(b[1]>=H*.50 for b in e.layout['text_boxes'])


def test_logo_replaces_second_channel_badge(tmp_path):
    from engine.render.graphics import OverlayEvent,render_overlay_png
    logo=tmp_path/'logo.png';Image.new('RGBA',(100,50),'red').save(logo)
    e=OverlayEvent('watermark',0,5,'Channel name')
    p=tmp_path/'overlay.png';render_overlay_png(e,str(p),1920,1080,str(logo),'playful')
    assert Image.open(p).getbbox()==(134,37,234,87)


def test_all_seven_sections_in_recap_with_clean_headings():
    from engine.render.graphics import plan_overlays
    words=['one','two','three','four','five','six','seven']
    m=NS(topic='Seven AI skills',target_seconds=160,content_type='education',shots=[NS(narration=f'Skill number {w} is Useful skill {i}',voice_start=10+i*18,voice_end=20+i*18) for i,w in enumerate(words,1)])
    events=plan_overlays(m,{},actual_duration=160)
    chapters=[e for e in events if e.kind=='chapter']
    assert len(chapters)==7 and all('number' not in e.body for e in chapters)
    rows=[r for e in events if e.kind=='recap' for r in e.body.splitlines()]
    assert len(rows)==7 and any(r.startswith('07.') for r in rows)
    assert all(e.end<=160 for e in events)


def test_reencoded_stock_repetition_is_blocked_and_metadata_preserved(tmp_path):
    from engine.render.coverage import audit_coverage,copy_source_provenance
    segments=[]
    for i in range(3):
        take=tmp_path/f'take{i}.mp4';take.write_bytes(f'encoding{i}'.encode())
        take.with_name(take.name+'.source.json').write_text(json.dumps({'source':'pexels','asset_id':123}))
        accepted=tmp_path/f'accepted{i}.mp4';accepted.write_bytes(take.read_bytes())
        copy_source_provenance(take,accepted)
        segments.append({'shot_id':f'shot{i}','src':str(accepted),'dur':12})
    report=audit_coverage(segments,150)
    assert not report['passed'] and any('Repeated stock asset' in x for x in report['issues'])
    missing=tmp_path/'no-sidecar.mp4';missing.write_bytes(b'new')
    copy_source_provenance(missing,tmp_path/'accepted0.mp4')
    assert not (tmp_path/'accepted0.mp4.source.json').exists()


def test_stock_search_uses_skill_not_presenter_background():
    from engine.planning.economy_storyboard import _stock_query
    shot=NS(narration='Skill one is Advanced Prompt Engineering and LLM use',visual_goal='Demonstrate typing a prompt',environment='modern office meeting room',subject='professional presenter')
    assert 'chatbot prompt' in _stock_query(shot)
    shot.narration='Data Analysis and Visualization';shot.visual_goal='Show data charts'
    assert 'dashboard charts' in _stock_query(shot)


def test_partial_references_fail_before_image_prompt(tmp_path):
    import pytest
    from engine.providers.flow_browser import FlowBrowserProvider,FlowReferenceUnavailable
    photo=tmp_path/'character-aanya.jpg';photo.write_bytes(b'image')
    b=NS(ensure_project=lambda *a,**kw:None,current_project_url=lambda:'',detect_editor_mode=lambda:'agent',
         select_agent_generation_type=lambda *a:None,attach_agent_media=lambda *a,**kw:0,
         snapshot_failure=lambda *a:'')
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider);provider._ensure=lambda:b
    with pytest.raises(FlowReferenceUnavailable,match='generation not submitted'):
        provider._generate_image_once(NS(shot_id='s'),{'reference_paths':[str(photo)],'prompt':'scene'},str(tmp_path/'out.jpg'),True)


def test_parallel_frame_does_not_repeat_exhausted_attachment(tmp_path,monkeypatch):
    import pytest
    import engine.providers.flow_browser as flow
    from engine.factory import Factory
    from tests.test_economy_parallel_frames import _shot,_Refs,_ProjectLog,_Browser
    calls=[]
    class Provider:
        def __init__(self,**kw):self.browser=_Browser('');self._last_video_project_url=''
        def close(self):pass
        def _ensure(self):return self.browser
        def generate_image(self,*a,**kw):
            calls.append('attempt')
            raise flow.FlowReferenceUnavailable('Image worker could not attach all master references; generation not submitted')
    monkeypatch.setattr(flow,'FlowBrowserProvider',Provider)
    f=Factory.__new__(Factory);f.pm=_ProjectLog()
    shot=_shot('shot_001')
    tasks=[{'shot':shot,'label':'opening frame','out':str(tmp_path/'out.jpg'),'prompt':'scene'}]
    with pytest.raises(RuntimeError,match='master references'):
        f._generate_economy_frames_parallel(NS(job_id='job',shots=[shot]),{'root':str(tmp_path)},_Refs(),True,{'flow_frame_retries':3},lambda *a:None,tasks,1,'flow')
    assert calls==['attempt']


def test_missing_selected_cast_blocks_video_before_submission(tmp_path):
    import pytest
    from engine.providers.flow_browser import video_reference_plan,FlowReferenceUnavailable
    with pytest.raises(FlowReferenceUnavailable,match='missing locally'):
        video_reference_plan({'reference_paths':[str(tmp_path/'character-missing.jpg')]},{})

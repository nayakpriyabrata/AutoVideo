#!/usr/bin/env python3
"""Local channel review: no browser, generation or social posting."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine.channel_desk import review_video,parse_metrics,metrics_summary,PROFILES

def main():
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
 r=sub.add_parser('review');r.add_argument('video');r.add_argument('--output',default='outputs/channel-reviews');r.add_argument('--destination',choices=list(PROFILES),required=True);r.add_argument('--silent',action='store_true')
 m=sub.add_parser('metrics');m.add_argument('csv');m.add_argument('--min-views',type=int,default=100)
 a=p.parse_args()
 if a.command=='review':result=review_video(a.video,a.output,a.destination,audio_expected=not a.silent,progress=lambda msg,pct,detail='':print(f'[{pct:3}%] {msg} {detail}',file=sys.stderr))
 else:result=metrics_summary(parse_metrics(Path(a.csv).read_text(encoding='utf-8-sig')),a.min_views)
 print(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
if __name__=='__main__':main()

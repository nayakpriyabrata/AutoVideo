"""Nonblocking, reentrant exact-review transactions across tabs/processes."""
from contextlib import contextmanager
from pathlib import Path
from functools import wraps
import inspect
import threading
from .production_lock import acquire, release

_held = threading.local()

@contextmanager
def review_transaction(review_path):
    path = Path(review_path).expanduser().resolve()
    key = str(path)
    held = getattr(_held, 'paths', None)
    if held is None:
        held = _held.paths = set()
    if key in held:
        yield
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.with_name(path.name + '.edit.lock').open('a+b') as handle:
        try:
            acquire(handle, blocking=False)
        except BlockingIOError as error:
            raise ValueError('This B-roll review is being edited or rendered in another tab/process. Wait for it to finish.') from error
        held.add(key)
        try:
            yield
        finally:
            held.remove(key)
            release(handle)


def locked_review(function):
    signature = inspect.signature(function)
    @wraps(function)
    def wrapped(*args, **kwargs):
        bound = signature.bind(*args, **kwargs)
        with review_transaction(bound.arguments['review_path']):
            return function(*args, **kwargs)
    return wrapped

"""v7.0.106: approve each Flow video request exactly once, automatically, and never a second time.

The field report: a job needs eight Flow videos, the first one is approved by itself, and the rest sit
behind an unclicked ``Approve`` card until a human clicks it. Meanwhile "Always approve" is unacceptable
- it would also confirm a request nobody planned.

So the rule this module enforces is *per saved request*, not per job and not per session:

* one click, for this request, when its card is visible and states a readable cost within the cap;
* never a second click for the same request, even across browser restarts, runs and processes;
* never the "Always approve" label;
* ``flow_approval = manual`` disables every automatic click.

The decision is a pure function (``plan``) so it can be tested without Playwright, and every click is
recorded twice: in the request journal (``approval_clicks``) and in a job-level audit file
(``flow_approvals.jsonl``) that the Queue panel and ``cli.py v3 status`` can show.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

MAX_CLICKS_PER_REQUEST = 1
JOURNAL_SUFFIX = '.flow-request.json'
AUDIT_NAME = 'flow_approvals.jsonl'
FORBIDDEN_LABEL = 'always approve'


def journal_for(output_path) -> Path:
    return Path(str(output_path) + JOURNAL_SUFFIX)


def _load(path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def ledger_clicks(journal) -> int:
    """How many ``approval`` clicks the submission ledger records for this request."""
    journal = Path(journal)
    name = journal.name
    if not name.endswith(JOURNAL_SUFFIX):
        return 0
    ledger = journal.with_name(name[:-len(JOURNAL_SUFFIX)] + '.submit-ledger.jsonl')
    if not ledger.is_file():
        return 0
    try:
        from .flow_submit_guard import read_events
        return sum(1 for event in read_events(str(ledger)) if event.get('event') == 'approval')
    except (OSError, ValueError, ImportError):
        return 0


def clicks_for(journal) -> dict:
    """Clicks already spent on this request: journal counter, reservations and ledger lines."""
    journal = Path(journal)
    request = _load(journal)
    try:
        recorded = int(request.get('approval_clicks') or 0)
    except (TypeError, ValueError):
        recorded = 0
    reserved = len([row for row in (request.get('approval_reservations') or []) if isinstance(row, dict)])
    ledger = ledger_clicks(journal)
    return {'clicks': max(recorded, reserved, ledger), 'recorded': recorded,
            'reserved': reserved, 'ledger': ledger,
            'last_label': str(request.get('approval_label') or ''),
            'last_cost': request.get('approval_cost'),
            'last_at': str(request.get('approval_clicked_at') or '')}


def auto_allowed(settings) -> tuple[bool, str]:
    """May this job click approval cards by itself? ``manual`` always wins."""
    settings = settings or {}
    mode = str(settings.get('flow_approval', 'once') or 'once').strip().lower()
    if mode == 'manual':
        return False, ('flow_approval is "manual" in this job\'s settings, so no card is clicked automatically')
    explicit = settings.get('flow_auto_approve_video_requests', True)
    if explicit is False:
        return False, ('automatic approval is switched off for this job '
                       '(settings.json flow_auto_approve_video_requests = false)')
    return True, f'flow_approval is "{mode}"; one click per saved video request is allowed'


def credit_cap(settings) -> int:
    try:
        cap = int((settings or {}).get('max_generation_credits', 10))
    except (TypeError, ValueError):
        return 10
    return cap if cap >= 0 else 10


def plan(journal, probe, *, setting='once', cap=10, allow_auto=True) -> dict:
    """Decide what to do with the card visible for ``journal``. Never clicks.

    Returns ``{'action', 'reason', 'cost', 'clicks'}`` where action is one of

    ``approve``    click the visible Approve control once
    ``duplicate``  this request was already approved; never click again
    ``manual``     the user asked to approve every card by hand
    ``no_card``    no clickable card is visible yet
    ``no_cost``    the card does not state a readable credit cost
    ``not_video``  the newest turn is not a video generation request
    ``over_cap``   the card costs more than this job allows for one take
    ``disabled``   automatic approval is off for this job
    """
    journal = Path(journal)
    counts = clicks_for(journal)
    clicks = counts['clicks']
    probe = probe or {}
    mode = str(setting or 'once').strip().lower()
    if clicks >= MAX_CLICKS_PER_REQUEST:
        return {'action': 'duplicate', 'clicks': clicks, 'cost': probe.get('cost'),
                'reason': (f'this request was already approved once '
                           f'({counts["last_at"] or "earlier"}{", " + str(counts["last_cost"]) + " credits" if counts["last_cost"] is not None else ""}); '
                           'a second card is never clicked, and the video it paid for is waited for')}
    if not allow_auto or mode == 'manual':
        return {'action': 'manual', 'clicks': clicks, 'cost': probe.get('cost'),
                'reason': 'automatic approval is off: click Approve in the saved Flow project yourself'}
    if not probe.get('visible'):
        return {'action': 'no_card', 'clicks': clicks, 'cost': None,
                'reason': 'no clickable Approve control is visible in the saved project'}
    cost = probe.get('cost')
    if not isinstance(cost, int) or isinstance(cost, bool) or cost < 0:
        return {'action': 'no_cost', 'clicks': clicks, 'cost': None,
                'reason': 'the visible card does not state a readable credit cost'}
    if probe.get('video') is False:
        return {'action': 'not_video', 'clicks': clicks, 'cost': cost,
                'reason': 'the newest Flow turn is not a video generation request'}
    if cap is not None and int(cap) >= 0 and cost > int(cap):
        return {'action': 'over_cap', 'clicks': clicks, 'cost': cost,
                'reason': (f'the card asks for {cost} credits, above this job\'s {int(cap)}-credit cap for one '
                           'take; nothing was clicked')}
    return {'action': 'approve', 'clicks': clicks, 'cost': cost,
            'reason': f'one approval will be clicked for this request ({cost} credits)'}


def record_click(journal, *, label, cost, job_dir=None) -> dict:
    """Persist one click in the request journal and in the job's audit log."""
    journal = Path(journal)
    request = _load(journal)
    counts = clicks_for(journal)
    request['approval_clicks'] = max(1, counts['clicks'] + (0 if counts['ledger'] else 1))
    request['approval_clicked_at'] = time.strftime('%Y-%m-%dT%H:%M:%S%z')
    request['approval_label'] = str(label or '')[:80]
    if isinstance(cost, int):
        request['approval_cost'] = cost
    _write_json(journal, request)
    audit = {'journal': str(journal), 'label': str(label or '')[:80], 'cost': cost if isinstance(cost, int) else None,
             'clicks_after': request['approval_clicks'], 'at': request['approval_clicked_at'],
             'max_clicks_per_request': MAX_CLICKS_PER_REQUEST}
    root = Path(job_dir) if job_dir else _job_dir_for(journal)
    if root:
        append_audit(root, audit)
    return audit


def _job_dir_for(journal) -> Path | None:
    """``<job>/flow/shots/<shot>/take.mp4.flow-request.json`` -> ``<job>``."""
    parts = Path(journal).resolve().parts
    for index in range(len(parts) - 1, 0, -1):
        if parts[index] == 'flow' and parts[index - 1] != 'logs':
            return Path(*parts[:index])
    return None


def _write_json(path, data) -> None:
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('w', encoding='utf-8') as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def audit_path(job_dir) -> Path:
    return Path(job_dir) / AUDIT_NAME


def append_audit(job_dir, row) -> None:
    try:
        job_dir = Path(job_dir)
        job_dir.mkdir(parents=True, exist_ok=True)
        with open(audit_path(job_dir), 'a', encoding='utf-8') as handle:
            handle.write(json.dumps(row, sort_keys=True) + '\n')
            handle.flush()
            os.fsync(handle.fileno())
    except OSError:
        pass


def audit_rows(job_dir) -> list[dict]:
    path = audit_path(job_dir)
    if not path.is_file():
        return []
    rows = []
    try:
        for raw in path.read_text(encoding='utf-8').splitlines():
            raw = raw.strip()
            if not raw:
                continue
            try:
                rows.append(json.loads(raw))
            except ValueError:
                continue
    except OSError:
        return []
    return rows


def safe_label(approval_mode: str) -> str:
    """The label to click for a mode. 'Always approve' is never returned unless the user asked for it."""
    return 'Always approve' if str(approval_mode or '').strip().lower() == 'always' else 'Approve'


def approve_saved_video_request(provider, journal, *, settings=None, project='AutoVideo-Recovery',
                                emit=None) -> dict:
    """Approve the card of one saved video request once, if the evidence and the guards allow it.

    Opens/uses ``provider``'s browser to read the card, so the caller owns the browser's lifetime.
    Returns ``{'clicked', 'action', 'reason', 'cost', 'clicks'}``; a refusal is a result, not an exception,
    so the caller can still attempt the download-only recovery.
    """
    journal = Path(journal)
    settings = settings or {}
    allow, why = auto_allowed(settings)
    request = _load(journal)
    probe = {}
    if request.get('kind') != 'video':
        return {'clicked': False, 'action': 'not_video', 'cost': None, 'clicks': 0,
                'reason': 'only a video request needs a credit card'}
    counts = clicks_for(journal)
    if counts['clicks'] >= MAX_CLICKS_PER_REQUEST:
        return {'clicked': False, 'action': 'duplicate', 'cost': None, 'clicks': counts['clicks'],
                'reason': plan(journal, {}, setting=str(settings.get('flow_approval', 'once') or 'once'),
                               cap=credit_cap(settings), allow_auto=allow)['reason']}
    if not allow:
        return {'clicked': False, 'action': 'manual', 'cost': None, 'clicks': counts['clicks'], 'reason': why}
    project_url = provider.normalize_project_url(request.get('project_url'))
    if not project_url:
        return {'clicked': False, 'action': 'no_project', 'cost': None, 'clicks': counts['clicks'],
                'reason': 'the saved video request has no project URL; nothing was clicked'}
    try:
        probe = provider.inspect_recorded_approval(project, str(journal), project_url=project_url)
    except Exception as error:                      # noqa: BLE001 - reported, never fatal
        return {'clicked': False, 'action': 'probe_failed', 'cost': None, 'clicks': counts['clicks'],
                'reason': f'the saved project could not be read for an approval card: {str(error)[:300]}'}
    decision = plan(journal, probe, setting=str(settings.get('flow_approval', 'once') or 'once'),
                    cap=credit_cap(settings), allow_auto=allow)
    if emit:
        emit(f'{journal.name}: {decision["reason"]}')
    if decision['action'] != 'approve':
        return {'clicked': False, **{k: decision[k] for k in ('action', 'reason', 'cost', 'clicks')}}
    labels = [str(label).strip().lower() for label in (probe.get('labels') or [])]
    if labels and all(label == FORBIDDEN_LABEL for label in labels):
        return {'clicked': False, 'action': 'refused_label', 'cost': decision['cost'], 'clicks': counts['clicks'],
                'reason': 'the only visible control is "Always approve"; it is never clicked automatically'}
    info = provider.approve_recorded_card(project, str(journal), project_url=project_url,
                                          confirm_credits=int(decision['cost']))
    label = str(info.get('clicked') or 'Approve')
    audit = record_click(journal, label=label, cost=int(decision['cost']))
    return {'clicked': True, 'action': 'approved', 'cost': int(decision['cost']),
            'clicks': audit['clicks_after'], 'label': label,
            'reason': f'approved once for {int(decision["cost"])} credits; the download that follows is free'}

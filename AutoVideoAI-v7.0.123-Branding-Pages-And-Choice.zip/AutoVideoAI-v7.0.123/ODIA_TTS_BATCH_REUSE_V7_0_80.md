# AutoVideo 7.0.80 — Odia TTS resilience, batch reuse, wrong-script guard

Update from 7.0.79 with `python3 ../AutoVideoAI-v7.0.80/tools/update_v779_to_v780.py . --apply`
(dry run first without `--apply`; stop the dashboard before applying).

## What failed (job 20261022-143856-7-small-daily-habits-tha-9729)

1. **Odia TTS, step 4 (`Prepare all selected TTS`).** The Gemini call failed twice:
   - SDK path: HTTP 400 `The value 'UNKNOWN' is not supported for 'type' at input[0].content[0].annotations[0]`.
     The request body built by google-genai 2.32.0 is correct (`speech_metadata`); the `UNKNOWN` value could
     not be reproduced here, so the SDK path is removed and the documented REST JSON is sent directly.
   - REST path: `Read timed out` after 180 s. One 3-minute request for the whole Odia narration.
   - Odia has no fallback by design, so preparation stopped.
2. **Odia TTS, video generation.** Production synthesised Odia a second time. Cause: when one saved language
   had a failed hook draft, `prepare_selected_editions` treated the whole saved batch as stale and reran
   localization, TTS and cards for all three languages. Odia voice files written by the failed run were not reused.
3. **Corrupted Odia narration.** The approved Odia text contained `βαğβαğ` in place of an Odia word
   (Gemini Web localization artifact). It was sent to TTS unchecked.

## What changed

- `engine/audio/tts.py`: Gemini TTS uses REST JSON only. Narration is split into parts of at most 1200
  characters at sentence ends (`।`, `.`, `!`, `?`, or a space for long unpunctuated runs). Each part is
  synthesised with a 30 s connect / 240 s read timeout, up to 3 attempts for timeouts, connection errors,
  408/429 and 5xx. Other 4xx responses fail at once. Finished parts are cached in `<out>.parts/` so a
  retry sends only the unfinished parts. The folder is removed after success.
- Odia failures now state that no English fallback is used and that the edition needs a native Odia voice
  file. **Per-language voice import is not available in 7.0.80**: the imported narration file applies to the
  source (master) language only, so it cannot replace the Odia edition yet.
- `engine/speech_cards.py`:
  - A saved batch with matching choices is reused. If only hook drafts are missing, only those hooks are drafted
    again; localization, TTS and card drafts are not repeated. A failed hook redo is recorded in `hooks_error`
    and the batch is still reused.
  - `foreign_script_words(text, language)` flags words with letters from a non-Latin foreign script, or Latin
    letters mixed into an Odia/Hindi word. Pure Latin words (brand names, loanwords) are allowed.
    `prepare_batch` raises before any TTS call and names the words. Correct them in step 4 and save again.
- `tools/update_v779_to_v780.py`: the updater. The 7.0.78→7.0.79 step is kept in the chain as
  documentation (run it from the 7.0.79 zip folder if you are on 7.0.78).

## Not verified

- Live Gemini Odia speech timing and quality could not be tested from the build sandbox. The REST path, timeouts
  and retries are tested with a fake server. Treat Odia narration as **needing a native voice file** until one
  Odia edition has been generated and listened to.
- The `UNKNOWN` SDK error did not reproduce on google-genai 2.32.0; the cause on the user's install is unknown.

## Tests

- `tests/test_v780_tts_resilience.py` (9): documented request body, timeout retried, 400 fails at once, persistent
  timeouts stop after 3 attempts, long narration split and finished parts reused, word-preserving split, Odia
  failure message.
- `tests/test_v780_batch_reuse.py` (5): foreign-script detection, wrong-script narration blocked before TTS,
  complete batch not rerun, failed hook redone alone, hook-redo failure recorded.
- `tests/test_v778_odia_fixes.py`: retry sleep patched.

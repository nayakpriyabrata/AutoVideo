# Speech batches in Jobs & Recovery (v7.0.83)

## What was wrong (reported on 7.0.82)

1. **"Correct them in step 4"** appeared in Jobs & Recovery for a job whose Create page had no step 4. The job's
   TTS step regenerated the Odia narration in the job folder and ignored the narration approved in Create step 4.
   There was no editing control on the page the message sent the user to.
2. **Halfway-failed jobs were invisible.** Create's Prepare step (and a job's TTS step before the job record exists)
   writes its batch under `speech_preparation/`. Jobs & Recovery listed only folders with a
   `production_manifest.json`, so a batch that stopped after one or two TTS calls had no row.
3. `approve_localized_scripts` (Create step 4) did not run the script check, so the Odia text with
   foreign letters could be approved and the error appeared only at TTS time.

## What changed

- **Job reruns use the approved narration.** `prepare_batch` takes the narration saved by Create step 4
  (`speech_preparation/scripts/<key>/localized_scripts.json`) when it exists. It regenerates narration only when no
  approved narration exists for that master and language set.
- **Batches are recorded from the start.** `batch.json` stores the narration, the request settings (TTS provider,
  narration audio, cleanup, text cards, educational, topic, card provider, hooks) and the last error. A batch that
  stops is kept with its error.
- **Approval checks script words.** Create step 4 refuses a language narration that contains words outside its script,
  with the same rule as before TTS. English words and brand names are not flagged.
- **Jobs & Recovery → Speech batches.** Lists Create step 4 batches and unfinished batches inside jobs, with the
  error, per-language narration (editable, with a review checkbox for each non-master language), **Save corrected
  narration** and **Resume TTS and cards**. The message no longer names a page the user may not have. A wrong-script
  error now reads: correct it in Jobs & Recovery > Speech batches (or Create step 4), save, then resume.
- **Resume.** Uses the saved narration and settings. Languages with a voice file already on disk are reused, so only
  unfinished languages are sent to TTS. A corrected batch clears its old voice files, so an old voice for the old
  text cannot be attached.

## Limits

- A job with no approved narration still generates narration when its TTS step runs (as before). Always approve
  narration in Create step 4 for Odia and Hindi jobs.
- Gemini request limits still apply to each resume. The Speech batches panel does not check quota before resuming;
  see the 7.0.81 and 7.0.82 notes for daily-limit behaviour.

## Files

- `engine/speech_cards.py`: `reviewed_scripts_for`, `prepare_batch` (saves state, approved narration, error),
  `approve_localized_scripts` (script check).
- `engine/speech_batches.py` (new): `list_speech_batches`, `correct_speech_scripts`, `resume_speech_batch`.
- `app.py`: Jobs & Recovery (Queue page) Speech batches panel.
- `tests/test_v783_speech_batches.py` (new, 6 tests).
- `tools/update_v782_to_v783.py`: updater from 7.0.82. Earlier steps are in earlier release zips.

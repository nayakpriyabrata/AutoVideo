"""Cross-channel duplicate guard for approved manual-upload deliveries.

Two checks run when a delivery is approved or scheduled for an account:

* Identical bytes (same SHA-256) already approved or scheduled for a different
  non-empty account are blocked. The same file cannot be cleared for two channels.
* A near-duplicate (same content after re-encoding) is a warning. It needs an
  explicit acknowledgment that names the matching release records.

Near-duplicate test (a proposal, tune with real data): sample 8 frames across the
video, reduce each to a 9x8 grayscale difference hash (64 bits), and compare the
mean Hamming distance. Matching requires a mean at or below NEAR_MAX_MEAN_BITS
and durations within DURATION_TOLERANCE.

Fingerprints are cached in a sidecar next to each video. The release JSON is not
changed, so existing approval fingerprints stay valid.
"""
from pathlib import Path
import json
import os
import subprocess

from .production import digest, read

FRAME_SAMPLES = 8
HASH_WIDTH, HASH_HEIGHT = 9, 8          # 8 comparisons per row x 8 rows = 64 bits
NEAR_MAX_MEAN_BITS = 10                 # proposed threshold, mean per frame (of 64)
DURATION_TOLERANCE = 0.02               # 2 %, same tolerance as delivery export
ACTIVE_STATES = ('APPROVED_FOR_MANUAL_UPLOAD', 'SCHEDULED_MANUAL_REMINDER')
DEFAULT_ROOTS = ('outputs',)
CACHE_SUFFIX = '.duplicate-fingerprint.json'


def _duration(path):
    from .render.ffmpeg_renderer import _probe_av_durations
    measured = _probe_av_durations(str(path))
    value = measured.get('video') or measured.get('format')
    if not value or value <= 0:
        raise ValueError('Cannot read video duration for the duplicate check: ' + Path(path).name)
    return float(value)


def _frame_hash(ffmpeg, path, seconds):
    command = [ffmpeg, '-v', 'error', '-ss', f'{seconds:.3f}', '-i', str(path),
               '-frames:v', '1', '-vf', f'scale={HASH_WIDTH}:{HASH_HEIGHT}:flags=area,format=gray',
               '-f', 'rawvideo', '-pix_fmt', 'gray', '-']
    result = subprocess.run(command, capture_output=True, timeout=120)
    pixels = result.stdout
    if result.returncode or len(pixels) != HASH_WIDTH * HASH_HEIGHT:
        raise ValueError('Cannot decode a frame for the duplicate check: ' + Path(path).name)
    value = 0
    for y in range(HASH_HEIGHT):
        row = y * HASH_WIDTH
        for x in range(HASH_WIDTH - 1):
            value = (value << 1) | (1 if pixels[row + x] > pixels[row + x + 1] else 0)
    return value


def _file_identity(path):
    stat = Path(path).stat()
    return stat.st_size, stat.st_mtime_ns


def fingerprint(path, *, use_cache=True):
    """Return {'sha256','size','duration','frames'} for one delivery video."""
    from .render.ffmpeg_renderer import ffmpeg_exe
    path = Path(path).resolve()
    if not path.is_file():
        raise ValueError('Delivery video is missing: ' + path.name)
    sha = digest(path)
    size, mtime_ns = _file_identity(path)
    cache_path = path.with_name(path.name + CACHE_SUFFIX)
    cached = read(cache_path) if use_cache else None
    if (isinstance(cached, dict) and cached.get('sha256') == sha and cached.get('size') == size
            and cached.get('mtime_ns') == mtime_ns and len(cached.get('frames') or []) == FRAME_SAMPLES):
        return {'sha256': sha, 'size': size, 'duration': cached['duration'],
                'frames': [int(v, 16) for v in cached['frames']]}
    duration = _duration(path)
    ffmpeg = ffmpeg_exe()
    frames = [_frame_hash(ffmpeg, path, duration * (i + 0.5) / FRAME_SAMPLES) for i in range(FRAME_SAMPLES)]
    result = {'sha256': sha, 'size': size, 'duration': duration, 'frames': frames}
    try:  # The cache is an optimisation; a failed write must not block a review.
        tmp = cache_path.with_suffix(cache_path.suffix + '.tmp')
        tmp.write_text(json.dumps({'sha256': sha, 'size': size, 'mtime_ns': mtime_ns,
                                   'duration': duration, 'frames': [f'{v:016x}' for v in frames]}),
                       encoding='utf-8')
        os.replace(tmp, cache_path)
    except OSError:
        pass
    return result


def mean_hamming(a, b):
    if len(a) != FRAME_SAMPLES or len(b) != FRAME_SAMPLES:
        raise ValueError('Fingerprints must have the same frame count')
    return sum(bin(x ^ y).count('1') for x, y in zip(a, b)) / FRAME_SAMPLES


def candidate_releases(roots=DEFAULT_ROOTS, *, extra_dirs=(), exclude=None):
    """Release JSON files under the roots (recursive) and the given folders (flat)."""
    seen, paths = set(), []
    excluded = Path(exclude).resolve() if exclude else None
    found = []
    for root in roots:
        base = Path(root)
        if base.is_dir():
            found.extend(base.rglob('*.release.json'))
    for folder in extra_dirs:
        base = Path(folder)
        if base.is_dir():
            found.extend(base.glob('*.release.json'))
    for path in found:
        if path.is_symlink() or not path.is_file():
            continue
        resolved = path.resolve()
        if resolved == excluded or resolved in seen:
            continue
        seen.add(resolved)
        paths.append(resolved)
    return sorted(paths)


def _describe(path, record, match, **extra):
    row = {'release': str(path), 'id': record.get('id', path.stem), 'account_id': record.get('account_id', ''),
           'destination': record.get('destination', ''), 'state': record.get('state', ''), 'match': match}
    row.update(extra)
    return row


def check(record, release_path, *, account_id, roots=DEFAULT_ROOTS):
    """Compare this delivery with approved/scheduled releases on other accounts.

    Returns {'blocked': [...], 'warnings': [...], 'skipped': [...]}. Raises ValueError
    if this delivery's own video cannot be fingerprinted (fail closed).
    """
    account = str(account_id or '').strip()
    release_path = Path(release_path).resolve()
    result = {'blocked': [], 'warnings': [], 'skipped': []}
    if not account:
        return result
    video = Path(record['video'])
    current = fingerprint(video)
    if current['sha256'] != record.get('sha256'):
        raise ValueError('Delivery file is missing or changed; review the current render')
    for path in candidate_releases(roots, extra_dirs=[release_path.parent], exclude=release_path):
        other = read(path)
        if not isinstance(other, dict):
            result['skipped'].append({'release': str(path), 'reason': 'unreadable release record'})
            continue
        other_account = str(other.get('account_id') or '').strip()
        if other.get('state') not in ACTIVE_STATES or not other_account or other_account == account:
            continue
        other_video = Path(str(other.get('video') or ''))
        if not other_video.is_file():
            result['skipped'].append({'release': str(path), 'reason': 'video file missing'})
            continue
        try:
            other_fp = fingerprint(other_video)
        except (OSError, ValueError, subprocess.SubprocessError) as error:
            result['skipped'].append({'release': str(path), 'reason': str(error)[:200]})
            continue
        if other_fp['sha256'] == current['sha256']:
            result['blocked'].append(_describe(path, other, 'identical_bytes'))
            continue
        distance = mean_hamming(current['frames'], other_fp['frames'])
        delta = abs(current['duration'] - other_fp['duration']) / max(current['duration'], other_fp['duration'])
        if distance <= NEAR_MAX_MEAN_BITS and delta <= DURATION_TOLERANCE:
            result['warnings'].append(_describe(path, other, 'near_duplicate',
                                                mean_hamming=round(distance, 2),
                                                duration_delta=round(delta, 4)))
    return result


def acknowledged_paths(record):
    review = record.get('duplicate_review')
    if not isinstance(review, dict) or review.get('acknowledged') is not True:
        return set()
    return {row.get('release') for row in review.get('matches', []) if isinstance(row, dict)}


def enforce(record, release_path, *, account_id, acknowledge, roots=DEFAULT_ROOTS):
    """Raise on blocked duplicates; require acknowledgment for near-duplicates.

    Returns the review note to store on the release record, or None when there is
    nothing to report.
    """
    result = check(record, release_path, account_id=account_id, roots=roots)
    if result['blocked']:
        names = ', '.join(f"{row['id']} ({row['account_id']})" for row in result['blocked'])
        raise ValueError('Identical video is already approved or scheduled for another account: '
                         f'{names}. Nothing approved; choose one channel for this file.')
    pending = [row for row in result['warnings'] if row['release'] not in acknowledged_paths(record)]
    if pending and acknowledge is not True:
        names = ', '.join(f"{row['id']} ({row['account_id']}, mean {row['mean_hamming']} bits)" for row in pending)
        raise ValueError('Near-duplicate of approved or scheduled delivery: ' + names
                         + '. Review the match and tick the acknowledgment to continue.')
    if not result['warnings'] and not result['skipped']:
        return None
    return {'acknowledged': bool(result['warnings']) and (acknowledge is True or not pending),
            'matches': result['warnings'], 'skipped': result['skipped'],
            'threshold': {'mean_hamming_bits_max': NEAR_MAX_MEAN_BITS, 'duration_tolerance': DURATION_TOLERANCE}}


def reverify_for_schedule(record, release_path, *, roots=DEFAULT_ROOTS):
    """Scheduling re-check: no new blocking or unacknowledged matches are allowed.

    Any new near-duplicate needs a fresh approval review, so the approval fingerprint
    stays the record of what was reviewed.
    """
    result = check(record, release_path, account_id=record.get('account_id'), roots=roots)
    if result['blocked']:
        names = ', '.join(f"{row['id']} ({row['account_id']})" for row in result['blocked'])
        raise ValueError('Identical video is now approved or scheduled for another account: '
                         f'{names}. Re-review this delivery before scheduling.')
    acknowledged = acknowledged_paths(record)
    if any(row['release'] not in acknowledged for row in result['warnings']):
        raise ValueError('A new near-duplicate delivery appeared since approval. Re-review and approve again.')

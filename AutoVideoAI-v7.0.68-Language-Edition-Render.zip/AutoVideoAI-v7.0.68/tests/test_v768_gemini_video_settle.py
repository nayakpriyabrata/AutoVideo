"""v7.0.68: Gemini-web video downloads wait for a loaded, stable video tile."""
from engine.providers.gemini_video import GEMINI_VIDEO_READY_JS, VideoTileSettle


class Clock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now


def test_chat_text_without_a_loaded_video_never_settles():
    clock = Clock()
    settle = VideoTileSettle(clock=clock)
    for _ in range(20):
        assert settle.observe({'ready': False, 'src': ''}) is False
        clock.now += 1.5


def test_loaded_video_must_stay_unchanged_for_two_seconds():
    clock = Clock()
    settle = VideoTileSettle(clock=clock)
    assert settle.observe({'ready': True, 'src': 'blob:a'}) is False
    clock.now += 1.5
    assert settle.observe({'ready': True, 'src': 'blob:a'}) is False
    clock.now += 0.5
    assert settle.observe({'ready': True, 'src': 'blob:a'}) is True


def test_source_change_restarts_the_window():
    clock = Clock()
    settle = VideoTileSettle(clock=clock)
    settle.observe({'ready': True, 'src': 'poster-thumb'})
    clock.now += 1.9
    assert settle.observe({'ready': True, 'src': 'blob:final'}) is False
    clock.now += 2.0
    assert settle.observe({'ready': True, 'src': 'blob:final'}) is True


def test_not_ready_resets_the_window():
    clock = Clock()
    settle = VideoTileSettle(clock=clock)
    settle.observe({'ready': True, 'src': 'blob:a'})
    clock.now += 1.9
    settle.observe({'ready': False, 'src': 'blob:a'})
    clock.now += 0.2
    assert settle.observe({'ready': True, 'src': 'blob:a'}) is False


def test_readiness_script_requires_decoded_video_not_metadata_only():
    assert 'readyState >= 3' in GEMINI_VIDEO_READY_JS
    assert 'readyState >= 1' not in GEMINI_VIDEO_READY_JS

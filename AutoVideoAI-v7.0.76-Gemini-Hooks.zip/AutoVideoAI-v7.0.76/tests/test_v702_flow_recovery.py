import hashlib
import json
from pathlib import Path
import subprocess
import shutil
from types import SimpleNamespace as NS
import pytest
from engine.providers.flow_browser import FlowBrowser, FlowBrowserProvider, FlowUIChanged, media_signature_matches


def test_real_gallery_scanner_does_not_borrow_video_badges_or_queue_text():
    if not shutil.which('node'):
        pytest.skip('Node is needed for this browserless JavaScript scanner test')
    fixture = Path(__file__).parent / 'fixtures/flow_gallery_dom.js'
    def evaluate(source):
        result = subprocess.run(['node', str(fixture)], input=json.dumps({'source':source}),
            text=True, capture_output=True, timeout=5, check=True)
        return json.loads(result.stdout)
    b=FlowBrowser.__new__(FlowBrowser);b._page=NS(evaluate=evaluate)
    assets=b.media_assets()
    assert [a['kind'] for a in assets] == ['video', 'image', 'pending']
    assert assets[0]['queue_context'] is False and assets[2]['queue_context'] is True


def test_signed_thumbnail_resize_is_same_asset_but_opaque_url_stays_strict():
    root='https://media.test/12345678-1234-1234-1234-123456789abc'
    a=f'IMG|{root}?w=400&X-Goog-Signature=old||video|200|300'
    b=f'IMG|{root}?w=800&X-Goog-Signature=new||video|250|350'
    assert media_signature_matches(a,b)
    assert not media_signature_matches('IMG|https://media.test/poster?w=400||video|200|300',
        'IMG|https://media.test/poster?w=800||video|250|350')


def test_grid_download_hover_selects_original_and_never_upscale(tmp_path):
    callbacks={};calls=[]
    download=NS(save_as=lambda path:Path(path).write_bytes(b'original video'))
    def on(event,fn):callbacks[event]=fn
    original=NS(click=lambda **kw:(calls.append('Original size'),callbacks['download'](download)))
    row=NS(click=lambda **kw:calls.append('Download'),hover=lambda **kw:calls.append('hover Download'))
    b=FlowBrowser.__new__(FlowBrowser)
    b._page=NS(on=on,remove_listener=lambda event,fn:callbacks.pop(event),wait_for_timeout=lambda ms:None)
    b._save_browser_video_artifact=lambda d,p:(d.save_as(p),p)[1]
    b._try_resolve=lambda action,**kw:original if action=='download_video_original_option' else None
    output=str(tmp_path/'clip.mp4')
    assert b._download_from_tile_button(row,output)==output
    assert calls==['Download','hover Download','Original size'] and not callbacks


def test_reviewed_editor_rejects_other_project_before_navigation(tmp_path):
    b=FlowBrowser.__new__(FlowBrowser)
    b._page=NS(goto=lambda *a,**kw:pytest.fail('Must validate before navigation'))
    with pytest.raises(ValueError,match='saved Flow project'):
        b.download_reviewed_editor_video('https://flow.google.com/project/other/edit/video',
            str(tmp_path/'clip.mp4'),'https://flow.google.com/project/saved')


def test_recorded_recovery_uses_signature_and_never_calls_generation(tmp_path):
    out=str(tmp_path/'recovered.mp4');journal=tmp_path/'take_01.mp4.flow-request.json'
    url='https://flow.google.com/project/saved';sig='IMG|https://media.test/video||video|200|300'
    journal.write_text(json.dumps({'kind':'video','project_url':url,'signature':sig,'baseline':['old']}))
    calls=[]
    b=NS(ensure_project=lambda *a,**kw:calls.append('open project'),
        media_assets=lambda:[{'sig':sig,'kind':'video'}],
        download_latest_asset=lambda output,**kw:(calls.append(kw),Path(output).write_bytes(b'video')))
    p=FlowBrowserProvider.__new__(FlowBrowserProvider);p._ensure=lambda:b;p._is_valid_video_file=lambda path:Path(path).is_file()
    p._generate_video_once=lambda *a,**kw:pytest.fail('Recovery must not generate')
    result=p.recover_recorded_video('Job',out,str(journal),project_url=url)
    assert result['credits']==0 and calls[1]['preferred_signature']==sig


def test_factory_reviewed_recovery_requires_confirmation_and_saved_request(tmp_path,monkeypatch):
    from engine.factory import Factory
    from engine.project.manifest import Shot
    import engine.providers.flow_browser as module
    f=Factory(outputs=str(tmp_path/'outputs'),db_path=str(tmp_path/'jobs.db'))
    job=f.create_job('recovery',images_per_shot=0)
    m=f.pm.load_manifest(job);m.shots=[Shot(shot_id='shot_001',status='failed')];f.pm.save_manifest(m)
    url='https://flow.google.com/project/saved';f._remember_flow_project_url(job,url)
    folder=Path(f.pm.dirs(job)['flow'])/'shots/shot_001';folder.mkdir(parents=True)
    (folder/'take_01.mp4.flow-request.json').write_text(json.dumps({'kind':'video','project_url':url,'signature':'exact'}))
    asset=url+'/edit/verified-video'
    with pytest.raises(ValueError,match='Review'):
        f.recover_flow_video(job,shot_id='shot_001',asset_url=asset)
    with pytest.raises(ValueError,match='saved Flow project'):
        f.recover_flow_video(job,shot_id='shot_001',asset_url='https://flow.google.com/project/other/edit/video',asset_reviewed=True)
    seen=[]
    class Provider:
        def recover_recorded_video(self,project,out,journal,**kwargs):
            seen.append(kwargs);Path(out).write_bytes(b'video');return {'path':out,'project_url':url}
        def close(self):pass
    monkeypatch.setattr(module,'FlowBrowserProvider',Provider)
    monkeypatch.setattr(f,'associate_download',lambda *a:{'take':'reviewed.mp4','qc':{'decision':'ACCEPT'}})
    result=f.recover_flow_video(job,shot_id='shot_001',asset_url=asset,asset_reviewed=True)
    assert result['accepted'] and seen[0]['asset_url']==asset


def test_reviewed_editor_download_uses_asset_toolbar_not_download_project(tmp_path):
    calls=[];url='https://flow.google.com/project/saved/edit/video'
    class Controls:
        def __init__(self,items):self.items=items
        def count(self):return len(self.items)
        def nth(self,index):return self.items[index]
    toolbar=NS(is_visible=lambda **kw:True)
    keyboard=NS(press=lambda key:calls.append(key))
    page=NS(url=url,goto=lambda target,**kw:calls.append(target),wait_for_timeout=lambda ms:None,
            keyboard=keyboard,get_by_role=lambda role,**kw:Controls([toolbar]),locator=lambda selector:Controls([]))
    b=FlowBrowser.__new__(FlowBrowser);b._page=page;b._ensure_project_guard_page=lambda project:None
    b._wait_for_largest_media_ready=lambda *a,**k:None
    b._download_from_tile_button=lambda control,out:calls.append('asset download') or out
    assert b.download_reviewed_editor_video(url,str(tmp_path/'video.mp4'),'https://flow.google.com/project/saved').endswith('video.mp4')
    assert calls==[url,'Escape','asset download']

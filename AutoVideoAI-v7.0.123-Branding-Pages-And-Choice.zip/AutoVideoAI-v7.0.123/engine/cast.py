"""Frozen character cast and explicitly reviewed speaker turns."""
from pathlib import Path
import hashlib
import json
import math
from .content_library import CharacterLibrary, character_snapshot
from .production import read, save, digest, run, probe


def snapshot_cast(ids, library_root='data/content/characters'):
    if not isinstance(ids,list) or len(ids)>3 or len(ids)!=len(set(ids)):
        raise ValueError('Select up to three distinct saved characters')
    library=CharacterLibrary(library_root)
    return [character_snapshot(library.get(identifier)) for identifier in ids]


def resolve_cast_reference(root, character, index, reference, reference_dir=None):
    root=Path(root).resolve()
    original=Path(reference['path'])
    name=f"character-{character['id']}-{index}{original.suffix.lower()}"
    installation=root.parent.parent
    candidates=[Path(reference_dir or root/'references')/name, original,
                installation/'data/content/characters'/character['id']/original.name]
    normalized=str(original).replace('\\','/')
    if '/data/content/characters/' in normalized:
        relative=Path(normalized.split('/data/content/characters/',1)[1])
        if '..' not in relative.parts:
            candidates.append(installation/'data/content/characters'/relative)
    source=next((p for p in candidates if p.is_file() and digest(p)==reference['sha256']),None)
    if source is None:
        raise ValueError(f"Saved character photo is missing or changed: {character.get('name', character['id'])}, photo {index+1} ({original.name}). Migrate outputs and data from the previous installation; no generation submitted.")
    return source


def register_cast(root, references):
    root=Path(root)
    cast=read(root/'cast_snapshot.json',{}).get('characters') or []
    if not cast:
        primary=read(root/'character_snapshot.json')
        cast=[primary] if primary else []
    for character in cast:
        for index,reference in enumerate(character.get('references',[])):
            original=Path(reference['path'])
            name=f"character-{character['id']}-{index}{original.suffix.lower()}"
            # Upgrade recovery uses only byte-identical saved media. Never adopt
            # an edited character's new photo or change the approved snapshot.
            source=resolve_cast_reference(root, character, index, reference, references.dir)
            target=str(Path(references.dir)/name)
            if source.resolve()!=Path(target).resolve():
                references.add('character',str(source),name)
            # Repair the runtime registry, while preserving approval snapshots.
            references.reg['character']=[p for p in references.get('character')
                if Path(p).name!=name]+[target]
            references._save()
    return cast


def photo_paths(references, shot=None):
    if not hasattr(references,'get'):return []
    chars=references.get('character')
    approved=[p for p in chars if Path(p).name.startswith('character-') and 'approved-' not in Path(p).name]
    chars=approved or chars
    ids=getattr(shot,'character_ids',[]) if shot is not None else []
    selected=[p for p in chars if any('character-'+identifier+'-' in Path(p).name for identifier in ids)] if ids else chars
    selected=selected or chars
    # First photo per character before adding a location; avoid one character's
    # alternate photos using the entire reference budget.
    unique=[];seen=set()
    for path in selected:
        key=Path(path).stem.rsplit('-',1)[0]
        if key not in seen:unique.append(path);seen.add(key)
    return [p for p in [*unique,*references.get('location')] if Path(p).is_file()][:3]


def prompt_identity(character):
    if character.get('references'):
        return str(character['name']) + ', preserve face and wardrobe from the attached original character photo; use the authored scene setting, lighting and action instead of the photo background'
    return character['canonical']


def assign_cast(shots, cast, turns=()):
    if turns:
        pieces=[]
        for shot in shots:
            edges=sorted({shot.voice_start,shot.voice_end,*[t['start'] for t in turns if shot.voice_start<t['start']<shot.voice_end]})
            for start,end in zip(edges,edges[1:]):
                piece=shot.model_copy(deep=True)
                piece.voice_start=start;piece.voice_end=end;piece.duration_target=end-start
                pieces.append(piece)
        shots[:]=pieces
        for index,shot in enumerate(shots):shot.shot_id=f'shot_{index+1:03d}'
    for shot in shots:
        text=(shot.narration+' '+shot.visual_goal).lower()
        selected=[c for c in cast if c['name'].lower() in text]
        matching=[t for t in turns if t['start'] < shot.voice_end and t['end'] > shot.voice_start]
        if matching:
            turn=max(matching,key=lambda t:min(t['end'],shot.voice_end)-max(t['start'],shot.voice_start))
            selected=[c for c in cast if c['id']==turn['character_id']]
            shot.speaker_id=turn['speaker_id']
        selected=selected or cast[:1]
        if selected:
            shot.character_ids=[c['id'] for c in selected]
            shot.subject='; '.join(c['name']+' ('+prompt_identity(c)+')' for c in selected)
    return shots


def validate_turns(turns, mapping, transcript):
    if not isinstance(turns,list) or not turns or len(turns)>200:
        raise ValueError('Provide 1–200 reviewed speaker turns')
    result=[]
    for turn in turns:
        speaker=str(turn.get('speaker_id',''));text=str(turn.get('text','')).strip()
        choice=mapping.get(speaker,{})
        if not text or not choice.get('character_id') or not choice.get('voice'):
            raise ValueError('Every speaker turn needs text, a saved character and an explicit voice')
        if choice.get('voice_style','unspecified') not in ('masculine','feminine','unspecified'):
            raise ValueError('Invalid reviewed speaker voice style')
        result.append({**turn,**choice,'speaker_id':speaker,'text':text})
    if ' '.join(t['text'] for t in result).split()!=str(transcript).split():
        raise ValueError('Speaker turns must preserve the reviewed transcript exactly and in order')
    return result


def synthesize_turns(turns, out, language, provider='auto'):
    from .audio.tts import synthesize_narration, _mp3_len
    folder=Path(out).parent/'speaker-turns';folder.mkdir(parents=True,exist_ok=True)
    paths=[];words=[];timeline=[];offset=0
    for index,turn in enumerate(turns):
        identity=hashlib.sha256(json.dumps([turn,language,provider],sort_keys=True).encode()).hexdigest()[:16]
        path=folder/f'{index:03d}-{identity}.mp3'
        if path.exists() and _mp3_len(str(path))>0:
            duration=float(_mp3_len(str(path)));timed=[]
        else:
            result=synthesize_narration(turn['text'],turn['voice'],str(path),provider=provider,
                language=language,provider_voice=turn.get('provider_voice',''))
            duration=float(result.get('duration') or _mp3_len(str(path)));timed=result.get('words') or []
        if not math.isfinite(duration) or duration<=0:raise ValueError('Speaker turn produced no playable audio')
        # Use explicitly estimated timing when provider timings are unavailable.
        if not timed:
            tokens=turn['text'].split();step=duration/max(1,len(tokens))
            timed=[{'word':word,'start':i*step,'end':(i+1)*step,'timing_source':'script-estimated'} for i,word in enumerate(tokens)]
        for word in timed:words.append({**word,'start':word['start']+offset,'end':word['end']+offset,'speaker_id':turn['speaker_id']})
        timeline.append({'speaker_id':turn['speaker_id'],'character_id':turn['character_id'],
                         'text':turn['text'],'start':offset,'end':offset+duration,'voice':turn['voice']})
        offset+=duration;paths.append(str(path))
    # Binary media inputs are concatenated by the decoder, not a shell manifest.
    command=['ffmpeg','-hide_banner','-loglevel','error','-y']
    for path in paths:command+=['-i',path]
    graph=''.join(f'[{i}:a]' for i in range(len(paths)))+f'concat=n={len(paths)}:v=0:a=1[a]'
    command+=['-filter_complex',graph,'-map','[a]','-c:a','libmp3lame',str(out)]
    run(command,timeout=300)
    save(Path(out).parent.parent/'speaker_timing.json',{'turns':timeline})
    return {'audio':str(out),'words':words,'duration':offset,'engine':'reviewed-multi-speaker'}


def propose_speakers(source_url, transcript):
    from urllib.parse import urlsplit
    url=urlsplit(source_url)
    if url.scheme!='https' or url.hostname not in ('youtube.com','www.youtube.com','youtu.be'):
        raise ValueError('Automatic speaker proposals currently require a public YouTube source URL')
    from .providers.gemini_web import gemini_web_generate
    response=gemini_web_generate('Return only JSON. Analyze speaker turns; never guess a person\'s gender identity. '+
        'Suggest masculine/feminine/unspecified voice presentation only when audible, uncertain otherwise. '+
        'Preserve every supplied transcript word, in order. Do not add or translate words.',
        'Analyze this source video: '+source_url+'\nReturn {"speakers":[{"speaker_id":"SPEAKER_1",'+
        '"voice_style":"unspecified","description":""}],"turns":[{"speaker_id":"SPEAKER_1","text":""}]}.'+
        '\nExact excerpt transcript: '+transcript)
    response=response.strip()
    if response.startswith('```'):response=response.split('\n',1)[1].rsplit('```',1)[0]
    proposal=json.loads(response)
    if ' '.join(t['text'] for t in proposal.get('turns',[])).split()!=transcript.split():
        raise ValueError('Gemini speaker proposal changed the transcript; review or label turns manually')
    speakers=proposal.get('speakers',[])
    import re
    if not 1<=len(speakers)<=3 or any(not re.fullmatch(r'SPEAKER_[1-3]',str(s.get('speaker_id',''))) or s.get('voice_style') not in ('masculine','feminine','unspecified') for s in speakers):
        raise ValueError('Speaker proposal needs 1–3 identifiable speakers; review manually')
    if any(t.get('speaker_id') not in {s['speaker_id'] for s in speakers} for t in proposal['turns']):raise ValueError('Unknown speaker in proposal')
    return proposal


def job_cast(job_dir):
    """The saved characters this job's storyboard will use, from its own snapshot (v7.0.122).

    ``character_snapshot.json`` / ``cast_snapshot.json`` are written by Create when the job is made, so a job
    always says which saved character it carries - including a job made from a prepared narration batch.
    """
    root = Path(job_dir)
    for name, key in (('cast_snapshot.json', 'characters'), ('character_snapshot.json', None)):
        data = read(root / name)
        if not isinstance(data, dict):
            continue
        rows = (data.get(key) if key else [data]) or []
        rows = [row for row in rows if isinstance(row, dict) and row.get('id')]
        if rows:
            return rows
    return []


def set_job_cast(job_dir, ids):
    """Choose the saved characters of a job that has not planned its scenes yet (v7.0.122).

    A job made from a prepared narration batch holds no cast, so its storyboard invents a new person even
    though the user saved a character. Writing the same snapshots Create writes means the next Resume plans
    that exact character. A job whose storyboard already exists keeps the identity its shots were planned
    with - its shots carry the reference photos they were compiled for, so changing the cast now would be a
    silently different video.
    """
    root = Path(job_dir)
    if not root.is_dir():
        raise ValueError('This job folder does not exist: ' + str(root))
    manifest = read(root / 'production_manifest.json', {}) or {}
    shots = [shot for shot in (manifest.get('shots') or []) if isinstance(shot, dict)]
    if shots:
        raise ValueError('This job already has a storyboard (' + str(len(shots)) + ' scene(s)), so its cast is '
                         'fixed. Nothing was changed. Choose the character when you create the next video; '
                         'this job keeps the identity its scenes were planned with.')
    wanted = list(dict.fromkeys(str(identifier) for identifier in (ids or [])))
    cast = snapshot_cast(wanted) if wanted else []
    if cast:
        save(root / 'character_snapshot.json', cast[0])
        save(root / 'cast_snapshot.json', {'characters': cast})
    else:
        for name in ('character_snapshot.json', 'cast_snapshot.json'):
            path = root / name
            if path.is_file():
                path.unlink()
    return {'ids': [character['id'] for character in cast],
            'names': [str(character.get('name') or character['id']) for character in cast],
            'photos': sum(len(character.get('references') or []) for character in cast)}

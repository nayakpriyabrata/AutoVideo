"""Durable background jobs for Clip Studio B-roll renders."""
from __future__ import annotations

from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import threading

from .production_lock import production_slot, acquire, release
from .review_lock import review_transaction
from .progress import JobProgress


_tasks: dict[str, dict] = {}
_guard = threading.Lock()


def _atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')
    os.replace(temporary, path)


def job_dir(review_path: str) -> Path:
    review = Path(review_path).expanduser().resolve()
    identity = hashlib.sha256(str(review).encode()).hexdigest()[:16]
    return review.parent / '.clip-render-jobs' / identity


def _read(path: Path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


def _lock_active(root: Path) -> bool:
    from .job_monitor import is_running
    if is_running(root):
        return True
    lock = root / '.launch.lock'
    if not lock.exists():
        return False
    with lock.open('a+b') as handle:
        try:
            acquire(handle, blocking=False)
        except BlockingIOError:
            return True
        release(handle)
    return False


def start(review_path: str) -> bool:
    """Start or resume one exact saved review; never duplicate a live render."""
    review = Path(review_path).expanduser().resolve()
    if not review.is_file():
        raise FileNotFoundError('Saved B-roll review is unavailable')
    review_bytes = review.read_bytes()
    saved_review = json.loads(review_bytes)
    if (not isinstance(saved_review, dict) or not isinstance(saved_review.get('candidates'), list)
            or any(not isinstance(item, dict) for item in saved_review['candidates'])):
        raise ValueError('Saved B-roll review is invalid')
    review_digest = hashlib.sha256(review_bytes).hexdigest()
    root = job_dir(str(review))
    root.mkdir(parents=True, exist_ok=True)
    key = str(root)
    with _guard:
        task = _tasks.get(key)
        if (task and task['thread'].is_alive()) or _lock_active(root):
            return False
        reservation = (root / '.launch.lock').open('a+b')
        folder_lock = None
        try:
            acquire(reservation, blocking=False)
            folder_lock = (review.parent / '.production.lock').open('a+b')
            acquire(folder_lock, blocking=False)
        except BlockingIOError:
            if folder_lock is not None:
                folder_lock.close()
            reservation.close()
            return False
        except BaseException:
            if folder_lock is not None:
                folder_lock.close()
            reservation.close()
            raise

        def unlock():
            # Closing releases both OS locks even when a worker exits with error.
            folder_lock.close()
            reservation.close()

        total_clips = len({os.path.realpath(str(item.get('clip_output') or ''))
                           for item in saved_review.get('candidates', [])
                           if item.get('approved') and item.get('rights_reviewed') and item.get('clip_output')})
        state = {
            'kind': 'clip_broll_render', 'review_path': str(review),
            'status': 'queued', 'stage': 'Queued', 'percent': 0,
            'info': 'Waiting for the local production slot',
            'completed_clips': 0, 'total_clips': total_clips,
            'started_at': datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
            'completed_at': None, 'outputs': [], 'error': None,
        }
        try:
            _atomic_json(root / 'state.json', state)
        except BaseException:
            unlock()
            raise
        task = {'result': None, 'error': None}

        def work():
            progress = None
            try:
                with production_slot(root), review_transaction(str(review)):
                    progress = JobProgress(str(root))
                    if hashlib.sha256(review.read_bytes()).hexdigest() != review_digest:
                        raise ValueError('B-roll review changed while queued; reload and start the reviewed batch again')
                    state.update(status='running', stage='Preparing saved review', percent=1,
                                 info='Validating exact approved assets')
                    _atomic_json(root / 'state.json', state)

                    def update(stage, percent, info=''):
                        match = re.search(r'(?:clip\s+)?(\d+)/(\d+)', str(info), re.I)
                        if match and str(stage) in {'Clip complete', 'Reusing completed clip'}:
                            state['completed_clips'] = int(match.group(1))
                            state['total_clips'] = int(match.group(2))
                        state.update(status='running', stage=str(stage), percent=round(float(percent), 2),
                                     info=str(info or ''))
                        progress.emit(stage, percent, info)
                        _atomic_json(root / 'state.json', state)

                    from .broll import apply_clip_studio_review
                    result = apply_clip_studio_review(str(review), progress_cb=update)
                    state.update(status='completed', stage='Clip render completed', percent=100,
                                 info=f"{len(result.get('outputs', []))} output clip(s) ready",
                                 outputs=result.get('outputs', []), completed_at=datetime.datetime.now().astimezone().isoformat(timespec='seconds'))
                    state['completed_clips'] = state.get('total_clips', len(result.get('outputs', [])))
                    progress.emit(state['stage'], 100, state['info'])
                    task['result'] = result
            except Exception as error:
                state.update(status='failed', stage='Clip render failed', error=str(error),
                             info='Saved progress is retained; Resume retries unfinished clips.',
                             completed_at=datetime.datetime.now().astimezone().isoformat(timespec='seconds'))
                if progress is not None:
                    progress.emit(state['stage'], state.get('percent', 0), str(error))
                task['error'] = str(error)
            finally:
                try:
                    _atomic_json(root / 'state.json', state)
                finally:
                    unlock()

        task['thread'] = threading.Thread(target=work, name='clip-render-' + root.name,
                                          daemon=False)
        _tasks[key] = task
        try:
            task['thread'].start()
        except BaseException:
            _tasks.pop(key, None)
            state.update(status='failed', stage='Could not start render worker')
            try:
                _atomic_json(root / 'state.json', state)
            finally:
                unlock()
            raise
    return True


def snapshot(review_path: str) -> dict:
    root = job_dir(review_path)
    state = _read(root / 'state.json', {})
    task = _tasks.get(str(root), {})
    running = bool(task.get('thread') and task['thread'].is_alive()) or _lock_active(root)
    if state.get('status') in {'queued', 'running'} and not running:
        state = {**state, 'status': 'interrupted', 'stage': 'Render interrupted',
                 'info': 'Studio stopped before completion. Resume continues from completed clips.'}
    try:
        with (root / 'logs/runtime.log').open('rb') as handle:
            handle.seek(0, 2)
            handle.seek(max(0, handle.tell() - 24000))
            logs = handle.read().decode('utf-8', errors='replace').splitlines()[-40:]
    except OSError:
        logs = []
    return {'exists': bool(state), 'running': running, 'state': state, 'logs': logs,
            'job_dir': str(root)}


def discover(roots) -> list[dict]:
    """Find persisted clip render jobs without loading or regenerating clips."""
    found = {}
    for value in roots:
        root = Path(value).expanduser().resolve()
        if not root.is_dir():
            continue
        for state_path in root.glob('**/.clip-render-jobs/*/state.json'):
            state = _read(state_path, {})
            review = str(state.get('review_path') or '')
            if review:
                found[review] = snapshot(review)
    return sorted(found.values(), key=lambda item: str(item['state'].get('started_at') or ''), reverse=True)

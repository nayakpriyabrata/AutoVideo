# AutoVideoAI 7.0.65 — Speech, Gemini video and cleanup

## Install
Finish or stop production and close Studio before updating. Extract the ZIP beside your existing AutoVideoAI-v7 directory. From your existing installation run:

```bash
python3 ../AutoVideoAI-v7.0.65/tools/update_v764_to_v765.py .
python3 ../AutoVideoAI-v7.0.65/tools/update_v764_to_v765.py . --apply
./dashboard.sh
```

The updater accepts an unchanged v7.0.64 or already updated v7.0.65 installation, backs up changed code, and preserves runtime data. It refuses unknown local code changes; do not bypass that check. This build does not automatically update your running WSL installation.

## Speech first, then cards
Enable speech-timed cards in Guided Studio. Final narration and word timing are prepared before Gemini proposes short cards using word indexes. The renderer uses those word boundaries rather than scaling guessed timestamps across the video. Changed audio or script invalidates old cards. Cards remain reviewable suggestions. Estimated timing is explicitly marked when speech recognition is unavailable; it is not perfect alignment.

Enable preparation of selected language editions for English, Hindi and Odia. Each edition has its own translation, narration, timing and card suggestions. Review translations, pronunciation and card copy before finishing. The existing channel profiles provide separate branding assets; shared music can be reused. The finishing logo is bottom-right and the separate channel name is top-left with subtle motion.

Multilingual jobs retain a clean visual master before narration, captions and branding. Finishing Studio reuses it so an English caption or logo is not baked into the other editions. This does not automatically re-edit all shots to fit every translation. Narration longer than the picture must be shortened or the picture extended before export; the tool reports this rather than silently truncating it.

## Optional Gemini Web video shots — experimental
Choose zero to four Gemini shots for a new video job (default zero). The planner reserves up to that many eligible Flow shots, requests approximately ten seconds each, and measures the actual downloaded duration. Duration, available models and account quotas are controlled by Gemini; ten seconds and four available generations are not guaranteed.

A finished text response is not completion. The adapter waits up to ten minutes for a playable video tile and saves the exact conversation. An interrupted transfer retains that request. Resume reopens the same chat and does not send another prompt. If the chat URL was never captured, assisted reconciliation is required. Pending generation chats are retained. No additional Flow credits are charged for Gemini shots, but Gemini account usage applies. AI video shots retain the existing protection from stock B-roll overlays.

The Gemini upload/download adapter is tested with simulated browser states, not a live signed-in account. Keep this option off for critical jobs until one account-level pilot succeeds. Existing Flow recovery guards remain enabled; this release does not claim to eliminate all Chromium or third-party UI failures.

## Optional image-project cleanup
Enable automatic image-project cleanup for the job. After browser production closes, the tool inventories projects and deletes only those proven eligible by the existing complete-gallery and captured-asset checks. Pending, mixed-media and video projects are retained for recovery. Cleanup results are recorded in logs/automatic-project-cleanup.json. Uncertain deletion is not blindly repeated. Video project deletion remains a deliberate user cleanup action.

## Music and publishing checks
Reuse tracks in AutoVideoAI-Shared/music_library and select the actual local track/library entry in the job. Keep source and licence records. Existing music preflight and narration ducking remain active. A selected path alone does not prove the final mix is audible: preview an exported section with speech and a section without it before publishing.

This release was checked with 90 focused Python tests including actual FFmpeg rendering, audio presence and clean-master tests. Browser recovery tests simulate interruption and ensure a second prompt is not submitted. Control Center checks and updater checks are separate. These checks do not certify the quality or rights of an unseen final video.

## Editorial assessment and next priorities
A large audience needs reliable review more than more automatic effects. Use a clear opening promise, a short visual hook, sparse readable cards, relevant footage, restrained branding, audible music under speech and an appropriate closing action. Avoid repeated B-roll and long generic intros on short clips.

Remaining work includes live Google UI validation, automatic per-language picture retiming, semantic footage review, better render-cache profiling on WSL, and measured audience-retention feedback. No build can promise platform reach or a flawless third-party generation service. Existing jobs and uncertain requests should be recovered before generating replacements.

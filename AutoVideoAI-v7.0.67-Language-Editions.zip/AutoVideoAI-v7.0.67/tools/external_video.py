#!/usr/bin/env python3
"""Export planned AI shots, opt into external production, and import reviewed MP4s."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine.factory import Factory
from engine.external_video import configure,export_plan,import_clip
p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['plan','enable','disable','import']);p.add_argument('job');p.add_argument('--shots',nargs='+');p.add_argument('--shot-id');p.add_argument('--file');p.add_argument('--platform',default='');p.add_argument('--reviewed',action='store_true');p.add_argument('--replace-pending',action='store_true');a=p.parse_args();f=Factory()
if a.action=='plan':result=export_plan(f,a.job,a.shots)
elif a.action in ('enable','disable'):result=configure(f,a.job,a.shots,a.action=='enable')
else:
 if not a.shot_id:p.error('--shot-id is required')
 source=a.file or str(Path(f.pm.job_dir(a.job))/'external_video/incoming'/f'{a.shot_id}.mp4')
 result=import_clip(f,a.job,a.shot_id,source,reviewed=a.reviewed,platform=a.platform,replace_pending=a.replace_pending)
print(json.dumps(result,indent=2))

"""
Factory (v3 orchestrator) - Topic -> plan -> script -> narration -> storyboard ->
Flow/local generation -> QC -> retries -> edit -> captions -> sound -> 1080p.

Resumable: every stage persists; rerunning continues where it stopped.
DRY RUN vs FLOW CREDIT GENERATION vs LOCAL FREE are always explicit.
"""
from __future__ import annotations
import os
import json
import shutil
import time
import hashlib
import glob
from pathlib import Path
import re
import yaml

from .project.manager import ProjectManager
from .project.database import JobDB
from .project.manifest import ProductionManifest, Shot
from .planning.script import plan_content
from .planning.story_bible import build_bible
from .planning.director import create_production_plan
from .planning.prompt_compiler import compile_shot
from .routing.credit_router import CreditRouter
from .routing.provider_router import ProviderRouter, NeedsDecision
from .reference_manager import ReferenceManager
from .cast import photo_paths
from .audio.tts import synthesize_narration, fit_narration_to_target
from .runtime_log import runtime_print as print
from .presentation import resolve_presentation, visual_duration, PRESENTATION_KEYS
from .narration_policy import (
    buffered_script_target_seconds, narration_duration_matches_target,
    narration_grace_seconds,
)
from .providers.flow_browser import FlowRequestPending

# Profiles that use the Flow browser bridge (scene images + Veo/Omni generation).
FLOW_PROFILES = ("FLOW_CINEMATIC", "FLOW_BALANCED", "FLOW_ECONOMY", "STORYBOARD_ECONOMY", "MANUAL_DIRECTOR")
_ECONOMY_FRAME_HEARTBEAT_SECONDS = 15


def _setting_int(settings, key, default):
    value = (settings or {}).get(key)
    return int(default if value is None else value)


class AssistedNeeded(Exception):
    def __init__(self, job_id: str, shot_id: str, prompt: str, watch_dir: str, reason: str):
        super().__init__(f"Assisted Flow Mode needed for {shot_id}: {reason}")
        self.job_id, self.shot_id, self.prompt, self.watch_dir, self.reason = \
            job_id, shot_id, prompt, watch_dir, reason


def _typed_flow_error(text, flowp):
    """Rebuild a typed Flow error from a failure text that was returned, not raised."""
    from .providers.flow_browser import FlowBrowserClosedError, FlowTransientNetworkError
    if flowp.is_browser_closed_error(text):
        return FlowBrowserClosedError(str(text))
    if flowp.is_transient_network_error(text):
        return FlowTransientNetworkError(str(text))
    return None


class FlowRequestFailed(RuntimeError):
    """A saved Flow request failed recovery without the user opting to pause."""


class RecoverableInterruption(NeedsDecision):
    def __init__(self, job_id, shot_id, original, project_url=''):
        super().__init__(str(original), alternatives=[f'python3 cli.py v3 resume {job_id}'])
        self.shot_id, self.original, self.project_url = shot_id, original, project_url


def load_preset(name: str) -> dict:
    # Studio's older theme identifier must not silently load photorealism.
    name = "cartoon_story" if name == "cartoon_3d" else name
    p = os.path.join("config", "presets", f"{name}.yaml")
    if not os.path.exists(p):
        p = os.path.join("config", "presets", "cinematic_realism.yaml")
    with open(p, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _save_json(path: str, obj):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, default=str)


class FlowFrameBatchPending(RuntimeError):
    def __init__(self, report):
        self.report = report
        super().__init__(f"Flow frame recovery needs attention: {len(report['unresolved'])} frame(s). Other independent frames were processed; no media was substituted.")


class Factory:
    def _pause_pending_flow(self, m, shot_id, error, project_url=""):
        from .automatic_recovery import can_recover
        recoverable = can_recover(error)
        automatic = recoverable and getattr(self, '_automatic_recovery_active', False)
        current = self.pm.load_manifest(m.job_id)
        current.status = "running" if automatic else "paused"
        self.pm.save_manifest(current)
        self.db.upsert(m.job_id, status=current.status)
        self._write_pause_state(m.job_id, shot_id, str(error),
                                kind="flow_download_or_ui", project_url=project_url,
                                automatic_recovery=automatic)
        if recoverable:
            raise RecoverableInterruption(m.job_id, shot_id, error, project_url)
        raise NeedsDecision(str(error), alternatives=[f"python3 cli.py v3 resume {m.job_id}"])

    def _fail_pending_flow(self, m, shot_id, error, project_url=""):
        """Stop without PAUSED when the user did not opt into Flow pauses.

        Keep the request journal intact. In particular, this does not submit a
        replacement video generation: an explicit Resume can retry the same
        request's exact-asset download later.
        """
        current = self.pm.load_manifest(m.job_id)
        current.status = "failed"
        for shot in current.shots:
            if shot.shot_id == shot_id and not shot.accepted_take:
                shot.status = "failed"
                break
        self.pm.save_manifest(current)
        self.db.upsert(m.job_id, status="failed")
        self.pm.log(m.job_id, "flow_request_failed_without_pause", {
            "shot": shot_id, "project_url": project_url,
            "error_type": type(error).__name__,
            "error": " ".join(str(error).split())[:1200],
        })

    def _archive_flow_request_for_fallback(self, out_path: str) -> str:
        """Archive a pending Flow image request after a valid free fallback exists."""
        journal = out_path + ".flow-request.json"
        if not os.path.isfile(journal):
            return ""
        try:
            with open(journal, encoding="utf-8") as handle:
                request = json.load(handle)
            request.update({"status": "abandoned_for_free_image_fallback",
                            "fallback_provider": "free_image", "fallback_at": time.time()})
            archive = out_path + ".flow-request.fallback.json"
            if os.path.exists(archive):
                archive = out_path + f".flow-request.fallback-{time.time_ns()}.json"
            temporary = archive + ".tmp"
            with open(temporary, "w", encoding="utf-8") as handle:
                json.dump(request, handle, indent=2)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, archive)
            os.remove(journal)
            return archive
        except Exception as exc:
            # Keep the original request if audit archival/removal fails; the caller
            # will not publish the fallback over an unarchived pending request.
            print(f"[Flow] Could not archive abandoned image request: {type(exc).__name__}")
            return ""

    def _free_image_fallback(self, shot, compiled, out_path, vertical, free_provider,
                             *, label="image"):
        """Generate a local/free still atomically, then archive any Flow request."""
        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        temporary = out_path + ".free-fallback.jpg"
        if os.path.exists(temporary):
            try:
                os.remove(temporary)
            except OSError:
                pass
        result = free_provider.generate_image(shot, compiled, temporary, vertical, dry_run=False)
        generated = result.get("path")
        if not generated or not self._is_valid_image_file(generated):
            self._remove_invalid_image(temporary)
            raise RuntimeError(f"{label}: {result.get('error', 'free provider returned no valid image')}")
        if os.path.abspath(generated) != os.path.abspath(temporary):
            shutil.copy2(generated, temporary)
        if not self._is_valid_image_file(temporary):
            self._remove_invalid_image(temporary)
            raise RuntimeError("free provider returned a corrupt/incomplete image")
        # Archive/remove the Flow request before publishing the fallback file. If
        # the process stops in between, FlowBrowserProvider sees the archive and
        # blocks a duplicate Flow submission until the free fallback is restored.
        had_pending_request = os.path.isfile(out_path + ".flow-request.json")
        if had_pending_request and not self._archive_flow_request_for_fallback(out_path):
            self._remove_invalid_image(temporary)
            raise RuntimeError("could not safely archive the pending Flow image request")
        os.replace(temporary, out_path)
        _save_json(out_path + '.free-image.json', {'shot_id':shot.shot_id, 'label':label,
                   'path':os.path.abspath(out_path), 'sha256':self._file_sha256(out_path), 'provider':'free'})
        return out_path

    def __init__(self, outputs: str = "outputs", db_path: str = "data/jobs.db"):
        self.pm = ProjectManager(outputs)
        self.db = JobDB(db_path)

    # ---------------- job setup ----------------
    def create_job(self, topic: str, video_type: str = "shorts", target_seconds: int = 45,
                   aspect: str = "9:16", language: str = "en", voice: str = "en-IN-PrabhatNeural",
                   content_type: str = "education", tone: str = "cinematic",
                   preset: str = "cinematic_realism", profile: str = "FLOW_BALANCED",
                   cartoon_provider: str = "flow", movieflow_mode: str = "full_story",
                   movieflow_project_url: str = "", movieflow_wait_seconds: int = 1800,
                   movieflow_recovery_wait_seconds: int = 300,
                   budgets: dict | None = None, dry_run: bool = False,
                   tts_provider: str = "auto", images_per_shot: int = 2,
                   video_share: float = 0.20, stock_share: float = 0.60,
                   flow_scenes: int | None = None, max_flow_scenes: int | None = None, frame_source: str = "auto",
                   flow_video_mode: str = "frames",
                   flow_approval: str = "once", max_generation_credits: int = 10, flow_approval_cards: int = 1,
                   shot_max_seconds: float | None = None, flow_frame_retries: int = 3,
                   network_wait_seconds: int = 300, flow_capacity_wait_seconds: int = 900,
                   flow_capacity_retries: int = 8, flow_image_wait_seconds: int = 60,
                   flow_project_url: str = "",
                   flow_video_retries: int = 1, flow_video_ready_grace_seconds: int = 20,
                   flow_video_recovery_wait_seconds: int = 180,
                   flow_reuse_project_media: bool = True,
                   flow_reuse_mode: str = "exact",
                   flow_image_workers: int = 1,
                   flow_pause_on_unresolved_request: bool | None = None,
                   gemini_chat_cleanup: str = "keep",
                   script_provider: str = "auto", script_model: str = "auto",
                   script_quality: str = "publish", tts_model: str = "",
                   tts_voice: str = "", tts_style: str = "",
                   caption_provider: str = "auto", caption_model: str = "whisper-large-v3-turbo",
                   caption_local_model: str = "small", caption_align_script: bool = True,
                   max_tts_speedup: float = 1.08, auto_retime_script: bool = True,
                   render_quality: str = "high",
                   production_mode: str = "legacy", dynamic_video_scenes: int | None = None,
                   stock_scenes: int | None = None, stock_source: str = "auto",
                   caption_display: str = "auto", background_music: str = "off",
                   music_mood: str = "", channel_name: str = "", channel_logo: str = "", channel_logo_size: str = "Small",
                   graphics_overlays: bool = False, watermark: bool = False,
                   voiceover_enabled: bool | None = None, text_cards_enabled: bool | None = None,
                   text_card_style: str = "auto", caption_template: str = "auto", background_music_path: str = "",
                   music_volume: float | None = None, sound_effects_enabled: bool | None = None,
                   ambience_enabled: bool | None = None, destination: str | None = None,
                   approved_plan_path: str = "", narration_input_path: str = "",
                   character_id: str = "", character_ids: list[str] | None = None,
                   broll_count: int = 0, broll_duration: float = 2.0, broll_max_uses: int = 1,
                   broll_query_hint: str = "", broll_auto: bool = False, external_video_mode: bool = False,
                   speech_cards_enabled: bool = False, gemini_video_count: int = 0,
                   flow_auto_cleanup_images: bool = False, card_draft_provider: str = "gemini-web",
                   hooks_enabled: bool = False) -> str:
        if type(gemini_video_count) is not int or not 0 <= gemini_video_count <= 4:
            raise ValueError("Gemini video count must be between zero and four")
        from .broll import validate_broll_options
        broll_options = validate_broll_options(broll_count,broll_duration,broll_max_uses,broll_query_hint,broll_auto)
        from .languages import language_pack, default_voice
        if flow_pause_on_unresolved_request is None:
            try:
                with open("config/user_settings.yaml", encoding="utf-8") as handle:
                    global_settings = yaml.safe_load(handle) or {}
                flow_pause_on_unresolved_request = global_settings.get(
                    "flow_pause_on_unresolved_request", False)
            except Exception:
                flow_pause_on_unresolved_request = False
        if isinstance(flow_pause_on_unresolved_request, str):
            flow_pause_on_unresolved_request = flow_pause_on_unresolved_request.strip().lower() in {
                "1", "true", "yes", "on"}
        else:
            flow_pause_on_unresolved_request = bool(flow_pause_on_unresolved_request)
        language = language_pack(language).code
        if voice == 'en-IN-PrabhatNeural' and language != 'en':
            voice = default_voice(language)
        if language == 'or' and caption_provider in ('auto','groq','local'):
            caption_provider = 'script-timed'  # Explicit estimated timings; never pretend Whisper supports or.
        delivery = None
        if destination:
            from .publishing import destination_profile
            delivery = destination_profile(destination)
            aspect = '16:9' if destination == 'youtube_long' else '9:16'
            if target_seconds > delivery['max_seconds']:
                raise ValueError('Duration exceeds the chosen conservative delivery recipe')
        from .cast import snapshot_cast
        cast_ids = list(character_ids or ([character_id] if character_id else []))
        cast = snapshot_cast(cast_ids)
        character_id = cast_ids[0] if cast_ids else ''
        if approved_plan_path:
            from .content_plan import load_plan
            approved = load_plan(approved_plan_path)
            if approved.get('audio_mode', 'voiceover') != 'voiceover' and voiceover_enabled is not False:
                raise ValueError('This visual-only plan requires Music only or Silent audio mode')
            if approved.get('audio_mode', 'voiceover') != 'voiceover' and abs(sum(float(s.get('duration',6)) for s in approved['scenes'])-target_seconds) > .05:
                raise ValueError('Visual scene durations must match the requested video duration')
            if approved['language'] != language:
                raise ValueError('Imported plan language must match the job language')
        resolve_presentation({"voiceover_enabled": voiceover_enabled, "text_cards_enabled": text_cards_enabled,
                              "text_card_style": text_card_style, "background_music": background_music, "caption_template": caption_template, "watermark": watermark,
                              "music_volume": music_volume, "sound_effects_enabled": sound_effects_enabled,
                              "ambience_enabled": ambience_enabled, "caption_display": caption_display})
        W, H = (1080, 1920) if aspect == "9:16" else (1920, 1080)
        m = ProductionManifest(job_id=self.pm.new_job_id(topic), topic=topic, video_type=video_type,
                               target_seconds=target_seconds, aspect=aspect, width=W, height=H,
                               language=language, voice=voice, content_type=content_type, tone=tone,
                               preset=preset, profile=profile, dry_run=dry_run)
        self.pm.create(m)
        _save_json(os.path.join(self.pm.job_dir(m.job_id), "settings.json"),
                   {"budgets": budgets or {}, "tts_provider": tts_provider,
                    "cartoon_provider": str(cartoon_provider or "flow"),
                    "movieflow_mode": str(movieflow_mode or "full_story"),
                    "movieflow_project_url": str(movieflow_project_url or "").strip(),
                    "movieflow_wait_seconds": int(movieflow_wait_seconds or 1800),
                    "movieflow_recovery_wait_seconds": int(movieflow_recovery_wait_seconds or 300),
                    "images_per_shot": images_per_shot,
                    "video_share": float(video_share), "stock_share": float(stock_share),
                    "flow_scenes": flow_scenes, "max_flow_scenes": max_flow_scenes, "frame_source": frame_source,
                    "flow_video_mode": str(flow_video_mode or "frames"),
                    "flow_approval": flow_approval, "flow_approval_cards": int(flow_approval_cards),
                    "max_generation_credits": int(max_generation_credits),
                    "shot_max_seconds": shot_max_seconds,
                    "flow_frame_retries": int(flow_frame_retries),
                    "network_wait_seconds": int(network_wait_seconds),
                    "flow_capacity_wait_seconds": int(flow_capacity_wait_seconds),
                    "flow_capacity_retries": int(flow_capacity_retries),
                    "flow_image_wait_seconds": int(flow_image_wait_seconds),
                    "flow_project_url": str(flow_project_url or "").strip(),
                    "flow_video_retries": int(flow_video_retries),
                    "flow_video_ready_grace_seconds": int(flow_video_ready_grace_seconds),
                    "flow_video_recovery_wait_seconds": int(flow_video_recovery_wait_seconds),
                    "flow_reuse_project_media": bool(flow_reuse_project_media),
                    "flow_reuse_mode": str(flow_reuse_mode or "exact"),
                    "flow_image_workers": max(1, min(3, int(flow_image_workers or 1))),
                    "flow_pause_on_unresolved_request": bool(flow_pause_on_unresolved_request),
                    "gemini_chat_cleanup": str(gemini_chat_cleanup or "keep"),
                    "script_provider": str(script_provider or "auto"),
                    "script_model": str(script_model or "auto"),
                    "script_quality": str(script_quality or "publish"),
                    "tts_model": str(tts_model or ""),
                    "tts_voice": str(tts_voice or ""),
                    "tts_style": str(tts_style or ""),
                    "caption_provider": str(caption_provider or "auto"),
                    "caption_model": str(caption_model or "whisper-large-v3-turbo"),
                    "caption_local_model": str(caption_local_model or "small"),
                    "caption_align_script": bool(caption_align_script),
                    "max_tts_speedup": float(max_tts_speedup or 1.08),
                    "auto_retime_script": bool(auto_retime_script),
                    "render_quality": str(render_quality or "high"),
                    "production_mode": str(production_mode or "legacy"),
                    "dynamic_video_scenes": dynamic_video_scenes,
                    "stock_scenes": stock_scenes,
                    "stock_source": str(stock_source or "auto"),
                    "caption_display": str(caption_display or "full"),
                    "background_music": str(background_music or "off"),
                    "music_mood": str(music_mood or ""), "external_video_mode": bool(external_video_mode),
                    "speech_cards_enabled": bool(speech_cards_enabled), "gemini_video_count": gemini_video_count,
                    "flow_auto_cleanup_images": bool(flow_auto_cleanup_images),
                    "card_draft_provider": str(card_draft_provider or "gemini-web"),
                    "hooks_enabled": bool(hooks_enabled),
                    "channel_name": str(channel_name or ""),
                    "channel_logo": str(channel_logo or ""), "channel_logo_size": channel_logo_size,
                    "graphics_overlays": bool(graphics_overlays),
                    "watermark": bool(watermark), "caption_template": caption_template,
                    "voiceover_enabled": voiceover_enabled, "text_cards_enabled": text_cards_enabled,
                    "text_card_style": text_card_style, "background_music_path": background_music_path,
                    "music_volume": music_volume, "sound_effects_enabled": sound_effects_enabled,
                    "ambience_enabled": ambience_enabled, "destination": destination,
                    "approved_plan_path": approved_plan_path, "narration_input_path": narration_input_path,
                    "character_id": character_id, **broll_options})
        # Freeze these two choices for new jobs; later global defaults must not
        # unexpectedly switch a saved storyboard to a different recipe.
        job_settings_path = os.path.join(self.pm.job_dir(m.job_id), "settings.json")
        actual = resolve_presentation(self._settings(m.job_id))
        job_settings = json.load(open(job_settings_path, encoding="utf-8"))
        job_settings.update(voiceover_enabled=actual.voiceover, text_cards_enabled=actual.text_cards)
        _save_json(job_settings_path, job_settings)
        m.voiceover_enabled = actual.voiceover
        m.timing_source = "narration" if actual.voiceover else "visual_storyboard"
        self.pm.save_manifest(m)
        self.db.upsert(m.job_id, topic=topic, status="created", video_type=video_type,
                       target_seconds=target_seconds, aspect=aspect, profile=profile,
                       preset=preset, dry_run=1 if dry_run else 0,
                       flow_project=str(flow_project_url or "").strip())
        self.pm.log(m.job_id, "job_created", {"profile": profile, "preset": preset, "dry_run": dry_run})
        if approved_plan_path:
            self.import_content_plan(m.job_id, approved)
        if cast:
            _save_json(os.path.join(self.pm.job_dir(m.job_id), 'character_snapshot.json'), cast[0])
            _save_json(os.path.join(self.pm.job_dir(m.job_id), 'cast_snapshot.json'), {'characters':cast})
        return m.job_id

    def _settings(self, job_id: str) -> dict:
        merged: dict = {"budgets": {}, "tts_provider": "auto", "monthly_credits": None,
                    "cartoon_provider": "flow", "movieflow_mode": "full_story",
                    "movieflow_project_url": "", "movieflow_wait_seconds": 1800,
                    "movieflow_recovery_wait_seconds": 300,
                    "images_per_shot": 2, "video_share": 0.20, "stock_share": 0.60,
                    "flow_scenes": None, "max_flow_scenes": None, "frame_source": "auto",
                    "flow_video_mode": "frames",
                    "flow_approval": "once", "max_generation_credits": 10, "flow_approval_cards": 1,
                    "shot_max_seconds": None, "flow_frame_retries": 3,
                    "network_wait_seconds": 300, "flow_capacity_wait_seconds": 900,
                    "flow_capacity_retries": 8, "flow_image_wait_seconds": 60, "flow_project_url": "",
                    "flow_video_retries": 1, "flow_video_ready_grace_seconds": 20,
                    "flow_video_recovery_wait_seconds": 180, "flow_reuse_project_media": True,
                    "flow_reuse_mode": "exact", "flow_image_workers": 1,
                    "flow_pause_on_unresolved_request": False,
                    "flow_local_closing_fallback": False, "flow_continue_unresolved_frames": False,
                    "flow_replace_unresolved_images": False, "flow_image_replacement_limit": 30,
                    "gemini_chat_cleanup": "keep",
                    "script_provider": "auto", "script_model": "auto", "script_quality": "publish",
                    "tts_model": "", "tts_voice": "", "tts_style": "",
                    "caption_provider": "auto", "caption_model": "whisper-large-v3-turbo",
                    "caption_local_model": "small", "caption_align_script": True,
                    "max_tts_speedup": 1.08, "auto_retime_script": True,
                    "render_quality": "high", "production_mode": "legacy",
                    "dynamic_video_scenes": None, "stock_scenes": None, "stock_source": "auto",
                    "caption_display": "auto", "background_music": "off", "music_mood": "",
                    "channel_name": "", "channel_logo": "", "graphics_overlays": False, "watermark": False,
                    "voiceover_enabled": True, "text_cards_enabled": None, "text_card_style": "auto", "caption_template": "auto",
                    "background_music_path": "", "music_volume": None,
                    "sound_effects_enabled": None, "ambience_enabled": None, "destination": None, "approved_plan_path": "",
                    "narration_input_path": "", "character_id": "", "narration_runtime_policy": "strict", "speech_cards_enabled": False, "gemini_video_count": 0, "flow_auto_cleanup_images": False}
        try:  # global user defaults
            import yaml as _yaml
            if os.path.exists("config/user_settings.yaml"):
                with open("config/user_settings.yaml", encoding="utf-8") as f:
                    g = _yaml.safe_load(f) or {}
                merged["budgets"] = dict(g.get("budgets", {}))
                merged["tts_provider"] = g.get("tts_provider", "auto")
                merged["monthly_credits"] = g.get("monthly_credits")
                merged["images_per_shot"] = int(g.get("images_per_shot", 2) or 0)
                for key in ("cartoon_provider", "movieflow_mode", "movieflow_project_url", "movieflow_wait_seconds", "movieflow_recovery_wait_seconds", "video_share", "stock_share", "flow_scenes", "max_flow_scenes", "frame_source", "flow_video_mode",
                            "flow_approval", "max_generation_credits", "flow_approval_cards", "shot_max_seconds",
                            "flow_frame_retries", "network_wait_seconds",
                            "flow_capacity_wait_seconds", "flow_capacity_retries",
                            "flow_project_url", "flow_video_retries", "flow_video_ready_grace_seconds",
                            "flow_video_recovery_wait_seconds", "flow_reuse_project_media",
                            "flow_reuse_mode", "flow_image_workers", "flow_pause_on_unresolved_request",
                            "flow_local_closing_fallback", "flow_continue_unresolved_frames",
                            "flow_replace_unresolved_images", "flow_image_replacement_limit", "flow_image_replacement_policy_version",
                            "gemini_chat_cleanup", "script_provider", "script_model", "script_quality",
                            "tts_model", "tts_voice", "tts_style", "caption_provider",
                            "caption_model", "caption_local_model", "caption_align_script",
                            "max_tts_speedup", "auto_retime_script", "render_quality",
                            "production_mode", "dynamic_video_scenes", "stock_scenes", "stock_source",
                            "caption_display", "background_music", "music_mood", "channel_name", "channel_logo",
                            "graphics_overlays", "watermark", "voiceover_enabled", "text_cards_enabled", "text_card_style", "caption_template",
                            "background_music_path", "music_volume", "sound_effects_enabled", "ambience_enabled", "destination",
                            "approved_plan_path", "narration_input_path", "character_id", "narration_runtime_policy", "external_video_shots", "external_video_mode", "speech_cards_enabled", "gemini_video_count", "flow_auto_cleanup_images"):
                    if key in g:
                        merged[key] = g[key]
        except Exception:
            pass
        try:  # per-job overrides
            with open(os.path.join(self.pm.job_dir(job_id), "settings.json"), encoding="utf-8") as f:
                j = json.load(f)
            merged["budgets"].update(j.get("budgets", {}))
            merged["tts_provider"] = j.get("tts_provider", merged["tts_provider"])
            if "images_per_shot" in j:
                merged["images_per_shot"] = int(j["images_per_shot"] or 0)
            for key in ("cartoon_provider", "movieflow_mode", "movieflow_project_url", "movieflow_wait_seconds", "movieflow_recovery_wait_seconds", "video_share", "stock_share", "flow_scenes", "max_flow_scenes", "frame_source", "flow_video_mode",
                        "flow_approval", "max_generation_credits", "flow_approval_cards", "shot_max_seconds",
                        "flow_frame_retries", "network_wait_seconds",
                        "flow_capacity_wait_seconds", "flow_capacity_retries",
                        "flow_project_url", "flow_video_retries", "flow_video_ready_grace_seconds",
                        "flow_video_recovery_wait_seconds", "flow_reuse_project_media",
                        "flow_reuse_mode", "flow_image_workers", "flow_pause_on_unresolved_request",
                            "flow_local_closing_fallback", "flow_continue_unresolved_frames",
                            "flow_replace_unresolved_images", "flow_image_replacement_limit", "flow_image_replacement_policy_version",
                        "gemini_chat_cleanup", "script_provider", "script_model", "script_quality",
                        "tts_model", "tts_voice", "tts_style", "caption_provider",
                        "caption_model", "caption_local_model", "caption_align_script",
                        "max_tts_speedup", "auto_retime_script", "render_quality",
                        "production_mode", "dynamic_video_scenes", "stock_scenes", "stock_source",
                        "caption_display", "background_music", "music_mood", "channel_name", "channel_logo",
                        "graphics_overlays", "watermark", "voiceover_enabled", "text_cards_enabled", "text_card_style", "caption_template",
                            "background_music_path", "music_volume", "sound_effects_enabled", "ambience_enabled", "destination",
                            "approved_plan_path", "narration_input_path", "character_id", "narration_runtime_policy", "external_video_shots", "external_video_mode", "speech_cards_enabled", "gemini_video_count", "flow_auto_cleanup_images"):
                if key in j and not (key in PRESENTATION_KEYS and j[key] is None):
                    merged[key] = j[key]
        except Exception:
            pass
        from .broll import BROLL_KEYS,validate_broll_options
        defaults=validate_broll_options()
        saved_broll=j if isinstance(locals().get('j'),dict) else {}
        merged.update({k:saved_broll.get(k,defaults[k]) for k in BROLL_KEYS})
        pause_value = merged.get("flow_pause_on_unresolved_request", False)
        if isinstance(pause_value, str):
            merged["flow_pause_on_unresolved_request"] = pause_value.strip().lower() in {
                "1", "true", "yes", "on"}
        else:
            merged["flow_pause_on_unresolved_request"] = bool(pause_value)
        # An upgrade cannot grant replacement permission. Existing reservations
        # and versioned explicit preferences retain their original caps.
        if merged.get('flow_image_replacement_policy_version') != 1:
            merged['flow_replace_unresolved_images'] = False
        merged['flow_image_replacement_policy_version'] = 1
        return merged

    @staticmethod
    def _movieflow_full_story_enabled(m, settings: dict) -> bool:
        return (str(settings.get("cartoon_provider", "flow")).lower() == "movieflow"
                and str(settings.get("movieflow_mode", "full_story")).lower() == "full_story"
                and str(getattr(m, "content_type", "")).lower() in {"kids_story", "cartoon_story", "story", "kids"})

    def _remember_movieflow_project_url(self, job_id: str, url: str | None) -> str:
        try:
            from .providers.movieflow_browser import MovieFlowBrowser
            url = MovieFlowBrowser.normalize_project_url(url)
        except Exception:
            url = str(url or "").strip()
        if not url:
            return ""
        try:
            sp = os.path.join(self.pm.job_dir(job_id), "settings.json")
            cfg = json.load(open(sp, encoding="utf-8")) if os.path.exists(sp) else {}
            if cfg.get("movieflow_project_url") != url:
                cfg["movieflow_project_url"] = url
                _save_json(sp, cfg)
                self.pm.log(job_id, "movieflow_project_bound", {"url": url})
                print(f"[MovieFlow] Bound AutoVideoAI job to MovieFlow project: {url}")
        except Exception:
            pass
        return url

    @staticmethod
    def _movieflow_story_prompt(m, plan: dict, bible: dict, preset: dict, narration_dur: float) -> str:
        chars = bible.get("characters") or bible.get("character") or bible.get("main_character") or []
        locs = bible.get("locations") or bible.get("location") or bible.get("setting") or []
        style = (bible.get("visual_style") or preset.get("visual_style") or preset.get("style")
                 or "cinematic family-friendly cartoon animation")
        mood = getattr(m, "tone", "warm")
        return (
            ("Create a complete dialogue-free cartoon story from the following visual story notes. "
             if not getattr(m, "voiceover_enabled", True) else
             "Create a complete cartoon story video from the following original narration. ") +
            "Use MovieFlow's story/Agent workflow to parse the story into coherent scenes. "
            "Keep the SAME main character identity, face, hairstyle, body proportions, wardrobe colors and art style in every scene. "
            "Maintain location continuity unless the story clearly changes setting. Avoid text, subtitles, logos and watermarks inside the generated visuals. "
            f"Target runtime: about {max(10, int(round(narration_dur)))} seconds. Aspect ratio: {getattr(m, 'aspect', '16:9')}. "
            f"Visual style: {style}. Mood: {mood}. "
            f"Character bible: {json.dumps(chars, ensure_ascii=False)[:2500]}. "
            f"Setting/location bible: {json.dumps(locs, ensure_ascii=False)[:1800]}. "
            "Story outcome must match the final narration sentence. Build clear beginning, middle, climax/lesson and ending. "
            "Generate a polished, family-friendly cartoon video with expressive acting, readable visual storytelling and smooth shot-to-shot continuity.\n\n"
            "NARRATION/STORY:\n" + str(plan.get("narration") or m.topic)
        )

    def _prepare_movieflow_full_story(self, m, plan: dict, bible: dict, preset: dict, narration_dur: float):
        prompt = self._movieflow_story_prompt(m, plan, bible, preset, narration_dur)
        shot = Shot(
            shot_id="shot_001", voice_start=0.0, voice_end=float(narration_dur),
            duration_target=float(narration_dur), narration=str(plan.get("narration") or ""),
            coverage="hero_outro", visual_goal=f"Complete MovieFlow cartoon story for: {m.topic}",
            subject=str(m.topic), subject_action="complete story progression",
            environment="MovieFlow story world from the character/location bible",
            camera_framing="cinematic animated sequence", camera_movement="story-driven",
            lighting="consistent stylized cartoon lighting", color_palette=str(getattr(m, "color_palette", "")),
            motion_intensity="medium", provider="movieflow", model="movieflow_story",
            gen_duration=max(4, int(round(narration_dur))), num_candidates=1,
            media_strategy="movieflow_full_story", compiled_prompt=prompt, qc_threshold=55, status="planned")
        m.shots = [shot]
        return m

    def _flow_project_url(self, job_id: str, settings: dict | None = None) -> str:
        """Resolve the exact Flow project URL for a job. Explicit setting wins, then DB."""
        from .providers.flow_browser import FlowBrowser
        url = FlowBrowser.normalize_project_url((settings or {}).get("flow_project_url", ""))
        if url:
            return url
        row = self.db.get(job_id) or {}
        return FlowBrowser.normalize_project_url(row.get("flow_project", ""))

    def _flow_video_project_url(self, job_id: str, settings: dict | None = None) -> str:
        """Dedicated motion-video project; never silently reuse the stills project.

        Existing pending requests remain pinned to their journal's project by
        FlowBrowserProvider. A new video project is created only on new calls.
        """
        from .providers.flow_browser import FlowBrowser
        override = FlowBrowser.normalize_project_url((settings or {}).get("flow_video_project_url", ""))
        if override:
            return override
        path = os.path.join(self.pm.job_dir(job_id), "flow_video_project.json")
        if os.path.isfile(path):
            try:
                with open(path, encoding="utf-8") as handle:
                    return FlowBrowser.normalize_project_url(json.load(handle).get("project_url", ""))
            except (OSError, ValueError, TypeError):
                pass
        return ""

    def flow_project_bindings(self, job_id: str, settings: dict | None = None) -> dict:
        """Where the stills project and the video project come from, and whether they collide.

        v7.0.103: the storyboard images and the motion videos must live in two different Flow projects,
        because a fresh video is matched to a shot by its prompt and gallery freshness inside one project.
        When both roles resolved to the same URL the run stopped with a one-line error that named neither
        project nor the fix.
        """
        from .providers.flow_browser import FlowBrowser

        settings = settings if settings is not None else self._settings(job_id)
        stills_setting = FlowBrowser.normalize_project_url((settings or {}).get("flow_project_url", ""))
        row = self.db.get(job_id) or {}
        stills_db = FlowBrowser.normalize_project_url(row.get("flow_project", ""))
        video_setting = FlowBrowser.normalize_project_url((settings or {}).get("flow_video_project_url", ""))
        video_file = ""
        path = os.path.join(self.pm.job_dir(job_id), "flow_video_project.json")
        if os.path.isfile(path):
            try:
                with open(path, encoding="utf-8") as handle:
                    video_file = FlowBrowser.normalize_project_url(json.load(handle).get("project_url", ""))
            except (OSError, ValueError, TypeError):
                video_file = ""
        stills = stills_setting or stills_db
        video = video_setting or video_file
        return {
            "job_id": job_id,
            "stills_project": stills,
            "stills_source": ("settings.json flow_project_url" if stills_setting else
                              "database flow_project" if stills_db else ""),
            "stills_candidates": {"settings": stills_setting, "database": stills_db},
            "video_project": video,
            "video_source": ("settings.json flow_video_project_url" if video_setting else
                             "flow_video_project.json" if video_file else ""),
            "video_candidates": {"settings": video_setting, "file": video_file},
            "conflict": bool(stills and video and stills == video),
        }

    def flow_project_conflict_message(self, job_id: str, settings: dict | None = None) -> str:
        """Explain a stills/video project collision and the exact repair, without guessing."""
        bindings = self.flow_project_bindings(job_id, settings)
        project = bindings["stills_project"]
        return (
            "The storyboard images and the video clips resolve to the same Flow project ("
            + project + "), so a new video could not be told apart from the stills in that gallery. "
            "Nothing was generated or charged for this shot. Both bindings are local files: "
            "stills = " + (bindings["stills_source"] or "not bound") + "; video = "
            + (bindings["video_source"] or "not bound") + ". "
            "Inspect them with `python3 cli.py v3 flow-projects " + job_id + "`. Either point the video "
            "production at its own project with `python3 cli.py v3 flow-projects " + job_id
            + " --clear-video` (the next video submission then opens a new one), or rebind the stills to "
            "their real storyboard project with `python3 cli.py v3 flow-projects " + job_id
            + " --set-stills https://flow.google.com/project/<storyboard-project-id>`, then resume. "
            "Until 7.0.103 a recovery that downloaded an already-finished video wrote the video project into "
            "the stills binding, which is how a job can end up with both roles on one project; 7.0.103 no "
            "longer does that. No images or credits are touched by either repair command.")

    def flow_project_missing_record(self, job_id: str) -> dict:
        """The last recorded 'Project not found' for this job, or {} (v7.0.104)."""
        path = os.path.join(self.pm.job_dir(job_id), "flow_project_missing.json")
        try:
            with open(path, encoding="utf-8") as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def _record_flow_project_missing(self, job_id: str, url: str, role: str = "video") -> dict:
        payload = {"project_url": str(url or ""), "role": role,
                   "at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
                   "job_id": job_id}
        _save_json(os.path.join(self.pm.job_dir(job_id), "flow_project_missing.json"), payload)
        self.pm.log(job_id, "flow_project_missing", payload)
        return payload

    def flow_project_missing_message(self, job_id: str, url: str, role: str = "video") -> str:
        """Explain a 404 project with the exact repair for this job."""
        fallback = "flow_video_project.json" if role == "video" else "settings.json flow_project_url"
        try:
            bound = (self.flow_project_bindings(job_id).get(
                "video_source" if role == "video" else "stills_source") or fallback)
        except Exception:
            bound = fallback
        other = "stills" if role == "video" else "video"
        return (
            "Flow answered 'Project not found' for the stored " + role + " project (" + (url or "<none>")
            + "), so it was deleted, belongs to another Google account, or the stored id is stale. Nothing was "
            "submitted or charged. That URL is stored in " + bound + "; see both bindings with "
            "`python3 cli.py v3 flow-projects " + job_id + "`. Repair options: "
            "`python3 cli.py v3 flow-projects " + job_id + " --clear-" + role + " --confirm` (the next "
            + role + " submission opens its own project) or "
            "`python3 cli.py v3 flow-projects " + job_id + " --set-" + role
            + " https://flow.google.com/project/<real-project-id> --confirm`. The " + other + " project is "
            "untouched. Any clip that was only in the deleted project is gone; a shot whose clip no longer "
            "exists needs a replacement request (it spends credits) - nothing does that automatically.")

    def _remember_flow_video_project_url(self, job_id: str, url: str | None) -> str:
        from .providers.flow_browser import FlowBrowser
        from .flow_project_isolation import persist_project_binding
        url = FlowBrowser.normalize_project_url(url)
        if not url:
            return ""
        path = os.path.join(self.pm.job_dir(job_id), "flow_video_project.json")
        return persist_project_binding(path, url, "video", job_id)

    def _remember_flow_project_url(self, job_id: str, url: str | None) -> str:
        """Persist Flow's /project/<uuid> URL for deterministic resume/recovery."""
        from .providers.flow_browser import FlowBrowser
        url = FlowBrowser.normalize_project_url(url)
        if not url:
            return ""
        row = self.db.get(job_id) or {}
        if row.get("flow_project") != url:
            self.db.upsert(job_id, flow_project=url)
            self.pm.log(job_id, "flow_project_bound", {"url": url})
            print(f"[Flow] Bound AutoVideoAI job to Flow project: {url}")
        # Keep the per-job settings portable as well as the SQLite binding.
        try:
            sp = os.path.join(self.pm.job_dir(job_id), "settings.json")
            cfg = json.load(open(sp, encoding="utf-8")) if os.path.exists(sp) else {}
            if cfg.get("flow_project_url") != url:
                cfg["flow_project_url"] = url
                _save_json(sp, cfg)
        except Exception:
            pass
        return url

    def pause_state(self, job_id: str) -> dict:
        """Return durable user guidance for a paused/assisted job."""
        path = os.path.join(self.pm.job_dir(job_id), "pause_state.json")
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def recovery_state(self, job_id: str, reason: str = "") -> dict:
        """Current read-only guidance; opening Queue never creates a pause."""
        m = self.pm.load_manifest(job_id)
        pending = [s for s in m.shots if not s.accepted_take]
        if not pending:
            return {}
        state = dict(self.pause_state(job_id))
        shot = next((s for s in pending if s.shot_id == state.get("shot_id")), pending[0])
        if state.get("kind") == "legacy_pause_recovery" or not state.get("reason"):
            state["reason"] = reason or f"Saved job status: {m.status}. Exact request recovery is available."
        # v7.0.104: the saved pause can describe a request that has since been resolved (shot_014 while the
        # production stopped at shot_018). Say what is true now instead of two shots in one panel.
        try:
            from .flow_resume_safety import check_job
            from .pause_freshness import refresh as refresh_pause
            unresolved = check_job(self.pm.job_dir(job_id)).get("unresolved", [])
            fresh = refresh_pause(state.get("reason"), state.get("shot_id"), unresolved,
                                  shot.shot_id, m.accepted_count(), len(m.shots))
            state["reason"] = fresh["reason"]
            state["paused_shot"] = fresh["paused_shot"]
            state["pause_notice_stale"] = fresh["stale"]
            state["unresolved_journals"] = fresh["unresolved_targets"]
            if fresh["stale"]:
                state["pause_notice_superseded"] = fresh["superseded"]
                # The saved reason described a resolved request; its stale cause must not be shown as current.
                state.pop("reason_detail", None)
        except Exception:
            pass
        settings = self._settings(job_id)
        # v7.0.106: each saved Flow video request is approved once - say whether that is on, what was clicked
        # in this job, and which saved requests are still waiting for their card.
        try:
            from .flow_approval_once import audit_rows, auto_allowed, clicks_for
            allowed, approve_reason = auto_allowed(settings)
            state["flow_auto_approve"] = bool(allowed)
            state["flow_auto_approve_reason"] = approve_reason
            state["flow_approvals"] = audit_rows(self.pm.job_dir(job_id))[-8:]
            pending_cards = []
            for row in (state.get("unresolved_journals") or []):
                journal = os.path.join(self.pm.job_dir(job_id), str(row))
                counts = clicks_for(journal)
                if counts["clicks"] < 1:
                    pending_cards.append(str(row))
            state["flow_unapproved_requests"] = pending_cards
        except Exception:
            pass
        state.update(job_id=job_id, shot_id=shot.shot_id, accepted_shots=m.accepted_count(),
                     total_shots=len(m.shots), status=m.status,
                     pause_on_unresolved=bool(settings.get("flow_pause_on_unresolved_request", False)))
        state.setdefault("actions", [{"label": "Resume saved job", "command": f"python3 cli.py v3 resume {job_id}"}])
        state.setdefault("flow_project_url", self._flow_project_url(job_id))
        # 7.0.96: a paused job used to repeat the same wait with no explanation. The last
        # recovery verdict and the one command that moves it forward are read-only facts.
        diagnosis = self.flow_journal_diagnosis(job_id)
        from .flow_resume_safety import journal_target
        if diagnosis:
            state.setdefault("flow_recovery_state", diagnosis.get("recovery_state"))
            state.setdefault("flow_last_recovery_error", diagnosis.get("last_recovery_error"))
            state.setdefault("flow_saved_project_url", diagnosis.get("saved_project_url"))
            state.setdefault("flow_next_action", diagnosis.get("next_action"))
            state["flow_journal_kind"] = diagnosis.get("kind", "")
            state["flow_pending_approval"] = bool(diagnosis.get("pending_approval"))
            # 7.0.98: the pause snapshot can name an older shot (shot_003 while the unresolved request is
            # shot_014). The unresolved journal is the truth.
            if diagnosis.get("shot_id") and diagnosis["shot_id"] in {s.shot_id for s in m.shots}:
                state["shot_id"] = diagnosis["shot_id"]
                state["flow_journal_shot"] = diagnosis["shot_id"]
            # Drop actions that point at a request which is no longer unresolved.
            live = str(diagnosis.get("journal") or "")
            state["actions"] = [a for a in state.get("actions", [])
                                if " archive-request " not in str(a.get("command", ""))
                                or (live and journal_target(live) in str(a.get("command", "")))]
            commands = {a.get("command") for a in state["actions"]}
            if diagnosis.get("video_recovery_command") and diagnosis["video_recovery_command"] not in commands:
                state["actions"].insert(0, {"label": "Recover the exact saved video (0 new credits)",
                                            "command": diagnosis["video_recovery_command"]})
            if diagnosis.get("approve_command") and diagnosis["approve_command"] not in commands:
                state["actions"].insert(0, {"label": "Approve the pending Flow card once (spends credits)",
                                            "command": diagnosis["approve_command"]})
            if diagnosis.get("archive_command") and diagnosis["archive_command"] not in commands:
                label = ("Allow one new free image request" if diagnosis.get("kind", "image") == "image"
                         else "Allow ONE new paid video request")
                state["actions"].append({"label": label, "command": diagnosis["archive_command"]})
        return state

    def flow_journal_diagnosis(self, job_id: str) -> dict:
        """Read the last saved Flow recovery verdict; never opens a browser. 7.0.96."""
        try:
            from .flow_resume_safety import check_job
            root = self.pm.job_dir(job_id)
            rows = check_job(root).get("unresolved", [])
        except Exception:
            return {}
        row = next((r for r in rows if r.get("recovery_state")), rows[0] if rows else None)
        if not row:
            return {}
        from .flow_resume_safety import image_request_row, journal_shot_id, journal_target
        from .flow_pending_approval import approve_command, evidence_for
        kind = 'image' if image_request_row(row) else (row.get('kind') or 'video')
        approval = {}
        try:
            approval = evidence_for(Path(self.pm.job_dir(job_id)) / str(row.get('journal') or ''))
        except (OSError, ValueError, TypeError):
            approval = {}
        notes = {
            "saved_project_not_reachable": ("The saved Flow project no longer opens, so another wait cannot "
                                            "produce this image. One new image request is free in Flow."),
            "no_generated_output_in_project": ("The saved project holds only the uploaded references. Resume "
                                               "submits one fresh free image request automatically."),
            "blocked_multiple_outputs": ("Two or more real images are saved. Review the project and keep one; "
                                         "nothing is resubmitted."),
            "recovery_checkpoint_retained": ("The Flow browser or a download failed. Nothing is resubmitted; fix "
                                             "the browser and Resume. The saved project is kept."),
            "fresh_request_not_started": ("The old request was archived, but the new free image request could not "
                                          "start. Resume again once the Flow browser is healthy; nothing was submitted."),
        }
        journal = str(row.get("journal") or "")
        shot_id = journal_shot_id(journal)
        state = row.get("recovery_state", "")
        command = video_command = ""
        if kind == "image" and state in ("saved_project_not_reachable", "no_generated_output_in_project"):
            command = f"python3 cli.py v3 archive-request {job_id} {journal_target(journal)}"
        if kind != "image":
            # 7.0.98: a video request is never "free". Offer download-only recovery, and keep a paid
            # replacement behind an explicit --confirm-new-credit-spend.
            shot_flag = f" --shot-id {shot_id}" if shot_id else ""
            video_command = (f"python3 cli.py v3 recover-flow-video {job_id}{shot_flag} --wait-seconds 180")
            command = f"python3 cli.py v3 archive-request {job_id} {journal_target(journal)} --confirm-new-credit-spend"
        next_action = notes.get(state, "")
        if kind != "image" and approval.get("suspected_pending"):
            # v7.0.99: no approval click is recorded for this submitted video request, so no video exists yet
            # and waiting again cannot produce one.
            cost = approval.get("cost")
            credits = f" ({cost} credits)" if isinstance(cost, int) else ""
            next_action = ("No approval click is recorded for this request. Either Flow is still waiting on the "
                           "card" + credits + " - nothing is generated until it is approved - or you approved it "
                           "directly in the Flow UI, where the click is not recorded here and the video may already "
                           "be in the project. Run the free download first (it costs no credits): if a clip exists "
                           "it is saved and QC runs; if nothing is there, approve that one card yourself or with the "
                           "command below and then download it.")
        if kind != "image" and not next_action:
            next_action = ("This is a video request: recover the exact saved video first (0 credits). A new video "
                           "generation spends credits, so nothing is resubmitted automatically.")
        return {"journal": journal, "recovery_state": state, "kind": kind, "shot_id": shot_id,
                "pending_approval": bool(approval.get("suspected_pending")),
                "approval_evidence": approval,
                "approve_command": approve_command(job_id, approval) if approval else "",
                "last_recovery_error": row.get("last_recovery_error", ""),
                "saved_project_url": row.get("saved_project_url", ""),
                "next_action": next_action,
                "archive_command": command, "video_recovery_command": video_command}

    def _write_pause_state(self, job_id: str, shot_id: str, reason: str,
                           kind: str = "flow_recovery",
                           project_url: str = "",
                           baseline_signatures=None, automatic_recovery=False) -> dict:
        """Persist exactly what stopped and the safest next actions."""
        import datetime
        try:
            m = self.pm.load_manifest(job_id)
            accepted, total = m.accepted_count(), len(m.shots)
        except Exception:
            accepted, total = 0, 0
        project_url = project_url or self._flow_project_url(job_id)
        baseline = sorted({str(x) for x in (baseline_signatures or []) if str(x)})
        recover = (f"python3 cli.py v3 recover-flow-video {job_id} "
                   f"--shot-id {shot_id} --wait-seconds 120")
        resume_action = {"label": "Resume the saved job after recovery/limit reset",
                         "command": f"python3 cli.py v3 resume {job_id}"}
        actions = [resume_action]
        if baseline:
            actions.insert(0, {"label": "Recover a new existing Flow video (no new credits)",
                               "command": recover})
        state = {
            "paused_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
            "kind": kind,
            "job_id": job_id,
            "shot_id": shot_id,
            "reason": str(reason),
            "flow_project_url": project_url,
            "accepted_shots": accepted,
            "total_shots": total,
            "safe_to_resume": True,
            "baseline_signatures": baseline,
            "safe_automatic_recovery": bool(baseline),
            "automatic_recovery_pending": bool(automatic_recovery),
            "actions": actions,
        }
        _save_json(os.path.join(self.pm.job_dir(job_id), "pause_state.json"), state)
        self.pm.log(job_id, "job_paused", state)
        from .support_report import redact
        tag = 'RECOVERING' if automatic_recovery else 'PAUSED'
        print(f"[{tag}] {job_id}/{shot_id} ({kind}): {redact(str(reason))}")
        print(f"[{tag}] Saved details: {os.path.join(self.pm.job_dir(job_id), 'pause_state.json')}. "
              f"Export diagnostics offline: python3 cli.py v3 support-report {job_id}")
        return state

    def import_content_plan(self, job_id, plan):
        from .content_plan import validate_plan, script_from_plan, plan_fingerprint
        from .production import save
        plan = validate_plan(plan)
        m = self.pm.load_manifest(job_id)
        if m.shots:
            raise ValueError('Do not replace an approved script after scene planning/generation; create a separate job')
        if plan['language'] != m.language:
            raise ValueError('Approved plan language does not match the job')
        if plan.get('audio_mode', 'voiceover') != 'voiceover' and resolve_presentation(self._settings(job_id)).voiceover:
            raise ValueError('This visual-only plan requires Music only or Silent audio mode')
        root = self.pm.job_dir(job_id)
        save(os.path.join(root,'approved_content_plan.json'), plan)
        save(os.path.join(root,'script.json'), script_from_plan(plan))
        settings = json.load(open(os.path.join(root,'settings.json'),encoding='utf-8'))
        settings.update(auto_retime_script=False, imported_plan_sha256=plan_fingerprint(plan),
                        narration_runtime_policy='visual_storyboard' if plan.get('audio_mode','voiceover') != 'voiceover' else 'measured')
        save(os.path.join(root,'settings.json'), settings)
        m.status = 'scripted';self.pm.save_manifest(m)
        self.db.upsert(job_id,status='scripted',script_status='imported')
        return {'job_id':job_id,'script_source':'approved-import','new_generations':0}

    def use_measured_narration_runtime(self, job_id: str):
        """Explicit local policy: accept shorter approved speech before scene planning."""
        m = self.pm.load_manifest(job_id)
        if m.shots:
            raise ValueError('Runtime cannot change after scene planning; preserve this job and create a new plan')
        path = os.path.join(self.pm.job_dir(job_id), 'settings.json')
        settings = json.load(open(path, encoding='utf-8'))
        settings['narration_runtime_policy'] = 'measured'
        settings['auto_retime_script'] = False
        _save_json(path, settings)
        self.pm.log(job_id, 'narration_runtime_policy', {'policy': 'measured', 'script_rewritten': False})
        return {'job_id': job_id, 'policy': 'measured', 'new_visual_generations': 0}

    def set_presentation_options(self, job_id: str, **updates) -> dict:
        """Local editing only: keep takes, scene timings, project bindings and journals."""
        from .job_monitor import is_running
        if is_running(self.pm.job_dir(job_id)):
            raise ValueError('This job is running. Wait for it to finish before changing saved rendering settings.')
        unknown = set(updates) - PRESENTATION_KEYS
        if unknown:
            raise ValueError("Unknown presentation option(s): " + ", ".join(sorted(unknown)))
        m = self.pm.load_manifest(job_id)
        merged = {**self._settings(job_id), **updates}
        resolve_presentation(merged)  # Validate every option before changing files.
        path = os.path.join(self.pm.job_dir(job_id), "settings.json")
        saved = json.load(open(path, encoding="utf-8"))
        saved.update(updates)
        from .production import save
        save(path, saved)
        m.voiceover_enabled = resolve_presentation(merged).voiceover
        self.pm.save_manifest(m)
        save(os.path.join(self.pm.job_dir(job_id), "production", "review.json"),
             {"status": "STALE_AFTER_PRESENTATION_CHANGE", "next_action": "Render the same accepted takes, then review"})
        self.pm.log(job_id, "presentation_changed", {"options": updates, "new_visual_generations": 0})
        return updates

    # ---------------- main run (resumable) ----------------
    def set_flow_pause_on_unresolved_request(self, job_id: str, enabled: bool) -> bool:
        """Persist an explicit pause choice for a saved job before resume."""
        self.pm.load_manifest(job_id)
        path = os.path.join(self.pm.job_dir(job_id), "settings.json")
        settings = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else {}
        enabled = bool(enabled)
        settings["flow_pause_on_unresolved_request"] = enabled
        _save_json(path, settings)
        self.pm.log(job_id, "flow_pause_policy_updated", {"pause_on_unresolved_request": enabled})
        return enabled

    def set_flow_image_wait_seconds(self, job_id: str, seconds: int) -> int:
        """How long one image request may wait before recovery reports no output (7.0.97)."""
        self.pm.load_manifest(job_id)
        seconds = max(5, min(3600, int(seconds)))
        path = os.path.join(self.pm.job_dir(job_id), "settings.json")
        settings = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else {}
        settings["flow_image_wait_seconds"] = seconds
        _save_json(path, settings)
        self.pm.log(job_id, "flow_image_wait_updated", {"seconds": seconds})
        return seconds

    def set_flow_frame_batch_recovery(self, job_id, enabled):
        manifest = self.pm.load_manifest(job_id)
        settings = self._settings(job_id)
        if enabled and (manifest.profile != "STORYBOARD_ECONOMY" or settings.get("frame_source") != "flow"):
            raise ValueError("Batch exact-frame recovery requires STORYBOARD_ECONOMY with frame_source=flow")
        settings["flow_continue_unresolved_frames"] = bool(enabled)
        _save_json(os.path.join(self.pm.job_dir(job_id), "settings.json"), settings)
        self.pm.log(job_id, "flow_frame_batch_policy_updated", {"enabled": bool(enabled)})
        return bool(enabled)

    def set_broll_options(self, job_id, **options):
        from .broll import validate_broll_options
        policy=validate_broll_options(**options)
        settings=self._settings(job_id);settings.update(policy)
        _save_json(os.path.join(self.pm.job_dir(job_id),'settings.json'),settings)
        return policy

    def set_flow_local_closing_fallback(self, job_id, enabled):
        """Explicitly permit opening-frame reuse; never resolve/delete Flow journals."""
        self.pm.load_manifest(job_id)
        settings = self._settings(job_id)
        settings['flow_local_closing_fallback'] = bool(enabled)
        _save_json(os.path.join(self.pm.job_dir(job_id), 'settings.json'), settings)
        self.pm.log(job_id, 'flow_local_closing_fallback_policy', {'enabled':bool(enabled)})
        return bool(enabled)

    def set_flow_image_replacement(self, job_id, enabled, limit=30):
        self.pm.load_manifest(job_id)
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError('Image replacement cap must be 1–100 for the whole job')
        settings = self._settings(job_id)
        settings.update(flow_replace_unresolved_images=bool(enabled),flow_image_replacement_limit=limit,flow_image_replacement_policy_version=1)
        _save_json(os.path.join(self.pm.job_dir(job_id), 'settings.json'), settings)
        self.pm.log(job_id,'flow_image_replacement_policy',{'enabled':bool(enabled),'job_cap':limit,'per_image_cap':1})
        return bool(enabled)

    def _local_closing_fallback(self, job_id, shot, out, root, error):
        opening = os.path.join(root, 'storyboard', shot.shot_id + '_open.jpg')
        if not self._is_valid_image_file(opening):
            return None
        shutil.copy2(opening, out)
        _save_json(out + '.local-fallback.json', {
            'source':opening, 'source_sha256':self._file_sha256(opening),
            'kind':'opening-frame-reuse', 'exact_flow_recovered':False,
            'pending_request_retained':True, 'reason':str(error)[-1600:]})
        self.pm.log(job_id, 'flow_closing_local_fallback', {'shot':shot.shot_id, 'source':opening})
        return out, 'local-opening-fallback'

    def set_gemini_cleanup(self, job_id, policy):
        if policy not in ("keep", "delete-after-read"):
            raise ValueError("Invalid Gemini cleanup policy")
        self.pm.load_manifest(job_id)  # Never create settings for a nonexistent job.
        path = os.path.join(self.pm.job_dir(job_id), "settings.json")
        with open(path, encoding="utf-8") as handle:
            settings = json.load(handle)
        settings["gemini_chat_cleanup"] = policy
        _save_json(path, settings)
        return policy

    def _disable_image_replacement_for_resume(self, job_id: str) -> None:
        """v7.0.71: a job with saved Flow requests is a resume. Replacement stays off.

        Replacement creates a second credit-bearing image request for a slot whose
        first request may still be rendering. Resume must recover the recorded
        request only, so the persisted permission is cleared before any work runs.
        """
        root = self.pm.job_dir(job_id)
        has_saved_request = False
        for _dir, _names, files in os.walk(root):
            if any(name.endswith(".flow-request.json") for name in files):
                has_saved_request = True
                break
        if not has_saved_request:
            return
        try:
            settings = self._settings(job_id)
        except Exception:
            return
        if settings.get("flow_replace_unresolved_images"):
            limit = int(settings.get("flow_image_replacement_limit", 30) or 30)
            self.set_flow_image_replacement(job_id, False, limit)
            self.pm.log(job_id, "flow_image_replacement_disabled_for_resume", {
                "reason": "saved Flow requests exist; resume recovers them without replacement"})
            print("[Flow] Image replacement disabled for this resume (saved requests exist).")

    def run_job(self, job_id: str, progress_cb=None, auto_render: bool = True) -> dict:
        # Multiple tabs may watch jobs; shared browser profiles and process-wide
        # provider settings require serialized production across tabs/installations.
        from .production_lock import production_slot
        from .automatic_recovery import run_with_recovery
        with production_slot(self.pm.job_dir(job_id)):
            self._disable_image_replacement_for_resume(job_id)
            # Safe by default across CLI, Streamlit, control center, and automation.
            # Never infer from a missing local file that a remote Flow request
            # failed; remote assets may already exist and consume credits.
            from .flow_resume_safety import require_safe_job, check_job
            from .progress import JobProgress
            reconciled = None
            recovery_progress = None  # created lazily: JobProgress sets process-wide runtime-log variables
            if check_job(self.pm.job_dir(job_id))['unresolved_count']:
                from .flow_resume_recovery import reconcile_job
                recovery_progress = JobProgress(self.pm.job_dir(job_id), progress_cb)
                reconciled = reconcile_job(self.pm.job_dir(job_id), self._settings(job_id), recovery_progress.emit)
            try:
                require_safe_job(self.pm.job_dir(job_id))
            except Exception:
                current = self.pm.load_manifest(job_id)
                current.status = "paused"
                self.pm.save_manifest(current)
                self.db.upsert(job_id, status="paused")
                if recovery_progress is None:
                    recovery_progress = JobProgress(self.pm.job_dir(job_id), progress_cb)
                # v7.0.87: when the only blocker is a saved image whose download was
                # interrupted, schedule a download-only automatic resume. Nothing is
                # uploaded, filled or sent; the exact request is kept.
                if (reconciled and reconciled.get("recoverable_only")
                        and self._settings(job_id).get("flow_auto_recovery", True) is True):
                    from .automatic_recovery import checkpoint
                    from .auto_resume import note_recoverable_failure
                    frames, accepted = checkpoint(self, job_id)
                    note_recoverable_failure(
                        self.pm.job_dir(job_id),
                        "Saved image download interrupted; automatic download-only resume scheduled. "
                        "No new Flow request is submitted.",
                        progress=[len(frames), len(accepted)])
                    self.pm.log(job_id, "flow_resume_auto_wait",
                                {"journals": [row["journal"] for row in reconciled.get("unresolved", [])]})
                    recovery_progress.emit("Automatic resume scheduled", 0,
                                           "Saved exact request kept; download-only retry")
                    # Returned, not raised: every caller records it with auto_resume.after_run.
                    return {"job_id": job_id, "status": "paused",
                            "message": "Saved image download interrupted; automatic download-only resume scheduled.",
                            "resume": f"python3 cli.py v3 resume {job_id}"}
                recovery_progress.emit("Recovery needs attention", 0,
                                       "Saved request unresolved; no new generation started")
                raise
            try:
                return run_with_recovery(self, job_id, progress_cb, auto_render)
            finally:
                if self._settings(job_id).get('flow_auto_cleanup_images'):
                    try:
                        from .flow_project_cleanup import inventory, delete_selected
                        root = self.pm.job_dir(job_id)
                        eligible = [row for row in inventory(root) if row['eligible']]
                        result = delete_selected(root, eligible, lock_held=True) if eligible else []
                        _save_json(os.path.join(root, 'logs', 'automatic-project-cleanup.json'), result)
                    except Exception as error:
                        self.pm.log(job_id, 'remote_cleanup_warning', {'error': str(error)[:400]})
                try:
                    from .job_cleanup import cleanup_job
                    report=cleanup_job(self.pm.job_dir(job_id), apply=True)
                    _save_json(os.path.join(self.pm.job_dir(job_id),'logs','cleanup.json'),report)
                    self.pm.log(job_id,'safe_cleanup',{'freed_bytes':report['freed_bytes'],
                                                     'warnings':report['warnings']})
                except Exception as error:
                    try:self.pm.log(job_id,'safe_cleanup_warning',{'error':str(error)[:300]})
                    except Exception:pass

    def _run_job(self, job_id: str, progress_cb=None, auto_render: bool = True) -> dict:
        from .progress import JobProgress
        progress = JobProgress(self.pm.job_dir(job_id), progress_cb)
        def prog(stage, pct, info=""):
            try:
                progress.emit(stage, pct, info)
            except Exception:
                pass

        m = self.pm.load_manifest(job_id)
        D = self.pm.dirs(job_id)
        settings = self._settings(job_id)
        from .clip_recreation import require_recreation_approval
        require_recreation_approval(D['root'])
        presentation = resolve_presentation(settings)
        m.voiceover_enabled = presentation.voiceover
        os.environ["AUTOVIDEO_GEMINI_CHAT_CLEANUP"] = str(
            settings.get("gemini_chat_cleanup", "keep") or "keep")
        prog("Gemini temporary-chat policy", 1, os.environ["AUTOVIDEO_GEMINI_CHAT_CLEANUP"])
        os.environ["AUTOVIDEO_STOCK_SOURCE"] = str(settings.get("stock_source", "auto") or "auto")
        self._check_storage(D["root"], prog)
        router = CreditRouter(m.profile, overrides=settings.get("budgets"))
        preset = load_preset(m.preset)
        # Optional visual-density override. Long videos normally work well around
        # 6-9 seconds per visual beat; this controls the maximum without changing
        # narration duration.
        if settings.get("shot_max_seconds"):
            preset = dict(preset)
            sl = list(preset.get("shot_length", [4, 8]))
            mx = max(2.0, float(settings["shot_max_seconds"]))
            preset["shot_length"] = [min(float(sl[0]), mx), mx]
        dry = m.dry_run
        refs = ReferenceManager(D["references"])
        from .cast import register_cast, assign_cast, photo_paths
        cast = register_cast(D["root"], refs)

        if not dry and presentation.music_mode != 'off':
            from .audio.job_music import obtain_job_music
            mood = str(settings.get('music_mood', '') or m.audio_mood or preset.get('music_style', '')
                       or f'soft motivational {m.content_type} instrumental')
            prog('Checking music before visual generation', 3)
            preflight = obtain_job_music(D['audio'], presentation.music_mode,
                mood if settings.get('music_mood') else m.topic + ' ' + mood, presentation.music_path)
            if preflight.get('path'):
                prog('Music ready', 3, str(preflight.get('source', '')) + (' · ' + preflight['warning'] if preflight.get('warning') else ''))
            if not preflight.get('path'):
                message = ('Requested background music needs a playable asset before generation. ' + str(preflight.get('error') or '') +
                           ' Choose a licensed local file, retry music lookup, or explicitly select Silent. No new visuals were generated.')
                prog('Music needs attention', 3, message)
                raise RuntimeError(message)

        # ---- 1. script ----
        script_path = os.path.join(D["root"], "script.json")
        # Long-form writers often under-deliver the requested word count. Ask
        # for a bounded narration buffer (5 min request -> ~6 min script), while
        # keeping the manifest/render target unchanged. Measured TTS below is the
        # source of truth and is accepted within a one-minute long-form window.
        script_target_seconds = buffered_script_target_seconds(
            m.target_seconds,
            voiceover_enabled=(presentation.voiceover and
                               bool(settings.get("auto_retime_script", True))),
        )
        script_headroom = script_target_seconds - m.target_seconds
        script_target_words = None
        if script_headroom:
            from .languages import language_pack
            from .planning.script_engine import NATURAL_WORDS_PER_SEC
            script_pack = language_pack(m.language)
            script_words_per_second = (
                NATURAL_WORDS_PER_SEC if script_pack.code == "en"
                else script_pack.words_per_second
            )
            script_target_words = max(
                50, int(round(script_target_seconds * script_words_per_second)))
        if m.status in ("created",) or not os.path.exists(script_path):
            prog("✍️ Director: planning content...", 5)
            plan = plan_content(
                m.topic, m.content_type, m.target_seconds, m.tone, m.language,
                script_provider=settings.get("script_provider", "auto"),
                script_model=settings.get("script_model", "auto"),
                script_quality=settings.get("script_quality", "publish"),
                target_words=script_target_words,
                voiceover_enabled=presentation.voiceover,
                audio_mode='voiceover' if presentation.voiceover else ('music_only' if presentation.music_mode != 'off' else 'silent'),
            )
            from .planning.script_engine import script_quality_report
            editorial_qc = plan.get("editorial_qc") or script_quality_report(
                plan, m.topic, m.content_type, m.target_seconds, script_target_words)
            plan["editorial_qc"] = editorial_qc
            _save_json(os.path.join(D["root"], "editorial_qc.json"), editorial_qc)
            if str(settings.get("script_quality", "publish")).lower() == "publish" and not editorial_qc.get("passed"):
                raise RuntimeError(
                    "Script failed publish-quality editorial QC before media generation: "
                    + "; ".join(editorial_qc.get("flags") or [])
                )
            _save_json(script_path, plan)
            self._write_script_md(m, plan, os.path.join(D["root"], "script.md"))
            target_detail = (
                f"~{script_target_words} words (~{script_target_seconds}s narration budget)"
                if script_headroom else f"{m.target_seconds}s requested target"
            )
            if script_headroom:
                target_detail += f" (+{script_headroom}s headroom; requested video {m.target_seconds}s)"
            prog(f"✍️ Script ready: {plan.get('words', 0)} words for {target_detail} "
                 f"via {plan.get('source', 'planner')}", 7)
            m.angle, m.audience = plan["angle"], plan["audience"]
            m.status = "scripted"
            self.pm.save_manifest(m)
            self.db.upsert(job_id, status="scripted", script_status="done")
        else:
            plan = json.load(open(script_path, encoding="utf-8"))

        # Gemini Web intentionally shares one sync-Playwright browser across the
        # multi-step writing pass.  Once the script is complete, release that
        # Playwright driver before TTS or Flow starts.  Keeping it alive in the
        # same Python process can make Edge TTS see an active asyncio loop and can
        # make a second sync-Playwright instance (Flow) fail immediately.  The
        # Gemini login itself remains persisted on disk and is reused next time.
        if str(plan.get("source", "")).lower().startswith("gemini-web") or \
                str(settings.get("script_provider", "")).lower() == "gemini-web":
            try:
                from .providers.gemini_web import close_shared_session
                close_shared_session()
                prog("🌐 Gemini writing session released; continuing with a clean TTS/Flow browser context.", 8)
            except Exception:
                pass

        # ---- 2. narration ----
        voice_path = os.path.join(D["narration"], "voice.mp3")
        words_path = voice_path + ".words.json"
        if not presentation.voiceover:
            # Do not synthesize a voice then mute it. No TTS, transcription,
            # retiming, dummy MP3 or fabricated caption timestamps are needed.
            words = []
            narration_dur = visual_duration(m)
            if not m.shots:
                m.timing_source = "visual_storyboard"
                m.status = "narrated"  # Existing stage order; voice itself is skipped.
                self.pm.save_manifest(m)
            prog("🎵 Voiceover disabled — visual story clock", 14, f"{narration_dur:.1f}s; TTS and speech captions skipped")
            self.pm.log(job_id, "voiceover_skipped", {"duration": narration_dur, "timing_source": "visual_storyboard"})
        elif m.status in ("created", "scripted") or not os.path.exists(voice_path):
            prog("🎙️ Narrating...", 12)

            def _synth(current_plan):
                prepared_path = Path(D['root'])/'production/prepared_speech.json'
                if prepared_path.is_file():
                    from .production import digest
                    from .speech_cards import validate_words
                    prepared = json.loads(prepared_path.read_text())
                    if prepared['script'].strip() != current_plan['narration'].strip() or prepared['language'] != m.language:
                        raise ValueError('Prepared narration no longer matches the approved script/language; prepare the batch again')
                    if digest(prepared['audio']) != prepared['audio_sha256']:
                        raise ValueError('Prepared narration changed; no new TTS was submitted')
                    import shutil
                    shutil.copy2(prepared['audio'], voice_path)
                    timed = json.loads(Path(prepared['words']).read_text())
                    validate_words(timed, prepared['duration'])
                    return {'audio':voice_path,'words':timed,'duration':prepared['duration'],
                            'engine':'reviewed-prepared-narration','timing_source':prepared['timing_source']}
                turns_path = os.path.join(D['root'], 'speaker_turns.json')
                if os.path.isfile(turns_path):
                    from .cast import synthesize_turns
                    from .audio.tts import provider_for_language
                    return synthesize_turns(json.load(open(turns_path,encoding='utf-8'))['turns'], voice_path, m.language,
                                            provider_for_language(settings.get('tts_provider','auto'), m.language))
                if settings.get('narration_input_path'):
                    from .audio.tts import _audio_to_mp3, _mp3_len
                    local_audio = os.path.abspath(os.path.expanduser(settings['narration_input_path']))
                    if not os.path.isfile(local_audio):
                        raise ValueError('Imported narration file not found')
                    _audio_to_mp3(local_audio, voice_path)
                    return {'audio':voice_path,'words':[],'duration':_mp3_len(voice_path),'engine':'imported-native-narration'}
                return synthesize_narration(
                    current_plan["narration"], m.voice, voice_path,
                    provider=settings.get("tts_provider", "auto"),
                    language=m.language,
                    style=settings.get("tts_style", ""),
                    model=settings.get("tts_model", ""),
                    provider_voice=settings.get("tts_voice", ""),
                )

            tts = None
            # A caption/transcription failure can happen after a perfectly good
            # narration file was already written. On resume, do not spend another
            # TTS request (or change the voice) just because manifest status never
            # advanced past ``scripted``. Reuse the audio checkpoint and retry the
            # caption-timing stage only.
            if m.status == "scripted" and os.path.exists(voice_path) and not os.path.isfile(os.path.join(D["root"], "production", "prepared_speech.json")):
                try:
                    from .audio.tts import _mp3_len
                    checkpoint_dur = float(_mp3_len(voice_path) or 0)
                    if os.path.getsize(voice_path) >= 1024 and checkpoint_dur > 0:
                        tts = {"audio": voice_path, "words": [],
                               "duration": checkpoint_dur, "engine": "existing-narration-checkpoint"}
                        prog(f"♻️ Reusing existing narration checkpoint: {checkpoint_dur:.1f}s", 12)
                except Exception:
                    tts = None

            if tts is None:
                try:
                    tts = _synth(plan)
                except Exception as e:
                    if dry:
                        prog(f"TTS offline ({str(e)[:60]}), using mock narration for dry run...", 12)
                        tts = synthesize_narration(plan["narration"], m.voice, voice_path,
                                                   provider="mock", language=m.language)
                    else:
                        raise RuntimeError(f"Narration failed: {e}")

            prog(f"🎙️ Voice ready via {tts.get('engine', settings.get('tts_provider', 'auto'))}: "
                 f"{float(tts.get('duration') or 0):.1f}s", 12)

            # v5.5.3: measured speech duration is the source of truth.
            # Retiming is now bidirectional: short narration is expanded and
            # overlong narration is shortened before media generation.
            if not dry and tts.get("engine") != "reviewed-prepared-narration" and bool(settings.get("auto_retime_script", True)):
                from .planning.script_engine import retime_script_plan
                grace_seconds = narration_grace_seconds(m.target_seconds)
                if grace_seconds:
                    duration_window = (
                        f"{m.target_seconds - grace_seconds:.0f}–"
                        f"{m.target_seconds + grace_seconds:.0f}s"
                    )
                else:
                    duration_window = (
                        f"{m.target_seconds * 0.92:.0f}–{m.target_seconds * 1.11:.0f}s"
                    )
                for _retime_round in range(2):
                    measured = float(tts.get("duration") or 0)
                    if measured <= 0 or narration_duration_matches_target(measured, m.target_seconds):
                        break

                    current_words = int(plan.get("words") or len(plan["narration"].split()))
                    target_words = max(45, int(round(
                        current_words * (float(script_target_seconds) / measured) * 0.99
                    )))
                    if measured > m.target_seconds:
                        prog(
                            f"✂️ Narration measured {measured:.1f}s; rewriting script to ~{target_words} words "
                            f"for the {duration_window} voiceover window...", 12
                        )
                    else:
                        prog(
                            f"➕ Narration measured only {measured:.1f}s; expanding script to ~{target_words} words "
                            f"(buffered goal {script_target_seconds}s; requested {m.target_seconds}s)...", 12
                        )

                    retimed = retime_script_plan(
                        plan, m.topic, m.content_type, m.target_seconds, m.tone, m.language,
                        target_words=target_words,
                        provider=settings.get("script_provider", "auto"),
                        model=settings.get("script_model", "auto"),
                    )
                    try:
                        from .providers.gemini_web import close_shared_session
                        close_shared_session()
                    except Exception:
                        pass
                    if not retimed or retimed.get("narration") == plan.get("narration"):
                        break

                    from .planning.script_engine import script_quality_report
                    retime_qc = retimed.get("editorial_qc") or script_quality_report(
                        retimed, m.topic, m.content_type, m.target_seconds, target_words)
                    retimed["editorial_qc"] = retime_qc
                    if str(settings.get("script_quality", "publish")).lower() == "publish" and not retime_qc.get("passed"):
                        raise RuntimeError(
                            "Retimed script failed publish-quality editorial QC before media generation: "
                            + "; ".join(retime_qc.get("flags") or [])
                        )
                    plan = retimed
                    _save_json(os.path.join(D["root"], "editorial_qc.json"), retime_qc)
                    _save_json(script_path, plan)
                    self._write_script_md(m, plan, os.path.join(D["root"], "script.md"))
                    try:
                        os.remove(voice_path)
                    except Exception:
                        pass
                    for suffix in (".words.json", ".words.meta.json"):
                        try:
                            os.remove(voice_path + suffix)
                        except Exception:
                            pass
                    tts = _synth(plan)
                    prog(
                        f"✍️ Retimed script: {plan.get('words', 0)} words; narration "
                        f"{float(tts.get('duration') or 0):.1f}s", 13
                    )

            # Use native TTS boundaries when present, otherwise Groq/local Whisper
            # only for timing. In both cases align visible caption wording back to
            # the exact authored script.
            from .captions import get_word_timestamps_resilient, align_words_to_script
            words = list(tts.get("words") or [])
            if words:
                _save_json(voice_path + ".words.meta.json", {"timing_source": tts.get("timing_source", "native-tts"), "engine": tts.get("engine", "")})
            if words and tts.get("engine") != "reviewed-prepared-narration" and bool(settings.get("caption_align_script", True)):
                words = align_words_to_script(plan["narration"], words, float(tts.get("duration") or 0))
            if not words:
                words = get_word_timestamps_resilient(
                    voice_path,
                    model_size=str(settings.get("caption_local_model", "small") or "small"),
                    provider=str(settings.get("caption_provider", "auto") or "auto"),
                    script_text=plan["narration"], language=m.language,
                    groq_model=str(settings.get("caption_model", "whisper-large-v3-turbo") or "whisper-large-v3-turbo"),
                    align_script=bool(settings.get("caption_align_script", True)),
                    force=True, audio_duration=float(tts.get("duration") or 0),
                ) or []

            if tts.get("engine") not in ("mock-silent", "reviewed-multi-speaker", "reviewed-prepared-narration") and not os.path.isfile(os.path.join(D["root"], "speaker_turns.json")):
                words_f, dur_f = fit_narration_to_target(
                    voice_path, words, m.target_seconds,
                    max_rate=float(settings.get("max_tts_speedup", 1.08) or 1.08),
                    hard_trim=False,
                )
                if dur_f and abs(dur_f - float(tts.get("duration") or 0)) > 0.3:
                    prog(f"⏱️ Gentle pacing correction {tts.get('duration', 0):.1f}s → {dur_f:.1f}s "
                         f"(target {m.target_seconds}s; max speedup {float(settings.get('max_tts_speedup', 1.08)):.2f}x)", 13)
                tts["words"], tts["duration"] = words_f, dur_f
                words = words_f
            narration_dur = float(tts.get("duration") or 0)
            if narration_dur <= 0 or not words:
                raise RuntimeError("Narration produced no usable audio/timings - aborting before spending anything.")
            # Persist authoritative caption timings after any final atempo change.
            _save_json(words_path, words)
            if narration_dur > m.target_seconds * 1.12:
                prog(f"⚠️ Narration is {narration_dur:.1f}s vs {m.target_seconds}s target; v5 keeps natural speech rather than hard-trimming audio.", 14)
            if ((settings.get('narration_runtime_policy') == 'measured' or
                 os.path.isfile(os.path.join(D['root'], 'approved_content_plan.json'))) and not m.shots
                    and narration_dur > 0 and not dry):
                previous_target = m.target_seconds
                m.target_seconds = max(10, int(round(narration_dur)))
                self.pm.save_manifest(m)
                self.pm.log(job_id, 'runtime_fitted_to_narration', {'previous_target': previous_target, 'measured_seconds': narration_dur})
                prog(f'Runtime uses measured approved narration: {narration_dur:.1f}s; wording preserved', 14)
            if m.target_seconds >= 120 and narration_dur < m.target_seconds * 0.75:
                raise RuntimeError(
                    f"Narration is only {narration_dur:.1f}s for a {m.target_seconds}s target. "
                    "Aborting before image/video generation."
                )
            if m.target_seconds >= 120 and narration_dur < m.target_seconds * 0.90:
                prog(f"⚠️ Narration is {narration_dur:.1f}s vs {m.target_seconds}s target; continuing but final runtime will be shorter.", 14)
            m.status = "narrated"
            self.pm.save_manifest(m)
            self.pm.log(job_id, "narrated", {"engine": tts["engine"], "duration": round(narration_dur, 1),
                                             "words": len(words), "script_source": plan.get("source")})
        else:
            words = json.load(open(words_path, encoding="utf-8")) if os.path.exists(words_path) else []
            from moviepy.editor import AudioFileClip
            c = AudioFileClip(voice_path)
            narration_dur = c.duration
            c.close()

        if presentation.voiceover and not dry:
            from .speech_cards import prepare_selected_editions
            from .render.educational_cards import is_educational
            # 7.0.95: preparing the extra language narrations can no longer kill the
            # production. If TTS or localization fails, the English master is still
            # rendered and the reason is saved for the Language editions panel.
            try:
                prepare_selected_editions(D['root'], plan.get('narration', ''), m.language, settings, prog,
                                          text_cards=presentation.text_cards, hooks=bool(settings.get('hooks_enabled')),
                                          educational=is_educational(m.content_type, getattr(m, 'preset', '')),
                                          topic=m.topic, card_provider=settings.get('card_draft_provider') or 'gemini-web')
            except Exception as edition_prep_error:
                from .language_editions import record_narration_error
                message = ('The extra language narrations could not be prepared: '
                           + ' '.join(str(edition_prep_error).split())[:600])
                try:
                    record_narration_error(D['root'], message)
                except Exception:
                    pass
                self.pm.log(job_id, 'language_narration_error', {'error': str(edition_prep_error)[:600]})
                prog('Language editions need narration: ' + message, 15,
                     'The primary master still renders; the Language editions panel names each language.')

        # 7.0.86: master cards are drafted only when text cards are on; with them off no Gemini card request is sent.
        if settings.get('speech_cards_enabled') and presentation.voiceover and presentation.text_cards and not dry:
            from .speech_cards import prepare
            prog('Drafting Gemini cards from saved narration words', 16)
            timing = 'unverified'
            metadata_path = voice_path + '.words.meta.json'
            if os.path.isfile(metadata_path):
                metadata = json.load(open(metadata_path, encoding='utf-8'))
                timing = metadata.get('timing_source', metadata.get('engine', 'unverified'))
            from .render.educational_cards import is_educational
            prepare(D['root'], voice_path, words, plan.get('narration', ''), narration_dur,
                    m.language, cleanup=settings.get('gemini_chat_cleanup', 'keep'), timing_source=timing,
                    educational=is_educational(m.content_type, getattr(m, "preset", "")),
                    topic=m.topic, provider=settings.get("card_draft_provider") or "gemini-web")

        if settings.get('hooks_enabled') and presentation.voiceover and not dry and words:
            # 7.0.76: Gemini Web hooks after narration words and text cards exist. A failed draft
            # is logged and the job continues without hooks.
            from .video_hooks import draft_hooks
            prog('Drafting Gemini Web hooks from saved narration words', 17)
            try:
                draft_hooks(D['root'], voice_path, words, plan.get('narration', ''), narration_dur,
                            m.language, topic=m.topic, cleanup=settings.get('gemini_chat_cleanup', 'keep'))
            except Exception as hook_error:
                self.pm.log(job_id, 'hooks_skipped', {'error': str(hook_error)[:300]})

        # ---- 3. bible + director ----
        if m.status in ("created", "scripted", "narrated") or not m.shots:
            prog("📖 Building story bible + shot plan...", 18)
            bible = build_bible(m.topic, m.content_type, preset, m.audience, m.tone, beats=plan.get("beats"))
            character_file = os.path.join(D['root'], 'character_snapshot.json')
            if os.path.isfile(character_file):
                character = json.load(open(character_file,encoding='utf-8'))
                from .cast import prompt_identity
                bible['characters'] = [{'id':f'CHARACTER_{i+1:02d}','canonical':prompt_identity(c),'name':c['name']} for i,c in enumerate(cast or [character])]
                from .planning.story_bible import _identity_block
                bible['identity_block'] = _identity_block(bible['characters'], bible.get('locations',[]), bible.get('objects',[]))
                for i, reference in enumerate(character.get('references', [])):
                    if self._file_sha256(reference['path']) != reference['sha256']:
                        raise ValueError('Character reference changed; no new generation submitted')
                    copied = os.path.join(D['references'], f'character-approved-{i}.png')
                    if copied not in refs.get('character'):
                        refs.add('character', reference['path'], f'character-approved-{i}.png')
            _save_json(os.path.join(D["root"], "story_bible.json"), bible)
            m = create_production_plan(m, plan["narration"], words, plan["beats"],
                                       bible, preset, router, narration_dur,
                                       timing_source="narration" if presentation.voiceover else "visual_storyboard")
            self.pm.save_manifest(m)
            if cast:
                timing_path = os.path.join(D['root'], 'speaker_timing.json')
                turns = json.load(open(timing_path,encoding='utf-8')).get('turns',[]) if os.path.isfile(timing_path) else []
                assign_cast(m.shots, cast, turns)
                self.pm.save_manifest(m)
            self.db.upsert(job_id, status="planned")
            self.pm.log(job_id, "planned", {"shots": len(m.shots)})

        bible = json.load(open(os.path.join(D["root"], "story_bible.json"), encoding="utf-8"))

        # ---- 3a. MovieFlow full-story cartoon mode ----
        movieflow_full = self._movieflow_full_story_enabled(m, settings)
        if movieflow_full:
            if not (len(m.shots) == 1 and getattr(m.shots[0], "provider", "") == "movieflow"):
                m = self._prepare_movieflow_full_story(m, plan, bible, preset, narration_dur)
                self.pm.save_manifest(m)
                self.pm.log(job_id, "movieflow_full_story_planned",
                            {"project_url": settings.get("movieflow_project_url", ""),
                             "runtime": round(float(narration_dur), 1)})
            prog("🎨 MovieFlow cartoon: full-story Agent generation selected; Google Flow scene generation is bypassed.", 20)

        # ---- 3b. storyboard-economy media routing (zero spend) ----
        if m.profile == "STORYBOARD_ECONOMY" and not movieflow_full:
            econ_path = os.path.join(D["root"], "economy_plan.json")
            if not os.path.exists(econ_path):
                from .planning.economy_storyboard import EconomyOptions, assign_storyboard_economy
                # Only reserve stock slots when a real stock source is available.
                # v4.0 could report "2 stock" even when no local library/API existed,
                # then silently route those scenes to image-motion at runtime.
                try:
                    from .providers.stock_provider import StockProvider
                    stock_available = StockProvider().status().available
                except Exception:
                    stock_available = False
                # Long-form default mix: 60% meaningful stock video, 20% Flow
                # hero/action video and 20% locally animated stills. Explicit
                # CLI/YAML scene counts always win and the credit budget may cap
                # Flow below its requested share.
                if str(settings.get("production_mode", "legacy")).lower() == "youtube_pro":
                    target_dynamic = settings.get("dynamic_video_scenes")
                    if target_dynamic is None:
                        target_dynamic = max(1, int(round(len(m.shots) * 0.80)))
                    if settings.get("flow_scenes") is None:
                        settings["flow_scenes"] = max(1, int(round(len(m.shots) * 0.20)))
                    if settings.get("stock_scenes") is None:
                        settings["stock_scenes"] = max(0, min(
                            len(m.shots) - int(settings.get("flow_scenes") or 0),
                            int(round(len(m.shots) * 0.60))))
                    settings["dynamic_video_scenes"] = int(target_dynamic)
                os.environ["AUTOVIDEO_STOCK_SOURCE"] = str(settings.get("stock_source", "auto") or "auto")

                opts = EconomyOptions(
                    max_credits=float(settings.get("budgets", {}).get("MAX_CREDITS_PER_VIDEO", 50)),
                    video_share=float(settings.get("video_share", 0.20) or 0),
                    stock_share=float(settings.get("stock_share", 0.60) or 0),
                    flow_scenes=settings.get("flow_scenes"),
                    max_flow_scenes=settings.get("max_flow_scenes"),
                    stock_scenes=settings.get("stock_scenes"),
                    dynamic_video_scenes=settings.get("dynamic_video_scenes"),
                    prefer_stock=bool(stock_available),
                    reserve_pct=float(router.budgets.get("RETRY_RESERVE_PCT", 15) or 0),
                )
                report = assign_storyboard_economy(m, router, opts)
                for shot in m.shots:
                    if shot.character_ids and shot.provider == 'stock':
                        shot.provider='image'; shot.model='kenburns_plus'; shot.media_strategy='image_motion'
                        shot.strategy_reason='Saved cast requires referenced visuals rather than unrelated stock people'
                report['stock_scenes']=sum(s.provider=='stock' for s in m.shots)
                report['image_scenes']=sum(s.provider=='image' for s in m.shots)
                prog(f"Render B-roll: up to {settings.get('broll_count',0)} contextual cutaways requested (separate from base stock scenes)",21)
                self.pm.save_manifest(m)
                _save_json(econ_path, report)
                self._write_economy_plan_md(m, report, os.path.join(D["root"], "economy_plan.md"))
                self.pm.log(job_id, "economy_routed", {k: report[k] for k in
                            ("flow_scenes", "stock_scenes", "image_scenes", "projected_total")})
            else:
                # Manifest already contains the persisted routing from the first run.
                try:
                    report = json.load(open(econ_path, encoding="utf-8"))
                except Exception:
                    report = {}
            # Cartoon scenes mode reuses the economy planner only to select how
            # many motion-critical shots deserve AI video, then hands those shots
            # to MovieFlow instead of Google Flow. Opening/closing stills can still
            # come from the normal frame pipeline.
            if (str(settings.get("cartoon_provider", "flow")).lower() == "movieflow"
                    and str(settings.get("movieflow_mode", "full_story")).lower() == "scenes"):
                changed = 0
                for _s in m.shots:
                    if getattr(_s, "provider", "") == "flow":
                        _s.provider = "movieflow"
                        _s.model = "movieflow_scene"
                        _s.media_strategy = "movieflow_video"
                        changed += 1
                if changed:
                    self.pm.save_manifest(m)
                    self.pm.log(job_id, "movieflow_scene_routing", {"shots": changed})
                    report["movieflow_scenes"] = changed
                    report["flow_scenes"] = 0
                    _save_json(econ_path, report)
            flow_note = ""
            if report.get("requested_flow_scenes") is not None:
                flow_note = f" (requested {report.get('requested_flow_scenes')})"
            elif settings.get("max_flow_scenes") is not None:
                flow_note = f" (max cap {settings.get('max_flow_scenes')})"
            if report.get("budget_limited"):
                flow_note += " [budget-limited]"
            _mf_scenes = int(report.get("movieflow_scenes", 0) or 0)
            _motion_count = _mf_scenes if _mf_scenes else int(report.get("flow_scenes", 0) or 0)
            _motion_name = "MovieFlow video" if _mf_scenes else "AI video"
            prog(f"🧠 Economy storyboard: {_motion_count} {_motion_name}{flow_note} / "
                 f"{report.get('stock_scenes',0)} stock / {report.get('image_scenes',0)} image-motion; "
                 f"~{report.get('projected_total',0)} credits", 21)

        # ---- 4. storyboard frames + compiled prompts ----
        prog("🖼️ Storyboard frames...", 24)
        from .providers.image_provider import ImageProvider
        img_prov = ImageProvider()
        vertical = m.aspect == "9:16"
        strict_flow_storyboard = bool(
            m.profile in FLOW_PROFILES
            and (m.profile == "STORYBOARD_ECONOMY" or int(settings.get("images_per_shot", 2) or 0) > 0)
            and str(settings.get("frame_source", "auto") or "auto").lower() == "flow"
            and not movieflow_full
        )
        if strict_flow_storyboard:
            # These preview JPEGs used Pollinations before the real Flow-frame pass.
            # On long-form jobs that meant dozens of 90-second HTTP waits before
            # the first visible per-shot progress line.  They are redundant when
            # strict Flow is already responsible for the actual opening/closing
            # frames, so compile prompts now without generating network previews.
            prog("⏭️ Strict Flow frame mode: skipping Pollinations storyboard previews; Flow frames will be generated next.", 24)
        for s in m.shots:
            if movieflow_full:
                # MovieFlow full-story mode needs only the story/character bible;
                # do not spend time creating Google Flow/local storyboard frames.
                continue
            frame = os.path.join(D["storyboard"], f"{s.shot_id}.jpg")
            if not os.path.exists(frame) and not dry and not strict_flow_storyboard:
                try:
                    img_prov.storyboard_frame(
                        f"{s.subject}, {s.environment}, {s.camera_framing}, {preset.get('color_treatment','')}, no text",
                        frame, vertical)
                    refs.add("storyboard", frame, f"{s.shot_id}.jpg")
                except Exception as e:
                    self.pm.log(job_id, "storyboard_failed", {"shot": s.shot_id, "error": str(e)[:150]})
            # resolve continuity placeholder
            if s.start_frame and s.start_frame.startswith("{prev_end_frame:"):
                prev = s.start_frame[16:-1]
                cand = os.path.join(D["references"], f"{prev}_end.jpg")
                s.start_frame = cand if os.path.exists(cand) else None
            if not s.compiled_prompt:
                c = compile_shot(s, bible, preset, vertical)
                s.compiled_prompt = c["prompt"]
                approved_scenes = plan.get('beats', [])
                if plan.get('source') == 'approved-import' and approved_scenes:
                    scene = approved_scenes[min(len(approved_scenes)-1,int(m.shots.index(s)*len(approved_scenes)/len(m.shots)))]
                    if scene.get('motion_prompt'):
                        s.compiled_prompt += ' Authored motion direction: ' + str(scene['motion_prompt'])
        self.pm.save_manifest(m)

        external_ids = settings.get('external_video_shots') or []
        if settings.get('external_video_mode') and not external_ids:
            external_ids = [s.shot_id for s in m.shots if s.provider in ('flow','movieflow')]
        if external_ids and any(s.shot_id in external_ids and not s.accepted_take for s in m.shots):
            from .external_video import export_plan
            export_plan(self, job_id, external_ids)
            m.status = 'paused'
            self.pm.save_manifest(m)
            self.db.upsert(job_id, status='paused')
            prog('Waiting for external video clips', 24, 'Shot prompts and incoming paths saved in external_video/plan.json; no video generation submitted')
            return {'job_id':job_id,'status':'paused','message':'Import reviewed external clips, then Resume', 'plan':os.path.join(D['root'],'external_video','plan.json')}

        # ---- 5. budget gate (Flow profiles) ----
        K = int(settings.get("images_per_shot", 2) or 0)
        est = router.estimate_job(m.shots)
        img_unit = float(router.reg["models"].get("imagen_flow", {}).get("credits_per_image", 0))
        est["image_credits"] = round(img_unit * K * len(m.shots), 1)
        est["projected_total"] = round(est["projected_total"] + est["image_credits"], 1)
        est["within_budget"] = est["projected_total"] <= float(est["max_per_video"])
        _save_json(os.path.join(D["root"], "budget.json"), est)
        self.db.upsert(job_id, est_credits=int(est["projected_total"]))
        if m.profile in ("FLOW_CINEMATIC", "FLOW_BALANCED", "FLOW_ECONOMY", "STORYBOARD_ECONOMY", "MANUAL_DIRECTOR") and not dry:
            if not est["within_budget"]:
                m.status = "paused"
                self.pm.save_manifest(m)
                self.db.upsert(job_id, status="paused")
                raise NeedsDecision(
                    f"Projected {est['projected_total']} Flow credits exceeds budget "
                    f"{est['max_per_video']}. Job paused before spending anything.",
                    alternatives=["Raise MAX_CREDITS_PER_VIDEO in SETTINGS and resume",
                                  "Switch profile to FLOW_ECONOMY", "Run as DRY RUN first"])
        prog(f"💳 Budget: ~{est['projected_total']} credits" + (" (DRY RUN - spending nothing)" if dry else ""), 28)

        # ---- 5b. scene images (Flow image gen; free fallback) ----
        # Multiple stills per scene -> best becomes the video reference (reference-first).
        # Runs only after the budget gate passes (never spends before approval).
        needs_approval = (m.profile == "MANUAL_DIRECTOR"
                          and any(s.status == "planned" for s in m.shots))
        if not dry and m.profile == "STORYBOARD_ECONOMY" and not needs_approval and not movieflow_full:
            try:
                self._generate_economy_frames(m, D, refs, vertical, settings, bible, prog)
            except FlowFrameBatchPending as e:
                current = self.pm.load_manifest(job_id)
                current.status = "paused"
                self.pm.save_manifest(current)
                self.db.upsert(job_id, status="paused")
                first = e.report["unresolved"][0]
                self._write_pause_state(job_id, first["shot_id"], str(e),
                                        kind="flow_frame_batch", project_url=self._flow_project_url(job_id, settings))
                self.pm.log(job_id, "flow_frame_batch_waiting", e.report)
                prog(str(e), 29, "See flow_frame_recovery_batch.json. Resume retains exact requests and cached frames.")
                return {"job_id": job_id, "status": "paused", "message": str(e),
                        "frame_recovery": e.report, "resume": f"python3 cli.py v3 resume {job_id}"}
            except RuntimeError as e:
                # Pausing is explicitly opt-in. In strict Flow mode, retain all
                # cached frames and either pause by request or fail cleanly; never
                # report a failed image request as PAUSED by default.
                msg = str(e)
                if "Strict --frame-source flow" in msg:
                    pause_requested = bool(settings.get("flow_pause_on_unresolved_request", False))
                    from .auto_resume import strict_failure_action
                    if strict_failure_action(settings, e.__cause__, pause_requested) == "retry":
                        # Recoverable browser/network interruptions go back through
                        # run_with_recovery: bounded backoff, then automatic resume.
                        raise RecoverableInterruption(job_id, getattr(e, "shot_id", ""), e.__cause__,
                                                      self._flow_project_url(job_id, settings))
                    m2 = self.pm.load_manifest(job_id)
                    m2.status = "paused" if pause_requested else "failed"
                    self.pm.save_manifest(m2)
                    self.db.upsert(job_id, status=m2.status)
                    event = "flow_frames_paused" if pause_requested else "flow_frames_failed_without_pause"
                    self.pm.log(job_id, event, {"error": msg[:1200]})
                    if pause_requested:
                        prog("⏸️ Flow frame generation paused by your setting; completed frames are cached.", 26)
                    else:
                        prog("❌ Strict Flow frame generation failed; automatic pause is disabled. Completed frames are cached.", 26)
                    return {
                        "job_id": job_id, "status": m2.status,
                        "message": msg,
                        "resume": f"python3 cli.py v3 resume {job_id}",
                    }
                m2 = self.pm.load_manifest(job_id)
                m2.status = "failed"
                self.pm.save_manifest(m2)
                self.db.upsert(job_id, status="failed")
                self.pm.log(job_id, "flow_frames_failed", {"error": msg[:1200]})
                return {"job_id": job_id, "status": "failed", "message": msg}
            m = self.pm.load_manifest(job_id)
        elif K > 0 and not dry and m.profile in FLOW_PROFILES and not needs_approval and not movieflow_full:
            self._generate_scene_images(m, D, refs, vertical, K, prog, settings=settings)
            m = self.pm.load_manifest(job_id)

        # ---- 6. generation loop ----
        if m.profile == "MANUAL_DIRECTOR" and any(s.status == "planned" for s in m.shots):
            m.status = "review"
            self.pm.save_manifest(m)
            self.db.upsert(job_id, status="review")
            return {"job_id": job_id, "status": "review",
                    "message": "MANUAL_DIRECTOR: approve shots in STORYBOARD, then resume."}

        try:
            self._generate_all(m, D, refs, router, vertical, dry, prog, settings)
        except FlowRequestFailed as e:
            detail = " ".join(str(e).split())[:1200]
            prog(f"❌ Flow request recovery failed; no replacement generation was submitted. {detail}", 82)
            return {"job_id": job_id, "status": "failed", "message": str(e),
                    "resume": f"python3 cli.py v3 resume {job_id}"}

        if dry:
            self.db.upsert(job_id, status="dry_complete")
            return {"job_id": job_id, "status": "dry_complete", "est": est,
                    "message": "DRY RUN complete - no credits spent and no media generated. Planning/audit files were written for review."}

        # ---- 7. review gate ----
        m = self.pm.load_manifest(job_id)
        if m.status == "review":
            return {"job_id": job_id, "status": "review", "message": "Awaiting director approval."}

        # ---- 8. render ----
        if auto_render:
            return self.render_job(job_id, quality=str(settings.get("render_quality", "high") or "high"), progress_cb=progress_cb)
        return {"job_id": job_id, "status": m.status}

    # ---------------- script markdown / Flow project frame cache ----------------
    @staticmethod
    def _norm_prompt_key(text: str) -> str:
        return " ".join(str(text or "").split()).strip().lower()

    @staticmethod
    def _file_sha256(path: str) -> str:
        try:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""

    @staticmethod
    def _is_valid_image_file(path: str, min_bytes: int = 128) -> bool:
        """Return True only for a decodable raster image with useful dimensions.

        A nearly-full disk or a Flow/download interruption can leave a .jpg path
        behind that is zero-byte, HTML, or a truncated JPEG.  Older releases
        treated mere path existence as success and later crashed in Pillow during
        image-motion rendering.  Validate bytes before caching/reusing a frame.
        """
        try:
            if not path or not os.path.isfile(path) or os.path.getsize(path) < min_bytes:
                return False
            from PIL import Image
            with Image.open(path) as im:
                im.verify()
            with Image.open(path) as im:
                w, h = im.size
                return w >= 64 and h >= 64
        except Exception:
            return False

    @classmethod
    def _remove_invalid_image(cls, path: str) -> bool:
        """Delete a corrupt/incomplete image file if present; return True if removed."""
        try:
            if path and os.path.exists(path) and not cls._is_valid_image_file(path):
                os.remove(path)
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def _check_storage(path: str, prog=None) -> None:
        """Fail early before media generation when the target drive is critically full.

        AutoVideoAI writes intermediate JPEG/MP4 files next to the job. A nearly
        full drive can leave truncated files that look cached but are undecodable.
        The thresholds are configurable for small systems.
        """
        try:
            free = shutil.disk_usage(os.path.abspath(path)).free
            free_gb = free / (1024 ** 3)
            minimum = float(os.environ.get("AUTOVIDEO_MIN_FREE_GB", "1.5"))
            warning = float(os.environ.get("AUTOVIDEO_WARN_FREE_GB", "5.0"))
            if free_gb < minimum:
                raise RuntimeError(
                    f"Insufficient free disk space on the output drive: {free_gb:.2f} GB available; "
                    f"at least {minimum:.1f} GB is required. Free space, then resume the same job.")
            if free_gb < warning and prog:
                prog(f"⚠️ Low disk space: {free_gb:.1f} GB free on output drive; media writes are protected but cleanup is recommended.", 4)
        except RuntimeError:
            raise
        except Exception:
            # Disk probing should never block production on exotic filesystems.
            return

    @staticmethod
    def _image_dhash(path: str) -> int | None:
        """Small perceptual hash used only to detect near-duplicate storyboard frames."""
        try:
            from PIL import Image
            with Image.open(path) as im:
                im = im.convert("L").resize((9, 8))
                px = list(im.get_flattened_data()) if hasattr(im, "get_flattened_data") else list(im.getdata())
            value = 0
            bit = 0
            for y in range(8):
                row = px[y * 9:(y + 1) * 9]
                for x in range(8):
                    if row[x] > row[x + 1]:
                        value |= (1 << bit)
                    bit += 1
            return value
        except Exception:
            return None

    @classmethod
    def _image_distance(cls, a: str, b: str) -> int | None:
        ha, hb = cls._image_dhash(a), cls._image_dhash(b)
        if ha is None or hb is None:
            return None
        return (ha ^ hb).bit_count()

    def _flow_frame_cache_key(self, project_url: str, prompt: str, vertical: bool, label: str) -> str:
        payload = "|".join([project_url.strip(), "9:16" if vertical else "16:9",
                            str(label or "frame").strip().lower(), self._norm_prompt_key(prompt)])
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _flow_frame_cache_dir(self, project_url: str) -> str:
        """Project cache shared across AutoVideoAI versions/install folders.

        v4.8 and older stored the cache under each source tree's ``data/`` folder,
        so extracting a new release made an existing Flow project look empty and
        caused the same images to be generated again.  v4.9 moves the canonical
        cache to the user's home directory and imports sibling legacy caches.
        """
        from .providers.flow_browser import FlowBrowser
        url = FlowBrowser.normalize_project_url(project_url)
        ident = url.rsplit("/", 1)[-1] if url else "unbound"
        base = os.environ.get("AUTOVIDEO_FLOW_CACHE_DIR") or os.path.join(
            os.path.expanduser("~"), ".local", "share", "autovideoai", "flow_project_cache")
        root = os.path.abspath(os.path.join(base, ident, "frames"))
        os.makedirs(root, exist_ok=True)
        self._import_legacy_flow_cache(ident, root)
        return root

    def _import_legacy_flow_cache(self, project_id: str, target: str) -> int:
        """Import per-release v4.x project caches into the shared v4.9 cache."""
        imported = 0
        candidates = []
        here = os.path.abspath(os.getcwd())
        candidates.append(os.path.join(here, "data", "flow_project_cache", project_id, "frames"))
        parent = os.path.dirname(here)
        try:
            for name in os.listdir(parent):
                if not name.lower().startswith("autovideoai"):
                    continue
                candidates.append(os.path.join(parent, name, "data", "flow_project_cache", project_id, "frames"))
        except Exception:
            pass
        for srcdir in candidates:
            try:
                if not os.path.isdir(srcdir) or os.path.abspath(srcdir) == os.path.abspath(target):
                    continue
                for fn in os.listdir(srcdir):
                    if not (fn.endswith(".jpg") or fn.endswith(".json")):
                        continue
                    src = os.path.join(srcdir, fn)
                    dst = os.path.join(target, fn)
                    if not os.path.exists(dst):
                        shutil.copy2(src, dst)
                        imported += 1
            except Exception:
                continue
        return imported

    def _external_project_jobs(self, project_url: str, topic: str = "", aspect: str = "",
                               reuse_mode: str = "topic") -> list[tuple[str, dict, dict]]:
        """Find prior jobs in this and sibling AutoVideoAI release folders.

        Returns ``(job_root, manifest_json, settings_json)`` newest-first.  This is
        intentionally file-based so project reuse survives extracting v4.9 into a
        brand-new source directory.
        """
        from .providers.flow_browser import FlowBrowser
        wanted = FlowBrowser.normalize_project_url(project_url)
        mode = str(reuse_mode or "topic").lower()
        if not wanted or mode == "exact":
            return []
        roots = [os.path.abspath(os.getcwd())]
        parent = os.path.dirname(os.path.abspath(os.getcwd()))
        try:
            roots += [os.path.join(parent, n) for n in os.listdir(parent)
                      if n.lower().startswith("autovideoai")]
        except Exception:
            pass
        seen = set()
        found = []
        wanted_topic = self._norm_prompt_key(topic)
        for root in roots:
            outroot = os.path.join(root, "outputs")
            if not os.path.isdir(outroot):
                continue
            try:
                jobids = sorted(os.listdir(outroot), reverse=True)
            except Exception:
                continue
            for jobid in jobids:
                jobroot = os.path.join(outroot, jobid)
                mp = os.path.join(jobroot, "production_manifest.json")
                sp = os.path.join(jobroot, "settings.json")
                if not os.path.isfile(mp):
                    continue
                key = os.path.realpath(jobroot)
                if key in seen:
                    continue
                seen.add(key)
                try:
                    manifest = json.load(open(mp, encoding="utf-8"))
                    settings = json.load(open(sp, encoding="utf-8")) if os.path.isfile(sp) else {}
                    purl = FlowBrowser.normalize_project_url(settings.get("flow_project_url", ""))
                    if purl != wanted:
                        continue
                    if aspect and manifest.get("aspect") != aspect:
                        continue
                    if mode == "topic" and self._norm_prompt_key(manifest.get("topic", "")) != wanted_topic:
                        continue
                    found.append((jobroot, manifest, settings))
                except Exception:
                    continue
        return found

    def _previous_project_frame(self, m, project_url: str, shot_id: str, label: str,
                                reuse_mode: str) -> str | None:
        """Reuse same-topic/same-shot media from an older release folder."""
        role = str(label or "").lower()
        for jobroot, manifest, _ in self._external_project_jobs(
                project_url, topic=m.topic, aspect=m.aspect, reuse_mode=reuse_mode):
            if manifest.get("job_id") == m.job_id:
                continue
            if role == "location master":
                cand = os.path.join(jobroot, "storyboard", "location_master.jpg")
            elif role == "character master":
                cand = os.path.join(jobroot, "storyboard", "character_master.jpg")
            elif role == "opening frame":
                cand = os.path.join(jobroot, "storyboard", f"{shot_id}_open.jpg")
            elif role == "closing frame":
                cand = os.path.join(jobroot, "storyboard", f"{shot_id}_close.jpg")
            else:
                continue
            try:
                if not self._is_valid_image_file(cand):
                    continue
                # Never resurrect an older poisoned identical closing frame.
                if role == "closing frame":
                    op = os.path.join(jobroot, "storyboard", f"{shot_id}_open.jpg")
                    if os.path.isfile(op) and self._file_sha256(op) == self._file_sha256(cand):
                        continue
                return cand
            except Exception:
                continue
        return None

    def _previous_project_video(self, m, project_url: str, shot_id: str,
                                reuse_mode: str, video_mode: str = "frames") -> str | None:
        """Return a prior *Flow* video generated with the same input mode."""
        wanted_mode = str(video_mode or "frames").lower()
        for jobroot, manifest, old_settings in self._external_project_jobs(
                project_url, topic=m.topic, aspect=m.aspect, reuse_mode=reuse_mode):
            if str(old_settings.get("flow_video_mode", "frames") or "frames").lower() != wanted_mode:
                continue
            if manifest.get("job_id") == m.job_id:
                continue
            for s in manifest.get("shots", []) or []:
                if s.get("shot_id") != shot_id or s.get("actual_provider") != "flow":
                    continue
                cand = s.get("accepted_take") or ""
                if cand and not os.path.isabs(cand):
                    cand = os.path.join(jobroot, cand)
                if not cand or not os.path.exists(cand):
                    # Historical manifests normally store an absolute accepted path;
                    # recover the conventional location if that path moved with a folder.
                    cand = os.path.join(jobroot, "flow", "shots", shot_id, "accepted.mp4")
                    if not os.path.exists(cand):
                        cand = os.path.join(jobroot, "flow", "shots", shot_id, "take_01.mp4")
                try:
                    if os.path.isfile(cand) and os.path.getsize(cand) > 4096:
                        return cand
                except Exception:
                    continue
        return None

    def _flow_frame_cache_get(self, project_url: str, prompt: str, vertical: bool, label: str) -> str | None:
        if not project_url:
            return None
        key = self._flow_frame_cache_key(project_url, prompt, vertical, label)
        path = os.path.join(self._flow_frame_cache_dir(project_url), key + ".jpg")
        try:
            if self._is_valid_image_file(path):
                return path
            if os.path.exists(path):
                # Never keep a poisoned shared cache entry.
                try: os.remove(path)
                except Exception: pass
                meta = os.path.splitext(path)[0] + ".json"
                try:
                    if os.path.exists(meta): os.remove(meta)
                except Exception:
                    pass
        except Exception:
            pass
        return None

    def _flow_frame_cache_put(self, project_url: str, prompt: str, vertical: bool,
                              label: str, src: str, source_job: str = "") -> str | None:
        if not project_url or not src or not self._is_valid_image_file(src):
            return None
        key = self._flow_frame_cache_key(project_url, prompt, vertical, label)
        root = self._flow_frame_cache_dir(project_url)
        dst = os.path.join(root, key + ".jpg")
        try:
            shutil.copy2(src, dst)
            if not self._is_valid_image_file(dst):
                try: os.remove(dst)
                except Exception: pass
                return None
            meta = os.path.join(root, key + ".json")
            _save_json(meta, {"project_url": project_url, "label": label,
                              "prompt_sha256": hashlib.sha256(self._norm_prompt_key(prompt).encode()).hexdigest(),
                              "source_job": source_job, "source_file": os.path.abspath(src)})
            return dst
        except Exception:
            return None

    def _bootstrap_flow_frame_cache(self, m, settings: dict, bible: dict, vertical: bool) -> int:
        """Index compatible frames from older local jobs bound to the same Flow project.

        This is the safe bridge for projects created before v4.6. We do not blindly
        trust generic Flow filenames. Instead we reconstruct each old frame prompt and
        only cache it under the exact prompt/aspect/project fingerprint. A new job can
        then reuse a byte-for-byte compatible image without spending another image
        generation or depending on Flow's date/time project title.
        """
        if not bool(settings.get("flow_reuse_project_media", True)):
            return 0
        project_url = self._flow_project_url(m.job_id, settings)
        if not project_url:
            return 0
        from .planning.frame_prompts import master_character_prompt, master_location_prompt, frame_prompt
        added = 0
        for old_id in self.pm.list_jobs():
            if old_id == m.job_id:
                continue
            try:
                old_settings = self._settings(old_id)
                if self._flow_project_url(old_id, old_settings) != project_url:
                    continue
                old_m = self.pm.load_manifest(old_id)
                if old_m.aspect != m.aspect:
                    continue
                old_D = self.pm.dirs(old_id)
                bible_path = os.path.join(old_D["root"], "story_bible.json")
                if not os.path.exists(bible_path):
                    continue
                old_bible = json.load(open(bible_path, encoding="utf-8"))

                # Master references.
                for label, fn, maker, enabled in (
                    ("character master", "character_master.jpg", master_character_prompt, bool(old_bible.get("characters"))),
                    ("location master", "location_master.jpg", master_location_prompt, bool(old_bible.get("locations"))),
                ):
                    src = os.path.join(old_D["storyboard"], fn)
                    if enabled and self._is_valid_image_file(src):
                        pr = maker(old_bible, vertical)
                        if not self._flow_frame_cache_get(project_url, pr, vertical, label):
                            if self._flow_frame_cache_put(project_url, pr, vertical, label, src, old_id):
                                added += 1

                for old_s in old_m.shots:
                    old_open = os.path.join(old_D["storyboard"], old_s.shot_id + "_open.jpg")
                    old_close = os.path.join(old_D["storyboard"], old_s.shot_id + "_close.jpg")
                    poisoned_pair = (os.path.exists(old_open) and os.path.exists(old_close) and
                                     self._file_sha256(old_open) and
                                     self._file_sha256(old_open) == self._file_sha256(old_close))
                    for kind, suffix, label in (("open", "_open.jpg", "opening frame"),
                                                ("close", "_close.jpg", "closing frame")):
                        # Do not bootstrap a known-bad closing frame from older jobs
                        # where opening and closing were byte-identical.
                        if poisoned_pair and kind == "close":
                            continue
                        src = os.path.join(old_D["storyboard"], old_s.shot_id + suffix)
                        if not self._is_valid_image_file(src):
                            continue
                        pr = frame_prompt(old_s, old_bible, vertical, kind)
                        if not self._flow_frame_cache_get(project_url, pr, vertical, label):
                            if self._flow_frame_cache_put(project_url, pr, vertical, label, src, old_id):
                                added += 1
            except Exception:
                continue
        return added

    @staticmethod
    def _write_script_md(m, plan: dict, path: str):
        L = [f"# {m.topic}", "",
             f"**Job:** {m.job_id} · **Type:** {m.video_type} · **Target:** {m.target_seconds}s · **Tone:** {m.tone}",
             f"**Angle:** {plan.get('angle', '')} · **Audience:** {plan.get('audience', '')}", "",
             f"## 🎣 Hook", plan.get("hook", ""), ""]
        for i, b in enumerate(plan.get("beats", []), 1):
            L += [f"### Beat {i}: {b.get('name', '')}", b.get("text", ""), ""]
        L += ["## 🎙️ Narration", plan.get("narration", ""), "",
              f"**CTA:** {plan.get('cta', '')} · **Words:** {plan.get('words', '')} · **Source:** {plan.get('source', '')}"]
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(L) + "\n")

    @staticmethod
    def _write_economy_plan_md(m, report: dict, path: str):
        rows = report.get("shots", [])
        lines = [f"# Storyboard Economy Plan - {m.topic}", "",
                 f"**Target:** {m.target_seconds}s · **Aspect:** {m.aspect} · **Budget:** {report.get('budget', 0)} credits", "",
                 f"**Plan:** {report.get('flow_scenes',0)} AI-video · {report.get('stock_scenes',0)} stock · {report.get('image_scenes',0)} image-motion", "",
                 f"**Estimated:** {report.get('estimated_credits',0)} + {report.get('retry_reserve',0)} reserve = **{report.get('projected_total',0)} credits**", "",
                 "| Shot | Time | Strategy | Model | Est. credits | Reason |", "|---|---:|---|---|---:|---|"]
        for r in rows:
            lines.append(f"| {r['shot_id']} | {r['start']:.1f}-{r['end']:.1f}s | {r['strategy']} | {r['model']} | {r['estimated_credits']} | {r['reason']} |")
        lines += ["", "## Continuity design", "",
                  "Each scene gets an opening and closing still. When continuity is appropriate, the previous scene's closing frame becomes the next scene's opening frame. Image-only scenes are animated locally with pan/zoom/crossfade, while selected motion-critical scenes use the same frame pair as first/last-frame guidance for Flow when supported."]
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

    def _generate_economy_frames_parallel(self, m, D, refs, vertical: bool,
                                          settings: dict, prog, tasks: list[dict],
                                          workers: int, source: str) -> dict[str, str]:
        """Generate independent Economy storyboard frames in isolated Flow projects.

        Opening frames that inherit a prior closing frame are deliberately not
        submitted here. Scene pairs stay linked in the serial continuity pass;
        only independent openings and distinct closing frames enter this queue.
        """
        from concurrent.futures import ThreadPoolExecutor
        from queue import Queue, Empty
        from .providers.flow_browser import (
            FlowBrowserProvider, PROFILE_DIR, FlowAuthNeeded, FlowQuotaExceeded,
            FlowRequestPending, FlowServiceBusy, FlowReferenceUnavailable, resolve_browser_cfg,
        )
        from .providers.image_provider import ImageProvider

        worker_root = os.path.join(D["root"], ".flow-workers")
        artifact_root = os.path.join(worker_root, "economy-frame-artifacts")
        os.makedirs(worker_root, exist_ok=True)
        os.makedirs(artifact_root, exist_ok=True)

        def artifact_path(task):
            label = "open" if task["label"] == "opening frame" else "close"
            token = hashlib.sha256(
                f"{m.job_id}|{task['shot'].shot_id}|{task['label']}|{task['prompt']}|{vertical}".encode()).hexdigest()[:16]
            return os.path.join(artifact_root,
                                f"{task['shot'].shot_id}_{label}_{token}.jpg")
        try:
            with open("config/flow_ui.yaml", encoding="utf-8") as handle:
                browser_cfg = resolve_browser_cfg(yaml.safe_load(handle) or {})
            worker_uses_cdp = (str(browser_cfg.get("mode", "auto")).lower() in ("auto", "cdp")
                               and bool(browser_cfg.get("cdp_url")))
        except Exception:
            worker_uses_cdp = False

        worker_profile_root = os.path.join(
            os.path.dirname(os.path.abspath(PROFILE_DIR)), ".flow-workers")
        os.makedirs(worker_profile_root, exist_ok=True)

        from .job_cleanup import profile_copy_ignore
        def profile_for(index: int) -> str:
            # Browser profiles stay outside the job folder; only project bindings
            # and request evidence are kept with the job. FlowBrowser recognizes
            # isolated workers because each profile is a direct child of this dir.
            dst = os.path.join(
                worker_profile_root, f"{m.job_id}-economy-worker-{index + 1}")
            if worker_uses_cdp:
                os.makedirs(dst, exist_ok=True)
            elif not os.path.isdir(dst) and os.path.isdir(PROFILE_DIR):
                try:
                    shutil.copytree(PROFILE_DIR, dst, ignore=profile_copy_ignore)
                except Exception:
                    os.makedirs(dst, exist_ok=True)
            else:
                os.makedirs(dst, exist_ok=True)
            return dst

        by_shot_index = {shot.shot_id: index for index, shot in enumerate(m.shots)}
        batches = [[] for _ in range(workers)]
        for task in tasks:
            index = by_shot_index.get(task["shot"].shot_id, 0) % workers
            batches[index].append(task)
        completed_results = []
        failures = []
        events = Queue()

        def run_batch(worker_index: int, batch: list[dict]):
            provider = None
            free_provider = ImageProvider()
            outcomes = []
            project = f"AutoVideo-{m.job_id}-economy-worker-{worker_index + 1}"
            binding_path = os.path.join(worker_root, f"economy-worker-{worker_index + 1}-project.json")
            project_url = ""

            def emit(row):
                outcomes.append(row)
                events.put(("result", worker_index, row, time.monotonic()))

            def phase(task, name):
                events.put(("phase", worker_index, {
                    "shot": task["shot"].shot_id if task else "",
                    "label": task["label"] if task else "",
                    "phase": name,
                }, time.monotonic()))

            def result_for(task, path="", source_name="failed", error="", exception=None):
                return (task, path, source_name, str(error)[:600], exception, project_url)

            def fallback_or_error(task, error):
                if isinstance(error, (FlowAuthNeeded, FlowRequestPending)):
                    return result_for(task, error=str(error), exception=error)
                if isinstance(error, FlowReferenceUnavailable) and getattr(task["shot"],"character_ids",[]):
                    return result_for(task,error=str(error),exception=error)
                if isinstance(error, FlowRequestPending) and settings.get(
                        "flow_pause_on_unresolved_request", False):
                    return result_for(task, error=str(error), exception=error)
                if source == "auto":
                    try:
                        fallback_compiled = {
                            "prompt": task["prompt"],
                            "negative": getattr(task["shot"], "negative", ""),
                            "project": project, "project_url": project_url,
                        }
                        worker_out = artifact_path(task)
                        path = self._free_image_fallback(
                            task["shot"], fallback_compiled, worker_out, vertical,
                            free_provider, label=task["label"])
                        if os.path.abspath(path) != os.path.abspath(task["out"]):
                            shutil.copy2(path, task["out"])
                        if not self._is_valid_image_file(task["out"]):
                            raise RuntimeError("free fallback did not produce a valid storyboard frame")
                        return result_for(task, task["out"], "free", f"Flow fallback: {error}")
                    except Exception as fallback_error:
                        return result_for(task, error=(
                            f"Flow failed: {error}; free fallback failed: {fallback_error}"),
                            exception=fallback_error)
                return result_for(task, error=str(error), exception=error)

            try:
                if os.path.isfile(binding_path):
                    try:
                        with open(binding_path, encoding="utf-8") as handle:
                            project_url = str(json.load(handle).get("project_url", "") or "")
                    except (OSError, ValueError, TypeError):
                        project_url = ""
                remaining_batch = []
                for task in batch:
                    worker_out = artifact_path(task)
                    if self._is_valid_image_file(worker_out):
                        if os.path.abspath(worker_out) != os.path.abspath(task["out"]):
                            shutil.copy2(worker_out, task["out"])
                        fallback_archive = glob.glob(worker_out + ".flow-request.fallback*.json")
                        emit(result_for(task, task["out"], "free" if fallback_archive else "flow-parallel-recovered"))
                    else:
                        remaining_batch.append(task)
                if not remaining_batch:
                    return outcomes
                phase(None, "opening saved worker project")
                provider = FlowBrowserProvider(profile_dir=profile_for(worker_index))
                browser = provider._ensure()
                browser.ensure_project(project, project_url=project_url or None)
                project_url = browser.current_project_url()
                if not project_url:
                    raise RuntimeError("Parallel Economy worker did not expose its Flow project URL")
                temporary = binding_path + ".tmp"
                with open(temporary, "w", encoding="utf-8") as handle:
                    json.dump({"project_url": project_url}, handle)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, binding_path)

                max_attempts = max(1, _setting_int(settings, "flow_frame_retries", 3))
                capacity_wait = _setting_int(settings, "flow_capacity_wait_seconds", 900)
                capacity_retries = _setting_int(settings, "flow_capacity_retries", 8)
                master_refs = [path for role in ("character", "location")
                               for path in refs.get(role)
                               if path and os.path.isfile(path)][:3]
                for task in remaining_batch:
                    phase(task, "generating or recovering exact frame")
                    shot, prompt, out_path, label = (
                        task["shot"], task["prompt"], task["out"], task["label"])
                    worker_out = artifact_path(task)
                    os.makedirs(os.path.dirname(os.path.abspath(worker_out)), exist_ok=True)
                    if self._is_valid_image_file(worker_out):
                        if os.path.abspath(worker_out) != os.path.abspath(out_path):
                            shutil.copy2(worker_out, out_path)
                        fallback_archive = glob.glob(worker_out + ".flow-request.fallback*.json")
                        recovered_source = "free" if fallback_archive else "flow-parallel-recovered"
                        emit(result_for(task, out_path, recovered_source))
                        continue
                    paired_open = task.get("paired_open_path", "")
                    from .cast import photo_paths
                    references = photo_paths(refs, shot)
                    if paired_open and self._is_valid_image_file(paired_open):
                        references.append(paired_open)
                    compiled = {
                        "prompt": prompt,
                        "negative": getattr(shot, "negative", ""),
                        "project": project,
                        "project_url": project_url,
                        "approval": "once",
                        "max_generation_credits": 0,
                        "flow_reuse_project_media": True,
                        "flow_capacity_wait_seconds": capacity_wait,
                        "flow_capacity_retries": capacity_retries,
                        "flow_image_wait_seconds": _setting_int(settings, "flow_image_wait_seconds", 60),
                        "reference_paths": references[:4],
                        "flow_replace_unresolved_images": bool(settings.get("flow_replace_unresolved_images", False)),
                        "flow_image_replacement_limit": _setting_int(settings, "flow_image_replacement_limit", 30),
                        "flow_image_replacement_root": D["root"],
                    }
                    attempt = 1
                    errors = []
                    generated = False
                    network_recoveries = 0
                    browser_recoveries = 0
                    while attempt <= max_attempts:
                        attempt_error = None
                        try:
                            from .flow_project_isolation import assert_project_binding
                            # v7.0.43 image transactions own a separate project per
                            # request. Legacy journals retain their old worker binding.
                            request_file = worker_out + '.flow-request.json'
                            saved_image_request = {}
                            if os.path.isfile(request_file):
                                with open(request_file, encoding='utf-8') as handle:
                                    saved_image_request = json.load(handle)
                            if saved_image_request and saved_image_request.get('scope') != 'isolated_image_v1':
                                browser = provider._ensure()
                                browser.ensure_project(project, project_url=project_url)
                                assert_project_binding(project_url, browser.current_project_url(),
                                                       f"economy-worker-{worker_index + 1}")
                            result = provider.generate_image(
                                shot, compiled, worker_out, vertical, dry_run=False)
                            candidate = result.get("path") or ""
                            if candidate and self._is_valid_image_file(candidate):
                                if os.path.abspath(candidate) != os.path.abspath(out_path):
                                    shutil.copy2(candidate, out_path)
                                if not self._is_valid_image_file(out_path):
                                    raise RuntimeError("Flow worker frame copy was corrupt/incomplete")
                                emit(result_for(task, out_path, "flow-parallel"))
                                generated = True
                                break
                            if candidate and os.path.exists(candidate):
                                self._remove_invalid_image(candidate)
                            attempt_error = RuntimeError(result.get("error", "Flow returned no valid still"))
                        except FlowRequestPending as error:
                            emit(fallback_or_error(task, error))
                            break
                        except FlowReferenceUnavailable as error:
                            emit(fallback_or_error(task, error))
                            break
                        except FlowServiceBusy as error:
                            emit(fallback_or_error(task, error))
                            break
                        except (FlowAuthNeeded, FlowQuotaExceeded) as error:
                            emit(fallback_or_error(task, error))
                            break
                        except Exception as error:
                            attempt_error = error
                            try:
                                transient_browser = (provider.is_browser_closed_error(error)
                                                     if hasattr(provider, "is_browser_closed_error") else False)
                                if (transient_browser and browser_recoveries < 2
                                        and provider.recover_browser(project, project_url=project_url)):
                                    browser_recoveries += 1
                                    continue
                                transient_network = (provider.is_transient_network_error(error)
                                                     if hasattr(provider, "is_transient_network_error") else False)
                                if (transient_network and network_recoveries < 3
                                        and provider.recover_network(
                                            project, timeout_s=max(15, int(settings.get(
                                                "network_wait_seconds", 300) or 300)),
                                            project_url=project_url)):
                                    network_recoveries += 1
                                    continue
                            except Exception:
                                pass
                        errors.append(f"attempt {attempt}: {type(attempt_error).__name__}: {attempt_error}")
                        if attempt < max_attempts:
                            time.sleep(min(6.0, 1.5 * attempt))
                        attempt += 1
                    if generated:
                        continue
                    if outcomes and outcomes[-1][0] is task:
                        # The handler above already recorded a pending/strict error
                        # or a successful free fallback for this exact frame.
                        if outcomes[-1][4] is not None or outcomes[-1][1]:
                            continue
                    detail = "; ".join(errors) or "Flow worker did not return an image"
                    emit(fallback_or_error(task, RuntimeError(detail[-900:])))
            except Exception as error:
                # A worker bootstrap failure is still bounded to its assigned
                # frames. Auto mode may use the configured free fallback; strict
                # Flow mode leaves these frames failed rather than changing source.
                recorded = {id(row[0]) for row in outcomes}
                for task in batch:
                    if id(task) not in recorded:
                        emit(fallback_or_error(task, error))
            finally:
                phase(None, "closing worker browser")
                if provider is not None:
                    try:
                        provider.close()
                    except Exception:
                        pass
                try:
                    from .job_cleanup import trim_worker_cache
                    report = trim_worker_cache(os.path.join(worker_profile_root, f'{m.job_id}-economy-worker-{worker_index + 1}'), apply=True)
                    _save_json(os.path.join(D['root'], 'logs', f'worker_cleanup-economy-{worker_index + 1}.json'), report)
                except Exception:
                    pass
            return outcomes

        active_batches = [(index, batch) for index, batch in enumerate(batches) if batch]
        total = len(tasks)
        prog(f"🖼️ Storyboard Economy: generating {total} independent frame(s) with "
             f"{len(active_batches)} isolated Flow worker(s); continuity-linked openings stay ordered.", 25)
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="flow-economy-frame") as pool:
            futures = [pool.submit(run_batch, index, batch) for index, batch in active_batches]
            completed = 0
            pending_futures = set(futures)
            worker_states = {}
            seen = set()
            last_heartbeat = time.monotonic()
            while pending_futures or not events.empty():
                event = None
                try:
                    event = events.get(timeout=1)
                except Empty:
                    pass
                now = time.monotonic()
                if event:
                    kind, index, data, started = event
                    if kind == "phase":
                        worker_states[index] = dict(data, started=started)
                    else:
                        task, path, source_name, error, exception, project_url = data
                        if id(task) in seen:
                            continue
                        seen.add(id(task))
                        completed += 1
                        record = {"shot": task["shot"].shot_id, "label": task["label"],
                                  "source": source_name, "path": path,
                                  "worker_project_url": project_url, "error": error}
                        self.pm.log(m.job_id, "economy_parallel_frame", record)
                        if path and self._is_valid_image_file(path):
                            completed_results.append((task, path, source_name))
                        else:
                            failures.append((task, error or "no valid frame", exception, project_url))
                        prog(f"🖼️ Storyboard frames completed {completed}/{total} · "
                             f"{task['shot'].shot_id} {task['label']} · "
                             f"ready {len(completed_results)}, failed {len(failures)}",
                             25 + 4 * completed / max(1, total))
                for future in list(pending_futures):
                    if future.done():
                        future.result()  # Surface unexpected worker failures.
                        pending_futures.remove(future)
                if event or now - last_heartbeat >= _ECONOMY_FRAME_HEARTBEAT_SECONDS:
                    states = [{"worker": index + 1, **{k: v for k, v in state.items() if k != "started"},
                               "elapsed_seconds": round(now - state["started"])}
                              for index, state in sorted(worker_states.items())]
                    snapshot = {"completed": completed, "total": total,
                                "ready": len(completed_results), "failed": len(failures),
                                "workers": states, "updated_at": time.time()}
                    snapshot_path = os.path.join(worker_root, "economy_frame_progress.json")
                    with open(snapshot_path + ".tmp", "w", encoding="utf-8") as handle:
                        json.dump(snapshot, handle, indent=2)
                    os.replace(snapshot_path + ".tmp", snapshot_path)
                    if now - last_heartbeat >= _ECONOMY_FRAME_HEARTBEAT_SECONDS and pending_futures:
                        detail = "; ".join(
                            f"worker {state['worker']}: {state['shot']} {state['label']} "
                            f"({state['phase']}, {state['elapsed_seconds']}s)" for state in states)
                        prog(f"🖼️ Storyboard waiting · completed {completed}/{total}",
                             25 + 4 * completed / max(1, total), detail)
                        last_heartbeat = now

        cast_failure=next((failure for failure in failures if isinstance(failure[2],FlowReferenceUnavailable) and getattr(failure[0]['shot'],'character_ids',[])),None)
        if cast_failure:
            task,error_text,exception,project_url=cast_failure
            self._pause_pending_flow(m,task['shot'].shot_id,exception,project_url=project_url)
        pending = next((failure for failure in failures
                        if isinstance(failure[2], FlowRequestPending)), None)
        if pending:
            task, error_text, exception, project_url = pending
            if settings.get("flow_pause_on_unresolved_request", False):
                self._pause_pending_flow(m, task["shot"].shot_id, exception,
                                         project_url=project_url)
            self._fail_pending_flow(m, task["shot"].shot_id, exception,
                                    project_url=project_url)
            raise RuntimeError(
                f"Flow request for {task['shot'].shot_id} {task['label']} remains unresolved. "
                "No replacement generation was submitted; the exact request remains available for Resume. "
                + str(error_text)[-700:]) from exception
        if failures:
            task, error_text, exception, _project_url = failures[0]
            strict_prefix = "Strict --frame-source flow: " if source == "flow" else ""
            message = (f"{strict_prefix}Storyboard Economy parallel frame failed for "
                       f"{task['shot'].shot_id} {task['label']}: {error_text}")
            if exception:
                raise RuntimeError(message) from exception
            raise RuntimeError(message)
        return {os.path.abspath(path): source_name
                for task, path, source_name in completed_results}

    def _generate_economy_frames(self, m, D, refs, vertical: bool, settings: dict, bible: dict, prog):
        """Create continuity-first opening/closing stills for every scene.

        `frame_source=auto` tries Flow's no-charge image path first and falls back
        to the local/free image provider.  `free` skips Flow entirely.  Frames are
        reusable by both local image-motion and Flow first/last-frame video shots.
        """
        from .planning.frame_prompts import master_character_prompt, master_location_prompt, frame_prompt
        from .providers.flow_browser import FlowServiceBusy
        from .flow_reference_validation import quarantine_reference_copy
        reference_files = [str(p) for p in Path(D.get("references", os.path.join(D["root"], "references"))).glob('*')
                           if p.suffix.lower() in ('.jpg', '.jpeg', '.png') and
                           ('character-' in p.name or 'master' in p.name)]
        reference_files += [os.path.join(D["storyboard"], 'location_master.jpg'),
                            os.path.join(D["storyboard"], 'character_master.jpg')]
        for frame in Path(D["storyboard"]).glob('shot_*_*.jpg'):
            rejected = quarantine_reference_copy(frame, reference_files)
            if rejected:
                prog(f"⚠️ {frame.name}: uploaded reference copy quarantined; recovering the saved image request.", 24)
                self.pm.log(m.job_id, 'reference_copy_rejected', rejected)
        providers = self._providers()
        flowp, freep = providers["flow"], providers["image"]
        source = str(settings.get("frame_source", "auto") or "auto").lower()
        reuse_project_media = bool(settings.get("flow_reuse_project_media", True))
        longform_single_frame = bool(
            m.profile == "STORYBOARD_ECONOMY"
            and source == "flow"
            and float(getattr(m, "target_seconds", 0) or 0) >= 180
        )
        if longform_single_frame:
            one_frame = sum(1 for _s in m.shots if getattr(_s, "provider", "") not in ("flow", "movieflow"))
            paired = len(m.shots) - one_frame
            prog(f"🧩 Long-form optimization: {one_frame} image-motion shot(s) use one Flow still each; "
                 f"{paired} AI-video shot(s) keep opening+closing frame pairs.", 24)
        if reuse_project_media:
            added = self._bootstrap_flow_frame_cache(m, settings, bible, vertical)
            if added:
                prog(f"♻️ Indexed {added} compatible frame(s) from earlier jobs using this Flow project.", 24)

        batch_recovery = source == "flow" and bool(settings.get("flow_continue_unresolved_frames", False))
        unresolved = []

        def gen_once(prompt, out, shot, label="frame", bypass_cache: bool = False):
            project_url = self._flow_project_url(m.job_id, settings)
            comp = {"prompt": prompt, "negative": getattr(shot, "negative", ""),
                    "project": f"AutoVideo-{m.job_id}",
                    "project_url": project_url,
                    "approval": "once", "max_generation_credits": 0,
                    "flow_reuse_project_media": reuse_project_media,
                    "flow_capacity_wait_seconds": _setting_int(settings, "flow_capacity_wait_seconds", 900),
                    "flow_capacity_retries": _setting_int(settings, "flow_capacity_retries", 8),
                    "flow_image_wait_seconds": _setting_int(settings, "flow_image_wait_seconds", 60),
                    "flow_replace_unresolved_images": bool(settings.get("flow_replace_unresolved_images", False)),
                    "flow_image_replacement_limit": _setting_int(settings, "flow_image_replacement_limit", 30),
                    "flow_image_replacement_root": D["root"]}
            errors = []
            from .cast import photo_paths
            comp['reference_paths'] = [] if label == 'location master' else photo_paths(refs, shot)

            # Exact project/prompt/aspect cache only. This is intentionally stricter
            # than matching old Flow filenames such as shot_001_open.jpg.
            if reuse_project_media and project_url and not bypass_cache:
                cached = self._flow_frame_cache_get(project_url, prompt, vertical, label)
                if cached:
                    try:
                        os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
                        shutil.copy2(cached, out)
                        if label in ("opening frame", "closing frame") and quarantine_reference_copy(out, reference_files):
                            raise ValueError("cached frame was an uploaded reference copy")
                        if not self._is_valid_image_file(out):
                            self._remove_invalid_image(out)
                            raise ValueError("cached Flow frame was corrupt/incomplete")
                        prog(f"♻️ {shot.shot_id} {label}: reused exact frame from shared Flow-project cache.", 25)
                        self.pm.log(m.job_id, "flow_frame_cache_hit",
                                    {"shot": shot.shot_id, "label": label, "project_url": project_url,
                                     "mode": "exact"})
                        return out, "flow-project-cache"
                    except Exception:
                        pass
                reuse_mode = str(settings.get("flow_reuse_mode", "exact") or "exact").lower()
                previous = self._previous_project_frame(m, project_url, shot.shot_id, label, reuse_mode)
                if previous:
                    try:
                        os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
                        shutil.copy2(previous, out)
                        if label in ("opening frame", "closing frame") and quarantine_reference_copy(out, reference_files):
                            raise ValueError("cached frame was an uploaded reference copy")
                        if not self._is_valid_image_file(out):
                            self._remove_invalid_image(out)
                            raise ValueError("reused project frame was corrupt/incomplete")
                        self._flow_frame_cache_put(project_url, prompt, vertical, label, out, m.job_id)
                        prog(f"♻️ {shot.shot_id} {label}: reused existing {reuse_mode}-matched frame from this Flow project.", 25)
                        self.pm.log(m.job_id, "flow_project_existing_frame_reuse",
                                    {"shot": shot.shot_id, "label": label, "project_url": project_url,
                                     "mode": reuse_mode, "source": previous})
                        return out, f"flow-project-{reuse_mode}-reuse"
                    except Exception:
                        pass
            if source in ("auto", "flow"):
                max_attempts = max(1, _setting_int(settings, "flow_frame_retries", 3))
                network_wait = max(15, int(settings.get("network_wait_seconds", 300) or 300))
                attempt = 1
                network_recoveries = 0
                browser_recoveries = 0
                last_error = None
                while attempt <= max_attempts:
                    try:
                        r = flowp.generate_image(shot, comp, out, vertical, dry_run=False)
                        bound = self._remember_flow_project_url(
                            m.job_id, r.get("project_url") or flowp.current_project_url())
                        if bound:
                            comp["project_url"] = bound
                        if r.get("path") and self._is_valid_image_file(r["path"]):
                            result_source = str(r.get("provider") or "flow")
                            if (result_source == "flow" and reuse_project_media
                                    and comp.get("project_url")):
                                self._flow_frame_cache_put(comp["project_url"], prompt, vertical,
                                                           label, r["path"], m.job_id)
                            return r["path"], ("free" if result_source == "image" else result_source)
                        if r.get("path") and os.path.exists(r["path"]):
                            self._remove_invalid_image(r["path"])
                            errtxt = "Flow returned a corrupt/incomplete image file; removed it and will retry"
                        else:
                            errtxt = r.get("error", "no image returned")
                        # A connectivity drop should pause/recover, not consume a
                        # normal generation retry or silently switch providers.
                        if (network_recoveries < 3 and
                                flowp.is_transient_network_error(errtxt)):
                            prog(f"🌐 {shot.shot_id} {label}: network interrupted; waiting for Flow to recover...", 26)
                            if flowp.recover_network(comp["project"], timeout_s=network_wait,
                                                     project_url=comp.get("project_url")):
                                network_recoveries += 1
                                prog(f"🌐 Network restored; retrying {shot.shot_id} {label} without losing progress.", 26)
                                continue
                        errors.append(f"Flow attempt {attempt}: {errtxt}")
                        last_error = _typed_flow_error(errtxt, flowp)
                    except FlowRequestPending as e:
                        last_error = e
                        if (settings.get("flow_pause_on_unresolved_request", False) and not batch_recovery
                                and not (label == 'closing frame' and settings.get('flow_local_closing_fallback'))):
                            self._pause_pending_flow(m, shot.shot_id, e, comp.get("project_url", ""))
                        errors.append(f"Flow image recovery remains ambiguous: {e}")
                        if source == "auto":
                            prog(f"↪️ {shot.shot_id} {label}: exact Flow image recovery was ambiguous; using the configured free fallback.", 26)
                        break
                    except FlowServiceBusy as e:
                        # High-demand throttling is handled internally with bounded
                        # Try-again/backoff. If that window expires, pause/fallback
                        # without burning normal frame retries.
                        errors.append(f"Flow capacity: {e}")
                        if source == "flow":
                            try:
                                flowp.close()
                            except Exception:
                                pass
                            raise RuntimeError(
                                f"Strict --frame-source flow: {shot.shot_id} {label} could not proceed because Flow Agent remained at high demand. "
                                f"No normal frame retry was consumed. Completed frames are cached; explicitly resume `{m.job_id}` later if desired. "
                                + str(e)[-500:]
                            ) from e
                        break
                    except Exception as e:
                        last_error = e
                        if (browser_recoveries < 2 and flowp.is_browser_closed_error(e)):
                            prog(f"🧭 {shot.shot_id} {label}: browser session closed; rebuilding Flow session...", 26)
                            if flowp.recover_browser(comp["project"],
                                                     project_url=comp.get("project_url")):
                                browser_recoveries += 1
                                prog(f"🧭 Browser recovered; retrying {shot.shot_id} {label} without consuming a frame retry.", 26)
                                continue
                        if (network_recoveries < 3 and
                                flowp.is_transient_network_error(e)):
                            prog(f"🌐 {shot.shot_id} {label}: network interrupted; waiting up to {network_wait}s...", 26)
                            if flowp.recover_network(comp["project"], timeout_s=network_wait,
                                                     project_url=comp.get("project_url")):
                                network_recoveries += 1
                                prog(f"🌐 Network restored; retrying {shot.shot_id} {label} without losing progress.", 26)
                                continue
                        errors.append(f"Flow attempt {attempt}: {type(e).__name__}: {e}")
                        from .providers.flow_browser import FlowReferenceUnavailable
                        if isinstance(e, FlowReferenceUnavailable) and getattr(shot,'character_ids',[]):
                            self._pause_pending_flow(m,shot.shot_id,e,comp.get('project_url',''))
                        if isinstance(e, FlowReferenceUnavailable):
                            # attach_agent_media already tried exact picker reuse
                            # and its bounded byte-identical upload recovery.
                            prog(f"⚠️ {shot.shot_id} {label}: reference recovery exhausted before submission; skipping identical outer retries.", 26)
                            break
                    if attempt < max_attempts:
                        prog(f"⚠️ {shot.shot_id} {label}: Flow attempt {attempt} failed; retrying ({attempt+1}/{max_attempts})...", 26)
                        time.sleep(min(6.0, 1.5 * attempt))
                    attempt += 1
                if source == "flow":
                    try:
                        flowp.close()
                    except Exception:
                        pass
                    raise RuntimeError(
                        f"Strict --frame-source flow: {shot.shot_id} {label} failed after {min(attempt, max_attempts)} attempts. "
                        f"Completed frames are cached; after fixing connectivity/UI run `python3 cli.py v3 resume {m.job_id}`. "
                        + "; ".join(errors)[-900:]
                    ) from last_error
                prog(f"⚠️ {shot.shot_id} {label}: Flow failed after {min(attempt, max_attempts)} attempts -> free fallback (may use Pollinations).", 26)
                self.pm.log(m.job_id, "flow_frame_fallback", {
                    "shot": shot.shot_id, "label": label, "errors": errors[-max_attempts:], "to": "free"})
            try:
                return self._free_image_fallback(
                    shot, comp, out, vertical, freep, label=label), "free"
            except Exception as e:
                errors.append(str(e))
            raise RuntimeError("; ".join(errors)[-800:])

        def gen(prompt, out, shot, label="frame", bypass_cache=False):
            # Master identity/location are prerequisites. Do not create scenes
            # with a missing master, or switch provider/scene to avoid a gate.
            request_out = out
            try:
                if batch_recovery:
                    phase = "open" if label == "opening frame" else "close"
                    token = hashlib.sha256(f"{m.job_id}|{shot.shot_id}|{label}|{prompt}|{vertical}".encode()).hexdigest()[:16]
                    artifact = os.path.join(D["root"], ".flow-workers", "economy-frame-artifacts",
                                            f"{shot.shot_id}_{phase}_{token}.jpg")
                    worker_journal = artifact + ".flow-request.json"
                    # Preserve pending requests created by older parallel runs.
                    # Recover their original output/project instead of issuing a
                    # second serial request for this same frame.
                    if os.path.isfile(worker_journal) and not os.path.isfile(out + ".flow-request.json"):
                        request_out = artifact
                        if not self._is_valid_image_file(artifact):
                            with open(worker_journal, encoding="utf-8") as handle:
                                worker_request = json.load(handle)
                            comp = {"prompt": prompt, "project": f"AutoVideo-{m.job_id}",
                                    "project_url": worker_request.get("project_url"),
                                    "approval": "once", "max_generation_credits": 0}
                            result = flowp.generate_image(shot, comp, artifact, vertical, dry_run=False)
                            if not result.get("path") or not self._is_valid_image_file(result["path"]):
                                raise RuntimeError("Saved worker image remains unresolved; original request retained")
                        shutil.copy2(artifact, out)
                        return out, "flow-worker-exact-recovery"
                return gen_once(prompt, out, shot, label, bypass_cache)
            except (RuntimeError, FlowRequestPending) as error:
                if label == 'closing frame' and settings.get('flow_local_closing_fallback'):
                    fallback = self._local_closing_fallback(m.job_id, shot, out, D['root'], error)
                    if fallback:
                        prog(f'⚠️ {shot.shot_id}: using its saved opening image as closing guidance; pending Flow request retained.', 26)
                        return fallback
                if not batch_recovery or label not in ("opening frame", "closing frame"):
                    raise
                unresolved.append({"shot_id": shot.shot_id, "frame": label,
                                   "path": os.path.relpath(out, D["root"]),
                                   "request_file": os.path.relpath(request_out + ".flow-request.json", D["root"]),
                                   "error": str(error)[-1600:]})
                prog(f"⏸️ {shot.shot_id} {label}: retained for exact recovery; continuing other frames.", 26)
                return None, "unresolved-exact-flow"

        # Stable master references.  They are generated once per project and can
        # later be supplied to Flow ingredients/character references.
        if bible.get("characters") and not refs.get("character"):
            tmp = os.path.join(D["storyboard"], "character_master.jpg")
            try:
                dummy = m.shots[0] if m.shots else None
                if dummy:
                    p, src = gen(master_character_prompt(bible, vertical), tmp, dummy, "character master")
                    refs.add("character", p, "character_master.jpg")
                    self.pm.log(m.job_id, "master_character", {"source": src})
            except Exception as e:
                prog(f"⚠️ Character master image failed: {str(e)[:160]}", 25)
                self.pm.log(m.job_id, "master_character_failed", {"error": str(e)[:180]})
                if source == "flow":
                    raise
        if bible.get("locations") and not refs.get("location"):
            tmp = os.path.join(D["storyboard"], "location_master.jpg")
            try:
                dummy = m.shots[0] if m.shots else None
                if dummy:
                    p, src = gen(master_location_prompt(bible, vertical), tmp, dummy, "location master")
                    refs.add("location", p, "location_master.jpg")
                    self.pm.log(m.job_id, "master_location", {"source": src})
            except Exception as e:
                prog(f"⚠️ Location master image failed: {str(e)[:160]}", 25)
                self.pm.log(m.job_id, "master_location_failed", {"error": str(e)[:180]})
                if source == "flow":
                    raise

        # Parallelize only frames that do not depend on the previous scene's
        # closing-frame identity. Continuity-linked openings are copied later in
        # the story-ordered pass; each selected video scene still keeps its own
        # opening/closing pair (long-form single-frame optimization excepted).
        parallel_sources = {}
        frame_workers = max(1, min(3, int(settings.get("flow_image_workers", 1) or 1)))
        if (frame_workers > 1 and source in ("auto", "flow") and not batch_recovery
                and not settings.get('flow_local_closing_fallback')):
            parallel_tasks = []
            main_project_url = self._flow_project_url(m.job_id, settings)

            def plan_parallel_frame(shot, prompt, out_path, label, paired_open_path=""):
                if self._remove_invalid_image(out_path):
                    prog(f"🧹 {shot.shot_id} {label}: removed corrupt/incomplete cached image.", 25)
                if self._is_valid_image_file(out_path):
                    return
                if reuse_project_media and main_project_url:
                    cached = self._flow_frame_cache_get(main_project_url, prompt, vertical, label)
                    if cached:
                        try:
                            shutil.copy2(cached, out_path)
                            if self._is_valid_image_file(out_path):
                                parallel_sources[os.path.abspath(out_path)] = "flow-project-cache"
                                self.pm.log(m.job_id, "flow_frame_cache_hit", {
                                    "shot": shot.shot_id, "label": label,
                                    "project_url": main_project_url, "mode": "exact"})
                                return
                        except Exception:
                            self._remove_invalid_image(out_path)
                    reuse_mode = str(settings.get("flow_reuse_mode", "exact") or "exact").lower()
                    previous = self._previous_project_frame(
                        m, main_project_url, shot.shot_id, label, reuse_mode)
                    if previous:
                        try:
                            shutil.copy2(previous, out_path)
                            if self._is_valid_image_file(out_path):
                                self._flow_frame_cache_put(
                                    main_project_url, prompt, vertical, label, out_path, m.job_id)
                                parallel_sources[os.path.abspath(out_path)] = (
                                    f"flow-project-{reuse_mode}-reuse")
                                self.pm.log(m.job_id, "flow_project_existing_frame_reuse", {
                                    "shot": shot.shot_id, "label": label,
                                    "project_url": main_project_url, "mode": reuse_mode,
                                    "source": previous})
                                return
                        except Exception:
                            self._remove_invalid_image(out_path)
                parallel_tasks.append({"shot": shot, "prompt": prompt,
                                       "out": out_path, "label": label,
                                       "paired_open_path": paired_open_path})

            planned_previous_close = False
            planned_previous_shot = None
            refresh_coverages = {"hook", "insert", "broll", "hero_outro"}
            for planned_shot in m.shots:
                if planned_shot.status not in ("planned", "approved", "failed"):
                    prior_close = getattr(planned_shot, "closing_frame", None)
                    if self._is_valid_image_file(prior_close):
                        planned_previous_close = True
                    continue
                planned_open = os.path.join(
                    D["storyboard"], f"{planned_shot.shot_id}_open.jpg")
                planned_close = os.path.join(
                    D["storyboard"], f"{planned_shot.shot_id}_close.jpg")
                same_environment = bool(
                    planned_previous_shot and
                    self._norm_prompt_key(getattr(planned_previous_shot, "environment", "")) ==
                    self._norm_prompt_key(getattr(planned_shot, "environment", "")))
                uses_previous_close = bool(
                    planned_previous_close and same_environment and
                    getattr(planned_shot, "coverage", "primary") not in refresh_coverages)
                if not uses_previous_close and not self._is_valid_image_file(planned_open):
                    plan_parallel_frame(
                        planned_shot,
                        frame_prompt(planned_shot, bible, vertical, "open"),
                        planned_open, "opening frame")
                skip_planned_close = bool(
                    longform_single_frame
                    and getattr(planned_shot, "provider", "") not in ("flow", "movieflow")
                    and not self._is_valid_image_file(planned_close))
                if not skip_planned_close and not self._is_valid_image_file(planned_close):
                    plan_parallel_frame(
                        planned_shot,
                        frame_prompt(planned_shot, bible, vertical, "close"),
                        planned_close, "closing frame", paired_open_path=planned_open)
                planned_previous_close = bool(
                    self._is_valid_image_file(planned_close) or not skip_planned_close)
                planned_previous_shot = planned_shot
            if parallel_tasks:
                parallel_sources.update(self._generate_economy_frames_parallel(
                    m, D, refs, vertical, settings, prog, parallel_tasks,
                    frame_workers, source))

        previous_close = None
        previous_shot = None
        for i, s in enumerate(m.shots):
            open_path = os.path.join(D["storyboard"], f"{s.shot_id}_open.jpg")
            close_path = os.path.join(D["storyboard"], f"{s.shot_id}_close.jpg")
            # A full disk or interrupted browser download can leave a .jpg that
            # exists but is not actually decodable.  Purge it before deciding a
            # frame is cached/completed so resume can regenerate it cleanly.
            if self._remove_invalid_image(open_path):
                prog(f"🧹 {s.shot_id} opening frame: removed corrupt/incomplete cached image.", 25)
            if self._remove_invalid_image(close_path):
                prog(f"🧹 {s.shot_id} closing frame: removed corrupt/incomplete cached image.", 26)
            saved_close_on_resume = self._is_valid_image_file(close_path)
            if s.status not in ("planned", "approved", "failed"):
                prev = s.closing_frame or previous_close
                previous_close = prev if self._is_valid_image_file(prev) else previous_close
                continue
            # Preserve continuity only when the new shot genuinely shares the
            # same environment. v5.0 copied *every* previous closing frame into
            # the next opening, which made listicles look like one repeated room.
            # Inserts/b-roll/hooks/outros intentionally refresh composition.
            same_environment = bool(
                previous_shot and
                self._norm_prompt_key(getattr(previous_shot, "environment", "")) ==
                self._norm_prompt_key(getattr(s, "environment", ""))
            )
            refresh_coverages = {"hook", "insert", "broll", "hero_outro"}
            reuse_previous = bool(
                previous_close and self._is_valid_image_file(previous_close) and
                same_environment and getattr(s, "coverage", "primary") not in refresh_coverages
            )
            if reuse_previous:
                try:
                    shutil.copy(previous_close, open_path)
                except shutil.SameFileError:
                    pass
                open_src = "previous-close-continuity"
            elif not self._is_valid_image_file(open_path):
                prog(f"🖼️ [{i+1}/{len(m.shots)}] {s.shot_id} opening frame...",
                     min(29, 25 + int(4 * (i + 1) / max(1, len(m.shots)))))
                _, open_src = gen(frame_prompt(s, bible, vertical, "open"), open_path, s, "opening frame")
            else:
                open_src = parallel_sources.get(os.path.abspath(open_path), "cached")

            # A stale Flow asset selector/cache can accidentally return the
            # generic location master as the shot opening. Do not let a master
            # reference become the actual scene image: force one fresh,
            # action-specific opening frame and replace the poisoned cache entry.
            if self._is_valid_image_file(open_path):
                open_hash = self._file_sha256(open_path)
                location_hashes = {self._file_sha256(lp) for lp in refs.get("location")
                                   if self._is_valid_image_file(lp)}
                if open_hash and open_hash in location_hashes and open_src != "previous-close-continuity":
                    prog(f"♻️ {s.shot_id}: opening frame matched location master; regenerating a scene-specific composition.", 25)
                    try:
                        os.remove(open_path)
                    except Exception:
                        pass
                    open_prompt = frame_prompt(s, bible, vertical, "open") + (
                        " IMPORTANT: create a NEW shot-specific composition, not the generic location/master image. "
                        "Show the described subject action prominently with a clearly different camera position and framing.")
                    _, open_src = gen(open_prompt, open_path, s, "opening frame", bypass_cache=True)
            close_prompt_text = frame_prompt(s, bible, vertical, "close")
            degraded_close = False
            skip_longform_close = bool(
                longform_single_frame
                and getattr(s, "provider", "") not in ("flow", "movieflow")
                and not self._is_valid_image_file(close_path)
            )
            if skip_longform_close:
                # For five-minute+ strict-Flow jobs, generating a second still for
                # every local image-motion scene roughly doubles browser work and
                # can take hours. A single high-quality Flow still already supports
                # the local pan/zoom renderer, while paid/AI-video shots retain
                # distinct first/last guidance frames.
                close_src = "skipped-longform-single-frame"
                degraded_close = True
                prog(f"⏭️ [{i+1}/{len(m.shots)}] {s.shot_id} closing frame skipped (single-frame long-form image-motion).",
                     min(29, 25 + int(4 * (i + 1) / max(1, len(m.shots)))))
            elif not self._is_valid_image_file(close_path):
                prog(f"🖼️ [{i+1}/{len(m.shots)}] {s.shot_id} closing frame...",
                     min(29, 25 + int(4 * (i + 1) / max(1, len(m.shots)))))
                try:
                    _, close_src = gen(close_prompt_text, close_path, s, "closing frame")
                except RuntimeError as e:
                    # In STORYBOARD_ECONOMY only the selected paid Flow-video
                    # scene truly requires a distinct closing frame.  Do not pause
                    # the entire job because a later image-motion scene's closing
                    # still timed out after all Flow retries.  Reuse that scene's
                    # already-generated Flow opening frame as an emergency close.
                    # This does NOT switch to another image provider and therefore
                    # still honours strict --frame-source flow for source media.
                    if (source == "flow" and m.profile == "STORYBOARD_ECONOMY"
                            and getattr(s, "provider", "") != "flow"
                            and os.path.exists(open_path)):
                        shutil.copy2(open_path, close_path)
                        close_src = "flow-opening-emergency-reuse"
                        degraded_close = True
                        prog(f"⚠️ {s.shot_id} closing frame: Flow exhausted retries; "
                             "reusing the existing Flow opening frame so this non-video scene does not pause the job.", 26)
                        self.pm.log(m.job_id, "flow_closing_frame_emergency_reuse", {
                            "shot": s.shot_id, "error": str(e)[-500:],
                            "source": "opening_frame", "provider": "flow"})
                    else:
                        raise
            else:
                close_src = parallel_sources.get(os.path.abspath(close_path), "cached")

            if os.path.isfile(close_path + '.local-fallback.json'):
                close_src = 'local-opening-fallback'
                degraded_close = True

            if (saved_close_on_resume and getattr(s, 'provider', '') != 'flow'
                    and self._is_valid_image_file(open_path) and self._is_valid_image_file(close_path)
                    and self._file_sha256(open_path) == self._file_sha256(close_path)):
                degraded_close = True
                close_src = getattr(s, 'closing_frame_source', '') or 'cached-single-frame-guidance'
                prog(f'⚠️ {s.shot_id}: retained cached single-frame guidance; quality review remains required.', 26)

            # A repeated free fallback is a single-frame guidance degradation,
            # not evidence authorizing another attempt through the broken Flow picker.
            if (close_src == 'free' and os.path.exists(open_path) and os.path.exists(close_path)
                    and self._file_sha256(open_path) == self._file_sha256(close_path)):
                degraded_close = True
                close_src = 'free-single-frame-guidance'
                prog(f"⚠️ {s.shot_id}: free opening/closing are identical; using single-frame guidance. Review likeness and scene meaning; no extra Flow retry.",26)
                self.pm.log(m.job_id,'single_frame_guidance',{'shot':s.shot_id,'source':'free','review_required':True})

            # v4.6 could bootstrap a poisoned cache created by older Flow asset
            # selection bugs. In the reported run shot_001_open.jpg and
            # shot_001_close.jpg had the *same content hash*, so Flow was asked to
            # interpolate an image to itself. Detect/repair that automatically.
            if os.path.exists(open_path) and os.path.exists(close_path) and not degraded_close:
                open_hash = self._file_sha256(open_path)
                close_hash = self._file_sha256(close_path)
                if open_hash and open_hash == close_hash:
                    prog(f"♻️ {s.shot_id}: opening/closing frames are identical; "
                         "invalidating the closing-frame cache and regenerating it.", 26)
                    self.pm.log(m.job_id, "duplicate_frame_pair", {
                        "shot": s.shot_id, "sha256": open_hash,
                        "open_source": open_src, "close_source": close_src})
                    # Remove the bad original-key cache entry as well as this job's
                    # copy so a later run cannot immediately resurrect it.
                    project_url = self._flow_project_url(m.job_id, settings)
                    try:
                        bad = self._flow_frame_cache_get(project_url, close_prompt_text, vertical, "closing frame")
                        if bad and os.path.exists(bad):
                            os.remove(bad)
                        meta_bad = os.path.splitext(bad)[0] + ".json" if bad else ""
                        if meta_bad and os.path.exists(meta_bad):
                            os.remove(meta_bad)
                    except Exception:
                        pass
                    try:
                        os.remove(close_path)
                    except Exception:
                        pass

                    # Give the image agent an explicit visual delta while retaining
                    # the same subject/location/identity continuity.
                    corrective = (close_prompt_text +
                        " IMPORTANT: This closing frame MUST be visibly different from the opening frame. "
                        "Show the completed action/end-state, change subject pose or object state, and use a "
                        "noticeably different camera moment while preserving identity, wardrobe and location.")
                    _, close_src = gen(corrective, close_path, s, "closing frame", bypass_cache=True)

                    # One extra repair attempt if the provider still returned the
                    # exact same bytes. This is independent of paid video retries.
                    if (os.path.exists(close_path) and
                            self._file_sha256(close_path) == open_hash):
                        try:
                            os.remove(close_path)
                        except Exception:
                            pass
                        corrective2 = corrective + (
                            " Use a different framing/camera position and a clearly changed end-state; "
                            "do not reproduce the supplied/opening composition.")
                        _, close_src = gen(corrective2, close_path, s, "closing frame", bypass_cache=True)

                    # Store a repaired distinct frame under the normal/original key
                    # so future same-project jobs can safely reuse it.
                    if (project_url and os.path.exists(close_path) and
                            self._file_sha256(close_path) != open_hash):
                        self._flow_frame_cache_put(project_url, close_prompt_text, vertical,
                                                   "closing frame", close_path, m.job_id)

            # For composition-refresh shots, reject a closing frame that is
            # perceptually almost the same as the previous scene. Exact byte
            # comparisons miss re-encoded duplicates; dHash catches those cheaply.
            if (not saved_close_on_resume and not degraded_close and previous_close and self._is_valid_image_file(previous_close) and
                    self._is_valid_image_file(close_path) and
                    getattr(s, "provider", "") != "flow" and
                    getattr(s, "coverage", "") in {"insert", "broll", "hero_outro"}):
                dist = self._image_distance(previous_close, close_path)
                if dist is not None and dist <= 5:
                    prog(f"♻️ {s.shot_id}: composition too similar to previous scene; regenerating for visual diversity.", 26)
                    try:
                        os.remove(close_path)
                    except Exception:
                        pass
                    diverse_prompt = close_prompt_text + (
                        " IMPORTANT: make this composition visually distinct from the previous shot. "
                        "Change camera distance/angle, subject placement, foreground/background geometry and end-state while preserving story continuity.")
                    try:
                        _, close_src = gen(diverse_prompt, close_path, s, "closing frame", bypass_cache=True)
                    except Exception:
                        # Diversity is quality-only; the normal valid frame path
                        # remains recoverable on resume and must not crash a job.
                        pass

            s.opening_frame = open_path if self._is_valid_image_file(open_path) else None
            s.closing_frame = close_path if self._is_valid_image_file(close_path) else None
            s.opening_frame_source = open_src if s.opening_frame else ""
            s.closing_frame_source = close_src if s.closing_frame else ""
            s.start_frame = s.opening_frame
            s.end_frame = s.closing_frame
            if s.opening_frame:
                try: refs.add("start", s.opening_frame, f"{s.shot_id}_start.jpg")
                except Exception: pass
            if s.closing_frame:
                try: refs.add("end", s.closing_frame, f"{s.shot_id}_end.jpg")
                except Exception: pass
            s.reference_assets = [p for p in [s.opening_frame, s.closing_frame, *refs.get("character"), *refs.get("location")] if p]
            self.pm.update_shot(m.job_id, s)
            self.pm.log(m.job_id, "economy_frames", {"shot": s.shot_id, "open": open_src,
                                                       "close": close_src, "strategy": s.media_strategy})
            previous_close = s.closing_frame
            previous_shot = s
        try:
            flowp.close()
        except Exception:
            pass
        if batch_recovery:
            valid_frames = sum(self._is_valid_image_file(os.path.join(D["storyboard"], f"{shot.shot_id}_{phase}.jpg"))
                               for shot in m.shots for phase in ("open", "close"))
            report = {"schema_version": 1, "job_id": m.job_id, "policy": "exact-flow-continue-frames",
                      "valid_frames": valid_frames, "unresolved": list({(item["shot_id"], item["frame"]): item for item in unresolved}.values()),
                      "new_replacement_generations": 0, "media_substitutions": 0,
                      "video_generation_started": False, "updated_at": time.time()}
            _save_json(os.path.join(D["root"], "flow_frame_recovery_batch.json"), report)
            if unresolved:
                raise FlowFrameBatchPending(report)

    # ---------------- generation ----------------
    def _generate_scene_images(self, m, D, refs, vertical: bool, K: int, prog, settings=None):
        """K stills per scene via Flow image mode (free provider fallback).
        Best still overwrites the storyboard frame -> feeds image/frames video gen."""
        settings = settings if settings is not None else self._settings(m.job_id)
        workers = max(1, min(3, int(settings.get("flow_image_workers", 1) or 1)))
        strict_frames = settings.get("frame_source") == "flow"
        free_frames = settings.get("frame_source") == "free"
        if workers > 1 and not free_frames:
            return self._generate_scene_images_parallel(m, D, refs, vertical, K, prog,
                                                        settings or {}, workers)
        from .providers.flow_browser import (FlowUIChanged, FlowAuthNeeded, FlowQuotaExceeded,
                                                   FlowBrowserClosedError, FlowServiceBusy)
        from .qc.video_qc import score_image
        providers = self._providers()
        fprov, freeprov = providers["flow"], providers["image"]
        project_url = self._flow_project_url(m.job_id, settings or {})
        for idx, s in enumerate(m.shots):
            if s.status not in ("planned", "approved", "failed"):
                continue
            imgdir = os.path.join(D["flow"], "shots", s.shot_id, "images")
            os.makedirs(imgdir, exist_ok=True)
            got = []
            for k in range(K):
                out = os.path.join(imgdir, f"img_{k+1:02d}.jpg")
                if os.path.exists(out) and os.path.getsize(out) > 5000:
                    got.append(out)
                    continue
                prog(f"🖼️ {s.shot_id} image {k+1}/{K}...", 26)
                comp = {"prompt": s.compiled_prompt, "negative": s.negative, "reference_paths": photo_paths(refs,s),
                        "project": f"AutoVideo-{m.job_id}",
                        "project_url": project_url,
                        "flow_capacity_wait_seconds": _setting_int(settings, "flow_capacity_wait_seconds", 900),
                        "flow_capacity_retries": _setting_int(settings, "flow_capacity_retries", 8),
                        "flow_image_wait_seconds": _setting_int(settings, "flow_image_wait_seconds", 60),
                    "flow_replace_unresolved_images": bool(settings.get("flow_replace_unresolved_images", False)),
                    "flow_image_replacement_limit": _setting_int(settings, "flow_image_replacement_limit", 30),
                    "flow_image_replacement_root": D["root"]}
                try:
                    res = (freeprov if free_frames else fprov).generate_image(s, comp, out, vertical, dry_run=False)
                    observed_url = res.get("project_url")
                    if not observed_url:
                        try:
                            observed_url = fprov.current_project_url()
                        except Exception:
                            observed_url = ""
                    bound = self._remember_flow_project_url(m.job_id, observed_url)
                    if bound:
                        project_url = bound
                        if settings is not None:
                            settings["flow_project_url"] = bound
                    if res.get("path") and os.path.exists(res["path"]):
                        got.append(out)
                    else:
                        raise RuntimeError(res.get("error", "no image returned"))
                except FlowRequestPending as e:
                    if strict_frames: raise
                    if (settings or {}).get("flow_pause_on_unresolved_request", False):
                        self._pause_pending_flow(m, s.shot_id, e, project_url)
                    self.pm.log(m.job_id, "scene_image_flow_pending_fallback", {
                        "shot": s.shot_id, "reason": "unresolved_exact_flow_asset", "to": "free"})
                    try:
                        got.append(self._free_image_fallback(
                            s, comp, out, vertical, freeprov, label=f"image {k + 1}"))
                    except Exception as fallback_error:
                        self.pm.log(m.job_id, "scene_image_failed", {
                            "shot": s.shot_id, "error": str(fallback_error)[:150]})
                except (FlowAuthNeeded, FlowQuotaExceeded) as e:
                    try:
                        bound = self._remember_flow_project_url(m.job_id, fprov.current_project_url())
                        if bound:
                            project_url = bound
                    except Exception:
                        pass
                    m2 = self.pm.load_manifest(m.job_id)
                    m2.status = "assisted"
                    self.pm.save_manifest(m2)
                    self.db.upsert(m.job_id, status="assisted")
                    raise AssistedNeeded(m.job_id, s.shot_id, s.compiled_prompt,
                                         D["downloads"], f"{type(e).__name__}: {e}")
                except Exception as e:
                    if strict_frames: raise RuntimeError("Strict Flow image failed; no free substitution: " + str(e)) from e
                    self.pm.log(m.job_id, "scene_image_flow_failed",
                                {"shot": s.shot_id, "error": str(e)[:150], "fallback": "free"})
                    try:
                        got.append(self._free_image_fallback(s, comp, out, vertical, freeprov, label=f"image {k + 1}"))
                    except Exception as e2:
                        self.pm.log(m.job_id, "scene_image_failed",
                                    {"shot": s.shot_id, "error": str(e2)[:150]})
            scored = [(score_image(p)["overall"], p) for p in got
                      if self._is_valid_image_file(p)]
            scored.sort(reverse=True)
            if scored and scored[0][0] > 0:
                best = scored[0][1]
                frame = os.path.join(D["storyboard"], f"{s.shot_id}.jpg")
                try:
                    shutil.copy(best, frame)
                    refs.add("storyboard", frame, f"{s.shot_id}.jpg")
                except Exception:
                    pass
                s.reference_assets = [p for _, p in scored]
                self.pm.log(m.job_id, "scene_images",
                            {"shot": s.shot_id, "count": len(scored),
                             "best_score": scored[0][0]})
            else:
                if strict_frames: raise RuntimeError("Strict Flow image produced no valid frame; no paid video submitted")
                self.pm.log(m.job_id, "scene_images_empty", {"shot": s.shot_id})
            self.pm.update_shot(m.job_id, s)
        try:
            providers["flow"].close()
        except Exception:
            pass

    def _generate_scene_images_parallel(self, m, D, refs, vertical: bool, K: int,
                                        prog, settings: dict, workers: int):
        """Generate independent still candidates with isolated browser profiles.

        Playwright's sync API and one browser context are not thread-safe.  Each
        worker therefore owns a provider/profile.  Results are merged and the
        manifest is updated only on the main thread.
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from .providers.flow_browser import (FlowBrowserProvider, PROFILE_DIR,
                                             FlowAuthNeeded, FlowQuotaExceeded,
                                             resolve_browser_cfg)
        from .providers.image_provider import ImageProvider
        from .qc.video_qc import score_image

        worker_root = os.path.join(D["root"], ".flow-workers")
        os.makedirs(worker_root, exist_ok=True)
        try:
            with open("config/flow_ui.yaml", encoding="utf-8") as handle:
                browser_cfg = resolve_browser_cfg(yaml.safe_load(handle) or {})
            worker_uses_cdp = (str(browser_cfg.get("mode", "auto")).lower() in ("auto", "cdp")
                               and bool(browser_cfg.get("cdp_url")))
        except Exception:
            worker_uses_cdp = False
        # Browser profiles are private and live outside the job directory. Lock
        # and socket files must never be copied from an active Chromium profile.
        profile_root = os.path.join(
            os.path.dirname(os.path.abspath(PROFILE_DIR)), ".flow-workers")
        os.makedirs(profile_root, exist_ok=True)

        from .job_cleanup import profile_copy_ignore
        def profile_for(index):
            dst = os.path.join(profile_root, f"{m.job_id}-candidate-worker-{index + 1}")
            if worker_uses_cdp:
                # These profiles are not used by CDP-attached workers. Avoid
                # copying a potentially live Chrome profile just to attach tabs.
                os.makedirs(dst, exist_ok=True)
                return dst
            if not os.path.isdir(dst) and os.path.isdir(PROFILE_DIR):
                try:
                    shutil.copytree(PROFILE_DIR, dst, ignore=profile_copy_ignore)
                except Exception:
                    os.makedirs(dst, exist_ok=True)
            else:
                os.makedirs(dst, exist_ok=True)
            return dst

        tasks = []
        for s in m.shots:
            if s.status not in ("planned", "approved", "failed"):
                continue
            imgdir = os.path.join(D["flow"], "shots", s.shot_id, "images")
            os.makedirs(imgdir, exist_ok=True)
            for k in range(K):
                out = os.path.join(imgdir, f"img_{k+1:02d}.jpg")
                if os.path.exists(out):
                    if os.path.getsize(out) > 5000 and self._is_valid_image_file(out):
                        continue
                    self._remove_invalid_image(out)
                tasks.append((s, k, out))

        # A baseline diff cannot attribute concurrent generations in one project.
        # Each worker therefore owns a dedicated project AND browser/profile/tab.
        prog(f"🖼️ Parallel Flow queue: {len(tasks)} image(s), {workers} isolated worker project(s). Master references are created serially first.", 25)

        def run_batch(wi, batch):
            provider = None
            free_provider = ImageProvider()
            results = []
            project = f"AutoVideo-{m.job_id}-images-worker-{wi + 1}"
            binding_path = os.path.join(worker_root, f"worker-{wi + 1}-project.json")

            def fallback(shot, out, project_url, flow_error):
                if settings.get("frame_source") == "flow":
                    pending = FlowRequestPending("Strict Flow image failed; no free substitution: " + str(flow_error))
                    return (shot, "", project_url, "failed", str(pending), pending)
                journal = out + ".flow-request.json"
                if (os.path.isfile(journal)
                        and settings.get("flow_pause_on_unresolved_request", False)):
                    # User opted in to preserving unresolved Flow requests as a
                    # pause. Otherwise the configured free image fallback below
                    # may replace the local output, never the Flow gallery asset.
                    try:
                        with open(journal, encoding="utf-8") as handle:
                            pending_url = json.load(handle).get("project_url", "")
                    except Exception:
                        pending_url = project_url
                    pending = FlowRequestPending(
                        "A saved Flow image request is still pending; pausing by user choice.")
                    return (shot, "", pending_url, "failed", str(pending), pending)
                try:
                    fallback_path = self._free_image_fallback(shot, {
                        "prompt": shot.compiled_prompt, "negative": shot.negative,
                        "project": project, "project_url": project_url,
                    }, out, vertical, free_provider, label="parallel image")
                    return (shot, fallback_path, project_url, "free",
                            f"Flow failed: {str(flow_error)[:180]}", None)
                except Exception as fallback_exc:
                    fallback_error = str(fallback_exc)
                detail = f"Flow failed: {flow_error}; free fallback failed: {fallback_error}"[:300]
                # Match the prior feature's behavior: report this candidate as
                # failed and continue other images instead of pausing the job.
                return (shot, "", project_url, "failed", detail, None)

            try:
                # Playwright is created, used and closed on this same thread.
                provider = FlowBrowserProvider(profile_dir=profile_for(wi))
                project_url = ""
                if os.path.isfile(binding_path):
                    try:
                        with open(binding_path, encoding="utf-8") as handle:
                            project_url = json.load(handle).get("project_url", "")
                    except (OSError, ValueError, TypeError):
                        project_url = ""
                browser = provider._ensure()
                browser.ensure_project(project, project_url=project_url or None)
                project_url = browser.current_project_url()
                if not project_url:
                    raise RuntimeError("Parallel worker did not expose a project URL")
                with open(binding_path + ".tmp", "w", encoding="utf-8") as handle:
                    json.dump({"project_url": project_url}, handle)
                os.replace(binding_path + ".tmp", binding_path)
                for shot, k, out in batch:
                    comp = {"prompt": shot.compiled_prompt, "negative": shot.negative,
                            "project": project, "project_url": project_url,
                            "approval": "once", "max_generation_credits": 0,
                            "flow_capacity_wait_seconds": _setting_int(settings, "flow_capacity_wait_seconds", 900),
                            "flow_capacity_retries": _setting_int(settings, "flow_capacity_retries", 8),
                            "flow_image_wait_seconds": _setting_int(settings, "flow_image_wait_seconds", 60),
                            "reference_paths": photo_paths(ReferenceManager(D["references"]), shot),
                            "flow_replace_unresolved_images": bool(settings.get("flow_replace_unresolved_images", False)),
                            "flow_image_replacement_limit": _setting_int(settings, "flow_image_replacement_limit", 30),
                            "flow_image_replacement_root": D["root"]}
                    try:
                        from .flow_project_isolation import assert_project_binding
                        assert_project_binding(project_url, browser.current_project_url(),
                                               f"candidate-worker-{wi + 1}")
                        result = provider.generate_image(shot, comp, out, vertical, dry_run=False)
                        if not result.get("path") or not os.path.isfile(result["path"]):
                            raise RuntimeError(result.get("error", "no image returned"))
                        results.append((shot, out, project_url, "flow", "", None))
                    except (FlowAuthNeeded, FlowQuotaExceeded) as error:
                        results.append((shot, "", project_url, "failed", str(error)[:300], error))
                        break
                    except FlowRequestPending as error:
                        if settings.get("flow_pause_on_unresolved_request", False):
                            # Keep the exact request journal and pause only because
                            # the user explicitly chose that recovery policy.
                            results.append((shot, "", project_url, "failed", str(error)[:300], error))
                            break
                        results.append(fallback(shot, out, project_url, error))
                        if results[-1][5] is not None:
                            break
                    except Exception as error:
                        results.append(fallback(shot, out, project_url, error))
                        if results[-1][5] is not None:
                            break
            except (FlowAuthNeeded, FlowQuotaExceeded) as error:
                results.append((batch[0][0], "", "", "failed", str(error)[:300], error))
            except Exception as error:
                # If project/browser bootstrap failed, preserve pending journals;
                # otherwise retain the legacy free-provider fallback for each task.
                for shot, _k, out in batch:
                    result = fallback(shot, out, "", error)
                    results.append(result)
                    if result[5] is not None:
                        break
            finally:
                if provider is not None:
                    try:
                        provider.close()
                    except Exception:
                        pass
                try:
                    from .job_cleanup import trim_worker_cache
                    report = trim_worker_cache(os.path.join(profile_root, f'{m.job_id}-candidate-worker-{wi + 1}'), apply=True)
                    _save_json(os.path.join(D['root'], 'logs', f'worker_cleanup-candidate-{wi + 1}.json'), report)
                except Exception:
                    pass
            return results

        by_shot = {s.shot_id: [] for s in m.shots}
        auth_error = None
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="flow-image") as pool:
            batches = [[] for _ in range(workers)]
            for item in tasks:
                shot, candidate_index, _out = item
                base = int(hashlib.sha256(str(shot.shot_id).encode()).hexdigest()[:8], 16)
                batches[(base + int(candidate_index)) % workers].append(item)
            futures = [pool.submit(run_batch, i, batch) for i, batch in enumerate(batches) if batch]
            done = 0
            for future in as_completed(futures):
                for shot, path, url, source, error, exception in future.result():
                    done += 1
                    if path:
                        by_shot.setdefault(shot.shot_id, []).append(path)
                    self.pm.log(m.job_id, "parallel_scene_image", {
                        "shot": shot.shot_id, "source": source, "path": path,
                        "worker_project_url": url, "error": error})
                    if exception is not None:
                        try:
                            setattr(exception, "project_url", url)
                        except Exception:
                            pass
                        auth_error = (shot, exception)
                    prog(f"🖼️ Parallel images completed {done}/{len(tasks)}", 25 + 4 * done / max(1, len(tasks)))
        if auth_error:
            shot, error = auth_error
            if isinstance(error, FlowRequestPending):
                project_url = getattr(error, "project_url", "")
                if settings.get("flow_pause_on_unresolved_request", False):
                    self._pause_pending_flow(m, shot.shot_id, error, project_url=project_url)
                self._fail_pending_flow(m, shot.shot_id, error, project_url=project_url)
                raise RuntimeError(
                    f"Flow image request for {shot.shot_id} remains unresolved. Automatic pause is off; "
                    "no different image was selected. The saved Flow request remains available for explicit Resume.") from error
            raise AssistedNeeded(m.job_id, shot.shot_id, shot.compiled_prompt,
                                 D["downloads"], f"{type(error).__name__}: {error}")

        # Include already-cached files and update shared state serially.
        for s in m.shots:
            imgdir = os.path.join(D["flow"], "shots", s.shot_id, "images")
            got = sorted(set(by_shot.get(s.shot_id, []) + glob.glob(os.path.join(imgdir, "img_*.jpg")))) if os.path.isdir(imgdir) else []
            scored = [(score_image(p)["overall"], p) for p in got
                      if self._is_valid_image_file(p)]
            scored.sort(reverse=True)
            if scored and scored[0][0] > 0:
                frame = os.path.join(D["storyboard"], f"{s.shot_id}.jpg")
                shutil.copy(scored[0][1], frame)
                refs.add("storyboard", frame, f"{s.shot_id}.jpg")
                s.reference_assets = [p for _, p in scored]
            self.pm.update_shot(m.job_id, s)

    def _providers(self):
        from .providers.flow_browser import FlowBrowserProvider
        from .providers.comfy_provider import ComfyProvider
        from .providers.stock_provider import StockProvider
        from .providers.image_provider import ImageProvider
        from .providers.movieflow_browser import MovieFlowBrowserProvider
        providers = {"flow": FlowBrowserProvider(), "movieflow": MovieFlowBrowserProvider(),
                "comfy": ComfyProvider(), "stock": StockProvider(), "image": ImageProvider()}
        tracked = getattr(self, '_active_job_providers', None)
        if tracked is not None:
            tracked.extend(providers.values())
        return providers

    def _generate_all(self, m, D, refs, router, vertical, dry, prog, settings=None):
        from .providers.flow_browser import (FlowUIChanged, FlowAuthNeeded, FlowQuotaExceeded,
                                                   FlowBrowserClosedError, FlowServiceBusy)
        from .qc.video_qc import analyze_take, RETRY_MODIFIERS
        providers = self._providers()
        movieflow_full = self._movieflow_full_story_enabled(m, settings or {})
        avail = {k: p.status().available for k, p in providers.items()}
        self.pm.log(m.job_id, "provider_status", {k: v for k, v in avail.items()})
        takeroot = os.path.join(D["flow"], "shots")
        max_retries = router.budgets.get("MAX_RETRIES_PER_SHOT", 2)

        pending = [s for s in m.shots if s.status in ("planned", "approved", "generating", "qc", "failed")]
        total = len(m.shots)
        from .providers.gemini_video import selected_shots, GeminiVideoProvider, GeminiVideoPending
        gemini_shots = selected_shots(self.pm.job_dir(m.job_id), m.shots,
                                     int((settings or {}).get('gemini_video_count', 0))) if not dry else []
        if gemini_shots:
            providers['gemini-web'] = GeminiVideoProvider(self.pm.job_dir(m.job_id), progress=prog)
        for s in pending:
            if s.status == "failed" and s.retry_count >= max_retries:
                continue
            s.status = "generating"
            self.pm.update_shot(m.job_id, s)
            try:
                use_prov = 'gemini-web' if s.shot_id in gemini_shots else ProviderRouter(m.profile).plan(s.provider, avail)
            except NeedsDecision as e:
                m = self.pm.load_manifest(m.job_id)
                m.status = "paused"
                self.pm.save_manifest(m)
                raise e
            planned_provider = s.provider
            if use_prov != planned_provider and use_prov != "gemini-web":
                reason = f"planned {planned_provider} unavailable; runtime routed to {use_prov}"
                s.fallback_reason = reason
                prog(f"⚠️ {s.shot_id}: {reason}", 29)
                self.pm.log(m.job_id, "provider_runtime_reroute",
                            {"shot": s.shot_id, "from": planned_provider, "to": use_prov})
            shot_dir = os.path.join(takeroot, s.shot_id)
            os.makedirs(shot_dir, exist_ok=True)
            shot_refs = refs.for_shot(s.shot_id)
            from .cast import photo_paths
            cast_photos = photo_paths(refs, s)
            selected = [p for p in cast_photos if p in refs.get('character')]
            if selected:shot_refs['character']=selected[0]
            # Resolve provider before building provider-specific compiled fields.
            # v5.3.1 referenced current_prov while constructing the MovieFlow
            # story payload, before current_prov had been assigned.
            current_prov = use_prov
            if s.start_frame and os.path.exists(s.start_frame):
                shot_refs["start"] = s.start_frame
            elif s.opening_frame and os.path.exists(s.opening_frame):
                shot_refs["start"] = s.opening_frame
            if s.end_frame and os.path.exists(s.end_frame):
                shot_refs["end"] = s.end_frame
            elif s.closing_frame and os.path.exists(s.closing_frame):
                shot_refs["end"] = s.closing_frame
            if current_prov == "flow":
                video_url = self._flow_video_project_url(m.job_id, settings or {})
                still_url = self._flow_project_url(m.job_id, settings or {})
                if video_url and still_url and video_url == still_url:
                    # v7.0.103: a job that cannot start must not stay "planned" (it looked like it was
                    # still running). Paused + a logged reason is the honest state, and it is recoverable.
                    current = self.pm.load_manifest(m.job_id)
                    current.status = "paused"
                    self.pm.save_manifest(current)
                    try:
                        self.db.upsert(m.job_id, status="paused")
                    except Exception:
                        pass
                    self.pm.log(m.job_id, "flow_project_conflict", {
                        "shot": s.shot_id, "project": video_url,
                        "stills_source": self.flow_project_bindings(m.job_id, settings or {})["stills_source"],
                        "video_source": self.flow_project_bindings(m.job_id, settings or {})["video_source"]})
                    raise RuntimeError(self.flow_project_conflict_message(m.job_id, settings or {}))
            compiled = {"prompt": s.compiled_prompt, "negative": s.negative, "reference_paths": cast_photos,
                        "project": f"AutoVideo-{m.job_id}-video",
                        "project_url": self._flow_video_project_url(m.job_id, settings or {}),
                        "flow_dedicated_video_project": True,
                        "flow_stills_project_url": self._flow_project_url(m.job_id, settings or {}),
                        "flow_video_project_binding_path": os.path.join(
                            self.pm.job_dir(m.job_id), "flow_video_project.json"),
                        "flow_job_id": m.job_id,
                        "approval": (settings or {}).get("flow_approval", "once"),
                        "max_generation_credits": (settings or {}).get("max_generation_credits", 10),
                        "flow_approval_cards": (settings or {}).get("flow_approval_cards", 1),
                        "flow_capacity_wait_seconds": _setting_int(settings, "flow_capacity_wait_seconds", 900),
                        "flow_capacity_retries": _setting_int(settings, "flow_capacity_retries", 8),
                        "flow_video_ready_grace_seconds": _setting_int(settings, "flow_video_ready_grace_seconds", 20),
                        "flow_video_recovery_wait_seconds": _setting_int(settings, "flow_video_recovery_wait_seconds", 180),
                        "flow_video_mode": str((settings or {}).get("flow_video_mode", "frames") or "frames"),
                        "flow_reuse_project_media": bool((settings or {}).get("flow_reuse_project_media", True)),
                        "flow_reuse_mode": str((settings or {}).get("flow_reuse_mode", "exact") or "exact"),
                        "movieflow_project_url": str((settings or {}).get("movieflow_project_url", "") or ""),
                        "movieflow_wait_seconds": int((settings or {}).get("movieflow_wait_seconds", 1800) or 1800),
                        "movieflow_recovery_wait_seconds": int((settings or {}).get("movieflow_recovery_wait_seconds", 300) or 300),
                        "movieflow_story_prompt": s.compiled_prompt if current_prov == "movieflow" else ""}

            takes = []
            n_cand = 1 if dry or use_prov == 'gemini-web' else max(1, s.num_candidates)
            for t in range(n_cand):
                pct = 30 + int(50 * ((total - len([x for x in m.shots if x.status in ('planned','approved','generating','qc','failed')])) / max(1, total)))
                current_prov = use_prov
                prov = providers[current_prov]
                prog(f"🎬 {s.shot_id} take {t+1}/{n_cand} via {current_prov}/{s.model}...", min(82, pct))
                # A QC retry is a new creative request. Never reuse the original
                # file/journal identity with a modified prompt. The same retry
                # keeps its path across browser interruptions and Resume.
                take_name = (f"take_{t+1:02d}" if not s.retry_count else
                             f"take_r{s.retry_count:02d}_{t+1:02d}")
                take_path = os.path.join(shot_dir, take_name + ".mp4")
                fallback_reason = ""
                try:
                    # STORYBOARD_ECONOMY gets one bounded Flow-video retry before
                    # dropping to local image motion. This retry is separate from
                    # still-frame retries and is useful for transient Agent/approval
                    # glitches where the first request never creates usable media.
                    flow_video_retries = max(0, int((settings or {}).get("flow_video_retries", 1) or 0))
                    flow_attempt = 0
                    while True:
                        try:
                            reused_video = None
                            if (current_prov == "flow" and not dry
                                    and bool((settings or {}).get("flow_reuse_project_media", True))):
                                reused_video = self._previous_project_video(
                                    m, compiled.get("project_url", ""), s.shot_id,
                                    str((settings or {}).get("flow_reuse_mode", "exact") or "exact"),
                                    str(compiled.get("flow_video_mode", "frames") or "frames"))
                            if reused_video:
                                shutil.copy2(reused_video, take_path)
                                prog(f"♻️ {s.shot_id}: reused an existing accepted Flow video from this project.", min(82, pct))
                                res = {"path": take_path, "provider": "flow", "model": s.model,
                                       "credits": 0, "project_url": compiled.get("project_url", ""),
                                       "log": "flow project video reuse"}
                            else:
                                res = prov.generate(s, compiled, shot_refs, take_path, vertical, dry_run=dry)
                        except (FlowBrowserClosedError, FlowServiceBusy, FlowUIChanged) as e:
                            from .providers.flow_browser import FlowReferenceUnavailable
                            if isinstance(e, FlowRequestPending):
                                project_url = compiled.get("project_url", "")
                                if (getattr(self, "_automatic_recovery_active", False) or
                                        (settings or {}).get("flow_pause_on_unresolved_request", False)):
                                    self._pause_pending_flow(m, s.shot_id, e, project_url)
                                self._fail_pending_flow(m, s.shot_id, e, project_url)
                                detail = " ".join(str(e).split())[:800]
                                raise FlowRequestFailed(
                                    f"Flow video request for {s.shot_id} remains unresolved. Automatic pause is off; "
                                    "no duplicate video generation was submitted. The saved request remains available for explicit Resume. "
                                    f"Provider recovery detail: {type(e).__name__}: {detail}") from e
                            # The Flow provider owns post-submit recovery. Do not
                            # start another full recovery timer here; v5.3.2 could
                            # stack multiple 179s waits for one shot. A browser-
                            # closed retry gets only an immediate session rebuild.
                            # v7.0.71: retry only when this take never started a Flow
                            # submission. A recorded/unknown submission is recovered, never re-sent.
                            from .flow_submit_guard import may_retry as _flow_may_retry
                            if (current_prov == "flow" and m.profile == "STORYBOARD_ECONOMY"
                                    and flow_attempt < flow_video_retries
                                    and not isinstance(e, FlowReferenceUnavailable)
                                    and _flow_may_retry(take_path)):
                                flow_attempt += 1
                                prog(f"🔁 {s.shot_id}: Flow video attempt failed; retrying once "
                                     f"({flow_attempt}/{flow_video_retries}) before image-motion fallback...", min(82, pct))
                                self.pm.log(m.job_id, "flow_video_retry",
                                            {"shot": s.shot_id, "attempt": flow_attempt + 1,
                                             "error": f"{type(e).__name__}: {str(e)[:220]}"})
                                # Browser-closed errors get an explicit project-URL recovery.
                                if isinstance(e, FlowBrowserClosedError):
                                    try:
                                        providers["flow"].recover_browser(
                                            compiled["project"], project_url=compiled.get("project_url"))
                                    except Exception:
                                        pass
                                time.sleep(2)
                                continue
                            raise

                        if current_prov == "flow":
                            bound = self._remember_flow_video_project_url(
                                m.job_id, res.get("project_url") or providers["flow"].current_project_url())
                            if bound:
                                compiled["project_url"] = bound
                        elif current_prov == "movieflow":
                            bound = self._remember_movieflow_project_url(
                                m.job_id, res.get("project_url") or providers["movieflow"].current_project_url())
                            if bound:
                                compiled["movieflow_project_url"] = bound

                        from .flow_submit_guard import may_retry as _flow_may_retry
                        if (current_prov == "flow" and m.profile == "STORYBOARD_ECONOMY"
                                and not dry and not res.get("path")
                                and flow_attempt < flow_video_retries
                                and _flow_may_retry(take_path)):
                            # Provider.generate() already exhausted exactly one
                            # bounded recovery window. Never add another recovery
                            # wait at the factory layer. The next provider call has
                            # a short retry-guard scan before it can submit again.
                            flow_attempt += 1
                            reason = res.get("error", "Flow returned no usable media")
                            prog(f"🔁 {s.shot_id}: Flow returned no usable video; retrying once "
                                 f"({flow_attempt}/{flow_video_retries}) before image-motion fallback...", min(82, pct))
                            self.pm.log(m.job_id, "flow_video_retry",
                                        {"shot": s.shot_id, "attempt": flow_attempt + 1,
                                         "error": str(reason)[:220]})
                            time.sleep(2)
                            continue
                        break
                except GeminiVideoPending as error:
                    s.status = 'generating'
                    self.pm.update_shot(m.job_id, s)
                    current = self.pm.load_manifest(m.job_id)
                    current.status = 'paused'
                    self.pm.save_manifest(current)
                    self.db.upsert(m.job_id, status='paused')
                    self._write_pause_state(m.job_id, s.shot_id, str(error), kind='gemini_video_pending')
                    raise
                except (FlowUIChanged, FlowAuthNeeded, FlowQuotaExceeded,
                        FlowBrowserClosedError, FlowServiceBusy) as e:
                    # v7.0.104: a stored project that answers "Project not found" is a binding problem, not a
                    # selector problem. Stop with the file to repair instead of falling back to image motion.
                    from .providers.flow_browser import FlowProjectMissing
                    if isinstance(e, FlowProjectMissing):
                        missing_role = "video" if str(take_path).lower().endswith(".mp4") else "stills"
                        self._record_flow_project_missing(m.job_id, e.url, missing_role)
                        message = self.flow_project_missing_message(m.job_id, e.url, missing_role)
                        current = self.pm.load_manifest(m.job_id)
                        current.status = "paused"
                        self.pm.save_manifest(current)
                        self.db.upsert(m.job_id, status="paused")
                        self._write_pause_state(m.job_id, s.shot_id, message, kind="flow_project_missing",
                                                project_url=e.url)
                        raise RuntimeError(message) from e
                    flow_baseline = set(getattr(
                        providers.get("flow"), "_last_video_baseline", set()) or set())
                    if current_prov == "flow":
                        try:
                            bound = self._remember_flow_video_project_url(
                                m.job_id, providers["flow"].current_project_url())
                            if bound:
                                compiled["project_url"] = bound
                        except Exception:
                            pass
                    from .providers.flow_browser import FlowReferenceUnavailable
                    if isinstance(e,FlowReferenceUnavailable) and getattr(s,'character_ids',[]):
                        self._pause_pending_flow(m,s.shot_id,e,compiled.get('project_url',''))
                    if (m.profile == "STORYBOARD_ECONOMY" and avail.get("image")
                            and (settings or {}).get("flow_pause_on_unresolved_request", False)):
                        self._pause_pending_flow(m, s.shot_id, e, compiled.get("project_url", ""))
                    if m.profile == "STORYBOARD_ECONOMY" and avail.get("image"):
                        fallback_reason = f"Flow generation failure after retry: {str(e)[:180]}"
                        prog(f"⚠️ {s.shot_id}: Flow unavailable after retry -> image-motion fallback", min(82, pct))
                        self.pm.log(m.job_id, "flow_motion_fallback",
                                    {"shot": s.shot_id, "error": str(e)[:220], "fallback": "image_motion"})
                        current_prov = "image"
                        res = providers["image"].generate(s, compiled, shot_refs, take_path, vertical, dry_run=dry)
                    elif isinstance(e, FlowAuthNeeded):
                        s.status = "failed"
                        self.pm.update_shot(m.job_id, s)
                        m2 = self.pm.load_manifest(m.job_id)
                        m2.status = "assisted"
                        self.pm.save_manifest(m2)
                        self.db.upsert(m.job_id, status="assisted")
                        self._write_pause_state(
                            m.job_id, s.shot_id, f"{type(e).__name__}: {e}",
                            kind="flow_login", project_url=compiled.get("project_url", ""),
                            baseline_signatures=flow_baseline)
                        raise AssistedNeeded(m.job_id, s.shot_id, s.compiled_prompt,
                                             D["downloads"], f"{type(e).__name__}: {e}")
                    else:
                        project_url = compiled.get("project_url", "")
                        if (settings or {}).get("flow_pause_on_unresolved_request", False):
                            s.status = "failed"
                            self.pm.update_shot(m.job_id, s)
                            m2 = self.pm.load_manifest(m.job_id)
                            m2.status = "paused"
                            self.pm.save_manifest(m2)
                            self.db.upsert(m.job_id, status="paused")
                            if isinstance(e, FlowQuotaExceeded):
                                kind = "flow_usage_limit"
                            elif isinstance(e, FlowServiceBusy):
                                kind = "flow_capacity"
                            else:
                                kind = "flow_download_or_ui"
                            state = self._write_pause_state(
                                m.job_id, s.shot_id, f"{type(e).__name__}: {e}",
                                kind=kind, project_url=project_url,
                                baseline_signatures=flow_baseline)
                            next_step = (
                                "Scan for media newer than the saved pre-generation baseline before any retry."
                                if state.get("safe_automatic_recovery") else
                                "Wait for Flow access to reset, then resume this same saved job."
                            )
                            raise NeedsDecision(
                                f"Flow paused at {s.shot_id} by your setting. Existing generated media and "
                                f"{state['accepted_shots']}/{state['total_shots']} accepted shots are safe. "
                                f"{next_step} Reason: {type(e).__name__}: {e}",
                                alternatives=[x["command"] for x in state["actions"]])
                        self._fail_pending_flow(m, s.shot_id, e, project_url)
                        raise FlowRequestFailed(
                            f"Flow failed at {s.shot_id}. Automatic pause is off; no replacement video request was submitted. "
                            "The saved job remains available for explicit Resume. "
                            f"Reason: {type(e).__name__}: {e}") from e

                # A provider can report a download/detection failure as a normal
                # result after Flow has already spent the credits. Never silently
                # submit another video. Pause only when the user opted in; otherwise
                # fail cleanly and leave explicit Resume available for recovery.
                if (not dry and current_prov == "flow" and not res.get("path")
                        and m.profile != "STORYBOARD_ECONOMY"):
                    reason = str(res.get("error") or "Flow media was generated but no valid video was downloaded")
                    if (settings or {}).get("flow_pause_on_unresolved_request", False):
                        s.status = "failed"
                        self.pm.update_shot(m.job_id, s)
                        m2 = self.pm.load_manifest(m.job_id)
                        m2.status = "paused"
                        self.pm.save_manifest(m2)
                        self.db.upsert(m.job_id, status="paused")
                        state = self._write_pause_state(
                            m.job_id, s.shot_id, reason, kind="flow_existing_video_recovery",
                            project_url=compiled.get("project_url", ""),
                            baseline_signatures=set(getattr(
                                providers.get("flow"), "_last_video_baseline", set()) or set()))
                        raise NeedsDecision(
                            f"Flow may already contain the finished video for {s.shot_id}; the job was paused by your setting "
                            f"before any retry could spend more credits. {reason}",
                            alternatives=[x["command"] for x in state["actions"]])
                    self._fail_pending_flow(m, s.shot_id, RuntimeError(reason), compiled.get("project_url", ""))
                    raise FlowRequestFailed(
                        f"Flow may have generated the video for {s.shot_id}, but no valid download was saved. "
                        "Automatic pause is off; no duplicate generation was submitted. Explicitly Resume this saved job to retry recovery. "
                        + reason)
                if not dry and not res.get("path") and current_prov == "movieflow" and movieflow_full:
                    s.status = "failed"
                    self.pm.update_shot(m.job_id, s)
                    m2 = self.pm.load_manifest(m.job_id)
                    m2.status = "paused"
                    self.pm.save_manifest(m2)
                    self.db.upsert(m.job_id, status="paused")
                    raise NeedsDecision(
                        "MovieFlow full-story generation did not produce a valid downloadable video. "
                        + str(res.get("error", "Open MovieFlow Studio and inspect the project, then resume."))[:700],
                        alternatives=[f"Run: python3 cli.py v3 resume {m.job_id}",
                                      "Run: python3 cli.py v3 movieflow-open --project-url <project-url>",
                                      "Use --cartoon-provider flow for the Google Flow cartoon preset"]
                    )
                if not dry and not res.get("path") and m.profile == "STORYBOARD_ECONOMY" and current_prov != "image" and avail.get("image"):
                    fallback_reason = res.get("error", "provider returned no media")
                    prog(f"⚠️ {s.shot_id}: {current_prov} returned no usable media -> image-motion fallback", min(82, pct))
                    self.pm.log(m.job_id, "economy_provider_fallback",
                                {"shot": s.shot_id, "from": current_prov,
                                 "error": fallback_reason, "to": "image_motion"})
                    current_prov = "image"
                    res = providers["image"].generate(s, compiled, shot_refs, take_path, vertical, dry_run=False)
                if dry or not res.get("path"):
                    takes.append({"take": take_name, "dry": True,
                                  "provider": current_prov, "model": res.get("model", s.model),
                                  "credits": res.get("credits", 0) or 0,
                                  "fallback_reason": fallback_reason,
                                  "log": res.get("log", ""), "error": res.get("error", "")})
                    continue
                qc = analyze_take(res["path"],
                                  [shot_refs.get("storyboard"), shot_refs.get("start"), shot_refs.get("character")],
                                  expect_seconds=s.gen_duration, expect_vertical=vertical)
                if (current_prov == 'stock' and str(qc.get('decision','')).upper() == 'REJECT'
                        and avail.get('image') and any(self._is_valid_image_file(path)
                            for path in shot_refs.values() if isinstance(path, str) and path)):
                    shutil.copy2(res['path'], take_path + '.stock-rejected.mp4')
                    _save_json(take_path + '.stock-rejected.qc.json', qc)
                    fallback_reason = 'stock QC rejected; local reviewed storyboard motion: ' + str(qc.get('failure',''))
                    prog(f'⚠️ {s.shot_id}: stock QC rejected; checking saved-storyboard motion instead', min(82, pct))
                    res = providers['image'].generate(s, compiled, shot_refs, take_path, vertical, dry_run=False)
                    current_prov = 'image'
                    qc = analyze_take(res['path'], [shot_refs.get('storyboard'), shot_refs.get('start'), shot_refs.get('character')],
                                      expect_seconds=s.gen_duration, expect_vertical=vertical)
                    self.pm.log(m.job_id, 'stock_qc_storyboard_repair', {'shot': s.shot_id, 'qc': qc, 'new_flow_credits': 0})
                _save_json(os.path.join(D["qc"], f"{s.shot_id}_{take_name}.json"), qc)
                takes.append({"take": take_name, "path": res["path"],
                              "provider": current_prov, "model": res.get("model", s.model),
                              "credits": res.get("credits", 0) or 0,
                              "fallback_reason": fallback_reason,
                              "overall": qc["overall"], "decision": qc["decision"],
                              "failure": qc["failure"]})
                self.pm.log(m.job_id, "take_qc", {"shot": s.shot_id, "take": take_name, "qc_retry": s.retry_count,
                                                  "provider": current_prov,
                                                  "overall": qc["overall"], "decision": qc["decision"]})
                self.db.bump(m.job_id, "actual_generations")

            if dry:
                s.takes = [x["take"] for x in takes]
                s.status = "planned"
                self.pm.update_shot(m.job_id, s)
                continue

            # pick best; retry failures with targeted modifier
            takes.sort(key=lambda x: x.get("overall", 0), reverse=True)
            best = takes[0] if takes else None
            if best and best.get("decision") in ("ACCEPT", "REVIEW") and best.get("overall", 0) >= s.qc_threshold - 10:
                shutil.copy(best["path"], os.path.join(shot_dir, "accepted.mp4"))
                # Stock provenance must survive acceptance so re-encoded copies
                # of the same downloaded asset cannot evade repetition checks.
                from .render.coverage import copy_source_provenance
                copy_source_provenance(best["path"], os.path.join(shot_dir, "accepted.mp4"))
                s.accepted_take = os.path.join(shot_dir, "accepted.mp4")
                s.takes = [x["take"] for x in takes]
                s.status = "accepted"
                s.actual_provider = best.get("provider", use_prov)
                s.actual_model = best.get("model", s.model)
                if best.get("fallback_reason"):
                    s.fallback_reason = best.get("fallback_reason", "")
                actual_credits = best.get("credits", 0)
                if actual_credits in (-1, None) and s.actual_provider == "flow":
                    actual_credits = router.model_cost(s.model, s.gen_duration)
                try:
                    s.credits_spent = int(round(float(actual_credits or 0)))
                except Exception:
                    s.credits_spent = 0
                self.db.bump(m.job_id, "accepted_shots")
                # continuity: end frame for next shot
                try:
                    refs.best_end_frame(s.accepted_take, os.path.join(D["references"], f"{s.shot_id}_end.jpg"))
                    nxt = next((x for x in m.shots if x.start_frame == f"{{prev_end_frame:{s.shot_id}}}"), None)
                    if nxt is not None:
                        nxt.start_frame = os.path.join(D["references"], f"{s.shot_id}_end.jpg")
                        self.pm.update_shot(m.job_id, nxt)
                except Exception as e:
                    self.pm.log(m.job_id, "endframe_failed", {"shot": s.shot_id, "error": str(e)[:150]})
            else:
                fail = (best or {}).get("failure", "generic")
                if s.retry_count < max_retries:
                    mod = RETRY_MODIFIERS.get(fail, RETRY_MODIFIERS["generic"])
                    s.compiled_prompt = s.compiled_prompt + f" Retry fix ({fail}): {mod}."
                    s.retry_history.append(f"{fail}: {mod}")
                    s.retry_count += 1
                    s.status = "failed"  # resume will retry
                    self.db.bump(m.job_id, "retry_count")
                    self.db.bump(m.job_id, "rejected_shots")
                    self.pm.log(m.job_id, "shot_retry", {"shot": s.shot_id, "failure": fail})
                else:
                    # Retain evidence, but exhausted retries never turn a rejected
                    # take into accepted coverage.
                    if best and best.get("path"):
                        shutil.copy(best["path"], os.path.join(shot_dir, "best_rejected.mp4"))
                    s.accepted_take = None
                    s.status = "failed"
                    self.pm.log(m.job_id, "shot_qc_exhausted", {"shot": s.shot_id, "failure": fail})
            self.pm.update_shot(m.job_id, s)

        # close browser provider
        try:
            providers["flow"].close()
        except Exception:
            pass
        m = self.pm.load_manifest(m.job_id)
        if not dry:
            # retry loop exhausted? mark review if failures remain
            failed = [s for s in m.shots if s.status == "failed"]
            if failed and all(s.retry_count >= max_retries for s in failed):
                pass  # best-effort already applied
            elif failed:
                return self._generate_all(m, D, refs, router, vertical, dry, prog, settings)  # next retry pass
        self.pm.save_manifest(m)

    def storyboard_repair_frames(self, job_id: str, shot_id: str):
        shot = next(s for s in self.pm.load_manifest(job_id).shots if s.shot_id == shot_id)
        saved = os.path.join(self.pm.dirs(job_id)['storyboard'], f'{shot_id}.jpg')
        start = next((p for p in [shot.opening_frame, shot.start_frame, saved, *shot.reference_assets]
                      if p and self._is_valid_image_file(p)), None)
        end = next((p for p in [shot.closing_frame, shot.end_frame]
                    if p and self._is_valid_image_file(p)), None)
        return start, end

    def repair_storyboard_shot(self, job_id: str, shot_id: str, reviewed: bool = False) -> dict:
        if reviewed is not True:
            raise ValueError('Review the saved opening and closing frames for this shot first')
        from .providers.image_provider import ImageProvider
        m = self.pm.load_manifest(job_id)
        shot = next((s for s in m.shots if s.shot_id == shot_id), None)
        if shot is None or shot.accepted_take:
            raise ValueError('Select an unaccepted shot; accepted takes are preserved')
        start, end = self.storyboard_repair_frames(job_id, shot_id)
        if not start or not os.path.isfile(start):
            raise ValueError('No saved opening frame exists; no generation was submitted')
        D = self.pm.dirs(job_id)
        os.makedirs(D['downloads'], exist_ok=True)
        out = os.path.join(D['downloads'], f'{shot_id}_storyboard_repair_{time.time_ns()}.mp4')
        result = ImageProvider().generate(shot, {'prompt': shot.compiled_prompt},
            {'start': start, 'end': end}, out, vertical=m.aspect == '9:16', dry_run=False)
        associated = self.associate_download(job_id, shot_id, result['path'])
        if associated['qc']['decision'] in ('ACCEPT','REVIEW'):
            current = self.pm.load_manifest(job_id)
            repaired = next(s for s in current.shots if s.shot_id == shot_id)
            repaired.actual_provider = 'image'
            repaired.actual_model = 'image_pair_motion'
            repaired.fallback_reason = 'User reviewed saved storyboard frames; local motion repair passed QC'
            self.pm.update_shot(job_id, repaired)
        associated['new_credits'] = 0
        return associated

    # ---------------- assisted association ----------------
    def associate_download(self, job_id: str, shot_id: str, src_file: str) -> dict:
        """Assisted mode: map a user-downloaded Flow clip to a shot, QC it, continue."""
        from .qc.video_qc import analyze_take
        m = self.pm.load_manifest(job_id)
        D = self.pm.dirs(job_id)
        s = next(x for x in m.shots if x.shot_id == shot_id)
        vertical = m.aspect == "9:16"
        shot_dir = os.path.join(D["flow"], "shots", shot_id)
        os.makedirs(shot_dir, exist_ok=True)
        n = len([f for f in os.listdir(shot_dir) if f.startswith("take_")]) + 1
        dst = os.path.join(shot_dir, f"take_{n:02d}.mp4")
        shutil.copy(src_file, dst)
        from .render.coverage import copy_source_provenance
        copy_source_provenance(src_file, dst)
        refs = ReferenceManager(D["references"]).for_shot(shot_id)
        qc = analyze_take(dst, [refs.get("storyboard"), refs.get("start")],
                          expect_seconds=s.gen_duration, expect_vertical=vertical)
        _save_json(os.path.join(D["qc"], f"{shot_id}_take_{n:02d}.json"), qc)
        if qc["decision"] in ("ACCEPT", "REVIEW"):
            shutil.copy(dst, os.path.join(shot_dir, "accepted.mp4"))
            from .render.coverage import copy_source_provenance
            copy_source_provenance(dst, os.path.join(shot_dir, "accepted.mp4"))
            s.accepted_take = os.path.join(shot_dir, "accepted.mp4")
            s.status = "accepted"
            self.db.bump(job_id, "accepted_shots")
        else:
            s.status = "failed"
            self.db.bump(job_id, "rejected_shots")
        s.takes = s.takes + [f"take_{n:02d}"]
        self.pm.update_shot(job_id, s)
        return {"qc": qc, "take": dst}

    def approve_flow_request(self, job_id: str, shot_id: str | None = None,
                             confirm_credits: int | None = None,
                             wait_seconds: int = 180, inspect_only: bool = False) -> dict:
        """Approve ONCE the Flow card a saved video request is still waiting on (v7.0.99).

        A submitted Flow *video* request is confirmed by a click, not by a wait: until the card is approved
        no video exists, so download-only recovery can only pause again. This names the exact saved request,
        requires the credit cost to be stated up front, and clicks ``Approve`` once - never ``Always
        approve``. ``inspect_only`` opens the project, reads the card and clicks nothing.
        """
        from .flow_pending_approval import approval_decision, evidence_for
        from .job_ref import job_lookup_error

        try:
            m = self.pm.load_manifest(job_id)
        except (OSError, ValueError) as error:
            raise ValueError(job_lookup_error(job_id, getattr(self.pm, "root", "outputs"),
                                              f"The saved production could not be read "
                                              f"({type(error).__name__}); nothing was opened or clicked."))
        unfinished = [s for s in m.shots if not s.accepted_take]
        if shot_id:
            shot = next((s for s in m.shots if s.shot_id == shot_id), None)
            if shot is None:
                raise ValueError(f"Unknown shot {shot_id!r} in job {job_id}")
            if shot.accepted_take:
                return {"job_id": job_id, "shot_id": shot_id, "status": "already_accepted",
                        "message": (f"{shot_id} already has an accepted take; nothing was approved or downloaded.")}
        elif unfinished:
            shot = unfinished[0]
        else:
            return {"job_id": job_id, "status": "all_shots_accepted",
                    "message": "All shots are already accepted; nothing was approved or downloaded."}

        D = self.pm.dirs(job_id)
        journals = sorted(glob.glob(os.path.join(D['flow'], 'shots', shot.shot_id, 'take_*.mp4.flow-request.json')))
        if not journals:
            raise RuntimeError(f"{shot.shot_id} has no saved Flow video request, so there is no card to approve. "
                               "Nothing was clicked or submitted.")
        if len(journals) > 1:
            raise ValueError('Multiple request journals exist for this shot; export support diagnostics before '
                             'approving anything. Nothing was clicked.')
        journal = journals[0]
        approval = evidence_for(journal)
        if approval.get('approved'):
            return {"job_id": job_id, "shot_id": shot.shot_id, "status": "already_approved",
                    "approved": True,
                    "message": ("An approval click is already recorded for this request; no second click was made. "
                                "Run `python3 cli.py v3 recover-flow-video "
                                f"{job_id} --shot-id {shot.shot_id} --wait-seconds 180` (0 credits) to download it.")}

        if inspect_only:
            from .providers.flow_browser import FlowBrowser, FlowBrowserProvider
            with open(journal, encoding="utf-8") as handle:
                saved_project = FlowBrowser.normalize_project_url(
                    (json.load(handle) or {}).get("project_url"))
            if not saved_project:
                raise ValueError('The saved video request has no Flow project URL; nothing was opened or clicked.')
            provider = FlowBrowserProvider()
            try:
                probe = provider.inspect_recorded_approval(
                    f'AutoVideo-{job_id}', journal, project_url=saved_project)
            finally:
                try:
                    provider.close()
                except Exception:
                    pass
            allowed, reason = approval_decision(probe, confirm_credits)
            self.pm.log(job_id, "flow_approval_inspected", {
                "shot": shot.shot_id, "visible": bool(probe.get("visible")),
                "cost": probe.get("cost"), "would_click": bool(allowed)})
            return {"job_id": job_id, "shot_id": shot.shot_id, "status": "inspect",
                    "card": probe, "would_click": bool(allowed), "reason": reason,
                    "project_url": saved_project, "new_credits": 0}
        return self.recover_flow_video(job_id, shot_id=shot.shot_id, wait_seconds=wait_seconds,
                                       approve_credits=confirm_credits)

    def recover_flow_video(self, job_id: str, shot_id: str | None = None,
                           wait_seconds: int = 120,
                           allow_latest: bool = False, asset_url: str = '',
                           asset_reviewed: bool = False,
                           approve_credits: int | None = None,
                           auto_approve: bool = False) -> dict:
        """Download an already-generated video from the bound Flow project.

        This recovery path never fills/submits a prompt and therefore cannot
        initiate a new credit-bearing generation. It is safe to run while the
        account is usage-limited, provided the existing project remains readable.

        v7.0.99: ``approve_credits`` approves the ONE card Flow is waiting on for this saved video request
        (a card that was never clicked means no video exists, so no wait can find one). The click happens
        first, is limited to the stated cost, and the download that follows is free.

        v7.0.106: ``auto_approve`` reads that card and clicks Approve once when its cost is readable and
        within this job's per-take cap - the same rule ``cli.py v3 resume`` applies, so each Flow video is
        approved once without a human and a duplicate card is never clicked.
        """
        from .providers.flow_browser import FlowBrowserProvider
        from .job_ref import job_lookup_error

        try:
            m = self.pm.load_manifest(job_id)
        except (OSError, ValueError) as error:
            raise ValueError(job_lookup_error(job_id, getattr(self.pm, "root", "outputs"),
                                              f"The saved production could not be read "
                                              f"({type(error).__name__}); nothing was opened or downloaded."))
        candidates = [s for s in m.shots
                      if not s.accepted_take and s.status in
                      ("failed", "generating", "planned", "approved", "qc")]
        if shot_id:
            shot = next((s for s in m.shots if s.shot_id == shot_id), None)
            if shot is None:
                raise ValueError(f"Unknown shot {shot_id!r} in job {job_id}")
            if shot.accepted_take:
                return {
                    "job_id": job_id, "shot_id": shot_id,
                    "status": "already_accepted", "accepted": True,
                    "take": shot.accepted_take, "new_credits": 0,
                    "message": (f"{shot_id} already has an accepted take. Nothing was replaced and "
                                f"no Flow generation/download was started; resume or render the job."),
                }
        elif candidates:
            shot = candidates[0]
        else:
            return {
                "job_id": job_id, "status": "all_shots_accepted",
                "accepted": True, "new_credits": 0,
                "message": "All shots are already accepted; run resume or render. No Flow action was started.",
            }

        project_url = self._flow_project_url(job_id)
        pause = self.pause_state(job_id)
        baseline = {str(x) for x in (pause.get("baseline_signatures") or []) if str(x)}
        D = self.pm.dirs(job_id)
        journals = sorted(glob.glob(os.path.join(D['flow'], 'shots', shot.shot_id, 'take_*.mp4.flow-request.json')))
        if len(journals) > 1:
            raise ValueError('Multiple request journals exist for this shot; export support diagnostics before selecting a take')
        journal = journals[0] if journals else None
        if journal:
            # Shot journals own their exact projects. The job-level pointer can
            # name a later reference/worker project and must never override it.
            from .providers.flow_browser import FlowBrowser
            with open(journal, encoding="utf-8") as handle:
                saved_request = json.load(handle)
            saved_project = FlowBrowser.normalize_project_url(saved_request.get("project_url"))
            if saved_request.get("kind") != "video" or not saved_project:
                raise ValueError("Selected shot journal lacks a valid video project; no browser action started")
            project_url = saved_project
        if not project_url:
            raise ValueError("No saved project is available for this shot; no browser action started")
        if asset_url and (asset_reviewed is not True or not journal):
            raise ValueError('Review this exact editor video for the selected shot first; a saved video request is required')
        if asset_url:
            from urllib.parse import urlsplit
            from .providers.flow_browser import FlowBrowser
            u = urlsplit(asset_url)
            if (u.scheme != 'https' or u.hostname not in ('flow.google.com', 'labs.google')
                    or u.username or u.password or u.query or u.fragment or u.port not in (None, 443)
                    or not re.fullmatch(r'/project/[A-Za-z0-9_-]+/edit/[A-Za-z0-9_-]+', u.path)
                    or FlowBrowser.normalize_project_url(asset_url) != FlowBrowser.normalize_project_url(project_url)):
                raise ValueError('Editor video URL must belong to this job’s saved Flow project')
        if not journal and not baseline and not allow_latest:
            raise RuntimeError(
                "This paused job has no saved pre-generation media baseline, so selecting the newest "
                "tile automatically could duplicate an earlier accepted shot. Wait for Flow access to "
                "reset and resume the same job, manually associate the confirmed MP4, or rerun this "
                "command with --allow-latest only after visually confirming the newest tile belongs to "
                f"{shot.shot_id}.")

        os.makedirs(D["downloads"], exist_ok=True)
        recovered = os.path.join(D["downloads"], f"recovered_{shot.shot_id}.mp4")
        provider = FlowBrowserProvider()
        approved = None
        try:
            if approve_credits is not None:
                if not journal:
                    raise RuntimeError(
                        f"{shot.shot_id} has no saved Flow video request, so there is no card to approve. "
                        "Nothing was clicked or submitted.")
                if asset_url:
                    raise ValueError("Approve and download a reviewed URL are separate actions; "
                                     "run them one at a time. Nothing was clicked.")
                print(f"[Flow] Approving the saved card for {shot.shot_id} once "
                      f"({int(approve_credits)} credits explicitly confirmed) in {project_url}...")
                approved = provider.approve_recorded_card(
                    f'AutoVideo-{job_id}', journal, project_url=project_url,
                    confirm_credits=int(approve_credits))
                print(f"[Flow] Card approved ({approved.get('cost')} credits). Waiting for the video; "
                      "the download itself is free.")
            elif auto_approve and journal:
                from .flow_approval_once import approve_saved_video_request
                approval = approve_saved_video_request(provider, journal, settings=self._settings(job_id),
                                                       project=f'AutoVideo-{job_id}')
                print(f"[Flow] Approval check for {shot.shot_id}: {approval.get('reason')}")
                if approval.get('clicked'):
                    approved = {'cost': approval.get('cost'), 'clicked': True}
                    self.pm.log(job_id, 'flow_auto_approval',
                                {'shot': shot.shot_id, 'cost': approval.get('cost'),
                                 'journal': os.path.basename(str(journal)), 'clicks': approval.get('clicks')})
            else:
                print(f"[Flow] Recovery-only mode: checking {shot.shot_id} in {project_url}; "
                      "no generation will be submitted and no new credits will be requested.")
            if journal:
                result = provider.recover_recorded_video(f'AutoVideo-{job_id}', recovered, journal,
                    project_url=project_url, wait_s=max(0, int(wait_seconds)), asset_url=asset_url)
            else:
                result = provider.rescue_recent_project_video(
                    f"AutoVideo-{job_id}", recovered, project_url=project_url,
                    max_candidates=12, wait_s=max(5, int(wait_seconds or 0)),
                    baseline_signatures=baseline)
            if not result or not result.get("path"):
                raise RuntimeError(
                    f"No downloadable video tile became available in {int(wait_seconds)}s. "
                    "The project is unchanged and nothing was submitted (waiting costs no credits). "
                    "A chat turn that says the generation is queued because of high demand is a snapshot from "
                    "when it was submitted and can stay in the chat after the clip is finished, so do not read it "
                    "as the current state: check the project's media grid for the newest video. If that video is "
                    "there but automatic matching cannot prove it is this shot, download exactly it with "
                    "`--asset-url https://flow.google.com/project/<project>/edit/<id> --asset-reviewed`. "
                    "Otherwise run this recovery again later.")
            # v7.0.103: this is a VIDEO download, so bind the video role only. Writing it into the stills
            # binding made the next production fail with "storyboard and video project are the same".
            bound = self._remember_flow_video_project_url(
                job_id, result.get("project_url") or provider.current_project_url())
            associated = self.associate_download(job_id, shot.shot_id, result["path"])
            qc = associated.get("qc", {})
            accepted = str(qc.get("decision", "")).upper() in ("ACCEPT", "REVIEW")
            if journal and accepted:
                # Commit only validated, QC-accepted recovery to the canonical
                # request output so Resume no longer chases the stale signature.
                canonical = journal[:-len(".flow-request.json")]
                shutil.copy2(result["path"], canonical)
                with open(journal, encoding="utf-8") as handle:
                    completed = json.load(handle)
                completed.update(status="downloaded", recovery_qc=qc,
                    media_sha256=__import__("hashlib").sha256(__import__("pathlib").Path(canonical).read_bytes()).hexdigest())
                _save_json(journal, completed)
            refreshed = self.pm.load_manifest(job_id)
            refreshed.status = "planned" if accepted else "paused"
            self.pm.save_manifest(refreshed)
            self.db.upsert(job_id, status=refreshed.status,
                           flow_project=bound or project_url)
            pause.update({
                "recovery_completed_at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
                "recovered_shot": shot.shot_id,
                "recovered_file": associated.get("take"),
                "recovery_qc": qc,
                "resolved": accepted,
            })
            _save_json(os.path.join(self.pm.job_dir(job_id), "pause_state.json"), pause)
            self.pm.log(job_id, "flow_existing_video_recovered", {
                "shot": shot.shot_id, "project_url": bound or project_url,
                "take": associated.get("take"), "qc": qc, "new_credits": 0,
                "approved_credits": (approved or {}).get("cost")})
            return {"job_id": job_id, "shot_id": shot.shot_id,
                    "project_url": bound or project_url, "new_credits": 0,
                    "approved_credits": (approved or {}).get("cost"),
                    "accepted": accepted, **associated}
        except Exception as error:
            from .providers.flow_browser import FlowProjectMissing
            if isinstance(error, FlowProjectMissing):
                self._record_flow_project_missing(job_id, error.url, "video")
                raise RuntimeError(self.flow_project_missing_message(job_id, error.url, "video")) from error
            raise
        finally:
            try:
                provider.close()
            except Exception:
                pass

    # ---------------- render ----------------
    def render_job(self, job_id: str, quality: str = "high", progress_cb=None) -> dict:
        from .render.timeline import build_timeline
        from .render.captions_ass import build_captions
        from .render.ffmpeg_renderer import render_ffmpeg
        from .audio.sound_design import plan_sfx, pick_music, pick_ambience
        from moviepy.editor import AudioFileClip

        from .progress import JobProgress
        progress = JobProgress(self.pm.job_dir(job_id), progress_cb)
        def prog(stage, pct, info=""):
            try:
                progress.emit(stage, pct, info)
            except Exception:
                pass

        m = self.pm.load_manifest(job_id)
        D = self.pm.dirs(job_id)
        settings = self._settings(job_id)
        preset = load_preset(m.preset)
        render_started = time.monotonic()
        prog("🎞️ Building timeline...", 85)
        presentation = resolve_presentation(settings)
        m.voiceover_enabled = presentation.voiceover
        voice_path = os.path.join(D["narration"], "voice.mp3")
        voice = voice_path if presentation.voiceover else None
        if voice:
            if not os.path.isfile(voice):
                raise RuntimeError("Voiceover is enabled but no narration exists. Run Resume to prepare it, or disable voiceover for a music-only/silent edit.")
            c = AudioFileClip(voice)
            ndur = c.duration
            c.close()
        else:
            ndur = visual_duration(m)
        tl = build_timeline(m, os.path.join(D["flow"], "shots"), ndur, hard_cuts=True)
        from .production import apply_overrides, save as save_review
        tl = apply_overrides(D["root"], tl)
        repaired = {s["shot_id"] for s in tl["segments"] if s.get("local_repair")}
        _save_json(os.path.join(D["render"], "timeline.json"), tl)
        from .render.coverage import audit_coverage
        coverage = audit_coverage(tl["segments"], ndur)
        # A rejected take must not be silently used even if a file exists.
        for shot in m.shots:
            if shot.status != "accepted" and shot.shot_id not in repaired:
                coverage["issues"].append(f"{shot.shot_id}: shot is not accepted")
        coverage["passed"] = not coverage["issues"]
        _save_json(os.path.join(D["render"], "coverage_qc.json"), coverage)
        if not coverage["passed"]:
            prog("⛔ Coverage QC stopped render before encoding", 85,
                 "See render/coverage_qc.json; replace the listed media or create a corrected plan. Existing job and Flow project are preserved.")
            raise RuntimeError("Coverage QC: " + "; ".join(coverage["issues"]) +
                               ". No new generation submitted. See render/coverage_qc.json.")
        from .broll import prepare_saved_production_broll
        prepare_saved_production_broll(self,job_id,settings,prog)
        broll_review_path = os.path.join(D["render"], "broll_review.json")
        video_cutaways = []
        if os.path.isfile(broll_review_path):
            from .broll import approved_video_overlays, validate_review_decisions, protected_video_intervals
            validate_review_decisions(broll_review_path, workflow="production")
            video_cutaways = approved_video_overlays(broll_review_path, float(tl.get("total", ndur)),
                protected=protected_video_intervals(m, tl))
            prog("B-roll placement checked", 88, f"{len(video_cutaways)} safe cutaways; AI video shots protected. See render/broll_placement_report.json for skipped inserts.")
        words_p = voice_path + ".words.json"
        words = json.load(open(words_p, encoding="utf-8")) if voice and os.path.exists(words_p) else []
        # v7.0.73: estimated caption timings drift against speech in pauses (the 2-3 s lag).
        # Say so in the readiness warnings instead of presenting them as measured.
        caption_timing_estimated = False
        caption_timing_engine = ""
        try:
            _cmeta = json.load(open(voice_path + ".words.meta.json", encoding="utf-8")) if voice else {}
            caption_timing_engine = str((_cmeta or {}).get("engine") or (_cmeta or {}).get("timing_source") or "")
        except Exception:
            caption_timing_engine = ""
        caption_timing_estimated = bool(words) and any(
            token in caption_timing_engine.lower() for token in ("script", "estimated"))
        script_text = ""
        script_data = {}
        try:
            script_data = json.load(open(os.path.join(D["root"], "script.json"), encoding="utf-8"))
            script_text = str(script_data.get("narration", "") or "")
        except Exception:
            script_text = ""
        if presentation.voiceover:
            if not words:
                from .captions import get_word_timestamps
                words = get_word_timestamps(
                    voice,
                    model_size=str(settings.get("caption_local_model", "small") or "small"),
                    provider=str(settings.get("caption_provider", "auto") or "auto"),
                    script_text=script_text, language=m.language,
                    groq_model=str(settings.get("caption_model", "whisper-large-v3-turbo") or "whisper-large-v3-turbo"),
                    align_script=bool(settings.get("caption_align_script", True)),
                ) or []
            elif script_text and bool(settings.get("caption_align_script", True)):
                from .captions import align_words_to_script
                words = align_words_to_script(script_text, words, ndur)
            cap = build_captions(words, os.path.join(D["captions"], "captions"),
                                 template=(settings.get("caption_template") if settings.get("caption_template", "auto") != "auto"
                                           else ("OPUS" if m.aspect == "9:16" else preset.get("caption_style", "HORMOZI"))),
                                 aspect=m.aspect, W=m.width, H=m.height, duration=ndur)
        else:
            cap = {"ass": None, "srt": None, "events": 0, "warnings": [],
                   "disabled": True, "reason": "voiceover_disabled"}
        if cap.get("warnings"):
            self.pm.log(job_id, "caption_timing_warning", {"warnings": cap["warnings"]})
            prog("⚠️ Caption timing needs review", 87, "; ".join(cap["warnings"]))

        pro_mode = str(settings.get("production_mode", "legacy") or "legacy").lower() == "youtube_pro"
        caption_display = presentation.captions
        burn_ass = cap["ass"] if caption_display == "full" else None

        # v5.6 graphics replace the dead-end permanent transcript in YouTube
        # production mode. Full SRT/ASS files are still generated for YouTube CC.
        overlays = []
        graphics_enabled = presentation.text_cards
        if graphics_enabled or bool(settings.get("watermark", False)):
            try:
                from .render.graphics import build_overlay_assets
                overlays = build_overlay_assets(
                    m, script_data, os.path.join(D["render"], "graphics"),
                    channel_name=str(settings.get("channel_name", "") or ""),
                    logo_path=str(settings.get("channel_logo", "") or ""),
                    show_watermark=bool(settings.get("watermark", False)),
                    logo_size=str(settings.get("channel_logo_size", "Small")),
                    actual_duration=ndur, text_cards_enabled=graphics_enabled,
                    style=presentation.card_style
                )
                _save_json(os.path.join(D["root"], "graphics_plan.json"), overlays)
            except Exception as ge:
                overlays = []
                self.pm.log(job_id, "graphics_overlay_failed", {"error": str(ge)[:300]})

        from .render.structured_graphics import build_structured_overlays
        from .render.typography import resolve_style
        from .render.educational_cards import is_educational
        educational = is_educational(m.content_type, getattr(m, "preset", ""))
        # 7.0.74: educational videos use the playful palette unless a style is chosen explicitly.
        card_style = 'playful' if educational and presentation.card_style == 'auto' else resolve_style(presentation.card_style, m)
        custom = (build_structured_overlays(D["root"], ndur, m.width, m.height, style=card_style, educational=educational)
                  if graphics_enabled else [])
        if custom:
            overlays = [e for e in overlays if e.get("kind") == "watermark"] + custom
            _save_json(os.path.join(D["root"], "graphics_plan.json"), overlays)

        if graphics_enabled:
            from .reviewed_cards import render_reviewed_cards
            reviewed = None
            if settings.get('speech_cards_enabled') and voice:
                from .speech_cards import render as render_speech_cards
                saved_words = json.load(open(words_p, encoding='utf-8'))
                reviewed = render_speech_cards(D['root'], voice, saved_words, script_text, ndur,
                                               m.width, m.height, card_style, educational=educational, topic=m.topic)
                if reviewed is None:
                    raise ValueError('Speech cards are enabled but not prepared. Resume this job first.')
            else:
                reviewed = render_reviewed_cards(D['root'], ndur, m.width, m.height, card_style)
            if reviewed is not None:
                overlays = [e for e in overlays if e.get('kind') == 'watermark'] + reviewed

        if settings.get('hooks_enabled') and voice and words:
            # 7.0.76: hook pills are placed after cards, and any hook covering another overlay is dropped.
            from .video_hooks import build_hook_overlays
            try:
                hook_overlays, dropped_hooks = build_hook_overlays(
                    D['root'], voice, words, script_text, ndur, m.width, m.height, card_style,
                    overlays, topic=m.topic, language=m.language)
                if dropped_hooks:
                    self.pm.log(job_id, 'hooks_dropped_overlap', {'dropped': dropped_hooks})
                overlays = [e for e in overlays if e.get('kind') != 'hook'] + hook_overlays
            except Exception as hook_error:
                self.pm.log(job_id, 'hooks_render_skipped', {'error': str(hook_error)[:300]})

        # Always update the plan, so a disabled overlay is not resurrected by
        # stale PNGs or a previous graphics_plan on a later render.
        _save_json(os.path.join(D["root"], "graphics_plan.json"), overlays)
        music_mode = presentation.music_mode
        music_meta = {"path": None, "source": "off"}
        if music_mode != "off":
            from .audio.job_music import obtain_job_music
            mood = str(settings.get('music_mood', '') or m.audio_mood or preset.get('music_style', '')
                       or f'soft motivational {m.content_type} instrumental')
            music_meta = obtain_job_music(D['audio'], music_mode,
                mood if settings.get('music_mood') else m.topic + ' ' + mood, presentation.music_path)
            if music_meta.get('warning'): prog('Music fallback', 90, music_meta['warning'])
        music = music_meta.get("path")
        # Legacy local music remains available when the explicit provider is off.
        if not music and not pro_mode and music_mode != "off":
            music = pick_music(preset.get("music_style", ""))
        if music_mode != "off" and not music:
            raise RuntimeError("Requested background music was unavailable. Choose a playable licensed track or explicitly turn music off. Accepted visuals were not regenerated.")
        amb = pick_ambience(m.shots[0].environment if m.shots else "") if presentation.ambience else None
        sfx = plan_sfx(words, tl["segments"]) if presentation.sound_effects else []
        audio_expected = bool(voice or music or amb or any(e.get("path") for e in sfx))
        _save_json(os.path.join(D["audio"], "sound_plan.json"),
                   {"music": music_meta if music_meta.get("path") else music, "ambience": amb, "sfx": sfx,
                    "caption_display": caption_display, "overlays": len([x for x in overlays if x.get("path")]),
                    "voiceover_enabled": presentation.voiceover, "text_cards_enabled": graphics_enabled,
                    "audio_expected": audio_expected, "music_volume": presentation.music_volume,
                    "audio_mode": "voiceover" if voice else ("instrumental" if audio_expected else "silent")})
        prog("🎬 Rendering 1080p YouTube master..." if pro_mode else "🎬 Rendering 1080p...", 92)
        out_name = f"{job_id}-final-broll.mp4" if video_cutaways else f"{job_id}-final.mp4"
        out = os.path.join(D["render"], out_name)
        from .publishing import destination_profile
        delivery = destination_profile(settings['destination']) if settings.get('destination') else {}
        encode_started = time.monotonic()
        clean_master = None
        editions_file = os.path.join(D['root'], 'production', 'language_editions.json')
        if os.path.isfile(editions_file):
            editions_config = json.load(open(editions_file, encoding='utf-8'))
            if len(editions_config.get('editions', [])) > 1:
                clean_master = os.path.join(D['render'], 'visual-master.mp4')
        try:
            r = render_ffmpeg(tl["segments"], voice, out, W=m.width, H=m.height,
                              fps=delivery.get('fps',24), audio_bitrate=delivery.get('audio_kbps',192),
                              ass_path=burn_ass, music=music, ambience=amb,
                              sfx=sfx, overlays=overlays, music_volume=presentation.music_volume,
                              stereo_master=True, quality=quality,
                              safe_concat=True, loop_short_segments=True,
                              video_overlays=video_cutaways, clean_master_path=clean_master,
                              progress_cb=lambda p, detail="": prog("🎬 Rendering", 92 + (float(p) * 0.06), detail))
            renderer = "ffmpeg"
            # Some WSL/libass builds advertise the subtitles filter but fail at
            # runtime. Keep the successful FFmpeg master edit/audio and replace
            # only the caption burn with a Pillow/MoviePy overlay pass.
            if r.get("caption_fallback_required") and words:
                from .video_builder import burn_wordpop_captions
                base = os.path.join(D["render"], f"{job_id}-ffmpeg-base.mp4")
                try:
                    if os.path.exists(base):
                        os.remove(base)
                    os.replace(out, base)
                    burn_wordpop_captions(base, words, out, vertical=(m.aspect == "9:16"))
                    renderer = "ffmpeg+caption-overlay"
                    try:
                        os.remove(base)
                    except Exception:
                        pass
                    prog("✅ FFmpeg master preserved; captions added with safe overlay renderer.", 94)
                except Exception as ce:
                    # The master edit is still valid. Restore it before allowing
                    # the outer fallback to decide whether a full rebuild is needed.
                    if not os.path.exists(out) and os.path.exists(base):
                        os.replace(base, out)
                    raise RuntimeError(f"Caption overlay fallback failed: {ce}")
        except Exception as e:
            render_error = str(e)
            render_error_lower = render_error.lower()
            integrity_failure = any(marker in render_error_lower for marker in (
                "visual qc detected", "motion qc detected",
                "refusing to publish a stuck render", "video stream covers only",
                "safe recovery watchdog",
                "encoder stalled",
            ))
            if integrity_failure:
                # MoviePy re-encodes the same damaged/timing-starved inputs and
                # used to sit silently for 30+ minutes. The FFmpeg renderer has
                # already tried a hard-cut, motion-looping recovery at this point;
                # stop clearly instead of pretending a second full rebuild can
                # repair corrupt or nearly-static source media.
                prog("⛔ Render QC stopped an unhealthy video", 98,
                     render_error[:500] +
                     " — replace/recover the affected source clip(s), then run Resume/Render again.")
                raise RuntimeError(
                    "Render recovery stopped: the output is still blank, truncated, or frozen after "
                    "the bounded safe recovery pass. AutoVideoAI did not publish it and did not start "
                    "the slow MoviePy fallback. Replace/recover the affected source clip(s), then "
                    f"resume the same job. Technical detail: {render_error}") from e
            if video_cutaways:
                raise RuntimeError(
                    "FFmpeg could not apply the approved stock cutaways. Source clips and approved "
                    "stock assets were preserved; no silent fallback without the inserts was used. "
                    f"Technical detail: {render_error}") from e
            prog(f"FFmpeg pipeline failed ({str(e)[:80]}), trying full MoviePy fallback...", 93)
            r = self._render_moviepy_fallback(m, D, tl, voice, out,
                                              music=music, ambience=amb, sfx=sfx, overlays=overlays,
                                              words=words, captions=caption_display == "full",
                                              music_volume=presentation.music_volume, quality=quality)
            renderer = "moviepy-fallback"
        _save_json(os.path.join(D['render'], 'render_profile.json'), {
            'quality': quality, 'renderer': renderer,
            'total_seconds': round(time.monotonic() - render_started, 2),
            'preparation_seconds': round(encode_started - render_started, 2),
            'encoding_and_qc_seconds': round(time.monotonic() - encode_started, 2),
            'staging_seconds': r.get('staging_seconds') if isinstance(r, dict) else None,
            'final_master_seconds': r.get('final_master_seconds') if isinstance(r, dict) else None,
            'encoder': r.get('encoder') if isinstance(r, dict) else None,
            'bounded_render': bool(r.get('bounded_render')) if isinstance(r, dict) else False,
            'segments': len(tl['segments']), 'approved_cutaways': len(video_cutaways),
            'graphics': len(overlays),
            'stage_timings': str(os.path.join(D['render'], 'render_stage_timings.json')),
        })
        # metadata bundle + planned-vs-actual generation audit
        _save_json(os.path.join(D["root"], "shots.json"), [s.model_dump() for s in m.shots])
        fallback_shots = [s for s in m.shots if s.fallback_reason]
        accepted_shots = [s for s in m.shots if s.status == "accepted"]
        unaccepted_shots = [s for s in m.shots if s.status != "accepted"]
        actual_counts = {}
        for s in accepted_shots:
            ap = s.actual_provider or s.provider or "unknown"
            actual_counts[ap] = actual_counts.get(ap, 0) + 1
        flow_credits = sum(int(s.credits_spent or 0) for s in accepted_shots
                           if (s.actual_provider or s.provider) == "flow")
        from .generation_audit import frame_fallbacks
        image_fallbacks = frame_fallbacks(D['root'], m.shots, settings.get('frame_source', 'auto'))
        total_fallbacks = len(fallback_shots) + len(image_fallbacks)
        generation_summary = {
            "shots": len(m.shots),
            "accepted": len(accepted_shots),
            "unaccepted": len(unaccepted_shots),
            "unaccepted_shots": [s.shot_id for s in unaccepted_shots],
            "planned_flow_scenes": sum(1 for s in m.shots if s.media_strategy == "flow_video"),
            "actual_provider_counts": actual_counts,
            "fallback_count": total_fallbacks,
            "scene_fallback_count": len(fallback_shots),
            "frame_fallback_count": len(image_fallbacks), "frame_fallbacks": image_fallbacks,
            "actual_flow_credits": flow_credits,
            "credit_basis": "observed-or-model-estimate",
            "fallbacks": [{"shot_id": s.shot_id, "planned": s.provider,
                           "actual": s.actual_provider or s.provider,
                           "reason": s.fallback_reason} for s in fallback_shots],
        }
        _save_json(os.path.join(D["root"], "generation_summary.json"), generation_summary)
        # Collect stock/music provenance for later YouTube descriptions and
        # license audits. Browser/API helpers write sidecars next to downloaded
        # media; the finished job consolidates them here.
        asset_sources = []
        for base in (D.get("flow"), D.get("audio")):
            if not base or not os.path.isdir(base):
                continue
            for root, _, files in os.walk(base):
                for fn in files:
                    if not fn.endswith(".source.json"):
                        continue
                    try:
                        meta = json.load(open(os.path.join(root, fn), encoding="utf-8"))
                        if isinstance(meta, dict):
                            asset_sources.append(meta)
                    except Exception:
                        pass
        if "music_meta" in locals() and isinstance(music_meta, dict) and music_meta.get("path"):
            if not any(x.get("path") == music_meta.get("path") for x in asset_sources if isinstance(x, dict)):
                asset_sources.append(music_meta)
        for cutaway in video_cutaways:
            asset_sources.append({
                "path": cutaway["path"], "source": cutaway.get("source", "stock"),
                "license": cutaway.get("license", ""), "page_url": cutaway.get("page_url", ""),
                "creator": cutaway.get("creator", ""), "query": cutaway.get("query", ""),
                "candidate_id": cutaway.get("candidate_id", ""),
                "timeline_start": cutaway.get("start"), "timeline_end": cutaway.get("end"),
                "rights_reviewed": True,
            })
        _save_json(os.path.join(D["root"], "asset_sources.json"), asset_sources)
        if video_cutaways:
            _save_json(os.path.join(D["render"], "broll_applied.json"), {
                "video": out, "audio_policy": "preserved-existing-audio-and-duration",
                "cutaways": [{k: v for k, v in item.items() if k != "path"}
                             | {"asset_name": os.path.basename(item["path"])}
                             for item in video_cutaways],
            })
        try:
            lines = ["# Media credits / provenance", ""]
            for a in asset_sources:
                src = str(a.get("source", "media"))
                creator = str(a.get("creator", "") or "").strip()
                page = str(a.get("page_url") or a.get("source_page") or "").strip()
                lic = str(a.get("license", "") or "").strip()
                q = str(a.get("query", "") or "").strip()
                line = f"- {src}" + (f" — {creator}" if creator else "")
                if lic:
                    line += f" — {lic}"
                if q:
                    line += f" — query: {q}"
                if page:
                    line += f" — {page}"
                lines.append(line)
            open(os.path.join(D["root"], "asset_credits.txt"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
        except Exception:
            pass
        with open(os.path.join(D["root"], "generation_summary.md"), "w", encoding="utf-8") as gf:
            gf.write(f"# Generation Summary\n\nShots: {len(m.shots)}\n\n")
            gf.write(f"Planned Flow motion scenes: {generation_summary['planned_flow_scenes']}\n\n")
            gf.write(f"Actual provider counts: {actual_counts}\n\n")
            gf.write(f"Actual/observed Flow credits: {generation_summary['actual_flow_credits']}\n\n")
            gf.write(f"Fallbacks: {total_fallbacks} (storyboard/master images: {len(image_fallbacks)})\n")
            for fs in fallback_shots:
                gf.write(f"- {fs.shot_id}: {fs.provider} -> {fs.actual_provider or fs.provider}: {fs.fallback_reason}\n")

        # v7.0.68: the primary edition is complete here. Every additional language
        # edition selected in Create is rendered from the approved clean picture and
        # its reviewed narration. A failure is reported, never replaced by English audio.
        # v7.0.73: the English master also gets the channel profile's intro and outro,
        # the same way the editions do. The unbranded final stays in render/ as well.
        primary_report = {"status": "not_requested"}
        try:
            from .language_editions import render_primary_branding
            primary_report = render_primary_branding(
                D["root"], out, progress=lambda label, pct, detail="": prog(label, 95 + 1 * float(pct) / 100, detail))
        except Exception as primary_error:
            primary_report = {"status": "failed", "error": str(primary_error)[:800]}
        edition_report = {"status": "not_requested", "editions": {}}
        try:
            from .language_editions import render_job_editions
            edition_report = render_job_editions(
                D["root"], progress=lambda label, pct, detail="": prog(label, 96 + 3 * float(pct) / 100, detail))
        except Exception as edition_error:
            edition_report = {"status": "failed", "editions": {}, "error": str(edition_error)[:800]}
        final_warnings = list(tl["warnings"])
        if caption_timing_estimated and caption_display == "full":
            final_warnings.append("Captions are estimated from the script (" + caption_timing_engine + "), not measured from speech. Words can drift 2-3 s during pauses; check sync before publishing.")
        if primary_report.get("status") == "failed":
            final_warnings.append("Intro/outro not applied to the primary master: " + str(primary_report.get("error") or "see production/language_editions_render.json"))
        if edition_report.get("status") in ("failed", "partial"):
            detail = str(edition_report.get("error") or "")
            if not detail:
                # 7.0.95: name every language that did not render, with its reason.
                try:
                    from .language_editions import edition_diagnosis
                    diagnosis = edition_diagnosis(D['root'])
                    detail = '; '.join(str(row.get('message') or '') for row in
                                       (diagnosis.get('editions') or {}).values()
                                       if row.get('status') != 'exported')
                except Exception:
                    detail = ""
            final_warnings.append("Language editions need attention: " +
                                  (detail or "see production/language_editions_render.json"))
        if image_fallbacks:
            final_warnings.append(f'{len(image_fallbacks)} storyboard/master image(s) used substitute media; character and scene fidelity need review')
        if fallback_shots:
            final_warnings.append(f"{len(fallback_shots)} scene(s) used runtime fallback; see generation_summary.md")
        if unaccepted_shots:
            final_warnings.append(f"{len(unaccepted_shots)} planned shot(s) were not accepted; timeline used visual bridging where needed")
        if renderer == "moviepy-fallback":
            final_warnings.append("FFmpeg master render failed; full MoviePy fallback was used")
        elif renderer == "ffmpeg+caption-overlay":
            final_warnings.append("FFmpeg master render succeeded; libass caption burn was replaced by safe Pillow overlay")

        # v5.1 visual-diversity QC is report-only: do not destroy a completed
        # render, but make excessive near-duplication visible in the job audit.
        try:
            from .qc.visual_diversity import analyze_storyboard
            diversity = analyze_storyboard(D["storyboard"])
            _save_json(os.path.join(D["root"], "visual_diversity.json"), diversity)
            if diversity.get("unique_ratio", 1.0) < 0.65:
                final_warnings.append(
                    f"Low storyboard visual diversity ({diversity.get('unique_ratio', 0):.0%} unique); "
                    "future same-topic generations will force more composition changes")
        except Exception:
            diversity = {}
        editorial_qc = script_data.get("editorial_qc") or {}
        dynamic_actual = int(actual_counts.get("flow", 0) or 0) + int(actual_counts.get("stock", 0) or 0) + int(actual_counts.get("movieflow", 0) or 0)
        overlay_count = len([x for x in overlays if x.get("path")]) if "overlays" in locals() else 0
        readiness_checks = {
            "editorial_qc": bool(editorial_qc.get("passed", False)),
            "ai_script": not str(script_data.get("source", "planner")).startswith("planner"),
            "all_shots_accepted": not bool(unaccepted_shots),
            "captions_present": not presentation.voiceover or bool(cap.get("events", 0)),
            "caption_timing": not bool(cap.get("warnings")),
            "visual_diversity": (not diversity or float(diversity.get("unique_ratio", 1.0)) >= 0.70),
            "no_storyboard_substitutions": not bool(image_fallbacks),
            "render_integrity": True,  # render_ffmpeg refuses broken black/missing outputs
        }
        if pro_mode:
            readiness_checks.update({
                "dynamic_media": dynamic_actual >= min(len(m.shots), max(1, int(round(float(m.target_seconds or 300) / 60.0)))),
                "editorial_graphics": not graphics_enabled or overlay_count >= 3,
                "stereo_master": True,
                "outro_cta": (not graphics_enabled or m.content_type in {"kids_story", "kids", "cartoon_story", "cinematic_story", "storytelling"}
                              or any(x.get("kind") == "outro" and x.get("path") for x in overlays)),
            })
        publish_warnings = list(cap.get("warnings", []))
        if image_fallbacks: publish_warnings.append(f"{len(image_fallbacks)} storyboard substitutions require visual review")
        failed_cards = [e for e in overlays if e.get("error")]
        if failed_cards:
            publish_warnings.extend("Text card needs review: " + e['error'] for e in failed_cards)
            readiness_checks["card_layout"] = False
        if fallback_shots:
            publish_warnings.append(f"{len(fallback_shots)} planned AI-motion scene(s) used fallback media")
        if diversity and float(diversity.get("unique_ratio", 1.0)) < 0.80:
            publish_warnings.append(f"Visual diversity is {float(diversity.get('unique_ratio', 0)):.0%}; 80%+ is preferred")
        if pro_mode and m.target_seconds >= 240 and dynamic_actual < 5:
            publish_warnings.append(f"Only {dynamic_actual} real/AI motion clip(s) made the final edit; 5+ is preferred for a five-minute video")
        if pro_mode and music_mode != "off" and not music:
            publish_warnings.append("Background music was requested but no royalty-free asset was obtained; add a local track or retry browser lookup")
        if pro_mode and not str(settings.get("channel_name", "") or "").strip():
            publish_warnings.append("No channel name supplied; watermark/brand identity is incomplete")
        publish_readiness = {
            "status": "NEEDS_EDITORIAL_REVIEW" if all(readiness_checks.values()) else "NEEDS_REVIEW",
            "passed": False,
            "technical_and_recipe_checks_passed": all(readiness_checks.values()),
            "checks": readiness_checks,
            "warnings": publish_warnings,
            "script_source": script_data.get("source", "unknown"),
            "renderer": renderer,
            "production_mode": settings.get("production_mode", "legacy"),
            "caption_display": caption_display,
            "voiceover_enabled": presentation.voiceover, "text_cards_enabled": graphics_enabled,
            "text_card_style": card_style,
            "checks_not_applicable": (["captions_present", "caption_timing"] if not voice else [])
                                     + (["editorial_graphics", "outro_cta"] if not graphics_enabled else []),
            "graphics_overlays": overlay_count,
            "dynamic_media_clips": dynamic_actual,
            "background_music": music_meta if "music_meta" in locals() else {"path": music, "source": "legacy"},
        }
        _save_json(os.path.join(D["root"], "publish_readiness.json"), publish_readiness)
        save_review(os.path.join(D["root"], "production", "review.json"),
                    {"status": "RENDER_CHANGED", "next_action": "Run production-check for this render"})
        details = (f"Title: {m.topic}\nProfile: {m.profile} | Preset: {m.preset}\n"
                   f"Size: {m.width}x{m.height} | Renderer: {renderer}\nShots: {len(m.shots)} "
                   f"accepted: {m.accepted_count()}\nActual providers: {actual_counts}\n"
                   f"Fallbacks: {total_fallbacks} | Flow credits: {generation_summary['actual_flow_credits']}\n"
                   f"Publish readiness: {publish_readiness['status']}\n"
                   f"Warnings: {final_warnings + publish_warnings}\n")
        open(os.path.join(D["root"], "details.txt"), "w", encoding="utf-8").write(details)
        m.status = "done"
        self.pm.save_manifest(m)
        self.db.upsert(job_id, status="done", render_status="done", final_path=out,
                       accepted_shots=m.accepted_count())
        prog(f"Render complete — {publish_readiness['status']}; providers={actual_counts} fallbacks={total_fallbacks} (storyboard={len(image_fallbacks)})", 100)
        return {"job_id": job_id, "status": "done", "video": out, "renderer": renderer,
                "language_editions": edition_report,
                "primary_branding": primary_report,
                "captions": cap, "generation_summary": generation_summary,
                "visual_diversity": diversity, "publish_readiness": publish_readiness,
                "graphics": overlays if "overlays" in locals() else [],
                "background_music": music_meta if "music_meta" in locals() else {},
                "broll_cutaways": len(video_cutaways),
                "warnings": final_warnings + publish_warnings}

    def _render_moviepy_fallback(self, m, D, tl, voice, out, **presentation) -> dict:
        from .render.moviepy_renderer import render_moviepy
        return render_moviepy(tl["segments"], voice, out, total=tl["total"],
                              W=m.width, H=m.height, **presentation)

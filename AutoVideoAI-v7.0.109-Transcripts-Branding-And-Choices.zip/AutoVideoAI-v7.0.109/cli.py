"""
CLI - Full automation without browser (v2)
Examples:
  python cli.py --topic "5 AI tools" --type shorts
  python cli.py --topic "5 AI tools" --visual-mode flow
  python cli.py --topic "5 AI tools" --visual-mode ai --ai-provider veo
  python cli.py --shot-list "My topic" --type shorts     (Flow subscription workflow)
  python cli.py --bulk topics.csv
  python cli.py --trending 5
"""
import argparse
import json
import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from engine.env_config import load_environment, format_environment_report


def _load_env_with_migration():
    """Load local .env, then fill any *missing* API keys from older installs.

    Older builds returned as soon as one key existed. A folder containing only a
    Gemini key could therefore make ``--script-provider groq`` look unconfigured
    even when a sibling version had the Groq key. v5.4 merges missing secrets
    without overriding values from the current installation.
    """
    load_dotenv()
    keys = ("GEMINI_API_KEY", "GROQ_API_KEY", "OPENAI_API_KEY", "XAI_API_KEY", "PEXELS_API_KEY", "PIXABAY_API_KEY")
    missing_before = {k for k in keys if not os.getenv(k)}
    if not missing_before:
        return
    candidates = []
    shared = Path.home() / ".config" / "autovideoai" / ".env"
    if shared.is_file():
        candidates.append(shared)
    here = Path(__file__).resolve().parent
    parent = here.parent
    siblings = []
    for q in parent.glob("AutoVideoAI-v*/.env"):
        try:
            if q.resolve() != (here / ".env").resolve():
                siblings.append(q)
        except Exception:
            siblings.append(q)
    siblings.sort(key=lambda q: q.stat().st_mtime if q.exists() else 0, reverse=True)
    candidates.extend(siblings)
    loaded_from = []
    for env_path in candidates:
        before = {k for k in keys if os.getenv(k)}
        load_dotenv(env_path, override=False)
        after = {k for k in keys if os.getenv(k)}
        if after - before:
            loaded_from.append(env_path.parent.name)
        if all(os.getenv(k) for k in keys):
            break
    if loaded_from:
        print("[Config] Filled missing API credentials from " + ", ".join(loaded_from) + " (secrets not copied).")


_load_env_with_migration()
_ENV_REPORT = load_environment(Path(__file__).resolve().parent)


def pause_guidance_lines(pause, state=None):
    """The console PAUSE / RECOVERY GUIDANCE block (v7.0.105).

    ``state`` is ``Factory.recovery_state(job_id)``. Without it the saved pause is printed verbatim, which is
    exactly how the console kept showing "shot_014 ... FlowRequestPending" and ``13/45`` while the production had
    moved to shot_018 with 17 accepted shots.
    """
    state = state or {}
    pause = pause or {}
    shot = state.get('shot_id') or pause.get('shot_id') or '?'
    reason = state.get('reason') or pause.get('reason') or 'unknown'
    lines = [f"  stopped_at={pause.get('paused_at', '?')} shot={shot}", f"  reason={reason}"]
    if state.get('pause_notice_stale'):
        lines.append('  (the saved notice above was superseded: it described a request that is already resolved)')
        superseded = str(state.get('pause_notice_superseded') or '')
        if superseded:
            lines.append('  superseded_reason=' + superseded)
    project = pause.get('flow_project_url') or state.get('flow_project_url') or ''
    if project:
        lines.append(f"  flow_project={project}")
    accepted = state.get('accepted_shots', pause.get('accepted_shots', 0))
    total = state.get('total_shots', pause.get('total_shots', 0))
    lines.append(f"  completed={accepted}/{total} (manifest)")
    unresolved = [str(row) for row in (state.get('unresolved_journals') or []) if row]
    if unresolved:
        lines.append(f"  unresolved_requests={len(unresolved)} (Resume keeps waiting on these; no new credits)")
        lines.extend('    ' + row for row in unresolved[:6])
    actions = state.get('actions') or pause.get('actions') or []
    for number, action in enumerate(actions, 1):
        lines.append(f"  {number}. {action.get('label')}:\n     {action.get('command')}")
    return lines


def main_v3(argv):
    from pathlib import Path
    """Factory CLI: python cli.py v3 <create|resume|status|render|queue|support-report>."""
    from engine.factory import Factory
    ap = argparse.ArgumentParser(prog="cli.py v3", description="AutoVideoAI v3 factory")
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("create", help="Create + run a production")
    c.add_argument("--topic", required=True)
    c.add_argument("--type", dest="video_type", default="shorts",
                   choices=["shorts", "faceless_youtube", "explainer", "marketing"])
    c.add_argument("--duration", type=int, default=45)
    c.add_argument("--language", default="en", choices=["en","hi","or"])
    c.add_argument("--destination", default=None, choices=["instagram_reel","facebook_reel","youtube_short","youtube_long"])
    c.add_argument("--external-video-mode", action="store_true", help="Export AI video shot prompts and wait for reviewed external MP4s")
    c.add_argument("--approved-plan-path", default="", help="reviewed external JSON script/storyboard")
    c.add_argument("--narration-input-path", default="", help="native narration file you own/are licensed to use")
    c.add_argument("--character-ids", nargs="*", default=[], help="up to three saved cast IDs")
    c.add_argument("--character-id", default="", help="original character from the local library")
    c.add_argument("--profile", default="FLOW_BALANCED",
                   choices=["FLOW_CINEMATIC", "FLOW_BALANCED", "FLOW_ECONOMY", "STORYBOARD_ECONOMY", "LOCAL_FREE", "FREE_HYBRID", "MANUAL_DIRECTOR"])
    c.add_argument("--preset", default="cinematic_realism")
    c.add_argument("--content-type", default="education")
    c.add_argument("--cartoon-provider", default="flow", choices=["flow", "movieflow"],
                   help="cartoon/kids-story visual engine: flow keeps the Google Flow workflow; movieflow uses MovieFlow Studio")
    c.add_argument("--movieflow-mode", default="full_story", choices=["full_story", "scenes"],
                   help="MovieFlow: full_story sends the complete cartoon story once; scenes uses MovieFlow only for AI-motion shots")
    c.add_argument("--movieflow-project-url", default="",
                   help="optional existing MovieFlow Studio project/workspace URL to reuse")
    c.add_argument("--movieflow-wait-seconds", type=int, default=1800,
                   help="maximum time to wait for a submitted MovieFlow video/story generation (default 1800s)")
    c.add_argument("--movieflow-recovery-wait-seconds", type=int, default=300,
                   help="if the MovieFlow tab/session closes after submit, reopen the project and wait this long for the already-running job instead of generating again")
    c.add_argument("--speech-cards", dest="speech_cards_enabled", action="store_true", help="Draft Gemini cards after narration using word timings")
    c.add_argument("--gemini-video-count", type=int, choices=range(5), default=0, help="Replace up to four planned Flow shots with Gemini Web requests")
    c.add_argument("--flow-auto-cleanup-images", action="store_true", help="Delete fully captured isolated image projects")
    c.add_argument("--tone", default="cinematic")
    c.add_argument("--voiceover", dest="voiceover_enabled", action=argparse.BooleanOptionalAction, default=None,
                   help="include narration; --no-voiceover skips TTS/ASR entirely and uses a visual story clock")
    c.add_argument("--text-cards", dest="text_cards_enabled", action=argparse.BooleanOptionalAction, default=None,
                   help="editorial title/key-point/recap cards; --no-text-cards also overrides Pro mode and custom graphics")
    c.add_argument("--text-card-style", choices=["auto", "bold", "playful", "clean"], default="auto")
    c.add_argument("--background-music-path", default="", help="licensed local music file; choose --background-music local")
    c.add_argument("--music-volume", type=float, default=None, help="music gain 0..1; auto defaults to a foreground instrumental level without voiceover")
    c.add_argument("--sound-effects", dest="sound_effects_enabled", action=argparse.BooleanOptionalAction, default=None)
    c.add_argument("--ambience", dest="ambience_enabled", action=argparse.BooleanOptionalAction, default=None)
    c.add_argument("--voice", default="en-IN-PrabhatNeural",
                   help="legacy/Edge voice name; provider-specific voice can be set with --tts-voice")
    c.add_argument("--script-provider", default="auto",
                   choices=["auto", "gemini", "gemini-web", "groq", "openai", "grok", "ollama", "planner"],
                   help="v5 script director; gemini-web uses your signed-in Gemini browser; auto can include it when AUTOVIDEO_ENABLE_GEMINI_WEB=1")
    c.add_argument("--script-model", default="auto",
                   help="optional exact model ID for the chosen script provider")
    c.add_argument("--script-quality", default="publish", choices=["standard", "high", "publish"],
                   help="publish (default) requires an AI writer and passes strict editorial/list/topic-drift QC before visuals are generated")
    c.add_argument("--tts-provider", default="auto",
                   choices=["auto", "gemini", "gemini-lite", "groq", "elevenlabs", "kokoro", "edge", "gtts", "mock"],
                   help="narration provider; auto is quality/free-first and keeps gTTS last")
    c.add_argument("--tts-model", default="", help="optional provider-specific TTS model ID")
    c.add_argument("--tts-voice", default="", help="provider-specific voice ID/name (Gemini/ElevenLabs/Kokoro)")
    c.add_argument("--tts-style", default="warm, confident YouTube narrator; conversational and human; varied emphasis; medium energy; short natural pauses before numbered sections; brighter tone when introducing each new point; slower on key takeaways; never salesy or robotic",
                   help="delivery direction for controllable TTS providers")
    c.add_argument("--caption-provider", default="auto", choices=["auto", "groq", "local", "script-timed"],
                   help="caption timing; script-timed uses exact authored text + measured audio duration and needs no Whisper/API")
    c.add_argument("--caption-model", default="whisper-large-v3-turbo",
                   help="Groq speech-to-text model for timing")
    c.add_argument("--caption-local-model", default="small",
                   help="faster-whisper fallback model (small is much more accurate than old tiny default)")
    c.add_argument("--no-caption-script-align", dest="caption_align_script", action="store_false", default=True,
                   help="disable exact-script caption correction (not recommended)")
    c.add_argument("--max-tts-speedup", type=float, default=1.08,
                   help="maximum final narration speed-up; v5 rewrites overlong scripts first")
    c.add_argument("--no-auto-retime-script", dest="auto_retime_script", action="store_false", default=True,
                   help="disable automatic script rewrite when measured TTS is much longer than target")
    c.add_argument("--render-quality", default="fast", choices=["preview", "fast", "standard", "high"],
                   help="final FFmpeg quality used by automatic render; high is the publish-ready default")
    c.add_argument("--production-mode", default="legacy", choices=["legacy", "youtube_pro"],
                   help="youtube_pro enables mixed stock/Flow motion, editorial graphics, stereo master and publish QC")
    c.add_argument("--dynamic-video-scenes", type=int, default=None,
                   help="youtube_pro target number of true-motion clips across the video (default ~= one every 30s)")
    c.add_argument("--stock-scenes", type=int, default=None,
                   help="exact target number of royalty-free stock-video slots; youtube_pro auto-fills the balance")
    c.add_argument("--stock-source", default="auto", choices=["auto", "api", "browser", "local"],
                   help="stock footage: local library first; auto uses free Pexels/Pixabay APIs when keys exist then isolated browser fallback")
    c.add_argument("--caption-display", default="auto", choices=["auto", "full", "none"],
                   help="burn transcript captions into video; youtube_pro auto=none while SRT/ASS are still generated for YouTube CC")
    c.add_argument("--background-music", default="off", choices=["off", "auto", "local", "browser", "generated", "reliable"],
                   help="soft royalty-free music; auto uses local assets then isolated Pixabay browser fallback")
    c.add_argument("--music-mood", default="",
                   help="search/style hint for background music, e.g. 'soft motivational ambient instrumental'")
    c.add_argument("--channel-name", default="", help="channel name used for subtle watermark and end-screen branding")
    c.add_argument("--channel-logo", default="", help="optional PNG/JPG logo path for intro/outro graphics")
    c.add_argument("--graphics-overlays", action="store_true",
                   help="enable editorial cards/key points; automatically enabled by youtube_pro")
    c.add_argument("--watermark", action="store_true",
                   help="enable a subtle channel-name watermark (off unless explicitly requested)")
    c.add_argument("--max-credits", type=int, default=100)
    c.add_argument("--max-retries", type=int, default=2)
    c.add_argument("--images-per-shot", type=int, default=2,
                   help="Scene stills per shot via Flow image gen (0=skip)")
    c.add_argument("--video-share", type=float, default=0.20,
                   help="STORYBOARD_ECONOMY: target fraction of scenes that deserve paid AI motion")
    c.add_argument("--stock-share", type=float, default=0.60,
                   help="STORYBOARD_ECONOMY: target fraction of generic B-roll scenes to use stock")
    c.add_argument("--flow-scenes", type=int, default=None,
                   help="exact target number of paid Flow motion scenes; budget cap still applies")
    c.add_argument("--max-flow-scenes", type=int, default=None,
                   help="hard cap on paid Flow motion scenes (not a requested count; budget cap still applies)")
    c.add_argument("--frame-source", default="auto", choices=["auto", "flow", "free"],
                   help="opening/closing stills: auto=retry Flow then visibly fall back; flow=strict Flow only; free=free provider only")
    c.add_argument("--flow-image-workers", type=int, default=1, choices=[1, 2, 3],
                   help="parallel isolated Flow still workers; Storyboard Economy keeps continuity-linked openings ordered")
    c.add_argument("--flow-video-mode", default="frames", choices=["frames", "prompt"],
                   help="Flow motion input: frames attaches storyboard references; prompt creates prompt-only clips")
    c.add_argument("--pause-on-unresolved-flow-request", dest="flow_pause_on_unresolved_request",
                   action=argparse.BooleanOptionalAction, default=None,
                   help="opt in to PAUSED jobs when a Flow request cannot be safely recovered; default is no automatic pause. Image recovery retries downloads first and permits at most one credit-bearing replacement after two scans prove absence")
    c.add_argument("--flow-approval", default="once", choices=["once", "manual", "always"],
                   help="Flow Agent credit confirmation behavior for paid motion scenes")
    c.add_argument("--max-generation-credits", type=int, default=10,
                   help="hard safety cap for any one Flow video generation")
    c.add_argument("--shot-max-seconds", type=float, default=None,
                   help="maximum narration seconds per visual shot; useful for long-form pacing (e.g. 8)")
    c.add_argument("--flow-frame-retries", type=int, default=3,
                   help="Flow still-image attempts before strict failure/fallback (default 3)")
    c.add_argument("--network-wait-seconds", type=int, default=300,
                   help="pause this long for temporary Internet loss before failing (default 300s)")
    c.add_argument("--flow-capacity-wait-seconds", type=int, default=900,
                   help="maximum time to recover Flow Agent high-demand responses before pausing (default 900s)")
    c.add_argument("--flow-capacity-retries", type=int, default=8,
                   help="Try-again clicks for Flow Agent high-demand recovery (default 8)")
    c.add_argument("--flow-image-wait-seconds", type=int, default=60,
                   help="Seconds to wait for one Flow image before reporting no output (default 60s; was 360s)")
    c.add_argument("--flow-project-url", default="",
                   help="reuse an exact https://flow.google.com/project/<uuid> project; resume stores/reuses it automatically")
    c.add_argument("--flow-video-retries", type=int, default=1,
                   help="extra Flow video attempts after recovery is exhausted (default 1 = retry once)")
    c.add_argument("--flow-video-ready-grace-seconds", type=int, default=20,
                   help="after Flow stops showing generation progress, keep waiting for a real video/download-ready tile before probing an untyped tile (default 20s)")
    c.add_argument("--flow-video-recovery-wait-seconds", type=int, default=180,
                   help="when the Flow page/session closes after generation, wait this long for the already-generated video to appear before submitting a new video request (default 180s)")
    c.add_argument("--flow-reuse-mode", default="exact", choices=["exact", "topic", "project"],
                   help="Flow-project reuse scope: exact=prompt fingerprint only (publish-safe default); topic/project are faster but may reuse visuals from an older script")
    c.add_argument("--no-flow-reuse-project-media", dest="flow_reuse_project_media", action="store_false", default=True,
                   help="disable frame/media reuse for a reused Flow project")
    c.add_argument("--dry-run", action="store_true")
    c.add_argument("--plan-only", action="store_true", help="Create the job configuration only; run v3 resume to execute it")

    cc = sub.add_parser("create-config", help="Create + run from a simple commented YAML file")
    cc.add_argument("config", help="path to video_config.yaml")
    cc.add_argument("--plan-only", action="store_true", help="create the resumable job without running it")

    sub.add_parser("themes", help="List Studio themes and their defaults")
    dash = sub.add_parser("dashboard", help="Open the HTML Studio dashboard")
    dash.add_argument("--port", type=int, default=8501)

    ar = sub.add_parser("archive-request", help="Archive one unresolved Flow image request (kept on record) so the next Resume makes ONE new submission; image requests are free in Flow, so no credit approval is needed")
    ar.add_argument("job_id")
    ar.add_argument("image", help="e.g. storyboard/shot_020_open.jpg")
    ar.add_argument("--confirm-new-credit-spend", action="store_true",
                    help="only for a non-image journal: you approve that the next Resume spends credits on one new submission. "
                         "An image request is free in Flow, so this flag is not required for it (accepted for old scripts)")
    r = sub.add_parser("resume", help="Resume a job")
    r.add_argument("job_id")
    r.add_argument('--replace-unresolved-images', action=argparse.BooleanOptionalAction, default=None,
                   help='After three download-only image recovery retries, allow one replacement per image; saved across Resume. Videos stay protected.')
    r.add_argument('--image-replacement-limit',type=int,default=None,help='Whole-job replacement cap, 1–100; default 30')
    r.add_argument('--flow-submission-cap', type=int, default=None,
                   help='v7.0.71: explicitly confirm a per-job cap on new Flow prompts (1–500; default 20). Written to the job and logged.')
    r.add_argument('--local-closing-fallback', action=argparse.BooleanOptionalAction, default=None,
                   help='Persist permission to reuse a shot opening image when its closing image cannot recover. Keeps the Flow journal; no replacement image request.')
    r.add_argument("--continue-on-unresolved-frames", action=argparse.BooleanOptionalAction, default=None,
                   help="Persist exact-Flow batch recovery: retain blocked frames, continue other frames, then pause once with a summary; no fallback or replacement generation")
    r.add_argument("--gemini-chat-cleanup", choices=["keep", "delete-after-read"], default=None,
                   help="Persist this cleanup policy for the existing job before resuming")
    r.add_argument("--pause-on-unresolved-flow-request", dest="flow_pause_on_unresolved_request",
                   action=argparse.BooleanOptionalAction, default=None,
                   help="explicitly enable/disable PAUSED status for unresolved Flow requests on this job")
    r.add_argument("--flow-image-wait-seconds", type=int, default=None,
                   help="Seconds to wait for one Flow image before recovery reports no output (default 60s; was 360s)")

    rv = sub.add_parser(
        "recover-flow-video",
        help="Recover/download an already-generated video from the saved Flow project (submits no generation)")
    rv.add_argument("job_id")
    rv.add_argument("--shot-id", default="", help="unfinished shot to associate; defaults to the first pending shot")
    rv.add_argument("--wait-seconds", type=int, default=120,
                    help="how long to scan the existing project for a downloadable video tile")
    rv.add_argument('--asset-url', default='', help='Exact reviewed /project/ID/edit/ID URL; download only')
    rv.add_argument('--asset-reviewed', action='store_true', help='Confirm the editor video belongs to the selected pending shot')
    rv.add_argument("--allow-latest", action="store_true",
                    help="allow newest-tile recovery without a saved baseline; use only after visually confirming it belongs to this shot")
    rv.add_argument("--auto-approve", action="store_true",
                    help="approve this saved request's Flow card ONCE (readable cost within the job's per-take "
                         "cap) before the download-only wait; a duplicate card is never clicked")

    ap_ = sub.add_parser(
        "approve-request",
        help="Approve ONCE the Flow credit card a saved video request is still waiting on, then download it "
             "(v7.0.99; the card cost must be confirmed explicitly)")
    ap_.add_argument("job_id")
    ap_.add_argument("--shot-id", default="", help="shot whose saved video request is waiting; defaults to the first pending shot")
    ap_.add_argument("--confirm-credits", type=int, default=None,
                     help="the exact credit cost shown on the Flow card; a different cost is refused before any "
                          "click, and omitting it only reads the card")
    ap_.add_argument("--wait-seconds", type=int, default=180,
                     help="how long to wait for the approved video to appear before reporting (default 180s)")
    ap_.add_argument("--inspect", action="store_true",
                     help="read-only: report whether a clickable card is visible and what it costs; never clicks")

    bk = sub.add_parser(
        "backups",
        help="Show where rendered videos are kept after a job or Clip Studio cleanup, and restore one")
    bk.add_argument("--restore", default="", metavar="JOB_ID",
                    help="copy this job's backed-up videos back to outputs/<job>/render (the job itself is not recreated)")
    bk.add_argument("--outputs", default="outputs", help="Outputs root (default: outputs)")

    fps = sub.add_parser(
        "flow-projects",
        help="Show the stills and video Flow projects of a job (read-only), or repair them explicitly: "
             "--set-stills URL, --set-video URL, --clear-stills, --clear-video")
    fps.add_argument("job_id")
    fps.add_argument("--set-stills", default="", metavar="URL",
                     help="bind the storyboard/stills project (also clears the video binding if it is the same URL)")
    fps.add_argument("--set-video", default="", metavar="URL", help="bind the motion-video project explicitly")
    fps.add_argument("--clear-stills", action="store_true",
                     help="remove the stills binding (settings.json flow_project_url and the database row)")
    fps.add_argument("--clear-video", action="store_true",
                     help="remove the video binding (flow_video_project.json / settings flow_video_project_url); "
                          "the next video submission opens its own project")
    fps.add_argument("--confirm", action="store_true",
                     help="required for every change; without it the command only prints the bindings")

    fp = sub.add_parser("flow-project", help="Bind/rebind an AutoVideoAI job to an exact Google Flow project URL")
    fp.add_argument("job_id")
    fp.add_argument("url")

    s = sub.add_parser("status", help="Show job status")
    s.add_argument("job_id")

    support = sub.add_parser("support-report", help="Export redacted pause diagnostics offline (no generation)")
    support.add_argument("job_id")
    support.add_argument("--outputs-root", default="outputs", help="Folder containing saved jobs")
    support.add_argument("--output", help="New .json file; existing files are never overwritten")
    cleanup_plan = sub.add_parser("cleanup-plan", help="Preview post-job cleanup: keeps the final video and all records")
    cleanup_plan.add_argument("job_id", nargs="?", help="Saved job id (generation jobs)")
    cleanup_plan.add_argument("--clip-folder", help="Clip output folder instead of a job")
    cleanup_plan.add_argument("--outputs-root", default="outputs", help="Folder containing saved jobs")
    cleanup_apply = sub.add_parser("cleanup-apply", help="Apply a reviewed cleanup; needs the digest from cleanup-plan")
    cleanup_apply.add_argument("job_id", nargs="?", help="Saved job id (generation jobs)")
    cleanup_apply.add_argument("--clip-folder", help="Clip output folder instead of a job")
    cleanup_apply.add_argument("--outputs-root", default="outputs", help="Folder containing saved jobs")
    cleanup_apply.add_argument("--digest", required=True, help="Digest printed by cleanup-plan")
    cleanup_apply.add_argument("--keep-video-dir", default="", help="Copy the final, branded and language videos here (verified) before cleanup")

    lang_out = sub.add_parser("language-outputs", help="Add the English intro/outro and render Hindi/Odia editions into render/")
    lang_out.add_argument("job_id")
    lang_out.add_argument("--outputs-root", default="outputs", help="Folder containing saved jobs")
    lang_out.add_argument("--explain", action="store_true",
                          help="Only report, per language, whether its video exists and what is missing (no render)")
    lang_out.add_argument("--recover-picture", action="store_true",
                          help="If the clean picture is missing, copy it from the finished video (may include its burned captions)")
    # 7.0.107: a longer reviewed narration no longer dead-ends at the old 25% limit.
    lang_out.add_argument("--fit-max-tempo", type=float, default=None,
                          help="Fastest pitch-preserving narration speed accepted when fitting a longer script (default 1.12)")
    lang_out.add_argument("--fit-hold", type=float, default=None,
                          help="Seconds of cloned last frame allowed at the end to fit a long narration (default 0 = never)")
    # 7.0.109: the burned transcript is a per-language choice, changeable after the first render.
    lang_out.add_argument("--transcript", dest="transcript", action=argparse.BooleanOptionalAction, default=None,
                          help="Burn the transcript into every extra edition (--no-transcript removes it). "
                               "Odia is off by default; changing this re-renders only the languages that changed.")
    lang_out.add_argument("--transcript-off", default="", metavar="LANG",
                          help="Comma-separated extra languages to render WITHOUT a transcript, e.g. or,hi")
    lang_out.add_argument("--transcript-on", default="", metavar="LANG",
                          help="Comma-separated extra languages to render WITH a transcript, e.g. hi")

    rd = sub.add_parser("render", help="Render accepted takes")
    rd.add_argument("job_id")
    rd.add_argument("--quality", default="fast", choices=["preview", "fast", "standard", "high"])
    rd.add_argument("--voiceover", dest="voiceover_enabled", action=argparse.BooleanOptionalAction, default=None)
    rd.add_argument("--text-cards", dest="text_cards_enabled", action=argparse.BooleanOptionalAction, default=None)
    rd.add_argument("--text-card-style", choices=["auto", "bold", "playful", "clean"], default=None)
    rd.add_argument("--caption-display", choices=["auto", "full", "none"], default=None)
    rd.add_argument("--background-music", choices=["off", "auto", "local", "browser", "generated", "reliable"], default=None)
    rd.add_argument("--background-music-path", default=None)
    rd.add_argument("--music-volume", type=float, default=None)
    rd.add_argument("--sound-effects", dest="sound_effects_enabled", action=argparse.BooleanOptionalAction, default=None)
    rd.add_argument("--ambience", dest="ambience_enabled", action=argparse.BooleanOptionalAction, default=None)

    au = sub.add_parser("audit", help="Audit shot density, provider fallbacks and observed credit use")
    au.add_argument("job_id")

    rc = sub.add_parser("refresh-cards",
                        help="Re-draft a saved job's cards and hooks from its saved narration (no TTS, no Flow credits)")
    rc.add_argument("job_id")
    rc.add_argument("--outputs-root", default="outputs", help="Folder containing saved jobs")
    rc.add_argument("--language", action="append", default=[], choices=["en", "hi", "or"],
                    help="Only this language; repeat for more than one (default: every saved language)")
    rc.add_argument("--cleanup", default="delete-after-read", choices=["keep", "delete-after-read"],
                    help="Whether the Gemini Web chat stays in the browser (default: delete after reading)")

    ms = sub.add_parser("music-suggest", help="Recommended royalty-free tracks per video type, with licences")
    ms.add_argument("--content-type", default="", choices=["", "education", "motivation", "documentary",
                                                            "technology", "kids", "travel", "business"],
                    help="Video type to recommend for (default: the whole catalogue)")
    ms.add_argument("--theme", action="append", default=[], choices=["calm", "motivation", "upbeat",
                                                                    "cinematic", "technology"],
                    help="Theme tag; repeat for more than one")
    ms.add_argument("--limit", type=int, default=6)
    ms.add_argument("--sources", action="store_true", help="Explain where to download from and the licence terms")
    ms.add_argument("--playbook", action="store_true",
                    help="What to look for in this video type, and the exact pages to download from")
    ms.add_argument("--json", action="store_true", help="Machine-readable output")

    mc = sub.add_parser("music-check", help="Check a downloaded track and print the music_library entry to fill in")
    mc.add_argument("file")

    ga = sub.add_parser("graphics-audit",
                        help="Explain why text cards or hooks did (or did not) appear, and check the finished video")
    ga.add_argument("job_id")
    ga.add_argument("--outputs-root", default="outputs", help="Folder containing saved jobs")
    ga.add_argument("--check", action="store_true",
                    help="Sample the finished video now and update production/graphics_audit.json")
    ga.add_argument("--json", action="store_true", help="Print the stored audit JSON instead of a summary")

    gs = sub.add_parser("gemini-shots",
                        help="Choose which 0-4 AI video shots Gemini Web generates instead of Flow")
    gs.add_argument("job_id")
    gs.add_argument("--outputs-root", default="outputs", help="Folder containing saved jobs")
    gs.add_argument("--choose", default="", metavar="SHOT_ID",
                    help="Comma-separated shot ids to hand to Gemini, e.g. shot_003,shot_007 (max 4)")
    gs.add_argument("--clear", action="store_true",
                    help="Forget the saved choice and go back to the first N eligible shots")
    gs.add_argument("--json", action="store_true", help="Print the full plan as JSON")

    tn = sub.add_parser("tune", help="Adjust music ducking, fades and the edition narration fit of a saved job")
    tn.add_argument("job_id")
    tn.add_argument("--outputs-root", default="outputs", help="Folder containing saved jobs")
    tn.add_argument("--duck-ratio", type=float, default=None, help="Music compression ratio under speech, 1-20 (default 12 = about 13 dB)")
    tn.add_argument("--duck-threshold", type=float, default=None, help="Sidechain threshold 0-0.5 (default 0.02)")
    tn.add_argument("--duck-release-ms", type=int, default=None, help="How fast the music returns (default 550)")
    tn.add_argument("--music-fade-in", type=float, default=None, help="Seconds of music fade-in (default 1.0)")
    tn.add_argument("--music-fade-out", type=float, default=None, help="Seconds of music fade-out (default 2.5)")
    tn.add_argument("--sfx-gain", type=float, default=None, help="Sound-effect level 0-1 (default 0.65)")
    tn.add_argument("--fit-max-tempo", type=float, default=None,
                    help="Fastest narration speed for a longer language script (default 1.12)")
    tn.add_argument("--fit-hold", type=float, default=None,
                    help="Seconds of cloned last frame allowed to fit a long language script (default 0)")
    tn.add_argument("--show", action="store_true", help="Only print the values this job uses")

    a = sub.add_parser("associate", help="Assisted mode: map a downloaded clip to a shot")
    a.add_argument("job_id")
    a.add_argument("shot_id")
    a.add_argument("file")

    sub.add_parser("queue", help="List jobs")
    sub.add_parser("doctor", help="Diagnose Flow browser setup (no browser launched)")
    sub.add_parser("env-doctor", help="Check environment-file discovery and provider variables (values hidden)")
    sub.add_parser("browser-test", help="Launch bundled Chromium with progressive "
                   "flag sets and report what works (takes a few minutes)")
    eb = sub.add_parser("extension-bridge", help="Run localhost bridge for Chrome companion extension")
    eb.add_argument("--host", default="127.0.0.1")
    eb.add_argument("--port", type=int, default=8765)
    ep = sub.add_parser("extension-prompt", help="Queue one prompt to the signed-in Flow Chrome tab")
    ep.add_argument("prompt")
    ep.add_argument("--aspect", default="9:16", choices=["9:16", "16:9"])
    ep.add_argument("--model", default="")
    ep.add_argument("--review", action="store_true", help="insert prompt but do not click Generate")

    mo = sub.add_parser("movieflow-open", help="Open persistent MovieFlow Studio browser for one-time manual login/project setup")
    mo.add_argument("--project-url", default="")

    go = sub.add_parser("gemini-open", help="Open persistent Gemini browser for one-time manual Google login and web-script setup")

    fo = sub.add_parser("flow-open", help="Open a persistent visible Flow browser without any Chrome extension")
    fo.add_argument("--browser", default="bundled", choices=["auto", "bundled", "cdp", "system"])
    fo.add_argument("--cdp-url", default="")

    fi = sub.add_parser("flow-inspect", help="Open Flow and save current UI screenshot/text diagnostics")
    fi.add_argument("--browser", default="bundled", choices=["auto", "bundled", "cdp", "system"])
    fi.add_argument("--cdp-url", default="")

    fd = sub.add_parser("flow-direct", help="Send one prompt directly to Flow via Playwright; no extension/API")
    fd.add_argument("prompt")
    fd.add_argument("--aspect", default="9:16", choices=["9:16", "16:9"])
    fd.add_argument("--model", default="", help="Visible Flow model label. If omitted, uses a credit-safe default instead of premium Quality.")
    fd.add_argument("--duration", type=int, default=None, choices=[4, 6, 8, 10], help="requested clip length in seconds; economy defaults to 10s, otherwise 8s")
    fd.add_argument("--economy", action="store_true", help="credit-saving mode: Gemini Omni Flash 360p + 10s default")
    fd.add_argument("--approval", default="once", choices=["once", "always", "manual"],
                    help="Agent credit confirmation: once=Approve, always=Always approve (persistent), manual=do not click")
    fd.add_argument("--max-generation-credits", type=int, default=None,
                    help="safety cap for one Agent generation; defaults to 10 in --economy, 20 otherwise")
    fd.add_argument("--count", type=int, default=1, choices=[1, 2, 3, 4], help="number of video variations")
    fd.add_argument("--project", default="AutoVideoAI")
    fd.add_argument("--browser", default="bundled", choices=["auto", "bundled", "cdp", "system"])
    fd.add_argument("--cdp-url", default="")
    fd.add_argument("--review", action="store_true", help="fill the prompt but do not click Generate")
    fd.add_argument("--download", default="", help="optional output .mp4 path; waits for generation and downloads")

    cl = sub.add_parser("clip", help="Create Opus-style vertical highlights from a local video or permitted URL")
    cl.add_argument("input", help="local video path or YouTube/video URL")
    cl.add_argument("--output", default="outputs/clips", help="output folder")
    cl.add_argument("--count", type=int, default=3, help="maximum non-overlapping highlights; fewer valid moments return an explicit partial result")
    cl.add_argument("--min-seconds", type=float, default=25)
    cl.add_argument("--max-seconds", type=float, default=55)
    cl.add_argument("--caption-provider", default="auto", choices=["auto", "groq", "local"])
    cl.add_argument("--ranking-provider", default="auto",
                    choices=["auto", "gemini-hybrid", "gemini-api-hybrid",
                             "gemini-web-hybrid", "gemini", "groq", "local"],
                    help="gemini-hybrid tries API, then visible Gemini browser, then Groq/local")
    cl.add_argument("--gemini-model", default="",
                    help="optional Gemini video-analysis model; defaults to GEMINI_CLIP_MODEL/GEMINI_SCRIPT_MODEL")
    cl.add_argument("--gemini-chat-cleanup", default="delete-after-read",
                    choices=["keep", "delete-after-read"],
                    help="cleanup policy for temporary Gemini browser clip-analysis chats")
    cl.add_argument("--source-rights", default="unknown",
                    choices=["unknown", "own_content", "written_permission", "licensed_content",
                             "creative_commons", "public_domain", "commentary_or_review",
                             "private_draft_only"],
                    help="required rights/licence declaration for URL input; stored in highlights.json")
    cl.add_argument("--rights-confirmed", action="store_true",
                    help="legacy compatibility flag; prefer the specific --source-rights declaration")
    cl.add_argument("--background-music", default="",
                    help="optional local music file; omit it to let the selected Internet/local source find a track")
    cl.add_argument("--background-music-enabled", action=argparse.BooleanOptionalAction, default=None,
                    help="explicit optional music switch; --background-music-enabled without a path searches Pixabay by default")
    cl.add_argument("--background-music-source", default="pixabay",
                    choices=["pixabay", "local", "auto", "generated", "reliable"],
                    help="music source when enabled without a local path (default: Pixabay Internet search)")
    cl.add_argument("--music-mood", default="soft ambient instrumental",
                    help="short search phrase for Internet/local music selection")
    cl.add_argument("--music-source-url", default="",
                    help="optional source/attribution page for a user-supplied local music file")
    cl.add_argument('--show-channel-logo', action=argparse.BooleanOptionalAction, default=False)
    cl.add_argument('--channel-logo-path', default='')
    cl.add_argument('--channel-logo-size', type=float, default=.12)
    cl.add_argument('--channel-logo-position', choices=['top-right','top-left','bottom-right','bottom-left'], default='top-right')
    cl.add_argument("--language", choices=['en','hi','or'],default='en')
    cl.add_argument("--music-license", default="none",
                    choices=["none", "own", "youtube_audio_library",
                             "royalty_free_licensed", "creative_commons"],
                    help="deprecated legacy provenance field; music selection no longer requires an acknowledgement")
    cl.add_argument("--music-volume", type=float, default=0.08,
                    help="background music gain from 0.0 to 0.35 (default 0.08)")
    cl.add_argument('--music-failure-policy', choices=['stop', 'continue-original'], default='stop',
                    help='Explicit fallback for optional music; retain original audio if retrieval fails')
    recover_clips = sub.add_parser('clip-recover', help='Render exact saved highlight indices locally, preserving existing clips')
    recover_clips.add_argument('--folder', default='outputs/my-clips')
    recover_clips.add_argument('--indices', nargs='+', type=int, default=[4, 5])
    recover_clips.add_argument('--selection')
    recover_clips.add_argument('--source')
    recover_clips.add_argument('--language', default='hi')
    recover_clips.add_argument('--framing', choices=['face-crop','fit'], default='face-crop')
    recover_clips.add_argument('--dry-run', action='store_true')
    clf = sub.add_parser("clip-config", help="Create highlights from a simple YAML input file")
    clf.add_argument("config", help="path to clip_config.yaml or a copy of it")
    cl.add_argument("--framing", choices=["face-crop", "fit"], default="face-crop",
                    help="fit preserves the complete source frame; face-crop uses a static face estimate")
    for command in ("production-init", "production-check", "production-repair"):
        review = sub.add_parser(command, help="Post-render review and local scene repair")
        review.add_argument("job_id")
        if command == "production-check":
            review.add_argument("--model", default="", help="Optional Gemini vision API model ID")
            review.add_argument("--max-model-calls", type=int, default=0,
                                help="Explicit API call budget; default zero")
        if command == "production-repair":
            review.add_argument("--plan", required=True)
    source_in = sub.add_parser('source-import', help='Import untrusted pasted text/public allowlisted article without generation')
    source_in.add_argument('--url', default='')
    source_in.add_argument('--feed', action='store_true', help='Import up to 10 items from the chosen public RSS URL')
    source_in.add_argument('--text-file', default='')
    source_in.add_argument('--title', default='')
    source_in.add_argument('--output-root', default='data/content/inbox')
    source_in.add_argument('--brief-output', default='', help='new text file for an external writer')
    chars = sub.add_parser('character-create', help='Create an original fictional character identity contract')
    chars.add_argument('--name', required=True); chars.add_argument('--description', required=True)
    chars.add_argument('--reference', action='append', default=[]); chars.add_argument('--original-confirmed', action='store_true')
    chars.add_argument('--library-root', default='data/content/characters')
    rec = sub.add_parser('recreate-clip', help='Create a review-gated AI character recreation plan; submits no generation')
    rec.add_argument('clip'); rec.add_argument('--character-id', required=True)
    rec.add_argument('--library-root', default='data/content/characters'); rec.add_argument('--transcript-file', default='')
    rec.add_argument('--language', choices=['en','hi','or'], default='en')
    rec.add_argument('--source-rights', default='unknown');rec.add_argument('--adaptation-confirmed', action='store_true')
    rec.add_argument('--max-credits', type=int, default=50);rec.add_argument('--background-music', default='')
    approve = sub.add_parser('approve-recreation', help='Approve the exact storyboard/identity/budget; no generation')
    approve.add_argument('job_id')
    tpl = sub.add_parser('longform-template', help='Create a local chapter/evidence template')
    tpl.add_argument('--topic', required=True);tpl.add_argument('--language', default='en');tpl.add_argument('--output',required=True)
    exp = sub.add_parser('export-delivery', help='Encode a destination copy and manual upload packet; no publishing')
    exp.add_argument('video');exp.add_argument('--folder',required=True)
    exp.add_argument('--destination', required=True, choices=['instagram_reel','facebook_reel','youtube_short','youtube_long'])
    exp.add_argument('--language', choices=['en','hi','or'], default='en');exp.add_argument('--title',default='')
    exp.add_argument('--caption',default='');exp.add_argument('--description',default='')
    exp.add_argument('--hashtags',default='',help='Space-separated hashtags, e.g. "#Odia #Gardening"')
    exp.add_argument('--chapters',default='',help='Optional multiline YouTube chapter text')
    exp.add_argument('--source-url',action='append',default=[],help='Reviewed HTTPS attribution URL; repeat for multiple sources')
    exp.add_argument('--category',default='')
    exp.add_argument('--framing',choices=['fit','crop'],default='fit')
    metrics=sub.add_parser('metrics-import',help='Import owned-account analytics JSON; does not scrape social sites')
    metrics.add_argument('input');metrics.add_argument('--output',required=True)
    profile_cmd = sub.add_parser('channel-profile', help='Save a reusable channel identity with local media snapshots')
    profile_cmd.add_argument('--name', required=True); profile_cmd.add_argument('--name-hi',default=''); profile_cmd.add_argument('--name-or',default='')
    profile_cmd.add_argument('--logo',default=''); profile_cmd.add_argument('--intro',default=''); profile_cmd.add_argument('--outro',default='')
    profile_cmd.add_argument('--music',default='');profile_cmd.add_argument('--music-license',default='')
    finish_plan = sub.add_parser('finish-plan', help='Plan independent language editions from an existing clip/video')
    finish_plan.add_argument('source'); finish_plan.add_argument('--profile',default='',help='One channel profile for all selected languages')
    for language in ('en','hi','or'):
        finish_plan.add_argument('--profile-'+language,default='',help='Actual channel profile for '+language)
    finish_plan.add_argument('--shared-music',default='',help='Reviewed local music for all editions')
    finish_plan.add_argument('--shared-music-license',default='',help='Source and permission of shared music')
    finish_plan.add_argument('--languages',default='en',help='Comma-separated en,hi,or');finish_plan.add_argument('--rights',default='own_content')
    finish_edition = sub.add_parser('finish-edition', help='Review exact cards and optional narration/music from local paths')
    finish_edition.add_argument('plan');finish_edition.add_argument('--language',choices=['en','hi','or'],required=True)
    finish_edition.add_argument('--cards',default='',help='JSON array with start, end and text')
    finish_edition.add_argument('--narration',default='');finish_edition.add_argument('--music',default='');finish_edition.add_argument('--music-license',default='')
    finish_edition.add_argument('--approve',action='store_true')
    finish_render = sub.add_parser('finish-render', help='Render one approved language edition locally without changing its source')
    finish_render.add_argument('plan');finish_render.add_argument('--language',choices=['en','hi','or'],required=True)
    args = ap.parse_args(argv)
    # v7.0.100: `outputs/<id>`, `outputs/<id>/`, `outputs/outputs/<id>` and absolute paths are reduced to the
    # bare id the Factory expects. A reference that resolves to nothing is passed on untouched, so offline
    # commands keep working and job-loading commands report the friendly message instead of a traceback.
    if getattr(args, 'job_id', None):
        from engine.job_ref import normalize_job_id
        args.job_id = normalize_job_id(args.job_id, getattr(args, 'outputs_root', None) or 'outputs')

    if args.cmd in ('channel-profile','finish-plan','finish-edition','finish-render'):
        from engine import finishing_studio as finish
        if args.cmd == 'channel-profile':
            print(finish.save_profile(args.name, names={'hi':args.name_hi,'or':args.name_or},
                  logo=args.logo,intro=args.intro,outro=args.outro,music=args.music,music_license=args.music_license))
        elif args.cmd == 'finish-plan':
            selected={lang:(getattr(args,'profile_'+lang) or args.profile) for lang in args.languages.split(',')}
            print(finish.create_plan(args.source,selected,languages=args.languages.split(','),source_rights=args.rights,
                  shared_music=args.shared_music or None,shared_music_license=args.shared_music_license))
        elif args.cmd == 'finish-edition':
            cards=json.loads(open(args.cards,encoding='utf8').read()) if args.cards else None
            print(finish.set_edition(args.plan,args.language,cards=cards,narration=args.narration or None,
                  music=args.music or None,music_license=args.music_license,reviewed=args.approve))
        else:
            print(finish.render(args.plan,args.language,progress=lambda p:print(f'{p:.0%} complete',flush=True)))
        return

    if args.cmd == "support-report":
        from engine.support_report import resolve_job_dir, write_support_report
        try:
            job_dir = resolve_job_dir(args.outputs_root, args.job_id)
            report_path = write_support_report(job_dir, args.output)
        except (ValueError, OSError) as exc:
            raise SystemExit(f"Diagnostic export failed: {exc}") from exc
        print(f"Redacted diagnostic report: {report_path}")
        print("No browser opened and no generation submitted. Review this JSON before sharing; never send .env or browser profiles.")
        return

    if args.cmd == "language-outputs":
        import json as _json
        from engine.language_editions import edition_diagnosis, render_language_outputs
        from engine.production_lock import production_slot
        from engine.support_report import resolve_job_dir
        job_dir = resolve_job_dir(args.outputs_root, args.job_id)
        if getattr(args, "explain", False):
            # 7.0.95: read-only. Names the language and the one action that unblocks it.
            print(_json.dumps(edition_diagnosis(job_dir), indent=2, ensure_ascii=False))
            return
        # 7.0.109: apply the transcript choice before rendering; only changed languages re-render.
        choices = {}
        for code in [x.strip() for x in str(getattr(args, "transcript_off", "") or "").split(",") if x.strip()]:
            choices[code] = False
        for code in [x.strip() for x in str(getattr(args, "transcript_on", "") or "").split(",") if x.strip()]:
            choices[code] = True
        if args.transcript is not None or choices:
            from engine.language_editions import set_transcript, transcript_plan
            try:
                set_transcript(job_dir, default=args.transcript, languages=choices)
            except ValueError as error:
                raise SystemExit("Transcript choice not saved: " + str(error)) from error
            print("Transcript: " + _json.dumps(transcript_plan(job_dir)["editions"]))
        fit_policy = {}
        if getattr(args, "fit_max_tempo", None) is not None:
            fit_policy["max_tempo"] = float(args.fit_max_tempo)
        if getattr(args, "fit_hold", None) is not None:
            fit_policy["allow_hold"] = float(args.fit_hold) > 0
            fit_policy["hold_cap"] = float(args.fit_hold) if float(args.fit_hold) > 0 else 20.0
        with production_slot(job_dir):
            report = render_language_outputs(job_dir,
                progress=lambda label, pct, detail="": print(f"[{int(pct):3d}%] {label} {detail}".rstrip()),
                allow_recovered_picture=bool(getattr(args, "recover_picture", False)),
                fit_policy=fit_policy or None)
        print(_json.dumps(report, indent=2, ensure_ascii=False))
        return

    if args.cmd in ("cleanup-plan", "cleanup-apply"):
        import json as _json
        from engine import post_job_cleanup as _pjc
        from engine.support_report import resolve_job_dir
        if bool(args.job_id) == bool(args.clip_folder):
            raise SystemExit("Give exactly one of a job id or --clip-folder")
        try:
            if args.clip_folder:
                target, kind = args.clip_folder, "clip"
            else:
                target, kind = resolve_job_dir(args.outputs_root, args.job_id), "job"
            if args.cmd == "cleanup-plan":
                plan = _pjc.plan_clip_folder(target) if kind == "clip" else _pjc.plan_job(target)
                print(_json.dumps({k: v for k, v in plan.items() if k != "files"}, indent=2))
                print(f"Reviewed digest: {plan['digest']}  (nothing deleted; run cleanup-apply with this digest)")
                return
            report = _pjc.apply_plan(target, args.digest, kind=kind, keep_video_dir=args.keep_video_dir or None)
        except (ValueError, OSError) as exc:
            raise SystemExit(f"Cleanup stopped: {exc}") from exc
        print(_json.dumps(report, indent=2))
        return

    f = Factory()
    from engine.runtime_log import timestamp_prefix
    cb = lambda s, p, i="": print(f"{timestamp_prefix()} [{int(p):3d}%] {s} {i}".rstrip())
    if args.cmd == 'source-import':
        from engine.source_inbox import SourceInbox
        inbox = SourceInbox(args.output_root)
        if bool(args.url) == bool(args.text_file):
            ap.error('Choose exactly one --url or --text-file')
        if args.feed:
            if not args.url or args.text_file:
                ap.error('--feed requires --url and no --text-file')
            print(json.dumps(inbox.feed(args.url),indent=2,ensure_ascii=False));return
        item = inbox.fetch(args.url) if args.url else inbox.paste(Path(args.text_file).read_text(encoding='utf-8'),title=args.title)
        if args.brief_output:
            with open(args.brief_output,'x',encoding='utf-8') as output:
                output.write(inbox.brief_prompt(item))
        print(json.dumps(item,indent=2,ensure_ascii=False));return
    elif args.cmd == 'character-create':
        from engine.content_library import CharacterLibrary
        print(json.dumps(CharacterLibrary(args.library_root).create(args.name,args.description,reference_files=args.reference,
                         original_confirmed=args.original_confirmed),indent=2,ensure_ascii=False));return
    elif args.cmd == 'recreate-clip':
        from engine.clip_recreation import create_recreation_job
        text = Path(args.transcript_file).read_text(encoding='utf-8') if args.transcript_file else ''
        print(json.dumps(create_recreation_job(f,args.clip,args.character_id,library_root=args.library_root,
                         transcript_text=text,language=args.language,source_rights=args.source_rights,
                         adaptation_confirmed=args.adaptation_confirmed,max_credits=args.max_credits,
                         background_music=args.background_music),indent=2));return
    elif args.cmd == 'approve-recreation':
        from engine.clip_recreation import approve_recreation
        print(json.dumps(approve_recreation(f,args.job_id),indent=2));return
    elif args.cmd == 'longform-template':
        from engine.content_plan import longform_template
        with open(args.output,'x',encoding='utf-8') as output:
            json.dump(longform_template(args.topic,args.language),output,indent=2,ensure_ascii=False)
        print('Template written; fill and approve it before importing.');return
    elif args.cmd == 'export-delivery':
        from engine.publishing import export_delivery
        print(json.dumps(export_delivery(
                         args.video,args.folder,args.destination,language=args.language,
                         title=args.title,framing=args.framing,caption=args.caption,
                         description=args.description,hashtags=args.hashtags,chapters=args.chapters,
                         source_urls=args.source_url,category=args.category),indent=2,ensure_ascii=False));return
    elif args.cmd == 'metrics-import':
        from engine.publishing import import_metrics
        print(json.dumps(import_metrics(args.output,json.loads(Path(args.input).read_text(encoding='utf-8'))),indent=2));return
    if args.cmd.startswith("production-"):
        from engine.production import init_review, check_job, stage_repairs
        root = f.pm.job_dir(args.job_id)
        if args.cmd == "production-init":
            result = init_review(root)
        elif args.cmd == "production-check":
            result = check_job(root, args.model, args.max_model_calls, cb)
        else:
            result = stage_repairs(root, args.plan)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    elif args.cmd == 'clip-recover':
        import subprocess
        command = [sys.executable, str(Path(__file__).resolve().parent / 'tools/recover_remaining_clips.py'),
                   '--folder', args.folder, '--indices', *map(str, args.indices),
                   '--language', args.language, '--framing', args.framing]
        for key in ('selection', 'source'):
            if getattr(args,key): command += ['--'+key, getattr(args,key)]
        if args.dry_run: command += ['--dry-run']
        raise SystemExit(subprocess.run(command).returncode)
    elif args.cmd == "clip-config":
        import yaml
        from engine.clipping import create_highlight_clips
        with open(args.config, encoding="utf-8") as handle:
            clip_cfg = yaml.safe_load(handle) or {}
        allowed = {
            "source", "output", "count", "min_seconds", "max_seconds",
            "caption_provider", "ranking_provider", "source_rights",
            "background_music", "music_license", "music_volume", "gemini_model",
            "gemini_chat_cleanup", "framing", "language", "background_music_enabled",
            "background_music_source", "music_mood", "background_music_source_url", "music_failure_policy",
            "show_channel_logo", "channel_logo_path", "channel_logo_text", "channel_logo_palette", "channel_logo_size", "channel_logo_position",
            "task", "segment_seconds", "transcript", "transcript_path", "captions_enabled",
        }
        unknown = sorted(set(clip_cfg) - allowed)
        if unknown:
            ap.error("Unknown clip config option(s): " + ", ".join(unknown))
        if not str(clip_cfg.get("source") or "").strip():
            ap.error("clip config requires a non-empty source")
        if clip_cfg.get('show_channel_logo') and str(clip_cfg.get('channel_logo_text') or '').strip():
            from engine.brand_logo import text_logo
            clip_cfg['channel_logo_path']=text_logo(clip_cfg['channel_logo_text'],clip_cfg.get('channel_logo_palette','Ocean'))
        transcript_data=None
        if clip_cfg.get('transcript_path'):
            with open(clip_cfg['transcript_path'],encoding='utf-8') as handle: transcript_data=json.load(handle)
        if clip_cfg.get('task','highlights') in ('convert','split'):
            from engine.local_video_edits import edit_video
            result=edit_video(str(clip_cfg['source']),str(clip_cfg.get('output') or 'outputs/local-edits'),
                mode=clip_cfg['task'],seconds=clip_cfg.get('segment_seconds',30),
                framing=clip_cfg.get('framing','face-crop'),transcript=clip_cfg.get('transcript','none'),
                language=clip_cfg.get('language','en'),transcript_data=transcript_data,
                caption_provider=clip_cfg.get('caption_provider','auto'),music_path=clip_cfg.get('background_music',''),
                music_volume=clip_cfg.get('music_volume',.08),show_channel_logo=clip_cfg.get('show_channel_logo',False),
                channel_logo_path=clip_cfg.get('channel_logo_path',''),channel_logo_size=clip_cfg.get('channel_logo_size',.12),
                channel_logo_position=clip_cfg.get('channel_logo_position','top-right'),
                source_rights=clip_cfg.get('source_rights','unknown'),progress_cb=cb)
            print(result['summary']);print('Edit report:',result['report_path'])
            for path in result['outputs']:print('  ',path)
            return
        if clip_cfg.get('task','highlights')!='highlights':ap.error('Unknown Clip Studio task')
        result = create_highlight_clips(
            str(clip_cfg["source"]), str(clip_cfg.get("output") or "outputs/my-clips"),
            language=clip_cfg.get('language','en'), captions_enabled=clip_cfg.get('captions_enabled',True),
            reviewed_transcript=transcript_data, background_music_enabled=clip_cfg.get('background_music_enabled'),
            show_channel_logo=clip_cfg.get('show_channel_logo',False),
            channel_logo_path=str(clip_cfg.get('channel_logo_path') or ''),
            channel_logo_size=clip_cfg.get('channel_logo_size',.12),
            channel_logo_position=str(clip_cfg.get('channel_logo_position') or 'top-right'),
            count=int(clip_cfg.get("count", 3)),
            min_seconds=float(clip_cfg.get("min_seconds", 25)),
            max_seconds=float(clip_cfg.get("max_seconds", 55)),
            caption_provider=str(clip_cfg.get("caption_provider") or "auto"),
            ranking_provider=str(clip_cfg.get("ranking_provider") or "auto"),
            source_rights=str(clip_cfg.get("source_rights") or "unknown"),
            background_music=str(clip_cfg.get("background_music") or ""),
            music_license=str(clip_cfg.get("music_license") or "none"),
            background_music_source=str(clip_cfg.get("background_music_source") or "pixabay"),
            music_mood=str(clip_cfg.get("music_mood") or "soft ambient instrumental"),
            background_music_source_url=str(clip_cfg.get("background_music_source_url") or ""),
            music_failure_policy=str(clip_cfg.get('music_failure_policy') or 'stop'),
            music_volume=float(clip_cfg.get("music_volume", 0.08)),
            gemini_model=str(clip_cfg.get("gemini_model") or ""),
            framing=str(clip_cfg.get("framing") or "face-crop"),
            gemini_chat_cleanup=str(clip_cfg.get("gemini_chat_cleanup") or "delete-after-read"),
            progress_cb=lambda message, pct, info="": cb(message, pct, info))
        print("Highlights report:", os.path.join(
            str(clip_cfg.get("output") or "outputs/my-clips"), "highlights.json"))
        for path in result["outputs"]:
            print("  ", path)
    elif args.cmd == "clip":
        from engine.clipping import create_highlight_clips
        result = create_highlight_clips(
            args.input, args.output, count=args.count,
            min_seconds=args.min_seconds, max_seconds=args.max_seconds,
            caption_provider=args.caption_provider, rights_confirmed=args.rights_confirmed,
            ranking_provider=args.ranking_provider,
            source_rights=args.source_rights, language=args.language,
            show_channel_logo=args.show_channel_logo, channel_logo_path=args.channel_logo_path,
            channel_logo_size=args.channel_logo_size, channel_logo_position=args.channel_logo_position,
            background_music_enabled=args.background_music_enabled,
            background_music=args.background_music,
            music_license=args.music_license,
            background_music_source=args.background_music_source,
            music_mood=args.music_mood,
            background_music_source_url=args.music_source_url,
            music_failure_policy=args.music_failure_policy,
            music_volume=args.music_volume,
            gemini_model=args.gemini_model,
            framing=args.framing,
            gemini_chat_cleanup=args.gemini_chat_cleanup,
            progress_cb=lambda message, pct, info="": cb(message, pct, info))
        print("Highlights report:", os.path.join(args.output, "highlights.json"))
        for path in result["outputs"]:
            print("  ", path)
    elif args.cmd == "create":
        aspect = "9:16" if args.video_type == "shorts" else "16:9"
        job = f.create_job(args.topic, args.video_type, args.duration, aspect, external_video_mode=args.external_video_mode,
                            voice=args.voice, language=args.language, destination=args.destination,
                            speech_cards_enabled=args.speech_cards_enabled, gemini_video_count=args.gemini_video_count,
                            flow_auto_cleanup_images=args.flow_auto_cleanup_images,
                            approved_plan_path=args.approved_plan_path, narration_input_path=args.narration_input_path,
                            character_id=args.character_id, character_ids=args.character_ids, content_type=args.content_type, tone=args.tone,
                            preset=args.preset, profile=args.profile,
                            cartoon_provider=args.cartoon_provider,
                            movieflow_mode=args.movieflow_mode,
                            movieflow_project_url=args.movieflow_project_url,
                            movieflow_wait_seconds=args.movieflow_wait_seconds,
                            movieflow_recovery_wait_seconds=args.movieflow_recovery_wait_seconds,
                            budgets={"MAX_CREDITS_PER_VIDEO": args.max_credits,
                                     "MAX_RETRIES_PER_SHOT": args.max_retries},
                            dry_run=args.dry_run,
                            tts_provider=args.tts_provider,
                            script_provider=args.script_provider,
                            script_model=args.script_model,
                            script_quality=args.script_quality,
                            tts_model=args.tts_model,
                            tts_voice=args.tts_voice,
                            tts_style=args.tts_style,
                            caption_provider=args.caption_provider,
                            caption_model=args.caption_model,
                            caption_local_model=args.caption_local_model,
                            caption_align_script=args.caption_align_script,
                            max_tts_speedup=args.max_tts_speedup,
                            auto_retime_script=args.auto_retime_script,
                            render_quality=args.render_quality,
                            production_mode=args.production_mode,
                            dynamic_video_scenes=args.dynamic_video_scenes,
                            stock_scenes=args.stock_scenes, stock_source=args.stock_source,
                            caption_display=args.caption_display, background_music=args.background_music,
                            music_mood=args.music_mood, channel_name=args.channel_name, channel_logo=args.channel_logo,
                            graphics_overlays=args.graphics_overlays, watermark=args.watermark,
                            voiceover_enabled=args.voiceover_enabled, text_cards_enabled=args.text_cards_enabled,
                            text_card_style=args.text_card_style, background_music_path=args.background_music_path,
                            music_volume=args.music_volume, sound_effects_enabled=args.sound_effects_enabled,
                            ambience_enabled=args.ambience_enabled,
                            images_per_shot=args.images_per_shot,
                            video_share=args.video_share, stock_share=args.stock_share,
                            flow_scenes=args.flow_scenes, max_flow_scenes=args.max_flow_scenes, frame_source=args.frame_source,
                            flow_image_workers=args.flow_image_workers,
                            flow_video_mode=args.flow_video_mode,
                            flow_approval=args.flow_approval,
                            max_generation_credits=args.max_generation_credits,
                            shot_max_seconds=args.shot_max_seconds,
                            flow_frame_retries=args.flow_frame_retries,
                            network_wait_seconds=args.network_wait_seconds,
                            flow_capacity_wait_seconds=args.flow_capacity_wait_seconds,
                            flow_capacity_retries=args.flow_capacity_retries,
                            flow_image_wait_seconds=args.flow_image_wait_seconds or 60,
                            flow_project_url=args.flow_project_url,
                            flow_video_retries=args.flow_video_retries,
                            flow_video_ready_grace_seconds=args.flow_video_ready_grace_seconds,
                            flow_video_recovery_wait_seconds=args.flow_video_recovery_wait_seconds,
                            flow_reuse_project_media=args.flow_reuse_project_media,
                            flow_reuse_mode=args.flow_reuse_mode,
                            flow_pause_on_unresolved_request=args.flow_pause_on_unresolved_request)
        print("JOB:", job)
        if args.plan_only:
            print("(plan-only created the job configuration only; run 'v3 resume' to execute script/TTS/media generation)")
            return
        print(_run_and_record(f, job, cb))
    elif args.cmd == "create-config":
        import yaml
        from engine.studio_config import load_video_config, config_to_factory_kwargs
        cfg = load_video_config(args.config)
        kwargs = config_to_factory_kwargs(cfg)
        job = f.create_job(topic=cfg["topic"], video_type=cfg["video_type"],
                           aspect=cfg["aspect"], **kwargs)
        resolved = os.path.join(f.pm.job_dir(job), "input_config.resolved.yaml")
        with open(resolved, "w", encoding="utf-8") as fh:
            yaml.safe_dump({k: v for k, v in cfg.items() if k not in ("config_source", "production_mode_engine")},
                           fh, sort_keys=False, allow_unicode=True)
        settings_path = os.path.join(f.pm.job_dir(job), "settings.json")
        settings = json.load(open(settings_path, encoding="utf-8"))
        settings.update({"theme": cfg["theme"], "studio_production_mode": cfg["production_mode"],
                         "config_source": cfg["config_source"]})
        with open(settings_path, "w", encoding="utf-8") as fh:
            json.dump(settings, fh, indent=2)
        print("JOB:", job)
        print("Resolved configuration:", resolved)
        if args.plan_only or cfg.get("plan_only"):
            print(f"Resume later: python3 cli.py v3 resume {job}")
            return
        print(_run_and_record(f, job, cb))
    elif args.cmd == "themes":
        from engine.studio_config import THEMES
        for name, values in THEMES.items():
            print(f"{name:24s} {values}")
    elif args.cmd == "dashboard":
        import subprocess
        raise SystemExit(subprocess.call([
            sys.executable, "-m", "streamlit", "run", os.path.join(os.path.dirname(__file__), "app.py"),
            "--server.port", str(args.port)]))
    elif args.cmd == "archive-request":
        from engine.flow_request_archive import archive_uncertain_request
        code, lines = archive_uncertain_request(
            Path(f.pm.job_dir(args.job_id)) / args.image, args.confirm_new_credit_spend)
        print("\n".join(lines))
        raise SystemExit(code)
    elif args.cmd == "resume":
        if args.flow_submission_cap is not None:
            from engine.flow_submit_guard import write_job_cap
            write_job_cap(f.pm.job_dir(args.job_id), args.flow_submission_cap, confirmed_by='cli-resume')
            print(f'Flow submission cap confirmed for this job: {args.flow_submission_cap}')
        if args.replace_unresolved_images:
            print('Image replacement is not available during Resume in v7.0.71; the request is recovered without a replacement image.')
        if args.replace_unresolved_images is not None or args.image_replacement_limit is not None:
            cfg=f._settings(args.job_id)
            f.set_flow_image_replacement(args.job_id,
                False,
                args.image_replacement_limit if args.image_replacement_limit is not None else cfg.get('flow_image_replacement_limit',30))
        if args.local_closing_fallback is not None:
            f.set_flow_local_closing_fallback(args.job_id, args.local_closing_fallback)
        if args.continue_on_unresolved_frames is not None:
            f.set_flow_frame_batch_recovery(args.job_id, args.continue_on_unresolved_frames)
        if args.gemini_chat_cleanup is not None:
            f.set_gemini_cleanup(args.job_id, args.gemini_chat_cleanup)
        if args.flow_image_wait_seconds is not None:
            print('Flow image wait set to %d s for this job.'
                  % f.set_flow_image_wait_seconds(args.job_id, args.flow_image_wait_seconds))
        if args.flow_pause_on_unresolved_request is not None:
            f.set_flow_pause_on_unresolved_request(
                args.job_id, args.flow_pause_on_unresolved_request)
        print(_run_and_record(f, args.job_id, cb))
    elif args.cmd == "approve-request":
        print(f.approve_flow_request(args.job_id, shot_id=args.shot_id or None,
                                     confirm_credits=args.confirm_credits,
                                     wait_seconds=args.wait_seconds, inspect_only=args.inspect))
    elif args.cmd == "recover-flow-video":
        print(f.recover_flow_video(args.job_id, shot_id=args.shot_id or None,
                                   wait_seconds=args.wait_seconds,
                                   allow_latest=args.allow_latest,
                                   asset_url=args.asset_url, asset_reviewed=args.asset_reviewed,
                                   auto_approve=bool(args.auto_approve)))
    elif args.cmd == "gemini-open":
        from engine.providers.gemini_web import GeminiWebBrowser
        b = GeminiWebBrowser()
        try:
            b.ensure_session(visible_login_seconds=600)
            print("Gemini web is ready:", getattr(b._page, "url", "https://gemini.google.com/app"))
            print("Login/profile is persisted. Press Ctrl+C when setup is complete.")
            try:
                while True:
                    import time as _time
                    _time.sleep(60)
            except KeyboardInterrupt:
                pass
        finally:
            b.close()
    elif args.cmd == "movieflow-open":
        from engine.providers.movieflow_browser import MovieFlowBrowser
        b = MovieFlowBrowser()
        try:
            b.ensure_session(visible_login_seconds=600)
            url = b.ensure_project("AutoVideoAI-MovieFlow", project_url=args.project_url or None)
            print("MovieFlow Studio ready:", url or b.current_project_url() or getattr(b._page, "url", ""))
            print("Keep the browser open if using CDP, or press Ctrl+C after login/setup is complete.")
            try:
                while True:
                    import time as _time
                    _time.sleep(60)
            except KeyboardInterrupt:
                pass
        finally:
            b.close()
    elif args.cmd == "backups":
        from engine.render_backup import backup_root, inventory, restore
        root = backup_root(args.outputs)
        print(f"Render backups: {root}\n"
              "Finished job videos are moved here before a job folder is deleted "
              "(AUTOVIDEO_RENDER_BACKUP_DIR overrides this folder).")
        rows = inventory(root)
        if not rows:
            print("No backed-up videos yet.")
        for row in rows:
            print(f"  {row['job']} · {len(row['files'])} video(s) · {row['bytes']/1024**2:.0f} MB · {row['folder']}")
            for row_file in row['files']:
                print(f"     {row_file['name']} · {row_file['bytes']/1024**2:.0f} MB")
        if args.restore:
            report = restore(root, args.restore, outputs=args.outputs)
            print(json.dumps(report, indent=2))
            if report.get('warning'):
                raise SystemExit(1)
    elif args.cmd == "flow-projects":
        from engine.flow_projects_cli import run_flow_projects
        raise SystemExit(run_flow_projects(f, args))
    elif args.cmd == "flow-project":
        from engine.providers.flow_browser import FlowBrowser
        url = FlowBrowser.normalize_project_url(args.url)
        if not url:
            raise SystemExit("Invalid Flow project URL. Expected https://flow.google.com/project/<uuid>")
        # Persist in both DB and per-job settings so the binding survives resume
        # even if the DB is later rebuilt from the output folder.
        settings_path = os.path.join(f.pm.job_dir(args.job_id), "settings.json")
        cfg = {}
        if os.path.exists(settings_path):
            with open(settings_path, encoding="utf-8") as fh:
                cfg = json.load(fh)
        cfg["flow_project_url"] = url
        with open(settings_path, "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2)
        f.db.upsert(args.job_id, flow_project=url)
        f.pm.log(args.job_id, "flow_project_bound_manual", {"url": url})
        print(f"Bound {args.job_id} -> {url}")
    elif args.cmd == "status":
        from engine.project.manager import ProjectManager
        m = ProjectManager().load_manifest(args.job_id)
        row = f.db.get(args.job_id) or {}
        print(f"{m.job_id}\n  status={m.status} profile={m.profile} shots={len(m.shots)} accepted={m.accepted_count()}"
              + (f"\n  flow_project={row.get('flow_project')}" if row.get("flow_project") else ""))
        # v7.0.103: "planned" does not say whether work is in progress; the production lock does.
        try:
            from engine.job_activity import describe as describe_activity, job_activity
            for line in describe_activity(job_activity(f.pm.job_dir(args.job_id))):
                print('  ' + line if not line.startswith('  ') else line)
        except Exception as error:
            print(f"  (activity unknown: {type(error).__name__})")
        try:
            missing = f.flow_project_missing_record(args.job_id)
            if missing:
                print("  LAST PROJECT ERROR: " + f.flow_project_missing_message(
                    args.job_id, missing.get('project_url', ''), missing.get('role', 'video')))
        except Exception:
            pass
        try:
            bindings = f.flow_project_bindings(args.job_id)
            if bindings.get('stills_project') or bindings.get('video_project'):
                print(f"  stills_project={bindings.get('stills_project') or '(not bound)'}"
                      + (f" · {bindings['stills_source']}" if bindings.get('stills_source') else ''))
                print(f"  video_project={bindings.get('video_project') or '(not bound)'}"
                      + (f" · {bindings['video_source']}" if bindings.get('video_source') else ''))
                if bindings.get('conflict'):
                    print('  CONFLICT: stills and video share one Flow project; video generation is refused. '
                          f'Run: python3 cli.py v3 flow-projects {args.job_id}')
        except Exception:
            pass
        try:
            from engine.flow_approval_once import audit_rows, auto_allowed, clicks_for
            rows = audit_rows(f.pm.job_dir(args.job_id))
            allowed, why = auto_allowed(f._settings(args.job_id))
            print(f"  flow_approvals: {len(rows)} clicked here (one per request; {why})")
            for row in rows[-5:]:
                journal = str(row.get('journal') or '')
                print(f"    {journal.rsplit('/', 1)[-1]} · {row.get('cost')} credits · "
                      f"{row.get('clicks_after', 0)}/1 · {row.get('at', '')}")
        except Exception:
            pass
        for s in m.shots:
            print(f"  {s.shot_id} {s.status} {s.media_strategy} {s.provider}/{s.model} "
                  f"est={s.estimated_credits}cr takes={len(s.takes)} retries={s.retry_count}")
        pause = f.pause_state(args.job_id)
        if pause and (m.status in ("paused", "assisted") or not pause.get("resolved")):
            print("\nPAUSE / RECOVERY GUIDANCE")
            # v7.0.105: describe the CURRENT state, not the saved snapshot (which named shot_014 while the
            # production had moved to shot_018, and counted 13/45 while the manifest held 17).
            try:
                guidance = f.recovery_state(args.job_id) or {}
            except Exception:
                guidance = {}
            for line in pause_guidance_lines(pause, guidance):
                print(line)
    elif args.cmd == "refresh-cards":
        import json as _json
        from engine.job_monitor import is_running
        from engine.speech_cards import refresh_saved_cards
        from engine.support_report import resolve_job_dir
        job_dir = resolve_job_dir(getattr(args, "outputs_root", None) or "outputs", args.job_id)
        if not job_dir.is_dir():
            raise SystemExit(f"No saved job at {job_dir}. Pass the job id exactly as it appears in outputs/.")
        if is_running(job_dir):
            raise SystemExit("This job is still running. Wait for it to finish, then refresh its cards.")
        report = refresh_saved_cards(job_dir, languages=args.language or None, cleanup=args.cleanup,
                                     progress=lambda label, pct, detail="": print(f"[{int(pct):3d}%] {label} {detail}".rstrip()))
        print(_json.dumps(report, indent=2, ensure_ascii=False))
        return
    elif args.cmd == "music-suggest":
        import json as _json
        from engine.audio.music_catalog import (SAFE_SOURCES, credit_block, playbook, recommend, theme_tags,
                                                VIDEO_TYPES)
        guide = playbook(args.content_type)
        tracks = recommend(args.content_type, args.theme or None, args.limit)
        if args.json:
            print(_json.dumps({"schema": "music-catalogue-v1", "video_types": VIDEO_TYPES,
                               "recommended": tracks, "credit_block": credit_block(tracks),
                               "library_tags": theme_tags(args.content_type),
                               "playbook": guide, "sources": SAFE_SOURCES}, indent=2, ensure_ascii=False))
            return
        if args.playbook:
            for kind, row in guide.items():
                print(f"{VIDEO_TYPES.get(kind, kind)}  ({kind})")
                print(f"  Sound: {row['mood']}  ·  {row['bpm']}")
                for platform, url, why in row["start"]:
                    print(f"  - {platform}: {url}")
                    print(f"      {why}")
                print(f"  Avoid: {row['avoid']}")
                print()
            print("Download into music_library/, then run: python3 cli.py v3 music-check <file>")
            return
        heading = VIDEO_TYPES.get(args.content_type, "every video type") if args.content_type else "every video type"
        print(f"Royalty-free music for {heading}")
        if not tracks:
            print("  No catalogue entry matches that combination; run with --sources to browse the libraries.")
        for track in tracks:
            need = "credit required" if track["attribution"] == "required" else "no credit needed"
            print(f"  {track['title']} - {track['artist']}  [{track['licence']}, {need}]")
            print(f"      {track['platform']} · {track['url']}")
            print(f"      search: {track['search']} · themes: {', '.join(track['themes'])}")
            print(f"      {track['notes']}")
        block = credit_block(tracks)
        if block:
            print("\nPaste this in the video description when you use these tracks:")
            print(block)
        print("\nImport them into the library with tags: " + ", ".join(theme_tags(args.content_type))
              + "  (Create > Music library, or set AUTOVIDEO_MUSIC_LIBRARY)")
        if args.sources:
            print("\nWhere to download, and the terms:")
            for source in SAFE_SOURCES:
                print(f"  {source['name']} - {source['url']}")
                print(f"      licence: {source['licence']}")
                print(f"      attribution: {source['attribution']}")
                print(f"      Content ID: {source['content_id']}")
                print(f"      {source['notes']}")
        print("\nRe-check the licence page before publishing; terms change. Full guide: docs/MUSIC_LIBRARY.md")
        return
    elif args.cmd == "music-check":
        import json as _json
        from pathlib import Path as _Path
        import hashlib as _hashlib
        path = _Path(args.file).expanduser().resolve()
        if not path.is_file():
            raise SystemExit(f"No file at {path}. Pass the path of the downloaded track.")
        from engine.flow_music import validate_audio
        try:
            validate_audio(str(path))
        except Exception as error:
            raise SystemExit(f"{path.name} is not a usable audio track: {error}")
        digest = _hashlib.sha256(path.read_bytes()).hexdigest()
        print(_json.dumps({"file": path.name, "size": path.stat().st_size, "sha256": digest,
                           "import": {"title": "<track title>", "tags": "<calm|motivation|upbeat|cinematic|technology>",
                                      "source_url": "<https:// page you downloaded from>",
                                      "license": "<exact licence, e.g. CC BY 4.0 or Pixabay Content License>"},
                           "next": "Upload it in Create > Music library (it writes manifest.json), or copy it into "
                                   "music_library/ and add this entry to music_library/manifest.json."},
                          indent=2, ensure_ascii=False, default=str))
        return
    elif args.cmd == "graphics-audit":
        import json as _json
        from engine.graphics_audit import _read, explain, write as write_graphics_audit
        from engine.support_report import resolve_job_dir
        job_dir = resolve_job_dir(getattr(args, "outputs_root", None) or "outputs", args.job_id)
        if not job_dir.is_dir():
            raise SystemExit(f"No saved job at {job_dir}. Pass the job id exactly as it appears in outputs/.")
        if args.check:
            from engine.graphics_audit import plan_path
            overlays = _read(plan_path(job_dir), []) or []
            masters = sorted((job_dir / "render").glob("*-final*.mp4"), key=lambda p: p.stat().st_mtime,
                             reverse=True)
            if not masters:
                raise SystemExit(f"No finished video in {job_dir / 'render'}. Render the job first, then run this again.")
            from engine.render.graphic_visibility import verify
            verified = verify(masters[0], overlays)
            report = _read(job_dir / "production" / "graphics_audit.json")
            if report:
                report["verified_in_video"] = verified
                write_graphics_audit(job_dir, report)
            print(f"Checked {verified.get('checked', 0)} card(s) in {masters[0].name}; "
                  f"{len(verified.get('missing') or [])} not visible.")
        if args.json:
            stored = _read(job_dir / "production" / "graphics_audit.json")
            print(_json.dumps(stored, indent=2, ensure_ascii=False) if stored else
                  _json.dumps({"error": "no production/graphics_audit.json yet; render the job or run with --check"},
                              indent=2))
            return
        print(explain(job_dir))
    elif args.cmd == "gemini-shots":
        from engine.providers.gemini_video import choose_shots, gemini_shot_plan
        from engine.support_report import resolve_job_dir
        job_dir = resolve_job_dir(args.outputs_root, args.job_id)
        manifest = f.pm.load_manifest(args.job_id)
        shots = list(getattr(manifest, "shots", []) or [])
        cap = int((f._settings(args.job_id) or {}).get("gemini_video_count", 0) or 0)
        try:
            if args.clear:
                plan = choose_shots(job_dir, shots, [])
                print("Saved Gemini choice cleared; the job will use its first eligible shots.")
            elif args.choose:
                ids = [x.strip() for x in args.choose.split(",") if x.strip()]
                plan = choose_shots(job_dir, shots, ids)
                print("Gemini will generate: " + (", ".join(plan["chosen"]) or "nothing") +
                      "  (saved to " + plan["selection_file"] + ", no request submitted)")
            else:
                plan = gemini_shot_plan(job_dir, shots, cap)
        except ValueError as error:
            raise SystemExit("Gemini shots not changed: " + str(error)) from error
        if args.json:
            print(json.dumps(plan, indent=2, ensure_ascii=False))
            return
        print(f"Job cap: {plan['cap'] or 0} shot(s) via Gemini · choice: {plan['source']}")
        if plan["chosen"]:
            print("Gemini now generates: " + ", ".join(plan["chosen"]))
        for row in plan["shots"]:
            mark = "*" if row["shot_id"] in plan["chosen"] else " "
            print(f" {mark} {row['shot_id']:10s} {row['reason']:48s} {row['prompt'][:70]}")
        if plan["dropped"]:
            print("Left out because they are no longer eligible: " + ", ".join(plan["dropped"]))
        print("Change it with: python3 cli.py v3 gemini-shots " + args.job_id +
              " --choose shot_003,shot_007   (or --clear). Nothing is submitted until the job runs.")
        return
    elif args.cmd == "tune":
        import json as _json
        updates = {"music_duck_ratio": args.duck_ratio, "music_duck_threshold": args.duck_threshold,
                   "music_duck_release_ms": args.duck_release_ms, "music_fade_in": args.music_fade_in,
                   "music_fade_out": args.music_fade_out, "sfx_gain": args.sfx_gain,
                   "edition_fit_max_tempo": args.fit_max_tempo,
                   "edition_fit_hold_seconds": args.fit_hold}
        updates = {key: value for key, value in updates.items() if value is not None}
        if args.show or not updates:
            print(_json.dumps(f.tuning_report(args.job_id), indent=2, ensure_ascii=False))
        else:
            print(_json.dumps(f.set_tuning_options(args.job_id, **updates), indent=2, ensure_ascii=False))
        return
    elif args.cmd == "audit":
        m = f.pm.load_manifest(args.job_id)
        ds = [float(x.duration_target or 0) for x in m.shots]
        planned = {}
        actual = {}
        fallbacks = []
        for sh in m.shots:
            planned[sh.media_strategy] = planned.get(sh.media_strategy, 0) + 1
            ap = sh.actual_provider or sh.provider or "unknown"
            actual[ap] = actual.get(ap, 0) + 1
            if sh.fallback_reason:
                fallbacks.append((sh.shot_id, sh.provider, ap, sh.fallback_reason))
        print(f"Job: {m.job_id}")
        print(f"Target: {m.target_seconds}s | shots: {len(m.shots)} | accepted: {m.accepted_count()}")
        if ds:
            print(f"Shot duration: avg={sum(ds)/len(ds):.1f}s max={max(ds):.1f}s")
            if max(ds) > 15:
                print("WARNING: visual shots are too long for normal long-form pacing; create a new v4.1 job or use --shot-max-seconds 8")
        print(f"Planned strategies: {planned}")
        if m.dry_run:
            print("Actual providers: NOT EXECUTED (dry run; provider names in the manifest are only planned routes)")
            print("Observed/recorded credits: 0 (dry run)")
        else:
            print(f"Actual providers: {actual}")
            print(f"Observed/recorded credits: {sum(int(x.credits_spent or 0) for x in m.shots)}")
        frame_sources = {}
        for sh in m.shots:
            for src in (getattr(sh, 'opening_frame_source', ''), getattr(sh, 'closing_frame_source', '')):
                if src:
                    frame_sources[src] = frame_sources.get(src, 0) + 1
        if frame_sources:
            print(f"Frame sources: {frame_sources}")
        print(f"Fallbacks: {len(fallbacks)}")
        for row in fallbacks[:12]:
            print(f"  {row[0]}: {row[1]} -> {row[2]} | {row[3][:140]}")
        gs = os.path.join(f.pm.job_dir(args.job_id), "generation_summary.json")
        if os.path.exists(gs):
            print("Generation summary:", gs)
    elif args.cmd == "render":
        from engine.presentation import PRESENTATION_KEYS
        edits = {key: getattr(args, key) for key in PRESENTATION_KEYS
                 if hasattr(args, key) and getattr(args, key) is not None}
        if edits:
            f.set_presentation_options(args.job_id, **edits)
        print(f.render_job(args.job_id, quality=args.quality, progress_cb=cb))
    elif args.cmd == "associate":
        print(f.associate_download(args.job_id, args.shot_id, args.file))
    elif args.cmd == "queue":
        from engine.project.database import JobDB
        for j in JobDB().list():
            print(f"{j['job_id'][:44]} {j['status']:10s} {j['profile']:16s} +{j['accepted_shots']}/-{j['rejected_shots']} est={j['est_credits']}")
    elif args.cmd == "doctor":
        from engine.providers.flow_browser import doctor_report
        print(doctor_report())
    elif args.cmd == "env-doctor":
        print(format_environment_report(_ENV_REPORT))
    elif args.cmd == "extension-bridge":
        from engine.bridge.server import run
        run(args.host, args.port)
    elif args.cmd == "extension-prompt":
        from engine.providers.flow_extension import FlowExtensionClient
        c = FlowExtensionClient()
        try:
            print("Bridge:", c.health())
        except Exception as e:
            raise SystemExit(f"Bridge is not running: {e}. Start: python3 cli.py v3 extension-bridge")
        tid = c.enqueue_scene(args.prompt, aspect=args.aspect, model_hint=args.model, auto_generate=not args.review)
        print("Queued:", tid)
        print("Keep https://flow.google.com/ open in Chrome with the AutoVideoAI companion extension enabled.")
    elif args.cmd == "flow-open":
        os.environ["FLOW_BROWSER_MODE"] = args.browser
        if args.cdp_url:
            os.environ["FLOW_CDP_URL"] = args.cdp_url
        from engine.providers.flow_browser import FlowBrowser
        b = FlowBrowser()
        try:
            b.ensure_session(visible_login_seconds=600)
            print(f"Flow browser ready: {b.active_browser}")
            print("Log in if needed. This profile is persistent, so the login is reused next time.")
            input("Press ENTER when you are finished with the Flow browser... ")
        finally:
            b.close()
    elif args.cmd == "flow-inspect":
        os.environ["FLOW_BROWSER_MODE"] = args.browser
        if args.cdp_url:
            os.environ["FLOW_CDP_URL"] = args.cdp_url
        from engine.providers.flow_browser import FlowBrowser
        b = FlowBrowser()
        try:
            b.ensure_session(visible_login_seconds=600)
            print(f"Browser: {b.active_browser}")
            path = b.snapshot_failure("flow-inspect", "ui", Exception("manual UI inspection"))
            print("Saved screenshot:", path)
            print("Saved UI text:", path[:-4] + ".json")
            try:
                print("URL:", b._page.url)
                print("TITLE:", b._page.title())
            except Exception:
                pass
            input("Press ENTER when you are finished inspecting Flow... ")
        finally:
            b.close()
    elif args.cmd == "flow-direct":
        os.environ["FLOW_BROWSER_MODE"] = args.browser
        if args.cdp_url:
            os.environ["FLOW_CDP_URL"] = args.cdp_url
        from engine.providers.flow_browser import FlowBrowser, FlowUIChanged
        b = FlowBrowser()
        try:
            b.ensure_session(visible_login_seconds=600)
            print(f"Browser: {b.active_browser}")
            print("[1/5] Entering or creating a Flow project...")
            b.ensure_project(args.project)
            print("[2/5] Detecting the current Flow editor and preparing VIDEO generation...")
            effective_duration = args.duration if args.duration is not None else (10 if args.economy else 8)
            effective_model = args.model or ("Gemini Omni Flash 360p" if args.economy else "Veo 3.1 - Lite")
            credit_cap = args.max_generation_credits if args.max_generation_credits is not None else (10 if args.economy else 20)
            if args.economy:
                print(f"[Flow] ECONOMY mode: {effective_model}, {effective_duration}s, one output; credit guard <= {credit_cap} credits.")
            strategy = b.prepare_text_video(
                aspect=args.aspect, model_label=effective_model, duration=effective_duration, count=args.count
            )
            print(f"[Flow] Editor strategy: {strategy}")
            if strategy == "agent":
                print("[Flow] Flow Agent is active. Video/orientation/model instructions will be sent as natural language; obsolete Text-to-Video tabs are not used.")
            elif strategy == "standard":
                print("[Flow] Migrated standard editor configured through its settings panel.")
            print(f"[3/5] Requested: aspect={args.aspect}, duration={effective_duration}s, count={args.count}, model={effective_model}")
            print("[4/5] Inserting the video instruction/prompt...")
            b.fill_text_video_prompt(
                args.prompt, strategy, aspect=args.aspect, model_label=effective_model,
                duration=effective_duration, count=args.count
            )
            if args.review:
                print("[5/5] Prompt inserted. Review mode is ON; nothing was submitted and no credits should be spent by this command.")
                input("Press ENTER after you finish reviewing in Flow... ")
            else:
                print("[5/5] Submitting to Flow...")
                b.submit_prepared_text_video(strategy)
                print("Prompt submitted.")
                if strategy == "agent":
                    print("[Flow] Waiting briefly for the Agent's credit confirmation, if your account requires one...")
                    clicked = b.confirm_agent_generation(timeout_s=25, approval=args.approval, max_credits=credit_cap)
                    info = getattr(b, "last_agent_confirmation", {}) or {}
                    if clicked:
                        cost = info.get("cost")
                        print(f"[Flow] Agent confirmation clicked: {info.get('clicked') or 'Approve'}" + (f" ({cost} credits shown by Flow)." if cost is not None else "."))
                    elif info.get("blocked"):
                        print(f"[Flow] Generation NOT approved: {info.get('reason', 'blocked by safety policy')}. The browser is left open for review.")
                    else:
                        print(f"[Flow] Confirmation was not clicked: {info.get('reason', 'none detected')}. Generation may already be running if Flow did not require approval.")
                if args.download:
                    if strategy == "agent":
                        print("Warning: automatic download from the expanded Agent UI is not reliable yet. The video will remain saved in the Flow project; --download is skipped in Agent mode in v3.6.")
                    else:
                        ok = b.wait_for_generation()
                        if not ok:
                            raise SystemExit("Flow did not report completion before timeout or reported a generation failure.")
                        out = b.download_generation(0, args.download)
                        print("Downloaded:", out)
                else:
                    info = getattr(b, "last_agent_confirmation", {}) or {}
                    if strategy == "agent" and info.get("blocked"):
                        input("Generation is paused at Flow confirmation. Review it in the browser, then press ENTER to close this session... ")
                    else:
                        input("Generation started (or Flow is processing the request). Press ENTER when you are finished with this Flow session... ")
        except FlowUIChanged as e:
            snap = b.snapshot_failure(args.project, "flow-direct", e)
            print(f"Flow UI changed or a control was not found: {e}")
            print(f"Diagnostic screenshot: {snap}")
            print(f"Diagnostic UI dump: {snap[:-4]}.json")
            raise
        finally:
            b.close()
    elif args.cmd == "browser-test":
        from engine.providers.flow_browser import browser_self_test
        print("Probing bundled Chromium (up to ~4 min, watch for windows popping up)...")
        r = browser_self_test()
        for i, v in enumerate(r.get("variants", []), 1):
            mark = "PASS" if v["ok"] else "FAIL"
            print(f"[{mark}] {i}. {v['name']}\n     {v['detail']}"
                  + (f"  (shot: {v['screenshot']})" if v.get("screenshot") else ""))
        print("\nVERDICT:", r.get("verdict", "?"))




def _run_and_record(f, job_id, progress_cb):
    """Run a job from the CLI and record its automatic-resume state, as the Studio job thread does."""
    from engine.auto_resume import after_run
    result = f.run_job(job_id, progress_cb=progress_cb)
    try:
        after_run(f, job_id, result)
    except Exception as error:  # the run result is still returned; the record is best-effort
        print(f"[auto-resume] could not record state for {job_id}: {type(error).__name__}: {error}")
    return result


from engine.automation import (create_video_from_topic, bulk_create_from_csv,
                               fetch_trending_topics, prepare_flow_shots)


def main():
    ap = argparse.ArgumentParser(description="Auto Video AI - free CLI")
    ap.add_argument("--topic", help="Video topic")
    ap.add_argument("--type", dest="video_type", default="shorts",
                    choices=["shorts", "faceless_youtube", "explainer", "marketing"])
    ap.add_argument("--duration", type=int, default=45)
    ap.add_argument("--voice", default="en-IN-NeerjaNeural")
    ap.add_argument("--tone", default="exciting")
    ap.add_argument("--watermark", default="")
    ap.add_argument("--visual-mode", default="auto",
                    choices=["auto", "flow", "stock", "ai", "kenburns"])
    ap.add_argument("--ai-provider", default="veo",
                    choices=["veo", "seedance", "fal", "comfy"])
    ap.add_argument("--caption-style", default="wordpop", choices=["wordpop", "classic"])
    ap.add_argument("--no-music", action="store_true")
    ap.add_argument("--bulk", help="Path to topics CSV for bulk mode")
    ap.add_argument("--shot-list", help="Only prepare script + Flow shot list for TOPIC (no video)")
    ap.add_argument("--trending", type=int, default=0, help="Auto-create N videos from trending topics")
    ap.add_argument("--outdir", default="outputs")
    args = ap.parse_args()

    def cb(stage, pct):
        print(f"[{pct:3d}%] {stage}")

    if args.shot_list:
        r = prepare_flow_shots(args.shot_list, args.video_type, args.duration, args.tone, args.outdir)
        print(f"\n📋 {len(r['shots'])} shots ready: {r['shot_list_md']}")
        print("Next: paste prompts into Flow → save clips to assets/flow_clips/ → rerun with --visual-mode flow")
        return

    if args.bulk:
        print(f"📦 Bulk mode: {args.bulk} (visual={args.visual_mode})")
        results = bulk_create_from_csv(args.bulk, args.outdir, cb, args.visual_mode, args.ai_provider)
        for r in results:
            print(("✅ " + r["video"]) if "video" in r else f"❌ {r}")
        return

    if args.trending:
        topics = fetch_trending_topics(args.trending)
        print(f"🔥 Trending: {topics}")
        for t in topics:
            r = create_video_from_topic(t, args.video_type, args.duration, args.voice,
                                        args.tone, args.watermark, args.outdir,
                                        args.visual_mode, args.ai_provider,
                                        args.caption_style, not args.no_music, progress_cb=cb)
            print("✅", r["video"], f"[{r['visual_used']}]")
        return

    if not args.topic:
        ap.error("Provide --topic, --bulk, --shot-list, or --trending")
    r = create_video_from_topic(args.topic, args.video_type, args.duration, args.voice,
                                args.tone, args.watermark, args.outdir,
                                args.visual_mode, args.ai_provider,
                                args.caption_style, not args.no_music, progress_cb=cb)
    print("\n🎉 VIDEO READY:", r["video"])
    print(f"Title: {r['title']} | {r['duration']:.0f}s | {r['size']} | visuals: {r['visual_used']} | AI cost: ${r['cost_usd']:.2f}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "v3":
        from engine.routing.provider_router import NeedsDecision
        try:
            main_v3(sys.argv[2:])
        except NeedsDecision as exc:
            print(f"PAUSED: {exc}")
            for action in exc.alternatives:
                print(f"Next action: {action}")
            raise SystemExit(2)
    else:
        main()

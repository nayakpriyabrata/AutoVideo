# v7.0.37 · blank-tab and recurring reference recovery

## What the attached run shows

The same Debanshi and location references were successfully attached through shot 4, then refused by a saved lifetime reattachment allowance. The pause occurred before prompt submission, preserving credits and saved frames. A paused job may retain a browser/session for recovery; an open browser does not imply generation continues.

Separately, page/guard recovery created new tabs and did not close them when navigation raised. Repeated failures could accumulate about:blank tabs. This source defect is fixed and reproduced using repeated failed-navigation tests. The screenshot confirms accumulated blank tabs but does not identify why the original navigation failed.

## Changes

- Failed project, isolated worker and guard navigation closes the tab created by that attempt, retaining the previous target.
- Startup in AutoVideoAI's owned persistent profile removes restored about:blank tabs and prefers a surviving project. User-owned CDP tabs are not pruned.
- Exact reference upload recovery is bounded to one reattachment per failure episode. Verified composer attachment resets the allowance for later scenes. Merely sending a file does not reset it.
- Older spent reservations receive one remediation under the new protocol; repeated failed uploads still pause.
- Prepared character photo hashes move into a local folder name, keeping the uploaded filename short. Upload aliases retain their content hash. Original approved photos and saved frames are unchanged. A short alias may require uploading the same local reference again; it does not regenerate it or authorize paid generation.
- Composer chip detection includes common accessible Close/Remove media labels.

## Upgrade and resume this existing job

Stop Studio and CLI jobs, then close the AutoVideoAI browser once before migration. Keep v7.0.36 until the new installation and job are verified. From the unzipped v7.0.37 folder:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.36 . --apply
python3 cli.py v3 resume 20261010-141959-7-morning-habits-that-ca-40b7
```

Resume retains cached frames and checks any pending request before submitting. It can continue normal generation for scenes that have not yet been submitted, within your existing budget. Uncertain videos remain download-only.

Do not delete journals or manually replace asset signatures. No new flags are needed. Existing accepted free-provider images remain saved and require likeness review; the patch does not silently replace them.

## Limits

The supplied logs also contain Pollinations HTTP 402 Payment Required responses and earlier Chromium download closures. This patch does not add payment or bypass provider pricing. Failure cleanup prevents tab accumulation but cannot guarantee Chromium or Google navigation never fails. Live WSL/Flow verification remains necessary; no live account generation was used for testing this build.

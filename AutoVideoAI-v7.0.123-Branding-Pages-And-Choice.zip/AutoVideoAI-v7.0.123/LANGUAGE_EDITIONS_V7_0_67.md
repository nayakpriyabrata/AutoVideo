# AutoVideoAI 7.0.67 · one master script, selected language editions

## What changed

Guided Studio now asks for language scope before script drafting.

- **Master script + primary video language** controls the one script Gemini drafts and the first rendered edition.
- **Additional language editions** is optional. Choose neither, one, or both remaining languages.
- The approved master keeps one story, factual structure, scene order and visual plan across editions.
- Each additional narration is localized as natural spoken language and shown for review before TTS.
- The exact reviewed language scripts are saved. A changed master or changed edition selection creates a new review checkpoint.
- One batch prepares all selected voices and measured word timings first. Only after every voice succeeds does Gemini receive a separate timed-card request for each language.

This design does not ask Gemini to invent three unrelated scripts. Hindi and Odia editions may use different word order and phrasing so they sound natural, while preserving the approved meaning and story beats.

## Guided Studio workflow

1. Open **Create → Reels & Long Videos**.
2. Select the **Master script + primary video language**.
3. Under **Additional language editions**, choose zero, one or two extra editions.
4. Draft and approve the one master script in step 2, or import an approved plan.
5. In step 4, click **Prepare selected language scripts for review · no TTS**.
6. Review and edit every localized narration. The master is read-only here because it was approved in step 2.
7. Approve each narration and click **Save reviewed language scripts**.
8. Click **Prepare all selected TTS → then all language text cards**.
9. Listen to every voice, inspect its cards, then approve reuse of the exact batch.
10. Create the production. The primary language drives the shared visual master; selected editions and channel-profile handoffs are saved with the job.

For a single-language video, select no additional editions. Preparing the language scripts makes no Gemini translation request; the already approved master can proceed directly to TTS.

## Safety and review boundaries

- Localization is a draft. A fluent reviewer should verify Hindi and Odia wording, pronunciation and factual equivalence.
- TTS/card preparation creates no Flow images or videos and spends no Flow credits.
- Text cards are anchored to measured word timings from each language voice, so translated editions do not inherit English timestamps.
- If one TTS fails, no language card requests start. Retry the same saved batch after fixing TTS access.
- Selecting three editions can create two localization requests, three TTS operations and three later card requests. The UI starts these from one reviewed workflow, but they remain distinct provider operations.

## Upgrade an existing 7.0.66 installation

Stop the dashboard and ensure no production job is active. Extract the 7.0.67 build beside the existing installation, then run from the existing installation directory:

```bash
python3 ../AutoVideoAI-v7.0.67/tools/update_v766_to_v767.py .
python3 ../AutoVideoAI-v7.0.67/tools/update_v766_to_v767.py . --apply
./dashboard.sh
```

The updater changes code and documentation only. Shared outputs, browser profiles, music, characters and saved jobs are not copied or removed. A timestamped code backup is created under `code-update-backups/`.

## Verification scope

Automated tests verify language selection order, source-script reuse, stale-review invalidation, exact reviewed-script handoff to TTS, all-voices-before-any-cards ordering and existing Channel Desk behavior. Live Gemini Web, TTS accounts and browser UI behavior still require a short account-level smoke test because those services can change independently of this build.

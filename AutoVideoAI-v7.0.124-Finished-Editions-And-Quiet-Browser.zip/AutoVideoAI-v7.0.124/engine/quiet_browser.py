"""Generation with no browser window on screen, on every OS.

Two mechanisms, one setting:

* **Linux / WSL** - a headed browser on a private, hidden X display (``Xvfb``). The display is a
  service: it survives the CLI exiting, and a localhost-only password-protected viewer exposes that
  same display on demand. No browser or profile is restarted by *Show browser*.
* **Windows / macOS** - there is no X server to hide behind, so the headed browser is launched
  **off-screen** (``--window-position=-32000,-32000``) and muted. The window exists - the Google
  session, cookies and downloads all behave exactly as they do visibly, which is the whole point of
  staying headed - but it sits outside the virtual desktop, so it is never seen and never captured by
  a screen share, a recording or a presentation. *Show browser* moves that same window on-screen over
  a loopback-only debugging port, without restarting it; *Hide browser* moves it back.

Both keep the browser **headed**. Nothing here switches a login to headless Chromium, which Google
rejects; quiet mode changes where the window is, never whether the session is real.
"""
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import subprocess
import sys
import time

#: Where a headed window is parked so no display, screen share or screenshot can see it.
OFFSCREEN = -32000

#: Loopback debugging port state, used only to move an already-running hidden window on-screen.
WINDOW_STATE_NAME = 'window.json'


def quiet_enabled(config=None):
    return os.getenv('AUTOVIDEO_QUIET_BROWSER','').lower() in ('1','true','yes') or bool((config or {}).get('quiet'))


def platform():
    """``'linux'``, ``'windows'`` or ``'macos'`` - decides which hiding mechanism quiet mode uses."""
    if sys.platform.startswith('linux'):
        return 'linux'
    if sys.platform == 'darwin':
        return 'macos'
    if os.name == 'nt':
        return 'windows'
    return sys.platform or 'unknown'


def uses_virtual_display():
    """True where quiet mode hides the browser on a private X display instead of moving it away."""
    return platform() == 'linux' and os.path.exists('/proc')


def _root():
    root=Path.home()/'.local/share/autovideoai/quiet-browser'
    root.mkdir(parents=True,exist_ok=True);root.chmod(0o700)
    return root


def _live(pid, token):
    """Is this recorded process still ours? POSIX reads /proc; elsewhere the OS is asked by pid."""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if uses_virtual_display():
        try:
            path=Path('/proc')/str(pid)
            return path.stat().st_uid==os.getuid() and token.encode() in (path/'cmdline').read_bytes()
        except (OSError,ValueError,TypeError):return False
    try:
        if os.name == 'nt':
            out = subprocess.run(['tasklist', '/FI', 'PID eq ' + str(pid), '/NH'],
                                 capture_output=True, text=True, timeout=10).stdout or ''
            return str(pid) in out
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def _dependencies(names):
    missing=[name for name in names if not shutil.which(name)]
    if missing:raise RuntimeError('Quiet browser dependencies missing: '+', '.join(missing)+
        '. Install: sudo apt install xvfb xauth x11-utils x11vnc tigervnc-viewer. Quiet mode did not open a visible browser.')


def browser_environment():
    """The private hidden X display for a headed Linux/WSL browser (contract unchanged)."""
    if not uses_virtual_display():
        raise RuntimeError('Quiet browser on ' + platform() + ' hides the window off-screen instead of using a '
                           'virtual display; browser_environment() is Linux/WSL only. Quiet mode did not open a '
                           'visible browser.')
    import fcntl
    _dependencies(['Xvfb','xauth','xdpyinfo'])
    root=_root();state_path=root/'display.json';auth=root/'Xauthority'
    with open(root/'service.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        state=json.loads(state_path.read_text()) if state_path.exists() else {}
        if not _live(state.get('pid'),str(auth)):
            display=next((':'+str(n) for n in range(81,100)
                          if not Path('/tmp/.X11-unix/X'+str(n)).exists() and not Path('/tmp/.X'+str(n)+'-lock').exists()),None)
            if not display:raise RuntimeError('No free private X display; Quiet mode did not open a visible browser')
            auth.touch(mode=0o600);auth.chmod(0o600)
            subprocess.run(['xauth','-f',str(auth),'add',display,'.',secrets.token_hex(16)],check=True,
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5)
            with open(root/'display.log','ab') as log:
                process=subprocess.Popen(['Xvfb',display,'-screen','0','1920x1080x24','-nolisten','tcp','-auth',str(auth)],
                                         stdout=log,stderr=log,start_new_session=True)
            state={'pid':process.pid,'display':display}
            state_path.write_text(json.dumps(state));state_path.chmod(0o600)
        env=dict(os.environ);env.pop('WAYLAND_DISPLAY',None)
        env.update(DISPLAY=state['display'],XAUTHORITY=str(auth))
        deadline=time.monotonic()+6
        while time.monotonic()<deadline:
            if subprocess.run(['xdpyinfo'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=2).returncode==0:
                return env
            time.sleep(.1)
        raise RuntimeError('Private X display did not become ready; check quiet-browser/display.log. No visible fallback was launched.')


# --------------------------------------------------------------------------- #
# Windows / macOS: a headed window nobody can see
# --------------------------------------------------------------------------- #
def hidden_window_args():
    """Chromium args that park a headed window outside every display, and mute it.

    Deliberately *not* ``--headless``: Google refuses a headless sign-in, and a headless session also
    loses the downloads and dialogs Flow relies on. An off-screen headed window keeps the real browser
    and the real login, and is simply never on screen.
    """
    return ['--window-position=%d,%d' % (OFFSCREEN, OFFSCREEN),
            '--window-size=1920,1080',
            '--mute-audio',
            '--hide-crash-restore-bubble',
            '--disable-session-crashed-bubble']


def _free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def debug_port_args():
    """Loopback debugging port so *Show browser* can move this window without restarting it.

    Best effort and strictly optional: when no port can be allocated the browser is still hidden, only
    the reveal button loses its handle. Chromium binds this to 127.0.0.1 only.
    """
    try:
        port = _free_port()
    except OSError:
        return [], 0
    return ['--remote-debugging-port=%d' % port, '--remote-debugging-address=127.0.0.1'], port


def launch_plan(config=None, *, record=True):
    """``{'transport', 'args', 'env', 'debug_port'}`` for a quiet launch on this OS.

    Returns ``None`` when quiet mode is off. Never opens a visible window and never silently downgrades
    to headless. ``record=False`` is for short-lived helper browsers (music search) that must not
    overwrite the Flow window handle the *Show browser* button reads.
    """
    if not quiet_enabled(config):
        return None
    if uses_virtual_display():
        return {'transport': 'quiet-x11', 'args': ['--ozone-platform=x11', '--disable-gpu'],
                'env': browser_environment(), 'debug_port': 0}
    args = list(hidden_window_args())
    port = 0
    if record:
        extra, port = debug_port_args()
        args += extra
        if port:
            _save_window_state({'port': port, 'pid': os.getpid(), 'platform': platform(), 'hidden': True,
                                'started_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
    return {'transport': 'quiet-hidden-window', 'args': args, 'env': None, 'debug_port': port}


def fallback_plan(config=None):
    """The same hidden window without the debugging port, if that argument ever breaks a launch."""
    if not quiet_enabled(config) or uses_virtual_display():
        return None
    return {'transport': 'quiet-hidden-window-noport', 'args': list(hidden_window_args()),
            'env': None, 'debug_port': 0}


def _window_state_path():
    return _root() / WINDOW_STATE_NAME


def _save_window_state(state):
    try:
        path = _window_state_path()
        path.write_text(json.dumps(state))
        path.chmod(0o600)
    except OSError:
        pass


def _window_state():
    try:
        path = _window_state_path()
        if not path.is_file():
            return {}
        state = json.loads(path.read_text())
        return state if isinstance(state, dict) else {}
    except (OSError, ValueError):
        return {}


def _set_window_bounds(port, bounds):
    """Move/resize the browser window that owns this loopback debugging port. No restart."""
    from playwright.sync_api import sync_playwright
    with sync_playwright() as playwright:
        browser = playwright.chromium.connect_over_cdp('http://127.0.0.1:%d' % int(port), timeout=10000)
        try:
            session = browser.new_browser_cdp_session()
            targets = (session.send('Target.getTargets', {}) or {}).get('targetInfos') or []
            page = next((t for t in targets if t.get('type') == 'page' and t.get('targetId')), None)
            if page is None:
                raise RuntimeError('The hidden browser has no page to move.')
            window = session.send('Browser.getWindowForTarget', {'targetId': page['targetId']})
            window_id = window.get('windowId')
            if window_id is None:
                raise RuntimeError('Chromium did not report a window for the hidden browser.')
            # A minimized window must leave that state before it accepts a position.
            if (window.get('bounds') or {}).get('windowState') not in (None, 'normal'):
                session.send('Browser.setWindowBounds',
                             {'windowId': window_id, 'bounds': {'windowState': 'normal'}})
            session.send('Browser.setWindowBounds', {'windowId': window_id, 'bounds': bounds})
            return True
        finally:
            try:
                browser.close()
            except Exception:
                pass


def reveal_window():
    """Bring the running hidden window on-screen (Windows/macOS). Returns a status dict."""
    state = _window_state()
    port = state.get('port')
    if uses_virtual_display():
        raise RuntimeError('On Linux/WSL the hidden browser lives on a private X display; use Show browser '
                           '(the VNC viewer) instead of moving a window.')
    if not port:
        raise RuntimeError('No hidden browser window is recorded. Turn on Quiet browser in SETTINGS and start '
                           'a browser job first; the window is only movable while that job runs.')
    try:
        _set_window_bounds(port, {'windowState': 'normal', 'left': 80, 'top': 80,
                                  'width': 1440, 'height': 900})
    except Exception as error:
        raise RuntimeError('The hidden browser could not be revealed (' + ' '.join(str(error).split())[:220] +
                           '). The job is unaffected and keeps running off-screen; restart it to get a '
                           'movable window.') from None
    state.update(hidden=False, revealed_at=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    _save_window_state(state)
    return {'status': 'revealed', 'port': port}


def conceal_window():
    """Send the revealed window back off-screen (Windows/macOS). Returns a status dict."""
    state = _window_state()
    port = state.get('port')
    if uses_virtual_display():
        raise RuntimeError('On Linux/WSL the hidden browser lives on a private X display; closing the viewer '
                           'hides it again.')
    if not port:
        raise RuntimeError('No hidden browser window is recorded yet.')
    _set_window_bounds(port, {'windowState': 'normal', 'left': OFFSCREEN, 'top': OFFSCREEN,
                              'width': 1920, 'height': 1080})
    state.update(hidden=True, concealed_at=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    _save_window_state(state)
    return {'status': 'hidden', 'port': port}


def window_is_revealed():
    """True when a recorded hidden window has been moved on-screen and not sent back."""
    state = _window_state()
    return bool(state.get('port')) and state.get('hidden') is False


def status_text(config=None):
    """One plain sentence for SETTINGS, saying what Quiet browser will do on this OS."""
    if not quiet_enabled(config):
        return 'Quiet browser is off: browser jobs open a visible Chromium window.'
    if uses_virtual_display():
        return ('Quiet browser is on: the headed browser runs on a private hidden X display '
                '(needs Xvfb, xauth, x11-utils; x11vnc + a VNC viewer for Show browser).')
    return ('Quiet browser is on: the headed browser runs off-screen and muted, so no window appears and a '
            'screen share cannot pick it up. Show browser moves that same running window on-screen for a '
            'Google sign-in; Hide browser moves it back. No browser or profile is restarted.')


def show_browser():
    """Reveal the running quiet session for a manual sign-in. Never restarts a browser or profile."""
    if not uses_virtual_display():
        return reveal_window()
    import fcntl
    _dependencies(['x11vnc','vncviewer'])
    root=_root();state_path=root/'display.json'
    if not state_path.exists():raise RuntimeError('No quiet session yet. Enable Quiet browser in Settings and start a browser job first.')
    state=json.loads(state_path.read_text())
    if not _live(state.get('pid'),str(root/'Xauthority')):raise RuntimeError('Quiet display is no longer running; resume the saved job first.')
    with open(root/'viewer.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        password=root/'vnc-password'
        if not password.exists():
            subprocess.run(['x11vnc','-storepasswd',secrets.token_hex(4),str(password)],check=True,
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5)
            password.chmod(0o600)
        vnc_path=root/'viewer.json';vnc=json.loads(vnc_path.read_text()) if vnc_path.exists() else {}
        if not _live(vnc.get('pid'),str(password)):
            with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            env=dict(os.environ);env.update(DISPLAY=state['display'],XAUTHORITY=str(root/'Xauthority'))
            with open(root/'viewer.log','ab') as log:
                process=subprocess.Popen(['x11vnc','-display',state['display'],'-localhost','-rfbauth',str(password),
                    '-rfbport',str(port),'-forever','-shared','-nolookup'],env=env,stdout=log,stderr=log,start_new_session=True)
            vnc={'pid':process.pid,'port':port};vnc_path.write_text(json.dumps(vnc));vnc_path.chmod(0o600)
        subprocess.Popen(['vncviewer','-passwd',str(password),'127.0.0.1::'+str(vnc['port'])],
                         stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)


def hide_browser():
    """Put the quiet session back out of sight after a sign-in."""
    if uses_virtual_display():
        return {'status': 'viewer', 'note': 'Close the VNC viewer window; the browser stays on its hidden display.'}
    return conceal_window()

"""v7.0.103: a stills/video Flow-project collision is explained, repairable, and no longer caused by recovery.

Field case (job 20261022-143856-7-small-daily-habits-tha-9729, 2026-10-27 04:46 IST): a new production run
stopped at the first video shot with

    Video Flow project must differ from storyboard image project

- no project URLs, no file names, no fix;
- the job stayed ``planned``, so it looked like it might still be running.

Root cause: ``recover_flow_video`` bound the *video* project it had just downloaded from through
``_remember_flow_project_url``, which writes the job's **stills** binding (settings ``flow_project_url`` and the
database ``flow_project``). With the video binding already on that project, the next run saw both roles on one
project and refused.

These tests pin: the recovery binds the video role only; the collision message names both roles, the files they
come from and the repair; the job is paused rather than left as "planned"; and ``flow-projects`` inspects and
repairs explicitly (nothing changes without ``--confirm``).

No browser, no Flow request, no credits.
"""
import json
import os
from types import SimpleNamespace

import pytest

from engine import flow_projects_cli as fpc

JOB = '20261022-143856-7-small-daily-habits-tha-9729'
STILLS = 'https://flow.google.com/project/14dbfdef-c5ac-44ff-ac50-37690c93a642'
VIDEO = 'https://flow.google.com/project/37d8cf57-12b4-4a85-9934-5580e90d3781'


class FakeDB:
    def __init__(self, row=None):
        self.row = dict(row or {})
        self.writes = []

    def get(self, job_id):
        return dict(self.row)

    def upsert(self, job_id, **fields):
        self.row.update(fields)
        self.writes.append(fields)


def _job(tmp_path, stills_setting='', stills_db='', video_file='', video_setting=''):
    job = tmp_path / JOB
    (job / 'flow').mkdir(parents=True)
    (job / 'production_manifest.json').write_text('{"job_id": "%s", "shots": []}' % JOB)
    settings = {}
    if stills_setting:
        settings['flow_project_url'] = stills_setting
    if video_setting:
        settings['flow_video_project_url'] = video_setting
    (job / 'settings.json').write_text(json.dumps(settings))
    if video_file:
        (job / 'flow_video_project.json').write_text(json.dumps({'project_url': video_file, 'role': 'video'}))
    return job


def _factory(job, db=None):
    from engine.factory import Factory
    factory = Factory.__new__(Factory)
    factory.pm = SimpleNamespace(job_dir=lambda job_id: str(job), log=lambda *a, **k: None,
                                 load_manifest=lambda job_id: (_ for _ in ()).throw(FileNotFoundError()))
    factory.db = db or FakeDB()
    return factory


# ----------------------------------------------------------------- the collision report

def test_bindings_name_each_role_and_its_source(tmp_path):
    job = _job(tmp_path, stills_setting=STILLS, video_file=VIDEO)
    bindings = _factory(job).flow_project_bindings(JOB)
    assert bindings['stills_project'] == STILLS and bindings['video_project'] == VIDEO
    assert bindings['stills_source'] == 'settings.json flow_project_url'
    assert bindings['video_source'] == 'flow_video_project.json'
    assert bindings['conflict'] is False


def test_a_collision_is_detected_across_sources(tmp_path):
    """Stills from the database, video from the file: the same URL still collides."""
    job = _job(tmp_path, video_file=VIDEO)
    factory = _factory(job, FakeDB({'flow_project': VIDEO}))
    bindings = factory.flow_project_bindings(JOB)
    assert bindings['conflict'] is True
    assert bindings['stills_source'] == 'database flow_project'


def test_the_conflict_message_names_both_sources_and_the_exact_commands(tmp_path):
    job = _job(tmp_path, stills_setting=VIDEO, video_file=VIDEO)
    message = _factory(job).flow_project_conflict_message(JOB)
    assert VIDEO in message
    assert 'settings.json flow_project_url' in message and 'flow_video_project.json' in message
    assert f'flow-projects {JOB} --clear-video' in message
    assert f'--set-stills https://flow.google.com/project/<storyboard-project-id>' in message
    assert 'Nothing was generated or charged' in message
    assert 'storyboard images and the video clips resolve to the same Flow project' in message


def test_the_old_one_line_error_is_gone():
    from pathlib import Path
    source = Path('engine/factory.py').read_text(encoding='utf-8')
    assert 'raise RuntimeError("Video Flow project must differ from storyboard image project")' not in source
    start = source.index('if video_url and still_url and video_url == still_url:')
    block = source[start:start + 1600]
    assert 'self.flow_project_conflict_message(' in block
    assert 'current.status = "paused"' in block          # not left looking like it is still running


# ----------------------------------------------------------------- recovery binds the video role only

def test_the_video_recovery_no_longer_writes_the_stills_binding():
    from pathlib import Path
    source = Path('engine/factory.py').read_text(encoding='utf-8')
    start = source.index('def recover_flow_video')
    end = source.index('def approve_flow_request', start) if 'def approve_flow_request' in source[start:] else len(source)
    block = source[start:end]
    assert '_remember_flow_video_project_url(' in block
    assert '_remember_flow_project_url(' not in block     # the stills writer must not appear


# ----------------------------------------------------------------- the CLI

class Args(SimpleNamespace):
    pass


def _args(**kwargs):
    base = dict(job_id=JOB, set_stills='', set_video='', clear_stills=False, clear_video=False, confirm=False)
    base.update(kwargs)
    return Args(**base)


def test_the_cli_is_read_only_without_confirm(tmp_path, capsys):
    job = _job(tmp_path, stills_setting=VIDEO, video_file=VIDEO)
    assert fpc.run_flow_projects(_factory(job), _args()) == 0
    printed = capsys.readouterr().out
    assert 'COLLISION' in printed and '--clear-video --confirm' in printed
    assert json.loads((job / 'settings.json').read_text())['flow_project_url'] == VIDEO   # untouched


def test_the_cli_refuses_a_dry_run_change(tmp_path, capsys):
    job = _job(tmp_path, stills_setting=VIDEO, video_file=VIDEO)
    assert fpc.run_flow_projects(_factory(job), _args(clear_video=True)) == 0
    assert 'Dry run' in capsys.readouterr().out
    assert (job / 'flow_video_project.json').is_file()


def test_clear_video_frees_the_role_and_keeps_a_backup(tmp_path, capsys):
    job = _job(tmp_path, stills_setting=VIDEO, video_file=VIDEO)
    assert fpc.run_flow_projects(_factory(job), _args(clear_video=True, confirm=True)) == 0
    assert not (job / 'flow_video_project.json').exists()
    assert (job / 'flow_video_project.json.cleared').is_file()
    assert 'opens its own project' in capsys.readouterr().out
    bindings = _factory(job).flow_project_bindings(JOB)
    assert bindings['conflict'] is False and bindings['video_project'] == ''


def test_set_stills_rebinds_and_warns_when_the_video_binding_still_collides(tmp_path, capsys):
    job = _job(tmp_path, stills_setting=VIDEO, video_file=VIDEO)
    factory = _factory(job)
    assert fpc.run_flow_projects(factory, _args(set_stills=STILLS, confirm=True)) == 0
    printed = capsys.readouterr().out
    assert json.loads((job / 'settings.json').read_text())['flow_project_url'] == STILLS
    assert factory.db.row.get('flow_project') == STILLS
    # the video binding still points at the old URL, so nothing collides any more
    assert _factory(job).flow_project_bindings(JOB)['conflict'] is False
    assert 'Stills project bound' in printed


def test_set_video_refuses_a_second_binding_without_clearing_first(tmp_path, capsys):
    job = _job(tmp_path, stills_setting=STILLS, video_file=VIDEO)
    other = 'https://flow.google.com/project/08d0cf93-326d-43a8-bb93-4b36653721c1'
    assert fpc.run_flow_projects(_factory(job), _args(set_video=other, confirm=True)) == 2
    assert 'Refused' in capsys.readouterr().out
    assert json.loads((job / 'flow_video_project.json').read_text())['project_url'] == VIDEO


def test_two_actions_in_one_command_are_refused(tmp_path, capsys):
    job = _job(tmp_path, stills_setting=VIDEO, video_file=VIDEO)
    assert fpc.run_flow_projects(_factory(job), _args(clear_video=True, clear_stills=True, confirm=True)) == 2
    assert 'one binding per command' in capsys.readouterr().out


def test_an_invalid_url_is_refused(tmp_path, capsys):
    job = _job(tmp_path, stills_setting=VIDEO, video_file=VIDEO)
    assert fpc.run_flow_projects(_factory(job), _args(set_stills='not-a-url', confirm=True)) == 2
    assert 'expected https://flow.google.com/project/<uuid>' in capsys.readouterr().out


def test_clear_stills_removes_both_copies(tmp_path):
    job = _job(tmp_path, stills_setting=STILLS)
    factory = _factory(job, FakeDB({'flow_project': STILLS}))
    assert fpc.run_flow_projects(factory, _args(clear_stills=True, confirm=True)) == 0
    assert 'flow_project_url' not in json.loads((job / 'settings.json').read_text())
    assert factory.db.row.get('flow_project') == ''


def test_the_report_says_ok_when_the_roles_differ(tmp_path, capsys):
    job = _job(tmp_path, stills_setting=STILLS, video_file=VIDEO)
    fpc.run_flow_projects(_factory(job), _args())
    assert 'OK: the two roles use different projects.' in capsys.readouterr().out


def test_the_report_flags_disagreeing_copies(tmp_path, capsys):
    job = _job(tmp_path, stills_setting=STILLS, stills_db=VIDEO, video_file=VIDEO)
    factory = _factory(job, FakeDB({'flow_project': VIDEO}))
    fpc.run_flow_projects(factory, _args())
    printed = capsys.readouterr().out
    assert 'Stored copies that disagree' in printed
    assert 'database stills' in printed and 'settings stills' in printed


# ----------------------------------------------------------------- is it running or stopped?

def test_a_free_lock_means_the_job_is_not_running(tmp_path):
    from engine.job_activity import job_activity
    job = _job(tmp_path, stills_setting=STILLS, video_file=VIDEO)
    (job / 'logs').mkdir()
    (job / 'logs' / 'progress.json').write_text(json.dumps(
        {'ts': '2026-10-27T04:46:16+05:30', 'percent': 28.0, 'stage': 'Opening persisted project URL'}))
    (job / 'generation_log.json').write_text(json.dumps([
        {'ts': '2026-10-27T04:46:20+05:30', 'event': 'flow_project_conflict',
         'shot': 'shot_017', 'error': 'stills and video resolve to the same project'}]))
    activity = job_activity(job, now=1761520000)
    assert activity['running'] is False
    assert activity['stopped_by'] == 'flow_project_conflict'
    assert activity['stop_shot'] == 'shot_017'
    assert 'same project' in activity['stop_reason']
    lines = ' '.join(__import__('engine.job_activity', fromlist=['describe']).describe(activity))
    assert 'NOT RUNNING' in lines
    assert '"planned" means the plan is saved' in lines


def test_a_held_lock_means_running(tmp_path):
    import fcntl
    from engine.job_activity import job_activity
    job = _job(tmp_path)
    lock_path = job / '.production.lock'
    lock_path.write_bytes(b'')
    with open(lock_path, 'a+b') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert job_activity(job)['running'] is True
    assert job_activity(job)['running'] is False

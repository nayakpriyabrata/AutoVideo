# v7.0.58 — Flow Uploads picker retry

The reported job `20261017-152520-stop-wasting-your-life-4e09` failed at shot_002 when a visible `Uploads` title timed out while Playwright waited for it to become stable. Its journal is saved; resume must recover that exact request before any further generation. The failure may occur before image submission, but the log alone does not establish that no request was sent.

This build retries the picker-scoped Uploads title click for at most 3.5 seconds, tries its clickable `mat-list-item` on a transient timeout, and retries opening Uploads inside the bounded attachment window. It never clicks the application sidebar as a fallback, never forces a click, and still requires an exact reference chip in the composer before generation.

The original v7.0.57 reference-filename selection fix remains included. This patch does not fix Flow's separate target-closed download condition. It cannot guarantee every third-party UI state succeeds.

## Upgrade an installation whose VERSION is 7.0.57

Stop Studio and any resume/CLI production processes. Extract this archive beside the installation and run from the existing `AutoVideoAI-v7` directory:

```bash
cat VERSION
python3 ../AutoVideoAI-v7.0.58/tools/update_v757_to_v758.py . --apply
```

The updater refuses unexpected code modifications; it backs up only changed code and leaves outputs, `.env` and browser profiles intact. If `cat VERSION` reports 7.0.56, install v7.0.57 first using its updater. A folder name is not a version check.

Then use `python3 tools/flow_resume_preflight.py outputs/20261017-152520-stop-wasting-your-life-4e09` and `python3 cli.py v3 resume 20261017-152520-stop-wasting-your-life-4e09`. Do not delete the saved journal or start a replacement generation. If safe resume remains blocked, export `python3 cli.py v3 support-report 20261017-152520-stop-wasting-your-life-4e09` and share its JSON plus the matching storyboard/shot_002_open.jpg.recovery.json. If the resume remains failed, preserve the output folder for recovery.

## Validation

Four focused new scenarios and seven existing picker tests passed through direct invocation. The Pytest runner in this workspace exited with a bus error before collection, so no full-suite pass is claimed. The extracted v7.0.57 → v7.0.58 update is also verified against a runtime-data sentinel. No signed-in live Flow run was performed.

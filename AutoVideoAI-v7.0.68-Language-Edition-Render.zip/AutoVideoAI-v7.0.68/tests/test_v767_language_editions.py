import json
from pathlib import Path

import pytest


def test_one_master_creates_only_selected_language_scripts(tmp_path,monkeypatch):
    import engine.speech_cards as sc
    import engine.providers.gemini_web as gw
    calls=[]
    def generate(system,user,**kwargs):
        calls.append(user)
        return json.dumps({'narration':'यह स्वीकृत हिंदी संस्करण है।'},ensure_ascii=False)
    monkeypatch.setattr(gw,'gemini_web_generate',generate)
    result=sc.prepare_localized_scripts(tmp_path,'This is the approved master.','en',['en','hi'])
    assert result['scripts']['en']=='This is the approved master.'
    assert set(result['scripts'])=={'en','hi'}
    assert len(calls)==1 and 'Target: hi' in calls[0]
    assert result['phase']=='review_scripts'


def test_single_master_language_needs_no_translation_review(tmp_path):
    import engine.speech_cards as sc
    result=sc.prepare_localized_scripts(tmp_path,'Only one approved master.','en',['en'])
    assert result['phase']=='scripts_approved'
    assert result['scripts']=={'en':'Only one approved master.'}


def test_reviewed_edition_text_is_exact_tts_input(tmp_path,monkeypatch):
    import engine.speech_cards as sc
    state={'source_language':'en','source_script':'Approved master','editions':['en','hi'],
           'fingerprint':sc.localization_key('Approved master','en',['en','hi']),
           'scripts':{'en':'Approved master','hi':'मसौदा'},'reviewed':{'en':True}}
    approved=sc.approve_localized_scripts(tmp_path,state,
        {'en':'Approved master','hi':'यह संशोधित और स्वीकृत वर्णन है।'},{'en':True,'hi':True})
    spoken=[]
    monkeypatch.setattr(sc,'prepare_edition',lambda root,script,language,**kw: spoken.append((language,script)) or {'language':language,'script':script})
    monkeypatch.setattr(sc,'complete_edition_cards',lambda bundle,*a:dict(bundle,cards=[]))
    result=sc.prepare_batch(tmp_path/'batch','Approved master','en',['en','hi'],localized_scripts=approved['scripts'])
    assert spoken==[('en','Approved master'),('hi','यह संशोधित और स्वीकृत वर्णन है।')]
    assert result['phase']=='ready_for_review'


def test_changed_master_invalidates_language_review(tmp_path):
    import engine.speech_cards as sc
    state={'source_language':'en','source_script':'Old master','editions':['en'],
           'fingerprint':sc.localization_key('Different master','en',['en']),
           'scripts':{'en':'Old master'}}
    with pytest.raises(ValueError,match='changed'):
        sc.approve_localized_scripts(tmp_path,state,{'en':'Old master'},{'en':True})


def test_tts_rejects_missing_selected_reviewed_script(tmp_path):
    import engine.speech_cards as sc
    with pytest.raises(ValueError,match='Every selected language'):
        sc.prepare_batch(tmp_path,'Master','en',['en','or'],localized_scripts={'en':'Master'})


def test_studio_exposes_language_choice_before_master_draft():
    source=Path('app.py').read_text(encoding='utf-8')
    assert source.index('Additional language editions · optional') < source.index('2 · Review script and cast · optional')
    assert 'Prepare selected language scripts for review · no TTS' in source
    assert source.index('Prepare selected language scripts for review · no TTS') < source.index('Prepare all selected TTS → then all language text cards')

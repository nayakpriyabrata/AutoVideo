import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from PIL import Image
from engine.factory import Factory
from engine.providers.flow_browser import FlowBrowserProvider,FlowRequestPending


def setup(tmp_path, replacement_pending=False):
    p=FlowBrowserProvider.__new__(FlowBrowserProvider)
    shot=NS(shot_id='shot_006')
    out=str(tmp_path/'close.jpg')
    cfg={'prompt':'A clear closing scene','project_url':'https://flow.google.com/project/test',
         'flow_replace_unresolved_images':True,'flow_image_replacement_limit':2,
         'flow_image_replacement_root':str(tmp_path)}
    key=hashlib.sha256(json.dumps(['image',shot.shot_id,cfg['prompt'],True],sort_keys=True).encode()).hexdigest()
    p._save_request(out,{'kind':'image','status':'pending','request_hash':key,'project_url':cfg['project_url']})
    original=Path(out+'.flow-request.json').read_bytes(); calls=[]
    state={'pending':replacement_pending,'compiled':[]}
    def once(s,c,r,path,v,dry,kind):
        calls.append((path,kind))
        if path==out:raise FlowRequestPending('No exact original match')
        state['compiled'].append(c)
        p._save_request(path,{'kind':'image','status':'pending','request_hash':key,'project_url':cfg['project_url']})
        if state['pending']:raise FlowRequestPending('Replacement still pending; no new submit')
        Image.new('RGB',(96,96),'green').save(path)
        return {'path':path,'provider':'flow','credits':0,'project_url':cfg['project_url']}
    p._guarded_generation_once=once
    return p,shot,cfg,out,original,calls,state


def test_saved_policies_survive_actual_settings_loader(tmp_path):
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'jobs.db'))
    job=f.create_job('Settings test',profile='STORYBOARD_ECONOMY',frame_source='flow',dry_run=True)
    f.set_flow_local_closing_fallback(job,True)
    f.set_flow_frame_batch_recovery(job,True)
    f.set_flow_image_replacement(job,True,5)
    actual=f._settings(job)
    assert actual['flow_local_closing_fallback'] and actual['flow_continue_unresolved_frames']
    assert actual['flow_replace_unresolved_images'] and actual['flow_image_replacement_limit']==5


def test_three_retries_then_one_replacement_original_journal_backed_up(tmp_path):
    p,s,c,out,original,calls,state=setup(tmp_path)
    result=p._guarded_generation(s,c,None,out,True,False,'image')
    assert result['path']==out and result['provider']=='flow-image-replacement'
    assert [path for path,kind in calls].count(out)==4 # initial scan + three recovery retries
    assert len(calls)==5
    assert state['compiled'][0]['project_url']==''
    assert state['compiled'][0]['project'].startswith('AutoVideo-ImageReplacement-')
    assert state['compiled'][0]['max_generation_credits']==0
    assert state['compiled'][0]['approval']=='once'
    assert result['project_url']==c['project_url']
    assert Path(out+'.flow-request.original.json').read_bytes()==original
    calls.clear()
    p._guarded_generation(s,c,None,out,True,False,'image')
    assert calls==[(out+'.replacement-01.jpg','image')]
    assert len(json.loads((tmp_path/'flow_image_replacements/ledger.json').read_text())['reservations'])==1


def test_pending_replacement_resume_recovers_child_without_new_original(tmp_path):
    p,s,c,out,original,calls,state=setup(tmp_path,True)
    with pytest.raises(FlowRequestPending):p._guarded_generation(s,c,None,out,True,False,'image')
    calls.clear();state['pending']=False
    p._guarded_generation(s,c,None,out,True,False,'image')
    assert calls==[(out+'.replacement-01.jpg','image')]
    assert Path(out+'.flow-request.original.json').read_bytes()==original


def test_crash_reservation_without_child_never_submits_again(tmp_path):
    p,s,c,out,original,calls,state=setup(tmp_path,True)
    with pytest.raises(FlowRequestPending):p._guarded_generation(s,c,None,out,True,False,'image')
    Path(out+'.replacement-01.jpg.flow-request.json').unlink();calls.clear()
    with pytest.raises(FlowRequestPending,match='cannot be verified'):
        p._guarded_generation(s,c,None,out,True,False,'image')
    assert calls==[]


def test_video_never_uses_image_replacement(tmp_path):
    p,s,c,out,original,calls,state=setup(tmp_path)
    with pytest.raises(FlowRequestPending):p._guarded_generation(s,c,None,out,True,False,'video')
    assert calls==[(out,'video')] and not Path(out+'.image-replacement.json').exists()


def test_job_cap_and_changed_prompt_refuse_replacement(tmp_path):
    from engine.flow_image_replacement import replace_image
    p,s,c,out,original,calls,state=setup(tmp_path)
    c['flow_image_replacement_limit']=1
    p._guarded_generation(s,c,None,out,True,False,'image')
    second=str(tmp_path/'second.jpg');Path(second+'.flow-request.json').write_bytes(original)
    with pytest.raises(FlowRequestPending,match='cap'):
        replace_image(p,s,c,second,True,pending_error=FlowRequestPending('pending'))
    with pytest.raises(FlowRequestPending,match='does not match'):
        replace_image(p,s,{**c,'prompt':'Different scene'},out,True)


def test_actual_loader_drives_closing_fallback(tmp_path):
    from tests.test_v716_frame_batch_recovery import setup_batch
    from tests.test_economy_parallel_frames import _Refs
    f,m,D,settings,calls=setup_batch(tmp_path,{'shot_001_close.jpg'})
    real=Factory(str(tmp_path/'outputs'),str(tmp_path/'jobs.db'))
    job=real.create_job('Loader regression',profile='STORYBOARD_ECONOMY',frame_source='flow',dry_run=True)
    real.set_flow_local_closing_fallback(job,True)
    settings.update({k:real._settings(job)[k] for k in ('flow_local_closing_fallback','flow_continue_unresolved_frames')})
    f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    assert m.shots[0].closing_frame_source=='local-opening-fallback'


def test_real_request_guard_recovers_interrupted_replacement_without_generate(tmp_path,monkeypatch):
    p,s,c,out,original,calls,state=setup(tmp_path)
    # Use the real journal guard, not the orchestration mock above.
    p._guarded_generation_once=FlowBrowserProvider._guarded_generation_once.__get__(p)
    c['flow_image_signature_wait_ms']=0
    new_url='https://flow.google.com/project/replacement-project'
    signature='IMG|https://flow-content.google/image/00000000-0000-0000-0000-000000000001|Tile|image|96|96'
    submits=[]
    bridge=NS(media_assets=lambda:[],ensure_project=lambda *a,**kw:None,
              read_asset_generation_prompt=lambda sig:c["prompt"] if sig==signature else None)
    p._ensure=lambda:bridge;p.bridge=bridge
    def generate(shot,compiled,path,vertical,dry_run=False):
        submits.append(path)
        p._save_request(path,{'kind':'image','status':'pending','request_hash':p._active_request_hash,
            'project_url':new_url,'signature':signature,'submitted_prompt':compiled['prompt']})
        return {'path':None,'error':'download interrupted'}
    from engine import flow_image_transaction
    monkeypatch.setattr(flow_image_transaction,"generate",lambda provider,shot,compiled,path,vertical,key:generate(shot,compiled,path,vertical))
    with pytest.raises(FlowRequestPending):p._guarded_generation(s,c,None,out,True,False,'image')
    def download(path,**kw):
        assert kw['preferred_signature']==signature
        Image.new('RGB',(96,96),'orange').save(path)
    bridge.download_latest_asset=download
    p._guarded_generation(s,c,None,out,True,False,'image')
    assert submits==[out+'.replacement-01.jpg']
    assert json.loads(Path(out+'.flow-request.json').read_text())['status']=='superseded_by_authorized_replacement'

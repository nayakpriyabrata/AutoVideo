import json
import subprocess
from pathlib import Path
from types import SimpleNamespace as NS
import numpy as np
import pytest


def test_second_clip_batch_keeps_first_and_caption_artifacts(tmp_path, monkeypatch):
    from tests.test_v703_workflow import clip_fixture
    from engine.studio_review import discover_clips
    from engine.render import captions_ass
    c, calls = clip_fixture(monkeypatch, tmp_path)
    monkeypatch.setattr(c, '_face_crop_track', lambda *a: [])
    caps = []
    def captions(words, folder, **kwargs):
        path=Path(folder)/'captions.ass'; path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text('captions-'+str(len(caps))); caps.append(path)
        return {'ass':str(path)}
    monkeypatch.setattr(captions_ass, 'build_captions', captions)
    folder=tmp_path/'clips'
    a=c.create_highlight_clips('source',str(folder),count=3,source_rights='own_content',ranking_provider='local')
    before={p:Path(p).read_bytes() for p in a['outputs']}
    b=c.create_highlight_clips('source',str(folder),count=3,source_rights='own_content',ranking_provider='local')
    assert a['batch_id']!=b['batch_id']
    assert set(a['outputs']).isdisjoint(b['outputs'])
    assert all(Path(p).read_bytes()==data for p,data in before.items())
    assert len(set(caps))==6 and caps[0].read_text()=='captions-0'
    discovered={x['path'] for x in discover_clips(folder)}
    assert set(a['outputs']+b['outputs'])<=discovered
    assert json.loads(Path(a['batch_report']).read_text())['outputs']==a['outputs']


def test_legacy_orphan_exports_reappear_but_working_media_does_not(tmp_path):
    from engine.studio_review import discover_clips
    folder=tmp_path/'my-clips';folder.mkdir()
    for name in ['yesterday.mp4','today.mp4','yesterday-broll.mp4','blocked.mp4']:(folder/name).write_bytes(b'media')
    (folder/'blocked.qc.json').write_text(json.dumps({'decision':'BLOCK'}))
    (folder/'highlights.json').write_text(json.dumps({'outputs':[str(folder/'today.mp4')]}))
    work=folder/'_clip_work';work.mkdir();(work/'source.mp4').write_bytes(b'raw')
    flow=tmp_path/'job/flow/shots/shot_001';flow.mkdir(parents=True);(flow/'take_01.mp4').write_bytes(b'raw')
    clips=discover_clips(tmp_path)
    assert {Path(c['path']).name for c in clips}=={'yesterday.mp4','today.mp4','yesterday-broll.mp4','blocked.mp4'}
    assert next(c['state'] for c in clips if c['path'].endswith('/blocked.mp4'))=='QC review required'


def test_face_track_crop_changes_at_camera_switch_in_real_ffmpeg(tmp_path):
    from engine.clipping import framing_filter
    from PIL import Image
    wide=tmp_path/'wide.png'; im=Image.new('RGB',(640,360),'red')
    im.paste('blue',(320,0,640,360));im.save(wide)
    output=tmp_path/'crop.mp4'
    vf=framing_filter('face-crop',face_track=[{'time':0,'x':.2},{'time':1,'x':.8}])
    subprocess.run(['ffmpeg','-v','error','-y','-loop','1','-i',str(wide),'-t','2',
                    '-vf',vf,'-r','10','-c:v','libx264','-preset','ultrafast',str(output)],check=True,timeout=30)
    for at, channel in [(.3,0),(1.3,2)]:
        raw=subprocess.run(['ffmpeg','-v','error','-ss',str(at),'-i',str(output),'-frames:v','1',
                            '-vf','scale=108:192','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True).stdout
        frame=np.frombuffer(raw,dtype=np.uint8).reshape(192,108,3)
        assert frame[50:100,30:70].mean(axis=(0,1))[channel]>220


def test_broll_keeps_accepted_picture_outside_cutaway_without_source_or_captions(tmp_path, ffmpeg_media):
    from engine.broll import _render_clip_studio_cutaway
    original=tmp_path/'accepted.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=red:s=320x180:r=30',
        '-i',ffmpeg_media['voice'],'-t','4','-c:v','libx264','-c:a','aac',str(original)],check=True)
    before=original.read_bytes()
    output=_render_clip_studio_cutaway({'clip_output':str(original),'path':ffmpeg_media['video'],
        'source_video':str(tmp_path/'unavailable.mp4'),'source_start':0,'clip_duration':4,
        'start':1,'duration':1,'framing':'fit'})
    for at in [.3,2.5]:
        raw=subprocess.run(['ffmpeg','-v','error','-ss',str(at),'-i',output,'-frames:v','1',
                            '-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True).stdout
        frame=np.frombuffer(raw,dtype=np.uint8).reshape(180,320,3)
        assert frame.mean(axis=(0,1))[0]>220 and frame.mean(axis=(0,1))[2]<30
    assert original.read_bytes()==before


def test_migrated_recreation_approval_uses_only_exact_saved_photo(tmp_path):
    from engine.production import digest, save
    from engine.clip_recreation import approval_fingerprint, require_recreation_approval
    root=tmp_path/'outputs/job';root.mkdir(parents=True)
    source=root/'source.mp4';source.write_bytes(b'source')
    photo=root/'references/character-aanya-0.jpg';photo.parent.mkdir();photo.write_bytes(b'original')
    save(root/'cast_snapshot.json',{'characters':[{'id':'aanya','name':'Aanya','references':[
        {'path':'/old/data/content/characters/aanya/face.jpg','sha256':digest(photo)}]}]})
    from engine.content_plan import validate_plan, script_from_plan
    plan=validate_plan({'topic':'Original story','narration':'A useful story.','scenes':[],
        'approved':True,'rights':{'declaration':'own_content','adaptation_confirmed':True}})
    save(root/'approved_content_plan.json',plan)
    save(root/'script.json',script_from_plan(plan))
    save(root/'character_snapshot.json',{'id':'aanya','name':'Aanya'})
    save(root/'settings.json',{})
    save(root/'recreation.json',{'state':'APPROVED_FOR_GENERATION','source_clip':str(source),'source_sha256':digest(source)})
    data=json.loads((root/'recreation.json').read_text());data['approval_sha256']=approval_fingerprint(root);save(root/'recreation.json',data)
    require_recreation_approval(root)
    photo.write_bytes(b'changed')
    with pytest.raises(ValueError,match='missing or changed'):require_recreation_approval(root)


def test_reference_upload_attempt_survives_failed_attachment(tmp_path,monkeypatch):
    from engine.flow_reference_policy import reference_upload_attempt,upload_record
    monkeypatch.chdir(tmp_path)
    assert not reference_upload_attempt('project','AV_face')
    reference_upload_attempt('project','AV_face',record=True)
    assert reference_upload_attempt('project','AV_face')
    assert not upload_record('project','AV_face')
    assert not reference_upload_attempt('other','AV_face')


def test_attachment_wait_clears_stale_search_and_requires_verified_chip(monkeypatch):
    from engine.providers import flow_browser as m
    browser=m.FlowBrowser.__new__(m.FlowBrowser);events=[]
    browser._clear_media_picker_search=lambda:events.append('clear')
    browser._reference_baseline={'@chip:old'}
    responses=iter([['@chip:old'],['@chip:old','@chip:new']])
    browser._agent_reference_names=lambda:next(responses)
    browser._dismiss_media_picker=lambda:events.append('dismiss')
    browser._click_text_action=lambda *a,**kw:False
    browser._page=NS(get_by_text=lambda *a,**kw:NS(count=lambda:0),locator=lambda *a:NS(count=lambda:0),wait_for_timeout=lambda ms:None)
    assert browser._finish_agent_media_picker('AV_exact.jpg')
    assert events==['clear','dismiss']

import json
from pathlib import Path
import pytest


def reply():
    return {'narration':'','scenes':[{'text':'','visual_intent':f'Adult woman dances in rain on a forest road, shot {i+1}', 'duration':6} for i in range(5)],'character_suggestions':[]}


@pytest.mark.parametrize('mode',['Music only','Silent'])
def test_gemini_visual_draft_has_no_spoken_text(monkeypatch, mode):
    import engine.providers.gemini_web as web
    from engine.studio_review import draft_script_cast
    seen=[]
    def generate(system,user,**kw):
        seen.append((system,user,kw));return json.dumps(reply())
    monkeypatch.setattr(web,'gemini_web_generate',generate)
    result=draft_script_cast('Dancing in rain',30,'en',[],audio_mode=mode)
    plan=result['plan']
    assert plan['narration']=='' and not plan['voiceover_enabled']
    assert all(s['text']=='' for s in plan['scenes'])
    assert sum(s['duration'] for s in plan['scenes'])==30
    assert plan['runtime_estimate_seconds']==30 and not plan['approved']
    assert 'NO narrator' in seen[0][0] and 'words, at least' not in seen[0][1]
    assert seen[0][2]['cleanup']=='delete-after-read'


@pytest.mark.parametrize('bad',[{'narration':'She embraces the rain.'}, {'scenes':[{'text':'Say hello','visual_intent':'Dance','duration':30}]}, {'scenes':[{'text':'','visual_intent':'Dance','duration':6}]}])
def test_rejects_spoken_or_wrong_duration_visual_reply(monkeypatch,bad):
    import engine.providers.gemini_web as web
    from engine.studio_review import draft_script_cast
    monkeypatch.setattr(web,'gemini_web_generate',lambda *a,**kw:json.dumps({**reply(),**bad}))
    with pytest.raises(ValueError):draft_script_cast('Dancing',30,'en',[],audio_mode='Music only')


def test_draft_mode_change_requires_redraft():
    from engine.visual_plan import validate_draft_selection
    plan={'topic':'Dance','language':'en','requested_seconds':30,'audio_mode':'voiceover'}
    with pytest.raises(ValueError,match='Draft again'):validate_draft_selection(plan,'Dance',30,'en','Music only')


def test_visual_plan_import_and_exact_duration_no_tts(tmp_path,monkeypatch):
    import engine.factory as module
    from engine.visual_plan import validated_visual_plan
    from engine.content_plan import script_from_plan
    from engine.planning.director import _visual_sentences
    plan=validated_visual_plan(reply(),'Rain dance',30,'en','music_only')
    script=script_from_plan(plan)
    assert script['narration']=='' and script['words']==0
    assert [b['duration'] for b in script['beats']]==[6]*5
    spans=_visual_sentences(script['beats'],'',30,8)
    assert [(s['start'],s['end']) for s in spans]==[(0,6),(6,12),(12,18),(18,24),(24,30)]
    f=module.Factory(str(tmp_path/'outputs'),str(tmp_path/'db.sqlite'))
    path=tmp_path/'approved.json';path.write_text(json.dumps(plan))
    with pytest.raises(ValueError,match='visual-only'):f.create_job('Rain',approved_plan_path=str(path),voiceover_enabled=True)
    assert not list((tmp_path/'outputs').iterdir())
    job=f.create_job('Rain',target_seconds=30,approved_plan_path=str(path),voiceover_enabled=False,
        background_music='generated',text_cards_enabled=False,script_provider='planner',script_quality='standard',profile='LOCAL_FREE',dry_run=True)
    monkeypatch.setattr(module,'synthesize_narration',lambda *a,**kw:pytest.fail('Must not synthesize speech'))
    monkeypatch.setattr(f,'_generate_all',lambda *a:None)
    assert f.run_job(job)['status']=='dry_complete'
    assert f.pm.load_manifest(job).shots[-1].voice_end==30
    assert not (Path(f.pm.job_dir(job))/'narration/voice.mp3').exists()


def test_automatic_music_only_writer_uses_visual_prompt(monkeypatch):
    import engine.planning.script_engine as writer
    from engine.planning.script import plan_content
    monkeypatch.setattr(writer,'_provider_available',lambda p:True)
    seen=[]
    def call(provider,model,system,user):seen.append((system,user));return json.dumps(reply())
    monkeypatch.setattr(writer,'_call_provider',call)
    plan=plan_content('Rain dance',duration_sec=30,script_provider='gemini-web',voiceover_enabled=False,audio_mode='music_only')
    assert plan['narration']=='' and plan['source']=='gemini-web-visual'
    assert 'NO narrator' in seen[0][0]


def test_studio_exposes_formats_and_passes_audio_to_draft(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard
    import engine.studio_review as review
    captured=[]
    def draft(topic,seconds,language,characters,style,**kw):
        from engine.visual_plan import validated_visual_plan
        captured.append(kw)
        plan=validated_visual_plan(reply(),topic,seconds,language,kw['audio_mode']);plan['approved']=False
        return {'plan':plan,'suggestions':[]}
    monkeypatch.setattr(review,'draft_script_cast',draft)
    _,app=dashboard(tmp_path,monkeypatch)
    modes=next(w for w in app.radio if w.label=='Video format')
    assert any('Normal Reel' in x for x in modes.options) and any('Long video' in x for x in modes.options)
    modes.set_value('reels_pro').run()
    next(w for w in app.text_input if w.label=='Topic / idea').set_value('Rain dance').run()
    next(w for w in app.number_input if w.label=='Duration (seconds)').set_value(30).run()
    next(w for w in app.radio if w.label=='Audio mode').set_value('Music only').run()
    assert not next(w for w in app.checkbox if w.label=='Include text cards').value
    next(w for w in app.button if w.label=='Draft script + suggest saved cast — no visuals or TTS').click().run()
    assert not app.exception,[x.message for x in app.exception]
    assert captured[-1]['audio_mode']=='Music only'
    assert json.loads(next(w for w in app.text_area if w.label=='Review/edit script and scenes JSON').value)['narration']==''

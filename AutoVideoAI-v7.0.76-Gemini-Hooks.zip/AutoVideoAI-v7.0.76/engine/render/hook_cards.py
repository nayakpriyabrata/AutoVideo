"""Hook pills (7.0.76): one short attention line, drawn as a centred pill.

Each hook PNG is a full-canvas transparent frame. The pill rectangle is returned as
``box`` so the FFmpeg renderer can pop it open and closed (anim='pop').
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

INK = (12, 20, 35, 255)


def render_hook_png(hook: dict, path, width: int, height: int, style: str = "bold") -> dict:
    from .typography import resolve_style, PALETTES, fit, draw_text
    style = resolve_style(style)
    palette = PALETTES[style]
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    vertical = height > width
    scale = min(width, height) / 1080.0
    max_w = int(width * (.84 if vertical else .60))
    pad_x, pad_y = int(34 * scale), int(20 * scale)
    stroke = max(1, int(2 * scale))
    layout = fit(d, hook["text"], max_w - 2 * pad_x, int(height * .14), size=64 * scale, minimum=40 * scale,
                 style=style, bold=True, headline=True, max_lines=2, stroke=stroke)
    box_w = min(max_w, layout.width + 2 * pad_x)
    box_h = layout.height + 2 * pad_y
    left = (width - box_w) // 2
    top = int(height * (.07 if vertical else .09))
    d.rounded_rectangle((left, top, left + box_w, top + box_h), radius=box_h // 2,
                        fill=palette["accent"], outline=(255, 255, 255, 90), width=max(1, int(2 * scale)))
    text_box = draw_text(d, layout, (left + pad_x, top + pad_y, left + box_w - pad_x, top + pad_y + layout.height),
                         INK, align="center")
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    img.save(path)
    return {"kind": "hook", "path": str(path), "start": hook["start"], "end": hook["end"], "title": hook["text"],
            "anchor": "top-center", "opacity": 1, "box": [left, top, box_w, box_h], "anim": "pop",
            "fade_in": .18, "fade_out": .18,
            "layout": {"style": style, "font_sizes": [layout.size], "text_boxes": [text_box],
                       "canvas": [width, height]}}

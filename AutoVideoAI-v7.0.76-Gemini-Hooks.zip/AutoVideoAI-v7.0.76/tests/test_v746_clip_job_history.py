import json
from pathlib import Path


def _report(folder, batch_id, title, output_name, *, latest=False, partial=False, stored_prefix=None):
    history = folder / 'clip-history'
    history.mkdir(parents=True, exist_ok=True)
    output = folder / output_name
    output.write_bytes(b'video-' + output_name.encode())
    stored = str(Path(stored_prefix) / output_name) if stored_prefix else str(output)
    value = {
        'batch_id': batch_id,
        'source_input': 'https://youtu.be/example',
        'source': str(folder / '_clip_work/source.mp4'),
        'partial_result': partial,
        'outputs': [stored],
        'highlights': [{'title': title, 'output': stored, 'duration': 30}],
    }
    path = folder / 'highlights.json' if latest else history / f'highlights-{batch_id}.json'
    path.write_text(json.dumps(value), encoding='utf-8')
    return path, output


def test_saved_clip_jobs_list_old_and_latest_batches_without_duplicate_alias(tmp_path):
    from engine.clip_history import discover_batches

    folder = tmp_path / 'outputs/my-clips'
    folder.mkdir(parents=True)
    old, _ = _report(folder, '1700000000000000000', 'Old useful clip', 'old.mp4')
    newest, _ = _report(folder, '1800000000000000000', 'Newest useful clip', 'new.mp4')
    # The latest alias repeats the newest permanent batch and must not create a duplicate row.
    (folder / 'highlights.json').write_bytes(newest.read_bytes())
    rows = discover_batches((tmp_path / 'outputs', folder))
    assert len(rows) == 2
    assert rows[0]['title'] == 'Newest useful clip'
    assert rows[1]['report_path'] == str(old.resolve())
    assert all(row['available_clips'] == 1 for row in rows)


def test_loading_old_job_rebases_a_uniquely_matching_clip_after_migration(tmp_path):
    from engine.clip_history import load_batch

    folder = tmp_path / 'outputs/my-clips'
    folder.mkdir(parents=True)
    report, output = _report(folder, '1700000000000000000', 'Migrated clip', 'kept.mp4',
                             stored_prefix='/old/install/outputs/my-clips')
    loaded = load_batch(report)
    assert loaded['outputs'] == [str(output.resolve())]
    assert loaded['highlights'][0]['output'] == str(output.resolve())
    assert loaded['batch_report'] == str(report.resolve())


def test_clip_studio_can_select_and_load_an_old_job(tmp_path, monkeypatch):
    from streamlit.testing.v1 import AppTest
    from engine.factory import Factory
    import engine.factory as factory_module
    import engine.project.database as db_module

    folder = tmp_path / 'outputs/my-clips'
    folder.mkdir(parents=True)
    report, output = _report(folder, '1700000000000000000', 'Old useful clip', 'old.mp4')
    import engine.clip_history as history_module
    saved = load = history_module.load_batch(report)
    row = {'report_path': str(report.resolve()), 'label': '2023-11-14 22:13 · Old useful clip · 1/1 clips · complete',
           'source': 'https://youtu.be/example', 'available_clips': 1, 'highlight_count': 1,
           'folder': str(folder), 'created_at': '2023-11-14T22:13:20+00:00'}
    monkeypatch.setattr(history_module, 'discover_batches', lambda *a, **k: [row])
    monkeypatch.setattr(history_module, 'load_batch', lambda *a, **k: dict(load))
    factory = Factory(str(tmp_path / 'outputs/jobs'), str(tmp_path / 'jobs.db'))
    monkeypatch.setattr(factory_module, 'Factory', lambda *a, **k: factory)
    monkeypatch.setattr(db_module, 'JobDB', lambda *a, **k: factory.db)
    app_path = Path(__file__).resolve().parents[1] / 'app.py'
    app = AppTest.from_file(str(app_path), default_timeout=30).run()
    next(widget for widget in app.sidebar.selectbox if widget.label == 'Workspace').set_value('Content & Delivery').run()
    next(widget for widget in app.sidebar.radio if widget.label == 'Page').set_value('CLIP STUDIO').run()
    assert not app.exception, [error.message for error in app.exception]
    assert any(widget.label == 'Choose a saved clip job' for widget in app.selectbox)
    next(widget for widget in app.button
         if widget.label == 'Load selected clip job — no regeneration').click().run()
    assert not app.exception, [error.message for error in app.exception]
    assert any('Loaded saved clip job' in message.value for message in app.success)

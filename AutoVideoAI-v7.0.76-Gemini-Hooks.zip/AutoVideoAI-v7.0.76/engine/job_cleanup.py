"""Conservative local cleanup: closed worker caches, completed worker clones.

Never deletes job media, request journals, original browser profiles or login
stores. Dry-run reports precede manual pruning of old job profiles.
"""
import json
import os
from pathlib import Path
import re
import shutil

CACHE_NAMES={'Cache','Code Cache','GPUCache','ShaderCache','GrShaderCache','DawnCache'}
PROTECTED_STORES={'IndexedDB','Local Storage','Session Storage','Sessions','Service Worker','File System','Storage'}


def profile_copy_ignore(directory, names):
    protected=any(part in PROTECTED_STORES for part in Path(directory).parts)
    return [n for n in names if (n in CACHE_NAMES and not protected) or n.startswith('Singleton') or
            n in ('LOCK','lockfile','DevToolsActivePort') or n.endswith('.tmp')]


def _active(profile):
    # A lock/socket may be stale, but ambiguity must preserve the profile.
    if any((profile/name).exists() or (profile/name).is_symlink()
           for name in ('SingletonLock','SingletonSocket')):return True
    proc=Path('/proc')
    if proc.exists():
        for entry in proc.iterdir():
            if not entry.name.isdigit():continue
            try:
                cmd=(entry/'cmdline').read_bytes().split(b'\0')
                target=str(profile).encode()
                if any(arg==b'--user-data-dir='+target for arg in cmd):return True
            except (OSError,PermissionError):continue
    return False


def _size(path):
    if path.is_symlink():return 0
    if path.is_file():return path.stat().st_size
    total=0
    for directory,dirs,files in os.walk(path,followlinks=False):
        dirs[:]=[n for n in dirs if not (Path(directory)/n).is_symlink()]
        for name in files:
            item=Path(directory)/name
            if not item.is_symlink():total+=item.stat().st_size
    return total


def trim_worker_cache(profile, *, apply=False):
    profile=Path(profile).absolute()
    report={'profile':str(profile),'apply':apply,'eligible_bytes':0,'freed_bytes':0,'removed':[], 'warnings':[]}
    if profile.is_symlink() or profile.parent.is_symlink() or profile.parent.name!='.flow-workers':
        report['warnings'].append('Not an isolated worker profile; preserved');return report
    if not profile.is_dir():return report
    if _active(profile):report['warnings'].append('Worker may still be open; preserved');return report
    for directory,dirs,_files in os.walk(profile,followlinks=False):
        dirs[:]=[name for name in dirs if name not in PROTECTED_STORES]
        for name in list(dirs):
            candidate=Path(directory)/name
            if candidate.is_symlink():dirs.remove(name);continue
            if name not in CACHE_NAMES:continue
            dirs.remove(name)
            size=_size(candidate);report['eligible_bytes']+=size
            if apply:
                try:shutil.rmtree(candidate);report['freed_bytes']+=size;report['removed'].append(str(candidate.relative_to(profile)))
                except OSError as error:report['warnings'].append(f'{name}: {type(error).__name__}')
    return report


def _completed_without_pending(job):
    from .providers.flow_browser import FlowBrowserProvider
    try:
        manifest=json.loads((job/'production_manifest.json').read_text())
        if manifest.get('status')!='done':return False,'Job is unfinished; profile retained for resume'
        final=job/'render'/(job.name+'-final.mp4')
        if not FlowBrowserProvider._is_valid_video_file(str(final)):return False,'No validated final video; profile retained'
        # Even a completed fallback edit can retain unresolved Google requests.
        for journal in job.rglob('*.flow-request.json'):
            if journal.is_symlink():return False,'Symlink request journal; profile retained'
            if json.loads(journal.read_text()).get('status')!='downloaded':
                return False,'Pending request retained; worker profile preserved'
        return True,''
    except (OSError,ValueError,TypeError):return False,'Unreadable job/recovery state; profile retained'


def cleanup_job(job_directory, worker_root=None, *, apply=False, completed_profiles=True):
    job=Path(job_directory).absolute()
    if job.is_symlink() or not job.is_dir():raise ValueError('Use an existing real job directory')
    if worker_root is None:
        from .providers.flow_browser import PROFILE_DIR
        worker_root=Path(PROFILE_DIR).absolute().parent/'.flow-workers'
    root=Path(worker_root).absolute()
    if root.is_symlink() or root.name!='.flow-workers':raise ValueError('Use a real .flow-workers directory')
    allowed,reason=_completed_without_pending(job) if completed_profiles else (False,'Completed-profile removal disabled')
    report={'job_id':job.name,'apply':apply,'eligible_bytes':0,'freed_bytes':0,'profiles':[], 'warnings':[]}
    if not root.is_dir():return report
    pattern=re.compile(re.escape(job.name)+r'-(?:economy|candidate)-worker-[1-9][0-9]*')
    for profile in sorted(root.iterdir()):
        if not pattern.fullmatch(profile.name) or profile.is_symlink():continue
        try:
            if allowed and not _active(profile):
                size=_size(profile)
                item={'profile':str(profile),'action':'remove completed worker clone','eligible_bytes':size,'freed_bytes':0,'warnings':[]}
                if apply:shutil.rmtree(profile);item['freed_bytes']=size
            else:
                item=trim_worker_cache(profile,apply=apply);item['action']='trim regenerable cache only'
                if reason:item['warnings'].append(reason)
            report['profiles'].append(item)
            report['eligible_bytes']+=item['eligible_bytes'];report['freed_bytes']+=item['freed_bytes']
        except OSError as error:report['warnings'].append(f'{profile.name}: {type(error).__name__}')
    return report

"""v7.0.71 Flow duplicate-spend guard.

Every credit-bearing Flow video submission must pass through this module.

* Check mode: while a saved request is being checked or downloaded, no new
  prompt may be sent and no approval card may be clicked. ``check_only()`` is
  process-wide, so a nested or concurrent caller cannot re-enable submission.
* Per-take ledger (``<take>.mp4.submit-ledger.jsonl``): an ``intent`` line is
  appended and fsynced *before* the Send/Enter action, and a ``submitted`` line
  after it returns. Any ``intent``/``submitted``/unreadable line blocks every
  later submission for that exact take file, including after a process restart,
  a factory retry or a job restart. A saved ``.flow-request.json`` also blocks.
* Per-job ledger (``<job>/flow_submission_ledger.jsonl``) with a cap on the
  number of intents. Exceeding the cap requires an explicit, logged
  confirmation file written by the user through ``cli.py resume
  --flow-submission-cap N``.

Blocking raises ``SubmissionBlocked``. Providers convert it to a pending
(non-retried) Flow error so the factory never silently spends again.
"""
from __future__ import annotations

import contextlib
import json
import os
import threading
import time
import uuid

LEDGER_SUFFIX = ".submit-ledger.jsonl"
JOB_LEDGER_NAME = "flow_submission_ledger.jsonl"
JOB_CAP_NAME = "flow_submission_cap.json"
DEFAULT_JOB_CAP = 20
STARTED_EVENTS = frozenset({"intent", "submitted", "unreadable"})

_LOCK = threading.RLock()
_CHECK_DEPTH = 0


class SubmissionBlocked(RuntimeError):
    """A new Flow submission is refused. Nothing was sent."""


@contextlib.contextmanager
def check_only(reason: str = "check"):
    """Forbid every new Flow submission and approval click inside the block."""
    global _CHECK_DEPTH
    with _LOCK:
        _CHECK_DEPTH += 1
    try:
        yield reason
    finally:
        with _LOCK:
            _CHECK_DEPTH -= 1


def check_mode_active() -> bool:
    return _CHECK_DEPTH > 0


def _append(path: str, record: dict) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def read_events(path: str) -> list[dict]:
    if not os.path.isfile(path):
        return []
    events: list[dict] = []
    with open(path, encoding="utf-8") as handle:
        for raw in handle:
            raw = raw.strip()
            if not raw:
                continue
            try:
                events.append(json.loads(raw))
            except ValueError:
                events.append({"event": "unreadable"})
    return events


def take_ledger(out_path: str) -> str:
    return out_path + LEDGER_SUFFIX


def job_ledger_for(out_path: str) -> str | None:
    """Return the job ledger for ``<job>/shots/<shot>/take.mp4``, if derivable."""
    current = os.path.dirname(os.path.abspath(out_path))
    while current and current != os.path.dirname(current):
        if os.path.basename(current) == "shots":
            return os.path.join(os.path.dirname(current), JOB_LEDGER_NAME)
        current = os.path.dirname(current)
    return None


def submission_started(out_path: str) -> bool:
    """True when this take already has (or may have) a sent Flow request."""
    if os.path.exists(out_path + ".flow-request.json"):
        return True
    if os.path.exists(out_path + ".flow-request.before-regeneration.json"):
        return True
    return any(event.get("event") in STARTED_EVENTS
               for event in read_events(take_ledger(out_path)))


def job_cap(job_ledger: str | None) -> int:
    if not job_ledger:
        return DEFAULT_JOB_CAP
    cap_path = os.path.join(os.path.dirname(job_ledger), JOB_CAP_NAME)
    if os.path.isfile(cap_path):
        try:
            with open(cap_path, encoding="utf-8") as handle:
                return max(1, int(json.load(handle).get("cap", DEFAULT_JOB_CAP)))
        except (OSError, ValueError, AttributeError):
            return DEFAULT_JOB_CAP
    return DEFAULT_JOB_CAP


def write_job_cap(job_dir: str, cap: int, confirmed_by: str = "cli") -> str:
    """Record an explicit user confirmation for a higher per-job cap."""
    cap = int(cap)
    if cap < 1 or cap > 500:
        raise ValueError("Flow submission cap must be between 1 and 500")
    target = os.path.join(job_dir, JOB_CAP_NAME)
    os.makedirs(job_dir, exist_ok=True)
    with open(target + ".tmp", "w", encoding="utf-8") as handle:
        json.dump({"cap": cap, "confirmed_by": confirmed_by, "at": time.time()}, handle, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(target + ".tmp", target)
    return target


def gate(out_path: str) -> str | None:
    """Raise unless one new submission for ``out_path`` is allowed right now.

    Returns the job ledger path (or None) for later ``record`` calls.
    """
    if check_mode_active():
        raise SubmissionBlocked("check mode is active; no new Flow prompt or approval may be sent")
    if submission_started(out_path):
        raise SubmissionBlocked(
            f"take {os.path.basename(out_path)} already has a recorded Flow submission; "
            "download-only recovery applies and no second prompt will be sent")
    job_ledger = job_ledger_for(out_path)
    if job_ledger:
        intents = sum(1 for e in read_events(job_ledger) if e.get("event") == "intent")
        cap = job_cap(job_ledger)
        if intents >= cap:
            raise SubmissionBlocked(
                f"job submission cap reached ({intents}/{cap}); confirm a higher cap with "
                "`cli.py resume <job> --flow-submission-cap N` before any new Flow video is sent")
    return job_ledger


def record_intent(out_path: str, job_ledger: str | None, *, request_id: str = "", **fields) -> str:
    """Write-ahead record immediately before the Send action.

    Re-checks the take ledger so two paths cannot both pass the gate.
    """
    if check_mode_active():
        raise SubmissionBlocked("check mode is active; no new Flow prompt may be sent")
    if any(e.get("event") in STARTED_EVENTS for e in read_events(take_ledger(out_path))):
        raise SubmissionBlocked(f"take {os.path.basename(out_path)} already has a Flow submission intent")
    request_id = request_id or uuid.uuid4().hex
    record(out_path, job_ledger, "intent", request_id=request_id, **fields)
    return request_id


def record(out_path: str, job_ledger: str | None, event: str, *, request_id: str = "", **fields) -> None:
    entry = {"event": event, "take": os.path.basename(out_path), "out_path": os.path.abspath(out_path),
             "request_id": request_id, "ts": time.time(), "pid": os.getpid(), **fields}
    _append(take_ledger(out_path), entry)
    if job_ledger:
        _append(job_ledger, entry)


def may_retry(out_path: str) -> bool:
    """Factory retry predicate: a take that started submission is never re-submitted."""
    return not submission_started(out_path) and not check_mode_active()

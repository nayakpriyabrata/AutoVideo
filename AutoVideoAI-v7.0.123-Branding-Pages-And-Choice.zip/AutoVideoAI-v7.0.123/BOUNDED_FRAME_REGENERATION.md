# v7.0.42 bounded frame regeneration add-on

Revision 2 fixes recovery after a download target closes. It first reuses the
recorded asset identity or its exact captured prompt, rather than requiring the
reopened gallery to contain only one fresh thumbnail. In this isolated one-frame
project only, changed thumbnail URLs may also be resolved by downloading up to
three image candidates, excluding the two known master images by content, and
requiring exactly one image to remain. Download reconnections are bounded to
three attempts and never submit again. An already saved, valid download artifact
can be committed without re-downloading. Keep the existing ledger and projects.

This adds a CLI recovery workflow for unresolved **worker storyboard image**
requests. It preserves other frames, accepted takes, narration, configuration
and the shared workspace. It does not replace the whole installation or bump
VERSION. Close running jobs and stop Studio while installing.

From the existing installation, after downloading this ZIP into Windows Downloads:

```bash
unzip -o ../../AutoVideoAI-v7.0.42-Bounded-Frame-Regeneration-v2.zip -d /tmp/autovideo-frame-regeneration
python3 /tmp/autovideo-frame-regeneration/install.py . --apply
python3 tools/regenerate_unresolved_flow_images.py
```

The preview must have `blocked: []`. For the supplied Little Kanha report,
10 old requests represent seven distinct frame roles. Original and replacement
journals must have the same saved creative brief to be grouped.

```bash
python3 tools/regenerate_unresolved_flow_images.py --apply --max-replacements 7
```

If it reports `ready_to_resume`:

```bash
python3 cli.py v3 resume 20261012-132342-littile-kanha-playing-ra-a7e2
```

If it reports `replacement_pending`, repeat the **regeneration tool command**
to recover its reserved replacements. That command never resends an uncertain
submission. Do not delete its ledger or requests. Its report lives under
`outputs/<job>/authorized_frame_replacements/report.json`.

## Behavior

- One durable reservation per frame; seven-request total cap for this job.
- A different initially empty project for each frame, with saved character and
  location masters attached. Reference uploads must settle before submission.
- The sole new image after that reference baseline belongs to the one request
  in this project. Record its project, asset signature and actual returned prompt
  before downloading; wording changes do not defeat this capture policy.
- Require a decoded image and reject byte/pixel copies of the uploaded references.
  Multiple generated images remain unresolved unless a previously captured
  identity or its exact actual prompt identifies one. Uploaded master copies
  are excluded from the isolated-project content fallback.
- Preserve original request backups and mark old journals as **superseded**,
  not downloaded. Install the replacement in its worker output(s) and canonical
  opening/closing path. Each frame commits independently.
- Safe Resume verifies replacement hashes before accepting supersession.
- Original media and replaced code are backed up. Runtime data is not migrated.

## Validation and limits

Regression tests cover one-shot reservation/recovery, rewritten prompts,
reference-copy rejection, upload settlement, multiple fresh results, cap
enforcement, partial commit replay and replacement-hash checks. Browser behavior
is simulated; no live Flow generation has been tested here.

The workflow still depends on Flow availability, an authenticated browser and
the supported Agent UI. It requests the saved no-charge Lite image model and
does not approve a positive-cost generation confirmation. Existing or new
generations may nevertheless affect your Flow credit balance according to its
current service behavior. Visual meaning, Radha's likeness and animation quality
are not proven by image decoding or asset identity; inspect the eventual video.

This recovers seven image roles, not the entire future video generation pipeline.
Later video requests and rendering can have their own failures. The tool stops
on ambiguous results and never promises that external services cannot fail.

Run the focused tests from the installation:

```bash
python3 -m unittest discover -s tests -p test_bounded_frame_regeneration.py -v
```

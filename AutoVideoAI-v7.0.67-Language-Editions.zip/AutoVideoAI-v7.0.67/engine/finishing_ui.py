"""Streamlit UI for reviewable language editions of saved video exports."""
import hashlib
import json
from pathlib import Path
from . import finishing_studio as finish
from .studio_review import discover_clips


def _upload(uploaded, kind):
    if uploaded is None:return ''
    data=uploaded.getvalue()
    if not data or len(data)>200*1024*1024:raise ValueError('Upload must be 1 byte–200 MB')
    suffix=Path(uploaded.name).suffix.lower()
    if suffix not in finish.MEDIA_EXT:raise ValueError('Unsupported uploaded media')
    folder=finish.shared_root()/'finishing_uploads';folder.mkdir(parents=True,exist_ok=True)
    path=folder/(kind+'-'+hashlib.sha256(data).hexdigest()[:24]+suffix)
    if not path.exists():path.write_bytes(data)
    return str(path)


def show(st):
    st.title('Finishing Studio')
    st.caption('Reuse a saved clip or completed video in English, Hindi or Odia. Each reviewed edition exports separately; the original is never changed. No Flow credit is used.')
    with st.expander('Channel profiles · one profile per actual channel',expanded=not finish.profiles()):
        st.info('Create a separate profile for each channel: for example The Skill Shift Academy, Hunar Setu and Odia Pragati. Each profile owns its logo, intro and outro. Save each channel once, then choose it for a language below.')
        name=st.text_input('This channel’s name',key='finish-channel-name',placeholder='e.g. Hunar Setu')
        st.caption('Optional media below belongs only to the named channel. Leaving an upload empty while updating preserves that channel’s saved media.')
        logo=st.file_uploader('Logo for this channel',type=['png','jpg','jpeg','webp'],key='finish-logo')
        intro=st.file_uploader('Intro video for this channel',type=['mp4','mov','mkv','webm'],key='finish-intro')
        outro=st.file_uploader('Outro video for this channel',type=['mp4','mov','mkv','webm'],key='finish-outro')
        music=st.file_uploader('Optional default music for this channel',type=['mp3','ogg','wav','m4a','flac'],key='finish-profile-music')
        music_license=st.text_input('Default music source and license/permission (if uploaded)',key='finish-profile-license')
        if st.button('Save this channel profile',key='finish-save-profile'):
            try:
                saved=finish.save_profile(name,logo=_upload(logo,'logo'),intro=_upload(intro,'intro'),
                       outro=_upload(outro,'outro'),music=_upload(music,'music'),music_license=music_license)
                st.success('Saved '+name+'. Create another profile for another channel.')
            except Exception as exc:st.error(str(exc))
    options=finish.profiles()
    if not options:
        st.info('Create at least one channel profile above to begin.');return
    from .audio.music_library import list_tracks
    choices=discover_clips()
    output=finish.shared_root()/'outputs'
    if output.is_dir():
        for path in list(output.glob('*/final*.mp4')) + list(output.glob('*/render/*-final*.mp4')):
            if path.is_file():choices.append({'path':str(path),'label':'Completed video / '+path.parent.name,'state':'ready'})
    source=st.selectbox('Saved source', ['Enter local MP4 path']+[r['path'] for r in choices],
                       format_func=lambda p:next((r['label'] for r in choices if r['path']==p),p))
    if source=='Enter local MP4 path':source=st.text_input('Local video path',key='finish-source-path')
    languages=st.multiselect('Language editions',['en','hi','or'],default=['en'],format_func=lambda x:finish.LANGUAGES[x])
    st.subheader('Choose the actual channel for each edition')
    channel_choices={}
    for lang in languages:
        channel_choices[lang]=st.selectbox(f'{finish.LANGUAGES[lang]} edition · channel logo, intro and outro',options,
              key='finish-profile-'+lang,format_func=lambda p:json.loads(p.read_text(encoding='utf8'))['name'])
    st.caption('The same background track can be shared across all editions, regardless of channel.')
    tracks=list_tracks()
    shared_choice=st.selectbox('Shared music for all editions',['None']+[r['path'] for r in tracks],key='finish-shared-music',
          format_func=lambda p:next((r['title']+' · '+r['license'] for r in tracks if r['path']==p),p))
    rights=st.selectbox('Source rights declaration',['own_content','licensed','creative_commons'])
    if st.button('Create finishing plan',disabled=not source or not languages):
        try:
            row=next((r for r in tracks if r['path']==shared_choice),None)
            if row and hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:
                raise ValueError('Music changed after import; import it again')
            path=finish.create_plan(source,channel_choices,languages=languages,source_rights=rights,
                  shared_music=row['path'] if row else None,
                  shared_music_license=(row['source_url']+' · '+row['license']) if row else '')
            st.session_state['finish-plan']=str(path);st.success('Draft plan saved: '+str(path))
        except Exception as exc:st.error(str(exc))
    plans=sorted((output/'finishing').glob('*/plan.json'),reverse=True) if (output/'finishing').is_dir() else []
    if not plans:return
    previous=st.session_state.get('finish-plan')
    index=next((i for i,p in enumerate(plans) if str(p)==previous),0)
    plan_path=st.selectbox('Saved finishing plan',plans,index=index,format_func=lambda p:p.parent.name)
    plan=json.loads(plan_path.read_text(encoding='utf8'))
    language=st.selectbox('Review edition',list(plan['editions']),format_func=lambda x:finish.LANGUAGES[x])
    edition=plan['editions'][language]
    st.caption(f"Source duration: {plan['source']['duration']:.1f}s · state: {plan['state']}")
    selected_channel=edition.get('channel',plan.get('channel',{})).get('name','Legacy channel profile')
    st.info(f'{finish.LANGUAGES[language]} edition belongs to **{selected_channel}**. Its logo, intro and outro are specific to that channel.')
    st.video(plan['source']['path'],width=480)
    if edition.get('narration'):
        st.audio(edition['narration']['path'])
        st.caption('Saved narration timing: '+edition.get('timing_source','review required'))
    st.caption('Cards use seconds relative to the original video. Keep them brief and away from faces or important action.')
    transcript=st.text_area('Reviewed transcript or video context for optional Gemini suggestions',value=edition.get('script',''),height=110,key='finish-transcript-'+str(plan_path)+language)
    if st.button('Suggest cards and music mood with Gemini Web',disabled=not transcript.strip()):
        try:
            draft=finish.propose_cards(transcript,plan['source']['duration'],language)
            st.session_state['finish-card-draft-'+str(plan_path)+language]=json.dumps(draft['cards'],ensure_ascii=False,indent=2)
            st.session_state['finish-cards-'+str(plan_path)+language]=json.dumps(draft['cards'],ensure_ascii=False,indent=2)
            st.info('Draft suggestion only. Review the wording and times before saving. Music mood: '+str(draft.get('music_mood','')))
        except Exception as exc:st.error(str(exc))
    provider=st.selectbox('Narration provider for this edition', ['auto','gemini','gemini-lite','edge','gtts'], key='finish-tts-'+language)
    if st.button('Generate narration, then draft speech-timed cards', disabled=not transcript.strip()):
        try:
            from .speech_cards import prepare_edition
            from .production_lock import production_slot
            with production_slot(plan_path.parent):
                bundle=prepare_edition(plan_path.parent, transcript, language, provider=provider)
            st.session_state['finish-prepared-voice-'+str(plan_path)+language]=bundle['audio']
            st.session_state['finish-card-draft-'+str(plan_path)+language]=json.dumps(bundle['cards'],ensure_ascii=False,indent=2)
            st.session_state['finish-cards-'+str(plan_path)+language]=json.dumps(bundle['cards'],ensure_ascii=False,indent=2)
            st.audio(bundle['audio'])
            st.info(f"Narration saved: {bundle['duration']:.1f}s. Timing source: {bundle['timing_source']}. Review wording and pronunciation before saving.")
            if bundle['duration'] > plan['source']['duration']+.25:
                st.warning('This narration is longer than the footage. Shorten its script or provide a longer source; speech will not be cut silently.')
        except Exception as exc:st.error(str(exc))
    default=json.dumps(edition['cards'],ensure_ascii=False,indent=2)
    cards=st.text_area('Reviewed text cards JSON · [{"start":2,"end":5,"text":"..."}]',
         value=st.session_state.get('finish-card-draft-'+str(plan_path)+language,default),height=150,key='finish-cards-'+str(plan_path)+language)
    narration=st.file_uploader('Optional narration audio for this language',type=['mp3','wav','ogg','m4a','flac'],key='finish-narration-'+str(plan_path)+language)
    tracks=list_tracks()
    music_choice=st.selectbox('Optional music override for this edition',['Use plan music']+[r['path'] for r in tracks],
                              format_func=lambda p: next((r['title']+' · '+r['license'] for r in tracks if r['path']==p),p))
    st.caption('Music will duck beneath the original audio or supplied narration. Confirm the track license covers your destination platforms.')
    edition_assets=edition.get('assets',plan.get('assets',{}))
    use_intro=st.checkbox(f'Include {selected_channel} intro',value=edition['intro'],disabled='intro' not in edition_assets)
    use_outro=st.checkbox(f'Include {selected_channel} outro',value=edition['outro'],disabled='outro' not in edition_assets)
    approved=st.checkbox('I reviewed these cards, media and rights for this edition',key='finish-approved-'+str(plan_path)+language)
    if st.button('Save reviewed edition',disabled=not approved):
        try:
            row=next((r for r in tracks if r['path']==music_choice),None)
            if row and hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:
                raise ValueError('Music changed after import; import it again')
            finish.set_edition(plan_path,language,cards=json.loads(cards),narration=_upload(narration,'narration') or st.session_state.get('finish-prepared-voice-'+str(plan_path)+language) or None,
                  music=row['path'] if row else '',music_license=(row['source_url']+' · '+row['license']) if row else None,
                  intro=use_intro,outro=use_outro,reviewed=True)
            st.success('Saved review. You can render this edition below.')
        except Exception as exc:st.error(str(exc))
    if st.button('Render this edition',disabled=not edition.get('reviewed')):
        progress=st.progress(0)
        try:
            result=finish.render(plan_path,language,progress=lambda v:progress.progress(float(v)))
            st.success('Exported: '+str(result));st.video(str(result),width=480)
        except FileExistsError as exc:st.info(str(exc))
        except Exception as exc:st.error(str(exc))
    exports=list((plan_path.parent/'exports').glob('*.mp4')) if (plan_path.parent/'exports').exists() else []
    for video in exports:
        st.write(finish.LANGUAGES.get(video.name.split('-')[0],'Video')+' · '+video.name)
        with video.open('rb') as handle:st.download_button('Download '+video.name,handle,file_name=video.name,key='finish-dl-'+str(video))

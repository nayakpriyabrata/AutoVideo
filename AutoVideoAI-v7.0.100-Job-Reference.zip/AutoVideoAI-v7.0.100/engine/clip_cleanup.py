"""Clip Studio disk cleanup (7.0.97): preview and remove what a clip batch leaves behind.

A Clip Studio run writes far more than the finished clips. In the chosen output folder (default
``outputs/my-clips``) it leaves the downloaded source video, speech chunks, caption/batch scratch
files and staged logos (``_clip_work/``), the per-batch selection reports (``clip-history/``), the
latest selection and B-roll reviews, the clip-render job state (``.clip-render-jobs/``) and the
rendered clips themselves.

Nothing here is deleted without a preview, an explicit category list and (for the rendered clips)
a separate opt-in. A folder with a running clip render is never touched, symlinks are skipped, and
nothing outside the selected folder is ever removed.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path

WORK_DIR = '_clip_work'
RENDER_STATE_DIR = '.clip-render-jobs'
HISTORY_DIR = 'clip-history'
REVIEW_NAMES = ('highlights.json', 'highlights.partial.json')
REVIEW_PATTERNS = ('broll-review-*.json', 'highlights.partial.json')

CATEGORIES = {
    'work': 'Downloaded source, speech chunks, caption and batch scratch files (_clip_work)',
    'render_state': 'Clip render job state (.clip-render-jobs)',
    'history': 'Per-batch selection reports (clip-history)',
    'reviews': 'Latest selection and B-roll review files',
    'clips': 'Rendered clips and their B-roll versions (*.mp4 in this folder)',
}
SAFE_CATEGORIES = ('work', 'render_state', 'history', 'reviews')


def _size(path: Path) -> int:
    path = Path(path)
    if path.is_symlink():
        return 0
    if path.is_file():
        return path.stat().st_size
    total = 0
    for directory, dirs, files in os.walk(path, followlinks=False):
        dirs[:] = [name for name in dirs if not (Path(directory) / name).is_symlink()]
        for name in files:
            item = Path(directory) / name
            if not item.is_symlink():
                try:
                    total += item.stat().st_size
                except OSError:
                    continue
    return total


def _inside(folder: Path, target: Path) -> bool:
    try:
        return target.resolve().is_relative_to(folder.resolve())
    except (OSError, ValueError):
        return False


def _clip_files(folder: Path) -> list[Path]:
    return sorted(path for path in folder.glob('*.mp4')
                  if path.is_file() and not path.is_symlink())


def _review_files(folder: Path) -> list[Path]:
    found = [folder / name for name in REVIEW_NAMES if (folder / name).is_file()]
    for pattern in REVIEW_PATTERNS:
        found.extend(sorted(path for path in folder.glob(pattern) if path.is_file()))
    unique = {}
    for path in found:
        if not path.is_symlink():
            unique[str(path)] = path
    return sorted(unique.values())


def looks_like_clip_output(folder) -> bool:
    folder = Path(folder)
    if folder.is_symlink() or not folder.is_dir():
        return False
    return ((folder / WORK_DIR).is_dir() or (folder / HISTORY_DIR).is_dir()
            or (folder / RENDER_STATE_DIR).is_dir()
            or (folder / 'highlights.json').is_file()
            or bool(_clip_files(folder)))


def render_running(folder) -> bool:
    """True while a clip render for this folder is live; such a folder is never cleaned."""
    folder = Path(folder)
    try:
        from .clip_render_jobs import _lock_active
        if _lock_active(folder):
            return True
    except Exception:
        pass
    for state in (folder / RENDER_STATE_DIR).glob('*/state.json') if (folder / RENDER_STATE_DIR).is_dir() else []:
        try:
            import json
            data = json.loads(state.read_text(encoding='utf-8'))
            if str(data.get('status') or '').lower() in ('running', 'queued', 'starting'):
                return True
        except (OSError, ValueError):
            continue
    return False


def folder_inventory(folder) -> dict:
    """What this Clip Studio output folder holds, per category, with bytes. Read-only."""
    folder = Path(folder).expanduser().absolute()
    report = {'folder': str(folder), 'exists': folder.is_dir() and not folder.is_symlink(),
              'is_clip_output': False, 'running': False, 'total_bytes': 0,
              'clips': 0, 'categories': [], 'warnings': []}
    if not report['exists']:
        report['warnings'].append('Folder is missing')
        return report
    report['is_clip_output'] = looks_like_clip_output(folder)
    report['running'] = render_running(folder)
    targets = {
        'work': [folder / WORK_DIR],
        'render_state': [folder / RENDER_STATE_DIR],
        'history': [folder / HISTORY_DIR],
        'reviews': _review_files(folder),
        'clips': _clip_files(folder),
    }
    for key, label in CATEGORIES.items():
        items, size, count = [], 0, 0
        for target in targets[key]:
            if not _inside(folder, target):
                report['warnings'].append(f'Skipped a path outside the folder: {target}')
                continue
            if not target.exists():
                continue
            items.append(str(target.relative_to(folder)))
            size += _size(target)
            count += 1 if target.is_file() else len(list(target.rglob('*')))
        report['categories'].append({'key': key, 'label': label, 'paths': items,
                                     'bytes': size, 'items': count,
                                     'destructive': key == 'clips'})
    report['clips'] = len(_clip_files(folder))
    report['total_bytes'] = sum(row['bytes'] for row in report['categories'])
    if report['running']:
        report['warnings'].append('A clip render is running for this folder; cleanup is refused')
    return report


def discover(root, extra=()) -> list[dict]:
    """Every Clip Studio output folder under ``root`` (plus explicitly named ones)."""
    root = Path(root).expanduser().absolute()
    found: dict[str, Path] = {}
    for candidate in extra:
        if not candidate:
            continue
        path = Path(candidate).expanduser()
        if not path.is_absolute():
            path = root / path
        found[str(path.absolute())] = path.absolute()
    if root.is_dir() and not root.is_symlink():
        for directory, dirs, _files in os.walk(root, followlinks=False):
            current = Path(directory)
            dirs[:] = [name for name in dirs if not (current / name).is_symlink()
                       and name not in RENDER_STATE_DIR and name != WORK_DIR]
            if not looks_like_clip_output(current):
                continue
            found[str(current.absolute())] = current.absolute()
            # A clip folder never nests another clip folder.
            dirs[:] = []
    return [folder_inventory(path) for path in sorted(found.values())]


def cleanup(folder, categories=SAFE_CATEGORIES, *, apply=False, include_clips=False) -> dict:
    """Remove the requested categories from one Clip Studio output folder.

    ``include_clips`` must be True to remove rendered clips; they are the product, not scratch data.
    """
    folder = Path(folder).expanduser().absolute()
    if folder.is_symlink() or not folder.is_dir():
        raise ValueError('Choose an existing real Clip Studio output folder')
    if not looks_like_clip_output(folder):
        raise ValueError('This folder does not look like Clip Studio output; nothing was changed')
    wanted = [key for key in categories if key in CATEGORIES]
    if include_clips and 'clips' not in wanted:
        wanted.append('clips')
    if 'clips' in wanted and not include_clips:
        wanted.remove('clips')
    report = {'folder': str(folder), 'apply': apply, 'requested': wanted,
              'eligible_bytes': 0, 'freed_bytes': 0, 'removed': [], 'warnings': []}
    if not wanted:
        report['warnings'].append('No category was selected')
        return report
    if render_running(folder):
        report['warnings'].append('A clip render is running for this folder; nothing was removed')
        return report
    targets = {'work': [folder / WORK_DIR], 'render_state': [folder / RENDER_STATE_DIR],
               'history': [folder / HISTORY_DIR], 'reviews': _review_files(folder),
               'clips': _clip_files(folder)}
    for key in wanted:
        for target in targets[key]:
            if not _inside(folder, target):
                report['warnings'].append(f'Skipped a path outside the folder: {target}')
                continue
            if not target.exists() or target.is_symlink():
                continue
            size = _size(target)
            report['eligible_bytes'] += size
            if not apply:
                continue
            try:
                if target.is_dir():
                    shutil.rmtree(target)
                else:
                    target.unlink()
                report['freed_bytes'] += size
                report['removed'].append(str(target.relative_to(folder)))
            except OSError as error:
                report['warnings'].append(f'{target.name}: {type(error).__name__}')
    return report

# AutoVideoAI 7.0.78: Odia text cards, Odia caption timing and Odia narration

Update from 7.0.77 with `tools/update_v777_to_v778.py`. Code and documentation only. Saved jobs, outputs, browser profiles, music, characters and channel profiles are never touched.

## What was wrong and what changed

1. **Odia text cards overlapped.** Indic glyphs were positioned from the baseline, but Pillow positions text from the ascender line. Odia vowel signs and conjuncts therefore sat one ascender too high, over the title or the line above. `engine/render/indic_font.py` now positions glyphs from the ascender line and reports real font metrics. Hindi (Devanagari) uses the same class when Raqm is not installed, so Hindi cards are corrected too.

2. **Odia caption timing drifted.** The shared Odia job had no usable provider timings (Gemini TTS returns none, and the transcription providers produced none for Odia), so Odia captions were spread across the whole file by character count. The spread ignored pauses, so captions ran later and later. `engine/captions.py` now detects the voiced parts of the narration and places the script words inside them. A word boundary near a detected pause snaps to that pause, so no word straddles a pause. Timings cached by 7.0.77 for this fallback are recomputed once. Timings from a real provider are kept.

3. **Odia caption repair crashed.** When ASR anchors looked implausible on audio of 30 s or more, `align_words_to_script` referenced undefined names (`audio_path`, `detail`). It now returns the estimated timing.

4. **Odia and Hindi text-card copy could be written in English.** The drafter received only the code `or`. It is now told the language by name and must write every card, title and point in that script. Copy that is not in the edition's script is retried once with a direct correction. If the retry is also wrong, the drafting step stops with a clear message and nothing is shipped. English editions are not checked.

5. **Odia narration was not told its language.** The Gemini TTS request carried only the English narrator style. It now names Odia (or Hindi) and asks for native pronunciation without translation. The instruction is kept even when a caller supplies its own style.

## Checks

- `tests/test_v778_odia_fixes.py`: 11 tests (timing on synthetic speech with pauses, schedule boundaries, stale cache recompute, card language retry and refusal, TTS language direction, the caption repair crash, and Indic glyph bounds for Odia and Devanagari).
- Synthetic speech with pauses (four phrases, 0.9 s pauses): worst word-start drift 0.18 s, down from 0.88 s with the 7.0.77 spread. This is a test signal, not a measurement of real Odia narration.
- Odia series and single card rendered at 1080×1920: titles, points and the highlight bar no longer overlap.

## Not verified here

- Real Odia narration. Measured Odia word timing needs the Odia voice file from a real job; the caption lag fix must be confirmed on one.
- Gemini TTS accent and pronunciation for Odia. The language instruction is in place; listen to one render.
- Gemini Web card drafting in Odia. The check and retry are in place; confirm the first Odia edition's cards.
- Raqm-enabled Pillow. This build was tested with the fallback path; the Raqm path is unchanged.

## Updating

From a 7.0.77 installation:

    python3 ../AutoVideoAI-v7.0.78/tools/update_v777_to_v778.py .
    python3 ../AutoVideoAI-v7.0.78/tools/update_v777_to_v778.py . --apply

Stop the dashboard before `--apply`. From 7.0.76 or earlier, the updater prints the earlier steps to run first.

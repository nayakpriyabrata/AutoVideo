# AutoVideoAI v7.0.39: automatic Flow recovery

This release addresses the repeated reference-menu and browser/download interruptions observed in the supplied v7.0.38 log. Recoverable interruptions now trigger automatic Resume with backoff, rather than requiring another manual Resume each time. This is enabled by default for existing jobs.

## Upgrade and continue the existing job

Stop Studio and any running AutoVideoAI job before migrating. Extract this release beside the old installation and run these commands from the new `AutoVideoAI-v7.0.39` folder. Keep the old installation until the migrated job is verified.

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.38 . --apply
python3 cli.py v3 resume 20261010-141959-7-morning-habits-that-ca-40b7
```

Adjust the old folder path if it has a different name. Migration retains existing settings, jobs and saved media. The Gallery & Downloads selection, preview, download and whole-job/clip-folder cleanup from v7.0.38 are included.

## Recovery behavior

- Typed recoverable Flow reference, pending-request, browser-closure, network and service-busy interruptions are retried automatically. Providers are closed before each retry, including sessions left open by interrupted storyboard generation.
- Retries wait between 10 and 60 seconds, with progress messages during the wait. Four retries are allowed without new validated saved frames or accepted takes; an advancing run can make twenty retries in total. Exhaustion preserves the job and pauses it for attention. Another explicit Resume starts a new bounded recovery run.
- The reference picker dismisses visible stale menus using Escape before clicking Add ingredients. If an overlay remains blocked, it does not force a click through it.
- After browser recovery, a rotated image signature can be rebound only through the existing saved request and exact prompt matching. An ambiguous image remains pending; recovery does not guess the newest tile or submit another video generation.
- Identical cached opening/closing frames used for non-Flow image-motion output are kept for quality review rather than regenerated on each Resume. Strict Flow video frame checks remain in place.
- `automatic_recovery.json` in the job folder records retry history and recovery state. Ctrl+C stops recovery; saved media and request journals remain available to Resume.

To disable the supervisor for a job, set `"flow_auto_recovery": false` in its settings JSON while the job is stopped.

## Limits

No release can guarantee that Flow, Chrome, authentication or the network never fails. Authentication, exhausted quota, required approval, changed/missing approved media, ambiguous recovery and exhausted retry limits still require attention. Existing spending limits, cast verification and approval requirements remain enforced. Automated tests cover recovery behavior; live Google Flow generation on the user's machine remains unverified.

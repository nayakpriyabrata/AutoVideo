import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from engine.providers.flow_browser import FlowBrowserProvider
from engine.flow_recovery_review import candidates,bind_reviewed


def journal(marker='AVREQ_'+ 'b'*24):
    r={'kind':'image','status':'pending','request_hash':hashlib.sha256(b'shot_004 close').hexdigest(),
       'project_url':'https://flow.google.com/project/saved-project','baseline':[],
       'submitted_prompt':marker+' tracking metadata. Create the closing frame in a studio.',
       'request_marker':marker,'signature':''}
    r['request_marker_context_sha256']=FlowBrowserProvider._request_marker_context(r)
    return r


def test_rewritten_prompt_recovers_by_unique_marker_and_saves_binding():
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider);r=journal()
    actual='Flow rewritten: woman closing her laptop. '+r['request_marker']
    assets=[{'sig':'old','kind':'image'},{'sig':'exact','kind':'image'},{'sig':'wrong-video','kind':'video'}]
    # Recovery works even if the baseline erroneously contains the exact tile.
    r['baseline']=['exact']
    bridge=NS(media_assets=lambda:assets,read_asset_generation_prompt=lambda sig: actual if sig=='exact' else 'unrelated')
    assert provider._identify_single_fresh_asset(bridge,r,'image',0)=='exact'
    assert provider._bound_recovery_prompt(r)==actual
    assert r['correlation_method']=='exact_request_marker'
    assert r['verified_prompt_binding']['source']=='exact_request_marker'


@pytest.mark.parametrize('field,value',[('request_hash','c'*64),('project_url','https://flow.google.com/project/other'),
    ('submitted_prompt','changed'),('request_marker','AVREQ_'+'d'*24)])
def test_marker_proof_rejects_changed_request_context(field,value):
    r=journal();r[field]=value
    assert FlowBrowserProvider._verified_request_marker(r) is None


@pytest.mark.parametrize('text',[ 'AVREQ_'+'b'*23, 'AVREQ_'+'b'*24+'suffix',
    'AVREQ_'+'b'*24+' AVREQ_'+'c'*24, 'another AVREQ_'+'c'*24 ])
def test_partial_other_and_mixed_request_labels_never_match(text):
    assert not FlowBrowserProvider._matches_request_marker(journal(),text)


def test_same_prompt_requests_use_distinct_markers():
    first=journal();second=journal('AVREQ_'+'c'*24)
    assert first['request_hash']==second['request_hash']
    assert not FlowBrowserProvider._matches_request_marker(second,first['submitted_prompt'])


def test_legacy_v712_request_label_remains_compatible():
    r=journal();r.pop('request_marker_context_sha256')
    r['request_marker']='AVREQ_'+r['request_hash'][:24];r['submitted_prompt']=r['request_marker']+' still image'
    assert FlowBrowserProvider._verified_request_marker(r)==r['request_marker']


def test_gallery_scans_continue_past_first_twelve_and_retain_evidence():
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider);r=journal()
    assets=[{'sig':str(i),'kind':'image'} for i in range(20)];reads=[]
    def read(sig):
        reads.append(sig);return 'rewritten '+r['request_marker'] if sig=='18' else 'other prompt '+sig
    bridge=NS(media_assets=lambda:assets,read_asset_generation_prompt=read)
    assert provider._identify_single_fresh_asset(bridge,r,'image',0)==''
    assert reads==[str(i) for i in range(12)]
    assert provider._identify_single_fresh_asset(bridge,r,'image',0)=='18'
    assert len(r['prompt_candidate_evidence'])==20
    assert '18' in reads[12:]


def test_unrelated_media_preserves_unresolved_request():
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider);r=journal()
    bridge=NS(media_assets=lambda:[{'sig':'wrong','kind':'image'}],read_asset_generation_prompt=lambda sig:'A different scene')
    assert provider._identify_single_fresh_asset(bridge,r,'image',0)==''
    assert 'verified_prompt_binding' not in r and r['status']=='pending'


def test_equivalent_review_candidates_deduplicate_and_bind_once(tmp_path):
    r=journal();r['prompt_candidate_evidence']=[{'prompt':'Reviewed closing frame','asset_fingerprint':'1'},
                                              {'prompt':'Reviewed closing frame','asset_fingerprint':'2'}]
    file=tmp_path/'close.jpg.flow-request.json';file.write_text(json.dumps(r))
    options=candidates(tmp_path);assert len(options)==1
    assert bind_reviewed(tmp_path,options[0])['new_generations']==0
    saved=json.loads(file.read_text());assert saved['verified_prompt_binding']['prompt']=='Reviewed closing frame'
    # The saved binding remains valid after a later Resume and path migration.
    assert FlowBrowserProvider._bound_recovery_prompt(saved)=='Reviewed closing frame'
    saved['project_url']='https://flow.google.com/project/other';file.write_text(json.dumps(saved))
    with pytest.raises(ValueError,match='changed'):bind_reviewed(tmp_path,options[0])


def test_submission_persists_complete_marker_proof_before_generate(tmp_path):
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider);r=journal()
    provider._active_request_hash=r['request_hash']
    out=str(tmp_path/'close.jpg')
    provider._record_submission(out,r['project_url'],{'old'},'image',
                                submitted_prompt=r['submitted_prompt'],request_marker=r['request_marker'])
    saved=json.loads(Path(out+'.flow-request.json').read_text())
    assert saved['status']=='pending' and saved['baseline']==['old']
    assert provider._verified_request_marker(saved)==r['request_marker']
    assert not Path(out).exists()


def test_resume_recovers_rewritten_image_without_generation(tmp_path):
    from PIL import Image
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider);r=journal()
    prompt='shot_004 closing frame'
    r['request_hash']=hashlib.sha256(json.dumps(['image','shot_004',prompt,True],sort_keys=True).encode()).hexdigest()
    r['request_marker_context_sha256']=provider._request_marker_context(r)
    out=str(tmp_path/'close.jpg');provider._save_request(out,r)
    downloads=[];actual='Rewritten laptop closing scene '+r['request_marker']
    def download(*a,**kw):
        downloads.append(kw['preferred_signature']);Image.new('RGB',(200,300),'blue').save(out)
    bridge=NS(ensure_project=lambda *a,**kw:None,
        media_assets=lambda:[{'sig':'exact','kind':'image'},{'sig':'unrelated','kind':'image'}],
        read_asset_generation_prompt=lambda sig:actual if sig=='exact' else 'other image',download_latest_asset=download)
    provider._ensure=lambda:bridge
    provider._generate_image_once=lambda *a,**kw:pytest.fail('No replacement generation allowed')
    result=provider._guarded_generation_once(NS(shot_id='shot_004'),{'prompt':prompt,'flow_image_signature_wait_ms':0},None,out,True,False,'image')
    saved=json.loads(Path(out+'.flow-request.json').read_text())
    assert downloads==['exact'] and result['credits']==0 and saved['status']=='downloaded'
    assert provider._bound_recovery_prompt(saved)==actual


def test_scan_progress_survives_gallery_url_changes():
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider);r=journal()
    assets=[{'sig':f'old-{i}','kind':'image'} for i in range(20)]
    bridge=NS(media_assets=lambda:assets,read_asset_generation_prompt=lambda s:'unrelated')
    assert provider._identify_single_fresh_asset(bridge,r,'image',0)==''
    assets[:]=[{'sig':f'rotated-{i}','kind':'image'} for i in range(20)]
    bridge.read_asset_generation_prompt=lambda s: 'Exact rewritten '+r['request_marker'] if s=='rotated-18' else 'unrelated'
    assert provider._identify_single_fresh_asset(bridge,r,'image',0)=='rotated-18'

# v7.0.45 — reopen an exact saved Clip Studio B-roll review

Clip Studio stored the B-roll review correctly, but **Load saved highlights** cleared only its in-memory path. The next search tried to create the same deterministic review file again and raised `A B-roll review already exists. Confirm replacement before searching again.` This could appear while returning to the approval workflow even though discovery had already completed.

v7.0.45 reopens the existing review instead of searching again only when all of these identities still match:

- the original source-video path and SHA-256;
- every referenced highlight path and SHA-256;
- the saved review is a Clip Studio review with candidates.

Saved approve/skip decisions are retained. Each B-roll candidate is still checked against its own exact-file hash during approval and rendering. If a source or highlight changed, Studio refuses reuse and asks for **Replace previous suggestions**. It never silently associates an old review with changed clips.

This build also includes the v7.0.44 exact-video-download recovery.

## Update the current installation

Stop Studio and the local runner. Extract the v7.0.45 ZIP beside the existing folder. From the existing `AutoVideoAI-v7.0.42` folder, whose VERSION currently says 7.0.43 or 7.0.44, run:

```bash
python3 ../AutoVideoAI-v7.0.45/tools/update_v743_to_v745.py . --apply
cat VERSION
bash dashboard.sh
```

VERSION must say `7.0.45`. The updater changes code only, creates a backup, and preserves shared outputs, highlights, B-roll downloads, reviews, profiles and settings.

## Continue the existing B-roll review

1. Open **Clip Studio** and use **Load saved highlights for B-roll review — no regeneration**.
2. Enable **Prepare related stock B-roll suggestions**.
3. Click **Search related stock for these highlights** once. Studio will report that it reopened the exact existing review; no stock search is repeated.
4. Select **All clips**, confirm the rights checkbox, then use **Approve available batch** or **Approve all & render**.

Keep **Replace previous suggestions** off unless you intentionally want to discard the old candidate set and run a new search.

## Validation

47 focused regression tests passed. They cover exact saved-review recovery, preservation of existing decisions, refusal after a highlight changes, the Streamlit batch-approval controls, batch approval integrity, changed-asset skipping, incomplete-review blocking, and the v7.0.44 video-download safeguards. Live rendering still depends on the local FFmpeg build and the availability of the previously downloaded assets.

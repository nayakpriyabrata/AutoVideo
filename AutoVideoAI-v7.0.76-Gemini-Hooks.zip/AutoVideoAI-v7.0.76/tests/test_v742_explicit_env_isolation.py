import os
from pathlib import Path

from engine.env_config import load_environment, _candidate_files


def test_explicit_root_does_not_scan_neighbors(monkeypatch, tmp_path):
    isolated = tmp_path / 'isolated'
    isolated.mkdir()
    neighbor = tmp_path / 'AutoVideoAI-v7.0.39'
    neighbor.mkdir()
    (neighbor / '.env').write_text('GOOGLE_API_KEY=neighbor-secret\n')
    (isolated / '.env').write_text('GOOGLE_API_KEY=google-test\n')
    monkeypatch.delenv('GEMINI_API_KEY', raising=False)
    monkeypatch.delenv('GOOGLE_API_KEY', raising=False)
    report = load_environment(isolated)
    assert os.environ['GEMINI_API_KEY'] == 'google-test'
    assert all(str(neighbor) not in item for item in report['files_found'])


def test_explicit_root_can_use_symlinked_shared_env(monkeypatch, tmp_path):
    shared = tmp_path / 'shared' / 'secrets'
    shared.mkdir(parents=True)
    (shared / '.env').write_text('GEMINI_API_KEY=shared-test\n')
    root = tmp_path / 'AutoVideoAI-v7.0.41'
    root.mkdir()
    (root / '.env').symlink_to(shared / '.env')
    monkeypatch.delenv('GEMINI_API_KEY', raising=False)
    report = load_environment(root)
    assert os.environ['GEMINI_API_KEY'] == 'shared-test'
    assert report['present']['GEMINI_API_KEY']


def test_default_mode_retains_existing_discovery(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    paths = _candidate_files()
    assert (tmp_path / '.env').resolve() in paths

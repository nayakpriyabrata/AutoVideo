# Download diagnostics (v7.0.88)

## Why this release exists

The shot_010 image still failed under 7.0.87 with `Image download target closed (URL scheme=blob)`.
Across the 2026-10-24 run (47 download events) about half saved and about half failed, and the failures
came two to three seconds after the download event. The log did not show why, because:

- The in-page blob capture never saved an image in any attempt, and every miss returned silently.
- `save_as` failures kept only the category `browser_artifact_target_closed`. The Playwright exception class
  and message were discarded.
- Nothing recorded whether the page, the browser context or the browser closed, crashed or disconnected.
- The UI blob capture never logged whether any click reached its page handler.

## What changes

Log-only. No download, retry, save or recovery behaviour changes.

- `engine/flow_download_diagnostics.py` (new): short diagnostic helpers. Exception text keeps the class and a
  capped message, with URLs removed. URLs are logged only as scheme and host.
- Page, context and browser watch for each image download window: `close`, `crash`, context `close` and browser
  `disconnected` are logged with the time after the click. Listeners are removed when the window ends.
- At each download event: whether the download belongs to the clicked page and whether that page is open,
  the URL shape, and the watch events so far.
- When `save_as` ends with a closed-target error: the Playwright exception class and redacted message, the
  download owner, and the browser state.
- In-page blob capture: one line per miss with reason codes (`page:closed`, `page:not_flow_page`,
  `blob_not_fetchable_in_page`, `payload_invalid`, `asset_invalid`, `error <class>`, and so on).
- UI blob capture: `armed` or `not armed: <class>: <message>` at arm time, and a summary at the end:
  `messages`, `foreign` (messages from another page), `chunks`, `bytes`, `error`. `messages=0` means the page's
  click handler never ran.
- Window end line: watch events, clicked-page state and browser state.

## Reading the next failing run

Search the runtime log for `[Flow][diag]`. Interpretation:

- `page closed while saving ...` or `browser context closed ...` before `save_as error`: Chrome or Flow closed the
  download's own target. Check whether the page belonged to the window the user saw.
- `page crashed ...`: the renderer crashed. The Chrome crash page or `chrome://crashes` is then the next evidence.
- `browser disconnected ...`: the DevTools connection dropped. Check Chrome's own window and logs.
- `save_as error: TargetClosedError ...` (or another class) with no close, crash or disconnect event: the
  download itself was refused or canceled. The exception text names the cause.
- `exact UI blob capture ... messages=0`: the page's click handler did not see Flow's click, so the UI-side
  capture never ran. Non-zero `messages` with an `error` names the failing step.
- `in-page blob capture did not save (blob:flow.google.com): page:closed` means the owning page was already gone
  when the blob was read.

## Updating

Install from the 7.0.87 installation folder:

    python3 ../AutoVideoAI-v7.0.88/tools/update_v787_to_v788.py .            # dry run
    python3 ../AutoVideoAI-v7.0.88/tools/update_v787_to_v788.py . --apply    # installs the code

Stop the dashboard first. Restart it after the update.

## Tests

`tests/test_v788_download_diagnostics.py` uses fakes only (no browser, no Flow, no generation).

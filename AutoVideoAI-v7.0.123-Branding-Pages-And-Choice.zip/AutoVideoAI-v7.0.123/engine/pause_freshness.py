"""v7.0.104: a saved pause must not describe a request that is already resolved.

Field case (job ``20261022-143856-7-small-daily-habits-tha-9729``, 2026-10-27 10:07 IST): the Queue said

    Job needs recovery at shot_018 · 17/45 accepted shots are saved.
    Flow video request is saved at …/flow/shots/shot_014/take_01.mp4.flow-request.json …
    Cause: FlowRequestPending: Existing request still has no single identifiable asset …

Two different shots in one panel. shot_014 had been downloaded, QC-accepted and saved hours earlier; the pause
snapshot was simply never rewritten. shot_018 was where the production had actually stopped.

``refresh()`` is a pure function: given the saved reason, the saved shot, the journals that are *still*
unresolved and the next unfinished shot, it returns the reason that is true now, plus evidence of what it
replaced. It never guesses and never hides the old text - it says it was superseded.
"""
from __future__ import annotations

JOURNAL_SUFFIX = '.flow-request.json'
JOB_FLOW_DIR = 'flow/shots/'


def _journal_shot(journal) -> str:
    parts = str(journal or '').split('/')
    for index, part in enumerate(parts):
        if part == 'shots' and index + 1 < len(parts):
            return parts[index + 1]
    return ''


def _journals_in(reason) -> list[str]:
    """Journal paths quoted inside a saved reason (e.g. ``…/flow/shots/shot_014/take_01.mp4.flow-request.json``)."""
    text = str(reason or '')
    found = []
    start = 0
    while True:
        # a reason may quote an absolute path (/…/flow/shots/…) or a job-relative one (flow/shots/…)
        index = text.find(JOB_FLOW_DIR, start)
        if index < 0:
            break
        end = text.find(JOURNAL_SUFFIX, index)
        if end < 0:
            break
        end += len(JOURNAL_SUFFIX)
        found.append(text[index:end])
        start = end
    return found


def refresh(reason, paused_shot, unresolved, next_shot, accepted, total) -> dict:
    """Return ``{'reason', 'stale', 'paused_shot', 'unresolved_targets', 'superseded', ...}``.

    ``unresolved`` rows are ``check_job()['unresolved']`` entries (dicts with ``journal``).
    """
    rows = [row for row in (unresolved or []) if isinstance(row, dict)]
    targets = [str(row.get('journal') or '') for row in rows if row.get('journal')]
    target_shots = sorted({_journal_shot(target) for target in targets} - {''})
    saved_reason = ' '.join(str(reason or '').split())
    paused_shot = str(paused_shot or '')
    next_shot = str(next_shot or '')
    moved_on = bool(paused_shot and next_shot and paused_shot != next_shot)

    stale = False
    if saved_reason:
        resolved_mentions = [journal for journal in _journals_in(saved_reason) if journal not in targets]
        if resolved_mentions:
            stale = True                      # it names a request that is no longer unresolved
        elif targets and paused_shot:
            stale = paused_shot not in target_shots
        elif not targets and moved_on:
            stale = True

    if not stale:
        return {'reason': saved_reason, 'stale': False, 'paused_shot': paused_shot,
                'unresolved_targets': targets, 'unresolved_shots': target_shots, 'superseded': ''}

    if saved_reason:
        head = (f"Superseded notice: this job was paused at {paused_shot or 'an older shot'}, but that request "
                "is no longer unresolved (it was downloaded or archived).")
    else:
        head = f"The job is paused at {next_shot or paused_shot or 'an unfinished shot'}."
    if targets:
        body = (f" Still unresolved: {len(targets)} Flow request(s) at {', '.join(targets)}"
                + (f" - shot(s) {', '.join(target_shots)}." if target_shots else '.'))
    else:
        body = " No unresolved Flow request remains, so nothing blocks a Resume."
    tail = (f" {int(accepted)}/{int(total)} shots are accepted; Resume continues at {next_shot}."
            if next_shot else '')
    return {'reason': head + body + tail, 'stale': True, 'paused_shot': paused_shot,
            'unresolved_targets': targets, 'unresolved_shots': target_shots,
            'superseded': saved_reason[:600]}

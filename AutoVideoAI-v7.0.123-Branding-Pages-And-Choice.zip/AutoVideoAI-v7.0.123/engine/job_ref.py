"""v7.0.100: accept the job reference people actually type, and say what to type when it is wrong.

Field case (2026-10-26, job ``20261022-143856-7-small-daily-habits-tha-9729``): every recovery command
failed with a bare ``FileNotFoundError``:

    python3 cli.py v3 recover-flow-video outputs/20261022-143856-7-small-daily-habits-tha-9729 ...

    FileNotFoundError: .../AutoVideoAI-v7/outputs/outputs/20261022-143856-.../production_manifest.json

The Factory already prefixes ``outputs/``, so the pasted path became ``outputs/outputs/...``. The user then
tried a trailing slash, which failed the same way, and the traceback never said what to do instead.

``normalize_job_id`` turns the common shapes - ``<id>``, ``outputs/<id>``, ``outputs/<id>/``,
``./outputs/<id>``, ``C:\\...\\outputs\\<id>`` or any absolute path to the job folder - into the bare id, and
``job_lookup_error`` explains an unknown one with the correct command and the ids that do exist.
"""
from __future__ import annotations

import os


def _parts(value: str) -> list[str]:
    return [part for part in value.replace('\\', '/').split('/') if part not in ('', '.')]


def normalize_job_id(value, outputs_root='outputs', strict=False) -> str:
    """Return the bare job id for ``value``.

    ``strict=False`` (the CLI) never raises: a reference that does not resolve is reduced to its last path
    component and handed on, so commands that deliberately work offline keep their own behaviour and the
    ones that load a job report the friendly ``job_lookup_error`` message. ``strict=True`` raises as soon as
    there is no such job.
    """
    if strict:
        return _normalize(value, outputs_root, strict=True)
    try:
        return _normalize(value, outputs_root, strict=True)
    except ValueError:
        parts = _parts(str(value or '').strip().strip('"').strip("'"))
        return (parts[-1] if parts else str(value or '').strip())


def _normalize(value, outputs_root, strict=False) -> str:
    raw = str(value or '').strip().strip('"').strip("'")
    if not raw:
        raise ValueError(job_lookup_error(value, outputs_root))
    expanded = os.path.expanduser(raw)
    # 1. A real path to the job folder (absolute, or relative to the current directory).
    if os.path.isdir(expanded) and os.path.isfile(os.path.join(expanded, 'production_manifest.json')):
        bare = os.path.basename(os.path.normpath(expanded))
        if _resolve(bare, outputs_root):
            return bare
    parts = _parts(raw)
    if not parts:
        raise ValueError(job_lookup_error(value, outputs_root))
    # 2. A path that mentions outputs/<id> (or outputs/<id>/).
    for index in range(len(parts) - 1, -1, -1):
        if parts[index].lower() == 'outputs':
            if index + 1 < len(parts):
                candidate = parts[index + 1]
                resolved = _resolve(candidate, outputs_root)
                if resolved:
                    return resolved
            raise ValueError(job_lookup_error(value, outputs_root))
    # 3. A bare id, with or without a trailing separator.
    resolved = _resolve(parts[-1], outputs_root)
    if resolved:
        return resolved
    raise ValueError(job_lookup_error(value, outputs_root))


def _resolve(candidate: str, outputs_root) -> str:
    """The real id when ``outputs_root/candidate`` is a job folder, else ''."""
    root = os.path.abspath(str(outputs_root or 'outputs'))
    path = os.path.join(root, candidate)
    return candidate if os.path.isdir(path) else ''


def job_ids(outputs_root='outputs', limit: int = 8) -> list[str]:
    root = os.path.abspath(str(outputs_root or 'outputs'))
    try:
        names = sorted((name for name in os.listdir(root)
                        if os.path.isdir(os.path.join(root, name)) and not name.startswith('.')),
                       reverse=True)
    except OSError:
        return []
    return names[:limit]


def job_lookup_error(value, outputs_root='outputs', extra: str = '') -> str:
    root = os.path.abspath(str(outputs_root or 'outputs'))
    message = (f"No saved job for {str(value or '').strip()!r}. Commands take the bare job id, without a path: "
               f"`python3 cli.py v3 <command> <job-id>` (the app adds outputs/ itself, so `outputs/<job-id>` "
               f"becomes outputs/outputs/<job-id>).")
    found = job_ids(outputs_root)
    if found:
        message += " Saved job ids in " + root + ": " + ", ".join(found) + (
            " (most recent first; raise the limit by looking at " + root + ")" if len(found) >= 8 else "") + "."
    else:
        message += (" No job folders were found in " + root + "; run the command from the AutoVideoAI "
                    "installation folder, or pass --outputs-root <folder> if the jobs live elsewhere.")
    return message + ((' ' + extra) if extra else '')

# Gemini TTS routes and part size (v7.0.82)

## Why each language used three requests

- **7.0.67 to 7.0.79:** Gemini received each whole narration in one request. A long Odia narration timed out at
  180 seconds in the 7.0.79 run, so 7.0.80 split narration into 1,200-character parts. One request was sent per part.
- **7.0.82:** the default part size is 2,400 characters, about 2 to 3 minutes of speech. A narration of
  about 5,000 characters is now 2 or 3 requests, not 4 or 5. Google's documented input limit is 8,192 tokens per request.
- **Tuning:** `GEMINI_TTS_CHUNK_CHARS` in `.env` sets the size, from 500 to 6,000. Smaller parts mean more requests.

## Per-language routes and key profiles

- Create, step 4: after the batch TTS provider, each selected language has a **Gemini route** dropdown.
  Options are `Batch setting above`, `Flash · default key`, `Flash-Lite · default key`, and the same two for
  each key profile found in `.env`.
- Each Gemini model has its own daily limit. On the AI Studio rate-limit page for this project, Gemini 3.8 Flash TTS
  and Gemini 3.8 Flash-Lite TTS both show 10 requests per day on the free tier. A language routed to
  Flash-Lite does not use up Flash's allowance.
- `.env`:
  - `GEMINI_API_KEY` is the profile `default`.
  - `GEMINI_API_KEY_<NAME>` adds the profile `<name>`, for example `GEMINI_API_KEY_PAID`.
  - Use keys only for Google projects you own and pay for. Two free-tier projects do not add their daily
    limits together; the limit is per project and per model. Keys are never shown in the UI.
- Routes are stored as `gemini`, `gemini-lite`, `gemini@<profile>` or `gemini-lite@<profile>`. A batch with
  per-language routes is stored as `{"default": ..., "<language>": ...}`. The batch key and the job settings
  include this value, so changing a route starts a new batch.
- A profile on a non-Gemini route is refused. A missing profile fails before any request is sent.
- Daily-limit errors name the key profile and the number of parts already saved.

## Suggested free-tier plan (not verified live)

With 2,400-character parts, a 5,000-character narration needs about 2 or 3 requests. Three languages on one
route can exceed 10 requests per day. A split that fits without billing:

- English and Hindi on `Flash · default key`.
- Odia on `Flash-Lite · default key`.

Check Flash-Lite Odia quality on a short sample before relying on it. The Odia narration needs review either way.

## Not verified

- Live timing of 2,400-character requests against the 240-second read timeout.
- Odia quality on Flash-Lite.
- Behaviour of paid keys: no paid key was tested here.

## Not included

- Pooling several free-tier accounts to multiply the daily limit. This is quota circumvention.
- A request counter that warns before a batch starts. This is the next step.

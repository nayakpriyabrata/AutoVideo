"""Script-first review and saved clip discovery. No visual/TTS generation."""
from pathlib import Path
import hashlib
import json
from .content_plan import validate_plan
from .production import save


def discover_clips(root='outputs', recent=()):
    """Read completed/partial clip reports across sessions, including review-only clips."""
    root = Path(root).expanduser().resolve()
    choices = {}
    def add(value, state='ready'):
        path = Path(str(value)).expanduser()
        if not path.is_absolute():
            path = Path.cwd()/path
        if not path.is_file():
            # Migration can leave report paths pointing at an old installation.
            matches = list(root.glob('**/'+path.name)) if root.is_dir() else []
            matches = [p for p in matches if p.parent.name == path.parent.name]
            if len(matches) != 1:
                return
            path = matches[0]
        if path.suffix.lower() in ('.mp4', '.mov', '.mkv', '.webm'):
            choices[str(path.resolve())] = state
    for value in recent:
        add(value)
    if root.is_dir():
        clip_folders = set()
        for report in sorted(set(root.glob('**/highlights*.json')) | set(root.glob('**/edits.json'))):
            try:
                data = json.loads(report.read_text(encoding='utf-8'))
                for value in data.get('outputs', []): add(value)
                for value in data.get('blocked_outputs', []): add(value, 'QC review required')
                for value in data.get('broll_outputs', []): add(value)
                clip_folders.add(report.parent.parent if report.parent.name == 'clip-history' else report.parent)
            except (OSError, ValueError, TypeError):
                continue
        # Older releases overwrote the latest report. Recover only exports next
        # to known clip/edit reports, never raw Flow takes or source-cache files.
        for folder in clip_folders:
            for path in folder.glob('*.mp4'):
                if path.is_symlink() or str(path.resolve()) in choices:
                    continue
                qc_path = path.with_suffix('.qc.json')
                try:
                    qc = json.loads(qc_path.read_text()) if qc_path.is_file() else {}
                except (OSError, ValueError):
                    qc = {}
                add(path, 'QC review required' if qc.get('decision') == 'BLOCK' else 'saved export · review required')
    return [{'path':path, 'label':Path(path).parent.name+' / '+Path(path).name+
             (' · '+state if state != 'ready' else ''), 'state':state}
            for path,state in choices.items()]


def draft_script_cast(topic, seconds, language, characters, style='education', cleanup='delete-after-read', audio_mode='voiceover'):
    if not str(topic).strip() or not 8 <= int(seconds) <= 7200:
        raise ValueError('Enter a topic and a duration of 8–7200 seconds')
    from .providers.gemini_web import gemini_web_generate
    available = [{'id':c['id'], 'name':c['name'], 'description':c['description'][:600],
                  'voice_style':c.get('voice_style','unspecified')} for c in characters]
    from .visual_plan import audio_mode as normalize_audio_mode, visual_prompt, validated_visual_plan
    mode = normalize_audio_mode(audio_mode)
    target_words = max(20, int(int(seconds) * 2.4))
    if mode != 'voiceover':
        system, user = visual_prompt(topic, seconds, language, mode, style, available)
        raw = gemini_web_generate(system, user, cleanup=cleanup)
    else:
        raw = gemini_web_generate(
            'Write an original, reviewable video script. Return JSON only. Do not generate media. '
            'Start with a concrete, specific spoken hook in the first 3 seconds: a surprising question, contrast, or visible problem tied directly to the topic. '
            'Show the promised payoff within the first 20 seconds and end with a useful takeaway. Avoid greetings, generic slogans and filler. '
            'Use topic-first visuals. Do not invent a named presenter or select a library character unless supplied in Saved characters or explicitly requested in the topic. '
            'Suggest zero to three supplied saved characters by ID only when useful. A cartoon treatment must '
            'preserve their facial identity, clothing and distinguishing traits in stylized form.',
            f'Topic: {topic}\nDuration: {seconds}s\nLanguage: {language}\nStyle: {style}\n'
            f'Saved characters: {json.dumps(available, ensure_ascii=False)}\n'
            f'Narration must contain about {target_words} words, at least {int(target_words*.8)} words. Include concrete explanations and examples for each skill.\n'
            'Return {"topic":"", "language":"", "narration":"", "scenes":'
            '[{"text":"", "visual_intent":"", "duration":6}], '
            '"character_suggestions":[{"character_id":"", "role":"", "reason":""}]}. '
            'Scene text must concatenate to exactly the narration in order. '
            'Every scene duration must be 0.5–30 seconds. Use enough narration for the target duration.', cleanup=cleanup)
    from .planning.script_engine import _extract_json
    value = _extract_json(raw)
    if value is None:
        raise ValueError('Gemini response has no complete script JSON. The captured answer is saved in logs/gemini; no media was generated.')
    suggestions = value.pop('character_suggestions', [])
    valid_ids = {c['id'] for c in characters}
    if not isinstance(suggestions, list) or len(suggestions)>3 or any(
            not isinstance(s,dict) or s.get('character_id') not in valid_ids for s in suggestions):
        raise ValueError('Gemini suggested an unknown cast; review the script and choose cast manually')
    if mode != 'voiceover':
        plan = validated_visual_plan(value, topic, seconds, language, mode)
    else:
        plan = validate_plan({**value, 'topic':topic, 'language':language, 'schema_version':1,
                              'approved':True, 'rights':{'declaration':'own_content','adaptation_confirmed':True}})
        plan['runtime_estimate_seconds'] = round(len(plan['narration'].split())/2.4, 1)
        plan['requested_seconds'] = int(seconds)
        plan['runtime_warning'] = ('Draft is shorter than requested; expand it before approval or use its measured speech runtime.'
                                   if len(plan['narration'].split()) < target_words*.8 else '')
        plan['audio_mode'] = 'voiceover'
    plan['approved'] = False
    plan['rights']['adaptation_confirmed'] = False
    return {'plan':plan, 'suggestions':suggestions,
            'hook_preview':str((plan.get('scenes') or [{}])[0].get('text','')).strip()[:300]}


def save_reviewed_plan(value, approved, folder='data/content/plans'):
    if approved is not True: raise ValueError('Review and approve the script first')
    plan = validate_plan({**value, 'approved':True,
                         'rights':{'declaration':'own_content','adaptation_confirmed':True}})
    fingerprint = hashlib.sha256(json.dumps(plan, sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    path = Path(folder).resolve()/('studio-'+fingerprint[:20]+'.json')
    save(path,plan)
    return str(path)


def review_recreation_clip(clip_path, transcript, language, cleanup='delete-after-read'):
    """Review actual local visuals plus exact transcript before any media generation."""
    from .clip_recreation import _transcript_record
    from .production import digest, run, probe
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    clip = Path(clip_path).expanduser().resolve()
    if not clip.is_file(): raise ValueError('Select an existing local clip')
    text, origin = _transcript_record(clip, transcript)
    duration = float(probe(clip).get('format', {}).get('duration', 0))
    if not 3 <= duration <= 180: raise ValueError('Review supports clips of 3–180 seconds')
    fingerprint = digest(clip)
    folder = Path('logs/gemini/recreation-review').resolve(); folder.mkdir(parents=True, exist_ok=True)
    proxy = folder/('review-'+fingerprint[:20]+'.mp4')
    try:
        run(['ffmpeg','-y','-i',str(clip),'-map','0:v:0','-an','-vf','scale=480:480:force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2,setsar=1,fps=8',
             '-c:v','libx264','-pix_fmt','yuv420p','-crf','32','-preset','fast','-movflags','+faststart',str(proxy)], timeout=180)
        raw = gemini_web_generate('Review the attached video visuals and the supplied exact transcript. '
            'Design an original AI recreation storyboard. Do not copy the source person identity. '
            'Do not invent transcript words. Return JSON only.',
            f'Language: {language}\nDuration: {duration}s\nExact transcript: {text}\n'
            'Return {"topic":"AI recreation", "narration":"exact transcript", "scenes":'
            '[{"text":"exact consecutive transcript words", "visual_intent":"observable scene/action", '
            '"duration":6}], "review_notes":"visual framing and sequence observations"}. '
            'Scene text must cover every transcript word exactly in order; scene durations 0.5–30 seconds. '
            'The attached proxy has no audio; speech comes only from this transcript.',
            cleanup=cleanup, attachments=[str(proxy)])
    finally:
        try:proxy.unlink(missing_ok=True)
        except OSError:pass
    value = _extract_json(raw)
    if not value or str(value.get('narration','')).split() != text.split():
        raise ValueError('Gemini changed or omitted transcript words; keep the captured review for editing, no generation started')
    value = validate_plan({**value, 'language':language, 'approved':True,
        'rights':{'declaration':'own_content','adaptation_confirmed':True}})
    value['approved'] = False
    value['rights']['adaptation_confirmed'] = False
    value['provenance'] = {'source_clip_sha256':fingerprint,'review_provider':'gemini-web-local-video',
                           'transcript_origin':origin,'silent_proxy':True}
    save(folder/('plan-'+fingerprint[:20]+'.json'), value)
    return value

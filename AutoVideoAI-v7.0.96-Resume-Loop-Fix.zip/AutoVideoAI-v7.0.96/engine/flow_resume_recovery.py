"""Reconcile saved requests under the production lock before allowing new work."""
from pathlib import Path
import json
from types import SimpleNamespace
from .flow_resume_safety import check_job
from .isolated_frame_regeneration import write_json, sha, image_valid


def note_recovery_error(root, row, error):
    """v7.0.96: leave the reason in the image journal so the next blocked Resume explains itself.

    A fresh image request that fails while its new project is being created writes a journal with
    ``phase: preparing`` and no project URL. Without this note the only trace is one line in
    resume-reconciliation.json, and the dashboard repeats the generic block message.
    """
    from .flow_image_transaction import SCOPE
    path = root / row['journal']
    try:
        data = json.loads(path.read_text())
    except (OSError, ValueError):
        return
    if data.get('scope') != SCOPE:
        return
    if not data.get('last_recovery_error'):
        data['last_recovery_error'] = str(error)[:500]
    if not data.get('recovery_state'):
        data['recovery_state'] = ('fresh_request_not_started' if str(data.get('phase') or '') == 'preparing'
                                  else 'recovery_checkpoint_retained')
    try:
        write_json(path, data)
    except OSError:
        pass


def reconcile_job(job_dir, settings=None, progress=None, provider_factory=None):
    from .providers.flow_browser import FlowBrowserProvider
    from .flow_image_transaction import SCOPE, recover, generate
    from .flow_reference_validation import matching_reference
    root = Path(job_dir).resolve()
    settings = settings or {}
    provider_factory = provider_factory or FlowBrowserProvider
    events = []
    for row in check_job(root)['unresolved']:
        path = root / row['journal']
        if row['state'] == 'unreadable' or path.is_symlink():
            continue
        # The bounded replacement ledger owns commit to the canonical frame.
        if row['journal'].startswith('authorized_frame_replacements/'):
            continue
        provider = None
        try:
            request = json.loads(path.read_text())
            if request.get('status') == 'superseded_by_authorized_replacement':
                continue
            output = str(path)[:-len('.flow-request.json')]
            if Path(output + '.image-replacement.json').is_file():
                continue
            if progress:
                progress('Recovering saved Flow request', 0, Path(output).name)
            provider = provider_factory()
            if request.get('scope') == SCOPE:
                compiled = {'prompt': request['source_prompt'], 'approval': 'once',
                    'max_generation_credits': 0,
                    'reference_paths': list(request.get('reference_hashes', {})),
                    'flow_image_replacement_root': str(root),
                    # v7.0.71: resume never starts image replacement (recovery only).
                    'flow_replace_unresolved_images': False,
                    'flow_image_replacement_limit': settings.get('flow_image_replacement_limit', 30)}
                # Same request hash and saved project; preparing means no Send
                # was attempted. Uncertain/submitted phases are download-only.
                shot = SimpleNamespace(shot_id=request['shot_id'])
                provider._active_request_hash = request['request_hash']
                try:
                    generate(provider, shot, compiled, output, request['vertical'], request['request_hash'])
                except Exception as error:
                    if not compiled['flow_replace_unresolved_images']:
                        raise
                    from .flow_image_replacement import replace_image
                    replace_image(provider, shot, compiled, output, request['vertical'], pending_error=error)
            elif request.get('kind') == 'image' and request.get('project_url'):
                # Older shared-project requests still require exact correlation.
                # An uploaded reference or an arbitrary local jpg is insufficient.
                bridge = provider._ensure()
                bridge.ensure_project('AutoVideo-Recovery', project_url=request['project_url'])
                signature = provider._identify_single_fresh_asset(bridge, request, 'image', timeout_ms=0)
                if not signature:
                    raise RuntimeError('Legacy image has no exact verified gallery match')
                stage = output + '.resume-download.jpg'
                request['signature'] = signature
                write_json(path, request)
                try:
                    bridge.download_latest_asset(stage, preferred_signature=signature, before_signatures=set())
                except Exception:
                    if not image_valid(stage): raise
                refs = [str(p) for p in (root / 'storyboard').glob('*master.jpg')]
                if not image_valid(stage) or matching_reference(stage, refs):
                    raise RuntimeError('Legacy recovery returned an invalid image or reference')
                Path(stage).replace(output)
                request.update(status='downloaded', media_sha256=sha(output))
                write_json(path, request)
            elif request.get('kind') == 'video' and request.get('project_url'):
                provider.recover_recorded_video('AutoVideo-Recovery', output, str(path),
                    project_url=request['project_url'], wait_s=120)
                request = json.loads(path.read_text())
                request.update(status='downloaded', media_sha256=sha(output))
                write_json(path, request)
            else:
                raise RuntimeError('Request lacks a supported recovery context')
            events.append({'journal': row['journal'], 'status': 'recovered'})
        except Exception as error:
            # v7.0.87: a download interruption on an exact saved request is retried
            # automatically (download-only); the flag tells run_job it may wait.
            from .automatic_recovery import recoverable_download_interruption
            events.append({'journal': row['journal'], 'status': 'pending', 'reason': str(error)[:500],
                           'recoverable': recoverable_download_interruption(error)})
            note_recovery_error(root, row, error)
        finally:
            if provider:
                try: provider.close()
                except Exception: pass
    # A replacement child can finish on a later Resume. Commit its bytes back
    # to the parent only when both journals and the reservation agree.
    from .flow_image_replacement import finish_saved_replacement
    for reservation in root.rglob('*.image-replacement.json'):
        try:
            if finish_saved_replacement(root, reservation):
                events.append({'replacement': str(reservation.relative_to(root)), 'status': 'committed'})
        except Exception as error:
            events.append({'replacement': str(reservation.relative_to(root)), 'status': 'pending', 'reason': str(error)[:500]})
    # Respect the saved user policy and its whole-job cap for older worker frames.
    # This helper is already inside the cross-process production lock.
    remaining = check_job(root)['unresolved']
    if any(r['journal'].startswith(('.flow-workers/economy-frame-artifacts/', 'authorized_frame_replacements/')) for r in remaining):
        from .isolated_frame_regeneration import regenerate, plan
        preview = plan(root)
        ledger_exists = (root / 'authorized_frame_replacements' / 'ledger.json').is_file()
        if not preview['blocked'] and preview['frames'] and (settings.get('flow_replace_unresolved_images', False) or ledger_exists):
            replacement = regenerate(root, apply=True,
                max_replacements=settings.get('flow_image_replacement_limit', 30),
                provider_factory=provider_factory, _locked=True,
                allow_new=settings.get('flow_replace_unresolved_images', False))
            events.append({'replacement_recovery': replacement})
    report = check_job(root)
    recoverable = {e['journal'] for e in events if e.get('status') == 'pending' and e.get('recoverable')}
    report['recoverable_only'] = bool(report['unresolved']) and all(
        row['journal'] in recoverable for row in report['unresolved'])
    write_json(root / 'logs' / 'resume-reconciliation.json', {'events': events, **report})
    return report

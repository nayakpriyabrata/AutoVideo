# v7.0.11 — recovery for Flow-rewritten image prompts

## Confirmed cause

The user's collected gallery has two identical closing-frame prompts, an opening-frame prompt and a location-master prompt. Flow shortened the character description and rephrased the action. The old journal did not record the original submitted prompt; Resume reconstructed a long instruction that was truncated. Exact wrapper stripping cannot reconcile these different texts.

## Recover this saved job

Stop Studio, CLI jobs and the runner. Back up the installation. Update source from v7.0.11 in the existing installation, preserving outputs/, data/, credentials, local configuration, browser profiles and all request journals. Keep local config values instead of overwriting them with release examples.

From that installation folder, run:

```sh
python3 tools/repair_debanshi_frame.py
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6
```

The repair script has no browser/provider/generation calls. It checks the exact reviewed request hash, project URL and reconstructed prompt digest; a mismatch stops without changes. It backs up the original journal once and records the exact closing-frame prompt from the user's diagnostic. It is safe to repeat. It does not bind by title, appearance or tile order. Resume re-reads the gallery and compares exact text before downloading; both identically prompted closing-frame variants are compatible for this request, while the opening frame and location master are rejected. Downloaded media still undergoes the ordinary image validation. Recovery itself submits no new generation. Once this frame is recovered, normal Resume can continue remaining production under the job's existing credit approvals.

## Future jobs

When the original generated image is detected, the provider records the exact Reuse prompt attached to that identified asset before downloading. A later Resume verifies that binding against the same request, project and submitted instruction digest. If the thumbnail fingerprint changes, it rescans for the exact bound prompt. Failed matching now includes readable candidate prompt text in local recovery diagnostics so a separate collector is less often needed.

This is not general fuzzy matching. When the original asset was never detected and Flow rewrites the prompt without a stable identity, a verified binding may still be needed. Authentication, provider capacity and downloads can fail independently. This release does not claim the live WSL job has finished.

All v7.0.9 compact players, B-roll batch approval and optional channel logos remain included.

"""Deterministic local text logos, reusable as exact image assets in every editor."""
from pathlib import Path
import hashlib
import os
from PIL import Image, ImageDraw
from .render.typography import font

SIZES = {'Small': .12, 'Medium': .18, 'Large': .25}

def text_logo(text, palette='Ocean', root='data/content/logos'):
    text = str(text).strip()
    if not text or len(text)>80 or any(ord(c)<32 for c in text):
        raise ValueError('Logo text must be 1–80 characters on one line')
    palettes = {'Ocean': ('#172554','#67e8f9'), 'Sunset': ('#4c1d95','#fbbf24'),
                'Forest': ('#14352b','#a3e635')}
    if palette not in palettes:
        raise ValueError('Choose a supported logo palette')
    bg, accent = palettes[palette]
    image = Image.new('RGBA', (1200,240), (0,0,0,0)); draw=ImageDraw.Draw(image)
    face=font(96,bold=True,style='clean',text=text)
    while draw.textlength(text,font=face)>1080 and face.size>20:
        face=font(face.size-2,bold=True,style='clean',text=text)
    bounds=draw.textbbox((0,0),text,font=face)
    width=min(1200,int(draw.textlength(text,font=face))+100)
    image=image.crop((0,0,width,240));draw=ImageDraw.Draw(image)
    draw.rounded_rectangle((0,0,width-1,239),radius=44,fill=bg,outline=accent,width=5)
    draw.text((50,(240-(bounds[3]-bounds[1]))/2-bounds[1]),text,font=face,fill='white')
    draw.rounded_rectangle((50,204,width-50,212),radius=4,fill=accent)
    folder=Path(root);folder.mkdir(parents=True,exist_ok=True)
    name=hashlib.sha256((text+'|'+palette).encode()).hexdigest()[:24]
    path=folder/(name+'.png');temporary=path.with_suffix('.tmp.png')
    image.save(temporary);os.replace(temporary,path)
    return str(path.resolve())

def logo_controls(st, scope, *, enabled=True):
    from .studio_widgets import save_uploaded_image
    kind=st.radio('Logo source', ['Image','Text'],horizontal=True,key=scope+'-kind',disabled=not enabled)
    image_path=st.text_input('Logo image path',key=scope+'-path',disabled=not enabled)
    upload=st.file_uploader('Upload logo image',type=['png','jpg','jpeg','webp'],key=scope+'-upload',disabled=not enabled)
    value=st.text_input('Logo text',key=scope+'-text',disabled=not enabled)
    palette=st.selectbox('Logo colours',['Ocean','Sunset','Forest'],key=scope+'-palette',disabled=not enabled)
    path=''
    if enabled and kind=='Image':
        path=save_uploaded_image(upload) if upload else image_path
    elif enabled and value.strip():
        try:
            path=text_logo(value,palette)
            st.image(path,width=240)
        except ValueError as error: st.error(str(error))
    size=st.selectbox('Logo size',list(SIZES),index=1,key=scope+'-size',disabled=not enabled)
    return path, SIZES[size]

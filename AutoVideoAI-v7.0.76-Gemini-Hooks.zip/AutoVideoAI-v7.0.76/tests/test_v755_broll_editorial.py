import json
from types import SimpleNamespace as NS
from engine.broll import editorial_filter, protected_video_intervals, approved_video_overlays, sha256_file, prepare_review

def row(name, start, sha='a', **kw):
    return dict(candidate_id=name, start=start, duration=2, sha256=sha, max_uses_per_asset=2, **kw)

def test_repeat_gap_and_intervening_cutaway():
    accepted, skipped=editorial_filter([row('a',0),row('b',3),row('c',10,'b'),row('d',31),row('e',33)])
    assert [r['candidate_id'] for r in accepted]==['a','c','e']
    assert len(skipped)==2

def test_same_asset_never_consecutive_even_after_long_gap():
    assert len(editorial_filter([row('a',0),row('b',100)])[0])==1

def test_limit_and_separate_clip_timelines():
    rows=[row('a',0),row('b',5,'b'),row('c',40),row('d',45,'c'),row('e',80)]
    assert [r['candidate_id'] for r in editorial_filter(rows)[0]]==['a','b','c','d']
    assert len(editorial_filter([row('a',0,clip_output='one'),row('b',0,clip_output='two')])[0])==2

def test_actual_provider_and_final_timeline():
    manifest=NS(shots=[NS(shot_id='a',provider='flow',actual_provider='image'),NS(shot_id='b',provider='flow',actual_provider='flow'),NS(shot_id='c',provider='movieflow',actual_provider='external')])
    tl={'segments':[dict(shot_id=k,timeline_start=i*10,dur=8,freeze=2) for i,k in enumerate('abc')]}
    assert protected_video_intervals(manifest,tl)==[(10,20),(20,30)]
    accepted,skipped=editorial_filter([row('safe',8),row('cross',9),row('ai',15)],protected_video_intervals(manifest,tl))
    assert [r['candidate_id'] for r in accepted]==['safe']
    assert len(skipped)==2

def test_saved_review_filtered_without_changing_approval(tmp_path):
    media=tmp_path/'a.mp4';media.write_bytes(b'approved bytes')
    rows=[dict(row('first',0),path=str(media),sha256=sha256_file(media),approved=True,rights_reviewed=True),dict(row('repeat',3),path=str(media),sha256=sha256_file(media),approved=True,rights_reviewed=True)]
    review=tmp_path/'broll_review.json';review.write_text(json.dumps(dict(schema_version=1,workflow='production',candidates=rows)))
    original=review.read_bytes()
    assert len(approved_video_overlays(str(review),20))==1
    assert approved_video_overlays(str(review),20,protected=[(0,20)])==[]
    assert review.read_bytes()==original
    assert len(json.loads((tmp_path/'broll_placement_report.json').read_text())['skipped'])==2

def test_all_ai_production_can_have_empty_review(tmp_path):
    review=prepare_review(str(tmp_path/'review.json'),[],workflow='production')
    assert review['candidates']==[]

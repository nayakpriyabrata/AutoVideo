# AutoVideoAI v7.0.18 — script review and recovery

## Upgrade from v7.0.17

Stop Studio, CLI and the local runner. Extract this build into a fresh folder beside the old installation. From the new folder:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.17 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.17 . --apply
```

The first command previews the migration. The second copies saved jobs/configuration and rebases character references. Keep the previous folder as a backup. Use your existing Python environment and installed WSL browser dependencies. Launch Studio with `python3 -m streamlit run app.py`.

## Script draft and cleanup

Guided Studio's optional draft stage now extracts the JSON object from Gemini response wrappers, including “Show thinking”, code fences and “Copy code”. It has its own cleanup selector, defaulting to delete-after-read, independent of an older job's Keep policy. A complete response is saved locally before deleting the exact newly submitted chat. If Google changes the deletion controls, the runtime log reports that deletion could not be verified; another conversation is never deleted as a fallback.

## Character cards

Studio and the private control center preserve the full reference portrait in their preview cards. This fixes center crops that removed faces. Generation references remain the original files.

## Optional video review for AI Recreate

Select a saved clip or local file, review its transcript and confirm adaptation rights. Expand **Gemini Web · review this clip before recreation** and choose **Review video + propose recreation scenes**. This explicitly uploads a small silent proxy of that local video to your signed-in Gemini session together with the transcript. Review/edit the resulting storyboard and select **Use this reviewed Gemini storyboard for recreation** before creating the job.

The reviewed plan is bound to the source file's SHA-256 and exact transcript words. Switching the source or changing its contents invalidates it. Planning launches no TTS, image or video generation. Gemini attachment controls in the user's live WSL browser are not yet verified; an unavailable upload control stops before the review prompt. The original transcript-only planning path remains available.

## Existing Debanshi job: stop blocking on a missing closing image

The latest report shows no verified shot_006 CLOSE asset. The old submitted prompt was truncated at 4,000 characters, and the readable gallery prompts do not identify that exact closing image. This build does not invent an exact match or clear its journal.

To permit this job to reuse each shot's saved opening image when closing recovery fails:

```bash
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6 --local-closing-fallback
```

This one-time choice is saved in the job; subsequent plain Resume uses it. It first attempts recovery. If closing recovery remains unresolved and that shot has a valid opening image, it copies that image as closing guidance, records a `.local-fallback.json` audit, and continues. The pending Flow journal is retained unchanged. No replacement image request is submitted. Normal subsequent video generation still follows the existing job's approved credit budget.

This is a continuity fallback, not recovery of the original closing asset. It can change the action's end-state. Review the final video. It does not bypass an unresolved opening image, character/location master, video request, budget gate or media QC. Therefore it cannot guarantee that the remainder of this legacy job will finish unattended.

The same option is available in Guided Studio, AI Recreate, Queue's recovery controls, and the private site's Resume review. It applies to the shared Storyboard Economy frame pipeline. For new jobs choose it before starting. For an existing job, Queue → Flow recovery behavior → **Save local closing recovery policy** → Resume. The Site requires the updated local runner and engine v7.0.18.

Disable for future attempts with `--no-local-closing-fallback`; already saved guidance is preserved. Strict exact recovery remains the default. The separate continue-on-unresolved-frames option still collects all unresolved frames and pauses once without substitutions.

## Verification scope

Regression coverage includes wrapped JSON, explicit cleanup overriding inherited settings, head/feet retention in thumbnails, source-bound recreation plans, exact transcript preservation, journal retention, both pause policies, idempotent Resume, missing-opening refusal and the private Site's review/dispatch guards. No live Google generation or WSL account action was executed while validating this build. No measured production failure-rate guarantee is made.

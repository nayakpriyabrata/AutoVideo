"""Zero-network preflight for outstanding Google Flow requests.

Pending journals are not proof of successful generation, and missing image files
are not authorization for another submission. Default to preserving credits.
"""
from __future__ import annotations
import json
import hashlib
from pathlib import Path


def check_job(job_dir):
    root = Path(job_dir).expanduser().absolute()
    if root.is_symlink() or not (root / 'production_manifest.json').is_file():
        raise ValueError('Expected an existing, non-symlink AutoVideoAI job directory')
    rows = []
    for journal in sorted(root.rglob('*.flow-request.json')):
        if journal.is_symlink():
            rows.append({'journal': str(journal.relative_to(root)), 'state': 'unreadable', 'reason': 'symlink'}); continue
        try:
            data = json.loads(journal.read_text(encoding='utf-8'))
            state = str(data.get('status') or data.get('state') or 'unknown').lower()
            image_path = Path(str(journal)[:-len('.flow-request.json')])
            image_present = image_path.is_file() and image_path.stat().st_size > 0
            if state == 'superseded_by_authorized_replacement':
                # Supersession is not a claim that the original request was
                # downloaded. Both the new asset and its installed frame must
                # remain bound to the committed replacement bytes.
                expected = data.get('replacement_sha256')
                valid = isinstance(expected, str) and len(expected) == 64
                for value in (data.get('replacement_file'), data.get('replacement_target')):
                    candidate = root / str(value or '')
                    valid = valid and (bool(value) and not candidate.is_symlink()
                        and candidate.resolve().is_relative_to(root.resolve())
                        and candidate.is_file())
                    if valid:
                        valid = hashlib.sha256(candidate.read_bytes()).hexdigest() == expected
                if not valid:
                    rows.append({'journal': str(journal.relative_to(root)), 'state': 'replacement_missing_or_changed'})
                continue
            if data.get('scope') in ('isolated_one_frame_one_request', 'isolated_image_v1') and state == 'downloaded':
                if (not image_present or image_path.is_symlink() or
                        hashlib.sha256(image_path.read_bytes()).hexdigest() != data.get('media_sha256')):
                    rows.append({'journal': str(journal.relative_to(root)), 'state': 'replacement_missing_or_changed'})
                continue
            if (data.get('scope') == 'isolated_image_v1' and str(data.get('phase') or '') == 'submission_uncertain'
                    and not image_present):
                # v7.0.93: image requests cost no Flow credits. A submit that was never acknowledged, with no local
                # image, goes through generate(): recover once, then one fresh image request if nothing was produced
                # (up to 3 per shot). 'submitted' journals keep blocking (7.0.87 download-only wait); video journals
                # keep blocking until explicitly reconciled.
                continue
            if state in ('pending', 'submitted', 'running', 'generating', 'unknown', 'unreadable'):
                # v7.0.96: carry the last recovery verdict so a blocked Resume explains itself
                # instead of repeating the same wait.
                rows.append({'journal': str(journal.relative_to(root)), 'state': state, 'local_image_exists': image_present,
                             'phase': str(data.get('phase') or ''),
                             'recovery_state': str(data.get('recovery_state') or ''),
                             'last_recovery_error': str(data.get('last_recovery_error') or '')[:300],
                             'saved_project_url': str(data.get('saved_project_url') or data.get('project_url') or ''),
                             'observed_project_url': str(data.get('observed_project_url') or '')})
        except (OSError, ValueError, TypeError) as exc:
            rows.append({'journal': str(journal.relative_to(root)), 'state': 'unreadable', 'reason': type(exc).__name__})
    return {'job_id': root.name, 'safe_to_generate': not rows, 'unresolved_count': len(rows), 'unresolved': rows,
            'policy': 'Conservative: pending/unreadable requests always require explicit reconciliation before new generation.'}


class FlowResumeBlocked(RuntimeError):
    def __init__(self, report):
        self.report = report
        job = report['job_id']
        images = []
        reasons = []
        for row in report.get('unresolved', []):
            journal = str(row.get('journal') or '')
            if journal.endswith('.flow-request.json'):
                image = journal[:-len('.flow-request.json')]
                images.append(image)
                if row.get('recovery_state'):
                    reasons.append(f"{image}: {row['recovery_state']}"
                                   + (f" ({row['last_recovery_error']})" if row.get('last_recovery_error') else ''))
        steps = ''.join(f"python3 cli.py v3 archive-request {job} {image}; " for image in images)
        message = (f"Safe Resume blocked: {report['unresolved_count']} unresolved Flow request journal(s) for {job}. "
                   f"Saved request(s): {', '.join(images) or 'see logs/resume-reconciliation.json'}. ")
        if reasons:
            message += "Last recovery result: " + '; '.join(reasons) + ". "
        if images:
            message += ("Resume reopens the exact saved project, consumes a finished image if there is one, and waits "
                        "once. When that project no longer holds the image, a wait cannot create it. Image requests "
                        "cost no Flow credits, so ONE fresh image request may be submitted without credit approval: "
                        f"`{steps.rstrip('; ')}`. That archives the old request, kept on record, and the next Resume "
                        "makes one new free image request. The archive refuses when a real image is already saved. "
                        "Nothing is submitted by the archive command itself. Read-only diagnosis of every journal: "
                        f"`python3 tools/flow_resume_preflight.py outputs/{job}`. ")
        message += "See logs/resume-reconciliation.json for recovery results."
        super().__init__(message)


def require_safe_job(job_dir):
    result = check_job(job_dir)
    if not result['safe_to_generate']:
        raise FlowResumeBlocked(result)
    return result

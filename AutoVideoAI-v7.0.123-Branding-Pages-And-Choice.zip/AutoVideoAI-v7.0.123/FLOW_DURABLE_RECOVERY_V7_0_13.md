# v7.0.13 — reusable Flow image recovery

This update applies to the shared Flow provider used by AI recreation, long form, reels and Flow cartoons. It does not generate a replacement to get around an uncertain pending request.

## What changed

- New image submissions get a random request label that is saved with the exact request, Flow project and submitted prompt in one atomic journal write before Generate is clicked. Two jobs with the same scene prompt receive different labels.
- Resume can identify an image when Flow rewrites the creative brief but retains that exact label in the image's Reuse prompt. It saves the rewritten prompt as a verified binding for future resumes.
- Matching a saved label or verified prompt checks the full available image gallery, even if a changed baseline includes the generated tile. Video tiles cannot satisfy an image request.
- Bounded prompt scans advance through the gallery instead of inspecting the first 12 candidates on every retry. Progress and prompt evidence survive another Resume.
- Equivalent gallery prompts appear once in the review list. A completed exact-prompt review stays saved; repeating that same binding is harmless and does not ask for another review. Queue hides candidates already covered by a valid saved binding.
- The v7.0.12 photo grounding, migration, audio checkpoints and exact-download/browser recovery changes remain included.

## Upgrade and recover the existing job

Stop the Studio, runner, CLI jobs and AutoVideoAI browser sessions. From the newly extracted v7.0.13 folder:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.12 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.12 . --apply
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6
```

If your saved jobs are in v7.0.11 or an earlier folder, pass that folder instead. Completed frames and accepted takes are reused. Keep the original folder until the migrated job finishes.

For future failures, select the existing job in Queue and use Resume. Creating a new recreation makes a new job and can incur new generation costs; it does not repair the original pending request. No per-job Python edits or hard-coded Debanshi repair are needed for the general recovery logic.

If automatic matching lacks proof, Queue → Resolve an ambiguous saved image shows recorded gallery prompts. Review the exact scene once and bind it, then Resume. The binding is kept for that request/project and migrates with the job. It cannot be transferred to a different request or project.

## Honest limits

The old shot-4 request may predate the tracking label, and Flow may omit labels from reused prompts. This build cannot reconstruct evidence that was never recorded. It retains the exact journal and requests a one-time review when there is no trustworthy match; it does not choose by similarity, thumbnail position or a different person. Missing media, sign-in/consent walls, account capacity and network outages can still need attention.

Tests simulate rewritten prompts, matching beyond candidate 12, changed baselines, request/project tampering, equivalent candidates, repeat review and download-only Resume with generation forbidden. Live recovery of the old WSL job is still unverified.

import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest


def test_qc_retry_after_later_shot_interruption_preserves_original_request(tmp_path,monkeypatch):
    from engine.factory import Factory
    from engine.project.manifest import Shot
    import engine.qc.video_qc as qc
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'jobs.db'))
    job=f.create_job('Discipline',profile='FREE_HYBRID')
    m=f.pm.load_manifest(job)
    m.shots=[Shot(shot_id=f'shot_{i:03d}',provider='flow',compiled_prompt=f'original scene {i}',
                  gen_duration=4,num_candidates=1,voice_start=(i-1)*4,voice_end=i*4,duration_target=4) for i in (1,2)]
    f.pm.save_manifest(m)
    interrupted=False;calls=[]
    class Provider:
        def status(self):return NS(available=True)
        def current_project_url(self):return ''
        def close(self):pass
        def generate(self,shot,compiled,refs,out,*a,**kw):
            nonlocal interrupted
            if shot.shot_id=='shot_002' and not interrupted:
                interrupted=True;raise RuntimeError('later shot interrupted')
            journal=Path(out+'.flow-request.json')
            if journal.exists():assert json.loads(journal.read_text())['prompt']==compiled['prompt']
            else:journal.write_text(json.dumps({'prompt':compiled['prompt'],'status':'downloaded'}))
            Path(out).write_bytes(compiled['prompt'].encode());calls.append(out)
            return {'path':out,'provider':'flow','model':'test','credits':0}
    monkeypatch.setattr(f,'_providers',lambda:{'flow':Provider()})
    monkeypatch.setattr(f,'_previous_project_video',lambda *a:None)
    monkeypatch.setattr(f,'_remember_flow_video_project_url',lambda *a:'')
    monkeypatch.setattr(qc,'analyze_take',lambda path,*a,**k:dict(overall=20 if path.endswith('shot_001/take_01.mp4') else 95,
        decision='REJECT' if path.endswith('shot_001/take_01.mp4') else 'ACCEPT',failure='low_motion'))
    refs=NS(for_shot=lambda *a:{},best_end_frame=lambda *a:None)
    router=NS(budgets={'MAX_RETRIES_PER_SHOT':2})
    with pytest.raises(RuntimeError,match='later shot interrupted'):
        f._generate_all(m,f.pm.dirs(job),refs,router,True,False,lambda *a:None,{})
    old=Path(calls[0]);original=old.read_bytes();journal=Path(str(old)+'.flow-request.json').read_bytes()
    m=f.pm.load_manifest(job);assert m.shots[0].retry_count==1
    f._generate_all(m,f.pm.dirs(job),refs,router,True,False,lambda *a:None,{})
    assert old.read_bytes()==original and Path(str(old)+'.flow-request.json').read_bytes()==journal
    assert Path(calls[1]).name=='take_r01_01.mp4'
    assert all(s.status=='accepted' for s in f.pm.load_manifest(job).shots)
    assert (Path(f.pm.dirs(job)['qc'])/'shot_001_take_01.json').exists()
    assert (Path(f.pm.dirs(job)['qc'])/'shot_001_take_r01_01.json').exists()


@pytest.mark.parametrize('message',['Recorded Flow request differs from this prompt; review the request record before replacing anything',
                                   'Recorded request belongs to a different Flow project; restore its project binding'])
def test_deterministic_conflict_is_not_automatically_retried(message):
    from engine.automatic_recovery import can_recover
    from engine.providers.flow_browser import FlowRequestPending
    assert not can_recover(FlowRequestPending('Saved request. Cause: '+message))


def test_completed_download_qc_is_visible_in_support_report(tmp_path):
    from engine.support_report import build_support_report
    (tmp_path/'production_manifest.json').write_text(json.dumps(dict(job_id='job',shots=[dict(shot_id='shot_001',status='failed',retry_count=1)])))
    media=tmp_path/'flow/shots/shot_001/take_01.mp4';media.parent.mkdir(parents=True);media.write_bytes(b'video')
    Path(str(media)+'.flow-request.json').write_text(json.dumps(dict(kind='video',status='downloaded',submitted_prompt='private draft')))
    (tmp_path/'qc').mkdir();(tmp_path/'qc/shot_001_take_01.json').write_text(json.dumps(dict(decision='REJECT',failure='duration',overall=20)))
    report=build_support_report(tmp_path)
    assert report['pending_request_count']==0
    assert report['completed_video_requests'][0]['qc']['decision']=='REJECT'
    assert report['job']['shots'][0]['retry_count']==1
    assert 'private draft' not in json.dumps(report)

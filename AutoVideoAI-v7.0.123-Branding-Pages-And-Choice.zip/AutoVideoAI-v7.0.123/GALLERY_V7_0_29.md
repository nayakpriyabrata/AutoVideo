# AutoVideoAI v7.0.29 · Gallery & Downloads

This build includes the Flow/login/reference fixes from v7.0.28.

## Open the gallery

Click **Gallery & Downloads** in the sidebar. It also appears under Jobs & Recovery. The former History page has been renamed so saved videos are easy to find.

The gallery separates Clips, Long-form videos and Short-form videos. Tiles stay compact with playback, fullscreen and Download MP4. It discovers final renders in real job folders even when a migrated database's final_path is stale, includes Mini Reels and includes local edit reports. It does not show raw takes or storyboard files. Use Additional clip output folder for a custom clip directory.

## Download, then delete

1. Click Download MP4 and save the video in your browser.
2. Click Delete exported video on the same tile.
3. Review its exact path and size, check I confirm deletion of this file, then click Confirm permanent deletion. Cancel leaves it untouched.

Deletion removes only the selected exported video. It is permanent and frees that file's disk space. Source footage, accepted takes, narration, storyboard and recovery records remain. A normal production job can be rendered again from retained media. Mini Reels remain subject to their saved Flow request's exact recovery evidence.

The app cannot prove that a browser download was saved. It does not delete automatically after download. It rechecks file contents before deletion and blocks running/queued jobs, pending Flow requests, linked paths and clips required by saved AI recreation jobs. It cannot remove source media through this gallery.

## Upgrade

Stop Studio, CLI jobs and the runner. Extract into a fresh v7.0.29 folder. In that folder run:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.27 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.27 . --apply
python3 -m pip install -r requirements.txt
./dashboard.sh
```

Use v7.0.28 as the source if you already migrated to it; use whichever installation contains your most complete saved data. Keep the source until migration is verified.

Gallery tests cover discovery after migration, deletion confirmation, changed-file protection, active-job/source-clip protection and preservation of working media. Live Google Flow operation remains unverified on your WSL machine; no Google generation was submitted for this update.

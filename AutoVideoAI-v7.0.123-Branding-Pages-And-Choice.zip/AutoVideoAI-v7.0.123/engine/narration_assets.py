"""Which narration voices a saved job already has, and where they are (v7.0.119).

The field report: "I tried to recover it with Queue and Resume and I don't see the audio and completed
steps."  Queue could resume a job and show its logs, but it never showed the thing a resume reuses - the
narrated voices. And the step row counted VOICE as missing whenever the voice came from a prepared Create
step 4 batch, because it only looked at ``narration/voice.mp3``.

A job can hold narration in four places, all of them recorded here read-only:
``narration/voice.mp3`` (classic pipeline), ``production/prepared_speech.json`` (the primary language of a
prepared batch), ``speech-editions/<lang>/voice.mp3`` (a batch copied into the job) and the bundle paths in
``production/language_editions.json``. Nothing is generated, moved or deleted.
"""
from __future__ import annotations

import json
from pathlib import Path

MIN_VOICE_BYTES = 2048  # a 0-byte or truncated file is not a voice a render can use


def _read(path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _label(code) -> str:
    code = str(code or '').strip()
    if not code:
        return 'Primary narration'
    try:
        from .languages import language_pack
        return language_pack(code).label
    except Exception:
        return code.upper()


def _seconds(*candidates):
    for value in candidates:
        try:
            number = float(value)
        except (TypeError, ValueError):
            continue
        if number > 0:
            return round(number, 1)
    return None


def voices(job_dir) -> list[dict]:
    """Every narration file this job already holds, in a stable order, with its language and length."""
    root = Path(job_dir)
    found: dict[str, dict] = {}

    def add(path, code, source, seconds=None):
        if not path:
            return
        file = Path(str(path))
        if file.is_symlink() or not file.is_file():
            return
        try:
            if file.stat().st_size < MIN_VOICE_BYTES:
                return
        except OSError:
            return
        key = str(file.resolve())
        if key in found:
            if found[key]['seconds'] is None:
                found[key]['seconds'] = _seconds(seconds)
            return
        found[key] = {'path': key, 'language': str(code or ''), 'source': source,
                      'seconds': _seconds(seconds), 'bytes': file.stat().st_size}

    add(root / 'narration' / 'voice.mp3', '', 'narration/voice.mp3')

    primary = _read(root / 'production' / 'prepared_speech.json')
    if primary:
        add(primary.get('audio'), primary.get('language') or '', 'production/prepared_speech.json',
            primary.get('duration'))

    editions_dir = root / 'speech-editions'
    if editions_dir.is_dir():
        for folder in sorted(editions_dir.iterdir()):
            if folder.is_symlink() or not folder.is_dir():
                continue
            words = _read(folder / 'words.json')
            duration = _seconds(words.get('duration'),
                                (words.get('words') or [{}])[-1].get('end') if words.get('words') else None)
            add(folder / 'voice.mp3', folder.name, 'speech-editions/' + folder.name + '/voice.mp3', duration)

    editions = _read(root / 'production' / 'language_editions.json')
    for code, bundle in (editions.get('bundles') or {}).items():
        if isinstance(bundle, dict):
            add(bundle.get('audio'), code, 'production/language_editions.json', bundle.get('duration'))

    for row in found.values():
        row['label'] = _label(row['language'])
    return sorted(found.values(), key=lambda row: (row['language'] != '', row['language']))


def labels(job_dir) -> list[str]:
    """Language names with a saved voice, e.g. ``['English', 'Hindi', 'Odia']``."""
    return [row['label'] for row in voices(job_dir)]


def summary(job_dir) -> str:
    names = labels(job_dir)
    return ' · '.join(names) if names else ''

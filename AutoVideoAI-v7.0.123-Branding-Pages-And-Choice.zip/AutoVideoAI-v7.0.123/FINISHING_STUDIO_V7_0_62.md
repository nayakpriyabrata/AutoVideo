# Finishing Studio · v7.0.62

Finishing Studio makes **new local exports** from an existing completed video or clip. It does not generate Flow media, modify the source, publish to social platforms, or remove Flow branding. Review any visible platform marks and platform rules before publishing.

1. Open **Content & Delivery → Finishing Studio**. Save a channel profile with optional channel names in English, Hindi and Odia, logo, licensed background music, intro and outro MP4s. The assets are copied into the shared workspace so code updates do not remove them.
2. Choose a saved clip or a completed video, or enter a local video path. Choose one or more languages and record the source rights declaration. Create a saved plan.
3. For each language, review timed text cards relative to the source video. Optionally provide a reviewed transcript to get *draft* cards and a music mood from Gemini Web. The draft never directly renders: review and save it first. Optionally upload an existing narration track, or choose a track from the reviewed shared music library. Verify that the track's permission covers YouTube, Facebook and Instagram.
4. Review and save each edition. Render it to `outputs/finishing/<plan-id>/exports/`. Existing exports are never overwritten. The export has a provenance JSON with hashes and music permission.

The original source footage is reused for every edition. For dubbed editions supply a separate narration track for each language; merely selecting another language does not translate speech. Narration must fit the original source duration. If a source already has speech, the narration replaces its audio for the source segment; intro and outro retain their own audio. Cards require system fonts that support the chosen script (Noto Sans Devanagari for Hindi, Noto Sans Oriya/Odia for Odia). Short content can omit the intro to preserve its first-second hook.

CLI equivalents:

```bash
python3 cli.py v3 channel-profile --name 'My Channel' --name-hi 'मेरा चैनल' --name-or 'ମୋ ଚ୍ୟାନେଲ' --logo /path/logo.png --intro /path/intro.mp4 --outro /path/outro.mp4
python3 cli.py v3 finish-plan /path/completed.mp4 --profile /path/to/channel_profiles/my-channel/profile.json --languages en,hi,or
python3 cli.py v3 finish-edition /path/to/plan.json --language en --cards /path/cards.json --approve
python3 cli.py v3 finish-render /path/to/plan.json --language en
```

Cards JSON is an array such as `[ {"start": 2, "end": 5, "text": "A useful takeaway"} ]`. Add `--narration /path/voice.m4a` and `--music /path/track.ogg --music-license 'Source page and usage terms'` to `finish-edition` when needed. A profile music track likewise requires `--music-license`. The CLI commands do not call Gemini Web. The UI's optional suggestion uses the signed-in Gemini Web session and sends the supplied transcript/context text.

Stop production before updating code. From an extracted v7.0.62 folder, apply the code-only updater to an existing v7.0.61 or v7.0.61-r2 directory:

```bash
python3 tools/update_v761_to_v762.py ../AutoVideoAI-v7 --apply
```

It checks expected source hashes, refuses unexpected edits in changed files, backs up replaced files, and leaves shared outputs, browser profiles, jobs and the music library alone. It does not repair an existing pending Flow request. Finish or safely recover such a request separately.

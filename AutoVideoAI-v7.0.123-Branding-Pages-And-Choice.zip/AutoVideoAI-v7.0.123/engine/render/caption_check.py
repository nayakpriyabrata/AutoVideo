"""Look at a finished video and say whether text is burned into its caption band (v7.0.112).

Field report: "the render is right there in the record, but the Odia video still shows the transcript." Provenance
and the plan agree with each other; the only witness that cannot be argued with is the picture. This module samples
the caption band of a finished file and measures how much of it is glyph-bright pixels - the white and yellow that
a burned caption is made of.

It is a **check with numbers**, not a judge: a bright sky or a white shirt can raise the ratio, so the result is
reported as a measurement (percentage of near-white pixels, per sampled frame) that a person can read, and a
threshold is only used to raise a *question*, never to certify a video as clean.

No FFmpeg state is kept and nothing is written; the caller decides what to do with the numbers.
"""
from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

#: How much of the caption band is glyph-bright (white or highlight yellow) in a file with a burned transcript.
#: The field videos measured 1.3 % with a transcript and 0.0 % without one.
BRIGHT_RATIO = 0.004

#: How much sharp local contrast the band carries. Text is thin strokes with a dark outline, so it produces far
#: more than a bright but flat scene does; a test pattern of colour bars (a false positive for brightness alone)
#: measured 0.015, a burned caption 0.063. Requiring **both** is what keeps a bright sky from being called text.
EDGE_RATIO = 0.035

#: Where the caption band starts, as a fraction of the height, when no frame size is known yet.
BAND_FRACTION = 0.70


def _ffmpeg():
    from .ffmpeg_renderer import ffmpeg_exe
    return ffmpeg_exe()


def _frame(video, moment, out):
    command = [_ffmpeg(), '-y', '-hide_banner', '-loglevel', 'error', '-ss', f'{max(0.0, moment):.3f}',
               '-i', str(video), '-frames:v', '1', str(out)]
    return subprocess.run(command, capture_output=True, text=True, timeout=120).returncode == 0 and Path(out).is_file()


def _measure(path, top_fraction):
    """``(bright_share, edge_share)`` for the caption band of one frame.

    ``bright_share`` counts pixels that are near white or a saturated highlight yellow - what a caption glyph is
    made of. ``edge_share`` counts pixels that differ sharply from their own neighbourhood, which is what thin
    text with a dark outline looks like and what a flat bright area does not.
    """
    from PIL import Image, ImageFilter
    with Image.open(path) as original:
        colour = original.convert('RGB')
    width, height = colour.size
    upper = int(height * top_fraction)
    band = colour.crop((0, upper, width, height))
    pixels = band.load()
    grey = band.convert('L')
    blurred = grey.filter(ImageFilter.GaussianBlur(6))
    flat, smooth = grey.load(), blurred.load()
    bright = edges = total = 0
    for y in range(0, band.size[1], 2):                 # every other row is plenty for a share
        for x in range(0, band.size[0], 2):
            red, green, blue = pixels[x, y]
            total += 1
            if (red >= 232 and green >= 232 and blue >= 232) or (red >= 195 and green >= 175 and blue <= 150):
                bright += 1
            if abs(flat[x, y] - smooth[x, y]) > 55:
                edges += 1
    if not total:
        return 0.0, 0.0
    return bright / total, edges / total


def probe(video, *, moments=(0.15, 0.3, 0.45, 0.6, 0.75), band=BAND_FRACTION):
    """``{'checked', 'frames': [...], 'ratio', 'looks_like_text', 'band', 'detail'}`` for one finished file."""
    video = Path(video)
    result = {'checked': False, 'frames': [], 'ratio': 0.0, 'edge_ratio': 0.0, 'looks_like_text': None,
              'band': band, 'detail': ''}
    if not video.is_file():
        result['detail'] = 'No file to check: ' + str(video)
        return result
    duration = 0.0
    try:
        from .. import finishing_studio as finish
        _info, duration = finish._probe(video)
    except Exception:
        duration = 0.0
    with tempfile.TemporaryDirectory(prefix='caption-check-') as folder:
        for index, share in enumerate(moments):
            moment = (duration * share) if duration else float(index) * 1.5 + 0.5
            frame = Path(folder) / f'{index}.png'
            try:
                if not _frame(video, moment, frame):
                    continue
                bright, edges = _measure(frame, band)
            except (OSError, subprocess.SubprocessError, ValueError):
                continue
            result['frames'].append({'at': round(moment, 2), 'bright': round(bright, 5),
                                     'edges': round(edges, 5)})
    if not result['frames']:
        result['detail'] = 'Could not read a frame from ' + video.name + ' (FFmpeg missing or the file is unreadable).'
        return result
    result['checked'] = True
    result['ratio'] = max(frame['bright'] for frame in result['frames'])
    result['edge_ratio'] = max(frame['edges'] for frame in result['frames'])
    result['looks_like_text'] = result['ratio'] >= BRIGHT_RATIO and result['edge_ratio'] >= EDGE_RATIO
    result['detail'] = ('caption band: '
                        + ', '.join(f"{frame['bright'] * 100:.2f}% bright / {frame['edges'] * 100:.2f}% edges "
                                    f"at {frame['at']}s" for frame in result['frames'])
                        + (' — consistent with a burned transcript.' if result['looks_like_text'] else
                           ' — no burned transcript detected.'))
    return result


def explain(result, *, expected):
    """A sentence that compares what the file shows with what the job asked for, or ``''`` when they agree."""
    if not result or not result.get('checked') or expected is None:
        return ''
    if expected and not result['looks_like_text']:
        # Deliberately not a warning: a caption is not on screen every second, so a handful of samples can land
        # between cues. The check only ever reports text it can see.
        return ''
    if (not expected) and result['looks_like_text']:
        return ('Bright text is visible in the caption band of this file, although this job asks for no transcript '
                'in this language. This is the current file, not an older one. Until 7.0.113 a narration longer '
                'than the picture was fitted by a step that re-enabled captions, whatever the plan said - so the '
                'file really does carry them. Rendering this language again repairs it, only this language, '
                'with no new voice and no Flow credits.')
    return ''

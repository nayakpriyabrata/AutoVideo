"""Reviewed removal of isolated image projects with verified local captures."""
import json
from pathlib import Path
from .production import digest, save
from .production_lock import acquire, release


def inventory(root):
    from .flow_image_transaction import completed, references_for, SCOPES
    from .providers.flow_browser import FlowBrowser
    root=Path(root).resolve(); grouped={}; unreadable=False
    for path in root.rglob('*.flow-request.json'):
        if path.is_symlink() or not path.is_file():continue
        try:
            row=json.loads(path.read_text())
            if not isinstance(row,dict): unreadable=True;continue
        except (OSError,ValueError):
            unreadable=True;continue
        try:
            url=FlowBrowser.normalize_project_url(row.get('project_url'))
            if not url:continue
            item=grouped.setdefault(url,{'project_url':url,'records':[],'blocked':[],'signatures':[]})
            output=Path(str(path)[:-len('.flow-request.json')])
            record={'journal':str(path),'journal_sha256':digest(path),'output':str(output)}
            item['records'].append(record)
            if row.get('kind')!='image':item['blocked'].append('Video/recovery project retained');continue
            if row.get('scope') not in SCOPES:item['blocked'].append('Not an isolated single-image project');continue
            if not completed(output,row):item['blocked'].append('Image is pending, missing or changed');continue
            refs=references_for(row)
            record['media_sha256']=digest(output)
            # The verified local image is the required evidence. A captured gallery
            # inventory, when present, tightens the live check; it is not required.
            signatures=row.get('capture_inventory') or []
            if signatures:item['signatures'].extend(signatures)
            else:item['inventory_complete']=False
            # Upper bound on live images this request could have produced: its own
            # output plus any uploaded references (see flow_image_transaction).
            item['max_images']=item.get('max_images',0)+len(refs)+1
        except (OSError,ValueError,RuntimeError,KeyError,TypeError,AttributeError):
            unreadable=True
    ledger_path=root/'.flow-project-cleanup.json'
    try:ledger=json.loads(ledger_path.read_text()) if ledger_path.is_file() else {}
    except (OSError,ValueError):ledger={};unreadable=True
    if not isinstance(ledger,dict):ledger={};unreadable=True
    for url,item in grouped.items():
        item['signatures']=sorted(set(item['signatures']))
        # Exact matching only when every record carries a captured inventory.
        item['exact']=bool(item['signatures']) and item.get('inventory_complete',True)
        item.setdefault('max_images',0)
        if unreadable:item['blocked'].append('An unreadable request journal needs reconciliation')
        item['blocked']=sorted(set(item['blocked']))
        item['remote_state']=ledger.get(url,{}).get('status','retained')
        if item['remote_state'] in ('deleted','uncertain'):item['blocked'].append('Remote cleanup already '+item['remote_state'])
        item['eligible']=bool(item['records'] and item['max_images'] and not item['blocked'])
    return sorted(grouped.values(),key=lambda x:x['project_url'])


def delete_selected(root, reviewed, provider_factory=None, *, lock_held=False):
    root=Path(root).resolve()
    if not reviewed:raise ValueError('Select at least one eligible project')
    if len({r['project_url'] for r in reviewed})!=len(reviewed):raise ValueError('Duplicate cleanup selection')
    from .providers.flow_browser import FlowBrowserProvider
    provider_factory=provider_factory or FlowBrowserProvider
    lockroot=Path.home()/'.local/share/autovideoai';lockroot.mkdir(parents=True,exist_ok=True)
    from contextlib import nullcontext
    with ((lockroot/'production.lock').open('a+b') if not lock_held else nullcontext()) as lock:
        if lock is not None:
            try:acquire(lock,blocking=False)
            except BlockingIOError:raise ValueError('Production is running. Wait before remote project cleanup.')
        provider=None
        try:
            fresh={r['project_url']:r for r in inventory(root)}
            for row in reviewed:
                if fresh.get(row['project_url'])!=row or not row.get('eligible'):
                    raise ValueError('Project evidence changed or recovery still needs it. Review again.')
            ledger_path=root/'.flow-project-cleanup.json'
            ledger=json.loads(ledger_path.read_text()) if ledger_path.is_file() else {}
            provider=provider_factory();bridge=provider._ensure();results=[]
            for row in reviewed:
                url=row['project_url']
                # Durable reservation before any destructive action. An uncertain
                # result is never retried automatically after a browser interruption.
                ledger[url]={'status':'uncertain','records':row['records']};save(ledger_path,ledger)
                try:
                    verification=bridge.delete_exact_project(
                        url,expected_signatures=row['signatures'] if row.get('exact') else None,
                        max_images=row.get('max_images'))
                    if not isinstance(verification,dict) or verification.get('status')!='deleted':
                        raise RuntimeError('Flow deletion was not independently confirmed')
                    ledger[url]['status']='deleted';save(ledger_path,ledger)
                    results.append({'project_url':url,'status':'deleted'})
                except Exception as error:
                    results.append({'project_url':url,'status':'needs_review','reason':str(error)[:400]})
                    break
            return results
        finally:
            if provider is not None:
                try:provider.close()
                except Exception:pass
            if lock is not None:release(lock)


def panel(st,root):
    with st.expander('Clean downloaded Flow image projects · optional'):
        st.caption('Retains every video project, pending request and changed or missing capture. An isolated image project can be selected once its image and request record are verified locally. Remote deletion removes the Flow copy; local media and resume records stay saved.')
        if st.button('Review saved Flow projects',key='flow-project-review-action'):
            st.session_state['flow-project-review-data']=inventory(root)
        rows=st.session_state.get('flow-project-review-data',[])
        eligible={r['project_url']:r for r in rows if r['eligible']}
        if rows:
            st.caption(f'{len(eligible)} eligible image projects · {len(rows)-len(eligible)} retained or already reviewed')
            st.dataframe([{'project':r['project_url'],'status':'eligible' if r['eligible'] else '; '.join(r['blocked'])} for r in rows],hide_index=True)
            urls=st.multiselect('Image projects to delete from Flow',list(eligible),key='flow-cleanup-selection')
            for url in urls:st.markdown('[Open exact project for review]('+url+')')
            confirmed=st.checkbox('I approve deleting these selected image projects from Google Flow',key='flow-cleanup-confirm')
            if st.button('Delete selected verified image projects',disabled=not(urls and confirmed),key='flow-cleanup-apply'):
                try:
                    with st.spinner('Checking saved copies and deleting the exact selected projects…'):
                        result=delete_selected(root,[eligible[url] for url in urls])
                    st.json(result)
                    st.session_state.pop('flow-project-review-data',None)
                except Exception as error:st.error(str(error))

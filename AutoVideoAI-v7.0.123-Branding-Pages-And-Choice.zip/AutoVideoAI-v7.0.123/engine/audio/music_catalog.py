"""Recommended royalty-free music, by video type, with the licence each track carries (v7.0.107).

The user asked for "excellent, widely used, pleasant, royalty-free and without copyright on YouTube"
background music, per video type, to download locally into ``music_library/``. Guessing a track name is
useless, so this is a small, checked catalogue:

* every entry names its platform, the exact licence, and whether a credit line is required;
* ``credit`` holds the line to paste into the YouTube description when attribution is required;
* ``themes`` uses the tags ``engine/audio/music_library.py`` understands, so an imported track is picked for
  the right videos automatically;
* ``search`` is what to type on the platform, so the list still works if a direct link changes.

Nothing here downloads or re-hosts music. Licences change; the doc that ships with the app
(``docs/MUSIC_LIBRARY.md``) says to re-check the licence page before publishing.
"""
from __future__ import annotations

SCHEMA = "music-catalogue-v1"

# Video types the app actually produces (``content_type`` / preset families).
VIDEO_TYPES = {
    "education": "Explainer, how-to and educational videos",
    "motivation": "Motivational and self-improvement videos",
    "documentary": "Documentary, story and cinematic narration",
    "technology": "Technology, AI and science videos",
    "kids": "Kids and cartoon stories",
    "travel": "Travel and lifestyle",
    "business": "Business, finance and career",
}


def _track(**row):
    return row


CATALOGUE = [
    _track(
        id="monplaisir-free-to-use-1", title="Free To Use 1", artist="Monplaisir",
        platform="Free Music Archive", licence="CC0 1.0 (public domain)", attribution="none",
        credit="", url="https://freemusicarchive.org/music/Monplaisir/",
        search="Monplaisir Free To Use 1", themes=["calm", "motivation"], tempo="slow",
        video_types=["education", "motivation", "business"],
        notes="Already the local default in this installation (music_library/). Calm, unobtrusive bed "
              "that survives ducking under speech. Best first choice for talking-head narration.",
    ),
    _track(
        id="buckley-amberlight", title="Amberlight", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Amberlight' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/amberlight/",
        search="Scott Buckley Amberlight", themes=["calm", "motivation"], tempo="slow",
        video_types=["education", "motivation", "documentary"],
        notes="Warm piano and strings. Empathetic, hopeful tone for habit/wellbeing explainers.",
    ),
    _track(
        id="buckley-life-in-motion", title="Life In Motion", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Life In Motion' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/life-in-motion/",
        search="Scott Buckley Life In Motion", themes=["calm", "motivation"], tempo="slow",
        video_types=["education", "documentary", "business", "travel"],
        notes="Neoclassical piano, clarinet and strings. Introspective without being sad.",
    ),
    _track(
        id="buckley-discovery", title="Discovery", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Discovery' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/discovery/",
        search="Scott Buckley Discovery", themes=["cinematic", "technology"], tempo="medium",
        video_types=["documentary", "technology", "education", "travel"],
        notes="Optimistic hybrid orchestra with synth arpeggios. Good under an opening hook, then duck it.",
    ),
    _track(
        id="buckley-origami", title="Origami", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Origami' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/origami/",
        search="Scott Buckley Origami", themes=["upbeat", "technology"], tempo="medium",
        video_types=["business", "technology", "education"],
        notes="Smooth electro-jazz groove. Works under listicles and 'three things to try' videos.",
    ),
    _track(
        id="buckley-echoes", title="Echoes", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Echoes' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/echoes/",
        search="Scott Buckley Echoes", themes=["cinematic", "calm"], tempo="slow",
        video_types=["documentary", "motivation"],
        notes="Solo cello and strings; builds after 3 minutes, so use its first half as a bed.",
    ),
    _track(
        id="buckley-midvinter", title="Midvinter", artist="Scott Buckley",
        platform="scottbuckley.com.au", licence="CC BY 4.0", attribution="required",
        credit="'Midvinter' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au",
        url="https://www.scottbuckley.com.au/library/midvinter/",
        search="Scott Buckley Midvinter", themes=["calm"], tempo="slow",
        video_types=["education", "kids"],
        notes="Simple piano lullaby. The gentlest entry here; use at low volume under meditation content.",
    ),
]

# Where to get more, and what the licence really allows. Re-check each page before publishing.
SAFE_SOURCES = [
    {"name": "YouTube Audio Library", "url": "https://support.google.com/youtube/answer/3376882?hl=en",
     "licence": "YouTube Audio Library license, or CC BY 4.0 for tracks marked 'Attribution required'",
     "attribution": "Depends on the track: filter 'Attribution not required' to skip credits",
     "content_id": "No Content ID claims for tracks downloaded from the Audio Library",
     "notes": "Safest option for a YouTube-first channel: lives in YouTube Studio, downloadable as MP3, "
              "filterable by mood and by attribution. The copyright-safe promise is YouTube-only."},
    {"name": "Pixabay Music", "url": "https://pixabay.com/music/",
     "licence": "Pixabay Content License (content from before 2019 is CC0)",
     "attribution": "Not required", "content_id": "Some tracks are Content ID registered (shield icon)",
     "notes": "Largest free library with no credit line needed. Download the MP3 and keep the track page; "
              "avoid tracks with the Content ID shield for monetised videos. Do not resell tracks as files."},
    {"name": "Scott Buckley (CC BY 4.0)", "url": "https://www.scottbuckley.com.au/library/",
     "licence": "CC BY 4.0", "attribution": "Required in the video description, in the exact published form",
     "content_id": "Registered with a claim-release process tied to the credit line",
     "notes": "Cinematic and neoclassical tracks that sound expensive. Paste the credit text verbatim or you "
              "will get a claim. See https://www.scottbuckley.com.au/library/using-this-music/."},
    {"name": "Free Music Archive", "url": "https://freemusicarchive.org/",
     "licence": "Per track: CC0, CC BY, CC BY-SA (never use NC/ND for monetised work)",
     "attribution": "Depends on the track; filter to CC0 for no-credit use",
     "content_id": "Varies by artist", "notes": "Where Monplaisir's CC0 catalogue lives."},
    {"name": "Incompetech / Kevin MacLeod", "url": "https://incompetech.com/music/royalty-free/music.html",
     "licence": "CC BY 4.0 (older tracks CC BY 3.0)",
     "attribution": "Required", "content_id": "Some tracks are claimed; the site publishes the credit format",
     "notes": "Huge, well-known catalogue at every mood; the credit format on each track page must be copied."},
    # 7.0.109: the two libraries that ask least of a YouTube-first channel.
    {"name": "Mixkit (Envato)", "url": "https://mixkit.co/free-stock-music/",
     "licence": "Mixkit Free License - personal and commercial use, YouTube and monetised videos included",
     "attribution": "Not required (appreciated, not required)",
     "content_id": "Not registered with Content ID; claims are rare in practice",
     "notes": "No account, no download cap, clean production tracks that sit well under narration. The Free "
              "License excludes CDs/DVDs, video games and TV/radio broadcast, and assets may not be resold as "
              "files - fine for a YouTube channel. Check each track page: a few assets carry the Restricted "
              "License (personal/non-commercial only)."},
    {"name": "Uppbeat", "url": "https://uppbeat.io/music",
     "licence": "Uppbeat licence (free tier: individual creators, own YouTube channels, monetisation allowed)",
     "attribution": "Free tier: a unique Uppbeat Credit per download, one video each, pasted in the description",
     "content_id": "Every track is registered with Content ID; the Credit (or paid channel safelisting) clears it",
     "notes": "Modern, pleasant tracks with a consistent house sound. The free tier allows about three "
              "downloads a month and only part of the catalogue, and each download generates a fresh Credit "
              "that is valid for one video - so keep the download page and paste the exact code. Paid plans "
              "safelist the channel and remove the per-video credit."},
    {"name": "Bensound", "url": "https://www.bensound.com/royalty-free-music",
     "licence": "Free tier: CC BY-style, online video and non-revenue educational use; paid licence for more",
     "attribution": "Required: 'Music by Bensound.com / License code: ... / Artist: ...' in the description",
     "content_id": "The per-video licence code exists to clear claims",
     "notes": "Polished corporate/upbeat tracks from one composer. Each download gives a code valid for one "
              "video, and the free tier does not cover podcasts, audiobooks, client work or paid ads."},
    {"name": "Chosic (search, not a library)", "url": "https://www.chosic.com/free-music/all/",
     "licence": "Varies: it indexes tracks from several libraries and shows each licence",
     "attribution": "Follow the licence it prints for the track",
     "content_id": "Unknown - always confirm on the original platform page",
     "notes": "Useful for finding a mood quickly (it groups by emotion and genre and links the source). Treat "
              "it as a directory: download and credit from the original library, not from the aggregator."},
]


#: Per video type: what to listen for, and the one or two places to start a download (v7.0.109).
#: Every "start" row is a real page, and the licence obligation is stated in the same line.
TYPE_PLAYBOOK = {
    "education": {
        "mood": "Calm, unobtrusive, no strong melody in the first ten seconds - it plays under a voice.",
        "bpm": "70-95, no vocals, no sudden drops",
        "start": [
            ("Mixkit", "https://mixkit.co/free-stock-music/tag/inspirational/",
             "Free, no credit, no sign-up. 'Inspirational' and 'Corporate' tags are the closest fit."),
            ("YouTube Audio Library", "https://studio.youtube.com/channel/UC/video_manager/music",
             "Filter 'Attribution not required' + mood 'Inspirational'. Safest for YouTube monetisation."),
            ("Scott Buckley", "https://www.scottbuckley.com.au/library/amberlight/",
             "CC BY 4.0 - paste the exact credit line. Warmer and more cinematic than a stock bed."),
        ],
        "avoid": "Tracks with a strong four-on-the-floor kick or vocal chops; they fight the narration.",
    },
    "motivation": {
        "mood": "Slow build, hopeful, restrained percussion - a payoff by the second half.",
        "bpm": "90-110 with a build, or 70 for a reflective piece",
        "start": [
            ("Scott Buckley", "https://www.scottbuckley.com.au/library/",
             "CC BY 4.0, credit required. 'Amberlight', 'Life In Motion', 'Echoes' are built for this."),
            ("Pixabay Music", "https://pixabay.com/music/search/inspiring/",
             "No credit needed; skip tracks with the Content ID shield icon for monetised videos."),
        ],
        "avoid": "Epic trailer drums over a calm script - the mismatch reads as generic.",
    },
    "documentary": {
        "mood": "Cinematic, sparse, minor-key strings or piano. Room for the voice.",
        "bpm": "60-90",
        "start": [
            ("Scott Buckley", "https://www.scottbuckley.com.au/library/discovery/",
             "CC BY 4.0, credit required - his catalogue is the reference sound for this genre."),
            ("Mixkit", "https://mixkit.co/free-stock-music/tag/cinematic/",
             "No credit, no account. Fewer options than Buckley, zero obligations."),
        ],
        "avoid": "Loops under 60 seconds; a documentary bed needs to survive eight minutes without repeating audibly.",
    },
    "technology": {
        "mood": "Clean synth pulses, light arpeggios, no aggressive drops.",
        "bpm": "100-120, steady",
        "start": [
            ("Mixkit", "https://mixkit.co/free-stock-music/tag/technology/",
             "Free, no credit, no sign-up - the quickest path to a usable tech bed."),
            ("Uppbeat", "https://uppbeat.io/music/genre/electronic",
             "Free tier: about three downloads a month, and a Uppbeat Credit code per video in the description."),
            ("Scott Buckley", "https://www.scottbuckley.com.au/library/origami/",
             "CC BY 4.0. Electro-jazz groove for listicles and demos."),
        ],
        "avoid": "Anything with a modem/robot sound effect; it dates a video instantly.",
    },
    "kids": {
        "mood": "Playful, simple, acoustic - glockenspiel, ukulele, claps.",
        "bpm": "100-130, bright but not shrill",
        "start": [
            ("Pixabay Music", "https://pixabay.com/music/search/kids/",
             "No credit needed; check the Content ID shield on each track."),
            ("YouTube Audio Library", "https://studio.youtube.com/channel/UC/video_manager/music",
             "Mood 'Happy'/'Bright', filter 'Attribution not required'."),
        ],
        "avoid": "Minor-key or tense beds, and anything with a vocal hook a child will fixate on.",
    },
    "travel": {
        "mood": "Open, rhythmic, acoustic guitar or light percussion.",
        "bpm": "95-120",
        "start": [
            ("Mixkit", "https://mixkit.co/free-stock-music/tag/travel/",
             "Free, no credit, no account."),
            ("Pixabay Music", "https://pixabay.com/music/search/travel/",
             "No credit required; avoid Content ID-shielded tracks for monetised uploads."),
        ],
        "avoid": "Overly 'stock corporate' beds - travel footage needs air, not a meeting room.",
    },
    "business": {
        "mood": "Confident, minimal, unobtrusive; light piano or muted synth.",
        "bpm": "90-110",
        "start": [
            ("Mixkit", "https://mixkit.co/free-stock-music/tag/corporate/",
             "Free, no credit, no account - the standard corporate bed."),
            ("Bensound", "https://www.bensound.com/royalty-free-music/tag/corporate",
             "Free tier needs the three-line credit and a per-video licence code; paid removes both."),
        ],
        "avoid": "Uplifting 'sales' music with a big chorus; it makes a finance explainer feel like an advert.",
    },
}


def playbook(content_type=""):
    """The per-type buying guide, or the whole table."""
    kind = str(content_type or "").strip().lower()
    if kind and kind in TYPE_PLAYBOOK:
        return {kind: TYPE_PLAYBOOK[kind]}
    return dict(TYPE_PLAYBOOK)


def recommend(content_type="", themes=None, limit=8):
    """Tracks suited to a video type and/or theme tags, best first."""
    kind = str(content_type or "").strip().lower()
    wanted = {str(theme).strip().lower() for theme in (themes or []) if str(theme).strip()}
    scored = []
    for index, track in enumerate(CATALOGUE):
        score = 0
        if kind and kind in track["video_types"]:
            score += 3
        score += 2 * len(wanted & set(track["themes"]))
        if track["attribution"] == "none":
            score += 1  # fewer obligations is a feature for a channel that reuses tracks
        if score:
            scored.append((score, index, track))
    scored.sort(key=lambda row: (-row[0], row[1]))
    return [track for _, _, track in scored[:max(1, int(limit))]]


def credit_block(tracks):
    """The description block for every track that needs one; empty when none do."""
    lines = [track["credit"] for track in tracks or [] if track.get("attribution") == "required" and track.get("credit")]
    if not lines:
        return ""
    return "Music:\n" + "\n".join(lines)


def theme_tags(content_type="", tracks=None, limit=3):
    """The library tags to attach when importing a track for this kind of video.

    Only the themes of the recommended tracks, most common first, so the advice is
    "tag it calm or motivation" rather than the whole vocabulary.
    """
    rows = tracks if tracks is not None else recommend(content_type, limit=6)
    counts = {}
    for track in rows:
        for theme in track["themes"]:
            counts[theme] = counts.get(theme, 0) + 1
    ranked = sorted(counts, key=lambda theme: (-counts[theme], theme))
    return ranked[:max(1, int(limit))] or ["calm"]

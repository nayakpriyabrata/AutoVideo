"""Hooks drafted with Gemini Web (7.0.76).

Hooks are short attention lines (at most 60 characters) placed where the narration
needs them: the opening when it is weak, and points where energy drops or a new
section starts. Gemini Web drafts them after the narration words and the text
cards exist. Each hook is anchored to a spoken word, so it appears when the
narrator reaches that moment.

Rules enforced here:
* at most 6 hooks; at least 10 seconds between hooks; each shown 2.5-3.5 seconds;
* a hook never covers a text card, a points series, or any other overlay; hooks
  that would are dropped at render time and counted in the log;
* if Gemini Web is unavailable, the job continues without hooks.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

MAX_HOOKS = 6
MIN_GAP_SECONDS = 10.0
HOLD_SECONDS = 3.0
MIN_VISIBLE_SECONDS = 2.5
MAX_CHARS = 60
VARIANT = "hooks-v1"


def hook_prompt(topic, language) -> str:
    return (
        "You are a senior short-form video editor. "
        f"The video topic is: {' '.join(str(topic or '').split())}. "
        f"Target language: {language}. "
        "Write attention hooks: short on-screen lines that stop a viewer from scrolling away. "
        'Return JSON {"hooks":[{"text":"...","start_word":0}]}. '
        "Choose at most 6 moments in the narration where a hook is genuinely needed: the opening if it is weak, "
        "and places where the narration loses energy or a new section begins. Spread them out; no two closer than "
        "10 seconds apart. Each text is at most 60 characters, in the target language, and echoes the narration as "
        "a question, a contrast, a surprising angle or a clear promise. Use exact zero-based word IDs from the "
        "supplied words. Do not invent facts, statistics or numbers, and do not repeat the narration word for word. "
        "An empty list is allowed if no hook is needed.")


def _fingerprint(audio, words, script, topic, language) -> str:
    h = hashlib.sha256()
    with Path(audio).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    h.update(json.dumps(words, sort_keys=True, ensure_ascii=False).encode())
    h.update(str(script).encode())
    h.update(f"{VARIANT}|{' '.join(str(topic or '').split())}|{language}".encode())
    return h.hexdigest()


def anchor_hooks(draft, words, duration):
    """Validate Gemini's hooks and convert word IDs to timed windows."""
    from .speech_cards import validate_words
    validate_words(words, duration)
    rows = draft.get("hooks") if isinstance(draft, dict) else None
    if rows is None:
        rows = []
    if not isinstance(rows, list) or len(rows) > MAX_HOOKS:
        raise ValueError(f"Gemini must return at most {MAX_HOOKS} hooks")
    hooks = []
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("Each hook must be an object")
        first = row.get("start_word")
        text = row.get("text")
        if type(first) is not int or not 0 <= first < len(words):
            raise ValueError("A hook refers to an invalid speech word index")
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= MAX_CHARS or "\n" in text:
            raise ValueError(f"Each hook must be one line of at most {MAX_CHARS} characters")
        start = float(words[first]["start"])
        end = min(float(duration), start + HOLD_SECONDS)
        if not math.isfinite(start) or end - start < MIN_VISIBLE_SECONDS:
            raise ValueError("A hook falls too close to the end of the video to be read")
        hooks.append({"text": text.strip(), "start_word": first, "start": round(start, 3), "end": round(end, 3)})
    hooks.sort(key=lambda h: h["start"])
    for before, after in zip(hooks, hooks[1:]):
        if after["start"] - before["start"] < MIN_GAP_SECONDS:
            raise ValueError("Hooks must be at least 10 seconds apart")
    return hooks


def draft_hooks(root, audio, words, script, duration, language, *, topic="", cleanup="keep"):
    """Ask Gemini Web for hooks and save production/hooks.json. Cached by fingerprint."""
    from .production import save
    from .speech_cards import validate_words
    from .planning.script_engine import _extract_json
    from .studio_review import _draft_generate
    root = Path(root)
    target = root / "production" / "hooks.json"
    key = _fingerprint(audio, words, script, topic, language)
    if target.is_file():
        prior = json.loads(target.read_text(encoding="utf-8"))
        if prior.get("fingerprint") == key:
            return prior
    validate_words(words, duration)
    indexed = [{"id": i, "word": w["word"], "start": w["start"], "end": w["end"]} for i, w in enumerate(words)]
    user = (f"Duration: {float(duration):.3f}s\nReviewed script:\n{script}\n"
            "Timed narration words:\n" + json.dumps(indexed, ensure_ascii=False))
    raw = _draft_generate('gemini-web', hook_prompt(topic, language), user, cleanup=cleanup)
    save(target.with_name("hooks-draft.json"), {"response": raw, "fingerprint": key})
    hooks = anchor_hooks(_extract_json(raw), words, duration)
    result = {"schema_version": 1, "source": "gemini-web-hooks", "fingerprint": key, "duration": float(duration),
              "language": language, "topic": str(topic or ""), "hooks": hooks}
    save(target, result)
    return result


def load_hooks(root, audio, words, script, duration, language, *, topic=""):
    """Saved hooks for the current narration, or None. A stale draft is refused, not reused."""
    path = Path(root) / "production" / "hooks.json"
    if not path.is_file():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("fingerprint") != _fingerprint(audio, words, script, topic, language):
        raise ValueError("Narration, timings or topic changed after hook drafting. Resume the job to refresh hooks.")
    return anchor_hooks(data, words, duration)


def build_hook_overlays(root, audio, words, script, duration, width, height, style, existing,
                        *, topic="", language="en"):
    """Render hook pills and drop any that would cover another overlay. Returns (overlays, dropped)."""
    from .render.hook_cards import render_hook_png
    hooks = load_hooks(root, audio, words, script, duration, language, topic=topic)
    if not hooks:
        return [], 0
    blocked = [(float(e["start"]), float(e["end"])) for e in existing if e.get("kind") != "watermark"]
    overlays, dropped = [], 0
    for index, hook in enumerate(hooks):
        if any(hook["start"] < end and start < hook["end"] for start, end in blocked):
            dropped += 1
            continue
        target = Path(root) / "render" / "graphics" / f"hook-{index:02d}.png"
        overlays.append(render_hook_png(hook, target, int(width), int(height), style=style))
    return overlays, dropped

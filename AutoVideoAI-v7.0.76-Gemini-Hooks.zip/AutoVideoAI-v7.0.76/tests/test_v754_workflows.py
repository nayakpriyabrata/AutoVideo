import base64,json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from engine.flow_ui_blob import Capture
from engine.audio.commons_music import metadata,music_query
from engine.external_video import export_plan,configure,import_clip

def test_chunk_capture_atomic(tmp_path):
    page=object();out=tmp_path/'clip.mp4';c=Capture(page,out,lambda p:Path(p).read_bytes()==b'exact-video')
    assert c.receive({'page':page},{'index':0,'data':base64.b64encode(b'exact-video').decode()})
    assert not out.exists()
    assert c.receive({'page':page},{'done':True,'bytes':11})
    assert out.read_bytes()==b'exact-video';c.close()

def test_incomplete_blob_never_published(tmp_path):
    page=object();c=Capture(page,tmp_path/'out.mp4',lambda p:True)
    assert not c.receive({'page':page},{'done':True,'bytes':10})
    assert not (tmp_path/'out.mp4').exists();c.close()

def test_music_license_and_theme():
    info={'url':'https://upload.wikimedia.org/a.ogg','mime':'audio/ogg','extmetadata':{'LicenseUrl':{'value':'https://creativecommons.org/licenses/by/4.0/'}}}
    assert metadata(info)
    info['extmetadata']['LicenseUrl']['value']='https://creativecommons.org/licenses/by-nc/4.0/'
    assert metadata(info) is None
    assert 'piano' in music_query('self-confidence motivation')

def factory(tmp_path):
    (tmp_path/'settings.json').write_text('{}')
    shot=NS(shot_id='shot_001',provider='flow',compiled_prompt='Exact action',visual_goal='action',gen_duration=6,accepted_take='',opening_frame='',closing_frame='',start_frame='',end_frame='')
    manifest=NS(shots=[shot],topic='A topic',aspect='16:9')
    def associate(job,id,src):
        accepted=tmp_path/'accepted.mp4';accepted.write_bytes(Path(src).read_bytes());shot.accepted_take=str(accepted)
        return {'qc':{'decision':'ACCEPT'},'take':str(accepted)}
    pm=NS(load_manifest=lambda j:manifest,job_dir=lambda j:str(tmp_path),update_shot=lambda *a:None)
    return NS(pm=pm,associate_download=associate),shot

def test_external_plan_import_and_hash(tmp_path):
    f,shot=factory(tmp_path);plan=configure(f,'job',['shot_001'],True)
    assert plan['shots'][0]['seconds']==6
    clip=tmp_path/'source.mp4';clip.write_bytes(b'validated-by-factory-qc')
    result=import_clip(f,'job','shot_001',clip,reviewed=True,platform='Other AI')
    assert result['accepted'];assert shot.actual_provider=='external'
    assert (tmp_path/'external_video/shot_001.receipt.json').is_file()

def test_external_changed_plan_blocks(tmp_path):
    f,shot=factory(tmp_path);export_plan(f,'job');shot.compiled_prompt='Changed action'
    clip=tmp_path/'clip.mp4';clip.write_bytes(b'x')
    with pytest.raises(ValueError,match='changed'):import_clip(f,'job','shot_001',clip,reviewed=True)

def test_external_pending_requires_explicit_replacement(tmp_path):
    f,shot=factory(tmp_path);export_plan(f,'job');directory=tmp_path/'flow/shots/shot_001';directory.mkdir(parents=True)
    (directory/'take_01.mp4.flow-request.json').write_text('{"status":"pending"}')
    clip=tmp_path/'clip.mp4';clip.write_bytes(b'x')
    with pytest.raises(ValueError,match='pending'):import_clip(f,'job','shot_001',clip,reviewed=True)


def test_external_settings_survive_factory_merge(tmp_path,monkeypatch):
    from engine.factory import Factory
    monkeypatch.chdir(Path(__file__).resolve().parents[1])
    f=Factory(outputs=str(tmp_path/'outputs'),db_path=str(tmp_path/'jobs.db'))
    job=f.create_job('External shot workflow',external_video_mode=True)
    assert f._settings(job)['external_video_mode'] is True


def test_broll_source_search_emits_slot_progress(tmp_path,monkeypatch):
    from engine.broll import _fetch_candidates
    from engine.providers.stock_provider import StockProvider
    import engine.stock_video as stock
    monkeypatch.setattr(StockProvider,'_pick_local',lambda *a,**k:None)
    monkeypatch.setattr(stock,'get_stock_videos',lambda *a,**k:{'clips':[]})
    calls=[]
    result=_fetch_candidates([{'query':'forest rain','candidate_id':'one'}],str(tmp_path),True,
        progress_cb=lambda *args:calls.append(args))
    assert calls and 'Slot 1/1' in calls[0][2]
    assert result[0]['status']=='not_found'

# Flow exact-image click hook (v7.0.89)

## Problem
Flow starts image downloads by clicking a detached blob anchor (`a.click()` or a synthetic click).
v7.0.88 logs show that a failing save follows the browser's own download event, and the
Chrome crash log lists a crash within a second of each failing download event. The in-page
capture never saw a click (`messages=0`), because detached anchors do not reach document listeners.

## What changed
- `engine/flow_ui_blob.py`: while armed, `HTMLAnchorElement.prototype.click` and
  `dispatchEvent` are hooked. A click on an exact blob anchor (same origin, `download`
  attribute) is taken in the page: `fetch` resolves the blob at click time, so revoking it right
  after the click does not matter. The bytes are sent in chunks through the existing binding, and
  Python validates the file before it is moved into place. No browser download starts.
- If the in-page read fails, or Python rejects the bytes, the original click runs (the browser
  download), as in earlier releases. The fallback runs only while the capture is still open.
- The hook is removed when the capture closes; the browser's original click behaviour is restored.
- `engine/flow_download_diagnostics.py`: the Playwright `Browser logs:` tail (the browser's own
  stderr, last 10 lines, capped, URLs removed) is kept in failure text, instead of being dropped.
- `engine/providers/flow_browser.py`: the launch transport and whether `DISPLAY`/`WAYLAND_DISPLAY`
  are set are logged once after launch (`browser launched: ...`), so a crash can be matched to it.

## What it does not do
- It does not change which page is clicked, which tile is chosen, or whether a new image is generated.
- It does not reproduce the Chrome crash. The crash cause is still unproven. Compare the next
  runtime log's `browser launched` line and any `Browser logs (last lines)` tail with `chrome://crashes`.

## Verification
- `tests/test_v789_blob_click_hook.py` (9 tests): unit tests for the log tail and the hook script,
  and real-browser tests through Playwright Python. The browser tests use Chromium
  (set `AUTOVIDEO_TEST_CHROMIUM`) and skip if none can be launched. Result in the build sandbox:
  Chromium 131 (npm `@sparticuz/chromium@131`), 9 passed.
- Standalone checks in Chromium 131 with the production script: `a.click()` with an immediate
  revoke, synthetic `dispatchEvent`, and a trusted click on an attached anchor each delivered 300,000
  bytes with a matching SHA-256 and started no browser download. A blob revoked before the click
  fell back to the original download. After `remove()`, a normal click downloads again.
- Not verified: Chrome 153 (the user's Playwright browser). The user's first run on 7.0.89 is the test.

## Update
From 7.0.88: `python3 ../AutoVideoAI-v7.0.89/tools/update_v788_to_v789.py . --apply`
From 7.0.87: first apply `python3 ../AutoVideoAI-v7.0.88/tools/update_v787_to_v788.py . --apply`.
Stop the dashboard first. Runtime data, jobs, profiles and outputs are never touched.

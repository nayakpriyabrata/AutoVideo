from types import SimpleNamespace as NS
from PIL import Image
import pytest


def test_playful_brand_opens_closes_and_remains_visible_without_cards(tmp_path):
    from engine.render.graphics import build_overlay_assets
    m = NS(target_seconds=80, topic='Morning habits', shots=[], content_type='educational', width=360, height=640)
    assets = build_overlay_assets(m, {}, str(tmp_path), channel_name='Skill Soft Pro',
                                  show_watermark=True, text_cards_enabled=False, style='playful')
    assert len(assets) >= 4 and all(a['kind'] == 'watermark' and a['path'] for a in assets)
    assert assets[0]['body'] == 'closed' and assets[1]['body'] == ''
    assert all(0 <= a['start'] < a['end'] <= 80 for a in assets)
    a = Image.open(assets[0]['path']).getbbox()
    b = Image.open(assets[1]['path']).getbbox()
    assert b[2]-b[0] > a[2]-a[0] and b[1] < 640*.2


def test_generic_flow_error_does_not_override_queued_request():
    from tests.test_v482_stale_failure_resilience import _browser
    b = _browser("Your video is in the queue due to high demand. Something went wrong")
    assert b.detect_failure() is None
    b = _browser("Your video is in the queue due to high demand. generation failed")
    assert b.detect_failure() == 'generation failed'


def test_branding_edit_keeps_accepted_take_and_rejects_invalid_style(tmp_path):
    from engine.factory import Factory
    from engine.project.manifest import Shot
    f = Factory(str(tmp_path/'outputs'), str(tmp_path/'db.sqlite'))
    job = f.create_job('Morning habits', caption_template='OPUS', watermark=True)
    m = f.pm.load_manifest(job)
    m.shots = [Shot(shot_id='shot_001', accepted_take='keep.mp4', status='accepted')]
    f.pm.save_manifest(m)
    f.set_presentation_options(job, watermark=True, channel_name='Skill Soft Pro',
                               text_card_style='playful', caption_template='OPUS')
    assert f.pm.load_manifest(job).shots[0].accepted_take == 'keep.mp4'
    assert f._settings(job)['caption_template'] == 'OPUS'
    with pytest.raises(ValueError, match='caption_template'):
        f.set_presentation_options(job, caption_template='invalid')

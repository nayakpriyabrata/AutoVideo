# Video review and music workflow — v7.0.59

## The two supplied exports

`20261017-113230-discipline-beats-motivat-2c5d-final-broll.mp4` is 49.96 s, 1920×1080, 24 fps, H.264/AAC. Its first ten sampled frames, spaced five seconds apart, show an English title on a dark face/fire, two near-identical face compositions at 5–10 s, and a series of desk/checklist/headset/hair/truck/clock cutaways at 15–40 s. Several inserts do not visibly communicate discipline. Odia captions overlap busy images. The opening supplies a title rather than a concrete question or problem. This needs editorial replacement and caption review before publication.

`20261016-115816-the-power-of-self-confid-31b9-final-broll.mp4` is 235.46 s, 1920×1080, 24 fps, H.264/AAC. Across 47 samples at five-second intervals, the same female presenter and bright living-room setting recur for most of the runtime, with occasional street/temple inserts. The story has limited visual progression; the opening uses a title and presenter rather than a specific tension or payoff. Some Hindi captions and decorative overlays need a legibility and spelling check. A five-minute topic needs a more varied, relevant shot plan and a stronger opening.

Measured audio: discipline −14.52 LUFS integrated, −2.21 dBTP; self-confidence −14.01 LUFS, −1.47 dBTP. Both are valid audio streams but are almost entirely centered: stereo side-to-mid RMS ratios approximately 0.0027 and 0.000042. This is consistent with voice-only or a very faint mono music bed; it is not proof that a particular song was absent. No audio listening/transcript audit or stock asset rights packet was available. These files are technical renders, not approved publication masters.

## Music library

`outputs` is commonly linked into AutoVideoAI-Shared, so the default reviewed folder resolves to `AutoVideoAI-Shared/music_library`. An explicit `AUTOVIDEO_MUSIC_LIBRARY` overrides it. Upload tracks through Guided Studio's music panel or Music Video's shared library panel. Supply a title, theme words (for example `confidence motivation cinematic`), exact source URL, license/permission label, and check rights for your publication platforms. Each file is probed, hashed, and recorded in `manifest.json`. Local selection chooses a matching reviewed theme and refuses a changed file. It does not silently take the alphabetically first unrelated track.

Suggested audition shortlist (each file page states CC0 at the time reviewed):

- TRG Banks, **Above the Earth**, 4:14: https://commons.wikimedia.org/wiki/File:TRG_Banks_-_03_-_Above_the_Earth.ogg
- Loyalty Freak Music, **Once more with you**, 3:03: https://commons.wikimedia.org/wiki/File:Loyalty_Freak_Music_-_01_-_Once_more_with_you.ogg
- Monplaisir, **Free To Use 1**, 3:12: https://commons.wikimedia.org/wiki/File:Monplaisir_-_01_-_Free_To_Use_1.ogg

Open each page, play the file, verify the current file-specific license, then download the original OGG. Some old uploads have conflicting embedded metadata; if the file/page conflict, use another track. CC0 allows commercial reuse, but platform automated claims remain possible. Retain the file page URL and license evidence. YouTube Studio Audio Library is another source for YouTube; YouTube does not guarantee licensing outside YouTube. Do not assume a Pixabay track is claim-free just because its page says free.

## New controls

- Guided Studio: editable Gemini Web music brief (including an original opening musical hook), reviewed shared library import/preview, Flow Music choice, and `reliable` music by default for voiced jobs. The app checks selected music before visual generation and reports errors instead of returning a musicless render.
- Music Video: visible manual Flow Music upload, Flow Music browser, shared library, or local path. Gemini Web writes editable original song/background directions and an optional lyric draft. Review lyrics and rights before creating the music-video storyboard.
- Queue: an existing completed job can create a new video copy with a reviewed music track and voice ducking. It leaves the original master unchanged and stores track hash, license, URL and gain beside the copy.
- Guided script draft: requests a specific opening tension and shows its first-scene hook for review. Existing jobs need a new edit/storyboard to change narrative hooks; adding a sound accent alone cannot fix a weak opening.

## Install and recover

Stop Studio/CLI production, extract `AutoVideoAI-v7.0.59` beside your installation, then from `AutoVideoAI-v7`:

```bash
cat VERSION
python3 ../AutoVideoAI-v7.0.59/tools/update_v758_to_v759.py . --apply
./dashboard.sh
```

The updater requires `VERSION` 7.0.58; use the earlier sequential updaters if needed. It does not copy outputs or shared music. Add three or more carefully chosen tracks with distinct theme tags. Test one short dry run/plan, then a small real job. Open Queue after rendering, inspect the sound plan and listen to the first, middle, and last minute. Use `Add reviewed background music to a copy` for an existing finished job and compare it with the original before publishing.

Validation: focused music import, matching, provenance, Gemini text direction, and an FFmpeg music-copy test passed by direct invocation; Python compile passed. The Pytest runner in this workspace previously exited with a bus error before collection. Live Gemini/Flow and signed-in music sites were not exercised. Human review remains necessary for pronunciation, editorial match, licensed B-roll, platform terms and copyright claims.

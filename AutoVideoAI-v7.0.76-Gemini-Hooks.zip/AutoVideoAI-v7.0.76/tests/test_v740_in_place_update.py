import hashlib
import json
from pathlib import Path
import pytest
from tools.update_v739_to_v740 import update, FILES


def setup(tmp_path):
    source = tmp_path / 'new'; target = tmp_path / 'old'
    source.mkdir(); target.mkdir()
    for rel in FILES:
        src = source / rel; src.parent.mkdir(parents=True, exist_ok=True)
        src.write_text('7.0.40' if rel == 'VERSION' else 'new code')
        dst = target / rel; dst.parent.mkdir(parents=True, exist_ok=True)
        if rel != 'engine/flow_reference_validation.py':
            dst.write_text('7.0.39' if rel == 'VERSION' else 'old code')
    entries = [{'path': rel, 'sha256': hashlib.sha256((source / rel).read_bytes()).hexdigest()} for rel in FILES]
    (source / 'RELEASE_MANIFEST.json').write_text(json.dumps({'version': '7.0.40', 'files': entries}))
    (target / 'outputs').mkdir(); (target / 'outputs/saved.mp4').write_bytes(b'existing media')
    (target / '.env').write_text('private settings')
    return source, target


def test_code_update_preserves_runtime_and_backs_up(tmp_path):
    source, target = setup(tmp_path)
    assert not update(source, target)['apply']
    assert (target / 'VERSION').read_text() == '7.0.39'
    result = update(source, target, True)
    assert (target / 'VERSION').read_text() == '7.0.40'
    assert (Path(result['backup']) / 'VERSION').read_text() == '7.0.39'
    assert (target / 'outputs/saved.mp4').read_bytes() == b'existing media'
    assert (target / '.env').read_text() == 'private settings'


def test_tampered_source_is_rejected_before_any_write(tmp_path):
    source, target = setup(tmp_path)
    (source / 'engine/factory.py').write_text('changed')
    with pytest.raises(ValueError, match='hash mismatch'):
        update(source, target, True)
    assert (target / 'VERSION').read_text() == '7.0.39'


def test_code_symlink_cannot_write_outside_installation(tmp_path):
    source, target = setup(tmp_path)
    outside = tmp_path / 'external.py'; outside.write_text('preserved')
    (target / 'engine/factory.py').unlink(); (target / 'engine/factory.py').symlink_to(outside)
    with pytest.raises(ValueError, match='Unsafe code path'):
        update(source, target, True)
    assert outside.read_text() == 'preserved'


def test_interrupted_code_copy_rolls_back_already_written_files(tmp_path, monkeypatch):
    import tools.update_v739_to_v740 as module
    source, target = setup(tmp_path)
    replace = module.os.replace
    def fail(src, dst):
        if Path(dst).name == 'README.md':
            raise OSError('simulated disk failure')
        replace(src, dst)
    monkeypatch.setattr(module.os, 'replace', fail)
    with pytest.raises(OSError, match='disk failure'):
        update(source, target, True)
    assert (target / 'VERSION').read_text() == '7.0.39'
    assert (target / 'README.md').read_text() == 'old code'
    assert not (target / 'engine/flow_reference_validation.py').exists()

# AutoVideo 7.0.93: image requests may use a fresh request; video stays credit-protected

**Status: fixture-tested only.** The 7.0.93 behaviour is verified with fakes in `tests/test_v793_fresh_image_requests.py`
and the earlier recovery tests. It has NOT been verified against live Flow. The first real use must be watched.

**Default split size: 2400 characters** per Gemini TTS request (unchanged from 7.0.82).

## Why

Image requests in Flow cost no credits (Flow's default image model is free for all Flow users, per Google's
announcements; confirm the selected model shows zero cost in Flow Settings before relying on it). Video requests do cost
credits.

In 7.0.92 a saved image request whose project held only the uploaded references (no generated image) stopped cleanly,
but it required a manual `cli.py archive-request ... --confirm-new-credit-spend` before a new submission could happen.
For images that is unnecessary friction, so 7.0.93 does it automatically, with hard limits.

## What changed

- **Image, no output (the only case that resubmits).** After the saved request has been recovered once and no generated
  image exists, the unresolved request is archived (kept, renamed `*.flow-request.archived-<time>-<id>.json`, never
  deleted) and one fresh image request is submitted. A shot gets at most **3 image submissions** in total. After that
  the run stops with the explicit reason `stopped after 3 submission(s)` and keeps the last request.
- **Two or more real outputs** in the saved project: still blocked. No wait, no archive, no resubmission. The message
  says two real outputs stay blocked and must be resolved by hand. Never guess between candidates.
- **Video:** never archived or resubmitted automatically. Video requests keep the exact-recovery rules from 7.0.61/7.0.92.
- **Resume gate (images only):** an image request that was never acknowledged (`submission_uncertain`) with no local
  image no longer blocks Resume; `generate()` handles it. A `submitted` image request still blocks Resume and keeps the
  7.0.87 download-only wait. Video journals still block.
- **Archive names** include a random suffix, so two archives in the same second never overwrite each other.
- **Wait message** now says uploaded reference tiles (AV_ labels) are excluded, instead of counting labels.

## Not included

- No fail-fast. A fresh request still waits up to the normal 360 s for a new image. The 17:28-17:34 IST runs
  (2026-10-25) showed no submit-acknowledged line; that diagnosis is still open.
- No change to the spend guard for video, to the Flow daily or per-job limits, or to Flow project deletion.

## Check before use

1. Flow Settings: the selected image model shows zero cost per image (the config `imagen_flow` is `credits_per_image: 0`,
   which the code assumes but does not check against Flow's picker).
2. Watch the first fresh request: it should show "fresh image request" in the log, then a new generated image.

## Update

From the installation folder, after extracting this zip beside it. The installation must be 7.0.92 (run the 7.0.92 update
first if it is older):

    python3 ../AutoVideoAI-v7.0.93/tools/update_v792_to_v793.py .            # dry run
    python3 ../AutoVideoAI-v7.0.93/tools/update_v792_to_v793.py . --apply    # install

Stop the dashboard first. Outputs, saved jobs and browser profiles are not touched.

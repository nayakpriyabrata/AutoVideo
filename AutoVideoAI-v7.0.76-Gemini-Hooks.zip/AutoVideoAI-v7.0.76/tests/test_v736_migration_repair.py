import importlib.util
import json
import sqlite3
from pathlib import Path
from types import SimpleNamespace
import hashlib
import pytest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('migration736',ROOT/'tools/migrate_installation.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def test_command_is_never_stat_or_rebased(tmp_path):
    old=tmp_path/'AutoVideoAI-v7.0.22';new=tmp_path/'AutoVideoAI-v7.0.36'
    command=str(old/'outputs/job/accepted.mp4')+' -ss 0.75 -t 4.5 -i '+str(old/'outputs/job/take.mp4')+' -filter_complex '+('scale;'*3000)
    assert m.rebase(command,old,new)==command
    assert m.rebase(command,new,new)==command


def test_repair_deleted_old_folder_json_sqlite_hashes(tmp_path):
    current=tmp_path/'AutoVideoAI-v7.0.35';current.mkdir();(current/'VERSION').write_text('7.0.35')
    asset=current/'outputs/job/broll/scene.mp4';asset.parent.mkdir(parents=True);asset.write_bytes(b'exact approved video')
    old=tmp_path/'AutoVideoAI-v7.0.34';oldpath=str(old/'outputs/job/broll/scene.mp4')
    candidate={'candidate_id':'scene_cut_001','approved':True,'rights_reviewed':True,'sha256':hashlib.sha256(asset.read_bytes()).hexdigest(),'path':oldpath}
    review=asset.parent.parent/'broll.json';review.write_text(json.dumps({'candidates':[candidate]}))
    (current/'data').mkdir()
    with sqlite3.connect(current/'data/jobs.db') as conn:
        conn.execute('CREATE TABLE jobs(path TEXT)');conn.execute('INSERT INTO jobs VALUES (?)',(oldpath,))
    original=review.read_bytes()
    dry=m.repair_paths(current);assert review.read_bytes()==original and dry['missing_approved_assets']==[]
    result=m.repair_paths(current,apply=True)
    assert result['rebased']==2 and result['missing_approved_assets']==[]
    assert json.loads(review.read_text())['candidates'][0]['path']==str(asset)
    assert json.loads(review.read_text())['candidates'][0]['sha256']==candidate['sha256']
    assert (Path(result['backup_folder'])/'rewritten/outputs/job/broll.json').read_bytes()==original
    with sqlite3.connect(current/'data/jobs.db') as conn:assert conn.execute('SELECT path FROM jobs').fetchone()[0]==str(asset)
    asset.write_bytes(b'changed')
    assert m.repair_paths(current)['missing_approved_assets'][0]['candidate']=='scene_cut_001'


def test_migration_long_diagnostic_does_not_abort_remaining_files(tmp_path):
    old=tmp_path/'AutoVideoAI-v7.0.34';new=tmp_path/'AutoVideoAI-v7.0.36'
    for p in (old,new):p.mkdir();(p/'VERSION').write_text('7.0.36')
    media=old/'outputs/job/stock.mp4';media.parent.mkdir(parents=True);media.write_bytes(b'video')
    command=str(tmp_path/'AutoVideoAI-v7.0.22/outputs/job/stock.mp4')+' -i '+('x'*9000)
    (media.parent/'a.json').write_text(json.dumps({'command':command}))
    (media.parent/'z.json').write_text(json.dumps({'path':str(media)}))
    report=m.migrate(old,new,apply=True)
    assert report['copied']==3
    assert json.loads((new/'outputs/job/a.json').read_text())['command']==command
    assert json.loads((new/'outputs/job/z.json').read_text())['path']==str(new/'outputs/job/stock.mp4')


def test_ai_storyboard_does_not_search_photographic_stock(tmp_path,monkeypatch):
    from engine import visuals
    from engine.providers.image_provider import ImageProvider
    from PIL import Image
    monkeypatch.setattr(visuals,'_try_pexels',lambda *a:pytest.fail('Generative storyboard must not use stock'))
    seen=[]
    def generate(prompt,w,h,seed,out):
        seen.append(prompt);Image.new('RGB',(10,10),'blue').save(out);return True
    monkeypatch.setattr(visuals,'_pollinations_with_retry',generate)
    prompt='Cute cartoon Kanha and Radha in Vrindavan, '+('maintain character identity '*20)
    ImageProvider().storyboard_frame(prompt,str(tmp_path/'open.jpg'),True)
    assert seen==[prompt]
    monkeypatch.setattr(visuals,'_pollinations_with_retry',lambda *a:False)
    with pytest.raises(RuntimeError,match='placeholder'):
        ImageProvider().storyboard_frame(prompt,str(tmp_path/'close.jpg'),True)


def test_sidebar_defaults_are_not_nullable():
    source=(ROOT/'app.py').read_text()
    assert 'NAV_GROUPS[workspace]' in source
    assert 'index=(None if' not in source[source.index('workspace = st.sidebar.selectbox'):source.index('indexed_jobs =')]

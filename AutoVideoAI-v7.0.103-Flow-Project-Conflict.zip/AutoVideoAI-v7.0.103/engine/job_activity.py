"""v7.0.103: answer "is this job still running, or did it stop?" from files, without a browser.

Field case (2026-10-27): the Queue showed ``status: planned`` and a red line *"Video Flow project must differ
from storyboard image project"*. Nothing said whether the production was still working or had stopped, and
``planned`` reads like "queued".

``job_activity()`` reads three local facts:

* the job's ``.production.lock`` — held means a live process owns this job (running);
* ``logs/progress.json`` — the last stage and percentage;
* the tail of ``generation_log.json`` — the most recent recorded event, including a stop reason.

It never opens a browser, takes no lock longer than an instant, and writes nothing.
"""
from __future__ import annotations

import datetime
import fcntl
import json
import os

LOCK_NAME = '.production.lock'
STOP_EVENTS = ('job_paused', 'flow_request_failed_without_pause', 'job_failed', 'run_failed',
               'flow_project_conflict', 'flow_recovery_exhausted')


def _read_json(path):
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def lock_held(job_dir) -> bool:
    """True when another process holds this job's production lock (an instant, non-blocking probe)."""
    path = os.path.join(job_dir, LOCK_NAME)
    if not os.path.isfile(path):
        return False
    try:
        with open(path, 'a+b') as handle:
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                return True
            fcntl.flock(handle, fcntl.LOCK_UN)
            return False
    except OSError:
        return False


def _age(seconds) -> str:
    if seconds is None:
        return 'unknown age'
    seconds = int(seconds)
    if seconds < 90:
        return f'{seconds}s ago'
    if seconds < 5400:
        return f'{seconds // 60}m ago'
    if seconds < 172800:
        return f'{seconds // 3600}h ago'
    return f'{seconds // 86400}d ago'


def _epoch(stamp):
    try:
        return datetime.datetime.fromisoformat(str(stamp)).timestamp()
    except (TypeError, ValueError):
        return None


def job_activity(job_dir, now=None) -> dict:
    """Local, read-only snapshot: is the job running, how far did it get, and why did it stop?"""
    job_dir = str(job_dir)
    now = now if now is not None else datetime.datetime.now().timestamp()
    running = lock_held(job_dir)
    progress = _read_json(os.path.join(job_dir, 'logs', 'progress.json'))
    events = _read_json(os.path.join(job_dir, 'generation_log.json'))
    # generation_log.json is a list, so _read_json's dict guard rejects it: read it directly.
    try:
        with open(os.path.join(job_dir, 'generation_log.json'), encoding='utf-8') as handle:
            loaded = json.load(handle)
        events = loaded if isinstance(loaded, list) else []
    except (OSError, ValueError):
        events = []
    last = events[-1] if events else {}
    stopped = next((row for row in reversed(events)
                    if str(row.get('event')) in STOP_EVENTS), {})
    progress_stamp = _epoch(progress.get('ts'))
    last_stamp = _epoch(last.get('ts'))
    newest = max([value for value in (progress_stamp, last_stamp) if value], default=None)
    return {
        'running': running,
        'last_stage': str(progress.get('stage') or ''),
        'last_percent': progress.get('percent'),
        'last_progress_at': progress.get('ts', ''),
        'last_event': str(last.get('event') or ''),
        'last_event_at': last.get('ts', ''),
        'idle': _age(now - newest) if newest else 'unknown',
        'stopped_by': str(stopped.get('event') or ''),
        'stop_reason': ' '.join(str(stopped.get('error') or stopped.get('reason') or '').split())[:600],
        'stop_shot': str(stopped.get('shot') or ''),
        'stop_at': stopped.get('ts', ''),
    }


def describe(activity) -> list[str]:
    """Human lines for ``cli.py v3 status``: running / stopped, and what to do next."""
    if activity.get('running'):
        head = ('RUNNING: a live process holds this job ('
                + (f"{activity.get('last_stage')} · {activity.get('last_percent')}% · "
                   f"last update {activity.get('idle')}" if activity.get('last_stage') else 'no progress line yet')
                + '). Keep Studio open.')
        return [head]
    lines = ['NOT RUNNING: no process holds this job, so nothing is progressing on its own.']
    if activity.get('last_stage'):
        lines.append(f"  Last progress: {activity['last_stage']} "
                     f"({activity.get('last_percent')}%, updated {activity.get('idle')})")
    if activity.get('stop_reason'):
        lines.append(f"  Stopped by: {activity.get('stopped_by')} at {activity.get('stop_at')}"
                     + (f" (shot {activity['stop_shot']})" if activity.get('stop_shot') else ''))
        lines.append(f"  Reason: {activity['stop_reason']}")
    elif activity.get('last_event'):
        lines.append(f"  Last recorded event: {activity['last_event']} at {activity.get('last_event_at')}")
    lines.append('  A status of "planned" means the plan is saved, not that work is in progress.')
    return lines

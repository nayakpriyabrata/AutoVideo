import json
import subprocess
from pathlib import Path
from types import SimpleNamespace as NS
import pytest


def test_scene_plan_wins_over_keyword_defaults():
    from engine.planning.story_bible import build_bible
    from engine.planning.frame_prompts import master_location_prompt
    beat={'visual_intent':'Full body woman dancing in heavy rain on forest street at night', 'environment':'Exterior forest street, heavy rain, night'}
    bible=build_bible('Girl dancing in rain on street','cinematic_story',{},beats=[beat])
    prompt=master_location_prompt(bible,True)
    assert beat['environment'] in prompt and 'apartment' not in prompt


def test_visual_director_preserves_action_and_framing(tmp_path,monkeypatch):
    from engine.factory import Factory
    from engine.visual_plan import validated_visual_plan
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'db.sqlite'))
    plan=validated_visual_plan({'narration':'','scenes':[{'text':'','duration':6,
        'visual_intent':'Full body dance on forest street at night','environment':'Exterior forest street at night',
        'framing':'Full body wide shot','camera_movement':'Slow arc'}]},'Rain dance',6,'en','silent')
    path=tmp_path/'plan.json';path.write_text(json.dumps(plan))
    job=f.create_job('Rain dance',target_seconds=6,approved_plan_path=str(path),voiceover_enabled=False,background_music='off',profile='LOCAL_FREE',dry_run=True)
    monkeypatch.setattr(f,'_generate_all',lambda *a:None)
    f.run_job(job)
    shot=f.pm.load_manifest(job).shots[0]
    assert shot.subject_action=='Full body dance on forest street at night'
    assert shot.environment=='Exterior forest street at night'
    assert shot.camera_framing=='Full body wide shot'
    assert shot.camera_movement=='Slow arc'


def test_auto_music_handles_browser_failure_and_caches(tmp_path,monkeypatch):
    from engine.audio import music_provider as mp
    from engine.audio.job_music import obtain_job_music
    monkeypatch.setattr(mp,'pick_music',lambda *a:None)
    calls=[]
    real=mp.subprocess.run
    def dispatch(cmd,**kw):
        if 'engine.providers.web_media_helper' in cmd:
            calls.append(cmd);return NS(returncode=1,stderr='AUTOVIDEO_MEDIA_SEARCH=browser_launch_failed',stdout='')
        return real(cmd,**kw)
    monkeypatch.setattr(mp.subprocess,'run',dispatch)
    result=obtain_job_music(tmp_path,'auto','joyful dance')
    assert result['source']=='local-generated-instrumental' and result['warning']
    assert obtain_job_music(tmp_path,'auto','joyful dance')['sha256']==result['sha256']
    assert len(calls)==1


def test_local_music_invalid_media_rejected(tmp_path):
    from engine.audio.job_music import obtain_job_music
    p=tmp_path/'fake.mp3';p.write_text('not audio')
    with pytest.raises(Exception):obtain_job_music(tmp_path,'local','',str(p))
    assert not (tmp_path/'music_preflight.json').exists()


def test_new_job_does_not_inherit_replacement_permission(tmp_path):
    from engine.factory import Factory
    f=Factory(str(tmp_path/'out'),str(tmp_path/'db.sqlite'))
    job=f.create_job('Rain dance',dry_run=True)
    assert f._settings(job)['flow_replace_unresolved_images'] is False
    f.set_flow_image_replacement(job,True,2)
    assert f._settings(job)['flow_replace_unresolved_images'] is True


def test_storyboard_audit_counts_only_verified_receipts(tmp_path):
    from engine.generation_audit import frame_fallbacks
    from engine.production import digest
    p=tmp_path/'master.jpg';p.write_bytes(b'fixture')
    receipt=Path(str(p)+'.free-image.json');receipt.write_text(json.dumps({'shot_id':'shot_1','label':'location master','sha256':digest(p)}))
    result=frame_fallbacks(tmp_path,[NS(shot_id='shot_1',opening_frame_source='free')])
    assert len(result)==2
    p.write_bytes(b'changed')
    assert len(frame_fallbacks(tmp_path,[]))==0
    assert frame_fallbacks(tmp_path,[], 'free')==[]


def test_rotated_video_recovery_requires_exact_unique_prompt():
    from engine.providers.flow_browser import FlowBrowserProvider
    p=FlowBrowserProvider.__new__(FlowBrowserProvider)
    request={'submitted_prompt':'the complete exact prompt','project_url':'https://flow.google.com/project/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','baseline':[]}
    assets=[{'kind':'video','sig':'v1'}]
    b=NS(current_project_url=lambda:request['project_url'],media_assets=lambda:assets,
         read_asset_generation_prompt=lambda sig:'the complete exact prompt')
    assert p._reidentify_exact_video(b,request)=='v1'
    assets.append({'kind':'video','sig':'v2'})
    assert not p._reidentify_exact_video(b,request)
    request.pop('submitted_prompt')
    assert not p._reidentify_exact_video(b,request)


def test_photo_identity_does_not_bring_biography_background():
    from engine.cast import prompt_identity
    person={'name':'Cast','canonical':'Long description. Indoor sunny living room.', 'references':[{'path':'photo.jpg'}]}
    assert 'living room' not in prompt_identity(person)
    person['references']=[]
    assert prompt_identity(person)==person['canonical']


@pytest.mark.parametrize('has_audio',[False,True])
def test_sound_hooks_preserve_source_frames_duration_and_cache(tmp_path,has_audio):
    from engine.audio.hooks import export_hooks
    from engine.production import digest
    src=tmp_path/'clip.mp4'
    cmd=['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=blue:s=128x128:r=24']
    if has_audio:cmd+=['-f','lavfi','-i','sine=frequency=220:sample_rate=48000']
    subprocess.run(cmd+['-t','4','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac',str(src)],check=True)
    before=digest(src);out=export_hooks(src,style='cinematic')
    assert digest(src)==before and Path(out)!=src
    assert export_hooks(src,style='cinematic')==out
    def video_hash(p):
        return subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:v','-f','hash','-hash','sha256','-']).strip()
    assert video_hash(src)==video_hash(out)
    info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',out]))
    assert any(s['codec_type']=='audio' for s in info['streams'])
    assert abs(float(info['format']['duration'])-4)<.1


def test_strict_candidate_generation_does_not_fallback(tmp_path,monkeypatch):
    from engine.factory import Factory
    from tests.test_scene_images import _job_with_shot, _stub_providers
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'db.sqlite'));job=_job_with_shot(f)
    def failed(out):raise RuntimeError('Flow UI changed')
    def free(out):pytest.fail('Strict Flow must not call free image provider')
    _stub_providers(monkeypatch,f,failed,free)
    with pytest.raises(RuntimeError,match='Strict Flow'):
        f._generate_scene_images(f.pm.load_manifest(job),f.pm.dirs(job),NS(add=lambda *a:None),True,1,lambda *a:None,{'flow_image_workers':1,'frame_source':'flow'})

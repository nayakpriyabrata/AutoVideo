"""Destination exports and a local review desk. No silent social-account posting."""
from pathlib import Path
import hashlib
import ipaddress
import json
import math
import os
import re
import shutil
import subprocess
import unicodedata
import uuid
from urllib.parse import urlsplit, urlunsplit

from .languages import language_pack
from .production import save, read, digest

PROFILES = {
    'instagram_reel': {'width':1080, 'height':1920, 'fps':30, 'audio_kbps':128, 'max_seconds':180, 'max_bytes':300*1024*1024},
    # The Facebook Page Reels Publishing API currently documents 3–90 seconds.
    'facebook_reel': {'width':1080, 'height':1920, 'fps':30, 'audio_kbps':192,
                      'min_seconds':3, 'max_seconds':90, 'max_bytes':1024*1024*1024},
    'youtube_short': {'width':1080, 'height':1920, 'fps':30, 'audio_kbps':384, 'max_seconds':180, 'max_bytes':2*1024**3},
    'youtube_long': {'width':1920, 'height':1080, 'fps':30, 'audio_kbps':384, 'max_seconds':7200, 'max_bytes':8*1024**3},
}
# Conservative application recipes, not universal platform maximum limits.


def destination_profile(name):
    if name not in PROFILES:
        raise ValueError('Unknown destination profile')
    return dict(PROFILES[name])


def _clean_metadata_text(value, limit, *, multiline=False):
    text = unicodedata.normalize('NFC', str(value or ''))
    text = ''.join(char for char in text
                   if char in '\n\t' or (ord(char) >= 0x20 and not 0x7f <= ord(char) <= 0x9f))
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    if multiline:
        text = '\n'.join(re.sub(r'[ \t]+', ' ', line).strip() for line in text.splitlines()).strip()
    else:
        text = re.sub(r'\s+', ' ', text).strip()
    return text[:limit].rstrip()


def _normalize_hashtags(value):
    if value is None or value == '':
        return []
    if isinstance(value, str):
        values = re.split(r'[\s,]+', value.strip())
    elif isinstance(value, (list, tuple)):
        values = list(value)
    else:
        raise ValueError('Hashtags must be text or a list of text values')
    tags, seen = [], set()
    for value in values:
        raw = unicodedata.normalize('NFC', str(value or '').strip()).lstrip('#')
        tag = ''.join(char for char in raw
                      if char == '_' or char.isalnum()
                      or unicodedata.category(char) in {'Mn', 'Mc', 'Me'})[:64]
        if tag and tag.casefold() not in seen:
            seen.add(tag.casefold())
            tags.append('#' + tag)
        if len(tags) >= 12:
            break
    return tags


def _normalize_source_urls(value):
    if value is None or value == '':
        return []
    if isinstance(value, str):
        values = value.splitlines()
    elif isinstance(value, (list, tuple)):
        values = list(value)
    else:
        raise ValueError('Source references must be HTTPS URLs, one per line')
    if len(values) > 20:
        raise ValueError('Keep the upload packet to at most 20 source URLs')
    urls, seen = [], set()
    for item in values:
        raw = _clean_metadata_text(item, 2000)
        if not raw:
            continue
        try:
            parsed = urlsplit(raw)
            host = (parsed.hostname or '').lower().rstrip('.')
            port = parsed.port
            if (parsed.scheme.lower() != 'https' or not host or parsed.username or parsed.password
                    or (port is not None and port != 443) or host == 'localhost'
                    or host.endswith('.local')):
                raise ValueError
            try:
                ip_address = ipaddress.ip_address(host)
            except ValueError:
                ip_address = None  # Ordinary DNS hostnames are allowed as references.
            if ip_address is not None and not ip_address.is_global:
                raise ValueError
            normalized = urlunsplit(('https', parsed.netloc, parsed.path or '/', parsed.query, parsed.fragment))
        except (TypeError, ValueError):
            raise ValueError('Source references must be valid public HTTPS URLs without credentials or custom ports')
        if normalized.casefold() not in seen:
            urls.append(normalized)
            seen.add(normalized.casefold())
    return urls


def _normalize_post_metadata(*, title='', caption='', description='', hashtags=None,
                             chapters='', source_urls=None, category=''):
    if isinstance(chapters, (list, tuple)):
        chapters = '\n'.join(str(item) for item in chapters)
    return {
        'caption': _clean_metadata_text(caption, 5000, multiline=True),
        'description': _clean_metadata_text(description, 5000, multiline=True),
        'hashtags': _normalize_hashtags(hashtags),
        'chapters': _clean_metadata_text(chapters, 12000, multiline=True),
        'source_urls': _normalize_source_urls(source_urls),
        'category': _clean_metadata_text(category, 100),
    }, _clean_metadata_text(title, 100)


def _approval_fingerprint(record):
    """Hash the exact video, destination, copy, account and review choices."""
    keys = ('id', 'video', 'sha256', 'source_sha256', 'destination', 'language',
            'title', 'profile', 'duration', 'account_id', 'made_for_kids',
            'ai_disclosure_required', 'rights_confirmed', 'facts_reviewed',
            'language_reviewed', 'post_metadata')
    payload = {key: record.get(key) for key in keys}
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()


def _upload_packet_path(release_path):
    path = Path(release_path).resolve()
    suffix = '.release.json'
    stem = path.name[:-len(suffix)] if path.name.endswith(suffix) else path.stem
    return path.with_name(stem + '.upload.txt')


def _upload_packet_text(record):
    metadata = record.get('post_metadata') if isinstance(record.get('post_metadata'), dict) else {}
    hashtags = metadata.get('hashtags') if isinstance(metadata.get('hashtags'), list) else []
    sources = metadata.get('source_urls') if isinstance(metadata.get('source_urls'), list) else []
    lines = [
        'AUTOVIDEOAI — MANUAL UPLOAD PACKET',
        f"Status: {record.get('state', 'REVIEW_REQUIRED')}",
        f"Destination: {record.get('destination', '')}",
        f"Language: {record.get('language', '')}",
        f"Category: {metadata.get('category', '')}",
        f"Video file: {record.get('video', '')}",
        f"Video SHA-256: {record.get('sha256', '')}",
        f"Title: {record.get('title', '')}",
        '',
        'CAPTION',
        str(metadata.get('caption', '') or '(add/edit in the destination app if needed)'),
        '',
        'DESCRIPTION',
        str(metadata.get('description', '') or '(none supplied)'),
        '',
        'HASHTAGS',
        ' '.join(hashtags) if hashtags else '(none supplied)',
        '',
        'YOUTUBE CHAPTERS',
        str(metadata.get('chapters', '') or '(none supplied)'),
        '',
        'SOURCE / ATTRIBUTION LINKS',
    ]
    lines.extend(sources or ['(none supplied; add links only after checking rights and accuracy)'])
    lines.extend([
        '',
        'PRE-PUBLISH REVIEW — confirm in the native upload screen',
        f"- Rights cleared: {'YES' if record.get('rights_confirmed') is True else 'NOT APPROVED'}",
        f"- Facts/story reviewed: {'YES' if record.get('facts_reviewed') is True else 'NOT APPROVED'}",
        f"- Native-language copy reviewed: {'YES' if record.get('language_reviewed') is True else 'NOT APPROVED'}",
        f"- Intended for children: {record.get('made_for_kids') if type(record.get('made_for_kids')) is bool else 'CHOOSE'}",
        f"- Realistic/meaningfully altered AI disclosure: {record.get('ai_disclosure_required') if type(record.get('ai_disclosure_required')) is bool else 'REVIEW AND CHOOSE'}",
        f"- Exact account/channel: {record.get('account_id') or 'CHOOSE BEFORE UPLOAD'}",
        '',
        'This is a local convenience packet. It does not log in, upload, schedule remotely, or grant rights.',
    ])
    if record.get('approval_sha256'):
        lines.append(f"Approval fingerprint (video + copy + destination + checks): {record['approval_sha256']}")
    return '\n'.join(lines).rstrip() + '\n'


def _write_upload_packet(record, release_path):
    packet_path = _upload_packet_path(release_path)
    content = _upload_packet_text(record)
    temporary = packet_path.with_suffix(packet_path.suffix + '.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, packet_path)
    record['upload_packet'] = str(packet_path)
    record['upload_packet_sha256'] = hashlib.sha256(content.encode('utf-8')).hexdigest()
    save(release_path, record)
    return packet_path


def _upload_packet_is_unchanged(record, release_path):
    packet_path = _upload_packet_path(release_path)
    try:
        payload = packet_path.read_bytes()
    except OSError:
        return False
    return hashlib.sha256(payload).hexdigest() == record.get('upload_packet_sha256')


def export_cmd(source, target, destination, *, framing='fit', duration=None):
    from .render.ffmpeg_renderer import ffmpeg_exe
    profile = destination_profile(destination)
    if framing not in ('fit', 'crop'):
        raise ValueError('Export framing must be fit or crop')
    if duration is not None:
        try:
            duration = float(duration)
        except (TypeError, ValueError) as exc:
            raise ValueError('Duration must be a finite number of seconds') from exc
        minimum = float(profile.get('min_seconds', 0))
        if not math.isfinite(duration) or duration <= 0 or duration < minimum or duration > profile['max_seconds']:
            raise ValueError('Duration is outside this conservative destination recipe; choose another export')
    w,h = profile['width'],profile['height']
    if framing == 'fit':
        vf = f'scale={w}:{h}:force_original_aspect_ratio=decrease:force_divisible_by=2,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=0x18202b'
    else:
        vf = f'scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}'
    return [ffmpeg_exe(), '-y', '-i', str(source), '-map','0:v:0','-map','0:a?', '-vf',
            vf+f",setsar=1,fps={profile['fps']},format=yuv420p", '-c:v','libx264','-preset','medium',
            '-crf','18','-maxrate','20M','-bufsize','40M','-g',str(profile['fps']*2),
            '-c:a','aac','-b:a',f"{profile['audio_kbps']}k",'-ar','48000',
            '-movflags','+faststart',str(target)]


def export_delivery(source, folder, destination, *, language='en', title='', framing='fit', duration=None,
                    caption='', description='', hashtags=None, chapters='', source_urls=None, category=''):
    source = Path(source).expanduser().resolve()
    if not source.is_file():
        raise ValueError('Render a local source video first')
    profile = destination_profile(destination)
    if duration is None:
        from .render.ffmpeg_renderer import _probe_av_durations
        measured = _probe_av_durations(str(source))
        duration = measured.get('video') or measured.get('format')
        if not duration:
            raise ValueError('Cannot determine source duration; install ffprobe before export')
    code = language_pack(language).code
    post_metadata, normalized_title = _normalize_post_metadata(
        title=title, caption=caption, description=description, hashtags=hashtags,
        chapters=chapters, source_urls=source_urls, category=category)
    folder = Path(folder).resolve()
    if folder == source.parent:
        raise ValueError('Export into a separate delivery folder to preserve the source')
    folder.mkdir(parents=True, exist_ok=True)
    filename = f'{destination}-{code}-{uuid.uuid4().hex[:8]}.mp4'
    output = folder/filename
    result = subprocess.run(export_cmd(source, output, destination, framing=framing, duration=duration),
                            capture_output=True, text=True, timeout=max(300, int(float(duration)*20)))
    if result.returncode:
        raise RuntimeError('Destination export failed: '+result.stderr[-700:])
    if output.stat().st_size > profile['max_bytes']:
        raise ValueError('Export exceeds this destination recipe file-size ceiling')
    from .render.ffmpeg_renderer import _probe_av_durations
    measured = _probe_av_durations(str(output))
    if measured.get('video') and abs(float(measured['video'])-float(duration)) > max(.5,float(duration)*.02):
        raise RuntimeError('Delivery video duration changed; review before release')
    release_path = folder/(output.stem+'.release.json')
    packet_path = _upload_packet_path(release_path)
    record = {'schema_version':1, 'id':output.stem, 'video':str(output), 'sha256':digest(output),
              'source_sha256':digest(source), 'destination':destination, 'language':code,
              'title':normalized_title, 'post_metadata':post_metadata,
              'profile':profile, 'duration':duration, 'state':'REVIEW_REQUIRED',
              'account_id':'', 'made_for_kids':None, 'ai_disclosure_required':None,
              'rights_confirmed':False, 'facts_reviewed':False, 'language_reviewed':False,
              'publishing_adapter':'manual-export', 'remote_id':None,
              'upload_packet':str(packet_path)}
    save(release_path, record)
    _write_upload_packet(record, release_path)
    return record


def approve_release(path, *, account_id, rights_confirmed=False, facts_reviewed=False,
                    language_reviewed=False, made_for_kids=None, ai_disclosure_required=None):
    record = read(path)
    if not record or digest(record['video']) != record['sha256']:
        raise ValueError('Delivery file is missing or changed; review the current render')
    if not str(account_id).strip() or not all(x is True for x in (rights_confirmed,facts_reviewed,language_reviewed)):
        raise ValueError('Select the exact account and approve rights, factual/story and language review')
    if type(made_for_kids) is not bool or type(ai_disclosure_required) is not bool:
        raise ValueError('Set intended kids audience and AI disclosure choices explicitly')
    metadata = record.get('post_metadata') or {}
    if not isinstance(metadata, dict):
        raise ValueError('Delivery post metadata must be a JSON object')
    normalized, title = _normalize_post_metadata(
        title=record.get('title', ''), caption=metadata.get('caption', ''),
        description=metadata.get('description', ''), hashtags=metadata.get('hashtags', []),
        chapters=metadata.get('chapters', ''), source_urls=metadata.get('source_urls', []),
        category=metadata.get('category', ''))
    record.update(title=title, post_metadata=normalized, account_id=str(account_id).strip(),
                  rights_confirmed=True, facts_reviewed=True, language_reviewed=True,
                  made_for_kids=made_for_kids, ai_disclosure_required=ai_disclosure_required,
                  state='APPROVED_FOR_MANUAL_UPLOAD')
    record['approval_sha256'] = _approval_fingerprint(record)
    _write_upload_packet(record, path)
    return record


def schedule_release(path, publish_at):
    from datetime import datetime, timezone
    record = read(path)
    approved = bool(
        record and record.get('state') == 'APPROVED_FOR_MANUAL_UPLOAD'
        and digest(record['video']) == record['sha256']
        and record.get('approval_sha256') == _approval_fingerprint(record)
        and _upload_packet_is_unchanged(record, path)
    )
    if not approved:
        raise ValueError('Video or post metadata changed after approval; re-review this exact delivery')
    when = datetime.fromisoformat(str(publish_at))
    if when.tzinfo is None or when <= datetime.now(timezone.utc):
        raise ValueError('Use a future timezone-aware ISO timestamp')
    record.update(state='SCHEDULED_MANUAL_REMINDER',publish_at=when.isoformat(),
                  notice='Local reminder only. No social API upload is configured or submitted.')
    _write_upload_packet(record, path)
    return record


def import_metrics(path, rows):
    """User-exported owned-account metrics; preserve platform definitions/denominators."""
    if not isinstance(rows,list) or len(rows)>10000:
        raise ValueError('Import at most 10000 metric rows')
    for row in rows:
        if not isinstance(row,dict) or not all(row.get(k) for k in ('account_id','destination','language','post_id','measured_at')):
            raise ValueError('Each metric row needs its account, platform, language, post ID and measurement date')
        destination_profile(row['destination']);language_pack(row['language'])
        metrics=row.get('metrics')
        if not isinstance(metrics,dict) or not metrics:
            raise ValueError('Use named native metrics; do not infer competitor retention from view counts')
        if any(type(v) not in (int,float) or not math.isfinite(v) or v<0 for v in metrics.values()):
            raise ValueError('Metric values must be finite nonnegative numbers')
    save(path,{'schema_version':1,'source':'user-exported-owned-account-metrics','rows':rows})
    return {'rows':len(rows),'source':'manual-owned-account-export'}

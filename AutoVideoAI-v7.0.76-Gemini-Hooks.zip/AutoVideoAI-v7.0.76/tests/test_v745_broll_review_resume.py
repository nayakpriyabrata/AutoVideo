import hashlib
import json
import os

import pytest


def _saved_review(tmp_path):
    from engine.broll import sha256_file

    source = tmp_path / "source.mp4"
    clip = tmp_path / "highlight.mp4"
    source.write_bytes(b"source-video-bytes")
    clip.write_bytes(b"rendered-highlight-bytes")
    result = {
        "source": str(source),
        "selection_report": "stable-selection-report",
        "highlights": [{"output": str(clip), "duration": 30.0}],
    }
    run_key = hashlib.sha256(result["selection_report"].encode()).hexdigest()[:12]
    path = tmp_path / f"broll-review-{run_key}.json"
    path.write_text(json.dumps({
        "schema_version": 1,
        "workflow": "clip_studio",
        "review_id": "saved-review",
        "candidates": [{
            "candidate_id": "clip_01_cut_01",
            "source_video": str(source.resolve()),
            "source_video_sha256": sha256_file(source),
            "clip_output": str(clip.resolve()),
            "clip_output_sha256": sha256_file(clip),
            "status": "ready",
            "decision": "approved",
            "approved": True,
            "rights_reviewed": True,
            "path": str(tmp_path / "candidate.mp4"),
            "sha256": "candidate-hash",
        }],
    }), encoding="utf-8")
    return result, path, clip


def test_saved_highlights_reopen_the_exact_existing_review(tmp_path, monkeypatch):
    import engine.broll as broll

    result, review_path, _ = _saved_review(tmp_path)
    monkeypatch.setattr(broll, "prepare_review",
                        lambda *a, **k: pytest.fail("must not search or replace an exact saved review"))
    path, review = broll.prepare_clip_studio_review(result, max_candidates=30,
                                                     default_duration=2.0, per_clip=True)
    assert os.path.realpath(path) == os.path.realpath(review_path)
    assert review["_resumed_existing_review"] is True
    assert review["candidates"][0]["decision"] == "approved"


def test_changed_highlight_cannot_reuse_old_review(tmp_path):
    from engine.broll import prepare_clip_studio_review

    result, _, clip = _saved_review(tmp_path)
    clip.write_bytes(b"changed-highlight-bytes")
    with pytest.raises(FileExistsError, match="different or changed highlight files"):
        prepare_clip_studio_review(result, max_candidates=30,
                                   default_duration=2.0, per_clip=True)

import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from PIL import Image
from engine import flow_reviewed_legacy as legacy
from engine.providers.flow_browser import FlowBrowserProvider


def recorded():
    return json.loads((Path(__file__).parent/'fixtures/debanshi_shot004_reviewed.json').read_text())


def test_recorded_request_qualifies_without_fuzzy_matching():
    r=recorded()
    assert legacy.reviewed_legacy_prompt(r)==legacy.REVIEWED_PROMPT
    r['submitted_prompt']+=' remaining original identity text'
    assert legacy.reviewed_legacy_prompt(r)==legacy.REVIEWED_PROMPT


@pytest.mark.parametrize('field,value',[
    ('kind','video'),('status','downloaded'),('request_hash','a'*64),
    ('project_url','https://flow.google.com/project/other'),('request_marker','AVREQ_'+'a'*24),
    ('submitted_prompt','changed'),('request_marker_context_sha256','a'*64),
    ('prompt_candidate_evidence',[{'prompt':'STORYBOARD OPEN FRAME, sharing scripts'}]),
])
def test_changed_or_other_requests_never_qualify(field,value):
    r=recorded();r[field]=value
    assert legacy.reviewed_legacy_prompt(r) is None


def test_live_prompt_recheck_excludes_open_and_other_scene():
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider);r=recorded()
    r['verified_prompt_binding']=provider._make_prompt_binding(r,legacy.REVIEWED_PROMPT,'reviewed_support_report')
    r['baseline']=['exact']
    prompts={'open':legacy.REVIEWED_PROMPT.replace('CLOSE FRAME','OPEN FRAME'),
             'other':legacy.REVIEWED_PROMPT.replace('sharing scripts','creating a cloud project'),
             'exact':legacy.REVIEWED_PROMPT}
    bridge=NS(media_assets=lambda:[{'sig':s,'kind':'image'} for s in prompts],
              read_asset_generation_prompt=prompts.get)
    assert provider._identify_single_fresh_asset(bridge,r,'image',0)=='exact'
    prompts.pop('exact')
    assert provider._identify_single_fresh_asset(bridge,r,'image',0)==''


def test_resume_auto_binds_backs_up_and_downloads_without_generation(tmp_path,monkeypatch):
    provider=FlowBrowserProvider.__new__(FlowBrowserProvider);r=recorded();r['baseline']=[]
    compiled={'prompt':'controlled closing-frame fixture','flow_image_signature_wait_ms':0}
    key=hashlib.sha256(json.dumps(['image','shot_004',compiled['prompt'],True],sort_keys=True).encode()).hexdigest()
    # Exercise the real adapter with a reproducible computed key; the recorded
    # production-key guard is independently verified by the tests above.
    monkeypatch.setattr(legacy,'REQUEST_HASH',key)
    r['request_hash']=key;r['request_marker']='AVREQ_'+key[:24]
    r['submitted_prompt']=r['submitted_prompt'].replace('AVREQ_8acbc45b41414e6431dfdac9',r['request_marker'])
    monkeypatch.setattr(legacy,'SUBMITTED_PREFIX_SHA256',hashlib.sha256(r['submitted_prompt'][:4000].encode()).hexdigest())
    out=str(tmp_path/'shot_004_close.jpg');provider._save_request(out,r)
    original=Path(out+'.flow-request.json').read_bytes();downloads=[]
    def download(*args,**kw):
        downloads.append(kw['preferred_signature']);Image.new('RGB',(200,300),'blue').save(out)
    bridge=NS(ensure_project=lambda *a,**kw:None,
        media_assets=lambda:[{'sig':'exact','kind':'image'},{'sig':'wrong','kind':'image'}],
        read_asset_generation_prompt=lambda sig:legacy.REVIEWED_PROMPT if sig=='exact' else 'other scene',
        download_latest_asset=download)
    provider._ensure=lambda:bridge
    provider._generate_image_once=lambda *a,**kw:pytest.fail('No new generation permitted')
    result=provider._guarded_generation_once(NS(shot_id='shot_004'),compiled,None,out,True,False,'image')
    assert downloads==['exact'] and result['credits']==0
    assert Path(out+'.flow-request.json.before-reviewed-binding.json').read_bytes()==original
    saved=json.loads(Path(out+'.flow-request.json').read_text())
    assert saved['status']=='downloaded'
    assert provider._bound_recovery_prompt(saved)==legacy.REVIEWED_PROMPT

# AutoVideoAI v7 — research and product plan

**Research snapshot:** 4 October 2026 (Asia/Kolkata). Product recommendations below are not predictions of virality, professional financial/medical advice, or legal advice. Platform interfaces, model access, prices, limits and terms can change; use the current native upload screen and the linked official docs before each release.

## Executive recommendation

Build a small, trusted multilingual content studio—not an unattended “viral video” factory. Use RSS and search trends to discover questions, not copy scripts. Verify claims, add an Odisha/local creator perspective, write naturally in English/Hindi/Odia, and make the final video meaningfully original through demonstrations, experiments, narrative, drawings, characters or expertise. Export clean destination copies; let a person make the final rights, audience, disclosure and account decisions.

**v7 delivers the next practical stage:** Factozone RSS in Mini Reels, category-specific editorial guardrails, Indic-safe metadata, a separate destination export, a manual upload packet, and an approval fingerprint. It does **not** publish to any social account. The prior v6 ZIP is a separate release and is not changed by this plan.

### Suggested initial channel portfolio

Do not launch every topic in every format at once. Pilot two connected but clearly branded pillars:

1. **Useful creator/learning videos:** practical AI and content workflows, small explainers, personality skills and tested productivity habits. Show the workflow or result, not just a list of AI-generated claims.
2. **Odisha-relevant everyday knowledge:** home gardening/farming, cooking and local seasonal ideas. Localize by district, crop, season, soil, climate, ingredients or household context; state what was actually tested.

Treat **children’s stories/original cartoons** as a separate series and audience decision. Keep it separate from investment, health and adult self-development uploads. Add devotional/cultural stories only with respectful pronunciation and clear distinction between belief, regional tradition and independently verified history. Investment and health can be occasional, carefully sourced explainers—not generic daily advice.

These are strategic hypotheses for a pilot, not claims that the topics are currently the most popular.

## 1. What the current tool provides and where v7 improves it

| Workflow | v6 baseline | v7 delivered or boundary |
|---|---|---|
| Discovery | Google Trends RSS, RSS/source inbox and visible Gemini Web drafting | Factozone (`factozone.com`, not `factzone.com`) is added to the Mini Reels feed picker beside TechniVella and other curated sources. Feed text is unverified inspiration only. Google search trends are not social-platform virality data. |
| Content range | English/Hindi/Odia settings, approved source/script imports, categories in broader studio paths | Mini Reels adds a visible category selector and category-specific prompt guidance for the full list below. A prompt guardrail is not a source checker. |
| Short video | Existing eight-second one-shot Mini Reels and a separate multi-scene reels workflow | Keep the eight-second Flow clip for visual micro-stories and concepts, not full tutorials. Use the existing multi-scene workflow for explainers and stories. |
| Long video | Existing storyboard, narration, render and long-form planning paths | Continue to plan evidence, examples, chapters, native-language narration and varied visuals. This version does not add autonomous research or a long-form source-verification agent. |
| Delivery | Destination encoding and local review | Export MP4 + JSON + copy/paste metadata packet; add an approval fingerprint over the exact video/copy/account/review. Local reminders only; no account publishing. |
| Learning | User-imported owned-account metrics | Keep native metric names and platform denominators. Cross-platform “viral score,” competitor scraping and automatic analytics downloads remain out of scope. |

### Supported editorial categories

The v7 Mini Reels selector covers **AI & content creation; learning & explainers; self-care & wellbeing; personality development; investment & money education; health & fitness; cooking & food; business ideas; motivation; devotional & cultural stories; original cartoons; kids’ stories; farming & gardening; and general/other.** General/other can host carefully sourced experiments in pets, local history, travel, science, environment, sports and consumer literacy; promote a new selector only after the creator has a distinct repeatable angle and a qualified reviewer where needed.

Use each category as a reminder to do the right editorial work:

| Category | Distinctive treatment | Extra review before upload |
|---|---|---|
| AI / creator tools | Demonstrate one workflow and its limits; compare results honestly | Verify current feature, price, access and regional availability; separate consumer credit from API billing |
| Learning / explainers | One question, one mental model, one concrete example | Source the factual claim; explain uncertainty and avoid false precision |
| Self-care / personality / motivation | A practical, humane exercise or a real, consented experience | No fabricated psychology, shame, diagnosis, guaranteed transformation or crisis advice |
| Investment / money | General concepts, risk, time horizon and competing outcomes | No personalized buy/sell calls, guaranteed return, invented performance or implied certification; have a qualified reviewer for consequential material |
| Health / fitness | Safe, general, evidence-aware demonstrations with modifications | Qualified/official source, contraindications and scope; do not diagnose or promise a cure |
| Cooking / food | Original recipe test, local technique or clear substitution | Test the instructions if calling them tested; verify food-safety and allergen cautions |
| Business ideas | Show a tiny customer-validation test and explicit assumptions | Label cost/revenue/demand as local estimates, not guaranteed income |
| Devotional / culture | Respectful storytelling in the language and tradition | Check names, pronunciation, attribution and community context; separate belief from historical fact |
| Cartoons / kids’ stories | Original characters, readable conflict and satisfying payoff | Clear adaptation rights, age-appropriate language and safety; choose the actual child audience in YouTube Studio |
| Farming / gardening | Local crop/season demonstration, measurement or before/after | Verify region-specific claims with qualified agricultural extension/ICAR/state sources; never invent pesticide dosage, safety or yield |

## 2. Original, multilingual production system

### A. Find a question; do not copy the answer

Use one or more of:

- A user-entered question from comments or real community conversations, with private details removed.
- Google Trends Trending Now/search interest as a **discovery signal**, selecting a country and time window. Google Trends does not measure Instagram/Facebook/YouTube recommendation demand.
- TechniVella or Factozone RSS titles/excerpts as topic leads. The feed is not a verified fact set, permission grant or substitute for reading the publisher’s page.
- Primary sources: official public agencies, original studies, established educational sources and qualified local experts.
- An original experiment or demonstration the creator actually performed.

The current Mini Reels source picker reads a bounded RSS feed, not the entire article or its media. Preserve the source URL and retrieval date where useful; independently verify each substantive fact and create original narration/visuals. Do not reuse site images, footage, article wording or another creator’s distinctive presentation without permission.

### B. Refine with several roles—but keep a human fact gate

A useful model-assisted workflow is:

1. **Researcher:** propose several angles and list claims requiring evidence; do not invent citations.
2. **Producer:** select one specific viewer question and create a hook, story/lesson beats, demonstration and ending.
3. **Skeptical editor:** mark unsupported, misleading, overstated, unsafe or repetitive lines; suggest what evidence would resolve each.
4. **Localization editor:** rewrite—not literally translate—the approved idea in Odia, Hindi or English. Keep a glossary for names, local units and technical terms. A fluent human checks it aloud.
5. **Visual director:** map each spoken beat to a distinct shot, diagram, demonstration, original character action or licensed asset. Reuse a series style bible, not the same generic stock montage.
6. **Publisher:** check rights, audience, metadata, cover/crop, captions, disclosure and account in the destination app.

Gemini, ChatGPT, Grok, local Ollama models and other tools can assist when their current terms, access, price and output rights suit the job. Compare them with the same source pack and ask them to identify uncertainty; do not mistake agreement between models for verification. Keep confidential, personal, unpublished or licensed source material out of a service unless its privacy and retention terms permit it.

**Prompt skeleton for manual model comparison:**

> Make three distinct, original video angles for [audience] in [language/region] about [question]. Use only the facts and source notes I provide; do not invent facts, quotations, prices, medical/financial advice, or citations. For each angle list: the viewer problem, original hook, claim-by-claim evidence still needed, what is uncertain, a 30–45 second short outline, a possible long-form expansion, and a visual demonstration we can actually create. Do not imitate a named creator, channel, studio, copyrighted character, article wording or trend template. Localize idioms and units rather than translating literally. Finish with a self-critique for safety, source quality, originality and repetition. Leave unsupported claims marked `[VERIFY]` rather than filling them in.

### C. Separate formats and promises

| Format | Suggested editorial shape | Design and review |
|---|---|---|
| Short vertical explainer (pilot range 25–60 sec) | Hook → one question → 2–4 clear beats/demo → useful payoff → modest CTA | 9:16, readable safe-zone text, captions reviewed against actual speech; remove dead air without making narration frantic |
| Eight-second Mini Reels | One instantly readable visual action with a clear beginning and ending | Use only for a visual micro-story, gag or product/idea teaser. Do not imply it explains nuanced health/finance or a full recipe |
| YouTube long-form pilot (often 6–8 min if justified) | Promise → context/evidence → examples/demo → counterpoint/limits → conclusion → chapters | 16:9; purposeful shot changes; meaningful original commentary; citations in description where appropriate |
| Original cartoon/kids’ story | Character goal → understandable obstacle → safe choice → emotional payoff | Keep characters original and consistent. Set audience based on actual intended audience, not merely “family friendly” visuals |

These are **starting editorial recipes**, not platform limits or guaranteed retention tactics. For vertical distribution, render a clean master and make each destination copy from that master. Adjust the cover crop, description and CTA per platform. Do not repeatedly download/recompress a social post as the next platform’s source. Use music only where the licence covers the destination, territory and monetization; an in-app track licence may not transfer across apps.

## 3. Language and quality assurance

English, Hindi and Odia are supported configuration targets; support in code is not proof that every generated voice, model or OCR tool performs equally well in all three.

- Create the first script in the language the creator can review fluently; localize the *idea and examples*, not just the sentence order.
- Use a native speaker for Odia/Hindi spelling, tone, pronunciation, code-switching and social nuance. Review the full audio, not just a transcript.
- Verify Indic shaping, matras/combining marks, line wrapping and subtitle contrast on a phone. Keep font licences with the release.
- Avoid fake urgency, shame, stereotypes, fabricated expert identities and invented testimonials.
- Preserve a claim/evidence ledger: exact claim, source URL and access date, evidence excerpt or page, reviewer, remaining uncertainty, and whether the claim is still publishable.
- Check video rights for each shot, reference image, character, B-roll, music bed, sound effect, font and voice. A generated result can still resemble protected material or a real person.
- For health, children, finance and farming, use the more conservative source/reviewer requirements in the category table. Prompt text alone cannot make high-stakes advice safe.

## 4. Platform facts and constraints (checked against primary docs)

**API rules are not the same as native-app rules or creative recommendations.** Check the current docs before implementing an API, and check the actual upload screen before a manual release.

### Instagram Reels

Meta’s [Instagram Content Publishing API guide](https://developers.facebook.com/documentation/instagram-platform/content-publishing) covers professional-account publishing with the applicable login setup, access tokens, permissions, media containers and a publish call. The reviewed documentation states a rolling 100 API-published posts per 24 hours. This does not mean a new AutoVideoAI installation can immediately publish: app review, account type, access and permissions matter. v7 exports a file only and performs no OAuth flow.

### Facebook Reels

The [Reels Publishing API guide](https://developers.facebook.com/documentation/video-api/guides/reels-publishing/) describes Page publishing with a Page access token and upload-then-publish flow. Its documented Reel profile is 3–90 seconds, vertical 9:16, 1080×1920 recommended (540×960 minimum), MP4 recommended, with a rolling 30 API-published-Reels-per-24-hour limit. This is why v7’s Facebook export recipe is 3–90 seconds; it is explicitly an API-oriented app recipe, not a universal statement about all Facebook surfaces. The user still publishes through Facebook unless a separately authorized integration is built.

### YouTube Shorts and long-form

YouTube’s [Shorts eligibility guidance](https://support.google.com/youtube/answer/15424877?hl=en) documents square/vertical Shorts up to three minutes for standard channels under the applicable upload-date rules. The same guidance warns an active Content ID claim on a Short longer than one minute can block it globally. Use cleared music and inspect upload checks. YouTube’s [encoding recommendations](https://support.google.com/youtube/answer/1722171?hl=en) include MP4/H.264 and 48 kHz audio guidance. A horizontal 16:9 master remains useful for conventional long-form tutorials.

Publishing with the [YouTube Data API](https://developers.google.com/youtube/v3/guides/uploading_a_video) requires an OAuth-authorized upload flow and registered application. The local packet is not an API client. The [made-for-kids guide](https://support.google.com/youtube/answer/9528076?hl=en) puts the audience decision on the creator; general family-friendliness alone does not decide it. The [altered/synthetic content policy](https://support.google.com/youtube/answer/14328491?hl=en) requires disclosure for certain realistic or meaningfully altered/generated content; review its examples and set the native upload field correctly.

### Originality and monetization

YouTube’s [channel monetization policy](https://support.google.com/youtube/answer/1311392?hl=en) clarifies that repetitive, mass-produced or inauthentic content may be ineligible. Meta’s March 2026 [original-content guidance](https://about.fb.com/news/2026/03/rewarding-original-creators-on-facebook/) says creator-produced material and third-party material with substantial new information/analysis can qualify as original, while minor edits/re-uploads may be deprioritized. Neither platform promises reach or earnings for following a checklist. Put the creator’s knowledge, performance, demonstration, analysis or original story at the center.

## 5. Cost and provider choices, including free paths

“Free” can mean no subscription, an expiring allowance, local compute, free assets under conditions, or a free user interface with no automation/API rights. Recheck limits and terms when producing; credit amounts, regions and offers change.

| Need | Lower-cost starting option | Paid/advanced option | Important boundary |
|---|---|---|---|
| Topic discovery | Manual question list; Google Trends Trending Now export/RSS; curated publisher RSS | Paid research/data services if they offer permitted, reliable APIs | Search interest is not short-video virality. Publisher RSS is not a reuse licence. |
| Script drafts and localization | Manual Gemini/ChatGPT/Grok user-facing tiers where available; local Ollama on capable hardware | Gemini/OpenAI/xAI/Groq API routes already represented in the project configuration, subject to current account/model billing | Consumer subscriptions and API billing are separate. Check the exact model, limits, privacy and output terms. A human must verify facts and Odia/Hindi fluency. |
| Model comparison | Compare 2–3 permitted services manually using the same evidence pack | Supported provider APIs through explicit credentials | Arena’s [Max announcement](https://arena.ai/blog/introducing-max) describes a model router in Direct Chat, not a general AutoVideoAI backend. The [Arena Terms](https://help.arena.ai/articles/5629909088-terms-of-use), reviewed on this date, include restrictions relevant to programmatic access and commercial exploitation. Do not automate Arena or use its output for monetized production unless the current terms and a separate permission clearly allow it. |
| Video generation | Google Flow’s consumer interface when the account has available credits; free/manual alternatives in Meta/YouTube product surfaces where available | Paid Flow plans or Gemini API video generation, with distinct entitlements/pricing | Google’s [Flow credits help](https://support.google.com/flow/answer/16526234?hl=en) described 50 daily credits for subscribers and non-subscribers at this snapshot, but non-subscribers may be unable to generate at peak time and model costs/availability vary. This is not a guaranteed quota or API allowance. |
| Meta creative tools | Meta AI/Vibes consumer create/edit/remix features where enabled | Use only a separately documented, authorized API if one becomes available | Meta [Vibes](https://ai.meta.com/meta-ai/vibes/) describes a consumer workflow. The reviewed product page did not establish a general public video-generation API for this app. Do not infer API access from a website feature. |
| Stock footage / sound | Existing Pexels/Pixabay workflows or assets the creator made | Paid stock, commissioned music/voice | Verify each specific licence, attribution, territory, monetization and platform permission. An API key does not grant asset rights. |
| Editing/render | AutoVideoAI + FFmpeg, plus free/open-source editors such as Kdenlive or Shotcut | Commercial editors, paid templates or commissioned work | Local rendering avoids per-generation fees but still costs hardware, storage, time, electricity and licensed assets. Verify codec, language support and project licence. |
| Social publishing | Native Instagram, Facebook and YouTube upload screens | Authorized official APIs with OAuth, app review and permissions | Do not store social passwords or automate consumer pages as a workaround. API eligibility and app review are separate from export capability. |

The [ChatGPT Plus help page](https://help.openai.com/en/articles/6950777-what-is-chatgpt-plus) currently lists its subscription price separately from API billing; features and regional pricing may change. Do not compare a subscription with video-generation credits as if they were equivalent. Before committing spend, generate one short sample, inspect it, then compare cost per **accepted** scene—not cost per prompt submitted. For Flow, explicitly check the account’s credits before each paid generation.

## 6. Product roadmap: feasible, safety-first increments

| Priority | Enhancement | Acceptance test / why it is next |
|---|---|---|
| **Done — v7.0.0** | Factozone + TechniVella Mini Reels discovery; category-specific prompt guardrails; Indic-safe metadata; destination packet; content/video/account/review fingerprint; Facebook Reels 3–90 second API-oriented recipe | Offline tests verify allowlisted feed parsing, category prompt injection, public HTTPS source URL handling, separate exports, Indic hashtags, packet hash and approval invalidation. No live credit or account publishing is required. |
| **P1** | Reusable episode brief and claim ledger with provenance, retrieved date, reviewer and publish/omit state | Import/export versioned JSON; reject unapproved high-impact claims; every script beat can point to its evidence; no invented citations. |
| **P1** | Native-language localization worksheet and reviewer sign-off | Keep a common approved fact set, separate `en/hi/or` script files, spelling/pronunciation glossary, reviewer name/status, captions and measured audio; never overwrite the original-language script. |
| **P1** | Category/topic research scorecard and series planner | Human scores audience need, source quality, original contribution, local relevance, production cost/credits and risk. Store score rationale; do not pretend it is a social algorithm. |
| **P2** | Visual series bible and shot/asset provenance | Pin authorized character/style references, asset licences and scene hashes; flag repeated scenes and near-identical scripts without rejecting legitimate series automatically. |
| **P2** | Platform-aware metadata validation and richer package | Separate limits/fields for Instagram, Facebook and YouTube; valid chapter timestamps, thumbnail/cover notes and platform-specific title/caption files; keep one clean master. |
| **P2** | Owned-account analytics import wizard | Import the user's platform export with explicit definitions/date windows; trend by topic/language/format only when denominator and account are comparable; no competitor scraping. |
| **P3** | OAuth publication for a single platform at a time | Only after a reviewed app, encrypted per-user token storage, least-privilege scopes, explicit upload confirmation, idempotency, remote status/retry controls, revoke/delete path, audit trail and a test account are implemented. Keep manual fallback. |
| **P3** | Optional multivariate tests | Predeclare one hypothesis and one primary metric; small randomized or matched tests; show uncertainty and guard against changing several creative variables at once. No “guaranteed winner” label. |

### Minimum test plan for an official publisher integration

Before calling a feature “auto-publish,” test with a private/unlisted test account where allowed, verify OAuth scopes and token expiry, handle large-file/resumable upload, detect duplicate retries, reconcile processing/publishing failures, store remote IDs, redact secrets from logs, permit immediate disconnect, document platform review requirements and ensure a human explicitly confirms the final title/caption/audience/disclosure. This release deliberately stops at a local packet.

## 7. Thirty-day pilot and learning loop

A manageable first experiment is **three short videos per week** across the two selected pillars, with at most one long-form YouTube test every other week. Produce matched ideas in Odia, Hindi and English only when a fluent reviewer and a suitable voice are available; do not publish weak translations just to fill a language quota. Keep a separate schedule/series for children’s cartoons if that audience is chosen.

For each episode, record topic, audience, language, format, hook type, source/evidence status, duration, original demonstration, voice, edit, publish date, platform and exact account. After a consistent window, import native account metrics and keep their original names (for example, average view duration, viewed/swiped, shares, saves, CTR) and definitions. Compare within the same platform and format; do not treat one platform’s “view” as equal to another’s. Use results to decide what to improve, not as evidence that a theme is universally viral.

Change one primary variable in a matched test—such as hook, first shot, language version or runtime. Keep rights, factual quality, native-language fluency and original contribution as non-negotiable constraints. A video with more views is not automatically more useful, trustworthy or monetizable.

## 8. Source register

Primary documentation used for this snapshot:

1. [Instagram Content Publishing API](https://developers.facebook.com/documentation/instagram-platform/content-publishing)
2. [Facebook Reels Publishing API](https://developers.facebook.com/documentation/video-api/guides/reels-publishing/)
3. [Google Flow credits](https://support.google.com/flow/answer/16526234?hl=en)
4. [Google Trends Trending Now](https://support.google.com/trends/answer/3076011?hl=en)
5. [YouTube Shorts eligibility](https://support.google.com/youtube/answer/15424877?hl=en)
6. [YouTube recommended upload encoding](https://support.google.com/youtube/answer/1722171?hl=en)
7. [YouTube made-for-kids setting](https://support.google.com/youtube/answer/9528076?hl=en)
8. [YouTube channel monetization policies](https://support.google.com/youtube/answer/1311392?hl=en)
9. [YouTube Data API resumable/upload guide](https://developers.google.com/youtube/v3/guides/uploading_a_video)
10. [YouTube altered/synthetic-content disclosure](https://support.google.com/youtube/answer/14328491?hl=en)
11. [Meta: Rewarding original creators on Facebook, 13 March 2026](https://about.fb.com/news/2026/03/rewarding-original-creators-on-facebook/)
12. [Meta AI Vibes](https://ai.meta.com/meta-ai/vibes/)
13. [Arena Max](https://arena.ai/blog/introducing-max) and [Arena Terms of Use](https://help.arena.ai/articles/5629909088-terms-of-use)
14. [ChatGPT Plus and separate API billing](https://help.openai.com/en/articles/6950777-what-is-chatgpt-plus)
15. [TechniVella RSS](https://technivella.com/feed/) and [Factozone RSS](https://factozone.com/feed/). Their RSS feeds are topic leads; this research did not establish a licence to reuse article text or media.

Recheck each page and product in its current region before purchase or release. The research date is a snapshot, not a promise that quotas, pricing, terms or interface labels remain the same.

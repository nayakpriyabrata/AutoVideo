from types import SimpleNamespace as NS
import json
from pathlib import Path
import pytest
from engine.providers.flow_browser import FlowBrowser

URL='https://flow.google.com/project/0cd4803d-c8d9-4a60-ae89-329a12f326c2'

class Page:
    def __init__(self):self.url='about:blank';self.closed=False
    def goto(self,*a,**kw):raise RuntimeError('Navigation failed')
    def close(self):self.closed=True
    def is_closed(self):return self.closed

class Context:
    def __init__(self):self.pages=[];self.created=[]
    def new_page(self):
        page=Page();self.pages.append(page);self.created.append(page);return page


def bridge(isolated=False):
    b=FlowBrowser.__new__(FlowBrowser);b._ctx=Context();b._page=Page();b._owns_page=False
    b._guard_page=None;b._project_url=URL;b._isolated_worker=isolated;b._cdp=None;b._own_context=True
    return b


def test_50_failed_recoveries_leave_no_live_blank_tabs():
    b=bridge();old=b._page
    for _ in range(50):assert not b.recover_project_page(URL)
    assert all(p.closed for p in b._ctx.created)
    assert b._page is old and not old.closed


def test_isolated_adoption_and_guard_navigation_failures_close_owned_tabs():
    b=bridge(True);old=b._page
    for _ in range(20):
        assert not b._adopt_live_flow_page(URL)
        assert not b._ensure_project_guard_page(URL)
    assert all(p.closed for p in b._ctx.created)
    assert b._page is old and not old.closed


def test_one_reattach_per_failure_episode_resets_only_after_verified_success(tmp_path,monkeypatch):
    from engine.flow_reference_policy import reserve_reference_reattach,upload_record,reference_upload_attempt
    monkeypatch.chdir(tmp_path);alias='AV_hash_character-debanshi.jpg'
    assert reserve_reference_reattach(URL,alias)
    reference_upload_attempt(URL,alias,record=True)
    assert not reserve_reference_reattach(URL,alias) # sending file alone is not success
    upload_record(URL,alias,record=True) # called only after verified composer chip
    assert reserve_reference_reattach(URL,alias)
    assert not reserve_reference_reattach(URL,alias)
    assert reserve_reference_reattach(URL,'AV_other_location.jpg')


def test_legacy_exhausted_reservation_gets_one_remediation(tmp_path,monkeypatch):
    from engine.flow_reference_policy import reserve_reference_reattach
    import hashlib
    monkeypatch.chdir(tmp_path);root=Path('data/flow_media_uploads/upload_registry');root.mkdir(parents=True)
    file=root/(hashlib.sha256(URL.encode()).hexdigest()+'.reattach.json')
    file.write_text(json.dumps({'alias':{'protocol':3}}))
    assert reserve_reference_reattach(URL,'alias')
    assert not reserve_reference_reattach(URL,'alias')


def test_upload_photo_filename_is_short_with_original_hash_directory(tmp_path):
    from engine.flow_upload_media import prepare_reference
    from engine.production import digest
    from PIL import Image
    source=tmp_path/'character-debanshi-8e9b31ff-0.jpg';Image.new('RGB',(32,32),'red').save(source)
    original=digest(source)
    ready=Path(prepare_reference(source,root=tmp_path/'prepared'))
    assert ready.parent.name==original and ready.name==source.name
    alias=FlowBrowser._media_upload_alias(str(ready))
    assert len(alias)<65 and alias.startswith('AV_') and digest(source)==original


def test_startup_prunes_only_owned_restored_blanks():
    b=bridge();b._ctx.pages=[Page() for _ in range(50)]
    flow=Page();flow.url=URL;b._ctx.pages.append(flow)
    other=Page();other.url='https://example.com/';b._ctx.pages.append(other)
    b._prune_owned_blank_tabs()
    assert b._page is flow and all(p.closed for p in b._ctx.pages[:50])
    assert not flow.closed and not other.closed
    b=bridge();b._own_context=False;b._ctx.pages=[Page() for _ in range(10)]
    b._prune_owned_blank_tabs();assert not any(p.closed for p in b._ctx.pages)

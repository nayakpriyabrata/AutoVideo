import json
import threading
from pathlib import Path
from types import SimpleNamespace
import pytest
from PIL import Image
from engine import job_monitor, flow_music
from engine.production import save, digest
from engine.production_lock import production_slot
from engine.content_library import CharacterLibrary


def test_monitor_reattaches_without_restarting_job(tmp_path):
    entered=threading.Event();finish=threading.Event();calls=[]
    def run(job, **kwargs):
        with production_slot(tmp_path):
            calls.append(job);entered.set();finish.wait(5)
            return {'status':'done'}
    factory=SimpleNamespace(pm=SimpleNamespace(job_dir=lambda job:str(tmp_path)),run_job=run)
    assert job_monitor.start(factory,'job-a')
    assert entered.wait(2)
    try:
        assert job_monitor.snapshot(tmp_path)['running']
        assert not job_monitor.start(factory,'job-a')
        assert calls==['job-a']
    finally:
        finish.set();job_monitor._tasks[str(tmp_path.resolve())]['thread'].join(2)
    assert job_monitor.snapshot(tmp_path)['result']['status']=='done'
    assert not job_monitor.snapshot(tmp_path)['running']


def test_monitor_reads_bounded_log_tail_and_corrupt_progress(tmp_path):
    (tmp_path/'logs').mkdir()
    (tmp_path/'logs/runtime.log').write_text('first\n'+'log\n'*10000+'last\n')
    (tmp_path/'logs/progress.json').write_text('{')
    view=job_monitor.snapshot(tmp_path)
    assert len(view['logs'])==40 and view['logs'][-1]=='last'
    assert view['progress']=={}


def test_character_update_and_delete_preserve_old_job_references(tmp_path):
    old=tmp_path/'old.png';new=tmp_path/'new.png'
    Image.new('RGB',(80,80),'red').save(old);Image.new('RGB',(80,80),'blue').save(new)
    library=CharacterLibrary(tmp_path/'characters')
    character=library.create('Aanya','A cheerful fictional host with a yellow jacket',reference_files=[old],original_confirmed=True)
    saved=character['references'][0]
    updated=library.update(character['id'],'Aanya Updated','A fictional host with a blue shirt and bright eyes',reference_files=[new],voice_style='feminine')
    assert updated['version']==2 and updated['name']=='Aanya Updated'
    assert digest(saved['path'])==saved['sha256']
    library.archive(character['id'])
    assert library.list()==[] and library.get(character['id'])['archived']
    assert digest(saved['path'])==saved['sha256']


def test_key_update_preserves_other_keys_and_never_returns_secret(tmp_path,monkeypatch):
    from engine.key_settings import update_key
    (tmp_path/'.env').write_text("GROQ_API_KEY='old'\n# comment\nPEXELS_API_KEY='preserved'\n")
    monkeypatch.delenv('GROQ_API_KEY',raising=False)
    result=update_key('GROQ_API_KEY','new-secret',tmp_path)
    assert 'new-secret' not in repr(result)
    assert 'preserved' in (tmp_path/'.env').read_text()
    assert (tmp_path/'.env').stat().st_mode & 0o777 == 0o600
    with pytest.raises(ValueError): update_key('GROQ_API_KEY','bad\nkey',tmp_path)
    with pytest.raises(ValueError): update_key('PATH','bad',tmp_path)


def test_music_crash_after_submit_rescans_once_without_generation(tmp_path,monkeypatch):
    journal=tmp_path/'request.json';save(journal,{'state':'draft'})
    calls=[]
    def operation(action,*args):
        calls.append(action)
        if action=='generate':
            save(journal,{'state':'submission-uncertain','session_url':'https://flowmusic.app/session/known'})
            raise RuntimeError('Target page, context or browser has been closed')
        return {'state':'candidates-ready'}
    monkeypatch.setattr(flow_music,'_browser_operation_once',operation)
    assert flow_music.browser_operation('generate',str(journal),True)['state']=='candidates-ready'
    assert calls==['generate','scan']


def test_music_crash_without_session_never_generates_again(tmp_path,monkeypatch):
    journal=tmp_path/'request.json';save(journal,{'state':'submission-uncertain'})
    calls=[]
    def operation(action,*args):
        calls.append(action);raise RuntimeError('Target page, context or browser has been closed')
    monkeypatch.setattr(flow_music,'_browser_operation_once',operation)
    with pytest.raises(RuntimeError,match='No duplicate'):flow_music.browser_operation('generate',str(journal),True)
    assert calls==['generate']


def test_thumbnail_resize_and_signing_do_not_reset_readiness(monkeypatch):
    from tests.test_v609_flow_video_typed_recovery import _Clock, _wait_browser
    from engine.providers import flow_browser
    clock=_Clock();monkeypatch.setattr(flow_browser,'time',clock)
    def assets():
        sig=f'IMG|https://media.test/12345678-1234-1234-1234-123456789abc?X-Goog-Signature={clock.now}|changing label|video|{200+clock.now}|300'
        return [{'sig':sig,'kind':'video'}]
    browser=_wait_browser(clock,assets)
    assert browser.wait_for_agent_generation(before_assets=set(),timeout_s=8,required_kind='video')
    assert clock.now<8


def test_text_logo_is_playable_transparent_image(tmp_path):
    from engine.brand_logo import text_logo
    from engine.clip_branding import validate_clip_logo,prepare_clip_logo
    logo=text_logo('Skill Shift Pro','Ocean',tmp_path/'logos')
    options=validate_clip_logo(True,logo,.25)
    rendered=prepare_clip_logo(options,tmp_path/'work',1080,1920)
    with Image.open(rendered['overlay_path']) as image:
        assert image.mode=='RGBA' and image.getbbox() is not None
    with pytest.raises(ValueError):text_logo('bad\ntext',root=tmp_path)


def test_reuse_only_approved_broll_from_exact_clip_and_snapshot_assets(tmp_path):
    from engine.broll import reuse_clip_review,approved_video_overlays
    clip=tmp_path/'clip.mp4';clip.write_bytes(b'exact-clip')
    other=tmp_path/'other.mp4';other.write_bytes(b'other')
    asset=tmp_path/'stock.mp4';asset.write_bytes(b'approved-asset')
    candidate={'candidate_id':'one','clip_output':str(clip),'clip_output_sha256':digest(clip),
        'path':str(asset),'sha256':digest(asset),'approved':True,'rights_reviewed':True,
        'decision':'approved','start':10,'duration':3}
    review=tmp_path/'review.json';save(review,{'schema_version':1,'workflow':'clip_studio',
        'candidates':[candidate,{**candidate,'candidate_id':'other','clip_output':str(other)}]})
    assert reuse_clip_review(review,clip,tmp_path/'job',30)==1
    overlays=approved_video_overlays(str(tmp_path/'job/render/broll_review.json'),60)
    assert len(overlays)==1 and overlays[0]['start']==20 and overlays[0]['end']==26
    asset.unlink()
    assert Path(overlays[0]['path']).is_file()
    clip.write_bytes(b'changed')
    with pytest.raises(ValueError,match='changed'):reuse_clip_review(review,clip,tmp_path/'second',30)


def test_theme_rerun_can_watch_existing_job_in_queue(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard,navigate
    factory,app=dashboard(tmp_path,monkeypatch)
    job=factory.create_job('A saved production',dry_run=True)
    app.session_state['job_id']=job
    save(Path(factory.pm.job_dir(job))/'logs/progress.json',{'stage':'Downloading exact asset','percent':42,'elapsed':'00:01:00'})
    navigate(app,'QUEUE')
    next(w for w in app.sidebar.selectbox if w.label=='Appearance').set_value('Warm').run()
    assert not app.exception
    assert any(x.value=='Job monitor' for x in app.subheader)
    assert any('Downloading exact asset' in x.value for x in app.markdown)

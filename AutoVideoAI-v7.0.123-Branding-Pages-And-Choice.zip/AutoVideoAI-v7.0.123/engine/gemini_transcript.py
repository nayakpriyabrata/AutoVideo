"""Explicit Gemini Web speech drafts and timestamp-preserving text correction."""
import hashlib
import json
import math
from pathlib import Path
from .local_video_edits import reviewed_words
from .clipping import resolve_input, _duration, _run


def correct_transcript(value, language='or', cleanup='delete-after-read'):
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    from .languages import language_pack
    label=language_pack(language).label
    words=value.get('words') if isinstance(value,dict) else value
    if not isinstance(words,list) or not words:raise ValueError('Correction needs an existing timed word transcript.')
    duration=max(float(w.get('end',0)) for w in words)
    original=reviewed_words(words,duration)
    raw=gemini_web_generate(f'Correct spelling, punctuation and grammatical errors in a {label} speech transcript. '
        'Preserve meaning and every timestamp. Do not add claims, translate, merge or remove words. Return JSON only.',
        'Return {"words":[{"word":"corrected text","start":0.0,"end":0.5}]}. '
        'Keep exactly the same number/order of entries and copy start/end unchanged.\n'+json.dumps(original,ensure_ascii=False),cleanup=cleanup)
    parsed=_extract_json(raw)
    fixed=reviewed_words(parsed,duration)
    if len(fixed)!=len(original) or any((a['start'],a['end'])!=(b['start'],b['end']) for a,b in zip(original,fixed)):
        raise ValueError('Gemini changed word timing or entry count; correction was rejected. No source transcript was overwritten.')
    return {**({k:value[k] for k in ('source_sha256','duration','source_path','original_source') if k in value} if isinstance(value,dict) else {}),'words':fixed,'language':language,'provider':'gemini-web-correction','review_required':True,
            'original_sha256':hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True).encode()).hexdigest()}


def draft_transcript(source, folder='logs/gemini/transcripts', language='or', *, rights_confirmed=False, cleanup='delete-after-read', progress_cb=None):
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    from .languages import language_pack
    pack=language_pack(language);language=pack.code
    root=Path(folder).resolve();root.mkdir(parents=True,exist_ok=True)
    local=resolve_input(source,str(root),rights_confirmed=rights_confirmed,source_rights='private_draft_only')
    total=_duration(local)
    if not 0<total<=3600:raise ValueError('Gemini transcript drafting supports videos up to 60 minutes.')
    from .clipping import _file_sha256
    fingerprint=_file_sha256(local)
    work=root/fingerprint[:20];work.mkdir(exist_ok=True)
    combined=[]
    for i in range(math.ceil(total/300)):
        start=i*300;duration=min(300,total-start);proxy=work/f'audio-video-{i+1:03d}.mp4'
        if progress_cb:progress_cb(f'Transcribing chunk {i+1}/{math.ceil(total/300)}')
        try:
            transfer=_run(['ffmpeg','-y','-ss',str(start),'-t',str(duration),'-i',local,
                '-map','0:v:0','-map','0:a:0','-vf','scale=360:360:force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2,setsar=1,fps=5',
                '-c:v','libx264','-pix_fmt','yuv420p','-b:v','120k','-maxrate','180k','-bufsize','360k','-preset','fast',
                '-c:a','aac','-b:a','64k','-ac','1','-movflags','+faststart',str(proxy)],timeout=max(180,int(duration*3)))
            if transfer.returncode or not proxy.exists():raise ValueError('Could not prepare an audible video proxy. Check that the source contains audio: '+(transfer.stderr or '')[-500:])
            if proxy.stat().st_size>20*1024*1024:raise ValueError('Gemini upload proxy exceeds 20 MB.')
            raw=gemini_web_generate(f'Transcribe audible {pack.label} speech faithfully in its native writing system. '
                'Do not translate, summarize or invent inaudible words. Return JSON only.',
                f'Attached chunk duration: {duration:.3f}s. Use timestamps relative to THIS chunk starting at zero. '
                'Return {"words":[{"word":"spoken word","start":0.2,"end":0.8}]}. '
                'One spoken word per entry, ordered, all times within chunk. Mark uncertainty in review_notes.',
                cleanup=cleanup,attachments=[str(proxy)])
        finally:
            try:proxy.unlink(missing_ok=True)
            except OSError:pass
        (work/f'raw-{i+1:03d}.txt').write_text(raw,encoding='utf-8')
        words=reviewed_words(_extract_json(raw),duration)
        combined.extend({**w,'start':w['start']+start,'end':w['end']+start} for w in words)
    result={'words':reviewed_words(combined,total),'language':language,'provider':'gemini-web-audible-video',
        'source_sha256':fingerprint,'source_path':local,'original_source':source,'duration':total,'review_required':True,
        'notice':'Gemini word timing and spelling are estimates. Review against the source before burning captions.'}
    path=work/'draft.json';path.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    return result


def transcript_controls(st,key,source,language='or',existing=None):
    """Draft/correct then explicitly review; never submit on a page rerun."""
    from .languages import language_pack
    label=language_pack(language).label
    key=key+'-'+hashlib.sha256(str(source).encode()).hexdigest()[:12]
    with st.expander(f'Gemini Web · {label} transcript and correction'):
        st.caption('Uses your signed-in Gemini browser. Drafting uploads an audible video proxy; correction sends the supplied text only. Draft timing/spelling need review. Submitted chats are cleaned up after capture.')
        allowed=st.checkbox('I permit sending this footage/transcript to Gemini for transcription',key=key+'-permit')
        cleanup=st.selectbox('Transcript chat cleanup',['delete-after-read','keep'],key=key+'-cleanup')
        if st.button(f'Draft {label} transcript from video',key=key+'-draft',disabled=not (allowed and source)):
            try:
                with st.spinner('Gemini is listening to an audible proxy…'):
                    draft=draft_transcript(source,language=language,rights_confirmed=True,cleanup=cleanup)
                st.session_state[key+'-draft-value']=draft
                st.session_state[key+'-editor']=json.dumps(draft,indent=2,ensure_ascii=False)
                st.session_state[key+'-approved']=False
            except Exception as error:st.error(str(error))
        value=st.session_state.get(key+'-draft-value') or existing
        if value:
            if st.button(f'Correct {label} wording · keep timestamps',key=key+'-correct',disabled=not allowed):
                try:
                    # Correct the visible edits rather than a stale generated draft.
                    visible=json.loads(st.session_state.get(key+'-editor') or json.dumps(value))
                    with st.spinner(f'Correcting {label} text…'):fixed=correct_transcript(visible,language,cleanup)
                    st.session_state[key+'-draft-value']=fixed
                    st.session_state[key+'-editor']=json.dumps(fixed,indent=2,ensure_ascii=False)
                    st.session_state[key+'-approved']=False
                except Exception as error:st.error(str(error))
            text=st.text_area('Review timed transcript JSON',value=json.dumps(value,indent=2,ensure_ascii=False),key=key+'-editor',height=220)
            st.download_button('Download transcript draft',text,file_name=language+'-transcript.json',key=key+'-download')
            approved=st.checkbox('I reviewed these words and timestamps against this video',key=key+'-approved-'+hashlib.sha256(text.encode()).hexdigest()[:12])
            if approved:
                try:
                    parsed=json.loads(text)
                    if parsed.get('source_sha256') and Path(source).is_file():
                        from .clipping import _file_sha256
                        if _file_sha256(source)!=parsed['source_sha256']:raise ValueError('Source video changed; draft or review its new transcript.')
                    # Draft/source binding is retained when available. Local editor
                    # also revalidates every timestamp against the actual duration.
                    return {**parsed,'review_required':False}
                except Exception as error:st.error('Invalid transcript JSON: '+str(error))
    return None

"""Save an exact UI blob anchor before its click can close the download target.

Only a blob URL on the existing Flow page is intercepted. No private endpoint,
credential copying, media-gallery guessing, or new generation is involved.
"""
import base64,os,secrets,tempfile,time
from pathlib import Path
SCRIPT=r'''({name,key,limit})=>{
 const state={active:true};window[key]=state;
 const handler=async(event)=>{
  const a=event.target.closest?.('a[download],a[href^="blob:"]');
  if(!state.active||!a||!a.href.startsWith('blob:'+location.origin+'/'))return;
  event.preventDefault();event.stopImmediatePropagation();state.active=false;
  document.removeEventListener('click',handler,true);
  try{
   const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),30000);
   try{
    const response=await fetch(a.href,{signal:controller.signal});
    if(!response.ok)throw Error('blob unavailable');
    const reader=response.body.getReader();let total=0,index=0;
    while(true){const {done,value}=await reader.read();if(done)break;
     total+=value.length;if(total>limit){await reader.cancel();throw Error('size limit');}
     let binary='';for(let i=0;i<value.length;i+=8192)binary+=String.fromCharCode(...value.subarray(i,i+8192));
     if(await window[name]({index:index++,data:btoa(binary)})!==true)throw Error('capture rejected');
    }
    if(await window[name]({done:true,bytes:total})!==true)throw Error('validation failed');
   }finally{clearTimeout(timer);}
  }catch(error){await window[name]({error:'Exact UI blob capture failed'});try{a.click();}catch{}}
 };
 state.remove=()=>{state.active=false;document.removeEventListener('click',handler,true);delete window[key];};
 document.addEventListener('click',handler,true);
}'''
class Capture:
    def __init__(self,page,output,validator):
        self.page=page;self.output=str(output);self.validator=validator;self.done=False;self.error='';self.size=0;self.index=0;self.active=True;self.started=time.monotonic()
        self.limit=128*1024*1024;self.key='avblob_'+secrets.token_hex(8);self.name=self.key+'_write'
        self.messages=0;self.foreign=0;self.reported=False
        parent=Path(output).resolve().parent;parent.mkdir(parents=True,exist_ok=True)
        fd,self.stage=tempfile.mkstemp(dir=parent,prefix='.flow-ui-',suffix=Path(output).suffix);self.handle=os.fdopen(fd,'wb')
    def receive(self,source,message):
        if not self.active:return False
        self.messages+=1
        if source.get('page')!=self.page:
            self.foreign+=1;self.error=self.error or 'source_page_mismatch';return False
        try:
            if time.monotonic()-self.started>120:raise ValueError('Capture deadline')
            if message.get('error'):raise ValueError(message['error'])
            if message.get('done'):
                if message.get('bytes')!=self.size or self.size==0:raise ValueError('Incomplete blob')
                self.handle.flush();self.handle.close()
                if not self.validator(self.stage):raise ValueError('Invalid media bytes')
                os.replace(self.stage,self.output);self.done=True;self.active=False;return True
            if message.get('index')!=self.index:raise ValueError('Out-of-order chunk')
            chunk=base64.b64decode(message['data'],validate=True)
            if len(chunk)>4*1024*1024 or self.size+len(chunk)>self.limit:raise ValueError('Capture limit')
            self.handle.write(chunk);self.size+=len(chunk);self.index+=1;return True
        except Exception as error:
            self.error=type(error).__name__;self.active=False;return False
    def install(self):
        if not str(self.page.url).startswith(('https://flow.google.com/','https://labs.google/')):raise ValueError('Flow page required')
        self.page.expose_binding(self.name,self.receive)
        self.page.evaluate(SCRIPT,{'name':self.name,'key':self.key,'limit':self.limit})
        return self
    def close(self):
        self.active=False
        self._report()
        try:self.page.evaluate('(key)=>window[key]?.remove()',self.key)
        except Exception:pass
        if not self.handle.closed:self.handle.close()
        if os.path.exists(self.stage):os.unlink(self.stage)
    def _report(self):
        # v7.0.88: one summary per capture. messages=0 means the page's click handler never ran.
        if self.reported:return
        self.reported=True
        from .flow_download_diagnostics import diag
        state='done' if self.done else 'not-done'
        diag('exact UI blob capture '+state+': messages='+str(self.messages)+' foreign='+str(self.foreign)
             +' chunks='+str(self.index)+' bytes='+str(self.size)+' error='+(self.error or 'none'))
def arm(page,output,validator):
    from .flow_download_diagnostics import describe_exception,diag
    capture=Capture(page,output,validator)
    try:
        armed=capture.install()
        diag('exact UI blob capture armed')
        return armed
    except Exception as error:
        diag('exact UI blob capture not armed: '+describe_exception(error))
        capture.close();return None

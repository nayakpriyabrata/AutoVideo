"""Presentation helpers; no provider calls or changes to job state."""
from pathlib import Path
import json
import subprocess
import sys
import math


THEME_TOKENS = {
    'Light': {'bg':'#f6f7fb','surface':'#ffffff','field':'#ffffff','ink':'#182235','muted':'#475569','line':'#cbd5e1','accent':'#4338ca','soft':'#eef2ff','code':'#f1f5f9'},
    'Warm': {'bg':'#ebe7de','surface':'#f5f1e8','field':'#f9f6ef','ink':'#2d342f','muted':'#4e5b53','line':'#aeb6ab','accent':'#315c4b','soft':'#e2e9df','code':'#e4e1d8'},
    'Dark': {'bg':'#0f172a','surface':'#172033','field':'#1e293b','ink':'#f1f5f9','muted':'#cbd5e1','line':'#475569','accent':'#a5b4fc','soft':'#26314f','code':'#111827'},
}


def theme_css(theme):
    tokens = THEME_TOKENS[theme]
    variables = ';'.join(f'--studio-{key}:{value}' for key,value in tokens.items())
    return ':root{' + variables + ';color-scheme:' + ('dark' if theme == 'Dark' else 'light') + ';}' + Path(__file__).with_name('studio.css').read_text(encoding='utf-8')


def apply_theme(st, version):
    st.sidebar.title('AutoVideoAI')
    st.sidebar.caption('Your local production workspace')
    theme = st.sidebar.selectbox('Appearance', list(THEME_TOKENS), key='studio-appearance')
    css = theme_css(theme)
    st.markdown('<style>' + css + '</style>', unsafe_allow_html=True)
    st.caption(f'AUTOVIDEOAI STUDIO  /  v{version}  /  LOCAL WORKSPACE')


def option_index(options, value, default=0):
    """Old settings may contain providers no longer shown by this widget."""
    return options.index(value) if value in options else default


def progress_percent(value):
    try:
        number = float(value)
        return max(0, min(100, int(number))) if math.isfinite(number) else 0
    except (TypeError, ValueError, OverflowError):
        return 0


def cleanup_report(outputs, apply=False):
    command = [sys.executable, str(Path(__file__).resolve().parents[1] / 'tools/cleanup_jobs.py'),
               '--outputs', str(outputs)]
    if apply:
        command.append('--apply')
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired as error:
        raise RuntimeError('Cleanup is taking longer than expected. Check the saved cleanup logs before retrying.') from error
    except OSError as error:
        raise RuntimeError('Cleanup could not start. Check the installation and output folder.') from error
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout or 'Cleanup could not finish.')[-1500:])
    try:
        report = json.loads(result.stdout)
        if not isinstance(report, dict):
            raise ValueError('Expected a cleanup report')
        return report
    except (ValueError, TypeError) as error:
        raise RuntimeError('Cleanup returned an unreadable report. Check the logs before retrying.') from error

"""Where an editorial card sits, in one place, for every language (v7.0.112).

Field report, with a screenshot: the English text card covered the presenter's face, while the Hindi and Odia
cards did not - and the English card looked better. Two things were wrong, and both were accidents of two
different code paths:

* the **English** master drew its keypoint card at 12 % of the frame height (a top card), straight over the face;
* the **language editions** drew theirs at 72 % (a bottom strip) in a plain navy panel with white text - a
  different look, because ``finishing_studio._card_image`` drew its own panels instead of using the shared
  renderer.

The band below is the one a presenter's face and the burned captions do not occupy: it starts below 40-44 % of
the frame (head and shoulders are above it) and ends where the caption style's own numbers say the top caption
line begins, less a small gap. A card is centred inside it, so the same card lands in the same place in English,
Hindi and Odia.
"""
from __future__ import annotations

#: The part of the frame a talking-head presenter's face normally occupies. Cards never start here. 16:9 portraits
#: sit in the middle of the frame with the head from about 8% to 36%; 9:16 frames put the head a little lower.
FACE_ZONE = {'landscape': 0.40, 'portrait': 0.44}

#: Where a card may end when no caption is burned: clear of the channel logo in the bottom-right corner.
FREE_ZONE = {'landscape': 0.84, 'portrait': 0.78}

#: The smallest band worth using when the frame is very short.
MIN_BAND = 0.12

#: Breathing room between the bottom of a card and the top of a caption line.
GAP = 0.02


def band(width, height, *, vertical=None, captions=True, template=None, gap=GAP):
    """``(top, bottom)`` of the card band in pixels, for this frame.

    The bottom is the highest pixel a burned caption can reach (``captions_ass.caption_block_top``, the same
    numbers the caption style uses) less a small gap - so a card can never sit on the transcript. Without a
    caption the band ends above the channel logo instead.
    """
    height = int(height)
    vertical = (int(height) > int(width)) if vertical is None else bool(vertical)
    top = int(round(height * FACE_ZONE['portrait' if vertical else 'landscape']))
    if captions:
        from .captions_ass import caption_block_top
        aspect = '9:16' if vertical else '16:9'
        bottom = caption_block_top(int(width), height, aspect=aspect, template=template or
                                   ('OPUS' if vertical else 'HORMOZI'))
        bottom -= int(round(height * float(gap)))
    else:
        bottom = int(round(height * FREE_ZONE['portrait' if vertical else 'landscape']))
    if bottom - top < int(round(height * MIN_BAND)):     # never invert or collapse the band
        bottom = min(height, top + max(1, int(round(height * MIN_BAND))))
        top = max(int(round(height * FACE_ZONE['portrait' if vertical else 'landscape'])), bottom - int(round(height * MIN_BAND)))
    return top, bottom


def safe_top(width, height, panel_height, *, vertical=None, captions=True, template=None):
    """Top edge for a card panel of ``panel_height``, centred in the band.

    A panel taller than the band starts at the band's top rather than being shrunk: the card renderers already
    chose a readable type size, and moving the panel is safer than re-fitting its text.
    """
    top, bottom = band(width, height, vertical=vertical, captions=captions, template=template)
    free = max(0, bottom - top - int(panel_height))
    return top + free // 2


def describe(width, height, panel_height=0, *, vertical=None, captions=True):
    """A sentence for a log or an audit: which band was used, in pixels and fractions."""
    vertical = (int(height) > int(width)) if vertical is None else bool(vertical)
    top, bottom = band(width, height, vertical=vertical, captions=captions)
    placed = safe_top(width, height, panel_height, vertical=vertical, captions=captions)
    height = int(height)
    return (('portrait' if vertical else 'landscape') + ' frame ' + str(int(height)) + ' px: cards sit between '
            + f'{top}px ({top / max(1, height):.0%}) and {bottom}px '
            + f'({bottom / max(1, height):.0%}); this card starts at {placed}px')

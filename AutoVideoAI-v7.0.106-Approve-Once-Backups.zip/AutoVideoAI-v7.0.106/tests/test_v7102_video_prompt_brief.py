"""v7.0.102: why the video scan said "no verified match" although the clip was in the project.

Field case (job 20261022-143856-7, shot_014, 2026-10-26 18:42 IST):

    [Flow] Exact video recovery scan: 8 gallery assets, 2 fresh candidates, 3 readable prompts,
           0 unavailable prompt controls; no verified match.

    FlowUIChanged: No unique completed video matches the request. Review the exact editor URL ...

The clip was there. Three things made the automatic match impossible:

1. a video request is written as *"Create exactly 1 VIDEO clip. … approximately 6 seconds, using Omni 1.1
   Flash. Generate the media from this scene description exactly as the creative brief: <brief>"*, while a
   tile's Reuse prompt often returns **only the brief** - so equality against the full envelope could never
   hold, even though 3 prompts were read successfully;
2. two assets were fresh relative to the baseline, and the video branch only accepts *exactly one* verified
   match, so even a correct match would have been refused while a second fresh asset existed;
3. the failure only said "review the exact editor URL", without saying which assets were considered.

v7.0.102: parse our own video envelope (`video_creative_brief`) and compare the brief exactly on either side
(`same_video_generation_prompt`), record each asset's own editor link when Flow exposes it (`edit_url`, never
part of the persisted signature), and print the fresh candidates with their prompts and links when nothing
verifies.

The manual path still worked and its result is pinned here too: `--asset-url … --asset-reviewed` downloaded
exactly that asset, QC decided ACCEPT (93.6), and a repeat correctly answers `already_accepted`.
"""
import json

import pytest

from engine.providers.flow_browser import FlowBrowser, FlowBrowserProvider

BRIEF = ("Close-up of Samridhi standing calmly in a brightly lit, elegant room, looking directly at the camera "
         "with a serene smile.")


def _video_prompt(brief=BRIEF, model="Omni 1.1 Flash", aspect="16:9", seconds=6):
    return FlowBrowser._agent_video_instruction(brief, aspect, model, seconds, 1)


# ----------------------------------------------------------------- the envelope

@pytest.mark.parametrize("model", ["Omni 1.1 Flash", "Veo 3.1 - Lite", "Veo 3.1", "Omni 1.1"])
def test_the_brief_is_extracted_from_our_own_video_envelope(model):
    """Model labels contain dots; the brief must still be found exactly."""
    assert FlowBrowser.video_creative_brief(_video_prompt(model=model)) == BRIEF


def test_a_card_showing_only_the_brief_matches_the_saved_envelope():
    prompt = _video_prompt()
    assert FlowBrowser.same_video_generation_prompt(BRIEF, prompt) is True
    assert FlowBrowser.same_video_generation_prompt(prompt, BRIEF) is True
    assert FlowBrowser.same_video_generation_prompt(prompt, prompt) is True


def test_a_different_scene_never_matches():
    prompt = _video_prompt()
    assert FlowBrowser.same_video_generation_prompt("A busy street at night, rain on the tarmac.", prompt) is False
    assert FlowBrowser.same_video_generation_prompt("", prompt) is False
    assert FlowBrowser.same_video_generation_prompt(prompt, "") is False


def test_a_near_miss_is_still_a_miss():
    """The comparison stays exact: one changed word is a different request."""
    prompt = _video_prompt()
    nearly = BRIEF.replace("serene smile", "serene frown")
    assert FlowBrowser.same_video_generation_prompt(nearly, prompt) is False


def test_an_image_envelope_is_not_mistaken_for_a_video_brief():
    image = FlowBrowser._agent_image_instruction(BRIEF, "16:9", 1)
    assert FlowBrowser.video_creative_brief(image) is None
    assert FlowBrowser.same_video_generation_prompt(BRIEF, image) is False
    assert FlowBrowser.same_image_generation_prompt(BRIEF, image) is True


# ----------------------------------------------------------------- the candidate listing

def _asset(src="https://lh3.example/poster.jpg", kind="video", edit="/project/p1/edit/54194f38-1fdb-4584-9840-b88a8775a6a4",
           width=640, height=360):
    sig = "|".join(["IMG", src, "alt text", kind, str(width), str(height)])
    return {"src": src, "alt": "alt text", "kind": kind, "sig": sig, "width": width, "height": height,
            "edit_url": edit}


def _evidence(*assets):
    import hashlib
    return {hashlib.sha256(str(a["sig"]).encode()).hexdigest():
            {"asset_fingerprint": hashlib.sha256(str(a["sig"]).encode()).hexdigest(), "prompt": BRIEF}
            for a in assets}


def test_the_listing_describes_each_fresh_candidate_read_only():
    first, second = _asset(), _asset(src="https://lh3.example/other.jpg", edit="")
    listing = FlowBrowserProvider._candidate_listing([first, second], _evidence(first, second), "video")
    assert len(listing) == 2
    assert listing[0]["edit_url"].endswith("/edit/54194f38-1fdb-4584-9840-b88a8775a6a4")
    assert listing[0]["kind"] == "video" and listing[0]["size"] == "640x360"
    assert listing[0]["prompt"] == BRIEF
    assert listing[1]["edit_url"] == ""            # never guessed


def test_the_listing_is_bounded():
    assets = [_asset(src=f"https://lh3.example/{n}.jpg") for n in range(9)]
    assert len(FlowBrowserProvider._candidate_listing(assets, {}, "video")) == 5


def test_a_missing_prompt_is_reported_as_unreadable_not_invented():
    rows = FlowBrowserProvider._candidate_listing([_asset()], {}, "video")
    assert rows[0]["prompt"] == ""


def test_a_relative_media_url_is_never_promoted_to_an_editor_url():
    rows = FlowBrowserProvider._candidate_listing([_asset(src="/media/poster.jpg", edit="")], {}, "video")
    assert rows[0]["edit_url"] == ""


# ----------------------------------------------------------------- the failure text

def test_the_scan_records_its_candidate_listing_on_the_journal():
    from pathlib import Path
    source = Path('engine/providers/flow_browser.py').read_text(encoding='utf-8')
    assert 'request["candidate_listing"] = listing' in source
    assert 'Fresh candidate {number}' in source


def test_the_failure_hands_over_a_ready_command():
    from pathlib import Path
    source = Path('engine/providers/flow_browser.py').read_text(encoding='utf-8')
    start = source.index('No unique completed video matches the request.')
    block = source[max(0, start - 2000):start + 400]
    assert '--asset-url' in block and '--asset-reviewed' in block
    assert 'does not expose their editor URL' in block     # the honest fallback


# ----------------------------------------------------------------- the double-exposure case

def test_a_clip_exposed_twice_is_matched_through_its_video_element():
    """Flow shows a clip as a <video> node and again as a poster <img>; both carry the same prompt."""
    from engine.providers.flow_browser import FlowBrowserProvider

    prompt = _video_prompt()
    poster = _asset(src="https://lh3.example/poster.jpg", edit="")
    poster.update(hasVideoNode=False, kind="video")
    node = _asset(src="https://lh3.example/clip.mp4", edit="/project/p1/edit/54194f38-1fdb-4584-9840-b88a8775a6a4")
    node.update(hasVideoNode=True, kind="video")

    class Bridge:
        def __init__(self):
            self._page = self

        def media_assets(self):
            return [poster, node]

        def read_asset_generation_prompt(self, sig):
            return BRIEF                      # the card returns only the brief

        def wait_for_timeout(self, ms):
            pass

    request = {"baseline": [], "submitted_prompt": prompt}
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    chosen = provider._identify_single_fresh_asset(Bridge(), request, "video", timeout_ms=0)
    assert chosen == node["sig"]
    assert request["correlation_method"] == "unique_exact_saved_video_prompt_video_node"


def test_two_different_clips_with_the_same_prompt_are_refused_and_listed():
    from engine.providers.flow_browser import FlowBrowserProvider

    prompt = _video_prompt()
    first = _asset(src="https://lh3.example/a.mp4", edit="/project/p1/edit/aaaa")
    second = _asset(src="https://lh3.example/b.mp4", edit="/project/p1/edit/bbbb")
    first.update(hasVideoNode=True, kind="video")
    second.update(hasVideoNode=True, kind="video")

    class Bridge:
        def __init__(self):
            self._page = self

        def media_assets(self):
            return [first, second]

        def read_asset_generation_prompt(self, sig):
            return BRIEF

        def wait_for_timeout(self, ms):
            pass

    request = {"baseline": [], "submitted_prompt": prompt}
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    assert provider._identify_single_fresh_asset(Bridge(), request, "video", timeout_ms=0) == ""
    listing = request.get("candidate_listing") or []
    assert len(listing) == 2 and all(row["edit_url"] for row in listing)

"""Reusable, reviewed tracks stored beside shared outputs, never in code updates."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile

_EXTENSIONS = {'.mp3', '.wav', '.ogg', '.m4a', '.flac'}
_THEMES = {
    'motivation': {'confidence', 'discipline', 'motivation', 'success', 'habit', 'inspire', 'growth', 'career'},
    'calm': {'calm', 'meditation', 'nature', 'rain', 'forest', 'gentle', 'sleep', 'mindful'},
    'upbeat': {'dance', 'joy', 'celebration', 'party', 'kids', 'fun', 'playful'},
    'cinematic': {'cinematic', 'dramatic', 'story', 'epic', 'travel', 'adventure'},
    'technology': {'technology', 'tech', 'science', 'ai', 'innovation', 'future'},
}


def root():
    configured = os.getenv('AUTOVIDEO_MUSIC_LIBRARY', '').strip()
    return Path(configured).expanduser().resolve() if configured else Path('outputs').resolve().parent/'music_library'


def _records(folder):
    try:
        data=json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
        return data['tracks'] if isinstance(data['tracks'],list) else []
    except (OSError, ValueError, KeyError, TypeError):
        return []


def list_tracks(folder=None):
    folder=Path(folder or root()).resolve()
    rows=[]
    for row in _records(folder):
        if not isinstance(row,dict):continue
        name=row.get('file','')
        if not isinstance(name,str) or Path(name).name!=name or Path(name).suffix.lower() not in _EXTENSIONS:continue
        path=folder/name
        if path.is_file() and not path.is_symlink() and path.stat().st_size>0:
            rows.append({**row,'path':str(path)})
    return rows


def import_track(data, filename, title, tags, source_url, license_label, folder=None):
    from ..flow_music import validate_audio
    from ..production import save
    folder=Path(folder or root()).resolve();folder.mkdir(parents=True,exist_ok=True)
    suffix=Path(filename).suffix.lower()
    if suffix not in _EXTENSIONS or not isinstance(data,bytes) or not 30000<=len(data)<=50*1024*1024:
        raise ValueError('Upload a playable MP3/WAV/OGG/M4A/FLAC file of 30 KB–50 MB')
    title=str(title).strip()[:120];source_url=str(source_url).strip()[:500]
    license_label=str(license_label).strip()[:160]
    tags=sorted(set(re.findall(r'[a-z]{3,}',str(tags).lower())))[:20]
    if not title or not tags or not source_url.startswith('https://') or not license_label:
        raise ValueError('Provide title, theme tags, exact HTTPS source page and license/permission label')
    sha=hashlib.sha256(data).hexdigest();name=sha[:20]+suffix;dest=folder/name
    fd,tmp=tempfile.mkstemp(dir=folder,prefix='.music-upload-',suffix=suffix)
    try:
        with os.fdopen(fd,'wb') as out:out.write(data);out.flush();os.fsync(out.fileno())
        validate_audio(tmp)
        with (folder/'.manifest.lock').open('a+b') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            if not dest.exists():os.replace(tmp,dest)
            row={'file':name,'sha256':sha,'title':title,'tags':tags,'source_url':source_url,
                 'license':license_label}
            rows=[r for r in _records(folder) if isinstance(r,dict) and r.get('file')!=name]+[row]
            save(folder/'manifest.json',{'schema_version':1,'tracks':rows})
        return {**row,'path':str(dest)}
    finally:
        Path(tmp).unlink(missing_ok=True)


def select_theme(theme, folder=None):
    tokens=set(re.findall(r'[a-z]{3,}',str(theme).lower()))
    categories={key for key,words in _THEMES.items() if tokens & words}
    wanted=tokens|categories
    matches=[]
    for row in list_tracks(folder):
        score=len(wanted & set(row.get('tags',[])))
        if score>0:matches.append((-score,row['title'].lower(),row))
    if not matches:return None
    matches.sort(key=lambda item:(item[0],item[1]))
    row=matches[0][2]
    if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:
        raise ValueError('Music library track changed after review; import it again')
    return row

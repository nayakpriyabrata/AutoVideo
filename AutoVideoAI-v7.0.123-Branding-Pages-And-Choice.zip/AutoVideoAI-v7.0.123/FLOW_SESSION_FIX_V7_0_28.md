# AutoVideoAI v7.0.28 · Flow session and reference fixes

## Upgrade without losing jobs

Stop Studio, CLI jobs, runner and Chromium before migration. Extract this ZIP into a new folder, open WSL there, then run:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.27 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.27 . --apply
python3 -m pip install -r requirements.txt
./dashboard.sh
```

If your most complete outputs/data are in another version, use that version as the source. Migration preserves existing output files, copies saved state and rebases installation paths. Keep the source folder until the migrated jobs are verified.

## Fixes

- Storyboard filters missing images and their captions together. An empty reference list shows a warning instead of crashing.
- Flow Session waits for authenticated Flow controls, including when the landing page still shows Sign in. It does not treat a Google URL redirect or an empty page as a successful login. Login timeout does not launch another fallback browser.
- Reference upload uses the visible Upload media action's file chooser. It no longer selects whichever old hidden file input happens to be last in the DOM.
- A retry reuses an exact named reference already attached to the composer, without reopening the empty library picker.
- Uploaded/reused references must appear on the composer as an exact named attachment or a new removable image attachment after the exact local-file upload/selection. Merely finding an editable prompt box or failing to see Add to prompt is insufficient.
- Mini Reels and other Flow modes dismiss the asset picker before editing, skip hidden editor matches and bound click/fill waits. A picker that refuses to close stops before submission with a specific diagnostic.
- Legacy upload recovery reservations receive one remediation attempt using the corrected attachment protocol. The file alias is checked by content hash, including same-size corrupt cache files. This only uploads the same reference; it does not regenerate images/videos.
- Saved cast recovery searches its frozen job reference and the corresponding migrated character file, accepting only the snapshot's original SHA-256. It never substitutes a changed photo or rewrites the approved cast. The error identifies the character and photo if neither copy exists.
- Queue provides Capture logs for copying: a stable, selectable text snapshot while progress continues. Download complete runtime log exports the full local log.
- Missing folders are excluded from active-job selectors. Settings → Missing job entries previews database rows whose entire folder is absent. Removal rechecks, refuses during production, backs up the database and deletes only those index entries. Incomplete folders, media files and journals are retained. A missing output root cannot authorize pruning.

Missing-entry removal is also available from WSL:

```bash
python3 tools/prune_missing_jobs.py
python3 tools/prune_missing_jobs.py --apply
```

The first command previews; the second rechecks and backs up the index before removal. It does not delete any job folders.

## Cleanup

Automatic cleanup still runs in the job's finally block. It trims regenerable caches from closed isolated Flow worker profiles. Entire worker clones are removed only for completed jobs with a validated final video and no unresolved request journals. Active profiles, base login profiles, accepted media, original inputs, saved cast and pending requests remain protected.

Settings → Disk cleanup previews eligible bytes; Apply rechecks eligibility. Each job saves its automatic report in `logs/cleanup.json`. Zero freed bytes can be correct when a worker is active or no eligible cache exists. Removing missing database entries frees negligible disk space; it does not delete media.

## Validation limits

Regression tests cover these local/UI behaviors and existing cleanup/recovery safeguards. No paid Google request was submitted during testing. The exact live Flow UI and WSLg browser lifetime still need verification on your computer. If Flow does not expose a verifiable attachment or asset identity, the tool preserves the job instead of silently using an unrelated image or submitting a duplicate video. This build does not claim a guaranteed provider failure rate.

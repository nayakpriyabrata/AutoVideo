"""v7.0.107: fit a longer reviewed narration onto the approved picture, and say exactly why if it cannot.

Field case (job ``20261022-143856-7-small-daily-habits-tha-9729``, 2026-10-27): Hindi exported, Odia failed with

    Odia narration is more than 25% longer than the approved picture. Shorten that language script,
    review it, and prepare it again.

That told nobody the actual numbers, and the only lever was "slow the picture by up to 25%" - so a perfectly
good Odia narration that was 30% longer produced no video at all.

Three bounded levers are available now, in this order:

1. **picture**: slow the approved picture (`setpts`), up to ``max_picture_stretch`` (default 1.25x);
2. **narration**: speed the reviewed narration with pitch-preserving ``atempo``, up to ``max_tempo``
   (default 1.12x); card/caption word timings are divided by the same factor so they stay in sync;
3. **hold** (opt-in): clone the last frame for the remaining seconds (``allow_hold``, capped by ``hold_cap``).

Combined, 1.25 x 1.12 absorbs a narration up to 1.40x the picture. Beyond that the render is refused with the
measurements, how much text to cut, and the exact flags that would accept it. This module is pure: no ffmpeg,
no files, no browser - so the arithmetic is testable.
"""
from __future__ import annotations

DEFAULT_MAX_PICTURE_STRETCH = 1.25
DEFAULT_MAX_TEMPO = 1.12
DEFAULT_HOLD_CAP = 20.0
# Rough speaking rate used only to express an overflow as "about N words to cut".
WORDS_PER_SECOND = 2.4


def _positive(value, default):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return float(default)
    return number if number > 0 else float(default)


def _policy(kwargs):
    kwargs = kwargs or {}
    return {
        'max_picture_stretch': _positive(kwargs.get('max_picture_stretch'), DEFAULT_MAX_PICTURE_STRETCH),
        'max_tempo': _positive(kwargs.get('max_tempo'), DEFAULT_MAX_TEMPO),
        'allow_hold': bool(kwargs.get('allow_hold', False)),
        'hold_cap': _positive(kwargs.get('hold_cap'), DEFAULT_HOLD_CAP),
    }


def plan(narration_seconds, picture_seconds, *, label='Narration', max_picture_stretch=None,
         max_tempo=None, allow_hold=False, hold_cap=None) -> dict:
    """Decide how a narration of ``narration_seconds`` fits a picture of ``picture_seconds``.

    ``mode`` is ``none`` (no fit needed), ``fit`` (picture and/or narration are retimed), ``hold``
    (retimed plus a cloned last frame) or ``refuse`` (nothing can be exported safely).

    ``picture_scale`` multiplies the picture length, ``tempo`` multiplies the narration speed
    (``atempo``), and ``hold_seconds`` is cloned onto the end of the picture.
    """
    policy = _policy({'max_picture_stretch': max_picture_stretch, 'max_tempo': max_tempo,
                      'allow_hold': allow_hold, 'hold_cap': hold_cap})
    max_stretch = policy['max_picture_stretch']
    max_tempo = policy['max_tempo']
    hold_cap = policy['hold_cap']
    narration = float(narration_seconds or 0.0)
    picture = float(picture_seconds or 0.0)
    base = {'narration_seconds': round(narration, 3), 'picture_seconds': round(picture, 3),
            'max_picture_stretch': max_stretch, 'max_tempo': max_tempo, 'allow_hold': policy['allow_hold'],
            'hold_cap': hold_cap, 'picture_scale': 1.0, 'tempo': 1.0, 'hold_seconds': 0.0,
            'ratio': round(narration / picture, 4) if picture > 0 else None,
            'absorbable_ratio': round(max_stretch * max_tempo, 4), 'overflow_seconds': 0.0,
            'words_to_cut': 0, 'fit_seconds': round(narration, 3), 'label': str(label or 'Narration')}
    if picture <= 0 or narration <= picture + 0.25:
        base.update(mode='none', message='')
        return base

    ratio = narration / picture
    stretch = min(ratio, max_stretch)
    tempo = ratio / stretch if stretch else ratio
    if tempo <= max_tempo + 1e-9:
        base.update(mode='fit', picture_scale=round(stretch, 6), tempo=round(min(tempo, max_tempo), 6),
                    tempo_used=bool(tempo > 1.0001))
        return base

    absorbed = picture * max_stretch * max_tempo
    overflow = max(0.0, narration - absorbed)
    words = int(round(overflow * WORDS_PER_SECOND))
    base.update(mode='refuse', picture_scale=max_stretch, tempo=max_tempo, hold_seconds=0.0,
                overflow_seconds=round(overflow, 3), words_to_cut=words)
    if policy['allow_hold'] and overflow <= hold_cap:
        base.update(mode='hold', hold_seconds=round(overflow, 3), words_to_cut=0,
                    message=(f"{base['label']} narration is {narration:.1f}s but the approved picture is "
                             f"{picture:.1f}s ({ratio:.2f}x). The picture is slowed {max_stretch:.2f}x, the "
                             f"narration sped {max_tempo:.2f}x, and the last frame is held for "
                             f"{overflow:.1f}s at the end so the whole narration is heard."))
        return base

    needed_tempo = max_tempo + (overflow / (picture * max_stretch))
    base['needed_tempo'] = round(needed_tempo, 3)
    hold_hint = (f' or hold the last frame for {overflow:.0f}s with `--fit-hold {overflow:.0f}`'
                 if not policy['allow_hold'] else f' (that is beyond the {hold_cap:g}s hold limit)')
    base['message'] = (
        f"{base['label']} narration is {narration:.1f}s but the approved picture is {picture:.1f}s "
        f"({ratio:.2f}x) - more than 25% longer than the approved picture, so a video rendered from it would "
        f"either cut the narration or freeze the picture. Slowing the picture {max_stretch:.2f}x and speeding "
        f"the narration {max_tempo:.2f}x absorbs {base['absorbable_ratio']:.2f}x, which still leaves "
        f"{overflow:.1f}s (about {words} spoken words) over. Nothing was exported. Fix one of these: shorten "
        f"that language script by about {words} words and re-approve it; re-run with `--fit-max-tempo "
        f"{needed_tempo:.2f}` to accept a faster narration;{hold_hint}; or trim the picture.")
    return base


def scale_words(words, tempo):
    """Divide word timings by ``tempo`` so cards and captions follow the sped-up narration."""
    tempo = float(tempo or 1.0)
    if abs(tempo - 1.0) < 1e-6:
        return [dict(word) for word in (words or [])]
    scaled = []
    for word in words or []:
        row = dict(word)
        for key in ('start', 'end'):
            if isinstance(row.get(key), (int, float)):
                row[key] = round(float(row[key]) / tempo, 3)
        scaled.append(row)
    return scaled


def describe(report) -> str:
    """One line for the log: what the fit did, with numbers."""
    report = report or {}
    mode = report.get('mode')
    if mode == 'none':
        return (f"No narration fit needed ({report.get('narration_seconds')}s narration, "
                f"{report.get('picture_seconds')}s picture).")
    if mode == 'fit':
        return (f"Narration fit: picture x{report.get('picture_scale')} · narration x{report.get('tempo')} "
                f"({report.get('narration_seconds')}s narration on {report.get('picture_seconds')}s picture).")
    if mode == 'hold':
        return (f"Narration fit: picture x{report.get('picture_scale')} · narration x{report.get('tempo')} · "
                f"last frame held {report.get('hold_seconds')}s.")
    return 'Narration fit refused: ' + str(report.get('message') or '')

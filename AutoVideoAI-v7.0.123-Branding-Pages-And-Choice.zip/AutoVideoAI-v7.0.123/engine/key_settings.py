"""Local-only secret updates; no values appear in logs, reports or return data."""
from pathlib import Path
import os
import tempfile
from dotenv import dotenv_values, set_key
from .env_config import API_KEYS

def update_key(name, value, root='.'):
    if name not in API_KEYS:
        raise ValueError('Choose a supported API key')
    value = str(value).strip()
    if not value or len(value)>8192 or any(c in value for c in '\r\n\x00'):
        raise ValueError('Enter a non-empty key on a single line')
    target = Path(root).resolve()/'.env'
    if target.is_symlink():
        raise ValueError('Environment file must not be a symbolic link')
    fd, temporary = tempfile.mkstemp(prefix='.env-update-', dir=target.parent)
    os.close(fd)
    try:
        if target.exists():
            Path(temporary).write_bytes(target.read_bytes())
        set_key(temporary, name, value, quote_mode='always')
        if dotenv_values(temporary).get(name) != value:
            raise ValueError('Key could not be saved')
        os.chmod(temporary, 0o600)
        os.replace(temporary, target)
        os.environ[name] = value
    finally:
        Path(temporary).unlink(missing_ok=True)
    return {'key': name, 'configured': True}

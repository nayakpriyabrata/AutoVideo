import json
from pathlib import Path
import pytest
from engine.channel_desk import (METRICS_TEMPLATE,parse_metrics,metrics_summary,validate_package,validate_brief,
 review_video,editorial_signoff,REVIEW_CHECKS,job_context)
from engine.production import save,digest,run


def csvrow(post='a',when='2026-10-19T00:00:00Z',views=100,watch=3000,language='en',window=7):
 return f'channel,youtube_long,{language},{post},{when},60,{window},{views},{watch},50,4,A\n'


def test_metrics_deduplicate_snapshots_without_double_counting_and_separate_languages():
 rows=parse_metrics(METRICS_TEMPLATE+csvrow(when='2026-10-18T00:00:00Z',views=200)+csvrow()+csvrow(language='hi')+csvrow(post='low',views=10,watch=30))
 result=metrics_summary(rows)
 assert result['latest_posts']==3 and result['excluded_low_views']==1
 assert len(result['cohorts'])==2 and all(c['views']==100 for c in result['cohorts'])
 assert all(c['average_view_seconds']==30 for c in result['cohorts'])


@pytest.mark.parametrize('bad',[csvrow(views=0,watch=5),csvrow(views=-1),csvrow(views='nan'),csvrow(when='2026-10-19'),csvrow(window=1.5),csvrow()+csvrow()])
def test_invalid_metrics_rejected(bad):
 with pytest.raises(ValueError):parse_metrics(METRICS_TEMPLATE+bad)


def test_looping_watch_percentage_not_clipped():
 result=metrics_summary(parse_metrics(METRICS_TEMPLATE+csvrow(watch=12000)))
 assert result['cohorts'][0]['median_watched_pct']==200


def test_gemini_evidence_must_exist_and_distinct_titles():
 brief=validate_brief(dict(title='Confidence',audience='Students',promise='Practice speaking',script='Practice one sentence every day.',language='en',destination='youtube_long'))
 draft={'variants':[dict(title=f'Option {i}',hook='Practice now',thumbnail_brief='A speaker on stage',evidence_quote='Practice one sentence') for i in range(3)],'closing_action':'Try one sentence today.','editor_notes':[]}
 assert validate_package(draft,brief)==draft
 draft['variants'][0]['evidence_quote']='Guaranteed wealth'
 with pytest.raises(ValueError):validate_package(draft,brief)


def test_real_review_missing_audio_previews_cache_and_stale_signoff(ffmpeg_media,tmp_path,monkeypatch):
 import engine.channel_desk as mod
 source=tmp_path/'source.mp4';source.write_bytes(Path(ffmpeg_media['video']).read_bytes())
 record=review_video(source,tmp_path/'packs','youtube_long')
 assert any(r['code']=='audio_missing' for r in record['issues'])
 assert Path(record['contact_sheet']).is_file() and all(Path(p).is_file() for p in record['previews'].values())
 monkeypatch.setattr(mod,'run',lambda *a,**k: (_ for _ in ()).throw(AssertionError('cached review must not re-encode')))
 assert review_video(source,tmp_path/'packs','youtube_long')['source_sha256']==record['source_sha256']
 checks={k:True for k in REVIEW_CHECKS}
 with pytest.raises(ValueError,match='warnings'):editorial_signoff(record['review_path'],checks)
 approved=editorial_signoff(record['review_path'],checks,'Test source intentionally small and silent')
 assert approved['status']=='EDITOR_REVIEWED'
 source.write_bytes(b'changed')
 with pytest.raises(ValueError,match='changed'):editorial_signoff(record['review_path'],checks,'note')


def test_real_final_audio_measurement(ffmpeg_media,tmp_path):
 source=tmp_path/'with-audio.mp4'
 run(['ffmpeg','-v','error','-y','-i',ffmpeg_media['video'],'-i',ffmpeg_media['voice'],'-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-shortest',str(source)])
 record=review_video(source,tmp_path/'packs','youtube_long')
 assert record['audio_streams']==1
 assert isinstance(record['analysis']['integrated_lufs'],float)
 assert not any(x['code']=='audio_missing' for x in record['issues'])


def test_production_qc_requires_choice_when_broll_and_plain_exist(tmp_path):
 from engine.production import check_job
 save(tmp_path/'production_manifest.json',{'job_id':'job','shots':[]})
 save(tmp_path/'render/timeline.json',{'total':4,'segments':[{}]})
 for name in ['job-final.mp4','job-final-broll.mp4']:(tmp_path/'render'/name).write_bytes(b'placeholder')
 with pytest.raises(ValueError,match='Multiple final exports'):check_job(tmp_path)


def test_timeline_hints_do_not_claim_final_music_audibility(tmp_path):
 save(tmp_path/'production_manifest.json',{'shots':[{'shot_id':'one','provider':'image'}]})
 save(tmp_path/'render/timeline.json',{'segments':[{'shot_id':'one','src':'same.jpg','dur':12},{'shot_id':'one','src':'same.jpg','dur':3}]})
 save(tmp_path/'audio/sound_plan.json',{'music':{'path':'missing.ogg'},'music_volume':.12})
 result=job_context(tmp_path/'render/job-final.mp4')
 assert result['adjacent_same_source'][0]['at']==12
 assert not result['planned_music_exists']
 assert len(result['long_image_segments'])==1


def test_publishing_signoff_is_for_exact_delivery_and_evidence_cannot_change(tmp_path, monkeypatch):
 import engine.delivery_duplicates as _dd; monkeypatch.setattr(_dd,'check',lambda *a,**k:{'blocked':[],'warnings':[],'skipped':[]})  # placeholder video bytes; guard covered in test_v768_delivery_duplicates
 from engine.publishing import approve_release,schedule_release
 media=tmp_path/'video.mp4';media.write_bytes(b'final fixture')
 release=tmp_path/'a.release.json';review=tmp_path/'review.json'
 save(release,{'id':'a','video':str(media),'sha256':digest(media),'destination':'youtube_long','language':'en','title':'Test'})
 save(review,{'status':'EDITOR_REVIEWED','source_sha256':'wrong','destination':'youtube_long','editorial_checks':{k:True for k in REVIEW_CHECKS}})
 args=dict(account_id='my-channel',rights_confirmed=True,facts_reviewed=True,language_reviewed=True,made_for_kids=False,ai_disclosure_required=True,editorial_review_path=review)
 with pytest.raises(ValueError,match='exact delivery'):approve_release(release,**args)
 data=json.loads(review.read_text());data['source_sha256']=digest(media);save(review,data)
 result=approve_release(release,**args);assert result['editorial_evidence']['sha256']==digest(review)
 review.write_text(review.read_text()+' ')
 with pytest.raises(ValueError,match='evidence changed'):schedule_release(release,'2099-01-01T00:00:00Z')


def test_all_language_voices_precede_any_card_request(tmp_path,monkeypatch):
 import engine.speech_cards as sc
 import engine.providers.gemini_web as gw
 events=[]
 translations={'hi':'हिंदी अनुवाद','or':'ଓଡ଼ିଆ ଅନୁବାଦ'}
 def translate(system,user,**kwargs):
  lang=user.split('Target: ')[1].split('\n')[0];return json.dumps({'narration':translations[lang]},ensure_ascii=False)
 monkeypatch.setattr(gw,'gemini_web_generate',translate)
 def voice(root,script,language,**kw):
  assert kw['draft_cards'] is False
  events.append(('voice',language));return {'language':language,'script':script}
 def cards(bundle,*args):events.append(('cards',bundle['language']));return dict(bundle,cards=[])
 monkeypatch.setattr(sc,'prepare_edition',voice);monkeypatch.setattr(sc,'complete_edition_cards',cards)
 result=sc.prepare_batch(tmp_path,'English script','en',['en','hi','or'])
 assert events==[('voice','en'),('voice','hi'),('voice','or'),('cards','en'),('cards','hi'),('cards','or')]
 assert result['phase']=='ready_for_review' and set(result['bundles'])=={'en','hi','or'}


def test_failed_voice_prevents_all_card_requests(tmp_path,monkeypatch):
 import engine.speech_cards as sc
 monkeypatch.setattr(sc,'prepare_edition',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('TTS unavailable')))
 monkeypatch.setattr(sc,'complete_edition_cards',lambda *a,**k: (_ for _ in ()).throw(AssertionError('No cards allowed yet')))
 with pytest.raises(RuntimeError,match='TTS unavailable'):sc.prepare_batch(tmp_path,'Hello','en',['en'])


def test_prepared_batch_snapshots_and_preserves_timing_type(tmp_path):
 from engine.speech_cards import attach_prepared_batch,fingerprint
 source=tmp_path/'preflight/en/key';source.mkdir(parents=True)
 audio=source/'voice.mp3';audio.write_bytes(b'prepared fixture');words=[{'word':'Hello','start':0,'end':1}]
 save(source/'words.json',words)
 save(source/'production/speech_cards.json',{'fingerprint':fingerprint(audio,words,'Hello'),'cards':[]})
 bundle={'audio':str(audio),'words':str(source/'words.json'),'audio_sha256':digest(audio),'language':'en','script':'Hello','duration':2,'timing_source':'estimated','cards':[]}
 result=attach_prepared_batch(tmp_path/'job',{'phase':'ready_for_review','source_language':'en','bundles':{'en':bundle}})
 audio.unlink()
 assert Path(result['en']['audio']).is_file()
 assert result['en']['timing_source']=='estimated'
 assert json.loads((tmp_path/'job/production/prepared_speech.json').read_text())['script']=='Hello'

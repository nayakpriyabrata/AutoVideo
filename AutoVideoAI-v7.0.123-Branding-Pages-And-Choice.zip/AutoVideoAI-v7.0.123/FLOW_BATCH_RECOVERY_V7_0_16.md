# AutoVideoAI 7.0.16 — exact Flow frame recovery as a batch

You selected Preserve Flow quality. This option does not replace a missing frame
with stock, a still from another scene, or a local animation. It does not
promise to identify an asset that Flow does not expose.

With this explicit option, an unresolved opening or closing frame is retained
and the job continues with other frames. Missing closings do not become fake
continuity links for later scenes. Successful frames are saved normally. After
all frames have been considered, the job pauses once and lists all unresolved
frames in `flow_frame_recovery_batch.json`, Queue, and the support report.
Video generation and rendering remain gated until the frames are resolved.

The next Resume reuses valid cached frames and retries only missing frames.
Pending serial requests keep their original prompt and project. Pending older
parallel-worker requests recover their original artifact in their saved project,
instead of creating another serial request. No unresolved request is replaced.
The recovery pass is serial to preserve those project/output bindings.
Missing master identity/location references still stop the pass: later frames
must not be generated without their required references.

## Upgrade and enable once

Stop Studio, runner and CLI jobs. From the extracted 7.0.16 directory:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.15 . --apply
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6 --continue-on-unresolved-frames
```

If your installed folder is still v7.0.14, use that folder as the migration source
instead. Keep the previous installation until the upgrade is verified.
The option is saved for this job; later runs need only `v3 resume JOB_ID`.
In Studio Queue → Flow recovery behavior, enable “Continue other frames when an
exact Flow image is unresolved” and save the frame recovery policy.
To restore the original stop-at-first-frame behavior, use:
`python3 cli.py v3 resume JOB_ID --no-continue-on-unresolved-frames`.

## What this does and does not fix

It fixes the first-unresolved-frame stop and repeated regeneration of completed
work. Shot 6's closing image remains unidentified in the supplied report. It may
remain on the final recovery list; the tool does not claim an end-to-end finished
video. New frame requests can still be made for never-submitted frames under the
job's existing Flow image approval/credit policy. No video is submitted while
this report has unresolved frames. Live WSL behavior remains unverified.

# AutoVideoAI 7.0.55 — B-roll placement repair

Stop Studio and any CLI/runner production before installing. Extract this build beside your existing installation, then run from that existing installation:

```bash
python3 ../AutoVideoAI-v7.0.55/tools/update_to_v755.py . --apply
./dashboard.sh
```

Supports 7.0.53 (including shipped recovery/approval hotfixes) and 7.0.54. Backs up changed code; preserves jobs, outputs, account profiles and settings. Includes all 7.0.54 features. No Flow project is deleted and no generation is requested by installing.

## Editing rules

- Reuse count is a ceiling. Repeated exact-file assets require a 30-second gap measured from the preceding use's end AND a different accepted cutaway in between. If that cannot fit, the second use is omitted.
- Planned B-roll excludes Flow, MovieFlow, external and unknown-provider video intervals. Actual image/stock fallback is eligible. Borrowed visuals and local override media are conservatively protected during final rendering.
- Final rendering checks the actual timeline, including holds and crossing boundaries. Old approvals cannot place B-roll over protected video. It skips the whole insert, never moves or trims the approved insert silently.
- Both production and Clip Studio enforce repeat spacing and reject overlaps. Different clip outputs have independent timelines. Clip Studio cannot infer AI origin from an arbitrary uploaded MP4; AI-shot protection applies to production jobs with saved shot provenance.
- Production writes render/broll_placement_report.json listing applied count and skipped candidate IDs/reasons. Clip reviews save placement_skips. Saved approvals and original highlight files remain intact.
- Short/all-AI productions may have fewer or zero cutaways. This is expected, not a search failure.

## Repair the existing final video

From the installed directory, after the update, use render (not a new generation):

```bash
python3 cli.py v3 render 20261016-115816-the-power-of-self-confid-31b9 --quality high
```

Keep a copy of any final render you want to retain before re-rendering. All shots must already be accepted; coverage checks still apply. The saved B-roll review is reused under the new placement rules. The render command uses saved takes; it does not request new Flow shots. An enabled B-roll search can fetch stock if there is no saved review.

## Review of the supplied 235.46-second video

Sampled the full video every five seconds and the 60–90 second section every second. Around 60–65 seconds the same flexing-man stock cutaway returns after a brief presenter shot. Nearby stock inserts change identity, background and lighting sharply. The presenter also recurs in very similar indoor compositions; that storyboard repetition is a separate issue. These are visual sampling findings, not a full audio/transcript or frame-by-frame review.

The placement fix addresses immediate repetition and interruption of generated video. It does not guarantee semantic relevance, identify re-encoded duplicates, redesign the storyboard, or fix burned-in captions. For contextual quality, review stock alongside the exact narration before approval; skip literal or stylistically inconsistent matches. The submitted MP4 is already composited: re-render from saved source assets to remove baked-in inserts cleanly.

## Validation

1,127 offline/local-media regression tests passed (13 dependency deprecation warnings). Focused editorial checks, ZIP integrity/manifest hashes, and a 7.0.54 code upgrade with a preserved runtime sentinel passed. No live Flow generation or download was performed for this release. Your full saved job assets were not available here, so the uploaded final video itself has not been re-rendered.

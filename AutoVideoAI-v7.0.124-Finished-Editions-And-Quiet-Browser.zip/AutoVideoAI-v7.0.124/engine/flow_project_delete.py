"""Exact-project UI deletion; navigation away alone never establishes success."""
import re
import time


def delete(bridge,url,expected_signatures=None,max_images=None):
    """Delete one exact Flow project after its local image evidence is verified.

    With a captured inventory, the live gallery must match it exactly. Without
    one, the live project must hold only images and no more than max_images,
    the number of images its verified local requests could have produced.
    """
    from .providers.flow_browser import FlowBrowser, FlowUIChanged, media_signature_matches
    wanted=FlowBrowser.normalize_project_url(url)
    if not wanted:
        raise FlowUIChanged('Flow project identity is invalid; nothing deleted')
    if not expected_signatures and (type(max_images) is not int or max_images<1):
        raise FlowUIChanged('Flow project deletion needs verified local image evidence; nothing deleted')
    bridge.ensure_project('Reviewed image cleanup',project_url=wanted)
    page=bridge._page
    def bound():
        if FlowBrowser.normalize_project_url(page.url)!=wanted:
            raise FlowUIChanged('Project identity changed; deletion stopped')
    bound()
    assets=bridge.media_assets()
    if not assets or any(a.get('kind')!='image' for a in assets):
        raise FlowUIChanged('Project contains non-image or unreadable assets; retained for review')
    if expected_signatures:
        actual=[a['sig'] for a in assets if a.get('sig')]
        if (len(actual)!=len(expected_signatures)
                or any(not any(media_signature_matches(sig,old) for old in expected_signatures) for sig in actual)):
            raise FlowUIChanged('Live project gallery differs from the saved captured inventory; retained')
    elif len(assets)>max_images:
        raise FlowUIChanged('Live project holds more images than its verified requests; retained for review')
    menu=bridge._try_resolve('project_actions',timeout_ms=2000)
    if menu is None:
        # Observed Oct-16 UI: the project-title row has its own more_vert menu.
        # Never fall back to an arbitrary toolbar/asset three-dot button.
        indexes=page.locator('button').evaluate_all(r'''buttons=>buttons.flatMap((b,i)=>{
          if(!b.getClientRects().length || !/more_vert|more_horiz/.test(b.textContent||''))return [];
          let p=b.parentElement;for(let n=0;p&&n<3;n++,p=p.parentElement){
           const text=(p.innerText||'').trim();
           if(text.length<160 && /\b[A-Z][a-z]{2}\s+\d{1,2}\s*[·-]\s*\d{1,2}:\d{2}/.test(text))return [i];
          }return [];
        })''')
        if not isinstance(indexes,list) or len(indexes)!=1:
            raise FlowUIChanged('Unique project-title menu could not be identified; nothing deleted')
        menu=page.locator('button').nth(indexes[0])
    success_pattern=re.compile(r'^(?:Project (?:has been )?deleted|Deleted project)[.!]?$',re.I)
    previous_success=page.get_by_text(success_pattern)
    if previous_success.count() and previous_success.first.is_visible(timeout=200):
        raise FlowUIChanged('A previous deletion notice is still visible; wait and review again')
    bound();menu.click(timeout=2500)
    # This combination distinguishes the project menu from a media tile menu. 7.0.124: poll instead of
    # `wait_for` on each item. A blocking wait on the FIRST item made a menu that was merely slow to
    # animate indistinguishable from the missing success toast at the end - the deletion stopped with
    # 'No explicit success confirmation' before Delete was ever clicked, so nothing was deleted and the
    # ledger could not say which of the two proofs had failed.
    deadline=time.monotonic()+5
    verified=False
    while time.monotonic()<deadline:
        try:
            items=[page.get_by_text(text,exact=True) for text in ('Rename','View bin','Delete')]
            if all(item.count()==1 and item.first.is_visible(timeout=200) for item in items):
                verified=True
                break
        except Exception:
            pass
        page.wait_for_timeout(150)
    if not verified:
        raise FlowUIChanged('Expected project menu is unavailable; nothing deleted')
    bound();page.get_by_text('Delete',exact=True).click(timeout=2500)
    dialogs=page.get_by_role('dialog')
    deadline=time.monotonic()+5
    while time.monotonic()<deadline:
        dialogs=page.get_by_role('dialog')
        if dialogs.count()==0:dialogs=page.get_by_role('alertdialog')
        if dialogs.count() and dialogs.first.is_visible(timeout=200):break
        notice=page.get_by_text(success_pattern)
        if notice.count() and notice.first.is_visible(timeout=200):
            return {'project_url':wanted,'status':'deleted','evidence':'visible_project_deleted_confirmation'}
        page.wait_for_timeout(200)
    if dialogs.count()==1 and dialogs.first.is_visible(timeout=500):
        dialog=dialogs.first;text=dialog.inner_text(timeout=1500)
        if not re.search(r'delete.{0,60}project|project.{0,60}delet',text,re.I|re.S):
            raise FlowUIChanged('Unexpected deletion dialog; no confirmation clicked')
        bound()
        confirm=dialog.get_by_role('button',name=re.compile(r'^Delete(?: project)?$',re.I))
        if confirm.count()!=1:raise FlowUIChanged('Unique project-delete confirmation unavailable')
        confirm.click(timeout=2500)
    # A disappeared page is not evidence of deletion. Require Flow's explicit
    # success text; missing confirmation remains uncertain in the local ledger.
    success=page.get_by_text(success_pattern)
    success.first.wait_for(state='visible',timeout=8000)
    return {'project_url':wanted,'status':'deleted','evidence':'visible_project_deleted_confirmation'}

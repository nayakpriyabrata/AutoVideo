"""Optional local end hold; never claims Flow generated a longer scene."""
from pathlib import Path
import subprocess
import time


def export_short_hold(video_path, seconds=8):
    from .render.ffmpeg_renderer import ffmpeg_exe, _probe_av_durations
    if type(seconds) is not int or seconds not in (8, 10, 12):
        raise ValueError('Mini Reel delivery must be 8, 10 or 12 seconds')
    source = Path(video_path).resolve()
    durations = _probe_av_durations(str(source)) or {}
    duration = float(durations.get('video') or 0)
    if not source.is_file() or not 7 <= duration <= 9:
        raise ValueError('Expected an approximately 8-second completed Flow clip; inspect the original')
    if seconds == 8:
        return str(source)
    output = source.with_name(f'{source.stem}-hold-{seconds}s-{time.time_ns()}.mp4')
    audio = ['-map', '0:a?', '-af', 'apad', '-c:a', 'aac'] if durations.get('audio') else ['-an']
    cmd = [ffmpeg_exe(), '-y', '-i', str(source), '-vf',
           f'tpad=stop_mode=clone:stop_duration={max(0, seconds-duration):.4f}',
           '-map', '0:v:0', *audio, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18',
           '-t', str(seconds), '-movflags', '+faststart', str(output)]
    try:
        result = subprocess.run(cmd, capture_output=True, timeout=120)
        measured = _probe_av_durations(str(output)) or {}
        if result.returncode or abs(float(measured.get('video') or 0)-seconds) > .15:
            raise RuntimeError('Local end-hold export failed; the original clip is preserved')
    except Exception:
        output.unlink(missing_ok=True)
        raise
    return str(output)

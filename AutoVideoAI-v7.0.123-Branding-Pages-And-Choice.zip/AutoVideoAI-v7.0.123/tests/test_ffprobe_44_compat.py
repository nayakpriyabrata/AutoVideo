"""Regression coverage for FFprobe 4.4 section selector incompatibility."""
import json
from types import SimpleNamespace
import engine.clipping as clips


def test_legacy_ffprobe_query_uses_supported_show_streams(monkeypatch):
    seen = []
    def fake_run(cmd, timeout):
        seen.append(cmd)
        return SimpleNamespace(returncode=0, stdout=json.dumps({'streams': [{'width': 320, 'height': 180, 'sample_aspect_ratio': '1:1'}]}))
    monkeypatch.setattr(clips, '_run', fake_run)
    assert clips._video_display_dimensions('source.mp4') == (320.0, 180.0)
    assert '-show_streams' in seen[0]
    assert 'stream_side_data' not in ' '.join(seen[0])


def test_rotation_and_pixel_aspect_still_applied(monkeypatch):
    def fake_run(cmd, timeout):
        return SimpleNamespace(returncode=0, stdout=json.dumps({'streams': [{'width': 320, 'height': 180, 'sample_aspect_ratio': '2:1', 'side_data_list': [{'rotation': -90}]}]}))
    monkeypatch.setattr(clips, '_run', fake_run)
    assert clips._video_display_dimensions('rotated.mp4') == (180.0, 640.0)


def test_invalid_video_still_rejected(monkeypatch):
    def fake_run(cmd, timeout):
        return SimpleNamespace(returncode=1, stdout='{}')
    monkeypatch.setattr(clips, '_run', fake_run)
    import pytest
    with pytest.raises(RuntimeError, match='Cannot read source video orientation'):
        clips._video_display_dimensions('invalid.mp4')

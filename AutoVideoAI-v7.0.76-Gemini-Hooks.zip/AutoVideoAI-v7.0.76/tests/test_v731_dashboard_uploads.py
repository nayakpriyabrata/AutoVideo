import io
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from PIL import Image


def uploaded_image(fmt='PNG', mime='image/jpeg'):
    buffer=io.BytesIO();Image.new('RGB',(50,60),'orange').save(buffer,format=fmt)
    return NS(type=mime,name='edited.jpg',getvalue=lambda:buffer.getvalue())


def test_gui_import_uses_decoded_format_not_browser_mime(tmp_path):
    from engine.studio_widgets import save_uploaded_image
    from engine.providers.flow_browser import FlowBrowser
    upload=uploaded_image();path=Path(save_uploaded_image(upload,tmp_path))
    assert path.suffix=='.png' and path.read_bytes()==upload.getvalue()
    wrong=tmp_path/'character-aanya-0.jpg';wrong.write_bytes(upload.getvalue())
    alias=FlowBrowser._media_upload_alias(str(wrong))
    assert alias.endswith('character-aanya-0.png')


def test_edit_character_saves_uploaded_photo_without_replace_checkbox(tmp_path,monkeypatch):
    import streamlit as st
    import engine.content_library as module
    from tests.test_presentation_dashboard import dashboard,navigate
    library=module.CharacterLibrary(tmp_path/'characters')
    character=library.create('Aanya','An original character with a friendly smiling face.',original_confirmed=True)
    monkeypatch.setattr(module,'CharacterLibrary',lambda *a,**kw:library)
    original_uploader=st.file_uploader
    upload=uploaded_image()
    monkeypatch.setattr(st,'file_uploader',lambda label,*a,**kw:[upload] if label=='New reference photos' else original_uploader(label,*a,**kw))
    _,app=dashboard(tmp_path,monkeypatch);navigate(app,'CHARACTER LIBRARY')
    assert not next(x for x in app.checkbox if x.label=='Replace reference photos').value
    next(x for x in app.button if x.label=='Update character').click().run()
    assert not app.exception,[e.message for e in app.exception]
    edited=library.get(character['id'])
    assert edited['version']==2 and len(edited['references'])==1
    assert Path(edited['references'][0]['path']).suffix=='.png'
    assert Path(edited['references'][0]['path']).read_bytes()==upload.getvalue()


def test_queue_resume_mounts_one_monitor_and_log_copy_survives(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard,navigate
    import engine.job_monitor as monitor
    f,app=dashboard(tmp_path,monkeypatch)
    job=f.create_job('A saved pending job',target_seconds=20,dry_run=True)
    log=Path(f.pm.job_dir(job))/'logs/runtime.log';log.write_text('saved log\n')
    app.session_state['job_id']=job;app.run();navigate(app,'QUEUE')
    calls=[];monkeypatch.setattr(monitor,'start',lambda factory,key:calls.append(key) or True)
    next(x for x in app.button if x.label=='▶️ Resume / continue job').click().run()
    assert calls==[job] and not app.exception
    assert len([x for x in app.button if x.label=='Capture logs for copying'])==1
    next(x for x in app.button if x.label=='Capture logs for copying').click().run()
    assert not app.exception
    assert 'saved log' in next(x.value for x in app.text_area if x.label=='Captured logs · select all and copy')
    app.run();assert not app.exception
    next(x for x in app.sidebar.button if x.label=='Gallery & Downloads').click().run()
    assert not app.exception and app.session_state['autovideo_current_page']=='HISTORY'


class Nodes:
    def __init__(self,nodes=()):self.nodes=list(nodes)
    def count(self):return len(self.nodes)
    def nth(self,i):return self.nodes[i]
    @property
    def first(self):return self.nodes[0]


def test_gemini_review_uses_visible_plus_and_upload_files_not_hidden_inputs(tmp_path):
    from engine.providers.gemini_web import GeminiWebBrowser
    proxy=tmp_path/'review.mp4';proxy.write_bytes(b'local proxy')
    b=GeminiWebBrowser.__new__(GeminiWebBrowser);events=[];menu={'open':False}
    add=NS(is_visible=lambda **kw:True,click=lambda **kw:menu.update(open=True))
    upload=NS(is_visible=lambda **kw:True,click=lambda **kw:events.append('Upload files'),wait_for=lambda **kw:None)
    filename=NS(wait_for=lambda **kw:events.append('filename visible'))
    class Chooser:
        value=NS(set_files=lambda p:events.append(Path(p).name))
        def __enter__(self):return self
        def __exit__(self,*args):pass
    def text(name,**kw):
        if isinstance(name,str):return Nodes([filename])
        return Nodes([upload] if menu['open'] else [])
    def buttons(role,name):
        assert role=='button' and name.search('Open upload file menu')
        return Nodes([add])
    b._page=NS(get_by_text=text,get_by_role=buttons,
               locator=lambda s:pytest.fail('Hidden file input must not be selected'),
               expect_file_chooser=lambda **kw:Chooser())
    b._attach_review_video([proxy])
    assert events==['Upload files','review.mp4','filename visible']


def test_gemini_missing_upload_menu_stops_before_file_or_prompt(tmp_path):
    from engine.providers.gemini_web import GeminiWebBrowser,GeminiWebUIChanged
    proxy=tmp_path/'review.mp4';proxy.write_bytes(b'local proxy')
    b=GeminiWebBrowser.__new__(GeminiWebBrowser)
    b._page=NS(get_by_text=lambda *a,**kw:Nodes(),get_by_role=lambda *a,**kw:Nodes(),
               locator=lambda *a:Nodes(),expect_file_chooser=lambda **kw:pytest.fail('No chooser may open'))
    with pytest.raises(GeminiWebUIChanged,match='menu is unavailable'):b._attach_review_video([proxy])

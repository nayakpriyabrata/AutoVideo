# Update 7.0.68

Selected language editions now render as finished videos. Each additional English, Hindi or Odia edition uses the approved picture, its own reviewed narration, timed cards, captions and its chosen channel profile. A missing or voiceless edition is refused instead of exported with English audio. See [the 7.0.68 render guide](LANGUAGE_EDITIONS_RENDER_V7_0_68.md).

# Update 7.0.67

Guided Studio now separates the master script from its output language editions. Choose the master/primary language and any additional English, Hindi or Odia editions before drafting. Gemini drafts one story, selected editions are localized for review, and the exact approved scripts are used to prepare every TTS track before any timed-card request. See [the language-edition guide](LANGUAGE_EDITIONS_V7_0_67.md).

# Update 7.0.66

Channel Desk adds editorial packaging drafts, final-file watch/listen evidence and owned-channel performance cohorts. Guided Studio now prepares ALL selected voices before ANY language card request, in one action. See [workflow guide](CHANNEL_DESK_V7_0_66.md) and [independent audit](CHANNEL_MANAGER_AUDIT_V7_0_66.md).

# Update 7.0.65

Speech-anchored Gemini cards, prepared language editions with a clean visual master, optional Gemini video shots (experimental, cap four), and eligible image-project cleanup. Read [the release guide](SPEECH_GEMINI_CLEANUP_V7_0_65.md) before enabling browser features.

**v7.0.63:** Finishing Studio selects a separate channel profile for each language edition, while one reviewed music track can be shared. Large renders report stage timing and use faster intermediate encodes; new jobs default to Fast 1080p. See [CHANNEL_RENDER_SPEED_V7_0_63.md](CHANNEL_RENDER_SPEED_V7_0_63.md).

**v7.0.62:** Finishing Studio adds saved channel profiles, reviewed multilingual finishing plans, local intro/outro, transparent text cards, subtle channel logo motion, and licensed ducked music. See [FINISHING_STUDIO_V7_0_62.md](FINISHING_STUDIO_V7_0_62.md).

# AutoVideoAI v7.0.61

See `EXACT_VIDEO_RECOVERY_V7_0_61.md` for immediate Flow blob capture, reviewed local MP4 recovery and upgrade steps.

# AutoVideoAI v7.0.60

See `CLIP_MUSIC_FLOW_CLEANUP_V7_0_60.md` for Clip Studio music and verified Flow project cleanup.

# AutoVideoAI v7.0.53

See [the current gallery, cast and Flow lifecycle guide](GALLERY_FLOW_LIFECYCLE_V7_0_53.md) for the cumulative updater and recovery instructions.

# AutoVideoAI v7.0.52

See [the current reliability, fidelity and upgrade guide](RELIABILITY_AND_FIDELITY_V7_0_52.md) before production. New fixes preserve authored scenes, contain image replacement, improve music fallback and add optional sound-hook exports. Live Google account behavior still needs verification.

# v7.0.51 — Reels, long videos and music-only scene plans

See [VISUAL_ONLY_REELS_V7_0_51.md](VISUAL_ONLY_REELS_V7_0_51.md). Create → Reels & Long Videos exposes normal vertical Reels/Shorts and landscape long videos. Music-only and silent modes draft timed visual directions with no spoken narration; voiceover mode remains available. This release includes v7.0.50 reliability fixes.

# v7.0.50 reliability audit

See [RELIABILITY_AUDIT_V7_0_50.md](RELIABILITY_AUDIT_V7_0_50.md) for this release, upgrade steps and verification limits. It fixes odd-dimension Gemini proxies, improves attachment controls, validates exact B-roll eligibility before recreation, and protects background review/render state. Automatic Flow project deletion is disabled pending reliable verification. Older release descriptions below are historical and do not override this change.

# AutoVideoAI v7.0.49 — persistent clip rendering and reviewed cleanup

Read [PERSISTENT_RENDER_CLEANUP_V7_0_49.md](PERSISTENT_RENDER_CLEANUP_V7_0_49.md) for durable Clip Studio render monitoring, resumable per-clip checkpoints, status-based cleanup, and guarded Google Flow project deletion.

# AutoVideoAI v7.0.47 — reliable mixed B-roll batch approval

Read [BROLL_BATCH_APPROVAL_V7_0_47.md](BROLL_BATCH_APPROVAL_V7_0_47.md) for the cumulative update and the fix for reviews containing both available assets and unmatched/duplicate-rejected slots.

# AutoVideoAI v7.0.46 — persistent Clip Studio job history

Read [CLIP_JOB_HISTORY_V7_0_46.md](CLIP_JOB_HISTORY_V7_0_46.md) for the cumulative update and the new Saved clip jobs selector.

# AutoVideoAI v7.0.45 — saved B-roll review recovery

Read [BROLL_REVIEW_RESUME_V7_0_45.md](BROLL_REVIEW_RESUME_V7_0_45.md) for the cumulative v7.0.43/v7.0.44 update and safe reopening of an existing Clip Studio B-roll review.

# AutoVideoAI v7.0.44 — video download recovery

Read [VIDEO_DOWNLOAD_RECOVERY_V7_0_44.md](VIDEO_DOWNLOAD_RECOVERY_V7_0_44.md) for the v7.0.43 code-only update and recovering an existing Mini Reel.

# AutoVideoAI v7.0.43 — durable Flow image recovery

Read [DURABLE_FLOW_RECOVERY_V7_0_43.md](DURABLE_FLOW_RECOVERY_V7_0_43.md) for the code-only upgrade from v7.0.42, recovery behavior, and validation limits.

# AutoVideoAI v7.0.41 Flow recovery evidence audit

A **read-only** diagnostic tool, not a live Flow recovery implementation. It does not launch browsers, send prompts, resume jobs, change files, or consume credits.

From your AutoVideoAI-v7.0.41 directory:

```bash
python3 tools/flow_recovery_audit.py outputs/20261012-132342-littile-kanha-playing-ra-a7e2 > /tmp/little-kanha-recovery-audit.json
```

Extract `tools/flow_recovery_audit.py` into the installation's `tools/` directory. Never overwrite or modify the job while it is running. JSON report excludes journal prompts and token values but contains project IDs and relative job filenames. Redact as needed.

Exact filenames prove only that a file exists at an expected name; they do not prove semantic quality. Duplicate flags are hash-identical files reused across separate shots; some cross-folder duplicates are expected.
# v7.0.64 · reviewed cards and reliable local music

Guided Studio can request sparse editorial text cards from Gemini Web separately from the script, review their timing, and clean up the temporary chat after capture. Choose a specific track in the shared music library for local background music; a requested track is checked before visual generation for voiceover and music-only jobs. Captions and imported narration remain optional. The chosen primary channel profile applies its name and logo, while selected language editions are saved as a finishing handoff. See `QUALITY_MUSIC_CARDS_V7_0_64.md` for limitations and upgrade instructions.


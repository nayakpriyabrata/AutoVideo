"""
AutoVideoAI Studio dashboard.
The Streamlit routes are grouped into user-facing workspaces in NAV_GROUPS.
"""
import os
import sys
import glob
import hashlib
import json
import threading
import time
import yaml
import streamlit as st

def broll_search_progress_ui():
    bar=st.progress(0)
    label=st.empty()
    def update(stage,percent,info=''):
        bar.progress(min(1.0,max(0.0,(float(percent)-85)/3)))
        label.caption(f'{stage} · {info}')
    update.allow_background=False
    return update


def compact_video(data):
    """Compact inline player; native fullscreen controls remain available."""
    st.video(data, width=320)

import pandas as pd
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
if not any(os.getenv(k) for k in ("GEMINI_API_KEY", "GROQ_API_KEY", "OPENAI_API_KEY", "XAI_API_KEY")):
    here = Path(__file__).resolve().parent
    candidates = [Path.home() / ".config" / "autovideoai" / ".env"]
    try:
        candidates += sorted(here.parent.glob("AutoVideoAI-v*/.env"),
                             key=lambda q: q.stat().st_mtime, reverse=True)
    except Exception:
        pass
    for env_path in candidates:
        try:
            if env_path.is_file() and env_path.resolve() != (here / ".env").resolve():
                load_dotenv(env_path, override=False)
                if any(os.getenv(k) for k in ("GEMINI_API_KEY", "GROQ_API_KEY", "OPENAI_API_KEY", "XAI_API_KEY")):
                    break
        except Exception:
            continue
from engine.env_config import load_environment
ENV_REPORT = load_environment(Path(__file__).resolve().parent)

from engine.version import get_version
from engine.support_report import build_support_report
APP_VERSION = get_version()
st.set_page_config(page_title=f"AutoVideoAI · Studio v{APP_VERSION}", page_icon="🎬", layout="wide")

from engine.studio_ui import apply_theme, option_index, cleanup_report, progress_percent
apply_theme(st, APP_VERSION)

from engine.factory import Factory, AssistedNeeded, load_preset
from engine.project.database import JobDB
from engine.routing.provider_router import NeedsDecision
from engine.studio_config import DEFAULTS, THEMES, config_to_factory_kwargs

F = Factory()
from engine.auto_resume import ensure_supervisor as _ensure_auto_resume
_ensure_auto_resume(F)
DB = JobDB()


def invalidate_script_review():
    st.session_state['studio-review-approved'] = False


def remember_studio_duration():
    mode = st.session_state['studio-mode']
    saved = dict(st.session_state.get('studio-saved-durations', {}))
    saved[mode] = st.session_state['studio-duration-' + mode]
    st.session_state['studio-saved-durations'] = saved
    invalidate_script_review()


def _flow_pause_setting_default():
    """Read only the non-sensitive global opt-in preference for new jobs."""
    try:
        with open("config/user_settings.yaml", encoding="utf-8") as handle:
            value = (yaml.safe_load(handle) or {}).get("flow_pause_on_unresolved_request", False)
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "yes", "on"}
        return bool(value)
    except Exception:
        return False


PROFILES = ["STORYBOARD_ECONOMY", "FLOW_CINEMATIC", "FLOW_BALANCED", "FLOW_ECONOMY", "LOCAL_FREE", "FREE_HYBRID", "MANUAL_DIRECTOR"]
PRESETS = sorted([os.path.splitext(f)[0] for f in os.listdir("config/presets") if f.endswith(".yaml")])
CONTENT_TYPES = ["education", "storytelling", "cinematic_story", "documentary", "motivation",
                 "technology", "history", "finance", "kids_story", "advertisement",
                 "product_demo", "news_explainer"]
VOICES = ["en-IN-PrabhatNeural", "en-IN-NeerjaNeural", "en-US-GuyNeural", "en-US-AriaNeural",
          "en-GB-RyanNeural", "en-GB-SoniaNeural", "hi-IN-MadhurNeural", "hi-IN-SwaraNeural"]

if "job_id" not in st.session_state:
    st.session_state.job_id = None

# ---------------- sidebar ----------------
mode_badge = {"STORYBOARD_ECONOMY": "🌱", "FLOW_CINEMATIC": "💎", "FLOW_BALANCED": "⚖️", "FLOW_ECONOMY": "💰",
              "LOCAL_FREE": "🖥️", "FREE_HYBRID": "🆓", "MANUAL_DIRECTOR": "🎥"}
NAV_GROUPS = {
    "Create": ["STUDIO", "MINI REELS", "MUSIC VIDEO", "CREATE"],
    "Review & Render": ["STORYBOARD", "DIRECTOR REVIEW", "PRODUCTION QC", "ASSETS", "RENDER"],
    "Jobs & Recovery": ["QUEUE", "HISTORY", "FLOW SESSION"],
    "Content & Delivery": ["CLIP STUDIO", "CONTENT INBOX", "CHARACTER LIBRARY", "AI RECREATE", "FINISHING STUDIO", "CHANNEL DESK", "PUBLISHING DESK"],
    "Setup & Legacy": ["SETTINGS", "Quick (v2)"],
}
PAGE_TO_GROUP = {item: group for group, items in NAV_GROUPS.items() for item in items}
PAGE_LABELS = {
    "STUDIO": "Reels & Long Videos",
    "MINI REELS": "Mini Reels",
    "MUSIC VIDEO": "Music Video",
    "CREATE": "Advanced Create",
    "STORYBOARD": "Storyboard",
    "DIRECTOR REVIEW": "Director Review",
    "PRODUCTION QC": "Production QC",
    "ASSETS": "Assets",
    "RENDER": "Render & B-roll",
    "QUEUE": "Queue & Resume",
    "HISTORY": "Gallery & Downloads",
    "FLOW SESSION": "Flow Session",
    "CLIP STUDIO": "Clip Studio",
    "CONTENT INBOX": "Content Inbox",
    "CHARACTER LIBRARY": "Character Library",
    "AI RECREATE": "AI Recreate",
    "CHANNEL DESK": "Channel Desk",
    "PUBLISHING DESK": "Publishing Desk",
    "FINISHING STUDIO": "Finishing Studio",
    "SETTINGS": "Settings",
    "Quick (v2)": "Quick (legacy v2)",
}
def open_gallery():
    st.session_state['autovideo_current_page']='HISTORY'
    st.session_state['autovideo_workspace']='Jobs & Recovery'
    st.session_state['autovideo_page_jobs-and-recovery']='HISTORY'
st.sidebar.button('Gallery & Downloads', on_click=open_gallery, key='open-gallery')
current_page = st.session_state.get("autovideo_current_page", "STUDIO")
default_group = PAGE_TO_GROUP.get(current_page, "Create")
if st.session_state.get("autovideo_workspace") not in NAV_GROUPS:
    st.session_state["autovideo_workspace"] = default_group
workspace = st.sidebar.selectbox(
    "Workspace", list(NAV_GROUPS), index=None,
    key="autovideo_workspace")
page_options = NAV_GROUPS[workspace]
page_key = "autovideo_page_" + workspace.lower().replace(" ", "-").replace("&", "and")
preferred_page = st.session_state.get(page_key, current_page)
page_index = page_options.index(preferred_page) if preferred_page in page_options else 0
if st.session_state.get(page_key) not in page_options:
    st.session_state[page_key] = page_options[page_index]
page = st.sidebar.radio(
    "Page", page_options, index=None,
    format_func=lambda value: PAGE_LABELS.get(value, value), key=page_key)
st.session_state["autovideo_current_page"] = page
st.sidebar.caption(f"{workspace} · {PAGE_LABELS.get(page, page)}")
external_video_mode_ui = st.sidebar.checkbox('New jobs: generate video shots externally', value=False,
    help='Plan prompts and incoming paths, then wait for reviewed MP4 uploads. Applies to new full video jobs; Mini Reels is separate.')
st.sidebar.divider()
indexed_jobs = DB.list(5000)
jobs = [j for j in indexed_jobs if (Path(F.pm.job_dir(j["job_id"]))/"production_manifest.json").is_file()]
missing_jobs = [j for j in indexed_jobs if not Path(F.pm.job_dir(j["job_id"])).exists()]
if missing_jobs:
    st.sidebar.caption(f"{len(missing_jobs)} missing job entries · review in Settings")
job_ids = [j["job_id"] for j in jobs]
sel = st.sidebar.selectbox("Active job", ["(none)"] + job_ids,
                           index=([ "(none)"] + job_ids).index(st.session_state.job_id) if st.session_state.job_id in job_ids else 0)
st.session_state.job_id = None if sel == "(none)" else sel
if st.session_state.job_id:
    j = DB.get(st.session_state.job_id)
    if j:
        st.sidebar.caption(f"Status: **{j['status']}** | {j['profile']} | ✅{j['accepted_shots']} ❌{j['rejected_shots']}")


_pause_panels = set()


def pause_panel(job_id, reason=""):
    """Actionable recovery controls for a durable paused/assisted job."""
    if job_id in _pause_panels:
        return
    _pause_panels.add(job_id)
    try:
        state = F.recovery_state(job_id, reason)
    except Exception:
        state = {}
    if not state:
        st.info("No unfinished Flow shot was found for this job.")
        return

    accepted = state.get("accepted_shots", 0)
    total = state.get("total_shots", 0)
    shot_id = state.get("shot_id", "")
    kind = state.get("kind", "flow_recovery")
    st.warning(f"Job needs recovery at `{shot_id}` · {accepted}/{total} accepted shots are saved.")
    st.write(state.get("reason") or reason or "Flow needs attention before the job can continue.")
    if kind == "flow_usage_limit":
        st.info("Flow reported a usage/rate limit. Your displayed credit balance can still be positive. "
                "Do not create a new job: wait for access to reset, or recover a video that already exists in the project.")
    project_url = state.get("flow_project_url")
    if project_url:
        st.markdown(f"[Open the saved Flow project]({project_url})")

    safe_recovery = bool(state.get("safe_automatic_recovery"))
    try:
        import glob, os, json
        from pathlib import Path
        request_files = sorted(glob.glob(os.path.join(F.pm.dirs(job_id)['flow'], 'shots', shot_id, 'take_*.mp4.flow-request.json')))
        recorded_video = len(request_files) == 1 and json.loads(Path(request_files[0]).read_text(encoding='utf-8')).get('kind') == 'video'
    except (OSError, ValueError, TypeError, AttributeError):
        recorded_video = False
    safe_recovery = safe_recovery or recorded_video
    if recorded_video:
        with st.expander('Recover a visually reviewed video if its old fingerprint no longer matches'):
            st.caption('Open the intended video thumbnail in the saved project, verify its content belongs to this shot, and copy its /edit/ URL. Recovery downloads that video only and still runs QC. The global Download project menu is not used.')
            reviewed_url = st.text_input('Exact Flow video editor URL', key=f'reviewed-asset-{job_id}-{shot_id}')
            approved_asset = st.checkbox(f'I reviewed this video and it belongs to {shot_id}', key=f'reviewed-asset-approved-{job_id}-{shot_id}')
            if st.button('Download reviewed video — 0 new generation credits',
                         disabled=not reviewed_url or not approved_asset, key=f'recover-reviewed-{job_id}-{shot_id}'):
                try:
                    result = F.recover_flow_video(job_id, shot_id=shot_id, asset_url=reviewed_url.strip(), asset_reviewed=True)
                    if result.get('accepted'):
                        st.success('Recovered and passed QC. Resume the saved job to continue.')
                    else:
                        st.warning('Downloaded, but QC did not accept this take. The job remains unresolved.')
                except Exception as exc:
                    st.error(f'Reviewed video download failed: {exc}')
            st.caption('If the Flow browser repeatedly closes during Download, download this exact video in your normal browser and import the MP4 here. The saved request and source file are preserved.')
            reviewed_file = st.file_uploader('Downloaded MP4 for this shot', type=['mp4'],
                                             key=f'reviewed-local-video-{job_id}-{shot_id}')
            if st.button('Import reviewed MP4 and run QC — 0 new credits',
                         disabled=not (reviewed_file and reviewed_url and approved_asset),
                         key=f'import-reviewed-video-{job_id}-{shot_id}'):
                import tempfile
                from engine.flow_local_video_recovery import import_reviewed_video
                try:
                    with tempfile.TemporaryDirectory(prefix='autovideo-reviewed-flow-') as temp:
                        staged = Path(temp)/'reviewed.mp4'
                        staged.write_bytes(reviewed_file.getvalue())
                        result = import_reviewed_video(F, job_id, shot_id, staged,
                                                       reviewed_url.strip(), reviewed=True)
                    if result['resolved']:
                        st.success('Exact reviewed MP4 passed QC and resolved the saved request. Resume this job.')
                    else:
                        st.warning(result['message'])
                    st.json({'shot': shot_id, 'new_credits': 0, 'qc': result.get('qc', {})})
                except Exception as exc:
                    st.error(f'Reviewed local video import failed: {exc}')
    if safe_recovery:
        st.markdown("**Safest next step:** recover the exact saved video request. This does not submit a prompt and requests **0 new generation credits**.")
        c1, c2 = st.columns(2)
        if c1.button("♻️ Recover proven-new Flow video — 0 new credits",
                     key=f"recover-existing-{job_id}-{shot_id}", type="primary"):
            with st.spinner("Scanning the saved Flow project for a new completed video (up to 120 seconds)..."):
                try:
                    result = F.recover_flow_video(job_id, shot_id=shot_id or None, wait_seconds=120)
                    if result.get("accepted"):
                        st.success(f"Recovered `{result['shot_id']}` and passed QC. Click Resume to continue/render.")
                    else:
                        st.warning("A video was recovered, but QC rejected it. Review the QC report before retrying recovery.")
                    st.json({"shot": result.get("shot_id"), "new_credits": 0,
                             "qc": result.get("qc", {})})
                except Exception as e:
                    st.error(f"Recovery did not find a usable new video yet: {e}")
        resume_clicked = c2.button("▶️ Resume saved job", key=f"resume-paused-{job_id}")
    else:
        policy = "enabled" if state.get("pause_on_unresolved") else "disabled"
        policy_text = ("Batch exact-frame recovery is enabled. Completed frames are cached; unresolved frames are listed together. "
                       if kind == "flow_frame_batch" else f"Saved automatic-pause policy: {policy}. ")
        st.info(policy_text + "Save a changed checkbox choice before Resume. "
                "Resume reconciles saved images and videos before continuing. Completed downloads are reused after browser interruptions. "
                "If image replacement is enabled, recovery may create one replacement per image within the saved job limit. "
                "See logs/resume-reconciliation.json for unresolved requests.")
        resume_clicked = st.button("▶️ Retry saved request and resume",
                                   key=f"resume-paused-{job_id}", type="primary")
    if resume_clicked:
        st.session_state.pending_resume_job = job_id
        st.rerun()

    st.caption("CLI recovery (safe to repeat):")
    # Old saved pause states may still contain the retired manual MP4 action.
    actions = [a for a in state.get("actions", [])
               if " v3 associate " not in a.get("command", "")]
    if actions:
        st.code("\n".join(a.get("command", "") for a in actions if a.get("command")), language="bash")
    with st.expander("Export pause diagnostics — no browser or generation requests"):
        st.caption("Includes the pause reason, recent log lines and pending Flow request evidence. "
                   "Excludes .env, settings, browser profiles and media; redacts known credentials and signed URL values. "
                   "Review the report before sharing it.")
        try:
            report = build_support_report(F.pm.job_dir(job_id))
            st.download_button("⬇️ Download redacted pause report", json.dumps(report, indent=2, ensure_ascii=False),
                               file_name=f"{job_id}-support-report.json", mime="application/json",
                               key=f"support-report-{job_id}")
        except (ValueError, OSError) as exc:
            st.warning(f"Diagnostic export unavailable: {exc}")
        st.code(f"python3 cli.py v3 support-report {job_id}", language="bash")

    with st.expander('Resolve an ambiguous saved image — review only'):
        from engine.flow_recovery_review import candidates, bind_reviewed
        try:
            options=candidates(F.pm.job_dir(job_id))
            if options:
                st.caption('Use only when automatic matching could not prove the request identity. Compare these recorded gallery prompts with the requested scene. Binding saves evidence; it never generates a replacement.')
                pick=st.selectbox('Recorded image candidate',range(len(options)),format_func=lambda i:options[i]['journal']+' · '+options[i]['prompt'][:90],key='recover-choice-'+job_id)
                st.code(options[pick]['prompt'])
                verified=st.checkbox('I verified this is the exact requested scene in the saved Flow project',key='recover-verified-'+job_id)
                if st.button('Bind reviewed prompt for download-only Resume',disabled=not verified,key='recover-bind-'+job_id):
                    st.json(bind_reviewed(F.pm.job_dir(job_id),options[pick]))
            else:st.caption('No unreviewed readable candidates remain. Saved prompt bindings are reused automatically on Resume; requests without a match remain protected.')
        except (ValueError,OSError) as error:st.warning(str(error))


def show_quiet_browser_control():
    if st.sidebar.button('Show quiet browser · same session'):
        try:
            from engine.quiet_browser import show_browser
            show_browser()
            st.sidebar.success('Local browser viewer opened. Close the viewer to hide it; production continues.')
        except Exception as error: st.sidebar.error(str(error))

show_quiet_browser_control()


@st.fragment(run_every=2)
def monitor_job(job_id, surface='queue'):
    from engine.job_monitor import snapshot
    view = snapshot(F.pm.job_dir(job_id))
    row = DB.get(job_id) or {}
    event = view['progress']
    state = 'Running / waiting for production slot' if view['running'] else (view['result'] or {}).get('status', row.get('status', 'saved'))
    st.subheader('Job monitor')
    st.caption(job_id + ' · ' + str(state))
    if event:
        st.progress(progress_percent(event.get('percent', 0)))
        st.write(event.get('stage', ''), event.get('info', ''), '· elapsed', event.get('elapsed', ''))
    if view['error']:
        st.error(view['error'])
    from engine.auto_resume import load as load_auto_resume, describe as describe_auto_resume
    auto_status = describe_auto_resume(load_auto_resume(F.pm.job_dir(job_id)))
    if auto_status:
        if 'stopped' in auto_status.lower():
            st.error(auto_status)
        else:
            st.info(auto_status)
    if view['result']:
        result = view['result']
        message = str(result.get('message') or result.get('video') or result.get('status'))
        if result.get('status') == 'failed': st.error(message)
        elif result.get('status') == 'paused': st.warning(message)
        else: st.success(message)
    if view['logs']:
        with st.expander('Live logs', expanded=True):
            text = '\n'.join(view['logs'])
            widget_scope = surface+'-'+job_id
            if st.button('Capture logs for copying', key='capture-logs-'+widget_scope):
                st.session_state['log-copy-'+job_id] = text
            captured = st.session_state.get('log-copy-'+job_id)
            if captured is not None:
                st.text_area('Captured logs · select all and copy', value=captured,
                             height=240, key='log-text-'+widget_scope+'-'+str(hash(captured)))
                st.caption('This captured text stays fixed while the live monitor continues.')
            st.code(text, language='text')
            log_path = Path(F.pm.job_dir(job_id))/'logs/runtime.log'
            if log_path.is_file():
                st.download_button('Download complete runtime log', data=log_path.read_bytes(),
                                   file_name=job_id+'-runtime.log', mime='text/plain', key='download-logs-'+widget_scope)
    if not view['running'] and row.get('final_path') and Path(row['final_path']).is_file():
        compact_video(row['final_path'])
        from engine.audio.hooks import hook_panel
        hook_panel(st, row['final_path'], 'job-hooks-'+surface+'-'+job_id)
    st.caption('Changing theme or workspace keeps this job running. Queue reconnects to its saved progress and logs. Keep Studio running until the job finishes.')


@st.fragment(run_every=2)
def monitor_clip_render(review_path):
    from engine.clip_render_jobs import snapshot, start
    view = snapshot(review_path)
    if not view['exists']:
        return
    state = view['state']
    status = str(state.get('status') or 'saved')
    st.subheader('Clip render monitor')
    st.caption(Path(review_path).parent.name + ' · ' + status)
    st.progress(progress_percent(state.get('percent', 0)))
    st.write(state.get('stage', ''), state.get('info', ''))
    total_clips = int(state.get('total_clips') or 0)
    completed_clips = min(total_clips, int(state.get('completed_clips') or 0))
    if total_clips:
        a, b, c = st.columns(3)
        a.metric('Completed', f'{completed_clips}/{total_clips}')
        b.metric('Remaining', max(0, total_clips - completed_clips))
        c.metric('Progress', f"{float(state.get('percent') or 0):.1f}%")
    if status == 'failed':
        st.error(state.get('error') or 'Clip render failed; saved work is retained.')
    elif status == 'interrupted':
        st.warning(state.get('info'))
    elif status == 'completed':
        st.success(state.get('info') or 'Render completed.')
    if status in {'failed', 'interrupted'}:
        if st.button('Resume unfinished clip render', key='resume-clip-render-' + hashlib.sha256(review_path.encode()).hexdigest()[:16]):
            start(review_path)
            st.rerun()
    outputs = [path for path in state.get('outputs', []) if os.path.isfile(path)]
    for output in outputs:
        compact_video(output)
        with open(output, 'rb') as handle:
            st.download_button('Download ' + os.path.basename(output), handle,
                               file_name=os.path.basename(output),
                               key='clip-render-download-' + hashlib.sha256(output.encode()).hexdigest()[:16])
    if view['logs']:
        with st.expander('Live render log', expanded=status in {'queued', 'running', 'failed'}):
            st.code('\n'.join(view['logs']), language='text')
    st.caption('You may close this browser tab or change workspaces; rendering continues in the Studio process. If Studio itself stops, reopen this saved clip job and choose Resume.')


def run_with_ui(job_id, dry_label):
    from engine.job_monitor import start
    if not start(F, job_id):
        st.info('This job is already running. Watching its existing progress; no second run was started.')
    st.session_state['job_id'] = job_id
    # Queue already has a durable monitor. Do not mount a second fragment after
    # clicking Resume; its widgets would collide on subsequent fragment refresh.
    if page != 'QUEUE':
        monitor_job(job_id, surface='launch')
    else:
        st.rerun()


def presentation_editor(job_id):
    from engine.presentation import resolve_presentation
    current = F._settings(job_id)
    recipe = resolve_presentation(current)
    with st.expander("Audio, captions and branding · render settings", expanded=False):
        st.caption("These controls affect rendering only. They preserve accepted takes, Flow bindings and pending request journals. Speech captions are separate from text cards.")
        modes = ["Voiceover", "Music only", "Silent"]
        initial_mode = "Voiceover" if recipe.voiceover else ("Music only" if recipe.music_mode != "off" else "Silent")
        edit_audio_mode = st.radio("Output audio mode", modes, index=modes.index(initial_mode),
                                   horizontal=True, key=f"edit-audio-mode-{job_id}")
        voice_on = edit_audio_mode == "Voiceover"
        with st.form(f"presentation-{job_id}"):
            a, b, c = st.columns(3)
            a.caption("Voice synthesis enabled" if voice_on else "No voiceover / speech captions")
            cards_on = b.checkbox("Include text cards", value=recipe.text_cards)
            styles = ["auto", "bold", "playful", "clean"]
            card_style = c.selectbox("Card style", styles, index=option_index(styles, recipe.card_style))
            d, e = st.columns(2)
            music_modes = ["off", "auto", "local", "browser", "generated", "reliable"]
            music_default = "auto" if edit_audio_mode == "Music only" and recipe.music_mode == "off" else recipe.music_mode
            music_mode = d.selectbox("Background music", music_modes, index=option_index(music_modes, music_default), disabled=edit_audio_mode == "Silent")
            music_path = e.text_input("Licensed local music path", value=recipe.music_path)
            f, g = st.columns(2)
            cap_modes = ["auto", "full", "none"]
            cap_display = f.selectbox("Speech captions", cap_modes, index=option_index(cap_modes, str(current.get('caption_display', 'auto'))), disabled=not voice_on)
            volume_default = .55 if not voice_on and recipe.voiceover else recipe.music_volume
            volume = g.slider("Music gain", 0.0, 1.0, volume_default, .01)
            h, i = st.columns(2)
            sounds = h.checkbox("Sound effects", value=recipe.sound_effects if voice_on else False, disabled=edit_audio_mode == "Silent")
            ambience = i.checkbox("Ambience", value=recipe.ambience if voice_on else False, disabled=edit_audio_mode == "Silent")
            channel_edit = st.text_input("Channel name for watermark", value=str(current.get("channel_name", "")))
            watermark_edit = st.checkbox("Show channel watermark", value=bool(current.get("watermark", False)))
            from engine.brand_logo import logo_controls
            logo_edit, logo_fraction = logo_controls(st, 'job-brand-'+job_id, enabled=watermark_edit)
            logo_size_edit = {.12:'Small', .18:'Medium', .25:'Large'}[logo_fraction]
            caption_styles = ["auto", "OPUS", "HORMOZI", "MINIMAL", "KIDS", "DOCUMENTARY", "CINEMATIC", "KARAOKE", "TECH"]
            caption_style_edit = st.selectbox("Speech caption style", caption_styles, index=option_index(caption_styles, current.get("caption_template", "auto")))
            st.caption("Playful card style adds a colourful watermark that fades open and closed. OPUS matches the larger Clip Studio captions.")
            if st.form_submit_button("Save audio & text choices"):
                F.set_presentation_options(job_id, voiceover_enabled=voice_on, watermark=watermark_edit, channel_name=channel_edit, channel_logo=logo_edit or current.get("channel_logo", ""), channel_logo_size=logo_size_edit, caption_template=caption_style_edit,
                                           text_cards_enabled=cards_on, text_card_style=card_style,
                                           background_music="off" if edit_audio_mode == "Silent" else music_mode, background_music_path=music_path,
                                           caption_display=cap_display if voice_on else "none", music_volume=volume,
                                           sound_effects_enabled=sounds if edit_audio_mode != "Silent" else False,
                                           ambience_enabled=ambience if edit_audio_mode != "Silent" else False)
                st.success("Saved. Use Render now below. No new visual generation was submitted.")
        preview_style = st.selectbox("Preview typography", ["bold", "playful", "clean"], key=f"card-preview-style-{job_id}")
        if st.button("Preview card — local only", key=f"card-preview-{job_id}"):
            from engine.render.graphics import OverlayEvent, render_overlay_png
            from PIL import Image
            preview = os.path.join(F.pm.dirs(job_id)['render'], 'card-style-preview.png')
            event = OverlayEvent('keypoint', 0, 3, 'Tiny steps. Big adventures.')
            render_overlay_png(event, preview, 540, 960, style=preview_style)
            with Image.open(preview) as image:
                st.image(image, caption="Transparent overlay preview; the video remains visible behind it.")


def pipeline_view(job_id):
    try:
        m = F.pm.load_manifest(job_id)
    except Exception:
        return
    D = F.pm.dirs(job_id)
    from engine.presentation import resolve_presentation
    recipe = resolve_presentation(F._settings(job_id))
    steps = [("SCRIPT", os.path.exists(os.path.join(D["root"], "script.json"))),
             ("VOICE", os.path.exists(os.path.join(D["narration"], "voice.mp3")) if recipe.voiceover else "OFF"),
             ("STORYBOARD", bool(m.shots)),
             ("FLOW", f"{m.accepted_count()}/{len(m.shots)}"),
             ("QC", f"{m.accepted_count()}/{len(m.shots)}"),
             ("RENDER", m.status == "done")]
    cols = st.columns(len(steps))
    for (name, ok), c in zip(steps, cols):
        c.metric(name, "✓" if ok is True else ("·" if ok is False else ok))


def language_edition_panel(job_id):
    """Language editions of a job: status, exports and an explicit render action."""
    from engine.language_editions import requested_languages, render_job_editions, render_language_outputs
    from engine.production_lock import production_slot
    from engine.languages import LANGUAGES as LANGUAGE_PACKS
    job_dir = Path(F.pm.job_dir(job_id))
    source, extra, state = requested_languages(job_dir)
    if not extra:
        return
    record_path = job_dir / 'production' / 'language_editions_render.json'
    record = json.loads(record_path.read_text(encoding='utf-8')) if record_path.is_file() else {'editions': {}}
    st.subheader('Language editions')
    st.caption('Each extra edition uses the approved picture, its reviewed narration, timed cards, captions and its own channel profile. The primary edition is the video above.')
    for code in extra:
        entry = record.get('editions', {}).get(code, {})
        status = entry.get('status', 'not rendered yet')
        st.write(f"**{LANGUAGE_PACKS[code].label}** · {status}")
        if entry.get('status') == 'exported' and Path(entry.get('path', '')).is_file():
            st.video(entry['path'], width=420)
        elif entry.get('status') == 'failed':
            st.error(entry.get('error', 'Render failed.'))
    if st.button('Add English intro/outro and render pending language editions', key=f'render-language-editions-{job_id}'):
        try:
            with production_slot(job_dir):
                report = render_language_outputs(job_dir)['editions']
            if report.get('status') == 'exported':
                st.success('All language editions are exported.')
            else:
                st.warning('Language editions: ' + report.get('status', 'check details') + ('. ' + report['error'] if report.get('error') else ''))
        except Exception as error:
            st.error(str(error))


# ================= STUDIO =================
queued_resume = st.session_state.pop("pending_resume_job", None)
if queued_resume:
    run_with_ui(queued_resume, "")

if page == "STUDIO":
    st.title("Create a Reel or long video")
    st.caption("Create multi-scene Reels/Shorts or long videos here. Mini Reels is the separate single-generation workflow. Saved jobs continue in Queue & Resume.")
    st.subheader("1 · Video setup")
    topic = st.text_input("Topic / idea", key="studio-topic", placeholder="What would you like to create?", on_change=invalidate_script_review)
    a, b = st.columns(2)
    production_mode = a.radio("Video format", ["youtube_pro", "reels_pro", "legacy"],
        format_func=lambda value: {"youtube_pro":"Long video · landscape 16:9", "reels_pro":"Normal Reel / Short · vertical 9:16", "legacy":"Classic pipeline"}[value], key="studio-mode", on_change=invalidate_script_review)
    theme = b.selectbox("Theme", list(THEMES), format_func=lambda value: value.replace("_", " ").title(), key="studio-theme")
    c, d = st.columns(2)
    duration_default = st.session_state.get('studio-saved-durations', {}).get(production_mode,
        45 if production_mode == "reels_pro" else 300)
    duration = c.number_input("Duration (seconds)", 10, 7200, duration_default,
        key="studio-duration-" + production_mode, on_change=remember_studio_duration)
    profile = d.selectbox("Generation profile", PROFILES, index=0, format_func=lambda value: value.replace("_", " ").title(), key="studio-profile", help="Flow Cinematic uses generated motion scenes. Storyboard Economy mixes selected video scenes with still-image motion; choose based on your motion needs and credit budget.")
    if profile == 'STORYBOARD_ECONOMY':
        st.info('Economy mixes generated video with animated stills. For a continuous dance or action video, select Flow Cinematic and review its credit budget.')
    studio_audio_mode = st.radio("Audio mode", ["Voiceover", "Music only", "Silent"], horizontal=True, key="studio-audio-mode", on_change=invalidate_script_review)
    from engine.studio_widgets import broll_settings
    studio_broll=broll_settings(st,'studio-broll')
    studio_voice_on = studio_audio_mode == "Voiceover"
    st.caption("Music only skips voice synthesis and speech captions. Silent also turns music, ambience and SFX off. Text cards can be switched independently.")
    from engine.languages import LANGUAGES
    language_column, destination_column = st.columns(2)
    language_code = language_column.selectbox('Master script + primary video language', list(LANGUAGES), format_func=lambda code: LANGUAGES[code].label, on_change=invalidate_script_review,
        help='Gemini drafts one master script in this language. This is also the first rendered edition.')
    destination = destination_column.selectbox('Destination recipe', ['automatic','instagram_reel','facebook_reel','youtube_short','youtube_long'])
    additional_language_options=[code for code in LANGUAGES if code!=language_code]
    additional_editions=st.multiselect('Additional language editions · optional',additional_language_options,default=[],
        format_func=lambda code: LANGUAGES[code].label,key='studio-additional-editions-'+language_code,
        help='Choose zero, one or two. Every edition reuses the same story and visual master, but receives a separately reviewed localized narration, TTS and timed cards.')
    batch_languages=[language_code]+additional_editions
    st.caption('One master script → '+', '.join(LANGUAGES[x].label for x in batch_languages)+'. Additional editions are localized from the approved master; they are not separate stories.')
    with st.expander('Import an approved script or narration', expanded=False):
        approved_plan_path = st.text_input('Approved script/storyboard JSON (optional)', help='Use CONTENT INBOX or your own writer, review the JSON, then approve it. Imported text is not automatically rewritten.')
        narration_input_path = st.text_input('Imported native narration file (optional)', help='An audio file you own/are licensed to use; useful for native-language review.')
        st.caption('A transcript upload is optional. Voiceover can be generated from the reviewed script; speech captions can be set to None below.')
    from engine.content_library import CharacterLibrary
    studio_characters = CharacterLibrary().list()
    from engine.studio_widgets import cast_picker
    with st.expander('2 · Review script and cast · optional', expanded=False):
        draft_topic = topic
        st.caption('Script topic: ' + (topic or 'Enter your topic above.'))
        draft_seconds = int(duration)
        st.caption(f'Master script target: {draft_seconds} seconds · {LANGUAGES[language_code].label}')
        st.caption('This action drafts one master script only. Selected additional editions are prepared after this master is approved.')
        draft_style = st.selectbox('Script treatment',['education','cartoon story','documentary','cinematic story'],key='studio-draft-style', index=0 if studio_voice_on else 3)
        from engine.studio_review import draft_provider_options
        draft_options = draft_provider_options()
        draft_provider = st.selectbox('Drafting model', [key for key, _, _, _ in draft_options],
            format_func=lambda key: next(f"{label}{'' if ok else ' — not configured'}" for k, label, ok, _ in draft_options if k == key),
            key='studio-draft-provider',
            help='Gemini Web and ChatGPT Web use your signed-in browser session. ChatGPT/OpenAI, Indus AI (Sarvam), Gemini API, Groq, Grok and Ollama use the API keys set in the environment.')
        chosen_draft = next(item for item in draft_options if item[0] == draft_provider)
        st.caption(chosen_draft[3])
        draft_cleanup = st.selectbox('Draft chat cleanup',['delete-after-read','keep'],key='studio-draft-cleanup', disabled=draft_provider not in ('gemini-web', 'chatgpt-web'),
            help='Applies to Gemini Web and ChatGPT Web. delete-after-read: Gemini deletes the chat; ChatGPT uses a temporary chat that is not saved. keep: the chat stays in your history.')
        def clear_cast_draft():
            st.session_state.pop('studio-review', None)
            st.session_state['studio-review-approved'] = False
            st.session_state['studio-use-review'] = False
        draft_cast_ids = st.multiselect('Saved characters available to this draft · optional',
            [c['id'] for c in studio_characters], format_func=lambda identifier:next(c['name'] for c in studio_characters if c['id']==identifier),
            default=[], max_selections=3, key='studio-draft-cast', on_change=clear_cast_draft,
            help='Empty creates a topic-first script without choosing a saved presenter. Only selected characters are sent to the drafting model; suggestions do not select the final cast.')
        draft_characters = [c for c in studio_characters if c['id'] in draft_cast_ids]
        if st.button('Draft script + suggest saved cast — no visuals or TTS', disabled=not chosen_draft[2]):
            try:
                from engine.studio_review import draft_script_cast
                with st.spinner(f'Asking {chosen_draft[1].split(" (")[0]} for a script and cast proposal…'):
                    review=draft_script_cast(draft_topic,int(draft_seconds),language_code,draft_characters,draft_style,cleanup=draft_cleanup,audio_mode=studio_audio_mode,provider=draft_provider)
                st.session_state['studio-review']=review
                st.session_state['studio-reviewed-json']=json.dumps(review['plan'],indent=2,ensure_ascii=False)
                invalidate_script_review()
            except Exception as error: st.error(str(error))
        review=st.session_state.get('studio-review')
        reviewed_path=''
        if review:
            if review['plan'].get('runtime_warning'):st.warning(review['plan']['runtime_warning'])
            st.caption('Reviewed voiceover scripts use measured speech runtime.' if studio_voice_on else 'Visual-only plan: no narration or dialogue. Scene durations determine the runtime; descriptions are production directions.')
            st.write('Suggested roles — you choose the final cast below')
            for suggestion in review['suggestions']:
                name=next((c['name'] for c in studio_characters if c['id']==suggestion['character_id']), suggestion['character_id'])
                st.write(name+' · '+str(suggestion.get('role',''))+' · '+str(suggestion.get('reason','')))
            reviewed_json=st.text_area('Review/edit script and scenes JSON',key='studio-reviewed-json',height=240,on_change=invalidate_script_review)
            use_review=st.checkbox('Use this reviewed script for the production below',key='studio-use-review')
            review_approved=st.checkbox('I approve the script, facts and rights to this original content',key='studio-review-approved')
            if use_review and review_approved:
                try:
                    from engine.studio_review import save_reviewed_plan
                    from engine.visual_plan import validate_draft_selection
                    edited_plan=json.loads(reviewed_json)
                    validate_draft_selection(edited_plan,topic,int(duration),language_code,studio_audio_mode)
                    reviewed_path=save_reviewed_plan(edited_plan,True)
                    approved_plan_path=reviewed_path
                except Exception as error:st.error(str(error))
    with st.expander('3 · Language editions and channel profiles', expanded=bool(st.session_state.get('studio-profile-open'))):
        from engine.finishing_studio import profiles as saved_channel_profiles, save_profile as save_channel_profile
        from engine.finishing_ui import _upload as upload_channel_media
        available_profiles = saved_channel_profiles()
        channel_editions=batch_languages
        if st.session_state.get('studio-profile-flash'):
            st.success(st.session_state.pop('studio-profile-flash'))
        st.write('Selected editions: '+', '.join(LANGUAGES[x].label for x in channel_editions))
        st.caption('Each language edition gets its own channel profile: logo, channel name in that language, and optional intro and outro. Pick a saved profile or create one for a language below. An edition without a profile is rendered with no channel mark.')
        edition_profiles = {}
        for edition in channel_editions:
            edition_label = LANGUAGES[edition].label
            if available_profiles:
                choice = st.selectbox(f'{edition_label} channel profile (logo, name, intro and outro)',
                                      [''] + [str(p) for p in available_profiles],
                                      format_func=lambda value: 'Select a profile' if not value else Path(value).parent.name,
                                      key=f'studio-edition-profile-{edition}')
                if choice:
                    edition_profiles[edition] = choice
                    logo_path = (json.loads(Path(choice).read_text(encoding='utf-8')).get('assets') or {}).get('logo', {}).get('path')
                    if logo_path and Path(logo_path).is_file():
                        st.image(logo_path, width=90, caption=f'{edition_label} logo')
            else:
                st.caption('No channel profiles saved yet. Create one for this language below.')
            with st.expander(f'Create a {edition_label} channel profile here · logo, name, intro, outro', expanded=not available_profiles):
                new_name = st.text_input(f'Channel name for the {edition_label} edition', key=f'studio-new-profile-name-{edition}', placeholder='e.g. Hunar Setu')
                new_logo = st.file_uploader(f'{edition_label} logo', type=['png','jpg','jpeg','webp'], key=f'studio-new-profile-logo-{edition}')
                new_intro = st.file_uploader(f'Optional {edition_label} intro video', type=['mp4','mov','mkv','webm'], key=f'studio-new-profile-intro-{edition}')
                new_outro = st.file_uploader(f'Optional {edition_label} outro video', type=['mp4','mov','mkv','webm'], key=f'studio-new-profile-outro-{edition}')
                st.caption('Saving with the name of an existing channel updates that channel. Empty uploads keep its saved media.')
                if st.button(f'Save {edition_label} channel profile', key=f'studio-save-profile-{edition}'):
                    saved_profile = False
                    try:
                        if not new_name.strip():
                            raise ValueError('Enter the channel name for this edition')
                        save_channel_profile(new_name, names={edition: new_name.strip()}, logo=upload_channel_media(new_logo,'logo'),
                                             intro=upload_channel_media(new_intro,'intro'), outro=upload_channel_media(new_outro,'outro'))
                        saved_profile = True
                    except Exception as error:
                        st.error(str(error))
                    if saved_profile:
                        st.session_state['studio-profile-flash'] = f'Saved “{new_name.strip()}”. Select it for the {edition_label} edition above.'
                        st.session_state['studio-profile-open'] = True
                        st.rerun()
    prepared_batch = None
    use_prepared_batch = False
    with st.expander('4 · Review language scripts → all TTS → timed cards', expanded=True):
        st.caption('First review the exact narration for every selected edition. Then one action prepares every voice and word timing before Gemini receives any text-card request. No visual generation starts here.')
        tts_provider = st.selectbox('TTS provider for the selected language batch', ['auto','gemini','gemini-lite','groq','elevenlabs','kokoro','edge','gtts'], key='studio-batch-tts', disabled=not studio_voice_on)
        st.write('Edition languages: ' + ', '.join(LANGUAGES[x].label for x in batch_languages))
        speech_cards_enabled = st.checkbox('Use speech-timed Gemini cards in this production', value=False, key='studio-speech-cards', disabled=not studio_voice_on)
        hooks_enabled = st.checkbox('Add Gemini Web hooks where the narration needs them', value=False, key='studio-hooks-enabled', disabled=not studio_voice_on,
            help='Gemini Web drafts up to 6 short hook lines after the narration words and text cards are ready. Each is a pop pill near the top and never covers a text card. Needs a voiceover.')
        prepare_language_audio = st.checkbox('Also prepare every selected language automatically during production', value=False, key='studio-all-language-audio', disabled=not studio_voice_on,
            help='If you prepare and approve the batch below, its saved audio/cards are reused instead of resubmitting TTS.')
        if not studio_voice_on:
            st.info('Music-only and Silent do not use TTS. Switch to Voiceover to prepare speech-timed cards.')
        batch_script = ''
        batch_path = None
        localization_path = None
        localization_state = None
        if approved_plan_path.strip() and studio_voice_on:
            try:
                from engine.content_plan import load_plan
                from engine.speech_cards import batch_key,localization_key
                from engine.finishing_studio import shared_root
                batch_script = load_plan(approved_plan_path).get('narration','').strip()
                localization_path = shared_root()/'speech_preparation'/'scripts'/localization_key(batch_script,language_code,batch_languages)
                batch_path = shared_root()/'speech_preparation'/batch_key(batch_script,language_code,batch_languages,tts_provider,narration_input_path.strip())
            except Exception as error:st.error(str(error))
        if st.button('Prepare selected language scripts for review · no TTS',key='studio-localize-scripts',disabled=not(studio_voice_on and batch_script and localization_path)):
            try:
                from engine.speech_cards import prepare_localized_scripts
                from engine.production_lock import production_slot
                bar=st.progress(0);message=st.empty()
                def speech_progress(label,pct,detail=''):
                    bar.progress(max(0,min(100,int(pct))));message.write(label+(' · '+detail if detail else ''))
                with production_slot(localization_path):
                    localization_state=prepare_localized_scripts(localization_path,batch_script,language_code,batch_languages,cleanup=draft_cleanup,progress=speech_progress)
            except Exception as error:st.error(str(error))
        if not batch_script and studio_voice_on:st.info('Approve your master script in step 2, or import an approved script, to enable language preparation.')
        if localization_path and (localization_path/'localized_scripts.json').is_file():
            try:localization_state=json.loads((localization_path/'localized_scripts.json').read_text(encoding='utf-8'))
            except Exception as error:st.error(str(error))
        reviewed_language_scripts=None
        if localization_state:
            st.markdown('**Review the exact narration that will be sent to TTS**')
            edited_language_scripts={};language_approvals={}
            for lang in batch_languages:
                edited_language_scripts[lang]=st.text_area(LANGUAGES[lang].label+' narration',value=localization_state['scripts'][lang],
                    height=150,key='studio-localized-script-'+localization_state['fingerprint']+'-'+lang,
                    disabled=lang==language_code,help='The master narration is edited in step 2.' if lang==language_code else 'Edit for natural pronunciation while preserving the approved facts and story order.')
                language_approvals[lang]=st.checkbox('I reviewed and approve the '+LANGUAGES[lang].label+' narration',
                    value=bool(localization_state.get('reviewed',{}).get(lang)),key='studio-localized-approve-'+localization_state['fingerprint']+'-'+lang)
            if st.button('Save reviewed language scripts',key='studio-save-localized-'+localization_state['fingerprint']):
                try:
                    from engine.speech_cards import approve_localized_scripts
                    localization_state=approve_localized_scripts(localization_path,localization_state,edited_language_scripts,language_approvals)
                    st.success('Reviewed scripts saved. TTS will use this exact snapshot.')
                except Exception as error:st.error(str(error))
            if localization_state.get('phase')=='scripts_approved':reviewed_language_scripts=localization_state['scripts']
        if st.button('Prepare all selected TTS → then all language text cards', key='studio-prepare-speech-batch', disabled=not(studio_voice_on and batch_script and batch_path and reviewed_language_scripts)):
            try:
                from engine.speech_cards import prepare_batch
                from engine.production_lock import production_slot
                bar=st.progress(0);message=st.empty()
                def batch_progress(label,pct,detail=''):
                    bar.progress(max(0,min(100,int(pct))));message.write(label+(' · '+detail if detail else ''))
                with production_slot(batch_path):
                    prepare_batch(batch_path,batch_script,language_code,batch_languages,provider=tts_provider,
                        audio_path=narration_input_path.strip() or None,cleanup=draft_cleanup,progress=batch_progress,localized_scripts=reviewed_language_scripts)
            except Exception as error:st.error(str(error))
        if batch_path and (batch_path/'batch.json').is_file():
            try:
                candidate=json.loads((batch_path/'batch.json').read_text())
                if candidate.get('phase')=='ready_for_review':
                    prepared_batch=candidate
                    for lang,bundle in prepared_batch['bundles'].items():
                        with st.expander(lang.upper()+' · voice '+str(round(bundle['duration'],1))+' seconds · '+bundle['timing_source']):
                            st.audio(bundle['audio']);st.write(bundle['script']);st.dataframe(bundle['cards'],use_container_width=True)
                    use_prepared_batch=st.checkbox('I reviewed these voices, translations and cards; reuse this exact batch',key='studio-use-batch-'+batch_path.name)
                else:st.info('Batch checkpoint: '+candidate.get('phase','preparing')+'. Retry the same action to reuse saved narration.')
            except Exception as error:st.error(str(error))
    with st.expander('Gemini video and project cleanup', expanded=False):
        gemini_video_count = st.number_input('Use Gemini Web for up to this many AI video shots', min_value=0, max_value=4, value=0,
            help='Zero uses existing providers. Requests approximately 10 seconds per shot; duration and quota depend on Gemini. Resume recovers unfinished requests without resubmission.')
        flow_auto_cleanup_images = st.checkbox('Delete captured image-only Flow projects automatically', value=False,
            help='After this job finishes, deletes isolated image-only Flow projects whose downloaded image and request record are verified locally. Video, mixed, pending and changed projects are retained. Off by default because deletion removes the Flow copy.')
    with st.expander('Characters and recovery preferences · optional', expanded=False):
        studio_cast = cast_picker(st,'studio-cast')
        studio_replace_images = st.checkbox('Regenerate an unresolved image once after 3 recovery retries',value=False,key='studio-replace-images',
            help='May leave an unused duplicate in Flow. Image-only; maximum 30 replacements for the job, one per image. Original requests retained. Replacement credit approval is capped at zero.')
        studio_local_close = st.checkbox('Allow saved opening-image guidance when a Flow closing image cannot recover',
            key='studio-local-close', help='Optional continuity fallback. Keeps the pending request and uses no replacement image credits; missing openings or videos still require exact recovery.')
    studio_flow_music_on=st.checkbox('Use a chosen Flow Music track for this production',disabled=studio_audio_mode=='Silent')
    studio_flow_music_path=''
    if studio_flow_music_on and studio_audio_mode!='Silent':
        from engine.studio_widgets import flow_music_picker
        with st.expander('Flow Music · generate, choose and download',expanded=True):
            studio_flow_music_path=flow_music_picker(st,'studio-flow-music','Create instrumental music for '+draft_topic+('. No vocals; leave room for narration.' if studio_voice_on else '. No vocals, singing, speech or narration.'))
    with st.form("studio-create"):
        e, f, g = st.columns(3)
        script_provider = e.selectbox("Script provider", ["auto", "gemini-web", "gemini", "groq", "openai", "indus", "planner"])
        f.caption("TTS provider selected above: " + tts_provider)
        render_quality = g.selectbox("Render quality", ["fast", "high", "standard", "preview"], help="Fast keeps 1080p but uses a faster CPU encoder and may produce a larger file. High keeps the slower quality preset.")
        with st.expander("Advanced · Flow, visuals, audio and branding", expanded=False):
            h, i, j = st.columns(3)
            flow_workers = h.selectbox("Parallel Flow image workers", [1, 2, 3], index=0,
                                       help="1 is serial. With 2–3, independent Flow stills use isolated projects/tabs. Storyboard Economy parallelizes independent openings and closings while preserving exact continuity-linked openings and distinct scene pairs. Video generation itself remains sequential. Google may throttle concurrent sessions; start with 1 or 2.")
            if profile == "STORYBOARD_ECONOMY":
                st.caption("In Storyboard Economy, independent opening photos and closing frames can run in parallel; linked openings still copy the exact previous close, and paid video clips remain sequential.")
            frame_source = i.selectbox("Frame source", ["flow", "auto", "free"], help="Flow retains the selected provider and stops for recovery. Auto permits free-provider substitutions that can change identity and scene quality.")
            flow_approval = j.selectbox("Flow credit approval", ["once", "manual", "always"])
            flow_approval_cards = st.number_input('Maximum approval cards per video request',1,3,1,
                help='Only distinct approval questions may be approved. Their cumulative displayed costs must stay within the per-generation credit cap. Download-only Resume never approves new charges.')
            flow_project_url = st.text_input("Existing Google Flow project URL (optional)",
                                             placeholder="https://flow.google.com/project/<uuid>",
                                             help="Stored with the job and automatically reused on resume.")
            if profile == "STORYBOARD_ECONOMY":
                flow_video_mode = st.selectbox(
                    "Flow video input", ["frames", "prompt"],
                    format_func=lambda value: ("Storyboard frames (continuity)" if value == "frames"
                                               else "Prompt only (no images attached)"),
                    help="Applies only to paid Flow motion scenes. Prompt-only clips are generated from the scene prompt; storyboard photos remain available for image-motion scenes and fallback.")
            else:
                flow_video_mode = "frames"
            flow_pause_on_unresolved_request = st.checkbox(
                "Pause when a Flow request cannot be safely recovered (opt-in)",
                value=_flow_pause_setting_default(),
                help="Off by default: ambiguous images use the free fallback in auto mode; strict image/video requests fail without PAUSED status and can be explicitly resumed. On: save the request and pause for your choice. Recovery retries download-only and verifies request identity; it never regenerates merely because a gallery scan misses an image.")
            k, l, n = st.columns(3)
            reuse_mode = k.selectbox("Flow reuse scope", ["exact", "topic", "project"])
            gemini_cleanup = l.selectbox("Gemini temporary chat", ["delete-after-read", "keep"])
            background_music = n.selectbox("Background music", ["off", "auto", "local", "browser", "generated", "reliable"],
                                           index=5 if studio_audio_mode == "Music only" else 0,
                                           disabled=studio_audio_mode == "Silent")
            music_path = st.text_input("Licensed local music path (optional)", help="Use a WSL/Linux path. Choose local above to avoid browser lookup.")
            from engine.audio.music_library import root as music_library_root, list_tracks
            from pathlib import Path
            library_tracks = list_tracks()
            local_files = sorted(p for p in music_library_root().glob('*') if p.is_file() and p.suffix.lower() in ('.mp3','.wav','.ogg','.m4a','.flac'))
            local_choices = [''] + sorted(set([row['path'] for row in library_tracks] + [str(p) for p in local_files]))
            chosen_music = st.selectbox('Shared licensed track · exact file', local_choices,
                                        format_func=lambda value: Path(value).name if value else 'Select a track',
                                        help='Files in the shared music_library folder appear here. Verify each track’s rights before publishing.')
            pc1, pc2, pc3 = st.columns(3)
            text_cards_enabled = pc1.checkbox("Include text cards", value=studio_voice_on, key="studio-cards-" + studio_audio_mode,
                                               help="Title, chapter, key-point, recap and structured cards. Off is respected even in Pro mode.")
            text_card_style = pc2.selectbox("Text card style", ["auto", "bold", "playful", "clean"],
                                            help="auto selects rounded playful type for cartoon stories, bold display type otherwise.")
            music_volume = pc3.slider("Music gain", 0.0, 1.0, .20 if studio_voice_on else .55, .01)
            o, p, q = st.columns(3)
            caption_display = o.selectbox("Speech captions", ["auto", "full", "none"], disabled=not studio_voice_on)
            from engine.channel_branding import branding_plan
            branding = branding_plan(channel_editions, edition_profiles, language_code)
            channel_name, channel_logo, channel_logo_size = '', '', 'Medium'
            inline_branding = {}
            if branding['complete']:
                p.caption('Channel name and logo come from the language profiles chosen in step 3 (one per edition).')
            else:
                if branding['primary_missing']:
                    channel_name = p.text_input("Channel name")
                    from engine.brand_logo import logo_controls
                    channel_logo, channel_logo_fraction = logo_controls(st, 'studio-brand')
                    channel_logo_size = { .12:'Small', .18:'Medium', .25:'Large' }[channel_logo_fraction]
                if branding['inline']:
                    st.caption('Editions without a profile in step 3. Enter their channel name and logo here; each entry is saved as that edition\'s profile when you create the production. A blank name means no channel mark for that edition.')
                    for edition in branding['inline']:
                        edition_label = LANGUAGES[edition].label
                        inline_name = st.text_input(f'Channel name in {edition_label}', key=f'studio-inline-name-{edition}', placeholder='Channel name in this language')
                        inline_logo = st.file_uploader(f'{edition_label} channel logo (optional)', type=['png','jpg','jpeg','webp'], key=f'studio-inline-logo-{edition}')
                        inline_branding[edition] = (inline_name, inline_logo)
            watermark_on = st.checkbox("Show animated channel watermark", value=True, help="Needs a channel name. Playful cards use a colourful opening/closing badge; other styles use subtle type.")
            caption_template = st.selectbox("Speech caption style", ["auto", "OPUS", "HORMOZI", "MINIMAL", "KIDS"], help="OPUS matches Clip Studio. Auto uses OPUS for vertical videos.")
            r1, r2, r3 = st.columns(3)
            max_credits = r1.number_input("Max credits/video", 0, 5000, 30)
            flow_scenes = r2.number_input("Exact Flow motion scenes (0=auto)", 0, 500, 0)
            images_per_shot = r3.number_input(
                "Candidate images/shot", 0, 10, 2,
                disabled=profile == "STORYBOARD_ECONOMY",
                help="Used by non-Economy profiles. Storyboard Economy instead creates one opening photo per scene and a closing frame only for selected Flow-video scenes.")
        plan_only = st.checkbox("Create plan only (run later with Resume)")
        submitted = st.form_submit_button("Create production", type="primary")
    if submitted:
        if review and st.session_state.get("studio-use-review") and not reviewed_path:
            st.warning("Approve a valid reviewed script before creating this production.")
        elif len(batch_languages)>1 and not (studio_voice_on and use_prepared_batch):
            st.warning('Additional language editions need Voiceover and an approved language batch. In step 4, approve each localized narration, click “Prepare all selected TTS”, then tick “reuse this exact batch”. Without it, no extra edition can be made, so nothing falls back to English.')
        elif studio_flow_music_on and studio_audio_mode != 'Silent' and not studio_flow_music_path:
            st.warning('Choose and download your Flow Music track before creating the production.')
        elif studio_audio_mode == 'Music only' and background_music == 'off' and not studio_flow_music_path:
            st.warning('Choose background music or select Silent before creating the production.')
        elif background_music == 'local' and not (music_path.strip() or chosen_music or studio_flow_music_path):
            st.warning('Select an exact shared track or enter a playable local path. Local music cannot silently disappear from the render.')
        elif not topic.strip():
            st.warning("Enter a topic first.")
        else:
            if inline_branding:
                from engine.finishing_studio import save_profile as save_channel_profile
                from engine.finishing_ui import _upload as upload_channel_media
                from engine.channel_branding import save_missing_profiles
                try:
                    edition_profiles.update(save_missing_profiles(inline_branding, save_channel_profile, upload_channel_media))
                except Exception as error:
                    st.error(f'Channel profile not saved: {error}')
                    st.stop()
            cfg = dict(DEFAULTS)
            cfg.update({"topic": topic.strip(), "production_mode": production_mode,
                        "production_mode_engine": "youtube_pro" if production_mode == "reels_pro" else production_mode,
                        "video_type": "shorts" if production_mode == "reels_pro" else "faceless_youtube",
                        "aspect": "9:16" if production_mode == "reels_pro" else "16:9",
                        "theme": theme, "duration": int(duration), "profile": profile,
                        "language":language_code, "destination":None if destination=='automatic' else destination,
                        "approved_plan_path":approved_plan_path.strip(), "narration_input_path":narration_input_path.strip(),
                        "script_provider": script_provider, "tts_provider": tts_provider,
                        "render_quality": render_quality, "flow_image_workers": flow_workers,
                        "frame_source": frame_source, "flow_approval": flow_approval, "flow_approval_cards": int(flow_approval_cards),
                        "flow_video_mode": flow_video_mode,
                        "flow_project_url": flow_project_url.strip(), "flow_reuse_mode": reuse_mode,
                        "flow_pause_on_unresolved_request": flow_pause_on_unresolved_request,
                        "gemini_chat_cleanup": gemini_cleanup,
                        "speech_cards_enabled": bool(studio_voice_on and (speech_cards_enabled or use_prepared_batch)), "gemini_video_count": int(gemini_video_count),
                        "flow_auto_cleanup_images": flow_auto_cleanup_images,
                        "background_music": "off" if studio_audio_mode == "Silent" else background_music,
                        "background_music_path": music_path.strip() or chosen_music, "music_volume": music_volume,
                        "voiceover_enabled": studio_voice_on, "text_cards_enabled": text_cards_enabled,
                        "text_card_style": text_card_style,
                        "sound_effects_enabled": studio_voice_on, "ambience_enabled": studio_voice_on,
                        "caption_display": ("none" if not studio_voice_on else
                                            ("full" if production_mode == "reels_pro" and caption_display == "auto" else caption_display)),
                        "channel_name": channel_name, "channel_logo": channel_logo, "channel_logo_size": channel_logo_size, "watermark": watermark_on, "caption_template": caption_template,
                        "max_credits": int(max_credits), "flow_scenes": int(flow_scenes) or None,
                        "images_per_shot": int(images_per_shot), "graphics_overlays": production_mode != "legacy"})
            from engine.languages import default_voice
            cfg['voice'] = default_voice(language_code)
            for key, value in THEMES[theme].items():
                cfg[key] = value
            if studio_flow_music_on and studio_audio_mode != 'Silent':
                cfg['background_music']='local';cfg['background_music_path']=studio_flow_music_path
            if language_code in edition_profiles:
                primary_profile = json.loads(Path(edition_profiles[language_code]).read_text(encoding='utf-8'))
                cfg['channel_name'] = primary_profile.get('names', {}).get(language_code) or primary_profile['name']
                logo_asset = primary_profile.get('assets', {}).get('logo')
                if logo_asset:
                    from engine.finishing_studio import _verified
                    cfg['channel_logo'] = str(_verified(logo_asset))
                cfg['watermark'] = True
            cfg['character_ids'] = studio_cast
            cfg['card_draft_provider'] = str(st.session_state.get('studio-draft-provider') or 'gemini-web')
            cfg['hooks_enabled'] = bool(studio_voice_on and st.session_state.get('studio-hooks-enabled', False))
            cfg.update(studio_broll)
            kwargs = config_to_factory_kwargs(cfg)
            job_id = F.create_job(topic=cfg["topic"], video_type=cfg["video_type"],
                                  aspect=cfg["aspect"], external_video_mode=external_video_mode_ui, **kwargs)
            if channel_editions or use_prepared_batch:
                from engine.production import save
                bundles = {}
                if use_prepared_batch and prepared_batch:
                    from engine.speech_cards import attach_prepared_batch
                    bundles = attach_prepared_batch(F.pm.job_dir(job_id),prepared_batch)
                save(Path(F.pm.job_dir(job_id)) / 'production' / 'language_editions.json',
                     {'source_language': language_code, 'editions': batch_languages,
                      'profiles': edition_profiles, 'prepare_audio': bool(studio_voice_on and (prepare_language_audio or use_prepared_batch)),
                      'bundles': bundles, 'status': 'prepared batch attached' if bundles else 'awaiting narration preparation',
                      'intro_outro_handoff': 'Finishing Studio'})
            F.set_flow_local_closing_fallback(job_id, studio_local_close)
            F.set_flow_image_replacement(job_id, studio_replace_images)
            resolved = os.path.join(F.pm.job_dir(job_id), "input_config.resolved.yaml")
            with open(resolved, "w", encoding="utf-8") as fh:
                yaml.safe_dump({k: v for k, v in cfg.items() if k != "production_mode_engine"}, fh,
                               sort_keys=False, allow_unicode=True)
            st.session_state.job_id = job_id
            st.success(f"Job created: `{job_id}`")
            if plan_only:
                st.info(f"Resume from QUEUE or run: python3 cli.py v3 resume {job_id}")
            else:
                run_with_ui(job_id, "🎛️ STUDIO ·")
    if st.session_state.job_id:
        st.divider()
        pipeline_view(st.session_state.job_id)
        language_edition_panel(st.session_state.job_id)

# ================= MUSIC VIDEO =================
elif page == 'MUSIC VIDEO':
    st.title('Music video · song first, visuals next')
    from engine.music_video import music_prompt, create_music_video
    from engine.content_library import CharacterLibrary
    locale=st.selectbox('Song language',['or','hi','en'])
    genre=st.selectbox('Song genre',['devotional','pop','folk','cinematic','children','instrumental'])
    topic=st.text_area('Song story and visual idea')
    lyrics=st.text_area('Reviewed lyrics / scene notes (optional)')
    background=st.checkbox('Build a soft instrumental background prompt instead')
    if topic:
        st.code(music_prompt(topic,locale,genre,background=background,lyrics=lyrics))
    source=st.radio('Song source',['Flow Music browser','Local downloaded song'],horizontal=True)
    if source=='Flow Music browser':
        from engine.studio_widgets import flow_music_picker
        path=flow_music_picker(st,'music-video-track',music_prompt(topic,locale,genre,background=background,lyrics=lyrics) if topic else '')
    else:
        path=st.text_input('Downloaded song file path')
    rights=st.checkbox('I have rights to use this song and these lyrics')
    aspect=st.selectbox('Music video framing',['9:16','16:9'])
    from engine.studio_widgets import cast_picker
    selected=cast_picker(st,'music-video-cast')
    stock=st.checkbox('Allow contextual stock base scenes',value=False)
    from engine.studio_widgets import broll_settings
    music_broll=broll_settings(st,'music-broll')
    budget=st.number_input('Maximum visual-generation credits',0,5000,50)
    if st.button('Create music-video storyboard — no generation',disabled=not rights):
        try:
            result=create_music_video(F,path,topic,language=locale,genre=genre,lyrics=lyrics,character_ids=selected,max_credits=int(budget),allow_stock=stock,aspect=aspect)
            F.set_broll_options(result['job_id'],**music_broll)
            st.session_state.job_id=result['job_id'];st.json(result)
        except Exception as error:st.error(str(error))

# ================= MINI REELS =================
elif page == "MINI REELS":
    st.title("Mini Reels · Gemini Web → Google Flow/Veo")
    st.caption("Trend, article, or manual idea → a reviewable prompt from your visible Gemini Web session → one 8-second, 9:16 Flow/Veo clip in your browser. This is separate from the long-form storyboard, voiceover, and render pipeline.")
    st.info("Start with a Google Trends topic, a public article RSS idea, or your own text. Trends indicate search interest—not social virality—and article excerpts are inspiration, not verified facts. Gemini Web must be signed in through AutoVideoAI's browser session; there is no Gemini API fallback. You review the final prompt and explicitly approve before Flow generation.")

    from engine.mini_reels import (
        AUDIO_LABELS, CONTENT_CATEGORIES, FLOW_MODEL_LABELS, LANGUAGE_LABELS, TREND_REGIONS,
        VISUAL_STYLES, build_content_idea_input, compose_flow_prompt,
        fetch_content_ideas, fetch_trend_ideas, generate_flow_reel,
        generate_prompt_brief, get_content_idea_sources, list_pending_reels,
        new_reel_id, read_reel, recover_flow_reel,
    )

    idea_modes = {
        "manual": "Manual idea",
        "trends": "Google Trends",
        "articles": "Article websites",
    }
    idea_source_mode = st.radio(
        "Choose where to start",
        list(idea_modes), index=0, horizontal=True,
        format_func=lambda key: idea_modes[key], key="mini-reel-idea-source")
    previous_idea_mode = st.session_state.get("_mini_reel_last_idea_mode")
    source_context = None

    if idea_source_mode == "trends":
        left, right = st.columns([2, 1])
        region_name = left.selectbox("Google Trends region", list(TREND_REGIONS), index=0,
                                     key="mini-reel-region")
        region_code = TREND_REGIONS[region_name]
        if right.button("↻ Refresh trend ideas", key="mini-reel-refresh-trends"):
            try:
                found = fetch_trend_ideas(region_code, count=10)
                cache = dict(st.session_state.get("mini_reel_trends", {}))
                cache[region_code] = found
                st.session_state["mini_reel_trends"] = cache
                st.success(f"Loaded {len(found)} current Google Trends search ideas for {region_name}.")
            except Exception as exc:
                st.warning(f"Trend feed unavailable: {exc}. You can enter an idea manually.")

        trends_by_region = st.session_state.get("mini_reel_trends", {})
        trend_rows = trends_by_region.get(region_code, [])
        trend_titles = [str(row.get("title", "")) for row in trend_rows if row.get("title")]
        selected_trend = st.selectbox(
            "Recent search trend (optional)", [""] + trend_titles,
            format_func=lambda value: value or "Choose a trend or enter your own idea",
            key="mini-reel-trend-choice")
        if selected_trend and (
                st.session_state.get("_mini_reel_last_trend") != selected_trend
                or previous_idea_mode != idea_source_mode):
            st.session_state["mini-reel-topic"] = selected_trend
        st.session_state["_mini_reel_last_trend"] = selected_trend
        if selected_trend:
            matched = next((row for row in trend_rows if row.get("title") == selected_trend), {})
            details = " · ".join(x for x in (matched.get("approx_traffic", ""), matched.get("published", "")) if x)
            st.caption(f"Google Trends Trending Now RSS · {region_name}" + (f" · {details}" if details else ""))

    elif idea_source_mode == "articles":
        st.subheader("Browse ideas from article websites")
        st.caption("Refresh a public RSS feed, choose an article, and use its title and excerpt as inspiration for Gemini Web. The article page and media are not downloaded; the final Flow prompt remains editable and reviewable.")
        st.caption("Factozone.com is included through its public RSS feed. Feeds can change or be unavailable; only titles/excerpts are used as unverified idea inspiration, never as permission to copy text/media.")
        source_rows = get_content_idea_sources()
        source_by_id = {row["id"]: row for row in source_rows}
        source_col, refresh_col = st.columns([3, 1])
        content_source_id = source_col.selectbox(
            "Article website", list(source_by_id),
            format_func=lambda key: source_by_id[key]["name"],
            key="mini-reel-content-source")
        if refresh_col.button("↻ Refresh articles", key="mini-reel-refresh-articles"):
            try:
                found = fetch_content_ideas(content_source_id, count=12)
                cache = dict(st.session_state.get("mini_reel_articles", {}))
                cache[content_source_id] = found
                st.session_state["mini_reel_articles"] = cache
                st.success(f"Loaded {len(found)} recent article ideas from {source_by_id[content_source_id]['name']}.")
            except Exception as exc:
                st.warning(f"Article feed unavailable: {exc}. Choose another website or enter an idea manually.")
        st.caption(source_by_id[content_source_id]["description"])

        articles_by_source = st.session_state.get("mini_reel_articles", {})
        article_rows = articles_by_source.get(content_source_id, [])
        article_by_id = {row["id"]: row for row in article_rows if row.get("id")}
        if article_by_id:
            selected_article_id = st.selectbox(
                "Article idea (optional)", [""] + list(article_by_id),
                format_func=lambda key: (
                    "Choose an article" if not key else
                    article_by_id[key]["title"] + (f" · {article_by_id[key]['published'][:16]}" if article_by_id[key].get("published") else "")
                ), key="mini-reel-article-choice")
            selected_article = article_by_id.get(selected_article_id)
            if selected_article:
                try:
                    article_input = build_content_idea_input(selected_article)
                    source_context = article_input["source_context"]
                    if (st.session_state.get("_mini_reel_last_article") != selected_article_id
                            or previous_idea_mode != idea_source_mode):
                        st.session_state["mini-reel-topic"] = article_input["idea"]
                    st.session_state["_mini_reel_last_article"] = selected_article_id
                    st.caption(f"Selected from {source_context['source_name']} · {source_context.get('published') or 'date not supplied'}")
                    if source_context.get("summary"):
                        with st.expander("Article excerpt used as idea context", expanded=True):
                            st.write(source_context["summary"])
                    st.link_button("Open selected article", source_context["url"],
                                   key=f"mini-reel-article-link-{selected_article_id}")
                except ValueError as exc:
                    st.warning(f"This feed item cannot be used safely: {exc}")
                    source_context = None
            else:
                st.session_state["_mini_reel_last_article"] = ""
        else:
            st.caption("No articles loaded yet. Use **Refresh articles** to fetch the selected website's feed.")
            st.session_state["_mini_reel_last_article"] = ""

    st.session_state["_mini_reel_last_idea_mode"] = idea_source_mode
    placeholders = {
        "manual": "Type a fresh idea, or edit a selected trend/article title",
        "trends": "Choose a trend above, or type a fresh idea",
        "articles": "Choose an article above, or type a fresh idea",
    }
    idea = st.text_input("Starting idea", key="mini-reel-topic", max_chars=300,
                         placeholder=placeholders[idea_source_mode])
    category = st.selectbox(
        "Content category / editorial guardrails", list(CONTENT_CATEGORIES),
        format_func=lambda key: CONTENT_CATEGORIES[key]["label"],
        key="mini-reel-category")
    st.caption("Category guidance helps the draft stay appropriate; it does not verify claims. Mini Reels makes one 8-second visual micro-story. Use Guided Studio/Advanced Create for a researched, multi-scene tutorial or full story.")

    c1, c2, c3 = st.columns(3)
    style_keys = list(VISUAL_STYLES)
    visual_style = c1.selectbox(
        "Visual treatment", style_keys, index=0,
        format_func=lambda key: {
            "miniature-diorama": "Miniature diorama / macro",
            "miniature-stop-motion": "Miniature stop-motion",
            "macro-realism": "Macro realism",
            "cinematic-short": "Cinematic short",
            "playful-3d": "Playful original 3D",
        }.get(key, key), key="mini-reel-style")
    language = c2.selectbox("Voiceover language (when requested)", list(LANGUAGE_LABELS),
                            format_func=lambda key: LANGUAGE_LABELS[key], key="mini-reel-language")
    audio_modes = list(AUDIO_LABELS)
    audio_mode = c3.selectbox("Flow audio request", audio_modes,
                               format_func=lambda key: AUDIO_LABELS[key], key="mini-reel-audio")
    st.caption("Audio intent is included in the prompt to Flow/Veo. Native speech/ambience—and even a silence request—depends on the selected model and account. AutoVideoAI makes no separate TTS request; review the returned clip and any Hindi/Odia pronunciation.")

    d1, d2, d3 = st.columns(3)
    model_options = list(FLOW_MODEL_LABELS)
    model = d1.selectbox("Flow/Veo model", model_options, index=1,
                         format_func=lambda key: FLOW_MODEL_LABELS[key], key="mini-reel-model")
    flow_project_url = d2.text_input("Existing Flow project URL (optional)", key="mini-reel-project-url",
                                     placeholder="https://flow.google.com/project/…")
    max_generation_credits = d3.number_input("Flow Agent approval cap (when shown)", min_value=0, max_value=5000,
                                              value=30, step=1, key="mini-reel-max-credits",
                                              help="Applied when Flow's current Agent UI exposes a credit-approval card. This is not a price estimate and may not be enforceable in every Flow UI mode; review any Flow credit prompt and your account's terms before proceeding.")
    st.caption("The numeric cap is conditional on Flow showing a credit-approval card. If your current Flow UI does not show one, account-level pricing/limits apply; AutoVideoAI still requires this separate one-generation confirmation and never automatically re-submits an uncertain request.")

    from engine.studio_widgets import cast_picker
    mini_cast=cast_picker(st,'mini-cast')
    pending_reels = list_pending_reels()
    draft = st.session_state.get("mini_reel_draft")
    if st.button("✨ Ask Gemini Web for an original reel prompt", type="primary",
                 key="mini-reel-generate-prompt"):
        if not idea.strip():
            st.warning("Choose a trend or enter an idea first.")
        else:
            try:
                with st.spinner("Asking the visible Gemini Web session for one original eight-second concept…"):
                    brief = generate_prompt_brief(
                        idea, visual_style=visual_style, language=language,
                        audio_mode=audio_mode, category=category, source_context=source_context)
                    flow_prompt = compose_flow_prompt(
                        brief, visual_style=visual_style, language=language,
                        audio_mode=audio_mode, model=model)
                draft = {
                    "reel_id": new_reel_id(), "brief": brief, "flow_prompt": flow_prompt,
                    "visual_style": visual_style, "language": language,
                    "category": category, "audio_mode": audio_mode, "model": model,
                    "flow_project_url": flow_project_url.strip(), "character_ids":mini_cast,
                }
                st.session_state["mini_reel_draft"] = draft
                st.success("Gemini Web returned a draft. Review or edit the exact Flow prompt below; no video has been generated yet.")
            except Exception as exc:
                st.error(f"Could not create a prompt with Gemini Web: {exc}")

    draft = st.session_state.get("mini_reel_draft")
    if draft:
        st.divider()
        st.subheader(f"Review draft · {draft['brief'].get('title', 'Mini reel')}")
        st.write(draft["brief"].get("angle", ""))
        category_label = CONTENT_CATEGORIES.get(draft["brief"].get("category", "general"), CONTENT_CATEGORIES["general"])["label"]
        st.caption(f"Gemini Web · {category_label} · {draft['brief'].get('idea', '')} · 8 seconds · 9:16 · {FLOW_MODEL_LABELS.get(draft.get('model'), draft.get('model'))}")
        draft_source = draft["brief"].get("source_context")
        if draft_source:
            st.caption(f"Idea inspiration: {draft_source.get('source_name', 'article feed')} · verify factual claims before publishing.")
            st.link_button("Review source article", draft_source["url"],
                           key=f"mini-reel-draft-source-{draft['reel_id']}")
        if draft["brief"].get("voiceover_line"):
            st.markdown("**Requested voiceover:** " + draft["brief"]["voiceover_line"])
        if draft["brief"].get("caption"):
            st.markdown("**Suggested post caption:** " + draft["brief"]["caption"])
        if draft["brief"].get("hashtags"):
            st.caption(" ".join(draft["brief"]["hashtags"]))
        prompt_key = f"mini-reel-flow-prompt-{draft['reel_id']}"
        flow_prompt = st.text_area("Final Flow prompt (editable)", value=draft["flow_prompt"],
                                   height=220, key=prompt_key)
        project_key = f"mini-reel-project-{draft['reel_id']}"
        project_for_draft = st.text_input("Flow project URL for this reel (optional)",
                                          value=draft.get("flow_project_url", ""), key=project_key,
                                          placeholder="https://flow.google.com/project/…")
        approval_key = f"mini-reel-credit-approval-{draft['reel_id']}"
        credit_acknowledged = st.checkbox(
            "I reviewed this prompt and approve one Flow/Veo generation using my signed-in Google account. Flow may use my account credits at the price shown by Flow.",
            value=False, key=approval_key)
        saved = None
        try:
            saved = read_reel(draft["reel_id"])
        except (FileNotFoundError, OSError, ValueError):
            pass
        if saved and saved.get("status") == "complete" and Path(saved.get("output_path", "")).is_file():
            st.success("This reel is already generated. Reopening it will not submit another video request.")
            compact_video(saved["output_path"])
            delivery_seconds = st.selectbox('Mini Reel delivery length', [8, 10, 12], key=f'mini-delivery-{draft["reel_id"]}')
            st.caption('Flow generates one 8-second scene. 10/12-second delivery adds a local final-frame hold and silence after native audio; it is not additional generated motion.')
            if delivery_seconds > 8 and st.button('Export with final-frame hold — no generation credits', key=f'mini-hold-{draft["reel_id"]}'):
                from engine.mini_reel_export import export_short_hold
                try:
                    export = export_short_hold(saved['output_path'], delivery_seconds)
                    compact_video(export)
                    st.download_button('Download extended delivery', Path(export).read_bytes(), file_name=Path(export).name, mime='video/mp4')
                except Exception as error: st.error(str(error))
            if saved.get("audio_mode") == "flow-voiceover":
                if saved.get("audio_stream_present") is True:
                    st.info("An audio track was detected. Listen through and verify that the requested voiceover is present and correct.")
                elif saved.get("audio_stream_present") is False:
                    st.warning("No audio track was detected. The video was not automatically regenerated or replaced, avoiding an unexpected second credit-bearing request.")
                else:
                    st.caption("Audio-track detection was unavailable; please listen to the clip to verify native audio.")
            elif saved.get("audio_mode") == "silent" and saved.get("audio_stream_present") is True:
                st.warning("Flow returned an audio track despite the silence prompt. AutoVideoAI kept the original clip; mute it manually if silence is required.")
            video_bytes = Path(saved["output_path"]).read_bytes()
            st.download_button("⬇️ Download mini reel", video_bytes,
                               file_name=f"{draft['reel_id']}.mp4", mime="video/mp4",
                               key=f"mini-reel-download-{draft['reel_id']}")
            if saved.get("flow_project_url"):
                st.markdown(f"[Open this reel's Flow project]({saved['flow_project_url']})")
        else:
            other_pending = [row for row in pending_reels if row.get("reel_id") != draft["reel_id"]]
            allow_other_pending = False
            if other_pending:
                st.info("An older reel still needs recovery. Its request and project will be retained.")
                allow_other_pending = st.checkbox("Start this separate reel; keep the older request for recovery. I understand this is an additional credit-bearing generation.", key="mini-separate-"+draft["reel_id"])
            if st.button("🎬 Generate once in Google Flow/Veo", type="primary",
                         disabled=(not credit_acknowledged or (bool(other_pending) and not allow_other_pending)),
                         key=f"mini-reel-generate-video-{draft['reel_id']}"):
                try:
                    with st.spinner("Flow is generating or recovering this one saved request. Keep the browser session open…"):
                        result = generate_flow_reel(
                            draft["reel_id"], brief=draft["brief"], flow_prompt=flow_prompt,
                            model=draft["model"], visual_style=draft["visual_style"],
                            audio_mode=draft["audio_mode"], language=draft["language"],
                            flow_project_url=project_for_draft,
                            flow_approval="once", max_generation_credits=int(max_generation_credits),
                            character_ids=draft.get("character_ids",[]), allow_other_pending=allow_other_pending)
                    st.success("Flow video saved. No separate voiceover/TTS job was run.")
                    compact_video(result["output_path"])
                    if result.get("audio_mode") == "flow-voiceover":
                        if result.get("audio_stream_present") is True:
                            st.info("An audio track was detected. Listen through and verify the requested voiceover.")
                        elif result.get("audio_stream_present") is False:
                            st.warning("No audio track was detected. AutoVideoAI did not automatically regenerate or replace this clip.")
                        else:
                            st.caption("Audio-track detection was unavailable; please listen to verify native audio.")
                    elif result.get("audio_mode") == "silent" and result.get("audio_stream_present") is True:
                        st.warning("Flow returned an audio track despite the silence prompt. AutoVideoAI kept the original clip; mute it manually if silence is required.")
                    st.download_button("⬇️ Download mini reel", Path(result["output_path"]).read_bytes(),
                                       file_name=f"{draft['reel_id']}.mp4", mime="video/mp4",
                                       key=f"mini-reel-download-now-{draft['reel_id']}")
                    if result.get("flow_project_url"):
                        st.markdown(f"[Open this reel's Flow project]({result['flow_project_url']})")
                except Exception as exc:
                    st.error(f"Flow generation/recovery did not complete: {exc}")
                    st.caption("A saved Flow request is never blindly resubmitted. If generation may have started, recover the same request below.")

    pending_reels = list_pending_reels()
    if pending_reels:
        st.divider()
        st.subheader("Recover a saved Flow request")
        st.caption("Recovery opens the saved project and downloads the exact requested asset; it does not send another generation prompt or intentionally spend another video-generation credit.")
        pending_labels = {
            row["reel_id"]: f"{row.get('title', row['reel_id'])} · {row['reel_id']} · {row.get('status', 'pending')}"
            for row in pending_reels
        }
        pending_id = st.selectbox("Unfinished reel", list(pending_labels),
                                  format_func=lambda key: pending_labels[key], key="mini-reel-pending-id")
        if st.button("♻️ Recover exact saved Flow video", key="mini-reel-recover-saved"):
            try:
                with st.spinner("Scanning the saved Flow project and retrying download only…"):
                    result = recover_flow_reel(pending_id)
                st.success("Saved Flow video recovered.")
                compact_video(result["output_path"])
                st.download_button("⬇️ Download recovered mini reel", Path(result["output_path"]).read_bytes(),
                                   file_name=f"{pending_id}.mp4", mime="video/mp4",
                                   key=f"mini-reel-recovered-download-{pending_id}")
            except Exception as exc:
                st.error(f"Recovery did not complete: {exc}")

# ================= CREATE =================
elif page == "CREATE":
    st.title("Advanced Create")
    st.caption("Full-control path for provider routing, scene allocation, retry and credit budgets. For a shorter guided path, choose **Guided Studio**.")
    st.info("For credit-bearing Flow work, keep the per-generation and per-video caps at amounts you accept. Use a dry run or plan-only pass first when you want to inspect the plan without launching production.")
    with st.expander("⚡ FIRST TIME HERE? Make a FREE test video in one click (no login, no Chrome, ~3 min)", expanded=True):
        st.caption("Uses free AI images + motion + voiceover. Proves everything works before you touch Flow.")
        with st.form("quickfree"):
            qtopic = st.text_input("Topic", value="Why octopuses have three hearts", key="qtopic")
            qgo = st.form_submit_button("⚡ MAKE MY FIRST FREE VIDEO", type="primary")
        if qgo:
            if not qtopic.strip():
                st.warning("Enter a topic first.")
            else:
                qid = F.create_job(qtopic.strip(), "shorts", 20, "9:16", "en",
                                   "en-IN-PrabhatNeural", "education", "cinematic",
                                   "cinematic_realism", "LOCAL_FREE",
                                   budgets={"MAX_CREDITS_PER_VIDEO": 0, "MAX_RETRIES_PER_SHOT": 2},
                                   dry_run=False, tts_provider="edge", images_per_shot=0)
                st.session_state.job_id = qid
                st.success(f"Job created: `{qid}`")
                run_with_ui(qid, "🆓 LOCAL FREE ·")
    create_audio_mode = st.radio("Audio mode", ["Voiceover", "Music only", "Silent"], horizontal=True, key="create-audio-mode")
    create_voice_on = create_audio_mode == "Voiceover"
    from engine.content_library import CharacterLibrary
    create_characters = CharacterLibrary().list()
    from engine.studio_widgets import cast_picker
    create_cast = cast_picker(st,'advanced-cast')
    with st.form("create"):
        topic = st.text_input("Topic / idea", placeholder="Why waking up at 5 AM doesn't automatically make you successful")
        c1, c2, c3 = st.columns(3)
        video_type = c1.selectbox("Format", ["shorts", "faceless_youtube", "explainer", "marketing"])
        duration = c2.slider("Target seconds", 15, 600, 45)
        content_type = c3.selectbox("Content type", CONTENT_TYPES)
        c4, c5, c6 = st.columns(3)
        voice = c4.selectbox("Voice", VOICES, disabled=not create_voice_on)
        preset = c5.selectbox("Style preset", PRESETS)
        profile = c6.selectbox("Quality profile", PROFILES, index=0, format_func=lambda p: f"{mode_badge[p]} {p}")
        pr1, pr2 = st.columns(2)
        create_cards = pr1.checkbox("Include text cards", value=False, help="Optional editorial cards; speech captions have a separate control below.")
        create_card_style = pr2.selectbox("Text card style", ["auto", "bold", "playful", "clean"])
        pm1, pm2, pm3 = st.columns(3)
        create_music = pm1.selectbox("Background music", ["off", "auto", "local", "browser", "generated", "reliable"],
                                    index=1 if create_audio_mode == "Music only" else 0, disabled=create_audio_mode == "Silent")
        create_music_path = pm2.text_input("Licensed local music path")
        create_captions = pm3.selectbox("Speech captions", ["auto", "full", "none"], disabled=not create_voice_on)
        with st.expander("Advanced"):
            a1, a2, a3 = st.columns(3)
            tone = a1.selectbox("Tone", ["cinematic", "exciting", "calm", "funny", "documentary"])
            language = a2.selectbox("Language", ["en", "hi", "or"])
            tts_provider = a3.selectbox("TTS", ["edge", "gtts", "kokoro", "chatterbox"], disabled=not create_voice_on)
            b1, b2 = st.columns(2)
            max_credits = b1.number_input("MAX CREDITS PER VIDEO", 0, 2000, 50,
                                          help="Storyboard Economy treats this as a hard planning ceiling; 0 = image/stock only.")
            max_retries = b2.number_input("MAX RETRIES PER SHOT", 0, 5, 1)
            images_per_shot = st.slider("Extra candidate images per shot", 0, 4, 0,
                                        help="Storyboard Economy already makes opening/closing frames. Keep this 0 unless you want extra candidates.")
            st.markdown("**🌱 Storyboard Economy controls**")
            e1, e2, e3, e4 = st.columns(4)
            video_share = e1.slider("AI-video scene share", 0.0, 1.0, 0.20, 0.05,
                                    help="Automatic target fraction of scenes worth spending Flow video credits on.")
            stock_share = e2.slider("Stock-video scene share", 0.0, 1.0, 0.60, 0.05,
                                    help="Meaningful generic B-roll can use your local Pexels/stock library or optional stock APIs.")
            flow_scenes_ui = e3.number_input("Exact Flow scenes (0=auto)", 0, 100, 0,
                                             help="Explicit requested count. Budget safety still wins.")
            max_flow_scenes_ui = e4.number_input("Max Flow scenes (0=no cap)", 0, 100, 0)
            f1, f2, f3 = st.columns(3)
            frame_source = f1.selectbox("Opening/closing frame source", ["auto", "flow", "free"], index=0,
                                        help="auto = try Flow Agent image generation then free/local fallback; free = never use Flow for frames.")
            flow_approval = f2.selectbox("Flow credit approval", ["once", "manual", "always"], index=0,
                                         help="once is safest: AutoVideoAI only approves a generation within your per-generation cap.")
            max_generation_credits = f3.number_input("Max credits per Flow generation", 0, 200, 10,
                                                     help="Credit guard. If Flow asks for more, AutoVideoAI leaves it unapproved.")
            flow_pause_on_unresolved_request = st.checkbox(
                "Pause when a Flow request cannot be safely recovered (opt-in)",
                value=_flow_pause_setting_default(),
                help="Off by default: ambiguous images use the free fallback in auto mode; strict image/video requests fail without PAUSED status and can be explicitly resumed. On: save the request and pause for your choice. Recovery retries download-only and verifies request identity; it never regenerates merely because a gallery scan misses an image.")
        from engine.studio_widgets import broll_settings
        create_broll=broll_settings(st,'advanced-broll')
        dry = st.checkbox("DRY RUN (plan + estimate, spend nothing)", value=("FLOW" in profile or "MANUAL" in profile or profile == "STORYBOARD_ECONOMY"))
        submitted = st.form_submit_button("🚀 GENERATE", type="primary")
    if submitted:
        if not topic.strip():
            st.warning("Enter a topic first.")
        else:
            aspect = "9:16" if video_type == "shorts" or (video_type == "marketing" and duration <= 65) else "16:9"
            job_id = F.create_job(topic, video_type, duration, aspect, language, voice,
                                   content_type, tone, preset, profile, external_video_mode=external_video_mode_ui, character_ids=create_cast,
                                   budgets={"MAX_CREDITS_PER_VIDEO": max_credits, "MAX_RETRIES_PER_SHOT": max_retries},
                                   dry_run=dry, tts_provider=tts_provider,
                                   images_per_shot=images_per_shot,
                                   video_share=video_share, stock_share=stock_share,
                                   flow_scenes=(int(flow_scenes_ui) or None),
                                   max_flow_scenes=(int(max_flow_scenes_ui) or None),
                                   frame_source=frame_source, flow_approval=flow_approval,
                                   max_generation_credits=int(max_generation_credits),
                                   flow_pause_on_unresolved_request=flow_pause_on_unresolved_request,
                                   voiceover_enabled=create_voice_on, text_cards_enabled=create_cards,
                                   text_card_style=create_card_style,
                                   background_music="off" if create_audio_mode == "Silent" else create_music,
                                   background_music_path=create_music_path.strip(),
                                   caption_display=create_captions if create_voice_on else "none",
                                   sound_effects_enabled=create_voice_on, ambience_enabled=create_voice_on, **create_broll)
            st.session_state.job_id = job_id
            st.success(f"Job created: `{job_id}`" + (" — **DRY RUN** (no credits)" if dry else ""))
            run_with_ui(job_id, "🧪 DRY RUN ·" if dry else ("🌱 ECONOMY STORYBOARD ·" if profile == "STORYBOARD_ECONOMY" else ("💳 FLOW CREDITS ·" if profile.startswith("FLOW") or profile == "MANUAL_DIRECTOR" else "🆓 LOCAL FREE ·")))
    if st.session_state.job_id:
        st.divider()
        pipeline_view(st.session_state.job_id)

# ================= STORYBOARD =================
elif page == "STORYBOARD":
    st.title("Storyboard")
    if not st.session_state.job_id:
        st.info("Select a job in the sidebar.")
    else:
        m = F.pm.load_manifest(st.session_state.job_id)
        D = F.pm.dirs(st.session_state.job_id)
        st.caption(f"{m.job_id} · {m.profile} · {len(m.shots)} shots")
        try:
            est = json.load(open(os.path.join(D["root"], "budget.json"), encoding="utf-8"))
            st.info(f"💳 Estimated {est['estimated_credits']} + reserve {est['retry_reserve']} = **{est['projected_total']}** (budget {est['max_per_video']}, within={est['within_budget']})")
        except Exception:
            pass
        rows = [{"shot": s.shot_id, "voice": f"{s.voice_start:.1f}-{s.voice_end:.1f}s",
                 "coverage": s.coverage, "strategy": getattr(s, "media_strategy", ""),
                 "est_credits": getattr(s, "estimated_credits", 0),
                 "priority": s.priority, "provider": s.provider,
                 "model": s.model, "gen_s": s.gen_duration, "takes": s.num_candidates,
                 "status": s.status} for s in m.shots]
        df = pd.DataFrame(rows)
        edited = st.data_editor(df, width="stretch", key="sb_table",
                                column_config={"model": st.column_config.SelectboxColumn(options=["omni_draft", "omni_standard", "veo_lite", "veo_fast", "veo_quality", "wan_t2v", "wan_i2v", "ltx_t2v", "stock", "kenburns_plus"]),
                                               "priority": st.column_config.SelectboxColumn(options=["LOW", "NORMAL", "HERO"]),
                                               "status": st.column_config.SelectboxColumn(options=["planned", "approved", "skipped"])})
        if st.button("💾 Save storyboard edits"):
            for _, r in edited.iterrows():
                s = next(x for x in m.shots if x.shot_id == r["shot"])
                s.priority, s.model, s.gen_duration, s.num_candidates, s.status = \
                    r["priority"], r["model"], int(r["gen_s"]), int(r["takes"]), r["status"]
                from engine.routing.credit_router import MODEL2PROVIDER
                s.provider = MODEL2PROVIDER.get(s.model, "flow")
                F.pm.update_shot(m.job_id, s)
            st.success("Saved. Resume from QUEUE to generate with these settings.")
        script_p = os.path.join(D["root"], "script.md")
        if os.path.exists(script_p):
            st.download_button("📜 Download full script (markdown)",
                               open(script_p, "rb"), file_name=f"{m.job_id}_script.md")
        for s in m.shots:
            with st.expander(f"{s.shot_id} · {s.coverage} · {s.status} · {s.model}"):
                c1, c2 = st.columns([1, 2])
                frame = os.path.join(D["storyboard"], f"{s.shot_id}.jpg")
                if os.path.exists(frame):
                    c1.image(frame, caption="Best reference" if s.reference_assets else "Storyboard frame")
                else:
                    c1.caption("(no frame yet)")
                c2.caption(f"🎙️ {s.voice_start:.1f}–{s.voice_end:.1f}s: {s.narration[:220]}")
                c2.code(s.compiled_prompt or "(prompt compiles at generation time)", language="text")
                if s.reference_assets:
                    st.caption(f"🖼️ {len(s.reference_assets)} scene stills (best first)")
                    available = [(i, p) for i, p in enumerate(s.reference_assets) if Path(p).is_file()]
                    if available:
                        st.image([p for _, p in available], caption=[f"#{i+1}" for i, _ in available], width=180)
                    missing = len(s.reference_assets) - len(available)
                    if missing:
                        st.warning(f"{missing} saved reference file(s) are missing. Migrate the old installation before resuming this job.")
                if s.retry_history:
                    c2.warning("Retries: " + " | ".join(s.retry_history))

# ================= DIRECTOR REVIEW =================
elif page == "DIRECTOR REVIEW":
    st.title("Director Review")
    if not st.session_state.job_id:
        st.info("Select a job in the sidebar.")
    else:
        m = F.pm.load_manifest(st.session_state.job_id)
        D = F.pm.dirs(st.session_state.job_id)
        for s in m.shots:
            with st.expander(f"{s.shot_id} · {s.status} · retries {s.retry_count}", expanded=(s.status != "accepted")):
                shot_dir = os.path.join(D["flow"], "shots", s.shot_id)
                takes = sorted(glob.glob(os.path.join(shot_dir, "take_*.mp4")))
                if not takes:
                    st.caption("No takes yet.")
                    continue
                for t in takes:
                    name = os.path.basename(t)
                    qc = {}
                    qp = os.path.join(D["qc"], f"{s.shot_id}_{os.path.splitext(name)[0]}.json")
                    if os.path.exists(qp):
                        qc = json.load(open(qp, encoding="utf-8"))
                    c1, c2 = st.columns([2, 1])
                    c1.video(t)
                    c2.write(f"**{name}**")
                    if qc:
                        c2.write(f"overall **{qc.get('overall')}** · {qc.get('decision')}")
                        c2.caption(f"tech {qc.get('technical')} · cont {qc.get('continuity')} · motion {qc.get('motion')} · fail: {qc.get('failure')}")
                    is_acc = s.accepted_take and os.path.basename(s.accepted_take) == name or (os.path.exists(os.path.join(shot_dir, "accepted.mp4")) and name == sorted(takes)[-1] and False)
                    if st.button(f"✅ Accept {name}", key=f"acc-{s.shot_id}-{name}"):
                        import shutil
                        shutil.copy(t, os.path.join(shot_dir, "accepted.mp4"))
                        s.accepted_take = os.path.join(shot_dir, "accepted.mp4")
                        s.status = "accepted"
                        F.pm.update_shot(m.job_id, s)
                        DB.bump(m.job_id, "accepted_shots")
                        st.success(f"{s.shot_id} accepted: {name}")
                        st.rerun()
                if st.button(f"🔁 Regenerate {s.shot_id} (spends credits!)", key=f"regen-{s.shot_id}"):
                    s.status = "planned"
                    s.accepted_take = None
                    F.pm.update_shot(m.job_id, s)
                    st.info("Marked for regeneration. Resume from QUEUE.")

# ================= QUEUE =================
elif page == "QUEUE":
    st.title("Queue")
    from engine.job_monitor import is_running
    jobs = [{**j, 'status':'running' if is_running(F.pm.job_dir(j['job_id'])) else j['status']} for j in jobs]
    rows = [{"job": j["job_id"][:40], "status": j["status"], "profile": j["profile"],
             "est": j["est_credits"], "gens": j["actual_generations"],
             "✅": j["accepted_shots"], "❌": j["rejected_shots"],
             "retries": j["retry_count"], "updated": j["updated_at"]} for j in jobs]
    st.dataframe(pd.DataFrame(rows), width="stretch")
    from engine.clip_render_jobs import discover as discover_clip_renders
    clip_render_jobs = discover_clip_renders((F.pm.root, 'outputs'))
    if clip_render_jobs:
        with st.expander(f"Clip render jobs · {len(clip_render_jobs)}", expanded=any(row['running'] for row in clip_render_jobs)):
            st.caption('Persistent Clip Studio renders continue when this browser tab closes. Open any saved render below to monitor or resume it.')
            for clip_render in clip_render_jobs:
                monitor_clip_render(clip_render['state']['review_path'])
    if st.session_state.job_id:
        monitor_job(st.session_state.job_id)
        from engine.job_monitor import snapshot
        job_active = snapshot(F.pm.job_dir(st.session_state.job_id))["running"]
        selected_row = DB.get(st.session_state.job_id) or {}
        current_flow_pause = bool(F._settings(st.session_state.job_id).get(
            "flow_pause_on_unresolved_request", False))
        with st.expander("Flow recovery behavior", expanded=False):
            replace_images = st.checkbox('Regenerate unresolved images once after 3 recovery retries',
                value=bool(F._settings(st.session_state.job_id).get('flow_replace_unresolved_images',False)),key='replace-images-'+st.session_state.job_id)
            replacement_cap = st.number_input('Maximum replacement images for this whole job',1,100,
                int(F._settings(st.session_state.job_id).get('flow_image_replacement_limit',30)),key='replacement-cap-'+st.session_state.job_id)
            st.caption('Image-only; may leave unused duplicates. One replacement per image, recorded before submission. Videos stay download-only. Paid image confirmations are blocked.')
            if st.button('Save image replacement policy',key='save-replace-'+st.session_state.job_id):
                F.set_flow_image_replacement(st.session_state.job_id,replace_images,int(replacement_cap))
                st.success('Policy saved for all future Resume attempts of this job.')
            local_close = st.checkbox('Use the saved opening image if a closing image cannot recover',
                value=bool(F._settings(st.session_state.job_id).get('flow_local_closing_fallback', False)),
                key='local-close-'+st.session_state.job_id,
                help='Changes closing guidance for that shot. Keeps the pending Flow request. No replacement image generation; normal video generation still uses the job credit budget. Missing openings and videos still need exact recovery.')
            if st.button('Save local closing recovery policy',key='save-local-close-'+st.session_state.job_id):
                F.set_flow_local_closing_fallback(st.session_state.job_id,local_close)
                st.success('Saved for this job and future Resume attempts.')
            batch_choice = st.checkbox("Continue other frames when an exact Flow image is unresolved",
                value=bool(F._settings(st.session_state.job_id).get("flow_continue_unresolved_frames", False)),
                key=f"flow-frame-batch-{st.session_state.job_id}",
                help="Strict Flow Storyboard Economy only. Preserves quality: no local fallback or replacement image. Processes other frames, then pauses once with a complete recovery summary.")
            if st.button("Save frame recovery policy", key=f"save-frame-batch-{st.session_state.job_id}"):
                try:
                    F.set_flow_frame_batch_recovery(st.session_state.job_id, batch_choice)
                    st.success("Saved for Resume. Completed frames are reused; unresolved requests stay protected.")
                except ValueError as error:
                    st.error(str(error))
            batch_report_path = os.path.join(F.pm.job_dir(st.session_state.job_id), "flow_frame_recovery_batch.json")
            if os.path.isfile(batch_report_path):
                with open(batch_report_path, encoding="utf-8") as handle:
                    batch_report = json.load(handle)
                st.caption(f"Saved valid frames: {batch_report.get('valid_frames', 0)}; unresolved: {len(batch_report.get('unresolved', []))}")
                if batch_report.get("unresolved"):
                    st.dataframe([{k: item.get(k) for k in ("shot_id", "frame", "error")} for item in batch_report["unresolved"]], width="stretch")
            pause_flow_choice = st.checkbox(
                "Pause this job if a Flow request cannot be safely recovered",
                value=current_flow_pause, key=f"flow-pause-policy-{st.session_state.job_id}",
                help="Off: auto-frame images use a free fallback; strict Flow/video requests fail without automatic PAUSED status. On: preserve the request and pause. Recovery never submits a replacement based on gallery absence.")
            if st.button("Save Flow recovery choice", key=f"save-flow-pause-policy-{st.session_state.job_id}"):
                F.set_flow_pause_on_unresolved_request(st.session_state.job_id, pause_flow_choice)
                st.success("Saved. This choice applies the next time the job is resumed.")
        if selected_row.get("status") in ("paused", "assisted", "failed"):
            pause_panel(st.session_state.job_id)
            st.divider()
        runtime_manifest = F.pm.load_manifest(st.session_state.job_id)
        if not runtime_manifest.shots:
            with st.expander('Approved narration is shorter than the target?'):
                st.caption('Use the measured speech length instead of extending or rewriting the approved script. A 121.8-second narration yields about 122 seconds, not 169. Available before scene planning only.')
                if st.button('Use measured narration length for this job'):
                    F.use_measured_narration_runtime(st.session_state.job_id)
                    st.success('Saved. Resume this same job to reuse narration and plan at its measured length.')
        presentation_editor(st.session_state.job_id)
        with st.expander('External AI video clips · prompts and uploads · optional'):
            from engine.external_video import export_plan, configure, import_clip
            external_manifest = F.pm.load_manifest(st.session_state.job_id)
            external_options = [s.shot_id for s in external_manifest.shots]
            external_selected = st.multiselect('Shots to generate on Flow or another platform', external_options,
                default=[s.shot_id for s in external_manifest.shots if s.provider in ('flow','movieflow') and not s.accepted_take], key='external-shot-selection')
            st.caption('Export prompts with shot durations and reference paths. External mode waits for these clips before continuing; each import runs normal QC.')
            if st.button('Export selected shot prompts and wait for external clips', disabled=job_active or not external_selected):
                try:
                    external_report=configure(F,st.session_state.job_id,external_selected,True)
                    st.success('External mode saved for the selected shots.')
                except Exception as error:st.error(str(error))
            external_root=Path(F.pm.job_dir(st.session_state.job_id))/'external_video'
            if (external_root/'prompts.md').is_file():
                st.download_button('Download external shot prompts', (external_root/'prompts.md').read_text(), file_name='external-shot-prompts.md')
                st.caption(str(external_root/'incoming'))
            external_unaccepted=[s.shot_id for s in external_manifest.shots if not s.accepted_take]
            if external_unaccepted:
                external_id=st.selectbox('Import video for shot',external_unaccepted,key='external-import-id')
                external_file=st.file_uploader('Completed external MP4',type=['mp4'],key='external-import-file')
                if external_file: st.video(external_file)
                external_platform=st.text_input('Generation platform / source',key='external-platform')
                external_reviewed=st.checkbox('I reviewed this video and its rights for the selected shot',key='external-reviewed')
                external_replace=st.checkbox('Replace this shot’s unresolved Flow request with this reviewed clip, if present',key='external-replace')
                if st.button('Import external video and run QC',disabled=job_active or not external_file or not external_reviewed):
                    try:
                        stage=external_root/'incoming'/f'{external_id}.mp4';stage.parent.mkdir(parents=True,exist_ok=True);stage.write_bytes(external_file.getvalue())
                        st.json(import_clip(F,st.session_state.job_id,external_id,stage,reviewed=True,platform=external_platform,replace_pending=external_replace))
                    except Exception as error:st.error(str(error))
            if st.button('Return selected shots to automatic production', disabled=job_active or not external_selected):
                try:configure(F,st.session_state.job_id,external_selected,False);st.success('Automatic production restored. Pending journals still require reconciliation.')
                except Exception as error:st.error(str(error))
        with st.expander('Repair an unaccepted shot from its saved storyboard — local only'):
            repair_manifest = F.pm.load_manifest(st.session_state.job_id)
            repair_shots = [s for s in repair_manifest.shots if not s.accepted_take]
            if repair_shots:
                repair_id = st.selectbox('Shot to repair', [s.shot_id for s in repair_shots], key='repair-storyboard-shot')
                repair_shot = next(s for s in repair_shots if s.shot_id == repair_id)
                st.write(repair_shot.visual_goal)
                repair_start, repair_end = F.storyboard_repair_frames(st.session_state.job_id, repair_id)
                for label, image_path in [('Opening', repair_start), ('Closing', repair_end)]:
                    if image_path and os.path.isfile(image_path): st.image(image_path, caption=label, width=250)
                repair_reviewed = st.checkbox('I reviewed these frames and they depict the intended scene', key=f'repair-storyboard-reviewed-{st.session_state.job_id}-{repair_id}')
                st.caption('Creates a local pan/zoom transition, not new character animation. QC still decides acceptance. Other shots and Flow requests are preserved.')
                if st.button('Repair this shot and run QC', disabled=not repair_reviewed):
                    try:
                        with st.spinner('Rendering local storyboard repair…'):
                            repair_result = F.repair_storyboard_shot(st.session_state.job_id, repair_id, reviewed=True)
                        st.json(repair_result)
                    except Exception as error: st.error(str(error))
            elif repair_manifest.shots: st.info('All shots have accepted takes.')
            else: st.info('No shots are ready yet. Resolve the planning or reference-image error above, then resume this saved job.')
        c1, c2 = st.columns(2)
        if c1.button("▶️ Resume / continue job", type="primary", disabled=job_active):
            run_with_ui(st.session_state.job_id, "")
        if c2.button("🎬 Render now (from accepted takes)", disabled=job_active):
            with st.spinner("Rendering..."):
                try:
                    r = F.render_job(st.session_state.job_id)
                    st.success(f"Done: {r['video']} ({r['renderer']})")
                    compact_video(r["video"])
                except Exception as e:
                    st.error(f"Render failed: {e}")

# ================= FLOW SESSION =================
elif page == "FLOW SESSION":
    st.title("Flow Session")
    from engine.providers.flow_browser import FlowBrowserProvider, FlowBrowser
    prov = FlowBrowserProvider()
    st.write("Provider:", prov.status().reason or ("available" if prov.status().available else "unavailable"))
    st.caption("Change browser in SETTINGS → Browser (auto = your Chrome first). "
               "Missing bundled browser? Run: `python3 -m playwright install chromium` — "
               "or skip the download and use system/CDP mode.")
    st.caption("First run opens a visible browser — log into Google YOURSELF. Passwords are never automated or stored. Profile: `.flow-profile/` (git-ignored).")
    c1, c2, c3 = st.columns(3)
    if c1.button("🔑 Open Flow (login / check session)"):
        b = FlowBrowser(headless=False)
        with st.spinner("Browser open — complete any Google login manually (5 min max)..."):
            try:
                b.ensure_session(visible_login_seconds=300)
                st.success(f"Session OK. Logged in: {b.is_logged_in()}")
            except Exception as e:
                st.error(str(e))
            finally:
                b.close()
    if c2.button("🌐 Open Flow website"):
        st.markdown("[Open labs.google/fx](https://labs.google/fx)")
    if c3.button("🧪 Dry-run check (no browser)"):
        st.success("Dry runs never launch a browser or spend credits. Use CREATE with DRY RUN checked.")
    if st.button("🩺 Run browser diagnostics"):
        from engine.providers.flow_browser import doctor_report
        st.code(doctor_report(), language="text")
    with st.expander("🔗 Attach to YOUR open Chrome (CDP — recommended on WSL)", expanded=False):
        from engine.providers.flow_browser import probe_cdp, cdp_is_live
        st.caption("This drives your already-open, already-logged-in Chrome — no second login, no bundled download, no profile juggling.")
        st.markdown("**Windows:** run `chrome-debug.bat` (in the project folder). **Mac/Linux:** `./chrome-debug.sh`. Then paste the port below.")
        cdp_in = st.text_input("Chrome debug URL", value="http://127.0.0.1:9222",
                               help="Also settable permanently via FLOW_CDP_URL or SETTINGS → Browser.")
        _r = probe_cdp(cdp_in)
        if cdp_is_live(cdp_in):
            st.success(f"✅ Detected: {_r.get('browser', '?')} — browser mode 'auto' will attach here.")
        else:
            st.warning(f"Not reachable ({_r.get('error', '?')}). Start Chrome with the launcher above, then retry.")
    st.divider()
    st.subheader("🧑‍✈️ Assisted Flow Mode")
    if st.session_state.job_id:
        selected_row = DB.get(st.session_state.job_id) or {}
        if selected_row.get("status") in ("paused", "assisted"):
            pause_panel(st.session_state.job_id)
            st.divider()
    st.caption("Use the saved-request recovery controls above. Manual prompt generation and newest-file association have been removed from this page.")

# ================= CLIP STUDIO =================
elif page == "CLIP STUDIO":
    st.title("Clip Studio")
    clip_mode=st.selectbox('Clip Studio task',['highlights','convert','split'],
        format_func=lambda x:{'highlights':'Find highlights with Gemini','convert':'Convert whole video · face crop 9:16','split':'Cut music video into shots'}[x])
    if clip_mode != 'highlights':
        from engine.local_edit_ui import local_edit_controls
        local_edit_controls(st,clip_mode)
        st.stop()
    st.caption("Find strong self-contained moments with Gemini video analysis, then verify the exact cuts against local speech timing. Gemini scores are editorial estimates—not promises of virality.")
    source = st.text_input("Source video", placeholder="Permitted YouTube, Facebook, Instagram URL or local video path")
    st.caption('Public URLs use yt-dlp when the site supports extraction. Private/login-only or unavailable posts require a permitted local download. Gemini URL visual analysis is YouTube-only; other sources use speech-transcript ranking.')
    c1, c2, c3 = st.columns(3)
    count = c1.number_input("Output clips", 1, 10, 3)
    min_seconds = c2.number_input("Minimum seconds", 8, 120, 25)
    max_seconds = c3.number_input("Maximum seconds", 10, 180, 55)
    r1, r2, r3 = st.columns(3)
    ranking = r1.selectbox("Clip selection", ["gemini-hybrid", "auto", "gemini-api-hybrid",
                                               "gemini-web-hybrid", "groq", "local"],
                           help="Gemini hybrid tries API, then the visible signed-in browser, then Groq/local.")
    captions = r2.selectbox("Speech timing", ["auto", "groq", "local"])
    clip_language = st.selectbox('Clip transcript language',['en','hi','or'],format_func=lambda x:{'en':'English','hi':'Hindi','or':'Odia / Oriya'}[x])
    clip_captions_on=st.checkbox('Include speech captions',value=True,help='Off removes burned captions; speech timing is still used to select highlights.')
    reviewed_clip_transcript=st.file_uploader('Reviewed timed transcript JSON (optional; required for Odia)',type=['json'],key='clip-reviewed-transcript')
    from engine.gemini_transcript import transcript_controls
    try: uploaded_clip_transcript=json.loads(reviewed_clip_transcript.getvalue()) if reviewed_clip_transcript else None
    except Exception as error:st.error('Invalid transcript JSON: '+str(error));uploaded_clip_transcript=None
    gemini_clip_transcript=transcript_controls(st,'clip-odia',source,clip_language,uploaded_clip_transcript) if clip_language=='or' else None
    rights = r3.selectbox("Source rights", [
        "own_content", "written_permission", "licensed_content", "creative_commons",
        "public_domain", "commentary_or_review", "private_draft_only",
    ])
    st.warning("Captions, music, cropping, zoom or motion alone do not make somebody else's video copyright-safe. AutoVideoAI records your declaration but cannot grant legal rights.")
    output_dir = st.text_input("Output folder", value="outputs/my-clips")
    background_music = ""
    music_source = "pixabay"
    music_mood = "soft ambient instrumental"
    background_music_source_url = ""
    music_volume = 0.08
    clip_music_fallback = False
    music_choice = ""
    with st.expander("Background music · optional", expanded=False):
        clip_music_on = st.checkbox(
            "Add soft background music", value=False,
            help="Off preserves the current source-only audio. On adds a low, ducked bed while keeping speech clear; no music acknowledgement is required.")
        if clip_music_on:
            clip_music_fallback = st.checkbox('If optional music is unavailable, continue with original audio', value=True,
                help='The report records the failure. No replacement track or silent audio is substituted.')
            music_choice = st.radio(
                "Music source", ["Reviewed shared music library", "Reliable automatic music (local → Commons → Pixabay → original instrumental)", "Flow Music browser", "Pixabay internet search", "Local file / YouTube Audio Library download", "Generate original instrumental offline"],
                horizontal=True, key="clip-studio-music-source")
            if music_choice == 'Reviewed shared music library':
                from engine.audio.music_ui import library_panel
                music_source='local'
                music_mood=st.text_input('Clip topic / music mood for theme matching',value='soft ambient instrumental',key='clip-library-mood')
                background_music=library_panel(st,'clip-shared-music',music_mood)
                if not background_music:st.info('Import a reviewed track or choose one with matching theme tags before rendering clips.')
            elif music_choice == 'Flow Music browser':
                from engine.studio_widgets import flow_music_picker
                music_source='local'
                background_music=flow_music_picker(st,'clip-flow-music','Create soft instrumental background music for '+str(source)+'. No vocals. Gentle melodic bed with space for dialogue, no dramatic volume jumps.')
                if not background_music:st.info('Generate, choose and download a song above before rendering clips with Flow Music.')
            elif music_choice.startswith('Reliable automatic'):
                music_source='reliable'
                music_mood=st.text_input('Background mood / search terms',value='soft ambient instrumental')
                st.caption('Tries a configured local track, then Pixabay; if unavailable, creates an original instrumental offline and records the fallback.')
            elif music_choice == "Pixabay internet search":
                music_source = "pixabay"
                music_mood = st.text_input(
                    "Soft instrumental search terms", value="soft ambient instrumental",
                    help="The exact query and selected track provenance are saved in highlights.json.")
                st.caption(
                    "AutoVideoAI searches Pixabay and records the item page, licence label and file hash. "
                    "Review the exact page/current terms; this is not a legal guarantee. YouTube Audio Library tracks are not scraped—download one from YouTube Studio and use the local-file option; some tracks require attribution.")
            elif music_choice == "Generate original instrumental offline":
                music_source = "generated"
                st.caption("Creates a quiet original instrumental locally; no browser, downloaded song or Flow credits.")
            else:
                music_source = "local"
                background_music = st.text_input(
                    "Local music file path (optional if your local music library is configured)", value="")
                background_music_source_url = st.text_input(
                    "Optional track page / artist / attribution note", value="",
                    help="Recorded with the clip report; include any attribution required by the source.")
            music_volume = st.slider("Music volume", 0.0, 0.35, 0.08, 0.01)
    gemini_cleanup = st.selectbox("Temporary Gemini browser chat", ["delete-after-read", "keep"])
    framing = st.selectbox(
        "Framing", ["face-crop", "fit"],
        format_func=lambda mode: {
            "face-crop": "Face crop — vertical 9:16",
            "fit": "Fit — preserve source orientation and full frame",
        }[mode],
        help="Fit preserves the full source picture and outputs in its original orientation/aspect ratio (landscape stays landscape; portrait stays portrait). Face crop creates a vertical 9:16 short and uses a static face estimate.")
    with st.expander("Channel logo · optional", expanded=False):
        clip_logo_on = st.checkbox("Show my channel logo on clips", value=False, key="clip-logo-on")
        from engine.brand_logo import logo_controls
        clip_logo_path, clip_logo_fraction = logo_controls(st, 'clip-brand', enabled=clip_logo_on)
        clip_logo_size = clip_logo_fraction*100
        clip_logo_position = st.selectbox("Logo corner", ["top-right", "top-left", "bottom-right", "bottom-left"], disabled=not clip_logo_on, key="clip-logo-position")
        st.caption("Transparent PNG is recommended. The selected logo is saved with these clips and retained in their B-roll versions.")
    clip_broll_enabled = st.checkbox(
        "Prepare related stock B-roll suggestions for these highlights",
        value=False,
        help="When enabled, AutoVideoAI searches after the highlights are rendered and previews the exact stock candidates. Review compact previews, then approve the batch once or edit individual suggestions. Approved inserts render as separate copies.")
    cb1, cb2, cb3 = st.columns(3)
    clip_broll_count = cb1.number_input(
        "Maximum B-roll suggestions per clip", 1, 150, 5, 1,
        disabled=not clip_broll_enabled, key="clip-studio-broll-count",
        help=("A maximum, not a guarantee. Several spaced suggestions can be prepared per highlight. "
              "A configured stock source may have no valid downloadable match; each unmatched slot shows why."))
    st.caption("B-roll repeats require at least 30 seconds and a different cutaway between uses. The reuse limit is a maximum, not a target. Production B-roll never covers AI/external video shots.")
    clip_broll_max_uses = st.selectbox("Maximum uses of one contextual B-roll asset", [1,2,3], disabled=not clip_broll_enabled, key="clip-broll-max-uses")
    clip_broll_duration = cb2.slider("Cutaway duration (seconds)", 0.5, 6.0, 2.0, 0.5,
                                      disabled=not clip_broll_enabled, key="clip-studio-broll-duration")
    clip_broll_replace = cb3.checkbox(
        "Replace previous suggestions", value=False,
        disabled=(not clip_broll_enabled or not st.session_state.get('clip_broll_review_path')),
        key="clip-studio-broll-replace")
    reaction_language = st.selectbox("Meme/reaction brief language", ["en", "hi", "or"], index=["en", "hi", "or"].index(clip_language))
    clip_broll_query_hint = ""
    if clip_broll_enabled:
        st.caption("B-roll workflow: render highlights → automatically find up to the selected maximum → compact previews → one batch approval → render approved cutaways. The original clips are never overwritten.")
        clip_broll_query_hint = st.text_input(
            "Optional English visual-search hint (useful for non-English transcript)", value="",
            key="clip-studio-broll-hint",
            help="Added to the highlight title/transcript for stock search; does not alter the clip.")
    confirmed = st.checkbox("I confirm the selected rights/licence declaration is accurate")
    if st.button("✂️ Analyse and create clips", type="primary", disabled=clip_music_on and music_choice in {"Flow Music browser", "Reviewed shared music library"} and not background_music):
        if not source.strip():
            st.error("Enter a YouTube URL or local video path.")
        elif not confirmed:
            st.error("Confirm the source-rights declaration before processing.")
        else:
            from engine.clipping import create_highlight_clips
            bar = st.progress(0)
            status = st.empty()
            def clip_progress(message, pct, info=""):
                bar.progress(max(0, min(100, int(pct))))
                status.code(f"{message}" + (f"\n{info}" if info else ""), language="text")
            try:
                result = create_highlight_clips(
                    (gemini_clip_transcript.get("source_path") if gemini_clip_transcript else None) or source.strip(), output_dir.strip() or "outputs/my-clips",
                    count=int(count), min_seconds=float(min_seconds),
                    max_seconds=float(max_seconds), caption_provider=captions,
                    ranking_provider=ranking, source_rights=rights,
                    language=clip_language, captions_enabled=clip_captions_on,
                    reviewed_transcript=gemini_clip_transcript or uploaded_clip_transcript,
                    background_music_enabled=clip_music_on,
                    background_music=background_music.strip(),
                    background_music_source=music_source, music_mood=music_mood,
                    background_music_source_url=background_music_source_url.strip(),
                    music_volume=float(music_volume),
                    music_failure_policy='continue-original' if clip_music_fallback else 'stop',
                    gemini_chat_cleanup=gemini_cleanup,
                    framing=framing, show_channel_logo=clip_logo_on,
                    channel_logo_path=clip_logo_path, channel_logo_position=clip_logo_position,
                    channel_logo_size=clip_logo_size / 100,
                    progress_cb=clip_progress)
                st.session_state['last_clip_result'] = result
                st.session_state.pop('clip_broll_review_path', None)
                st.session_state.pop('clip_broll_search_error', None)
                st.session_state.pop('clip_broll_search_summary', None)
                if clip_broll_enabled:
                    try:
                        from engine.broll import prepare_clip_studio_review
                        suggestion_limit = min(int(clip_broll_count), len(result.get("highlights") or []))
                        with st.spinner(
                                f"Searching for up to {suggestion_limit} reviewable B-roll candidate(s). "
                                "Nothing will be inserted until you approve it…"):
                            review_path, review = prepare_clip_studio_review(
                                result, max_candidates=int(clip_broll_count),
                                default_duration=float(clip_broll_duration),
                                query_hint=clip_broll_query_hint, per_clip=True, max_uses_per_asset=clip_broll_max_uses,
                                progress_cb=broll_search_progress_ui())
                        st.session_state['clip_broll_review_path'] = review_path
                        ready_count = sum(
                            1 for item in review.get("candidates", [])
                            if item.get("status") == "ready")
                        searched_count = len(review.get("candidates", []))
                        st.session_state['clip_broll_search_summary'] = (
                            ("Reopened the existing exact B-roll review; "
                             if review.get('_resumed_existing_review') else "") +
                            f"Found {ready_count} previewable B-roll candidate(s); "
                            f"{searched_count - ready_count} were unmatched/invalid. No B-roll is applied yet.")
                    except Exception as broll_exc:
                        st.session_state['clip_broll_search_error'] = (
                            f"Highlights were created, but B-roll search could not complete "
                            f"({type(broll_exc).__name__}: {str(broll_exc)[:300]}). Retry the search below; no insert was made.")
                st.success(f"Created {len(result['outputs'])} clips using {result['method']}.")
                music_info = result.get("music") or {}
                if music_info.get('warning'):
                    st.warning('Optional music unavailable; original audio retained: ' + music_info['warning'])
                if music_info.get("enabled"):
                    st.info(
                        "Soft music added at volume " + str(music_info.get("volume", 0)) +
                        " · source: " + str(music_info.get("source", "local-file")) +
                        " · licence label: " + str(music_info.get("license") or "not provided"))
                    if music_info.get("creator"):
                        st.caption("Music creator: " + str(music_info["creator"]))
                    if music_info.get("page_url"):
                        st.markdown(f"[Review exact music source page]({music_info['page_url']})")
                    if music_info.get("license_url"):
                        st.markdown(f"[Review provider licence summary]({music_info['license_url']})")
                    if music_info.get("provenance_note"):
                        st.caption(str(music_info["provenance_note"]))
                if result.get("partial_result"):
                    st.warning(result["shortfall_reason"])
                if result.get("ranking_fallback_reason"):
                    st.warning("Gemini fallback: " + result["ranking_fallback_reason"])
                for item in result["highlights"]:
                    st.subheader(item.get("title") or "Highlight")
                    qc = item.get("qc") or {}
                    st.caption(
                        f"{item['start']:.1f}s–{item['end']:.1f}s · "
                        f"quality {qc.get('quality_score', item.get('score', 0))}/100 · "
                        f"QC {qc.get('decision', 'not run')} · {item.get('ranking', 'local')} · "
                        f"{item.get('output_filename', '')}")
                    if qc and not qc.get("ready_to_publish"):
                        st.warning("Clip requires review: " + ", ".join(
                            qc.get("blocking_issues") or qc.get("review_issues") or
                            ["semantic relevance, hook/payoff, framing and publication rights are not certified by technical QC"]))
                    if item.get('render_error'):
                        st.error('This highlight failed: ' + item['render_error'])
                    elif item.get('output') and os.path.isfile(item['output']):
                        compact_video(item['output'])
            except Exception as exc:
                st.error(str(exc))
    from engine.clip_history import discover_batches as discover_clip_batches, load_batch as load_clip_batch
    saved_clip_batches = discover_clip_batches((output_dir.strip() or 'outputs/my-clips', 'outputs'))
    with st.expander(f"Saved clip jobs · {len(saved_clip_batches)}", expanded=bool(saved_clip_batches)):
        if saved_clip_batches:
            selected_clip_report = st.selectbox(
                "Choose a saved clip job",
                [row['report_path'] for row in saved_clip_batches],
                format_func=lambda value: next(row['label'] for row in saved_clip_batches
                                               if row['report_path'] == value),
                key='clip-saved-job-report')
            selected_clip_job = next(row for row in saved_clip_batches
                                     if row['report_path'] == selected_clip_report)
            st.caption(
                f"Source: {selected_clip_job['source']} · "
                f"Available clips: {selected_clip_job['available_clips']}/{selected_clip_job['highlight_count']} · "
                f"Folder: {selected_clip_job['folder']}")
            if st.button('Load selected clip job — no regeneration', key='clip-load-selected-job'):
                try:
                    saved_clip_result = load_clip_batch(selected_clip_report)
                    st.session_state['last_clip_result'] = saved_clip_result
                    st.session_state.pop('clip_broll_review_path', None)
                    st.session_state.pop('clip_broll_search_error', None)
                    st.session_state['clip_loaded_job_notice'] = (
                        f"Loaded saved clip job from {selected_clip_job['created_at']}. "
                        "Enable B-roll suggestions to reopen its exact review.")
                except Exception as error:
                    st.error(str(error))
        else:
            st.caption('No saved Clip Studio batches were found under the current output folder or outputs/.')
    if st.session_state.get('clip_loaded_job_notice'):
        st.success(st.session_state['clip_loaded_job_notice'])
    if st.button('Load latest highlights from the current output folder — no regeneration', key='clip-load-saved'):
        try:
            saved_clip_path = Path(output_dir.strip() or 'outputs/my-clips') / 'highlights.json'
            saved_clip_result = load_clip_batch(saved_clip_path)
            st.session_state['last_clip_result'] = saved_clip_result
            st.session_state.pop('clip_broll_review_path', None)
            st.session_state['clip_loaded_job_notice'] = (
                'Loaded the latest highlights from the current output folder. '
                'Enable B-roll suggestions, then search and review below.')
            st.success(st.session_state['clip_loaded_job_notice'])
        except Exception as error: st.error(str(error))
    saved_highlights = st.session_state.get('last_clip_result', {}).get('highlights', [])
    hook_sources = [str(x['output']) for x in saved_highlights if x.get('output') and Path(x['output']).is_file()]
    if hook_sources:
        from engine.audio.hooks import hook_panel
        hook_source = st.selectbox('Saved clip for optional sound hooks', list(dict.fromkeys(hook_sources)), format_func=lambda p:Path(p).name, key='clip-hooks-source')
        hook_panel(st, hook_source, 'clip-hooks-'+hashlib.sha256(hook_source.encode()).hexdigest()[:12])
    if clip_broll_enabled and st.session_state.get('last_clip_result'):
        from engine.broll import (load_review as load_clip_broll_review,
                                  prepare_clip_studio_review, save_review as save_clip_broll_review,
                                  validate_review_decisions)
        clip_result = st.session_state['last_clip_result']
        st.divider()
        st.subheader("🌿 Preview and approve B-roll cutaways")
        st.caption("The main clip action searches automatically when B-roll is enabled. Review compact previews, then approve available assets for the batch once. You can also approve one clip, skip a group or edit individual inserts. One final rendered copy per highlight contains its approved inserts.")
        if st.session_state.get('clip_broll_search_summary'):
            st.info(st.session_state['clip_broll_search_summary'])
        if st.session_state.get('clip_broll_search_error'):
            st.warning(st.session_state['clip_broll_search_error'])
        current_review_path = st.session_state.get('clip_broll_review_path')
        search_label = ("🔄 Replace B-roll suggestions with a new search"
                        if current_review_path else "🔎 Search related stock for these highlights")
        if st.button(search_label, key="clip-broll-search",
                     disabled=bool(current_review_path) and not clip_broll_replace):
            try:
                with st.spinner("Searching configured stock sources; no Flow/Veo generation is submitted…"):
                    review_path, review = prepare_clip_studio_review(
                        clip_result, max_candidates=int(clip_broll_count),
                        default_duration=float(clip_broll_duration), replace=clip_broll_replace,
                        query_hint=clip_broll_query_hint, per_clip=True, max_uses_per_asset=clip_broll_max_uses,
                                progress_cb=broll_search_progress_ui())
                st.session_state['clip_broll_review_path'] = review_path
                st.session_state.pop('clip_broll_search_error', None)
                ready_count = sum(1 for x in review.get("candidates", [])
                                  if x.get("path") and x.get("sha256"))
                missing_count = len(review.get("candidates", [])) - ready_count
                st.session_state['clip_broll_search_summary'] = (
                    ("Reopened the existing exact B-roll review with its saved decisions. "
                     if review.get('_resumed_existing_review') else "") +
                    f"Prepared {ready_count} previewable B-roll candidate(s) and "
                    f"{missing_count} unmatched/invalid result(s). Nothing is inserted yet.")
                st.success(st.session_state['clip_broll_search_summary'] +
                           " Review every candidate and save a decision before applying approved cutaways.")
            except Exception as exc:
                st.error(str(exc))
        clip_review_path = st.session_state.get('clip_broll_review_path')
        if clip_review_path and os.path.isfile(clip_review_path):
            try:
                review = load_clip_broll_review(clip_review_path)
                decision_version = hashlib.sha256(json.dumps([
                    [c.get('candidate_id'), c.get('sha256'), c.get('decision'), c.get('start'), c.get('duration'), c.get('rights_reviewed')]
                    for c in review.get('candidates', [])], sort_keys=True).encode()).hexdigest()[:12]
                review_widget_scope = str(review.get("review_id") or review.get("created_at") or "review") + '-' + decision_version
                candidates = review.get('candidates', [])
                groups = list(dict.fromkeys(str(c.get('clip_output') or '') for c in candidates))
                view_group = st.selectbox("Preview one clip's cutaways", groups,
                    format_func=lambda x: os.path.basename(x), key=f"broll-view-{review_widget_scope}") if groups else ''
                group_candidates = [c for c in candidates if str(c.get('clip_output') or '') == view_group]
                pages = max(1, (len(group_candidates) + 5) // 6)
                preview_page = st.selectbox("Preview page", list(range(pages)),
                    format_func=lambda x: f"{x+1} / {pages}", key=f"broll-page-{review_widget_scope}-{view_group}")
                visible_candidates = group_candidates[preview_page*6:(preview_page+1)*6]
                if view_group and os.path.isfile(view_group):
                    with st.expander("Original highlight", expanded=False):
                        compact_video(view_group)
                tiles = st.columns(3)
                for index, candidate in enumerate(visible_candidates):
                    with tiles[index % 3]:
                        st.caption(candidate.get('label', candidate.get('candidate_id', 'Cutaway')))
                        if candidate.get('path') and os.path.isfile(candidate['path']):
                            st.video(candidate['path'], width=240)
                        else:
                            st.caption(candidate.get('search_error') or 'Unavailable — batch approval will skip this slot')
                        st.caption(f"{candidate.get('source', 'stock')} · {candidate.get('license', 'Review source terms')}")
                        if candidate.get('page_url'):
                            st.markdown(f"[Source and licence]({candidate['page_url']})")
                batch_scope = st.radio("Batch decision applies to", ["All clips", "Previewed clip"], horizontal=True,
                                       key=f"broll-scope-{review_widget_scope}")
                batch_candidates = candidates if batch_scope == "All clips" else group_candidates
                batch_ids = [str(c['candidate_id']) for c in batch_candidates]
                available_batch_candidates = [c for c in batch_candidates
                                              if c.get('path') and c.get('sha256')]
                expected_hashes = {str(c['candidate_id']):c.get('sha256')
                                   for c in available_batch_candidates}
                unavailable_batch_count = len(batch_candidates) - len(available_batch_candidates)
                batch_confirmed = st.checkbox(f"I approve the listed B-roll assets and their rights for this batch ({len(available_batch_candidates)} available)",
                                             key=f"broll-confirm-{review_widget_scope}-{batch_scope}-{view_group}")
                st.caption(
                    "Batch approval verifies every available exact file and skips "
                    f"{unavailable_batch_count} unmatched/invalid slot(s). "
                    "Individual review remains optional below.")
                bapprove, bskip, brender = st.columns(3)
                from engine.broll import save_batch_decisions
                if bapprove.button("Approve available batch", disabled=not batch_confirmed, key=f"broll-approve-batch-{review_widget_scope}"):
                    save_batch_decisions(clip_review_path, batch_ids, 'approve', rights_confirmed=True,
                        expected_review_id=review.get('review_id'), expected_hashes=expected_hashes)
                    st.rerun()
                if bskip.button("Skip this batch", key=f"broll-skip-batch-{review_widget_scope}"):
                    save_batch_decisions(clip_review_path, batch_ids, 'skip',
                        expected_review_id=review.get('review_id'), expected_hashes=expected_hashes)
                    st.rerun()
                if brender.button("Approve all & render", disabled=not batch_confirmed or batch_scope != "All clips",
                                  key=f"broll-render-batch-{review_widget_scope}"):
                    save_batch_decisions(clip_review_path, batch_ids, 'approve', rights_confirmed=True,
                        expected_review_id=review.get('review_id'), expected_hashes=expected_hashes)
                    from engine.clip_render_jobs import start as start_clip_render
                    if not start_clip_render(clip_review_path):
                        st.info('This exact clip render is already running. Watching its saved progress.')
                    st.rerun()
                updates = {}
                with st.expander("Advanced individual decisions and placement", expanded=False):
                    for candidate in visible_candidates:
                        cid = str(candidate.get("candidate_id", "cutaway"))
                        st.markdown(f"**{candidate.get('label', cid)}**")
                        prior_output = str(candidate.get("broll_output") or "")
                        if prior_output and os.path.isfile(prior_output):
                            compact_video(prior_output)
                            st.caption("Applied B-roll version (separate rendered file); original highlight is unchanged")
                        with st.expander('Use an AI image, local stock photo or permitted meme for this slot'):
                            st.caption('Gemini writes an image prompt; the free image provider renders it. Gemini image downloading is not automated. Hindi/Odia meme briefs use Indian reaction themes; English uses global themes. Film memes need your own permitted asset and review.')
                            local_asset = st.text_input('Local image/video/meme path', key=f'local-cutaway-{review_widget_scope}-{cid}')
                            if st.button('Attach local asset for review', key=f'attach-cutaway-{review_widget_scope}-{cid}', disabled=not local_asset):
                                from engine.broll import replace_clip_candidate_asset
                                try:
                                    replace_clip_candidate_asset(clip_review_path, cid, local_asset)
                                    st.rerun()
                                except Exception as error: st.error(str(error))
                            if st.button('Create Gemini-planned AI image for review', key=f'ai-cutaway-{review_widget_scope}-{cid}'):
                                from engine.broll import generate_clip_candidate_image
                                try:
                                    with st.spinner('Gemini prompt → free image → local motion; no Flow generation'):
                                        generate_clip_candidate_image(clip_review_path, cid)
                                    st.rerun()
                                except Exception as error: st.error(str(error))
                            if st.button('Draft regional meme/reaction idea', key=f'meme-cutaway-{review_widget_scope}-{cid}'):
                                from engine.broll import draft_reaction_brief
                                try:
                                    draft_reaction_brief(clip_review_path, cid, language=reaction_language)
                                    st.rerun()
                                except Exception as error: st.error(str(error))
                            if candidate.get('reaction_brief'): st.write(candidate['reaction_brief'])
                        has_asset = bool(candidate.get("path") and os.path.isfile(candidate["path"]))
                        if has_asset:
                            st.video(candidate["path"], width=240)
                            st.caption("Search query: " + str(candidate.get("query", "")) +
                                       " · Source: " + str(candidate.get("source", "stock")) +
                                       " · Licence: " + str(candidate.get("license", "review required")) +
                                       (" · Creator: " + str(candidate.get("creator")) if candidate.get("creator") else ""))
                            if candidate.get("page_url"):
                                st.markdown(f"[Open stock source page]({candidate['page_url']})")
                            clip_duration = float(candidate.get("clip_duration") or 0)
                            max_start = max(0.0, clip_duration - 0.5)
                            cut_start = st.number_input("Cutaway start within this highlight (seconds)", 0.0, max_start,
                                                        min(max_start, max(0.0, float(candidate.get("start", 0) or 0))), 0.25,
                                                        key=f"clip-broll-start-{review_widget_scope}-{cid}")
                            max_cut = max(0.5, min(6.0, clip_duration - float(cut_start)))
                            cut_default = min(max_cut, max(0.5, float(candidate.get("duration", clip_broll_duration) or clip_broll_duration)))
                            cut_length = st.slider("Cutaway length (seconds)", 0.5, max_cut, cut_default, 0.5,
                                                   key=f"clip-broll-length-{review_widget_scope}-{cid}")
                            choices = ["pending", "approve", "skip"]
                        else:
                            st.warning(candidate.get("search_error", "No valid stock clip was found for this highlight."))
                            cut_start = float(candidate.get("start", 0) or 0)
                            cut_length = float(candidate.get("duration", clip_broll_duration) or clip_broll_duration)
                            choices = ["pending", "skip"]
                        saved = str(candidate.get("decision") or "pending").lower()
                        saved = {"approved": "approve", "skipped": "skip"}.get(saved, saved)
                        if saved not in choices:
                            saved = "pending"
                        decision = st.radio(
                            "Decision for this suggestion", choices,
                            index=choices.index(saved), horizontal=True,
                            format_func=lambda x: {"pending": "Pending review", "approve": "Approve insert", "skip": "Skip insert"}[x],
                            key=f"clip-broll-decision-{review_widget_scope}-{cid}")
                        reviewed = False
                        if decision == "approve" and has_asset:
                            reviewed = st.checkbox(
                                "I reviewed this exact stock clip and its current licence/rights",
                                value=bool(candidate.get("rights_reviewed")),
                                key=f"clip-broll-rights-{review_widget_scope}-{cid}")
                        updates[cid] = {"start": float(cut_start), "duration": float(cut_length),
                                        "decision": decision, "rights_reviewed": reviewed}
                try:
                    validate_review_decisions(clip_review_path, workflow="clip_studio")
                    decisions_complete = True
                except ValueError:
                    decisions_complete = False
                    st.caption("Use batch approval above, or save individual decisions for the remaining suggestions.")
                if st.button("💾 Save B-roll decisions", key="clip-broll-save"):
                    review = save_clip_broll_review(clip_review_path, updates)
                    n_approved = sum(1 for x in review.get("candidates", [])
                                     if x.get("approved") and x.get("rights_reviewed"))
                    n_skipped = sum(1 for x in review.get("candidates", [])
                                    if x.get("decision") == "skipped")
                    pending_count = len(review.get("candidates", [])) - n_approved - n_skipped
                    decisions_complete = pending_count == 0
                    st.success(f"Saved decisions: {n_approved} approved, {n_skipped} skipped, {pending_count} pending. Approved inserts are separate files; originals stay unchanged.")
                n_approved_saved = sum(1 for x in review.get("candidates", [])
                                       if x.get("approved") and x.get("rights_reviewed"))
                if st.button("🎬 Apply saved cutaways to separate copies",
                             disabled=(n_approved_saved == 0 or not decisions_complete),
                             key="clip-broll-apply"):
                    from engine.clip_render_jobs import start as start_clip_render
                    if not start_clip_render(clip_review_path):
                        st.info('This exact clip render is already running. Watching its saved progress.')
                    st.rerun()
                monitor_clip_render(clip_review_path)
            except Exception as exc:
                st.error("B-roll review failed: " + str(exc))

# ================= CONTENT INBOX =================
elif page == 'FINISHING STUDIO':
    from engine.finishing_ui import show as show_finishing
    show_finishing(st)

elif page == 'CONTENT INBOX':
    st.title('Source ideas & approved scripts')
    st.caption('Import an idea, not a licence or an instruction. Public source text is untrusted; no generation is submitted here.')
    from engine.source_inbox import SourceInbox
    from engine.content_plan import longform_template
    title = st.text_input('Source title')
    source_text = st.text_area('Paste permitted post/article text', height=180)
    source_url = st.text_input('Public allowlisted HTTPS article URL (optional)')
    feed_url = st.selectbox('Optional source feed',['https://technivella.com/feed/','https://factozone.com/feed/'])
    if st.button('Import up to 5 feed ideas — no generation'):
        try:
            st.json(SourceInbox().feed(feed_url,count=5))
        except Exception as error:
            st.error(str(error))
    if st.button('Save source idea — no generation'):
        try:
            inbox = SourceInbox()
            item = inbox.paste(source_text,title=title,source_url=source_url) if source_text.strip() else inbox.fetch(source_url)
            st.session_state['source_inbox_item'] = item
        except Exception as error:
            st.error(str(error))
    item = st.session_state.get('source_inbox_item')
    if item:
        st.json({key:value for key,value in item.items() if key != 'text'})
        brief = SourceInbox().brief_prompt(item)
        st.download_button('Download external-writer brief',brief,file_name='original-content-brief.txt')
        st.code(brief)
    st.subheader('Chapter-based long-form template')
    topic = st.text_input('Long-form topic')
    locale = st.selectbox('Template language',['en','hi','or'])
    if topic:
        st.download_button('Download chapter/evidence template',json.dumps(longform_template(topic,locale),indent=2,ensure_ascii=False),
                           file_name='approved-content-plan.json',mime='application/json')
    st.info('Fill narration, chapters/scenes and rights; review facts and set approved=true. Import that JSON from STUDIO. Arena browser automation and automatic commercial-output rights are not provided.')

# ================= CHARACTER LIBRARY =================
elif page == 'CHARACTER LIBRARY':
    st.title('Original fictional character library')
    from engine.content_library import CharacterLibrary
    library = CharacterLibrary()
    name = st.text_input('Character name')
    description = st.text_area('Physical identity, clothes, palette, personality and visual style')
    references = st.text_area('Authorized reference image paths, one per line (optional)')
    photos=st.file_uploader('Or upload character reference photos',type=['png','jpg','jpeg','webp'],accept_multiple_files=True,key='character-photo-upload')
    voice_style = st.selectbox('Default voice presentation',['unspecified','masculine','feminine'])
    original = st.checkbox('This is my original or authorized fictional character; not an impersonation')
    if st.button('Save character identity'):
        try:
            from engine.studio_widgets import save_uploaded_image
            paths=[p.strip() for p in references.splitlines() if p.strip()]
            paths += [save_uploaded_image(photo,'data/content/photo_imports') for photo in photos]
            st.json(library.create(name,description,reference_files=paths,original_confirmed=original,voice_style=voice_style))
        except Exception as error:
            st.error(str(error))
    from engine.studio_widgets import character_cards
    character_cards(st,library.list())
    for character in library.list():
        with st.expander(character['name']+' · '+character['id']):
            with st.form('character-edit-'+character['id']):
                edit_name = st.text_input('Name', value=character['name'])
                edit_description = st.text_area('Description', value=character['description'])
                edit_voice = st.selectbox('Default voice', ['unspecified','masculine','feminine'], index=['unspecified','masculine','feminine'].index(character.get('voice_style','unspecified')))
                replace_photos = st.checkbox('Replace reference photos')
                edit_photos = st.file_uploader('New reference photos',type=['png','jpg','jpeg','webp'],accept_multiple_files=True)
                st.caption('Uploaded photos replace this card’s photos when you click Update character. Existing approved jobs keep their saved originals.')
                clear_photos = st.checkbox('Remove photos for future jobs')
                if st.form_submit_button('Update character'):
                    try:
                        from engine.studio_widgets import save_uploaded_image
                        if clear_photos and edit_photos:
                            raise ValueError('Choose either uploaded replacement photos or Remove photos, not both')
                        if replace_photos and not edit_photos and not clear_photos:
                            raise ValueError('Upload a photo or explicitly choose Remove photos')
                        refs = ([] if clear_photos else [save_uploaded_image(photo,'data/content/photo_imports') for photo in edit_photos]) if (replace_photos or clear_photos or edit_photos) else None
                        library.update(character['id'],edit_name,edit_description,reference_files=refs,voice_style=edit_voice)
                        st.rerun()
                    except ValueError as error: st.error(str(error))
            delete_confirm = st.checkbox('Remove this character from the picker', key='archive-confirm-'+character['id'])
            if st.button('Delete character', disabled=not delete_confirm,key='archive-character-'+character['id']):
                library.archive(character['id']); st.rerun()
            st.caption('Existing jobs keep their original references. Updating or deleting this card affects future casting.')
            style=st.selectbox('Voice presentation',['unspecified','masculine','feminine'],index=['unspecified','masculine','feminine'].index(character.get('voice_style','unspecified')),key='char-style-'+character['id'])
            if st.button('Save voice presentation',key='save-char-style-'+character['id']):
                library.set_voice_style(character['id'],style);st.success('Voice preference saved for future speaker proposals.')
            if character['references']:
                crop=character.get('preview_crop',{'x':.5,'y':.3,'zoom':2.0})
                cx=st.slider('Card face position · left/right',0.0,1.0,float(crop['x']),key='crop-x-'+character['id'])
                cy=st.slider('Card face position · up/down',0.0,1.0,float(crop['y']),key='crop-y-'+character['id'])
                cz=st.slider('Card zoom',1.0,8.0,float(crop['zoom']),key='crop-z-'+character['id'])
                from PIL import Image
                from engine.studio_widgets import face_thumbnail
                with Image.open(character['references'][0]['path']) as source:
                    st.image(face_thumbnail(source,focus={'x':cx,'y':cy,'zoom':cz}),width=140)
                if st.button('Save card face crop',key='crop-save-'+character['id']):
                    library.set_preview_crop(character['id'],cx,cy,cz);st.rerun()
                st.caption('Preview only; original Flow reference photo is preserved.')
            for reference in character['references']:
                st.image(reference['path'],width=240)
    st.caption('Without a supplied reference, the recreation workflow asks Flow to generate a character master before scene images. Identity still needs visual review.')

# ================= AI RECREATE =================
elif page == 'AI RECREATE':
    st.title('Recreate an authorized clip with an original AI character')
    st.warning('This creates new scenes and narration, not a face swap or automatic copyright clearance. No original person is uploaded as a character reference. New TTS/Flow generation can cost credits after approval.')
    from engine.content_library import CharacterLibrary
    from engine.clip_recreation import create_recreation_job, approve_recreation
    characters = CharacterLibrary().list()
    from engine.studio_review import discover_clips
    origin=st.radio('Recreation source',['Saved generated clip','Local video file'],horizontal=True)
    if origin=='Saved generated clip':
        clips_root=st.text_input('Folder containing generated clips',value='outputs')
        choices=discover_clips(clips_root,st.session_state.get('last_clip_result',{}).get('outputs',[]))
        if choices:
            clip=st.selectbox('Already generated clips',[r['path'] for r in choices],
                format_func=lambda p:next(r['label'] for r in choices if r['path']==p),key='recreate-saved-clip')
            compact_video(clip)
        else:
            clip='';st.info('No saved clips found in this folder. Choose Local video file or the correct clips folder.')
    else:
        clip=st.text_input('Local video path (WSL/Linux path)',key='recreate-local-path')
    transcript = st.text_area('Reviewed transcript (optional when matching transcript sidecar exists)')
    locale = st.selectbox('Recreation language',['en','hi','or'])
    from engine.gemini_transcript import transcript_controls
    drafted_recreation=transcript_controls(st,'recreate-speech',clip,locale)
    if drafted_recreation:
        transcript=' '.join(w['word'] for w in drafted_recreation['words'])
    transcript_ready=False
    if clip and Path(clip).is_file():
        try:
            from engine.clip_recreation import _transcript_record
            _transcript_record(Path(clip),transcript)
            transcript_ready=True
            st.caption('Transcript available for this clip. Review its words before confirming adaptation.')
        except ValueError:
            st.info('Prepare speech first: open the Gemini transcript panel above, draft and review it, or paste the reviewed transcript. Visual review and storyboard creation unlock after this step.')
    rights = st.selectbox('Transcript AND footage adaptation rights',['own_content','written_permission','licensed_content','creative_commons','public_domain'])
    confirmed = st.checkbox('I have reviewed the transcript and have rights to adapt it and the source video')
    budget = st.number_input('Maximum Flow credits for this new recreation',0,5000,50)
    music = st.text_input('Optional licensed soft music file')
    fit_narration = st.checkbox('Use measured narration length instead of source clip duration', value=True, help='Preserves approved words; the final duration can differ from the source clip.')
    recreate_local_close = st.checkbox('Allow saved opening-image guidance if a closing image cannot recover',
        key='recreate-local-close', help='Optional fallback, preserved for future Resume attempts. No replacement image generation; normal Flow videos can still use credits.')
    recreate_replace_images = st.checkbox('Regenerate an unresolved recreation image once after 3 recovery retries',value=True,key='recreate-replace-images',
        help='Image-only, one per image and up to 30 for the job. May leave unused duplicate assets; no paid replacement approval.')
    reviewed_recreation_plan = None
    with st.expander('Gemini Web · review this clip before recreation',expanded=True):
        st.caption('Uploads a small silent proxy of this local clip to your Gemini session, together with the reviewed transcript. The default storyboard below uses transcript only; this optional review examines visual framing and action too.')
        recreation_cleanup = st.selectbox('Recreation review chat cleanup',['delete-after-read','keep'])
        if st.button('Review video + propose recreation scenes',disabled=not (clip and confirmed and transcript_ready and (not reuse_broll or reuse_review))):
            try:
                from engine.studio_review import review_recreation_clip
                with st.spinner('Preparing the clip proxy and asking Gemini to review its visuals…'):
                    proposal=review_recreation_clip(clip,transcript,locale,recreation_cleanup)
                st.session_state['recreation-review-json']=json.dumps(proposal,ensure_ascii=False,indent=2)
            except Exception as error:st.error(str(error))
        review_text=st.text_area('Review/edit Gemini recreation storyboard JSON',key='recreation-review-json',height=220)
        use_video_review=st.checkbox('Use this reviewed Gemini storyboard for recreation')
        if use_video_review:
            try:
                reviewed_recreation_plan=json.loads(review_text)
            except ValueError:st.error('Enter valid storyboard JSON before creating the job.')
    from engine.studio_widgets import broll_settings
    recreate_broll=broll_settings(st,'recreate-broll')
    reuse_broll = st.checkbox('Reuse approved B-roll from this same clip', value=False)
    reuse_review = ''
    if reuse_broll and clip:
        review_paths = sorted(Path(clip).resolve().parent.glob('broll-review-*.json'))
        from engine.broll import reusable_clip_candidates
        eligible_reviews = []
        for review_path in review_paths:
            try:
                reusable_clip_candidates(str(review_path), clip)
                eligible_reviews.append(review_path)
            except (ValueError, OSError):
                continue
        review_paths = eligible_reviews
        if review_paths:
            reuse_review = st.selectbox('Saved B-roll review', [str(p) for p in review_paths],format_func=lambda p:Path(p).name)
            st.caption('Reuses only exact approved files belonging to this clip. Placement follows the new narration length; no stock search or generation.')
        else: st.info('No exact approved B-roll is available for this clip. Open its saved job in Clip Studio and approve assets, or turn off B-roll reuse.')
    speaker_turns = []; speaker_mapping = {}
    multi = st.checkbox('Multiple podcast speakers — reviewed cast and voices')
    if multi:
        st.caption('Preserves the reviewed words and speaker order. Voice presentation is a suggestion, not gender identification. Exact acting and lip-sync are not reproduced.')
        source_url = st.text_input('Public YouTube source URL for speaker proposal (optional)')
        if st.button('Ask Gemini Web for speaker proposal',disabled=not (source_url and transcript)):
            try:
                from engine.cast import propose_speakers
                proposal = propose_speakers(source_url,transcript)
                st.session_state['speaker-proposal'] = proposal
                st.session_state['speaker-turns-editor'] = json.dumps(proposal['turns'],ensure_ascii=False,indent=2)
                st.json(proposal['speakers'])
            except Exception as error:st.error(str(error))
        turns_text = st.text_area('Reviewed speaker turns JSON',key='speaker-turns-editor',placeholder='[{"speaker_id":"SPEAKER_1","text":"Exact transcript words"}]')
        try:
            speaker_turns=json.loads(turns_text or '[]')
            for sid in dict.fromkeys(t['speaker_id'] for t in speaker_turns):
                if characters:
                    suggested=next((s.get('voice_style','unspecified') for s in st.session_state.get('speaker-proposal',{}).get('speakers',[]) if s['speaker_id']==sid),'unspecified')
                    recommended=next((i for i,c in enumerate(characters) if suggested!='unspecified' and c.get('voice_style')==suggested),0)
                    cid=st.selectbox(sid+' character',[c['id'] for c in characters],index=recommended,key='cast-'+sid,format_func=lambda i:next(c['name'] for c in characters if c['id']==i))
                    style=st.selectbox(sid+' voice presentation',['unspecified','feminine','masculine'],index=['unspecified','feminine','masculine'].index(suggested),key='style-'+sid)
                    default = ('hi-IN-SwaraNeural' if style=='feminine' else 'hi-IN-MadhurNeural') if locale=='hi' else ('en-IN-NeerjaNeural' if style=='feminine' else 'en-IN-PrabhatNeural')
                    voice=st.text_input(sid+' fallback voice',value=default,key='voice-'+sid)
                    provider_voice=st.text_input(sid+' Gemini voice',value='Kore' if style=='feminine' else 'Puck',key='provider-voice-'+sid)
                    speaker_mapping[sid]={'character_id':cid,'voice':voice,'provider_voice':provider_voice,'voice_style':style}
        except (ValueError,TypeError,KeyError):st.error('Enter a JSON list of speaker_id/text turns before planning.')
    if characters:
        character_id = st.selectbox('Original character',[c['id'] for c in characters],format_func=lambda identifier:next(c['name'] for c in characters if c['id']==identifier))
        from engine.studio_widgets import character_cards
        character_cards(st,[c for c in characters if c['id']==character_id],key='recreate')
        if st.button('Create recreation storyboard — no generation',type='primary',disabled=not (clip and confirmed and transcript_ready and (not reuse_broll or reuse_review))):
            try:
                if use_video_review and reviewed_recreation_plan is None:
                    raise ValueError('Review valid Gemini storyboard JSON first')
                result = create_recreation_job(F,clip,character_id,transcript_text=transcript,language=locale,
                                              source_rights=rights,adaptation_confirmed=confirmed,max_credits=int(budget),background_music=music,fit_narration=fit_narration,speaker_turns=speaker_turns if multi else None,speaker_mapping=speaker_mapping,reviewed_plan=reviewed_recreation_plan, broll_review_path=reuse_review if reuse_broll else '')
                F.set_broll_options(result['job_id'],**recreate_broll)
                F.set_flow_local_closing_fallback(result['job_id'],recreate_local_close)
                F.set_flow_image_replacement(result['job_id'],recreate_replace_images)
                st.session_state['recreation_job'] = result['job_id'];st.json(result)
            except Exception as error:
                st.error(str(error))
    else:
        st.info('Create an original character in CHARACTER LIBRARY first.')
    recreation = st.session_state.get('recreation_job')
    if recreation:
        root = Path(F.pm.job_dir(recreation))
        st.code(str(root/'approved_content_plan.json'))
        st.json(json.loads((root/'approved_content_plan.json').read_text(encoding='utf-8')))
        approve = st.checkbox('I approve this exact storyboard, character and credit ceiling')
        if st.button('Approve recreation (does NOT start generation)',disabled=not approve):
            try:
                st.json(approve_recreation(F,recreation))
                st.session_state.job_id = recreation
                st.info('Use QUEUE → Resume explicitly to create the narration and new Flow scenes. Existing source clip remains unchanged.')
            except Exception as error:
                st.error(str(error))

elif page == 'CHANNEL DESK':
    from engine.channel_desk_ui import show
    show(st)

# ================= PUBLISHING DESK =================
elif page == 'PUBLISHING DESK':
    st.title('Destination exports & release review')
    st.caption('Encode a destination MP4 plus a copy/paste upload packet. Approval and scheduling remain local manual-upload records; this page does not connect or publish to social accounts.')
    from engine.publishing import PROFILES, export_delivery, approve_release, schedule_release
    source = st.text_input('Rendered video path')
    folder = st.text_input('Separate delivery folder',value='outputs/deliveries')
    destination = st.selectbox('Destination',list(PROFILES))
    locale = st.selectbox('Delivery language',['en','hi','or'])
    title = st.text_input('Localized title')
    caption = st.text_area('Platform caption (Reels / Shorts)', max_chars=5000)
    description = st.text_area('Description / supporting copy', max_chars=5000)
    hashtags = st.text_input('Hashtags (space-separated)', placeholder='#Odia #Gardening')
    chapters = st.text_area('YouTube chapters (optional; one timestamp and title per line)',
                            placeholder='00:00 Introduction\n01:15 First step')
    source_urls = st.text_area('Source / attribution URLs (one HTTPS URL per line)',
                               help='Only include sources you reviewed. A URL is attribution, not permission to copy.')
    category = st.text_input('Content category (optional)', placeholder='gardening, devotional story, health education…')
    framing = st.selectbox('Export framing',['fit','crop'])
    if st.button('Encode destination delivery + upload packet (local only)'):
        try:
            with st.spinner('Encoding a separate destination copy and preparing its metadata packet; source is preserved'):
                record = export_delivery(source,folder,destination,language=locale,title=title,framing=framing,
                                         caption=caption,description=description,hashtags=hashtags,
                                         chapters=chapters,source_urls=source_urls,category=category)
            st.session_state['release_record_path'] = str(Path(folder)/(record['id']+'.release.json'))
            compact_video(record['video']);st.json(record)
            st.download_button('Download copy/paste upload packet',
                               Path(record['upload_packet']).read_bytes(),
                               file_name=Path(record['upload_packet']).name,
                               mime='text/plain', key=f"upload-packet-{record['id']}")
        except Exception as error:
            st.error(str(error))
    release_path = st.text_input('Delivery review JSON',value=st.session_state.get('release_record_path',''))
    editorial_review = st.text_input('Optional Channel Desk review.json for this exact delivery MP4', help='Review the exported delivery in Channel Desk, then attach its signed review here. A source master review does not approve a changed delivery.')
    account = st.text_input('Exact destination account/channel identifier')
    rights = st.checkbox('Visual/audio/transcript rights reviewed')
    facts = st.checkbox('Facts, story and intended audience reviewed')
    language_ok = st.checkbox('Native-language narration and text reviewed')
    kids = st.selectbox('Intended for children?',['Choose','Yes','No'])
    ai = st.selectbox('AI disclosure required for this delivery?',['Choose','Yes','No'])
    dup_ack = st.checkbox('Near-duplicate warning reviewed: any similar approved or scheduled video listed in the warning is a different video for this channel', value=False,
                          help='Identical bytes already approved for another account are always blocked. A similar re-encoded video needs this acknowledgment.')
    st.caption('The approval fingerprint covers the video hash, copy, destination, exact account and review choices. Editing the release JSON or upload packet after approval requires re-review.')
    if st.button('Approve exact file + metadata for manual upload'):
        try:
            st.json(approve_release(release_path,account_id=account,rights_confirmed=rights,facts_reviewed=facts,
                                    language_reviewed=language_ok,made_for_kids=None if kids=='Choose' else kids=='Yes',
                                    ai_disclosure_required=None if ai=='Choose' else ai=='Yes',
                                    editorial_review_path=editorial_review.strip() or None,
                                    acknowledge_duplicate_warning=dup_ack))
        except Exception as error:
            st.error(str(error))
    when = st.text_input('Optional local reminder: future ISO time with timezone',placeholder='2026-10-05T18:00:00+05:30')
    if st.button('Add local manual-upload reminder'):
        try:
            st.json(schedule_release(release_path,when))
        except Exception as error:
            st.error(str(error))

# ================= PRODUCTION QC =================
elif page == "PRODUCTION QC":
    st.title("Production review and local repair")
    st.caption("Checks the rendered job. Sampled semantic review is optional Gemini API use; it is separate from your browser subscription. No publication or Flow generation occurs here.")
    if not st.session_state.job_id:
        st.info("Select a rendered job in the sidebar.")
    else:
        from engine.production import init_review, check_job, stage_repairs, read
        root = Path(F.pm.job_dir(st.session_state.job_id))
        if st.button("Create review templates"):
            st.json(init_review(root))
        st.code(str(root / 'production'))
        st.caption("Edit rights.json, facts.json and graphics.json in this folder. See README section 16 for schemas and repair instructions.")
        model = st.text_input("Vision API model ID (optional)", value="")
        max_calls = st.number_input("Maximum API calls this review", 0, 100, 0)
        qc_exports = sorted((root/'render').glob('*-final*.mp4'))
        qc_export = st.selectbox('Exact export to check', qc_exports, format_func=lambda p:p.name) if qc_exports else None
        if st.button("Run production checks", disabled=qc_export is None):
            bar, status = st.progress(0), st.empty()
            def review_progress(message, pct, info=""):
                bar.progress(max(0, min(100, int(pct))))
                status.write(message + (' — ' + info if info else ''))
            try:
                with st.spinner("Checking media and evidence; progress is also recorded in job logs"):
                    check_job(root, model.strip(), int(max_calls), review_progress, final_path=qc_export)
            except Exception as exc:
                st.error(str(exc))
        report = read(root / 'production/review.json', {})
        if report:
            st.json(report)
        plan = st.text_input("Edited local repair plan", value=str(root / 'production/repair_plan.json'))
        if st.button("Validate and stage local replacements"):
            try:
                st.json(stage_repairs(root, plan))
                st.info("Use RENDER for this same job, then run production checks again.")
            except Exception as exc:
                st.error(str(exc))

# ================= ASSETS =================
elif page == "ASSETS":
    st.title("Assets")
    if not st.session_state.job_id:
        st.info("Select a job in the sidebar.")
    else:
        D = F.pm.dirs(st.session_state.job_id)
        for key in ("storyboard", "references", "downloads", "captions", "audio", "render"):
            with st.expander(f"📁 {key}", expanded=(key == "storyboard")):
                files = sorted(glob.glob(os.path.join(D[key], "*")))
                if not files:
                    st.caption("(empty)")
                for f in files[:24]:
                    if f.endswith((".jpg", ".png", ".jpeg", ".webp")):
                        st.image(f, caption=os.path.basename(f), width=240)
                    elif f.endswith((".mp4", ".webm", ".mov")):
                        compact_video(f)
                    else:
                        st.write(os.path.basename(f), f"({os.path.getsize(f)//1024} KB)")

# ================= RENDER =================
elif page == "RENDER":
    st.title("Render")
    if not st.session_state.job_id:
        st.info("Select a job in the sidebar.")
    else:
        from engine.render.ffmpeg_renderer import detect_encoder
        from engine.broll import (load_review as load_broll_review, prepare_job_review,
                                  save_review as save_broll_review, validate_review_decisions)
        st.caption(f"Encoder: `{detect_encoder()}` · Target: 1080p + burned captions + ducked music + loudness.")
        D = F.pm.dirs(st.session_state.job_id)
        broll_review_path = os.path.join(D["render"], "broll_review.json")
        shots_for_broll = F.pm.load_manifest(st.session_state.job_id).shots
        estimated_timeline = sum(max(0.1, float(x.voice_end) - float(x.voice_start)) for x in shots_for_broll)
        broll_render_ready = True
        with st.expander("🌿 Optional related stock B-roll cutaways", expanded=False):
            st.caption("The suggestion count limits the search; it does not insert footage. Preview each exact asset, then explicitly approve or skip every suggestion and save decisions before rendering. Approved cutaways replace only the picture for a few seconds; narration/music and final duration remain unchanged. No Flow/Veo generation is submitted. Review each asset's current terms before approval.")
            auto_broll = st.checkbox('Automatically select valid B-roll and skip unavailable assets',value=False,key=f'auto-broll-{st.session_state.job_id}')
            st.caption('Automatic selection uses your declared permission for configured stock sources, verifies exact files and records every decision. Review visual relevance in the finished video.')
            from engine.studio_widgets import broll_settings
            saved_broll_policy=broll_settings(st,'saved-broll-'+st.session_state.job_id,F._settings(st.session_state.job_id))
            if st.button('Save B-roll choices for this job',key='save-broll-policy-'+st.session_state.job_id):
                F.set_broll_options(st.session_state.job_id,**saved_broll_policy)
                st.success('Render-only B-roll choices saved; accepted visuals and pending Flow requests preserved.')
            existing_broll = os.path.isfile(broll_review_path)
            if existing_broll and auto_broll and st.button('Automatically select saved cutaways',key=f'auto-saved-broll-{st.session_state.job_id}'):
                try:
                    from engine.broll import auto_select_production_review
                    auto_select_production_review(broll_review_path,source_permission=True)
                    st.rerun()
                except ValueError as error:st.error(str(error))
            b1, b2, b3 = st.columns(3)
            broll_count = b1.number_input("Maximum suggestions", min_value=1, max_value=150, value=3, step=1,
                                         key=f"broll-count-{st.session_state.job_id}")
            broll_duration = b2.slider("Cutaway duration (seconds)", 0.5, 6.0, 2.0, 0.5,
                                        key=f"broll-duration-{st.session_state.job_id}")
            replace_broll = b3.checkbox("Replace existing suggestion list", value=False,
                                        disabled=not existing_broll,
                                        key=f"broll-replace-{st.session_state.job_id}")
            broll_query_hint = st.text_input(
                "Optional English visual-search hint (useful for non-English narration)", value="",
                key=f"broll-hint-{st.session_state.job_id}",
                help="Added to scene subjects to improve stock search relevance; it does not change the approved script or scene.")
            if st.button("🔎 Find related stock cutaways", key=f"broll-search-{st.session_state.job_id}"):
                try:
                    with st.spinner("Searching configured stock sources; no Flow/Veo generation is submitted…"):
                        _path, review = prepare_job_review(
                            F, st.session_state.job_id, max_candidates=int(broll_count),
                            default_duration=float(broll_duration), replace=replace_broll,
                            query_hint=broll_query_hint)
                    if auto_broll:
                        from engine.broll import auto_select_production_review
                        review = auto_select_production_review(_path,source_permission=True)
                        st.success('Automatic decisions saved. Valid cutaways are ready for the next render.')
                    ready_count = sum(1 for x in review.get("candidates", []) if x.get("status") in ('ready','approved'))
                    missing_count = len(review.get("candidates", [])) - ready_count
                    st.success(f"Search complete: {ready_count} valid candidate(s), {missing_count} unmatched/invalid. " + ("Automatic decisions saved; render to apply them." if auto_broll else "Save approval or skip decisions before render."))
                except Exception as exc:
                    st.error(str(exc))
            if os.path.isfile(broll_review_path):
                try:
                    review = load_broll_review(broll_review_path)
                    review_widget_scope = str(review.get("review_id") or review.get("created_at") or "review")
                    decisions = {}
                    candidates=review.get("candidates", [])
                    pages=max(1,(len(candidates)+5)//6)
                    preview_page=st.selectbox("Cutaway preview page",list(range(pages)),format_func=lambda i:f"{i+1} / {pages}",key=f"production-broll-page-{st.session_state.job_id}-{review_widget_scope}")
                    for candidate in candidates[preview_page*6:(preview_page+1)*6]:
                        cid = str(candidate.get("candidate_id", "cutaway"))
                        st.markdown(f"**{candidate.get('label', cid)}**")
                        has_asset = bool(candidate.get("path") and os.path.isfile(candidate["path"]))
                        if has_asset:
                            compact_video(candidate["path"])
                            st.caption("Exact preview · Query: " + str(candidate.get("query", "")) +
                                       " · Source: " + str(candidate.get("source", "stock")) +
                                       " · Licence: " + str(candidate.get("license", "review required")) +
                                       (" · Creator: " + str(candidate.get("creator")) if candidate.get("creator") else ""))
                            if candidate.get("page_url"):
                                st.markdown(f"[Open stock source page]({candidate['page_url']})")
                            max_start = max(0.0, estimated_timeline - 0.5)
                            start_default = min(max_start, max(0.0, float(candidate.get("start", 0) or 0)))
                            cut_start = st.number_input("Start time in final video (seconds)", 0.0, max_start,
                                                        start_default, 0.25,
                                                        key=f"broll-start-{st.session_state.job_id}-{review_widget_scope}-{cid}")
                            max_cut_duration = max(0.5, min(6.0, estimated_timeline - float(cut_start)))
                            duration_default = min(max_cut_duration, max(0.5, float(candidate.get("duration", broll_duration) or broll_duration)))
                            cut_duration = st.slider("Use this many seconds", 0.5, max_cut_duration, duration_default, 0.5,
                                                      key=f"broll-length-{st.session_state.job_id}-{review_widget_scope}-{cid}")
                            choices = ["pending", "approve", "skip"]
                        else:
                            st.warning(candidate.get("search_error", "No valid stock video was found for this gap."))
                            cut_start, cut_duration = float(candidate.get("start", 0) or 0), float(candidate.get("duration", broll_duration) or broll_duration)
                            choices = ["pending", "skip"]
                        saved = str(candidate.get("decision") or "pending").lower()
                        saved = {"approved": "approve", "skipped": "skip"}.get(saved, saved)
                        if saved not in choices:
                            saved = "pending"
                        decision = st.radio(
                            "Decision for this suggestion", choices,
                            index=choices.index(saved), horizontal=True,
                            format_func=lambda x: {"pending": "Pending review", "approve": "Approve insert", "skip": "Skip insert"}[x],
                            key=f"broll-decision-{st.session_state.job_id}-{review_widget_scope}-{cid}")
                        reviewed = False
                        if decision == "approve" and has_asset:
                            reviewed = st.checkbox(
                                "I reviewed this exact clip and its current licence/rights",
                                value=bool(candidate.get("rights_reviewed")),
                                key=f"broll-rights-{st.session_state.job_id}-{review_widget_scope}-{cid}")
                        decisions[cid] = {"start": float(cut_start), "duration": float(cut_duration),
                                          "decision": decision, "rights_reviewed": reviewed}
                    try:
                        validate_review_decisions(broll_review_path, workflow="production")
                        saved_decisions_complete = True
                    except ValueError:
                        saved_decisions_complete = False
                    broll_render_ready = saved_decisions_complete
                    if not saved_decisions_complete:
                        st.warning("Save an explicit Approve or Skip decision for every suggestion before rendering; pending B-roll reviews block final render.")
                    if st.button("💾 Save cutaway decisions", key=f"broll-save-{st.session_state.job_id}"):
                        try:
                            review = save_broll_review(broll_review_path, decisions)
                            count_approved = sum(1 for x in review.get("candidates", [])
                                                 if x.get("approved") and x.get("rights_reviewed"))
                            count_skipped = sum(1 for x in review.get("candidates", [])
                                                if x.get("decision") == "skipped")
                            pending_count = len(review.get("candidates", [])) - count_approved - count_skipped
                            broll_render_ready = pending_count == 0
                            st.success(f"Saved decisions: {count_approved} approved, {count_skipped} skipped, {pending_count} pending. Only approved exact files will be inserted.")
                        except Exception as exc:
                            st.error(str(exc))
                except Exception as exc:
                    broll_render_ready = False
                    st.error("Could not load B-roll review: " + str(exc))
        quality = st.radio("Quality", ["fast", "preview", "standard", "high"], horizontal=True)
        if st.button("🎬 Render final", type="primary", disabled=not broll_render_ready):
            render_bar = st.progress(0)
            render_status = st.empty()
            def render_cb(stage, pct, info=""):
                render_bar.progress(min(100, int(pct)))
                render_status.info(f"{stage} {info}")
            with st.spinner("Rendering..."):
                try:
                    r = F.render_job(st.session_state.job_id, quality=quality, progress_cb=render_cb)
                    st.success(f"Done via {r['renderer']} · {r.get('broll_cutaways', 0)} approved stock cutaway(s)")
                    compact_video(r["video"])
                    with open(r["video"], "rb") as f:
                        st.download_button("⬇️ Download MP4", f, file_name=os.path.basename(r["video"]))
                    for k in ("ass", "srt"):
                        p = r["captions"][k]
                        with open(p, "rb") as f:
                            st.download_button(f"⬇️ {k.upper()}", f, file_name=os.path.basename(p))
                    if r.get("warnings"):
                        st.warning(" | ".join(r["warnings"]))
                except Exception as e:
                    st.error(f"Render failed: {e}")

# ================= HISTORY =================
elif page == "HISTORY":
    st.title("Gallery & Downloads")
    from engine.studio_review import discover_clips
    from engine.media_gallery import media_gallery
    clip_folder=st.text_input('Additional clip output folder',value=str(Path(F.pm.root)/'my-clips'),key='gallery-clip-root')
    clips=discover_clips(F.pm.root)
    if clip_folder.strip():
        clips+=discover_clips(clip_folder.strip())
    media_gallery(st, F, indexed_jobs, clips, [F.pm.root, clip_folder.strip() or F.pm.root])
    from engine.flow_project_cleanup import panel as flow_project_cleanup_panel
    flow_project_cleanup_panel(st, F.pm.root)
    st.divider()
    from engine.storage_manager import storage_manager
    storage_manager(st, F, [clip_folder.strip() or F.pm.root])

# ================= SETTINGS =================
elif page == "SETTINGS":
    st.title("Settings")
    with st.expander('Local production readiness — no Google requests'):
        if st.button('Check local production readiness'):
            from tools.production_preflight import check
            st.session_state['production-preflight'] = check(F.pm.root)
        readiness = st.session_state.get('production-preflight')
        if readiness:
            st.dataframe(readiness['checks'], hide_index=True)
            st.download_button('Download readiness report', json.dumps(readiness, indent=2),
                               file_name='production-readiness.json', mime='application/json')
    usp = "config/user_settings.yaml"
    cur = {}
    if os.path.exists(usp):
        cur = yaml.safe_load(open(usp, encoding="utf-8")) or {}
    b = cur.get("budgets", {})
    with st.form("settings"):
        s1, s2 = st.columns(2)
        tts_options = ["edge", "auto", "gemini", "gemini-lite", "groq", "elevenlabs", "gtts", "kokoro", "chatterbox"]
        tts = s1.selectbox("Default TTS", tts_options,
                           index=option_index(tts_options, cur.get("tts_provider", "edge")))
        monthly = s2.number_input("Monthly Flow credits (your plan)", 0, 50000, int(cur.get("monthly_credits") or 1000))
        c1, c2, c3 = st.columns(3)
        maxv = c1.number_input("MAX_CREDITS_PER_VIDEO", 0, 2000, int(b.get("MAX_CREDITS_PER_VIDEO", 50)))
        maxr = c2.number_input("MAX_RETRIES_PER_SHOT", 0, 5, int(b.get("MAX_RETRIES_PER_SHOT", 2)))
        maxq = c3.number_input("MAX_QUALITY_GENERATIONS", 0, 10, int(b.get("MAX_QUALITY_GENERATIONS", 1)))
        c4, c5 = st.columns(2)
        reserve = c4.number_input("USER_RESERVE", 0, 2000, int(b.get("USER_RESERVE", 50)))
        retrypct = c5.number_input("RETRY_RESERVE_PCT", 0, 100, int(b.get("RETRY_RESERVE_PCT", 15)))
        st.markdown("**🌱 Storyboard Economy defaults**")
        ec1, ec2, ec3, ec4a = st.columns(4)
        g_video_share = ec1.slider("Default AI-video share", 0.0, 1.0, float(cur.get("video_share", 0.20)), 0.05)
        g_stock_share = ec2.slider("Default stock-video share", 0.0, 1.0, float(cur.get("stock_share", 0.60)), 0.05)
        g_flow_scenes = ec3.number_input("Default exact Flow scenes (0=auto)", 0, 100, int(cur.get("flow_scenes") or 0))
        g_max_flow = ec4a.number_input("Default max Flow scenes (0=no cap)", 0, 100, int(cur.get("max_flow_scenes") or 0))
        ec4, ec5, ec6 = st.columns(3)
        fs_opts = ["auto", "flow", "free"]
        g_frame_source = ec4.selectbox("Default frame source", fs_opts, index=fs_opts.index(cur.get("frame_source", "auto")) if cur.get("frame_source", "auto") in fs_opts else 0)
        ap_opts = ["once", "manual", "always"]
        g_approval = ec5.selectbox("Default Flow approval", ap_opts, index=ap_opts.index(cur.get("flow_approval", "once")) if cur.get("flow_approval", "once") in ap_opts else 0)
        g_gen_cap = ec6.number_input("Default per-generation credit cap", 0, 200, int(cur.get("max_generation_credits", 10)))
        g_pause_flow = st.checkbox(
            "Pause unresolved Flow requests by default (opt-in)",
            value=_flow_pause_setting_default(),
            help="When off, unresolved images fall back only in auto frame mode; strict images and videos fail without entering PAUSED. When on, they are saved and paused for a deliberate Resume. Recovery retries download-only and verifies request identity; it never regenerates merely because a gallery scan misses an image.")
        st.markdown("**🌐 Flow browser** (which Chrome to drive)")
        br = cur.get("browser", {}) or {}
        bmodes = ["auto", "system", "bundled", "cdp"]
        bmode = st.selectbox("Browser mode", bmodes,
                             index=bmodes.index(br.get("mode", "auto")) if br.get("mode", "auto") in bmodes else 0,
                             help="auto=tries your Chrome first, then bundled. system=your installed Chrome only. cdp=attach to YOUR open browser (uses your existing Google login!). bundled=playwright download.")
        bquiet = st.checkbox("Quiet browser · experimental (Linux/WSL)", value=bool(br.get('quiet',False)),
            help="Headed Chromium on a hidden virtual display. Requires xvfb, xauth, x11-utils, x11vnc and tigervnc-viewer. Show browser reveals the same session for sign-in; no headless login change.")
        bc1, bc2 = st.columns(2)
        chans = ["chrome", "chromium", "msedge"]
        bchan = bc1.selectbox("System channel", chans,
                              index=chans.index(br.get("channel", "chrome")) if br.get("channel", "chrome") in chans else 0)
        bcdp = bc2.text_input("CDP URL (cdp mode)", value=br.get("cdp_url", ""),
                              placeholder="http://localhost:9222")
        bexe = st.text_input("Chrome executable override (optional)", value=br.get("executable", ""),
                             placeholder="e.g. /usr/bin/google-chrome (native path only — never a /mnt/c/... .exe from WSL)")
        if st.form_submit_button("💾 Save settings"):
            yaml.safe_dump({**cur, "tts_provider": tts, "monthly_credits": monthly,
                            "budgets": {"MAX_CREDITS_PER_VIDEO": maxv, "MAX_RETRIES_PER_SHOT": maxr,
                                        "MAX_QUALITY_GENERATIONS": maxq, "USER_RESERVE": reserve,
                                        "RETRY_RESERVE_PCT": retrypct},
                            "video_share": g_video_share, "stock_share": g_stock_share,
                            "flow_scenes": (int(g_flow_scenes) or None),
                            "max_flow_scenes": (int(g_max_flow) or None),
                            "frame_source": g_frame_source, "flow_approval": g_approval,
                            "max_generation_credits": int(g_gen_cap),
                            "flow_pause_on_unresolved_request": g_pause_flow,
                            "browser": {"mode": bmode, "quiet": bquiet, "channel": bchan,
                                        "executable": bexe, "cdp_url": bcdp}},
                           open(usp, "w", encoding="utf-8"))
            st.success("Saved to config/user_settings.yaml")
    from engine.providers import find_system_chrome as _find_chrome, is_wsl as _is_wsl, is_windows_exe as _is_wexe
    _det = _find_chrome()
    if _det and _is_wsl() and _is_wexe(_det):
        st.caption(f"🔍 Windows Chrome visible: `{_det}` — not directly launchable from WSL; use **cdp** mode (chrome-debug.bat) or **bundled**.")
    else:
        st.caption(f"🔍 Detected system Chrome: `{_det}`" if _det else "🔍 No system Chrome detected — CDP or bundled mode, or install Chrome.")
    st.divider()
    st.subheader("🔑 Keys & providers")
    from engine.env_config import API_KEYS
    from engine.key_settings import update_key
    with st.form('api-key-editor', clear_on_submit=True):
        key_name = st.selectbox('Key to add or update', list(API_KEYS))
        key_value = st.text_input('New key value', type='password', autocomplete='off')
        st.caption('Saved only to this local installation. Existing keys are never displayed.')
        if st.form_submit_button('Save API key'):
            try:
                update_key(key_name, key_value, Path(__file__).parent)
                st.success(key_name + ' saved. Future provider requests use the updated key.')
            except ValueError as error: st.error(str(error))
    import shutil as _sh
    checks = [("GEMINI_API_KEY (Gemini scripts/TTS)", bool(os.getenv("GEMINI_API_KEY"))),
              ("GROQ_API_KEY (scripts/captions/TTS)", bool(os.getenv("GROQ_API_KEY"))),
              ("ELEVENLABS_API_KEY (optional TTS)", bool(os.getenv("ELEVENLABS_API_KEY"))),
              ("OPENAI_API_KEY (optional scripts)", bool(os.getenv("OPENAI_API_KEY"))),
              ("XAI_API_KEY (optional scripts)", bool(os.getenv("XAI_API_KEY"))),
              ("FAL_KEY (Seedance/Kling)", bool(os.getenv("FAL_KEY"))),
              ("Local stock library (assets/stock_library)", os.path.isdir("assets/stock_library")),
              ("PEXELS_API_KEY (optional stock search)", bool(os.getenv("PEXELS_API_KEY"))),
              ("PIXABAY_API_KEY (optional stock search)", bool(os.getenv("PIXABAY_API_KEY"))),
              ("FFmpeg", bool(_sh.which("ffmpeg"))),
              ("Playwright browser", os.path.exists(os.path.expanduser("~/.cache/ms-playwright"))),
              ("Flow profile (.flow-profile)", os.path.isdir(".flow-profile") and bool(os.listdir(".flow-profile")) if os.path.isdir(".flow-profile") else False)]
    for name, ok in checks:
        st.write(("✅ " if ok else "⬜ ") + name)
    found_env = ENV_REPORT.get("files_found") or []
    st.caption("Environment file: " + (found_env[0] if found_env else "not found"))
    if ENV_REPORT.get("aliases_used"):
        st.caption("Normalized aliases: " + ", ".join(ENV_REPORT["aliases_used"]))
    st.code("pip install playwright\nplaywright install chromium   # one-time, for Flow browser bridge", language="bash")
    with st.expander('Missing job entries', expanded=False):
        st.caption('Remove database entries only when the entire job folder is absent. Existing media, incomplete folders and running jobs are preserved.')
        missing = DB.missing_jobs(F.pm.root)
        if missing:
            st.dataframe([{'job_id': j['job_id'], 'topic': j['topic']} for j in missing], hide_index=True)
            if st.button('Remove these missing entries', key='prune-missing-jobs'):
                try:
                    report = DB.prune_missing(F.pm.root, [j['job_id'] for j in missing])
                    st.success(f"Removed {len(report['removed'])} missing entries; saved a database backup.")
                    st.rerun()
                except (ValueError, OSError) as error:
                    st.error(str(error))
        else:
            st.info('No missing job folders found.')
    with st.expander('Delete completed job · permanent', expanded=False):
        st.warning('Permanent deletion removes the selected completed job folder, including its final video and recovery history. It cannot be resumed afterward. Browser login profiles and external worker clones are not touched. Back up any media you want to retain first.')
        from engine.job_delete import completed_job_delete
        completed_rows = [r for r in DB.list(100000) if r.get('status') == 'done']
        candidates = [r['job_id'] for r in completed_rows]
        if not candidates:
            st.info('No completed jobs available for permanent deletion.')
        else:
            delete_job_id = st.selectbox('Completed job', candidates, key='delete-completed-job')
            if st.button('Preview permanent deletion',key='delete-job-preview'):
                try:
                    st.session_state['job-delete-preview'] = completed_job_delete(F.pm.root, DB.path, delete_job_id)
                except (ValueError, RuntimeError, OSError) as error:
                    st.error(str(error))
            report = st.session_state.get('job-delete-preview')
            if report and report.get('job_id') == delete_job_id:
                st.json(report)
                if report['eligible']:
                    typed = st.text_input('Type exact job ID to authorize deletion',key='delete-job-exact-confirm')
                    if st.button('Permanently delete job and DB entry',disabled=typed!=delete_job_id,key='delete-job-apply'):
                        try:
                            deleted = completed_job_delete(F.pm.root, DB.path, delete_job_id,apply=True,confirmation=typed)
                            st.json(deleted)
                            st.session_state.pop('job-delete-preview',None)
                            if deleted.get('deleted'):st.success('Completed job deleted. A database backup was preserved.')
                            else:st.warning('Quarantined files require manual review; see report.')
                        except (ValueError,RuntimeError,OSError) as error:
                            st.error(str(error))
                else:st.info('This job is not eligible for permanent deletion; unresolved Flow requests or missing final media must be reviewed.')
    with st.expander('Disk cleanup · safe worker files', expanded=False):
        st.caption('After each worker/job, regenerable worker caches are trimmed. Completed worker clones are removed only with a validated final video and no pending Flow requests. Final videos, accepted takes, characters, main login profiles and recovery journals are preserved.')
        if st.button('Preview cleanup of saved jobs', key='storage-preview'):
            try:
                with st.spinner('Checking saved jobs and eligible worker files…'):
                    st.session_state['storage-cleanup-preview'] = cleanup_report(F.pm.root)
            except RuntimeError as error:
                st.session_state.pop('storage-cleanup-preview', None)
                st.error(str(error))
        preview=st.session_state.get('storage-cleanup-preview')
        if preview:
            st.metric('Eligible space', f"{preview.get('eligible_bytes',0)/1024**3:.2f} GB")
            with st.expander('Inspect cleanup report'):
                st.json(preview)
            if st.button('Apply safe cleanup · rechecks eligibility',key='storage-apply'):
                try:
                    with st.spinner('Removing eligible worker files…'):
                        report = cleanup_report(F.pm.root, apply=True)
                    st.success(f"Freed {report.get('freed_bytes',0)/1024**3:.2f} GB; recovery state preserved.")
                    st.json(report)
                    st.session_state.pop('storage-cleanup-preview',None)
                except RuntimeError as error:
                    st.error(str(error))



# ================= Quick v2 =================
else:
    st.title("Quick (v2 pipeline)")
    st.caption("Legacy fast path: topic → video in one shot (Ken Burns / stock / API).")
    topic = st.text_input("Topic", key="v2t")
    cc1, cc2 = st.columns(2)
    vm = cc1.selectbox("Visuals", ["auto", "flow", "stock", "ai", "kenburns"], key="v2vm")
    vtype = cc2.selectbox("Type", ["shorts", "faceless_youtube", "explainer", "marketing"], key="v2vt")
    if st.button("🚀 Generate (v2)", type="primary"):
        from engine.automation import create_video_from_topic
        bar = st.progress(0)
        stxt = st.empty()
        try:
            with st.spinner("Generating..."):
                r = create_video_from_topic(topic, vtype, 45, "en-IN-NeerjaNeural", "exciting",
                                            outdir="outputs", visual_mode=vm,
                                            progress_cb=lambda s, p: (stxt.info(s), bar.progress(p)))
            st.success(f"Done: {r['video']}")
            compact_video(r["video"])
        except Exception as e:
            st.error(str(e))

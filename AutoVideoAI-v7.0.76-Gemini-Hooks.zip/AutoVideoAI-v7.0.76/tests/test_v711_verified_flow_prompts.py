import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace as NS

import pytest
from PIL import Image
from engine.providers.flow_browser import FlowBrowser, FlowBrowserProvider, FlowRequestPending

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / 'tests/fixtures/debanshi_prompt_recovery.json').read_text())
spec = importlib.util.spec_from_file_location('repair', ROOT / 'tools/repair_debanshi_frame.py')
repair = importlib.util.module_from_spec(spec)
spec.loader.exec_module(repair)


def saved_request():
    return {'kind':'image', 'status':'pending', 'request_hash':repair.REQUEST_HASH,
            'project_url':repair.PROJECT, 'submitted_prompt':DATA['expected'],
            'prompt_correlation_legacy':True, 'signature':'', 'baseline':['old-token']}


def test_reviewed_binding_is_guarded_backed_up_and_idempotent(tmp_path):
    out = tmp_path / 'outputs' / repair.JOB / 'storyboard/shot_001_close.jpg'
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    provider._save_request(str(out), saved_request())
    journal = Path(str(out) + '.flow-request.json'); original = journal.read_bytes()
    assert 'bound' in repair.repair(tmp_path)
    request = json.loads(journal.read_text())
    assert provider._bound_recovery_prompt(request) == DATA['prompts'][0]
    assert Path(str(journal) + '.before-reviewed-binding.json').read_bytes() == original
    first = journal.read_bytes()
    assert 'already present' in repair.repair(tmp_path)
    assert journal.read_bytes() == first
    request['request_hash'] = 'different'
    provider._save_request(str(out), request)
    before = journal.read_bytes()
    with pytest.raises(RuntimeError, match='differs'):
        repair.repair(tmp_path)
    assert journal.read_bytes() == before


@pytest.mark.parametrize('field,value', [('request_hash','another-shot'),
    ('project_url','https://flow.google.com/project/another'),
    ('submitted_prompt','changed-scene')])
def test_binding_cannot_be_reused_for_a_different_request(field, value):
    request = saved_request()
    request['verified_prompt_binding'] = FlowBrowserProvider._make_prompt_binding(request, DATA['prompts'][0], 'reviewed')
    request[field] = value
    assert FlowBrowserProvider._bound_recovery_prompt(request) is None


def test_collected_gallery_recovers_only_reviewed_close_images_with_rotated_tokens():
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    request = saved_request()
    request['verified_prompt_binding'] = provider._make_prompt_binding(request, DATA['prompts'][0], 'reviewed')
    assets = [{'sig':str(i), 'kind':'image'} for i in range(4)]
    bridge = NS(media_assets=lambda:assets, read_asset_generation_prompt=lambda sig:DATA['prompts'][int(sig)])
    assert provider._identify_single_fresh_asset(bridge, request, 'image', 0) == '0'
    assert request['verified_equivalent_assets'] == 2
    assert request['correlation_method'] == 'exact_bound_reused_prompt'
    bridge.media_assets = lambda:assets[2:]
    assert provider._identify_single_fresh_asset(bridge, request, 'image', 0) == ''
    # A single unrelated remaining tile must not bypass a reviewed binding.
    bridge.media_assets = lambda:assets[2:3]
    assert provider._identify_single_fresh_asset(bridge, request, 'image', 0) == ''


def test_stale_signature_rescans_bound_prompt_without_submitting(tmp_path):
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    prompt = 'original compiled prompt'
    request = saved_request()
    import hashlib
    request['request_hash'] = hashlib.sha256(json.dumps(['image','shot_001',prompt,True],sort_keys=True).encode()).hexdigest()
    request['verified_prompt_binding'] = provider._make_prompt_binding(request, DATA['prompts'][0], 'reviewed')
    request['signature'] = 'expired-token'
    out = str(tmp_path / 'close.jpg'); provider._save_request(out, request)
    assets = [{'sig':'close-new', 'kind':'image'}, {'sig':'open-new', 'kind':'image'}]
    downloads = []
    def download(*args, **kwargs):
        downloads.append(kwargs['preferred_signature'])
        Image.new('RGB',(200,300),'blue').save(out)
    bridge = NS(media_assets=lambda:assets, ensure_project=lambda *a, **k:None,
        read_asset_generation_prompt=lambda sig: {'close-new':DATA['prompts'][0], 'open-new':DATA['prompts'][2]}.get(sig),
        download_latest_asset=download)
    provider._ensure = lambda:bridge
    provider._generate_image_once = lambda *a, **k:pytest.fail('No generation permitted')
    result = provider._guarded_generation_once(NS(shot_id='shot_001'), {'prompt':prompt}, None, out, True, False, 'image')
    assert downloads == ['close-new'] and result['credits'] == 0
    assert json.loads(Path(out+'.flow-request.json').read_text())['status'] == 'downloaded'


def test_original_generation_records_flow_rewritten_prompt_before_download(tmp_path):
    provider = FlowBrowserProvider.__new__(FlowBrowserProvider)
    out = str(tmp_path / 'close.jpg')
    provider._save_request(out, saved_request())
    provider.bridge = NS(read_asset_generation_prompt=lambda sig:DATA['prompts'][0])
    provider._record_asset(out, 'identified-original-generation')
    request = json.loads(Path(out+'.flow-request.json').read_text())
    assert request['signature'] == 'identified-original-generation'
    assert provider._bound_recovery_prompt(request) == DATA['prompts'][0]
    assert request['verified_prompt_binding']['source'] == 'observed_original_generation'

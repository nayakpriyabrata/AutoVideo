import asyncio
import base64
import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from PIL import Image


def test_approval_cards_reserve_once_and_share_total_cap(tmp_path):
    from engine.flow_approval import reserve
    p=tmp_path/'request.json';p.write_text('{}')
    body='Would you like me to kick off this 1 video generation, costing 5 credits? Approve Reject'
    assert reserve(p,body,5,10,2)
    assert reserve(p,body,5,10,2) is False
    assert reserve(p,body+'\n'+body,5,10,2) is False
    assert reserve(p,body.replace('this 1 video','a second video'),5,10,2)
    with pytest.raises(ValueError,match='limit'):reserve(p,body.replace('this 1 video','a third video'),5,30,2)
    assert json.loads(p.read_text())['approval_credit_total_reserved']==10


def test_unknown_and_over_budget_approval_never_reserves(tmp_path):
    from engine.flow_approval import reserve
    p=tmp_path/'request.json';p.write_text('{}')
    text='Would you like me to generate a video, costing 9 credits?'
    with pytest.raises(ValueError):reserve(p,text,None,10,2)
    with pytest.raises(ValueError):reserve(p,text,9,8,2)
    assert json.loads(p.read_text())=={}


def test_exact_browser_blob_capture_and_untrusted_origin(tmp_path,monkeypatch):
    from engine.flow_blob_capture import capture
    from playwright import async_api
    image=tmp_path/'image.jpg';Image.new('RGB',(160,120),'green').save(image)
    data=image.read_bytes()
    class Page:
        def __init__(self,obj):pass
        async def evaluate(self,*args):return {'bytes':len(data),'data':base64.b64encode(data).decode()}
    monkeypatch.setattr(async_api,'Page',Page)
    page=NS(_impl_obj=object(),_sync=asyncio.run,is_closed=lambda:False,url='https://flow.google.com/project/exact')
    bridge=NS(_page=page,_guard_page=None)
    out=tmp_path/'saved.jpg'
    assert capture(bridge,NS(url='blob:https://evil.example/id'),str(out)) is None
    assert not out.exists()
    assert capture(bridge,NS(url='blob:https://flow.google.com/exact-event'),str(out))==str(out)
    assert out.read_bytes()==data


def image_request(root,name='frame',kind='image',status='downloaded'):
    from engine.flow_image_transaction import SCOPE,sha
    output=root/(name+'.jpg');Image.new('RGB',(160,120),'green').save(output)
    row={'scope':SCOPE,'kind':kind,'status':status,'project_url':'https://flow.google.com/project/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
         'media_sha256':sha(output),'reference_hashes':{},'capture_inventory':['exact-image']}
    path=Path(str(output)+'.flow-request.json');path.write_text(json.dumps(row));return path,output,row


def test_cleanup_retains_video_pending_and_changed_images(tmp_path):
    from engine.flow_project_cleanup import inventory
    path,out,row=image_request(tmp_path)
    assert inventory(tmp_path)[0]['eligible']
    out.write_bytes(b'changed');assert not inventory(tmp_path)[0]['eligible']
    path,out,row=image_request(tmp_path,kind='video');assert not inventory(tmp_path)[0]['eligible']
    path,out,row=image_request(tmp_path,status='pending');assert not inventory(tmp_path)[0]['eligible']


def test_cleanup_revalidates_then_records_exact_project_success(tmp_path):
    from engine.flow_project_cleanup import inventory,delete_selected
    path,out,row=image_request(tmp_path);calls=[]
    class Provider:
        def _ensure(self):return NS(delete_exact_project=lambda url,**kw:(calls.append((url,kw)) or {'status':'deleted'}))
        def close(self):pass
    reviewed=inventory(tmp_path)
    path.write_text(path.read_text()+' ')
    with pytest.raises(ValueError):delete_selected(tmp_path,reviewed,Provider)
    assert not calls
    reviewed=inventory(tmp_path);result=delete_selected(tmp_path,reviewed,Provider)
    assert calls[0][0]==row['project_url'] and calls[0][1]['expected_signatures']==['exact-image']
    assert result[0]['status']=='deleted' and out.is_file() and path.is_file()
    assert not inventory(tmp_path)[0]['eligible']


def test_cleanup_uncertain_action_is_not_retried(tmp_path):
    from engine.flow_project_cleanup import inventory,delete_selected
    image_request(tmp_path)
    class Provider:
        def _ensure(self):return NS(delete_exact_project=lambda *a,**k:(_ for _ in ()).throw(RuntimeError('confirmation unavailable')))
        def close(self):pass
    assert delete_selected(tmp_path,inventory(tmp_path),Provider)[0]['status']=='needs_review'
    assert inventory(tmp_path)[0]['remote_state']=='uncertain'


def test_gallery_cards_do_not_read_video_bytes_or_create_players(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard
    f,app=dashboard(tmp_path,monkeypatch)
    job=f.create_job('Saved export',dry_run=True)
    path=Path(f.pm.job_dir(job))/'render'/(job+'-final.mp4');path.write_bytes(b'export')
    f.db.upsert(job,status='done',final_path=str(path))
    real=Path.read_bytes
    def guarded(self):
        if self.suffix=='.mp4':pytest.fail('Gallery must not eagerly read MP4s')
        return real(self)
    monkeypatch.setattr(Path,'read_bytes',guarded)
    next(w for w in app.sidebar.button if w.label=='Gallery & Downloads').click().run()
    assert not app.exception
    assert not app.get('video')
    assert any(w.label=='▶ Play / download' for w in app.button)


def test_default_studio_cast_scope_is_empty_and_replacement_is_opt_in(tmp_path,monkeypatch):
    from tests.test_presentation_dashboard import dashboard
    f,app=dashboard(tmp_path,monkeypatch)
    assert next(w for w in app.multiselect if w.label.startswith('Saved characters available')).value==[]
    assert not next(w for w in app.checkbox if w.label.startswith('Regenerate an unresolved')).value


def test_owned_guard_is_reused_across_many_image_projects():
    from engine.providers.flow_browser import FlowBrowser
    class Page:
        url='https://flow.google.com/project/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
        def is_closed(self):return False
        def goto(self,url,**kw):self.url=url
    guard=Page();b=FlowBrowser.__new__(FlowBrowser)
    b._page=Page();b._guard_page=guard;b._owns_guard_page=True
    b._ctx=NS(new_page=lambda:pytest.fail('An owned guard already exists; no new tab required'))
    for n in range(12):
        assert b._ensure_project_guard_page(f'https://flow.google.com/project/00000000-0000-0000-0000-{n:012d}')
        assert b._guard_page is guard


def test_current_credit_card_not_historical_cheaper_price():
    from tests.test_flow_agent_v37 import FakePage,browser_with
    page=FakePage('Would you like me to generate an old video, costing 5 credits? Approve\nWould you like me to generate a new video, costing 100 credits?',['Approve'])
    b=browser_with(page)
    assert not b.confirm_agent_generation(timeout_s=1,approval='once',max_credits=10)
    assert b.last_agent_confirmation['cost']==100 and page.buttons['Approve'].clicked==0


@pytest.mark.parametrize('toast',[True,False])
def test_remote_delete_requires_exact_inventory_menu_and_success_toast(toast):
    from engine.flow_project_delete import delete
    from engine.providers.flow_browser import FlowBrowser
    url='https://flow.google.com/project/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';actions=[]
    class Loc:
        def __init__(self,text):self.text=text;self.first=self
        def count(self):return 0 if hasattr(self.text,'pattern') and 'confirm' not in actions else 1
        def is_visible(self,**kw):return bool(self.count())
        def click(self,**kw):actions.append(self.text)
        def inner_text(self,**kw):return 'Delete this project?'
        def get_by_role(self,*a,**kw):return Loc('confirm')
        def wait_for(self,**kw):
            if not toast:raise RuntimeError('No explicit success confirmation')
    page=NS(url=url,get_by_text=lambda *a,**kw:Loc(a[0]),get_by_role=lambda *a,**kw:Loc('dialog'))
    b=NS(_page=page,ensure_project=lambda *a,**kw:None,media_assets=lambda:[{'kind':'image','sig':'exact'}],
         _try_resolve=lambda *a,**kw:Loc('project-menu'))
    with pytest.raises(Exception):delete(b,url,['different'])
    assert not actions
    if toast:
        assert delete(b,url,['exact'])['status']=='deleted'
    else:
        with pytest.raises(RuntimeError,match='success'):delete(b,url,['exact'])
    assert actions==['project-menu','Delete','confirm']

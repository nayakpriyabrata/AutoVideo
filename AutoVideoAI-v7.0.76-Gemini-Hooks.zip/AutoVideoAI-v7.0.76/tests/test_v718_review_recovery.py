import base64
import io
import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from PIL import Image


def test_draft_accepts_visible_response_chrome_and_owns_cleanup(monkeypatch):
    from engine.studio_review import draft_script_cast
    import engine.providers.gemini_web as gw
    reply={'narration':'A child shares a book.', 'scenes':[{'text':'A child shares a book.',
           'visual_intent':'A child hands a book to a friend.'}], 'character_suggestions':[]}
    seen=[]
    def generate(*args, **kwargs):
        seen.append(kwargs)
        return 'Show thinking\nJSON\n```json\n'+json.dumps(reply)+'\n```\nCopy code'
    monkeypatch.setattr(gw,'gemini_web_generate',generate)
    monkeypatch.setenv('AUTOVIDEO_GEMINI_CHAT_CLEANUP','keep')
    result=draft_script_cast('Sharing',45,'en',[])
    assert result['plan']['narration']==reply['narration']
    assert seen==[{'cleanup':'delete-after-read'}]
    assert not result['plan']['approved']


def test_explicit_cleanup_overrides_inherited_job_policy(monkeypatch):
    from engine.providers.gemini_web import GeminiWebBrowser
    b=GeminiWebBrowser.__new__(GeminiWebBrowser)
    monkeypatch.setenv('AUTOVIDEO_GEMINI_CHAT_CLEANUP','keep')
    b._request_cleanup='delete-after-read'
    assert b._cleanup_requested()
    b._request_cleanup='keep'
    monkeypatch.setenv('AUTOVIDEO_GEMINI_CHAT_CLEANUP','delete-after-read')
    assert not b._cleanup_requested()


def test_character_preview_without_detected_face_keeps_whole_photo_compact(tmp_path):
    from engine.studio_widgets import character_cards
    image=Image.new('RGB',(60,240),'blue')
    image.paste('red',(0,0,60,30));image.paste('green',(0,210,60,240))
    path=tmp_path/'portrait.png';image.save(path)
    html=[]
    from contextlib import nullcontext
    st=NS(columns=lambda n:[NS(container=lambda **kw:nullcontext()) for _ in range(n)],
        markdown=lambda value,**kw:html.append(value),dialog=lambda *a,**kw:lambda fn:fn,button=lambda *a,**kw:False)
    character_cards(st,[{'id':'test','name':'Test','references':[{'path':str(path)}]}])
    encoded=html[0].split('base64,')[1].split('"')[0]
    thumb=Image.open(io.BytesIO(base64.b64decode(encoded)))
    assert thumb.getpixel((70,10))[0]>200
    assert thumb.getpixel((70,150))[1]>80
    assert thumb.size==(140,160)


@pytest.mark.parametrize('pause', [True,False])
def test_local_close_fallback_retains_journal_and_survives_resume(tmp_path,pause):
    from tests.test_v716_frame_batch_recovery import setup_batch
    from tests.test_economy_parallel_frames import _Refs
    f,m,D,settings,calls=setup_batch(tmp_path,{'shot_001_close.jpg'})
    settings.update(flow_local_closing_fallback=True, flow_continue_unresolved_frames=False,
                    flow_pause_on_unresolved_request=pause)
    journal=Path(D['storyboard'])/'shot_001_close.jpg.flow-request.json'
    journal.write_text('{"status":"pending","request_hash":"do-not-change"}')
    original=journal.read_bytes()
    f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    close=Path(D['storyboard'])/'shot_001_close.jpg'
    opening=Path(D['storyboard'])/'shot_001_open.jpg'
    assert close.read_bytes()==opening.read_bytes()
    assert journal.read_bytes()==original
    record=json.loads(Path(str(close)+'.local-fallback.json').read_text())
    assert not record['exact_flow_recovered'] and record['pending_request_retained']
    assert m.shots[0].closing_frame_source=='local-opening-fallback'
    calls.clear()
    f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    assert calls==[] and journal.read_bytes()==original


def test_local_fallback_never_invents_missing_opening(tmp_path):
    from tests.test_v716_frame_batch_recovery import setup_batch
    from tests.test_economy_parallel_frames import _Refs
    from engine.factory import FlowFrameBatchPending
    f,m,D,settings,calls=setup_batch(tmp_path,{'shot_001_open.jpg','shot_001_close.jpg'})
    settings['flow_local_closing_fallback']=True
    with pytest.raises(FlowFrameBatchPending):
        f._generate_economy_frames(m,D,_Refs(),False,settings,{},lambda *a:None)
    assert not (Path(D['storyboard'])/'shot_001_close.jpg').exists()


def test_video_review_attaches_source_proxy_and_preserves_exact_words(tmp_path,monkeypatch):
    from engine.studio_review import review_recreation_clip
    import engine.production as prod
    import engine.providers.gemini_web as gw
    monkeypatch.chdir(tmp_path)
    clip=tmp_path/'clip.mp4';clip.write_bytes(b'fixture video')
    monkeypatch.setattr(prod,'probe',lambda p:{'format':{'duration':'12'}})
    monkeypatch.setattr(prod,'run',lambda command,**kw:Path(command[-1]).write_bytes(b'proxy'))
    seen=[]
    reply={'topic':'Help','narration':'Please help me.', 'scenes':[{'text':'Please help me.',
           'visual_intent':'Person requests help in a garden.', 'duration':6}]}
    def generate(*a,**kw):
        assert Path(kw['attachments'][0]).read_bytes()==b'proxy'
        seen.append(kw);return json.dumps(reply)
    monkeypatch.setattr(gw,'gemini_web_generate',generate)
    result=review_recreation_clip(clip,'Please help me.','en')
    assert not Path(seen[0]['attachments'][0]).exists()
    assert clip.read_bytes()==b'fixture video'
    assert seen[0]['cleanup']=='delete-after-read'
    assert result['provenance']['source_clip_sha256']==prod.digest(clip)
    assert not result['approved']
    reply['narration']='Invented replacement.'
    with pytest.raises(ValueError,match='changed or omitted'):
        review_recreation_clip(clip,'Please help me.','en')


def test_invalid_attachment_stops_before_submission(tmp_path,monkeypatch):
    from engine.providers.gemini_web import GeminiWebBrowser
    b=GeminiWebBrowser.__new__(GeminiWebBrowser)
    with pytest.raises(ValueError,match='MP4 proxy'):
        b._attach_review_video([tmp_path/'missing.mp4'])


def test_reviewed_visual_scenes_are_imported_and_stale_source_is_rejected(tmp_path,ffmpeg_media):
    from engine.clip_recreation import create_recreation_job
    from engine.content_library import CharacterLibrary
    from engine.factory import Factory
    from engine.production import digest,read
    library=CharacterLibrary(tmp_path/'library')
    c=library.create('Helper','A fictional robot wearing a blue coat.',original_confirmed=True)
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'jobs.db'))
    clip=ffmpeg_media['video']
    value={'topic':'Help','narration':'Please help me.', 'scenes':[{'text':'Please help me.',
           'visual_intent':'The robot offers a hand in the garden.', 'duration':6}],
           'provenance':{'source_clip_sha256':digest(clip),'review_provider':'gemini-web-local-video'}}
    kwargs={'library_root':tmp_path/'library','transcript_text':'Please help me.',
            'source_rights':'own_content','adaptation_confirmed':True,'reviewed_plan':value}
    result=create_recreation_job(f,clip,c['id'],**kwargs)
    plan=read(Path(f.pm.job_dir(result['job_id']))/'approved_content_plan.json')
    assert plan['scenes']==value['scenes'] and result['new_generations']==0
    value['provenance']['source_clip_sha256']='wrong'
    with pytest.raises(ValueError,match='another source'):
        create_recreation_job(f,clip,c['id'],**kwargs)

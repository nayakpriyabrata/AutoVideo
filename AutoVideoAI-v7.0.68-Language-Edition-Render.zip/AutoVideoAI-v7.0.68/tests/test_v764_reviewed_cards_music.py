import json
from pathlib import Path

import pytest

from engine.reviewed_cards import validate_cards, render_reviewed_cards
from engine.audio.job_music import obtain_job_music


def test_reviewed_card_handoff_scales_to_measured_voice_and_renders(tmp_path):
    root = tmp_path / 'job'
    (root / 'production').mkdir(parents=True)
    (root / 'production' / 'reviewed_cards.json').write_text(json.dumps({
        'duration': 30, 'cards': [{'start': 3, 'end': 6, 'text': 'Pause, then speak clearly'}]}))
    overlays = render_reviewed_cards(root, 24, 640, 360, 'bold')
    assert len(overlays) == 1
    assert overlays[0]['start'] == 2.4 and overlays[0]['end'] == 4.8
    assert Path(overlays[0]['path']).is_file()


def test_reviewed_cards_reject_overlapping_or_overlong_copy():
    with pytest.raises(ValueError, match='overlap'):
        validate_cards({'cards': [
            {'start': 2, 'end': 4, 'text': 'First'},
            {'start': 3, 'end': 5, 'text': 'Second'}]}, 30)
    with pytest.raises(ValueError, match='short line'):
        validate_cards({'cards': [{'start': 1, 'end': 3, 'text': 'X' * 81}]}, 30)


def test_missing_exact_local_track_fails_before_browser_or_render(tmp_path):
    with pytest.raises(ValueError, match='does not exist'):
        obtain_job_music(tmp_path, 'local', 'motivation', str(tmp_path / 'missing.ogg'))

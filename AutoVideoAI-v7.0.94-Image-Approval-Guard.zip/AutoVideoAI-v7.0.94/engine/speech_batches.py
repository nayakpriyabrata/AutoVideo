"""Speech batches from Create step 4, shown and resumable from Jobs & Recovery (7.0.83).

A batch is prepared before a job exists. Until 7.0.83 a batch that stopped during TTS lived only in the
shared speech_preparation folder, so Jobs & Recovery could not show it, and a job that failed the script
check had no place to correct its narration. This module lists those batches, saves a corrected narration
into the approved snapshot, and resumes a batch. Finished languages are reused: voice files are cached by
script and provider, so a resume only sends the languages that are not finished.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .finishing_studio import shared_root
from .languages import language_pack
from .speech_cards import localization_key, reviewed_scripts_for


def batches_root() -> Path:
    return shared_root() / 'speech_preparation'


def _read(folder: Path) -> dict:
    return json.loads((Path(folder) / 'batch.json').read_text(encoding='utf-8'))


def _row(folder: Path, origin: str) -> dict | None:
    file = folder / 'batch.json'
    try:
        state = _read(folder)
    except (OSError, ValueError):
        return None
    editions = list(state.get('editions') or [])
    bundles = state.get('bundles') or {}
    done = [code for code in editions
            if isinstance(bundles.get(code), dict) and Path(str(bundles[code].get('audio', ''))).is_file()]
    scripts = dict(state.get('scripts') or {})
    if not scripts and state.get('source_script') and state.get('source_language') and editions:
        try:
            scripts = reviewed_scripts_for(state['source_script'], state['source_language'], editions) or {}
        except Exception:
            scripts = {}
    return {
        'key': folder.name,
        'origin': origin,
        'path': str(folder),
        'source_language': state.get('source_language', ''),
        'source_script': state.get('source_script', ''),
        'editions': editions,
        'phase': state.get('phase', ''),
        'ready': state.get('phase') in ('voices_ready', 'ready_for_review') and len(done) == len(editions),
        'done': done,
        'error': state.get('error', ''),
        'scripts': scripts,
        'request': state.get('request') or {},
        'updated': file.stat().st_mtime,
    }


def list_speech_batches(job_dirs=(), limit: int = 60) -> list[dict]:
    """Batches from Create step 4 (shared folder) and unfinished batches inside jobs, newest first.

    Names and states only; no key values.
    """
    rows = []
    root = batches_root()
    if root.is_dir():
        for folder in root.iterdir():
            if folder.is_symlink() or not (folder / 'batch.json').is_file():
                continue
            row = _row(folder, 'Create step 4')
            if row:
                rows.append(row)
    for job in job_dirs:
        folder = Path(job)
        if folder.is_symlink() or not (folder / 'batch.json').is_file():
            continue
        row = _row(folder, 'Job ' + folder.name)
        # A finished job batch is not listed; the job itself shows the result.
        if row and not (row['ready'] and not row['error']):
            rows.append(row)
    rows.sort(key=lambda row: -row['updated'])
    return rows[:limit]


def correct_speech_scripts(folder, edited: dict, approvals: dict) -> dict:
    """Save corrected narration for a batch and the approved snapshot shared with Create and jobs (7.0.83).

    The check is the same as Create step 4 (words outside the language's script are refused). The master
    script is not edited here. Corrected batches lose their voice files until resumed, so an old voice file
    for the old text can never be attached.
    """
    from .production import save
    from .speech_cards import approve_localized_scripts
    folder = Path(folder)
    state = _read(folder)
    editions = list(state['editions'])
    source = state['source_language']
    master = state['source_script']
    key = localization_key(master, source, editions)
    snapshot_dir = batches_root() / 'scripts' / key
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    snapshot = {'fingerprint': key, 'source_language': source, 'source_script': master, 'editions': editions}
    edited = dict(edited or {})
    approvals = dict(approvals or {})
    edited[source] = master
    approvals[source] = True
    result = approve_localized_scripts(snapshot_dir, snapshot, edited, approvals)
    scripts = {code: str(result['scripts'][code]).strip() for code in editions}
    state.update(scripts=scripts,
                 scripts_sha256=hashlib.sha256(json.dumps(scripts, sort_keys=True, ensure_ascii=False).encode()).hexdigest(),
                 bundles={}, phase='scripts_corrected', error='')
    save(folder / 'batch.json', state)
    return scripts


def resume_speech_batch(folder, *, provider=None, progress=None) -> dict:
    """Continue a batch with its saved scripts and settings. Finished voices are reused (7.0.83)."""
    from .speech_cards import prepare_batch
    folder = Path(folder)
    state = _read(folder)
    editions = list(state['editions'])
    scripts = dict(state.get('scripts') or {})
    if not scripts:
        scripts = reviewed_scripts_for(state['source_script'], state['source_language'], editions) or {}
    if not scripts:
        raise ValueError('This batch has no saved narration. Open Create step 4 and prepare the language scripts again.')
    request = dict(state.get('request') or {})
    chosen = provider if provider is not None else request.get('provider', 'auto')
    audio = str(request.get('audio_path') or '')
    audio_path = audio if audio and Path(audio).is_file() else None
    return prepare_batch(
        folder, state['source_script'], state['source_language'], editions,
        draft_cards=request.get('draft_cards', True),
        provider=chosen, audio_path=audio_path, cleanup=request.get('cleanup', 'delete-after-read'),
        progress=progress, localized_scripts=scripts, text_cards=request.get('text_cards', True),
        educational=request.get('educational', False), topic=request.get('topic', ''),
        card_provider=request.get('card_provider', 'gemini-web'), hooks=request.get('hooks', False))


def language_label(code: str) -> str:
    return language_pack(code).label

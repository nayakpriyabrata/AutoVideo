# AutoVideoAI 7.0.17 · Cast and music workflow

Stop Studio, the runner and all jobs before upgrading. Extract into a fresh
folder. Replace the example old directory with the version you actually use:

```bash
cd AutoVideoAI-v7.0.17
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.14 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.14 . --apply
python3 -m pip install -r requirements.txt
python3 -m playwright install chromium
python3 -m streamlit run app.py
```

If Chromium reports missing Linux libraries, install its WSL dependencies with
`python3 -m playwright install --with-deps chromium`. Visible browser workflows
also need WSLg or your working display setup.

## Character library and production

- Character Library shows four compact collectible cards per row. Each card
  shows the first authorized reference portrait and the character name. Entries
  without a supplied portrait show the name alone. Details and voice preferences
  remain below the cards. Image upload and existing WSL paths are supported.
- Guided Studio has an optional script-first Gemini Web stage. Review/edit the
  returned script and scene JSON, read its suggested saved cast roles, approve
  the original script, choose up to three saved characters, then create the
  production. Drafting does not launch visuals or TTS. A reviewed script is
  imported into the job rather than sent through the writer again.
- Long videos, Shorts/Reels, cartoon recipes, Advanced Create, music videos and
  Mini Reels have optional cast selection. Cartoon styling asks for the same
  selected identity in stylized form; visual identity still needs review.
- Mini Reels freeze the cast and copy the first supplied portrait per character
  into the reel's reference folder before Flow. Resume uses that saved cast and
  exact request. Change the cast by starting a new draft, never by changing an
  unresolved request. No-photo entries use their saved textual identity; they
  cannot guarantee a matching likeness without an identity reference.
- The private control center can load character cards directly from the
  authenticated loopback runner. Portraits stay in the local connection and tab
  memory; the hosted site does not store them. The manual ID field remains usable.

## AI recreation source selection

Choose **Saved generated clip** to load clips from persisted complete/partial
`highlights` reports, including after a browser restart. Point the folder field
at a custom output directory if needed. QC-blocked clips are labeled for review.
Choose **Local video file** explicitly to enter a WSL/Linux video path. Missing
legacy paths are relocated only when one matching saved file can be identified.

## Flow Music browser workflow

Music Video, Guided Studio and Clip Studio expose the same workflow:

1. Open the Flow Music login browser and sign in directly. This uses a separate
   persistent Chromium profile under `data/browser/flow_music`.
2. Edit the contextual music prompt and save a new draft request.
3. Approve one request at your account's current cost, then **Generate music
   once**. Flow Music is not assumed to be free. If the service displays an
   additional approval, handle it in its visible browser.
4. Choose a returned song version, download the selected MP3 and listen to it.
   A music-video job copies the validated selected song into its own audio folder.

The request is journaled before submission. Repeated Generate is blocked after
submission, including an uncertain timeout. Rescan opens the saved session and
never sends a new prompt. Download scopes the menu to the exact recorded song
identity, then uses Download → MP3 and validates the file with ffprobe before
accepting it. Duplicate titles alone are not treated as identity. If the service
changes or candidates are ambiguous, recovery stops instead of choosing another
song. A session URL can be supplied only when the submission URL was not captured;
an existing saved session cannot be replaced by a different session.

The browser integration is based on the supplied Flow Music screenshots and
has local request/recovery tests. **Live Flow Music sign-in, DOM selectors,
generation, account pricing and downloads in your WSL session are unverified.**
Its UI may require a selector update. The local-song import option remains
available. This build does not promise unattended success or a failure rate.

## Background music and clip logos

- Clip Studio has Flow Music, local licensed files, Pixabay search, offline
  original instrumental and an explicit reliable automatic option. Reliable
  automatic tries the configured local library, then Pixabay, then creates an
  original quiet instrumental locally. It validates playable audio and reports
  fallback reasons; it does not claim a downloaded song was found when it wasn't.
- Pixabay browser failures remain visible. YouTube Audio Library or other tracks
  you have permission to use can be downloaded separately and imported as local
  files. Provider labels do not establish publication rights.
- Clip Studio's **Channel logo watermark** controls are expanded. Enable the logo,
  upload PNG/JPEG/WebP or supply its WSL path, then choose size and corner. The
  selected exact logo is retained in the clip and approved B-roll renders.
- Video previews remain compact with native fullscreen controls.

The v7.0.16 batch recovery and exact Flow image/video journals are preserved.
This release does not automatically resolve an ambiguous old Flow image request
or authorize replacement image/video generations.

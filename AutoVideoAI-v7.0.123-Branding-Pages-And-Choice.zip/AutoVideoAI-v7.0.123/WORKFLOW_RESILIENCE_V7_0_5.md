# AutoVideoAI 7.0.5 — narration recovery, multi-insert B-roll and offline music

## Upgrade

Stop Studio, runner and CLI jobs. Back up the installation; overlay source in
the same folder to preserve absolute job paths. Preserve outputs/, data/, .env,
browser profiles and config/user_settings.yaml. Review defaults before replacing
custom config. In your existing Python environment install requirements.txt and
restart Studio/runner. Mini Reels also has a restricted XML fallback if defusedxml
is absent; it rejects DTD/entity declarations and UTF16/32 feeds.

## AI recreation: 121.8 seconds versus 169 seconds

Imported approved narration is not automatically rewritten. Resume reused the
121.8-second checkpoint, then failed the same target-duration check. Before scene
planning, Queue offers “Use measured narration length for this job”. Save it and
Resume the same job. The target follows measured narration, preserves wording
and reuses audio. The output will be about 122 seconds, not 169. This option
disables automatic script retiming. New recreation jobs offer this choice before
creation. It cannot alter timing after shots exist.

To retain a 169-second production, expand and review the script in a new approved
plan instead. Artificial silence/stretching is not used to disguise the mismatch.

## Five to ten meaningful inserts in a clip

Clip Studio's maximum is now PER CLIP (up to ten), subject to enough duration for
nonoverlapping inserts and gaps. Search uses local speech context around each
placement when the transcript sidecar exists. The candidates are spread across
the clip. A twenty-clip batch can therefore request up to 200 candidates; start
with fewer clips/slots if download time is significant. This is a maximum, not
a promise that ten suitable assets exist.

Load saved highlights without regeneration. Replace previous suggestions when
moving an old one-slot review to the new multi-slot plan. For example: use seven
slots, create AI images in two or three slots, attach one or two permitted local
stock photos, and fill the rest with relevant video cutaways/reactions. Every
asset must be previewed and explicitly approved or skipped. Save decisions, then
apply. All approved inserts for a clip are now combined into ONE edited copy;
captions are burned once and original audio/music and source files are preserved.
Overlapping edits are rejected. Editing a source asset resets its approval.

### AI images and reaction ideas

Each slot has “Create Gemini-planned AI image for review”. Gemini Web writes the
contextual prompt; the existing free image provider creates the image, then it
is encoded locally as a short visual insert. This does not download images from
Gemini Web and does not submit Flow generation. Image/provider fallback quality
still needs review. A Gemini login or image/network failure is shown without
discarding your completed clips.

You can attach a local image or video (including a meme you have permission to
use) to a slot. Regional reaction briefs use Indian themes for Hindi/Odia and
global English themes for English. These are original editorial suggestions,
not verified current popularity claims. Bollywood/movie assets are not scraped,
licensed or automatically approved by the tool. Inspect each asset's permissions
yourself. Stock photos downloaded with permission can use the same local path
control. Odia reaction briefs do not certify Odia speech recognition.

## Free test and an unaccepted stock shot

The one-click free test now uses LOCAL_FREE with a zero Flow budget. It does not
route to downloaded stock. It still needs working TTS and free-image access.
Rejected stock takes can use a bounded saved-storyboard motion fallback, which
runs QC again. Both the rejected stock take and its QC report are retained. A
rejected fallback remains unaccepted; exhausted retries no longer silently accept
a rejected take.

For the existing octopus job, select it in Queue. Open local storyboard repair,
select shot_003, review the displayed image(s), and run repair/QC. The repair now
also finds the legacy storyboard/shot_003.jpg frame. If accepted, Render now uses
the same job's accepted takes. Other accepted shots are preserved. If the saved
frame is irrelevant or the repair fails QC, replace/review that shot; do not mark
it accepted just to bypass coverage.

## Music without Chromium

Choose Background music = generated for video jobs, or “Generate original
instrumental offline” in Clip Studio. This creates a quiet 32-second original
instrumental loop locally; the renderer can loop it for longer productions.
It uses no browser, network, downloaded song, voice or Flow credits. It is a
simple instrumental option, not a promise of studio-composed music quality.
Licensed local tracks remain another offline option.

Stock/music browser searches now use isolated temporary profiles to avoid shared
profile locks. Known launch errors distinguish missing Chromium, Linux libraries,
profile lock, full storage and unavailable display. For missing dependencies use
the same WSL Python environment:

    python3 -m playwright install --with-deps chromium

That command may require system package permissions. Use generated/local music
if you do not want to install browser dependencies. Low disk space still needs
attention before media writes; this build does not delete your files.

## Mini Reels: one native scene, optional local delivery hold

The module starts with a manual idea and creates one reviewed 8-second Flow
video, with native requested audio and no long-form TTS/storyboard pipeline.
After completion choose 8, 10 or 12 seconds for delivery. Ten/twelve explicitly
adds a local final-frame hold and silent audio padding. It does not generate more
motion or spend more Flow credits. The native source remains unchanged. A source
that is not approximately eight seconds is rejected for this export.

## Attached long-form log

The log shows shot_001 eventually downloaded after browser closures. The later
shot_008 request stopped because its credit approval control could not be
activated. Inspect that exact pending request in the persisted Flow project.
Approve it manually only if you accept the displayed cost, then use existing
request recovery/Resume. Do not click Generate again or associate an arbitrary
newest tile. This release does not remove credit caps or pending-request guards.

## Reliability and validation

The 2–3% failure target requires representative live runs and a defined metric
(first-attempt completion versus successful eventual recovery). Passing mocked
and encoded-media tests does not establish that rate. Flow capacity, Google UI,
sign-in, public image/stock sources, ASR/TTS and disk space remain dependencies.
No live user account operation or paid generation was performed during this build.

Validation: 676 engine tests passed (12 dependency deprecation warnings); 27 control-center checks passed. Encoded-media tests cover combined B-roll and the end-hold export. Live Google/WSL browser behavior remains unverified.

"""Channel branding (name, logo, intro, outro) for a saved job - and for the narration that becomes one.

Two field reports after v7.0.123's predecessor:

* *"I don't see the earlier selected channel profile is attached to either of the language"* - a narration
  prepared in Create step 4 never recorded the channel profiles chosen in step 3, and a job created from those
  voices therefore had an empty ``production/language_editions.json``: no name, no logo, no intro, no outro,
  and the Three-language panel could only answer "no_intro_outro".
* *"give user option to attach the channel and character if its missing"* - attaching has to be possible after
  the fact, without re-recording a voice, re-rendering a shot or spending a Flow credit.

This module only writes settings and profile paths. It never copies, re-encodes or deletes media: the existing
Three-language panel adds the intro/outro and renders the extra editions from the picture the job already has.
"""
from __future__ import annotations

import json
from pathlib import Path

from .production import read, save


def saved_profiles(root=None) -> list[dict]:
    """Every channel profile on this installation: path, name, languages, and what it carries."""
    from .finishing_studio import profiles as profile_paths
    rows = []
    for path in profile_paths(root):
        data = read(path, {}) or {}
        assets = data.get('assets') or {}
        rows.append({
            'path': str(path),
            'name': str(data.get('name') or path.parent.name),
            'names': {str(k): str(v) for k, v in (data.get('names') or {}).items()},
            'languages': sorted({key.split('-', 1)[1] for key in assets
                                 if key.startswith('logo-') and len(key.split('-', 1)) == 2}),
            'logo': bool(assets.get('logo') or any(key.startswith('logo-') for key in assets)),
            'intro': bool(assets.get('intro')),
            'outro': bool(assets.get('outro')),
        })
    return rows


def label(profile) -> str:
    """One line for a saved profile: its name and the branding it actually carries."""
    parts = [profile['name']]
    if profile.get('languages'):
        parts.append('own logo for ' + ', '.join(profile['languages']))
    elif profile.get('logo'):
        parts.append('logo')
    parts.append('intro' if profile.get('intro') else 'no intro')
    parts.append('outro' if profile.get('outro') else 'no outro')
    return ' · '.join(parts)


def _editions_file(job_dir) -> Path:
    return Path(job_dir) / 'production' / 'language_editions.json'


def job_profiles(job_dir) -> dict:
    """The profile each language of this job uses, as saved in the job (never guessed)."""
    data = read(_editions_file(job_dir), {}) or {}
    profiles = data.get('profiles') or {}
    return {str(code): str(path) for code, path in profiles.items() if path}


def job_editions(job_dir) -> list[str]:
    """The editions this job renders, from its saved record (falls back to its manifest language)."""
    data = read(_editions_file(job_dir), {}) or {}
    editions = [str(code) for code in (data.get('editions') or []) if code]
    if editions:
        return editions
    manifest = read(Path(job_dir) / 'production_manifest.json', {}) or {}
    return [str(manifest.get('language') or 'en')]


def attach_profiles(job_dir, profiles: dict, *, editions=None) -> dict:
    """Save one channel profile per language into a job. Settings only - nothing is rendered.

    ``profiles`` maps a language code to a channel profile path (an empty value removes that entry). The
    Three-language panel reads this file, so a job given its profile here can add the intro/outro and render
    every edition from the picture it already has - no shot is generated again.
    """
    folder = Path(job_dir)
    if not (folder / 'production_manifest.json').is_file():
        raise ValueError('No saved job at ' + str(folder) + ' (production_manifest.json is missing).')
    available = {row['path']: row for row in saved_profiles()}
    chosen = {}
    for code, path in (profiles or {}).items():
        code, path = str(code), str(path or '')
        if not path:
            continue
        if path not in available:
            raise ValueError('No saved channel profile at ' + path
                             + '. Choose one from the list (Channel Desk lists them), then save again.')
        chosen[code] = path
    record = read(_editions_file(folder), {}) or {}
    wanted = [str(code) for code in (editions or job_editions(folder))]
    merged = dict(record.get('profiles') or {})
    for code, path in chosen.items():
        merged[code] = path
    for code in list(merged):
        if code not in wanted and code not in chosen:
            merged.pop(code, None)
    record.update({
        'source_language': record.get('source_language') or job_editions(folder)[0],
        'editions': wanted,
        'profiles': merged,
        # 'status' belongs to narration preparation and is left alone; branding records its own line.
        'branding_status': 'channel profiles attached',
    })
    record.setdefault('prepare_audio', True)
    save(_editions_file(folder), record)
    rows = []
    for code in wanted:
        profile = available.get(merged.get(code, ''), {})
        rows.append({'language': code, 'path': merged.get(code, ''),
                     'name': str(profile.get('name') or ''),
                     'channel_name': str((profile.get('names') or {}).get(code) or profile.get('name') or ''),
                     'intro': bool(profile.get('intro')), 'outro': bool(profile.get('outro')),
                     'logo': bool(profile.get('logo'))})
    return {'job_id': folder.name, 'editions': wanted, 'profiles': merged, 'rows': rows,
            'intro_outro': any(row['intro'] or row['outro'] for row in rows)}


def missing(job_dir, editions=None) -> list[str]:
    """Editions of this job that still have no channel profile."""
    known = job_profiles(job_dir)
    return [code for code in (editions or job_editions(job_dir)) if not known.get(code)]


def summary(rows) -> str:
    """Plain sentence for the UI and the CLI: which language uses which channel, and what it carries."""
    from .languages import language_pack
    pieces = []
    for row in rows or []:
        name = row.get('channel_name') or row.get('name') or ''
        if not name:
            continue
        extras = [word for word, present in (('logo', row.get('logo')), ('intro', row.get('intro')),
                                             ('outro', row.get('outro'))) if present]
        try:
            label = language_pack(row['language']).label
        except Exception:
            label = str(row['language'])
        pieces.append(label + ' → ' + name + (' (' + ', '.join(extras) + ')' if extras else ''))
    return ' · '.join(pieces)

from types import SimpleNamespace as NS
from pathlib import Path
import json
import pytest


def test_edited_library_photo_becomes_bounded_rgb_upload(tmp_path):
    from PIL import Image
    from engine.content_library import CharacterLibrary
    from engine.cast import snapshot_cast,register_cast
    from engine.reference_manager import ReferenceManager
    from engine.flow_upload_media import prepare_reference
    from engine.production import digest,save
    source=tmp_path/'portrait.jpg';Image.new('CMYK',(3000,2400),(1,50,70,0)).save(source)
    library=CharacterLibrary(tmp_path/'data/content/characters')
    original=library.create('Aanya','Original young character with expressive eyes',original_confirmed=True)
    edited=library.update(original['id'],'Aanya',original['description'],reference_files=[str(source)])
    cast=snapshot_cast([edited['id']],str(library.root))
    root=tmp_path/'outputs/job';root.mkdir(parents=True);save(root/'cast_snapshot.json',{'characters':cast})
    refs=ReferenceManager(str(root/'references'));register_cast(root,refs)
    frozen=Path(refs.get('character')[0]);before=digest(frozen)
    ready=prepare_reference(frozen,root=str(tmp_path/'prepared'))
    with Image.open(ready) as image:
        assert image.mode=='RGB' and max(image.size)<=2048 and image.format=='JPEG'
    assert before==digest(source)==digest(frozen)
    assert json.loads(Path(ready+'.prepared.json').read_text())['source_sha256']==before
    assert ready==prepare_reference(frozen,root=str(tmp_path/'prepared'))


def test_cutaway_overlaps_keep_last_approved_picture_and_duration():
    from engine.render.bounded import picture_intervals
    rows=picture_intervals(10,[{'path':'a','start':1,'end':5},{'path':'b','start':3,'end':4}])
    assert [(r['start'],r['duration'],r['path']) for r in rows]==[(0,1,None),(1,2,'a'),(3,1,'b'),(4,1,'a'),(5,5,None)]
    assert rows[3]['in']==3 and sum(r['duration'] for r in rows)==10


def test_google_rejection_never_counts_as_music_auth(tmp_path):
    from engine.flow_music import wait_for_manual_login
    seen=[]
    def wait(ms):
        seen.append(json.loads((tmp_path/'.autovideo-login.json').read_text()))
        (tmp_path/'.autovideo-login-control.json').write_text(json.dumps({'token':'owned','action':'close'}))
    b=NS(page=NS(url='https://accounts.google.com/v3/signin/rejected',is_closed=lambda:False,wait_for_timeout=wait),composer=lambda:(_ for _ in ()).throw(RuntimeError('Login required')))
    result=wait_for_manual_login(b,tmp_path,token='owned')
    assert not result['auth_ready'] and seen[0]['state']=='sign-in-blocked'


def test_imported_music_validation_without_generation(tmp_path,ffmpeg_media):
    from engine.flow_music import import_music
    path=import_music(Path(ffmpeg_media['music']).read_bytes(),'downloaded.wav',str(tmp_path/'music'))
    assert Path(path).read_bytes()==Path(ffmpeg_media['music']).read_bytes()
    with pytest.raises(ValueError):import_music(b'invalid','a.txt',str(tmp_path/'music'))


def test_large_render_bounds_decoders_and_keeps_all_60_cutaways(tmp_path,ffmpeg_media,monkeypatch):
    from engine.render import ffmpeg_renderer as ff
    from engine.production import probe
    import subprocess,cv2,numpy as np
    stock=tmp_path/'distinct-stock.mp4'
    subprocess.run([ff.ffmpeg_exe(),'-y','-v','error','-i',ffmpeg_media['video'],'-vf','hue=h=90','-an','-c:v','libx264','-preset','ultrafast',str(stock)],check=True,capture_output=True,timeout=30)
    commands=[];real=ff._run_ffmpeg_progress
    def recorded(cmd,*a,**kw):
        commands.append(cmd)
        return real(cmd,*a,**kw)
    monkeypatch.setattr(ff,'_run_ffmpeg_progress',recorded)
    segments=[{'src':ffmpeg_media['video'],'in':0,'dur':1,'hard_cut':True} for _ in range(20)]
    cuts=[{'path':str(stock),'start':.1+i*.3,'end':.225+i*.3,'in':1} for i in range(60)]
    out=tmp_path/'out.mp4'
    result=ff.render_ffmpeg(segments,None,str(out),str(tmp_path),W=160,H=90,fps=24,encoder='libx264',quality='preview',safe_concat=True,video_overlays=cuts)
    assert result['bounded_render'] and result['approved_cutaways']==60
    assert max(cmd.count('-i') for cmd in commands)<=8
    assert abs(float(probe(str(out))['format']['duration'])-20)<.15
    assert not list(tmp_path.glob('.bounded-*'))
    def frame(path,seconds):
        cap=cv2.VideoCapture(str(path));cap.set(cv2.CAP_PROP_POS_MSEC,seconds*1000);ok,pixels=cap.read();cap.release();assert ok
        return cv2.resize(pixels,(160,90)).astype(float)
    actual=frame(out,.125)
    expected=frame(stock,1.04)
    wrong=frame(ffmpeg_media['video'],.125)
    assert np.mean(abs(actual-expected))<np.mean(abs(actual-wrong))



def test_photo_cast_pauses_parallel_frames_instead_of_free_fallback(tmp_path,monkeypatch):
    import engine.providers.flow_browser as flow
    from engine.factory import Factory
    from tests.test_economy_parallel_frames import _shot,_Refs,_ProjectLog,_Browser
    class Provider:
        def __init__(self,**kw):self.browser=_Browser('');self._last_video_project_url=''
        def close(self):pass
        def _ensure(self):return self.browser
        def generate_image(self,*a,**kw):raise flow.FlowReferenceUnavailable('Original cast photo could not attach')
    monkeypatch.setattr(flow,'FlowBrowserProvider',Provider)
    f=Factory.__new__(Factory);f.pm=_ProjectLog();seen=[]
    f._free_image_fallback=lambda *a,**kw:pytest.fail('Must not substitute free images for the selected cast')
    def pause(*a,**kw):
        seen.append(a[1]);raise RuntimeError('Paused for required cast reference')
    f._pause_pending_flow=pause
    shot=_shot('shot_001');shot.character_ids=['aanya']
    tasks=[{'shot':shot,'label':'opening frame','out':str(tmp_path/'out.jpg'),'prompt':'scene'}]
    with pytest.raises(RuntimeError,match='Paused for required cast'):
        f._generate_economy_frames_parallel(NS(job_id='job',shots=[shot]),{'root':str(tmp_path)},_Refs(),True,{'flow_frame_retries':3},lambda *a:None,tasks,1,'auto')
    assert seen==['shot_001']


def test_staged_render_keeps_audio_captions_and_channel_overlay(tmp_path,ffmpeg_media):
    from engine.render.ffmpeg_renderer import render_ffmpeg,has_subtitles_filter
    from engine.production import probe
    from PIL import Image
    import cv2
    logo=tmp_path/'logo.png';image=Image.new('RGBA',(160,90));image.paste((255,0,0,255),(0,0,20,20));image.save(logo)
    captions=tmp_path/'captions.ass'
    captions.write_text('''[Script Info]
ScriptType: v4.00+
PlayResX: 160
PlayResY: 90
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,12,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,5,5,5,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:00.00,0:00:04.00,Default,,0,0,0,,Reviewed captions
''')
    segments=[{'src':ffmpeg_media['video'],'in':0,'dur':1,'hard_cut':True} for _ in range(4)]
    cuts=[{'path':ffmpeg_media['video'],'start':.1+i*.3,'end':.25+i*.3,'in':1} for i in range(10)]
    output=tmp_path/'branded.mp4'
    result=render_ffmpeg(segments,ffmpeg_media['voice'],str(output),str(tmp_path),W=160,H=90,fps=24,quality='preview',encoder='libx264',safe_concat=True,video_overlays=cuts,overlays=[{'path':str(logo),'start':0,'end':4}],music=ffmpeg_media['music'],use_loudnorm=False,ass_path=str(captions))
    media=probe(str(output))
    assert result['bounded_render'] and result['approved_cutaways']==10
    assert any(s['codec_type']=='audio' for s in media['streams'])
    assert result['captions_requested'] and result['burn_captions']==has_subtitles_filter()
    cap=cv2.VideoCapture(str(output));cap.set(cv2.CAP_PROP_POS_MSEC,2000);ok,pixels=cap.read();cap.release();assert ok
    assert pixels[10,10,2]>220 and pixels[10,10,0]<30
    assert abs(float(media['format']['duration'])-4)<.15

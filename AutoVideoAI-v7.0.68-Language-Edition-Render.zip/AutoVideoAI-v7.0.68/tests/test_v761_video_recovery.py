import json
from pathlib import Path
from types import SimpleNamespace as NS

import pytest


def _fixture(tmp_path, monkeypatch, decision='ACCEPT'):
    from engine.providers.flow_browser import FlowBrowserProvider
    monkeypatch.setenv('HOME', str(tmp_path/'home'))
    monkeypatch.setattr(FlowBrowserProvider, '_is_valid_video_file', staticmethod(lambda p: Path(p).read_bytes()==b'playable-video'))
    folder=tmp_path/'outputs'/'job';shot_dir=folder/'flow/shots/shot_008';shot_dir.mkdir(parents=True)
    source=tmp_path/'reviewed.mp4';source.write_bytes(b'playable-video')
    journal=shot_dir/'take_01.mp4.flow-request.json'
    url='https://flow.google.com/project/1cc33857-aaaf-4f7f-ac7a-2e20fc6687d3'
    journal.write_text(json.dumps({'kind':'video','status':'pending','project_url':url}))
    (folder/'pause_state.json').write_text(json.dumps({'resolved':False}))
    shot=NS(shot_id='shot_008',accepted_take='')
    manifest=NS(shots=[shot],status='failed')
    pm=NS(job_dir=lambda j:folder,load_manifest=lambda j:manifest,save_manifest=lambda m:None)
    db=NS(upsert=lambda *a,**k:None)
    calls=[]
    def associate(job,id,path):
        calls.append((job,id,path))
        if decision=='ACCEPT':shot.accepted_take=str(shot_dir/'accepted.mp4')
        return {'qc':{'decision':decision},'take':str(shot_dir/'take_04.mp4')}
    return NS(pm=pm,db=db,associate_download=associate),source,journal,url,calls


def test_reviewed_mp4_resolves_exact_journal_without_browser(tmp_path,monkeypatch):
    from engine.flow_local_video_recovery import import_reviewed_video
    factory,source,journal,url,calls=_fixture(tmp_path,monkeypatch)
    editor=url+'/edit/eb4b2d6b-9411-4968-a049-5b64e1857f60'
    result=import_reviewed_video(factory,'job','shot_008',source,editor,reviewed=True)
    assert result['resolved'] and result['new_credits']==0 and len(calls)==1
    assert json.loads(journal.read_text())['status']=='downloaded'
    assert (journal.parent/'take_01.mp4').read_bytes()==b'playable-video'
    assert json.loads((journal.parents[3]/'pause_state.json').read_text())['resolved']
    with pytest.raises(ValueError,match='unresolved'):
        import_reviewed_video(factory,'job','shot_008',source,editor,reviewed=True)


def test_wrong_editor_and_rejected_qc_keep_request_pending(tmp_path,monkeypatch):
    from engine.flow_local_video_recovery import import_reviewed_video
    factory,source,journal,url,calls=_fixture(tmp_path,monkeypatch,decision='REJECT')
    with pytest.raises(ValueError,match='does not match'):
        import_reviewed_video(factory,'job','shot_008',source,
            'https://flow.google.com/project/other/edit/asset',reviewed=True)
    assert not calls
    result=import_reviewed_video(factory,'job','shot_008',source,url+'/edit/asset',reviewed=True)
    assert not result['resolved'] and json.loads(journal.read_text())['status']=='pending'
    assert not (journal.parent/'take_01.mp4').exists()


def test_blob_event_is_captured_before_target_closes(tmp_path,monkeypatch):
    from engine.providers.flow_browser import FlowBrowser
    import engine.flow_ui_blob as ui_blob
    import engine.flow_blob_capture as blob_capture
    out=tmp_path/'take.mp4';handlers={}
    page=NS(url='https://flow.google.com/project/exact',
            on=lambda name,fn:handlers.__setitem__(name,fn),
            off=lambda name,fn:handlers.pop(name,None))
    browser=FlowBrowser.__new__(FlowBrowser)
    browser._page=page;browser._project_url=page.url
    browser._ensure_project_guard_page=lambda *a:None
    browser._click_download_control=lambda button,**kw:handlers['download'](NS(url='blob:https://flow.google.com/exact'))
    monkeypatch.setattr(ui_blob,'arm',lambda *a:None)
    def capture(bridge,event,path):
        Path(path).write_bytes(b'valid-video')
        return path
    monkeypatch.setattr(blob_capture,'capture',capture)
    assert browser._download_from_tile_button(object(),str(out))==str(out)
    assert out.read_bytes()==b'valid-video'


def test_exact_video_tile_waits_then_rebinds_or_refuses(tmp_path):
    from engine.providers.flow_browser import FlowBrowser, FlowUIChanged
    import pytest
    elapsed=[]
    tile=NS(is_visible=lambda **kw:True)
    tiles=NS(count=lambda:1,nth=lambda i:tile)
    page=NS(wait_for_timeout=lambda ms:elapsed.append(ms),locator=lambda selector:tiles)
    browser=FlowBrowser.__new__(FlowBrowser);browser._page=page
    browser._wait_for_media_signature=lambda signature,timeout_ms:{'kind':'video','sig':signature,'dom_index':0}
    asset,element=browser._settle_exact_video_tile('saved-video')
    assert elapsed==[15000] and element is tile and asset['sig']=='saved-video'
    browser._wait_for_media_signature=lambda signature,timeout_ms:None
    with pytest.raises(FlowUIChanged,match='changed while loading'):
        browser._settle_exact_video_tile('saved-video')

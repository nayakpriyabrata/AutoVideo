"""Explicit completed-job deletion with preview, lock, database backup and confirmation.

A completed job with resolved Flow requests is eligible. v7.0.97 finds the finished video wherever
the renderer wrote it (``<job>-final.mp4``, ``<job>-final-broll.mp4`` for video cutaways, a saved
``final_path``) instead of one hard-coded name, and can delete a completed job folder that has no
finished video when the user ticks that explicit choice. An unfinished job or an unresolved Flow
request is never eligible. Never follows job-directory symlinks or touches shared browser logins.

v7.0.106: the finished video is moved to ``<outputs>/_render-backups/<job>/`` *before* the folder is removed
(``keep_videos=True``, the default). Deleting the job no longer destroys the video it produced; if the backup
cannot be verified the deletion is refused and nothing is removed.
"""
from pathlib import Path
import json
import shutil
import sqlite3
import time
import uuid
import os
from .job_cleanup import _size, find_final_video, job_completion_state
from .production_lock import acquire, release


def _backup_targets(job, final, candidates):
    """Finished videos worth keeping: every language edition, then the validated final.

    v7.0.109: deleting a job used to keep only the primary finished video, so a three-language production
    lost its Hindi and Odia editions with the job folder - exactly the space the user was trying to free,
    while the videos they wanted to publish disappeared. The branded master, the edition copies in
    ``render/`` and every export under ``language_editions/`` and ``primary_branding/`` are backed up too.
    """
    from .post_job_cleanup import _deliverable_videos
    found, seen = [], set()
    extra = []
    try:
        extra = list(_deliverable_videos(job))
    except OSError:
        extra = []
    for path in extra + [final] + [Path(row['path']) for row in candidates if row.get('valid')]:
        if not path:
            continue
        try:
            resolved = path.resolve()
        except OSError:
            continue
        if str(resolved) in seen or not resolved.is_file():
            continue
        try:
            resolved.relative_to(Path(job).resolve())      # never back up something outside the job
        except (OSError, ValueError):
            continue
        seen.add(str(resolved))
        found.append(str(resolved))
    return found


def completed_job_delete(outputs, db_path, job_id, *, apply=False, confirmation='',
                         allow_missing_final=False, keep_videos=True, backup_dir=None):
    outputs=Path(outputs).absolute()
    db_path=Path(db_path).absolute()
    if not job_id or job_id in ('.','..') or Path(job_id).name!=job_id or '/' in job_id or '\\' in job_id:
        raise ValueError('Invalid job ID')
    if outputs.is_symlink():
        # Shared workspace output root is intentionally a link; its target must be trusted.
        outputs=outputs.resolve(strict=True)
    if not outputs.is_dir():raise ValueError('Outputs directory missing')
    job=outputs/job_id
    if job.is_symlink() or not job.is_dir():raise ValueError('Job directory missing or linked')
    code,reason=job_completion_state(job)
    final,candidates=find_final_video(job)
    override=''
    eligible=not code
    if code=='no_final_video' and allow_missing_final:
        eligible,override=True,'no_final_video'
    if code=='no_final_video' and not allow_missing_final:
        reason+=' — tick "delete this completed job even though no finished video was found" to allow it'
    result={'job_id':job_id,'eligible':eligible,'reason':reason or 'Completed job with resolved Flow requests',
            'reason_code':code,'override':override,
            'final_video':str(final) if final else '',
            'final_bytes':final.stat().st_size if final else 0,
            'candidates':[{'name':Path(row['path']).name,'bytes':row.get('bytes',0),'valid':row['valid'],
                           'reason':row.get('reason','')} for row in candidates],
            'bytes':_size(job),'apply':apply,
            'includes':'job folder and SQLite index only; external browser profiles excluded',
            'keeps':'the finished primary video, the branded master and every language edition '
                    '(render/ copies and language_editions/ exports) are backed up before deletion'}
    from .render_backup import backup_root, plan as plan_backup
    keep_root = Path(backup_dir) if backup_dir else backup_root(outputs)
    keep_list = _backup_targets(job, final, candidates) if keep_videos else []
    if keep_list:
        planned = plan_backup(keep_list, root=keep_root, label=job_id)
        result['video_backups'] = planned['files']
        result['backup_folder'] = planned['folder']
        result['backup_bytes'] = planned['bytes']
    result['keep_videos'] = bool(keep_videos)
    result['backup_root'] = str(keep_root)
    if not apply:return result
    if confirmation!=job_id:raise ValueError('Type the exact job ID to confirm permanent deletion')
    if not eligible:raise ValueError('Deletion refused: '+reason)
    service=Path.home()/'.local/share/autovideoai'
    service.mkdir(parents=True,exist_ok=True)
    with (service/'production.lock').open('a+b') as lock:
        try:acquire(lock,blocking=False)
        except BlockingIOError:raise RuntimeError('Production running: stop it before deleting a job')
        try:
            from .job_monitor import _tasks, _guard
            with _guard:
                if any(t['thread'].is_alive() for t in _tasks.values()):
                    raise RuntimeError('A Studio job is running or queued')
            code,reason=job_completion_state(job)
            if code and not (code=='no_final_video' and allow_missing_final):
                raise ValueError('Job changed: '+reason)
            if not db_path.is_file():raise ValueError('Job DB missing; deletion refused')
            # v7.0.106: move the finished video out first. A failure aborts the deletion.
            from .render_backup import backup_files
            if keep_list:
                try:
                    moved = backup_files(keep_list, root=keep_root, label=job_id, apply=True)
                except OSError as error:
                    raise RuntimeError('The finished video could not be backed up (' + str(error)
                                       + '); the job was NOT deleted. Fix the backup folder and try again.')
                kept = [row for row in moved['files'] if row.get('target')]
                if len(kept) != len(keep_list):
                    raise RuntimeError('Not every finished video was backed up ('
                                       + ', '.join(moved.get('warnings') or ['unknown reason'])
                                       + '); the job was NOT deleted. Nothing else was removed.')
                result['video_backups'] = moved['files']
                result['backup_folder'] = moved['folder']
                result['backup_bytes'] = moved['bytes']
                result['kept_videos'] = [row['target'] for row in kept]
            with sqlite3.connect(db_path) as cx:
                backup=db_path.with_name('jobs-before-delete-'+str(time.time_ns())+'.db')
                with sqlite3.connect(backup) as dst:cx.backup(dst)
            trash=outputs/'.deletion-quarantine'
            trash.mkdir(exist_ok=True)
            target=trash/(job_id+'-'+uuid.uuid4().hex)
            os.rename(job,target)
            try:
                with sqlite3.connect(db_path) as cx:
                    cx.execute('DELETE FROM jobs WHERE job_id=?',(job_id,))
            except BaseException:
                os.rename(target,job)
                raise
            # If physical deletion fails, quarantined files remain for manual review.
            try:
                shutil.rmtree(target)
                result['deleted']=True
            except OSError as error:
                result['deleted']=False
                result['quarantine']=str(target)
                result['warning']='Index removed, but files remain quarantined: '+str(error)
            result['backup_db']=str(backup)
            return result
        finally:release(lock)

# v7.0.8 — request-correlated Flow image recovery

## What the supplied report establishes

The location master and shot_001 opening image downloaded in v7.0.7. The closing request remained pending with no recorded completed-asset signature. Its baseline held two images and its final gallery snapshot held four images: two distinct fresh image candidates. The report cannot establish which request produced each candidate. The prior automatic replacement may have contributed to ambiguity. A gallery-only absence check did not provide sufficient proof of failure.

## Changes

- New Agent image instructions carry a request tracking marker, explicitly designated metadata that must not be drawn in the image. The exact submitted instruction is saved before the Send action. The existing request hash and Flow project binding are preserved.
- When a recorded image lacks its asset signature, recovery reads each eligible tile's visible **Reuse prompt** action and compares the full instruction to the saved instruction, allowing only whitespace/Unicode normalization. It never sends that reused prompt. It restores any unsent composer text after every read; failed restoration stops recovery.
- Legacy jobs reconstruct their original instruction only after the saved request hash and project binding pass the existing checks. A unique fresh legacy image retains the prior recovery behavior. Multiple candidates need exact prompt proof. If multiple candidates have the same verified instruction, one is selected by a deterministic content signature and proof is saved in the journal. Selection does not depend on tile order, truncated title, visual resemblance, or newest position. It establishes instruction equivalence, not a semantic quality guarantee.
- Explicitly labelled Flow gallery tiles can be detected below the previous 140-pixel cutoff. Unlabelled images retain the stricter size threshold. Flow ASB thumbnail size variants share identity only when their opaque content token is identical.
- Initial image detection waits briefly for a stable single candidate. Ambiguous candidates are handled through the saved request's prompt correlation.
- Gallery absence no longer triggers automatic replacement generation. Incomplete, delayed or virtualized galleries cannot prove an original request failed. Historical replacement reservations remain protected against resubmission.
- Native image-save target closure is classified as a browser recovery condition rather than an unexplained HTTP/blob fallback failure. v7.0.7 bounded transfer and validation remain in place.

## Upgrade and retry the existing job

Stop Studio and the current CLI run. Back up the installation. Update source files inside the existing installation folder and preserve outputs, data, .env, configuration, browser profiles and all request/recovery journals. Do not delete the two candidate images or manually edit signatures.

Restart Studio, or run in that existing folder:

```bash
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6
```

A successful prompt-correlated recovery logs `Verified ... image candidate(s) against the saved exact generation prompt; recovering without a new generation.` Cached validated images remain reusable. Resume is download-only for already-submitted requests; continuing the unfinished job can still submit its later planned generations under the saved credit policy.

## Practical limits

This build improves automatic recovery where Flow exposes a tile's original prompt. If Flow hides that action, edits or truncates the original prompt, loses the asset, closes the browser repeatedly, or rejects the generation, request ownership may remain unprovable. The tool preserves the job and reports the unresolved request; it cannot guarantee zero failures or unattended recovery in all third-party UI states. No live WSL/Google account or paid generation was used while developing this update.

## v7.0.8 validation

Full engine suite: 702 passed, with 12 existing dependency deprecation warnings. Private control-center checks: 27 passed, with syntax checks also passing. Recovery regressions cover exact-prompt selection among multiple candidates, equivalent same-instruction variants, rejection of partial matches and unavailable prompt UI, composer restoration, legacy-journal recovery without submission, and protection against replacement based on gallery absence. Playwright native-artifact tests exercise its actual sync bridge with controlled Download artifacts. The new Reuse prompt UI behavior is tested with controlled locator fixtures, not the user’s live Flow DOM. No Chromium/Google/WSL end-to-end generation was performed.

"""Keep one of the images a blocked Flow request already saved - locally, without touching Flow.

The failure this answers (v7.0.123), reported from a real job:

    ⚠️ shot_051 opening frame: Flow failed after 1 attempts → free fallback
    Cause: FlowRequestPending: Two or more real images are saved for shot_051_open.jpg.
    Recovery stopped without submitting or replacing; review the saved Flow project and choose
    which image to keep.

The app was right to stop: it cannot prove which of two generated images belongs to that frame, and guessing
would put the wrong picture in the video. But the images themselves are already downloaded as probe files next
to the frame, with their checksums recorded in the request journal - so *you* can look at them and pick one.
That is all this module does: it lists those saved candidates and commits the one you choose, using the same
``commit_capture`` the automatic path uses (checksum, reference exclusion, journal update). No browser opens, no
request is submitted, no Flow credit is spent, and the other candidate is left where it is.
"""
from __future__ import annotations

import json
from pathlib import Path

from .flow_image_transaction import commit_capture, journal_path
from .isolated_frame_regeneration import image_valid, sha


def _frames(job_dir) -> list[Path]:
    """Every frame with a request journal, in shot order.

    The frame file itself need not exist yet - a request that never finished has a journal and saved candidate
    images but no committed ``.jpg``, which is exactly the case this module exists for.
    """
    storyboard = Path(job_dir) / 'storyboard'
    if not storyboard.is_dir():
        return []
    suffix = '.flow-request.json'
    return sorted(Path(str(path)[:-len(suffix)]) for path in storyboard.glob('*.jpg' + suffix))


def _read(path: Path) -> dict:
    try:
        return json.loads(journal_path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def candidates(output) -> list[dict]:
    """The saved images for this frame that are not uploaded references, newest evidence first.

    Each row is one probe the journal already downloaded and checksummed. A row whose bytes no longer match the
    recorded checksum is reported as ``broken`` instead of being offered: a changed file is not the image the
    journal saw.
    """
    output = Path(output)
    request = _read(output)
    rows = []
    for entry in (request.get('capture_probes') or {}).values():
        if not isinstance(entry, dict) or entry.get('reference') or not entry.get('file'):
            continue
        probe = output.parent / str(entry['file'])
        exists = probe.is_file() and probe.parent == output.parent
        valid = bool(exists and image_valid(probe))
        matches = bool(valid and entry.get('sha256') and sha(probe) == entry['sha256'])
        rows.append({'file': str(entry['file']), 'path': str(probe), 'exists': exists,
                     'valid': valid, 'matches_recorded_checksum': matches,
                     'bytes': probe.stat().st_size if exists else 0,
                     'signature': str(entry.get('signature') or ''),
                     'state': str(entry.get('state') or ''),
                     'usable': bool(valid and matches)})
    rows.sort(key=lambda row: (not row['usable'], row['file']))
    return rows


def blocked_frames(job_dir) -> list[dict]:
    """Frames where recovery stopped because more than one real image is saved, plus their candidates."""
    found = []
    for output in _frames(job_dir):
        request = _read(output)
        if str(request.get('status') or '') == 'downloaded' and output.is_file() and image_valid(output):
            continue
        rows = candidates(output)
        usable = [row for row in rows if row['usable']]
        if len(usable) < 2:
            continue
        found.append({'image': output.name, 'path': str(output), 'shot': output.name.split('.')[0],
                      'project_url': str(request.get('project_url') or ''),
                      'prompt': str((request.get('prompt') or request.get('text') or ''))[:400],
                      'candidates': usable, 'count': len(usable)})
    return found


def all_frames(job_dir) -> list[dict]:
    """Every unfinished frame with at least one usable saved candidate, for a manual pick."""
    found = []
    for output in _frames(job_dir):
        request = _read(output)
        if str(request.get('status') or '') == 'downloaded' and output.is_file() and image_valid(output):
            continue
        usable = [row for row in candidates(output) if row['usable']]
        if not usable:
            continue
        found.append({'image': output.name, 'path': str(output), 'shot': output.name.split('.')[0],
                      'project_url': str(request.get('project_url') or ''),
                      'prompt': str((request.get('prompt') or request.get('text') or ''))[:400],
                      'candidates': usable, 'count': len(usable)})
    return found


def keep(job_dir, image: str, index: int) -> dict:
    """Commit the chosen saved image as this frame. ``index`` is the 0-based position in ``candidates``."""
    job_dir = Path(job_dir)
    output = job_dir / 'storyboard' / str(image)
    if not journal_path(output).is_file():
        raise ValueError('No saved frame with a request journal at ' + str(output))
    request = _read(output)
    if str(request.get('status') or '') == 'downloaded' and output.is_file() and image_valid(output):
        raise ValueError(output.name + ' is already saved as the frame; nothing was changed.')
    rows = candidates(output)
    if not rows:
        raise ValueError('No saved candidate images are recorded for ' + output.name
                         + ', so there is nothing to choose. Resume the job to ask Flow again.')
    try:
        chosen = rows[int(index)]
    except (IndexError, TypeError, ValueError):
        raise ValueError('Choose a candidate between 1 and ' + str(len(rows)) + ' for ' + output.name) from None
    if not chosen['usable']:
        raise ValueError('Candidate ' + chosen['file'] + ' is missing or no longer matches the checksum recorded '
                         'when it was saved, so it cannot be used. Nothing was changed.')
    commit_capture(output, request, chosen['path'], 'reviewed_candidate_choice')
    request['reviewed_choice'] = {'file': chosen['file'], 'sha256': sha(output)}
    journal_path(output).write_text(json.dumps(request, indent=2, ensure_ascii=False), encoding='utf-8')
    return {'image': output.name, 'kept': chosen['file'], 'probe': chosen['path'], 'path': str(output),
            'sha256': request['media_sha256'], 'candidates': len(rows),
            'note': 'Saved locally from an image Flow had already produced. No browser opened, no request '
                    'submitted, no Flow credit spent.'}

import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
import uuid
from urllib.error import HTTPError
from urllib.request import Request, urlopen

SPEC = importlib.util.spec_from_file_location('runner', Path(__file__).parents[1] / 'autovideo_runner.py')
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)
ORIGIN = 'https://private-control.example.test'

FAKE_CLI = '''
import sys,json,time
from pathlib import Path
args=sys.argv[2:];action=args[0]
with open('calls.jsonl','a') as h:h.write(json.dumps(args)+'\\n')
if action in ('create-config','clip-config'):
    c=json.loads(Path(args[1]).read_text())
    if action=='clip-config':
        p=Path(c['output']);p.mkdir(parents=True)
        (p/'highlights.json').write_text(json.dumps({'partial':True,'count':1}))
        print('Ranking source video...',flush=True);time.sleep(.2)
        print('Partial result: 1 of 3 clips',flush=True);sys.exit(0)
    p=Path('outputs/engine-test');(p/'logs').mkdir(parents=True)
    m={'topic':c['topic'],'aspect':'9:16' if c['production_mode']=='reels_pro' else '16:9','status':'created','preset':c.get('preset','cinematic_realism')}
    (p/'production_manifest.json').write_text(json.dumps(m));(p/'settings.json').write_text(json.dumps(c))
    print('JOB: engine-test',flush=True)
    if c.get('plan_only'):sys.exit(0)
    progress={'percent':41,'stage':'Flow visuals','elapsed':'00:18:42','ts':'2026-10-04T09:00:00+05:30'}
    (p/'logs/progress.json').write_text(json.dumps(progress))
    (p/'logs/runtime.log').write_text('[Flow] Completed 2 of 5 shots\\n')
    print('[Flow] Agent at capacity; waiting 300s; next attempt at 09:05:00',flush=True);time.sleep(.3)
    m['status']='paused';(p/'production_manifest.json').write_text(json.dumps(m))
    pause={'reason':'Download.save_as callback failed','kind':'flow_existing_video_recovery','shot_id':'shot_003','safe_automatic_recovery':True,'baseline_signatures':['saved-request'],'accepted_shots':2,'total_shots':5}
    (p/'pause_state.json').write_text(json.dumps(pause))
    print('PAUSED: download failed',flush=True);sys.exit(2)
if action=='export-delivery':
    folder=Path(args[args.index('--folder')+1]);folder.mkdir(parents=True,exist_ok=True)
    (folder/'review.upload.txt').write_text('REVIEW_REQUIRED: manual publication')
    print('Local delivery packet created; no publishing.',flush=True);sys.exit(0)
p=Path('outputs')/args[1]
if action=='recover-flow-video':
    pause=json.loads((p/'pause_state.json').read_text());pause['resolved']=True;(p/'pause_state.json').write_text(json.dumps(pause))
    print('Existing media matched and downloaded. No generation submitted.',flush=True);time.sleep(.05);sys.exit(0)
if action=='resume':
    time.sleep(.05)
    m=json.loads((p/'production_manifest.json').read_text());m['status']='done';(p/'production_manifest.json').write_text(json.dumps(m))
    pause=json.loads((p/'pause_state.json').read_text()) if (p/'pause_state.json').exists() else {};pause['resolved']=True;(p/'pause_state.json').write_text(json.dumps(pause))
    (p/'logs/progress.json').write_text(json.dumps({'percent':100,'stage':'Complete','elapsed':'00:20:00'}))
    print('Render complete',flush=True)
'''

def config(mode='youtube',plan=False):
    return {'topic':'5 habits for success','production_mode':'reels_pro' if mode=='reels' else 'youtube_pro','video_type':'shorts' if mode=='reels' else 'faceless_youtube','theme':'cartoon_story' if mode=='cartoon' else 'motivational','duration':45 if mode=='reels' else 300,'profile':'STORYBOARD_ECONOMY','flow_scenes':3,'max_credits':25,'max_generation_credits':10,'flow_image_workers':1,'flow_project_url':'https://flow.google.com/project/verified','plan_only':plan}

class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        (self.root/'cli.py').write_text(FAKE_CLI)
        (self.root/'VERSION').write_text('5.8.4')
        (self.root/'engine').mkdir()
        defaults={k:None for k in runner.VIDEO_KEYS}
        (self.root/'engine/studio_config.py').write_text('DEFAULTS = '+repr(defaults))
        self.controller=runner.Controller(self.root)
        self.server=runner.RunnerHTTPServer(('127.0.0.1',0),runner.handler(self.controller,ORIGIN,'test-token'))
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.url='http://127.0.0.1:'+str(self.server.server_address[1])

    def tearDown(self):
        self.wait_done()
        self.server.shutdown();self.server.server_close();self.temp.cleanup()

    def request(self,path,body=None,token='test-token',origin=ORIGIN,method=None):
        if body is not None:
            body={**body,'request_id':body.get('request_id',str(uuid.uuid4()))}
        headers={'Origin':origin,'Authorization':'Bearer '+token,'Content-Type':'application/json'}
        req=Request(self.url+path,data=json.dumps(body).encode() if body is not None else None,headers=headers,method=method)
        try:
            with urlopen(req,timeout=3) as r:return r.status,json.load(r)
        except HTTPError as e:return e.code,json.load(e)

    def start(self,mode='youtube',plan=False):
        status,result=self.request('/api/jobs',{'mode':mode,'config':config(mode,plan),'approved':True});self.assertEqual(status,202,result);return result['id']

    def wait_done(self):
        end=time.time()+4
        while self.controller.active and time.time()<end:time.sleep(.01)
        self.assertIsNone(self.controller.active)

    def test_access_requires_token_origin_and_explicit_approval(self):
        self.assertEqual(self.request('/api/health',token='wrong')[0],401)
        self.assertEqual(self.request('/api/health',origin='https://evil.test')[0],403)
        self.assertEqual(self.request('/api/health')[1]['version'],'5.8.4')
        self.assertEqual(self.request('/api/jobs',{'mode':'youtube','config':config()})[0],400)
        self.assertEqual(self.controller.records,{})
        status,_=self.request('/api/jobs',{'mode':'youtube','config':{**config(),'duration':0},'approved':True});self.assertEqual(status,400)

    def test_start_live_progress_capacity_pause_recovery_and_resume(self):
        rid=self.start()
        status,_=self.request('/api/jobs',{'mode':'youtube','config':config(),'approved':True});self.assertEqual(status,409)
        end=time.time()+2;found=None
        while time.time()<end:
            found=self.request('/api/jobs/'+rid)[1]
            if found['status']=='waiting':break
            time.sleep(.01)
        self.assertEqual(found['status'],'waiting');self.assertEqual(found['percent'],41);self.assertIn('capacity',found['info'])
        self.wait_done();detail=self.request('/api/jobs/'+rid)[1]
        self.assertEqual(detail['status'],'paused');self.assertEqual(detail['engine_id'],'engine-test');self.assertIn('callback',detail['pause']['reason']);self.assertTrue(detail['logs'])
        self.assertNotIn('baseline_signatures',detail['pause'])
        status,_=self.request('/api/jobs/'+rid+'/recover',{'approved':True});self.assertEqual(status,202)
        self.wait_done();self.assertTrue(self.request('/api/jobs/'+rid)[1]['pause']['resolved'])
        calls=[json.loads(x) for x in (self.root/'calls.jsonl').read_text().splitlines()]
        self.assertEqual(calls[1][0],'recover-flow-video');self.assertNotIn('--allow-latest',calls[1]);self.assertIn('shot_003',calls[1]);self.assertEqual(len(calls),2)
        status,_=self.request('/api/jobs/'+rid+'/resume',{'approved':True});self.assertEqual(status,202)
        self.wait_done();detail=self.request('/api/jobs/'+rid)[1];self.assertEqual(detail['status'],'completed');self.assertEqual(detail['percent'],100)
        self.assertEqual(self.request('/api/jobs/'+rid+'/resume',{'approved':True})[0],400)
        self.assertEqual(len(self.request('/api/jobs')[1]['jobs']),1)

    def test_existing_jobs_import_without_creating_or_mutating_a_job(self):
        p=self.root/'outputs/existing-1';p.mkdir(parents=True)
        (p/'production_manifest.json').write_text(json.dumps({'topic':'Existing reel','aspect':'9:16','status':'created'}))
        jobs=self.request('/api/jobs')[1]['jobs'];self.assertEqual(jobs[0]['mode'],'reels');self.assertEqual(jobs[0]['status'],'planned');self.assertFalse((self.root/'calls.jsonl').exists())
        self.assertEqual(self.request('/api/jobs/..%2F..%2Fetc')[0],404)

    def test_no_baseline_cannot_trigger_video_recovery(self):
        rid=self.start();self.wait_done();p=self.root/'outputs/engine-test/pause_state.json';pause=json.loads(p.read_text());pause['safe_automatic_recovery']=False;p.write_text(json.dumps(pause))
        self.assertEqual(self.request('/api/jobs/'+rid+'/recover',{'approved':True})[0],400)
        self.assertEqual(len((self.root/'calls.jsonl').read_text().splitlines()),1)

    def test_plan_only_and_reels_mapping(self):
        rid=self.start('reels',True);self.wait_done();detail=self.request('/api/jobs/'+rid)[1]
        self.assertEqual(detail['status'],'planned');self.assertIsNone(detail['percent']);self.assertEqual(detail['config']['production_mode'],'reels_pro')

    def test_clips_keep_chats_fresh_output_and_truthful_unknown_progress(self):
        c={'input':'/mnt/c/owned.mp4','count':3,'min_seconds':25,'max_seconds':55,'source_rights':'own_content','framing':'face-crop','ranking_provider':'gemini-web-hybrid','caption_provider':'groq'}
        status,result=self.request('/api/jobs',{'mode':'clip','config':c,'approved':True});self.assertEqual(status,202,result);rid=result['id']
        self.assertIsNone(self.request('/api/jobs/'+rid)[1]['percent']);self.wait_done()
        payload=json.loads((self.root/'.autovideo-control'/f'{rid}.json').read_text());self.assertEqual(payload['source'],c['input']);self.assertEqual(payload['gemini_chat_cleanup'],'keep');self.assertIn(rid,payload['output'])
        self.assertEqual(self.request('/api/jobs/'+rid+'/resume',{'approved':True})[0],400)
        self.assertEqual(self.request('/api/jobs/'+rid)[1]['status'],'completed')

    def test_restart_marks_unfinished_job_and_log_redaction(self):
        self.controller.records['old']={'id':'old','status':'running','mode':'clip'};self.controller.save();loaded=runner.Controller(self.root);self.assertEqual(loaded.records['old']['status'],'interrupted')
        self.assertNotIn('secret',runner.redact('api_key=secret Bearer secret token=secret&ok=1'))

    def test_retry_of_the_same_approved_request_does_not_create_another_job(self):
        body={'mode':'youtube','config':config(),'approved':True,'request_id':str(uuid.uuid4())}
        status,first=self.request('/api/jobs',body);self.assertEqual(status,202)
        status,second=self.request('/api/jobs',body);self.assertEqual(status,202);self.assertEqual(first['id'],second['id']);self.assertTrue(second['deduplicated'])
        self.wait_done();status,third=self.request('/api/jobs',body);self.assertEqual(status,202);self.assertEqual(first['id'],third['id']);self.assertEqual(len((self.root/'calls.jsonl').read_text().splitlines()),1)
        self.assertEqual(self.request('/api/jobs',{**body,'config':{**config(),'topic':'Changed'}})[0],400)

    def test_recovery_exit_zero_does_not_override_failed_quality_checks(self):
        rid=self.start();self.wait_done()
        self.controller.records[rid].update(last_action='recover',exit_code=0,status='finished')
        detail=self.controller.detail(rid)
        self.assertFalse(detail['pause'].get('resolved',False))
        self.assertEqual(detail['status'],'paused')
        self.assertIn('quality checks',detail['stage'])
        self.assertIn('did not accept',detail['error'])

    def test_reviewed_editor_recovery_requires_approval_and_same_project(self):
        rid=self.start();self.wait_done()
        path=self.root/'outputs/engine-test/pause_state.json';pause=json.loads(path.read_text())
        project='https://flow.google.com/project/verified';pause['flow_project_url']=project;path.write_text(json.dumps(pause))
        options={'asset_url':project+'/edit/exact-video','asset_reviewed':True}
        endpoint='/api/jobs/'+rid+'/recover'
        self.assertEqual(self.request(endpoint,{'options':options})[0],400)
        self.assertEqual(self.request(endpoint,{'options':{**options,'asset_reviewed':False},'approved':True})[0],400)
        self.assertEqual(self.request(endpoint,{'options':{**options,'asset_url':'https://flow.google.com/project/other/edit/video'},'approved':True})[0],400)
        self.assertEqual(self.request(endpoint,{'options':options,'approved':True})[0],202);self.wait_done()
        call=json.loads((self.root/'calls.jsonl').read_text().splitlines()[-1])
        self.assertIn('--asset-reviewed',call);self.assertEqual(call[call.index('--asset-url')+1],options['asset_url'])
        self.assertEqual(call[0],'recover-flow-video')

    def test_v7_paths_resolve_against_engine_and_language_is_validated(self):
        voice=self.root/'native.wav';voice.write_bytes(b'owned audio fixture')
        c={**config(), 'language':'or','tts_provider':'edge','narration_input_path':'native.wav',
           'voiceover_enabled':True,'text_cards_enabled':False,'caption_display':'none','flow_pause_on_unresolved_request':True}
        status,result=self.request('/api/jobs',{'mode':'youtube','config':c,'approved':True})
        self.assertEqual(status,202,result);self.wait_done()
        payload=json.loads((self.root/'.autovideo-control'/f"{result['id']}.json").read_text())
        self.assertEqual(payload['narration_input_path'],str(voice))
        self.assertFalse(payload['text_cards_enabled'])
        self.assertRaisesRegex(ValueError,'Odia',runner.validate,'youtube',{**c,'narration_input_path':''})
        self.assertRaisesRegex(ValueError,'voiceover_enabled',runner.validate,'youtube',{**c,'voiceover_enabled':'false'})

    def test_delivery_is_explicit_local_and_uses_only_job_outputs(self):
        rid=self.start();self.wait_done()
        output=self.root/'outputs/engine-test/render';output.mkdir();video=output/'final.mp4';video.write_bytes(b'fixture')
        options={'index':0,'destination':'instagram_reel','framing':'fit','title':'Reviewed title'}
        self.assertEqual(self.request('/api/jobs/'+rid+'/delivery',{'options':options})[0],400)
        self.assertEqual(self.request('/api/jobs/'+rid+'/delivery',{'options':{**options,'source':'/etc/passwd'},'approved':True})[0],400)
        status,result=self.request('/api/jobs/'+rid+'/delivery',{'options':options,'approved':True});self.assertEqual(status,202,result);self.wait_done()
        call=json.loads((self.root/'calls.jsonl').read_text().splitlines()[-1])
        self.assertEqual(call[:2],['export-delivery',str(video)])
        self.assertTrue(self.controller.detail(rid)['delivery_paths'])
        self.assertNotIn('publish',call)

    def test_mini_reels_require_separate_brief_and_flow_requests_and_recover_journal(self):
        adapter=self.root/'tools';adapter.mkdir()
        (adapter/'control_center_adapter.py').write_text('''
import json,sys
from pathlib import Path
operation,path=sys.argv[1:];p=Path(path);payload=json.loads(p.read_text())
with open('mini-calls.jsonl','a') as h:h.write(json.dumps(operation)+'\\n')
if operation=='mini-brief':
    result={'brief':{'video_prompt':'Original garden','prompt_provider':'gemini-web'},'flow_prompt':'Reviewed original garden'}
else:
    rid=payload['reel_id'];folder=Path('outputs/mini_reels')/rid;folder.mkdir(parents=True,exist_ok=True)
    journal=folder/'mini-reel.mp4.flow-request.json'
    if operation=='mini-generate':
        journal.write_text('{"status":"pending"}')
        (folder/'mini_reel.json').write_text(json.dumps({'status':'flow_request_pending','error':'Flow capacity; saved request pending'}))
        sys.exit(1)
    assert journal.exists()
    result={'status':'complete'}
    (folder/'mini_reel.json').write_text(json.dumps(result));(folder/'mini-reel.mp4').write_bytes(b'fixture')
Path(str(p)+'.result.json').write_text(json.dumps(result))
''')
        c={'idea':'Tiny garden','language':'hi','visual_style':'miniature-diorama','audio_mode':'silent','category':'general','model':'veo_fast','flow_project_url':'','max_generation_credits':4,'flow_capacity_wait_seconds':0,'flow_capacity_retries':0,'flow_video_recovery_wait_seconds':5}
        status,result=self.request('/api/jobs',{'mode':'mini','config':c,'approved':True});self.assertEqual(status,202,result);rid=result['id'];self.wait_done()
        detail=self.controller.detail(rid);self.assertEqual(detail['status'],'brief');self.assertIn('review',detail['stage'])
        self.assertEqual((self.root/'mini-calls.jsonl').read_text().splitlines(),['"mini-brief"'])
        generation={**c,'brief_id':rid,'flow_prompt':detail['flow_prompt']}
        self.assertEqual(self.request('/api/jobs',{'mode':'mini','config':{**generation,'language':'en'},'approved':True})[0],400)
        status,_=self.request('/api/jobs',{'mode':'mini','config':generation,'approved':True});self.assertEqual(status,202);self.wait_done()
        detail=self.controller.detail(rid);self.assertEqual(detail['status'],'paused');self.assertTrue(detail['pause']['safe_automatic_recovery'])
        self.assertEqual(self.request('/api/jobs/'+rid+'/resume',{'approved':True})[0],400)
        self.assertEqual(self.request('/api/jobs/'+rid+'/recover',{'approved':True})[0],202);self.wait_done()
        detail=self.controller.detail(rid);self.assertEqual(detail['status'],'completed');self.assertEqual(detail['percent'],100);self.assertTrue(detail['output_paths'])
        self.assertEqual((self.root/'mini-calls.jsonl').read_text().splitlines(),['"mini-brief"','"mini-generate"','"mini-recover"'])

if __name__=='__main__':unittest.main()

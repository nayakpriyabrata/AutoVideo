# Educational points series and AI-drafted cards (7.0.75)

Follows 7.0.74. Changed on request: the list is no longer fixed at five points,
and each point is covered while the narration reaches it, across the whole video.

## Who gets it

Only **educational** videos: content type `education`, and a preset that is not a
story preset. Presets containing `story`, `cartoon`, `kids`, `fairy` or `animation`
are excluded (for example `cartoon_story` and `cinematic_story`). Story and
cartoon videos keep their current cards. Educational videos with the default
`cinematic_realism` preset do get the cards.

## What appears on screen

- **Points series.** 2–8 points, in spoken order. The panel opens when the first
  point starts, highlights the point being covered (soft bar, accent colour), moves
  to the next point when the narration moves on, and closes after the last point.
  Each point is shown for the time it is spoken. The font shrinks as needed so up to
  eight points fit; a list that cannot fit at a readable size fails with a clear message.
- **Single-point cards** (`takeaway`, `tip`, `warning`), at most four, and only
  before the first point or after the last point. Cards that would overlap the series
  are dropped and counted in `speech_cards.json` as `dropped_overlapping_cards`.

## Who writes the copy

The card draft uses the **drafting model chosen in Create** (the "Drafting model"
selector): Gemini Web (default), ChatGPT Web, ChatGPT/OpenAI API, Indus AI, Gemini
API, Groq, Grok or Ollama. The choice is saved with the job as `card_draft_provider`.
The prompt includes the video topic, so copy stays on the topic. Only facts stated in
the narration are allowed.

## Validation rules (checked before rendering)

- 2–8 points; each point at most 60 characters; series title at most 60.
- Points must not overlap and must be in spoken order.
- Coverage: the first point starts within the first quarter of the narration, and the
  last point ends after 70% of it.
- Single cards: 1.5–6 seconds, at most 80 characters, takeaway/tip/warning only.

## Animation

- The series panel opens once (scale-in with fade), then stays while the highlight
  moves, and closes once (shrink with fade).
- Single cards pop open and closed.
- The FFmpeg renderer supports `open`, `close` and `pop` modes. Middle segments of the
  series carry no animation, so the highlight changes without the panel re-animating.

## Not in this release

- Language editions still use the 7.0.73 card path. Educational series are not
  applied to edition copies yet.
- The narration script itself is not rewritten by this change. Only the on-screen copy
  is drafted by the chosen provider.
- A real AI draft and a full render on the user's footage still need the user's test.

## Install

From 7.0.74: `python3 ../AutoVideoAI-v7.0.75/tools/update_v774_to_v775.py .` (dry run),
then with `--apply`. Stop the dashboard first.

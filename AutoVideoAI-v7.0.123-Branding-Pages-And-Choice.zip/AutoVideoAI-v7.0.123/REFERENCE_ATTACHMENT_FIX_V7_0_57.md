# Reference attachment fix — 7.0.57

Fixes the reported timeout while selecting an uploaded, exact-name reference in Flow. Selection now scopes to the visible picker, skips hidden duplicate titles, and retries transient Playwright click timeouts within the existing bounded window. A verified composer reference is still required before success. It does not bypass approvals or submit replacement generations on an uncertain request.

Includes the 7.0.56 QC retry identity fix and earlier B-roll placement protections.

## Install over 7.0.56
Stop Studio and all production/resume processes first. Extract this build beside your installation. From your existing AutoVideoAI-v7 directory run:

```bash
python3 ../AutoVideoAI-v7.0.57/tools/update_v756_to_v757.py . --apply
```

The updater checks source hashes and existing code, backs up changed code, and preserves runtime outputs, configuration and browser profiles. Unexpected local code modifications cause a refusal rather than an overwrite.

## Keep the existing reviewed shot
The supplied diagnostics show shot_001 downloaded successfully but received QC REVIEW (64.2), not automatic acceptance. Confirming identity alone does not mean its visual quality is acceptable. If you have played it and want to keep it, while production is stopped run:

```bash
python3 cli.py v3 associate 20261017-113230-discipline-beats-motivat-2c5d shot_001 outputs/20261017-113230-discipline-beats-motivat-2c5d/flow/shots/shot_001/take_01.mp4
```

This local import runs QC and accepts ACCEPT/REVIEW results; a REJECT result remains failed. It makes no Flow request. After successful acceptance:

```bash
python3 cli.py v3 resume 20261017-113230-discipline-beats-motivat-2c5d
```

Resume can generate the remaining shot_009 and use credits. Do not delete request journals or manually rename files to accepted.mp4. If the original clip quality is unsatisfactory, do not associate it.

## Validation and limits
72 focused regression tests passed, including six new picker tests covering transient and persistent timeouts, hidden duplicates, picker scoping and attachment verification. The code-only updater was checked against an extracted 7.0.56 build with a runtime sentinel. Live signed-in Flow execution was not available; this is a targeted fix, not a guarantee against future Flow UI changes or all download failures.

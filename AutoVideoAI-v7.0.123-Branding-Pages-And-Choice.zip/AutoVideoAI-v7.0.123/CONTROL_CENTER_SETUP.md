# AutoVideoAI Control Center

This private Site configures and monitors your existing WSL2 AutoVideoAI engine.
It hosts the control interface and a reviewed source download. Your signed-in browser, API keys, job execution and videos stay on your PC.
Commands go from your browser directly to an authenticated loopback runner on the
same computer. Use the private Site from your Windows browser on that PC.
Open the deployed URL directly in Chrome so local-network permission can apply;
an embedded preview may have a stricter permissions policy.

## First connection

1. Download the reviewed `AutoVideoAI-v7.0.2-Reviewed.zip` from the Site and extract it into a fresh folder. Read `CONTROL_CENTER_REVIEW.md`. Keep the old installation as a backup; preserve existing outputs, local configuration and browser profiles when moving your workflow. Never overwrite a running installation. The ZIP includes `autovideo_runner.py` and `tools/control_center_adapter.py`.
2. Open that folder in WSL. Activate the same Python environment used by
   AutoVideoAI. Python 3.10+ is required; the runner adds no Python dependencies.
3. Stop other Studio/CLI jobs. Copy and run the exact setup command shown in the
   Site. It includes your deployed Site's origin:

   ```bash
   python3 autovideo_runner.py --root . --origin https://autovideoai-control.priyabrata-ericsson.chatgpt.site
   ```

4. Keep the terminal open. Paste the printed connection token into Connection
   settings, keep the address `http://127.0.0.1:8765`, and click Connect runner.
   Allow local-network access if the browser asks. The runner serves only the
   configured origin, requires a random token, and binds to loopback.
5. The Site loads existing video jobs from `outputs/*/production_manifest.json`.

The token is kept only in the current tab's memory, never browser storage, source
code, or the hosted Site. Reconnect after a page reload or runner restart.
Drafts are saved in this browser; engine jobs and outputs remain on disk in WSL.

## Configure and start

Choose YouTube, Reels, Cartoon, Clips, or Mini Reel. Pick a topic/source, length, providers,
scene count and credit limits. Save a draft or select Start job. Review the
summary and explicitly approve the command. No command runs on page load,
connection, draft save, or an example interaction.

- YouTube uses `youtube_pro`, 16:9, and a default 300-second duration.
- Reels use the engine's `reels_pro` configuration with 9:16 and full captions.
- Cartoons use the existing cartoon theme and preset. This adds no animation
  rigs, guaranteed character consistency, or new cartoon engine.
- Clips use `clip-config`, face-crop or fit, a rights declaration and highlight
  ranking. Each run receives a fresh local output folder. Partial selections
  remain valid; the engine may return fewer clips than requested.
- English, Hindi and Odia are available for video jobs. Odia requires Gemini TTS or imported native narration; it uses script-timed captions. English/Hindi clips use verified transcription routes.
- Voiceover, text cards, captions, effects, ambience and music can be selected independently. Approved plan JSON, narration and music paths resolve relative to the engine folder.
- Script-timed captions are available for videos. Clips support auto, Groq, and
  local timing. Your existing provider/model/environment configuration applies.
- Plan only creates a saved video job without generation. Resume later to run it.
- New video jobs keep Gemini chats unless you explicitly select cleanup. Clip
  jobs keep chats. Existing resumes preserve their already-saved cleanup policy.
- Video retry count is 0. Scene counts remain subject to engine budget/routing.
  Total Flow credit limits do not cap separate API-provider charges.

## Monitor and recover

Progress is read from `logs/progress.json`; it is not fabricated from a timer.
The Site polls the local runner every second. Video runtime logs survive resume.
CLI stdout is included to expose startup and provider failures. Clip percentage
is unavailable when the engine does not report it; logs still update.

- Capacity: wait/retry limits come from your configuration. The panel exposes
  engine wait messages and pause reasons. Usage limits are shown separately.
- Closed Flow page: preserve the saved project; review the pause state.
- Missing/unmatched media: preserve request journals and diagnostics. The
  control center never picks an arbitrary newest tile or uses `--allow-latest`.
- Download failure: Recover existing media uses `recover-flow-video` only when
  an unresolved saved video request journal or legacy baseline is present. It requests no new generation.
  The engine must mark the media resolved and accepted before you separately choose Resume. A zero exit status alone does not imply QC acceptance.
- Resume runs `v3 resume ENGINE-JOB-ID` using saved settings. Editing the new-job
  form does not change an existing job. Resume can continue credit-consuming work.
- Interrupted clips do not support full resume in v7.0.2. Reprocess as a fresh
  clip job; the previous clip output folder stays intact.

Only one engine command runs at a time. Do not run Studio/CLI alongside the
control center on the same installation. The runner refuses another command
when it observes an active engine process. It does not kill an existing job.
Repeated delivery of the same approved request reuses its result instead of
starting a duplicate command, including after that command has finished.
Closing the browser tab leaves the local CLI running. Keep the runner terminal
open; Ctrl+C interrupts its active CLI. Check browser/provider subprocesses
before restarting after an interrupted terminal session.

## Connection troubleshooting

- Open the Site on the same PC running WSL. A phone cannot use your PC's localhost.
- Confirm the terminal is running and copy its latest token.
- Confirm `--origin` matches the Site origin exactly, with no route/path.
- Check browser local-network permission if fetch is blocked. Keep the address
  loopback; do not expose the runner to your LAN or a public tunnel.
- Chrome's permission behavior is described in its official
  [Local Network Access guide](https://developer.chrome.com/blog/local-network-access).
- If WSL localhost forwarding fails, restart WSL and check its localhost
  forwarding setting. This Site does not change Windows/WSL/network settings.
- A changed Site domain requires restarting the runner with the new origin.
- A missing provider key, Flow login, installed dependency or engine failure is
  shown in the logs. Configure those using your existing engine setup.

Tested integration contract: AutoVideoAI 7.0.2. New-job options are checked against
the installed engine's accepted configuration keys before a video command runs.
Google Flow UI behavior and provider quotas require live validation on your PC.
This control center makes failures visible; it does not fix Google's capacity
or certify generation/download reliability. It has no social publishing action.

## Files created by the runner

The runner creates `.autovideo-control/` inside the selected engine directory for
its local job index, approved-request receipts, JSON configurations (valid YAML),
stdout logs and lock.
It reads existing engine progress, settings, pause state and manifests. Approved
CLI commands create/update normal engine outputs. It never patches engine source
or reads `.env` for upload. Treat logs and local configurations as private data.

## Mini Reels and delivery

Mini Reels use the engine’s Gemini Web brief and Flow generation journal. First approve a Gemini brief request; this does not generate a video. Select **Review Gemini brief**, edit the prompt, then separately approve **Generate Flow Reel**. Changing idea, language, style, category or audio requires a fresh brief. Credit/capacity settings are saved. Pending requests offer exact recovery, not Resume or a replacement prompt. Flow native speech, pronunciation and silence are best effort: review the actual audio.

**Prepare delivery packet** selects one of the job’s local MP4s, a destination recipe, framing and title. Review and approve the export. The engine preserves the original, encodes a local destination copy, and writes REVIEW_REQUIRED metadata and a manual upload packet under `.autovideo-control/delivery/`. It never publishes to YouTube, Instagram or Facebook. Rich post metadata and the remaining v7 tools are available in the local Studio.

## Review coverage

The supplied 601-test engine suite passed here with FFmpeg. Additional regression cases cover invalid settings, import errors, metadata formatting, zero capacity limits, Mini Reel recovery and runner approvals. The Site’s DOM interaction and loopback HTTP tests pass with mocked providers. Browser layout, Windows-to-WSL permission behavior and real signed-in Gemini/Flow generation have not been exercised in this environment.

## v7.0.2 reviewed video recovery

If exact fingerprint recovery fails, verify the intended clip in the saved Flow project, copy its /edit/ URL, and use reviewed recovery. The approval summary requires confirmation that the clip belongs to the pending shot. It selects Original size and downloads without submitting a new generation. Resume separately after QC acceptance. See FLOW_RECOVERY_V7_0_2.md for the recovery procedure and verification limits.

# Educational text cards (7.0.74)

Applies only when a video's content type is **education** (the default type,
also used by cooking, health, self-care, business and farming presets). Other
video types keep the 7.0.73 cards exactly as before.

## What changed

- **Five-point box.** Gemini Web can return a `points` card: a title and 3–5 short
  points (each at most 60 characters), anchored to the spoken list. It lasts 6–14
  seconds. The box is a translucent panel with numbered rows.
- **Single-point cards.** Three new kinds, each with a glyph badge:
  - `takeaway` (star, "KEY IDEA")
  - `tip` (check, "TRY THIS")
  - `warning` (triangle, "AVOID THIS")
  Each is one line of at most 80 characters and lasts 2–6 seconds.
- **Open and close animation.** Educational cards and list panels pop open (scale
  70% → 100%, eased, with a fade-in) and close (shrink to 80% with a fade-out). The
  animation is applied in the FFmpeg overlay graph, so it works in normal and
  bounded renders. Other video types are not animated.
- **Playful look.** For educational videos with card style set to *auto*, cards use
  the playful palette. An explicit card style is respected.
- **Structured list graphics.** `production/graphics.json` list events also pop in
  educational videos.

## Content rules (Gemini Web)

- Only facts stated in the narration. No invented facts, statistics or numbers.
- Kinds: `takeaway`, `tip`, `warning`, `points`. Any other kind is rejected.
- Non-educational videos ignore `kind` and `points`. Their drafts stay plain keypoint cards.

## Compatibility

- The speech-card fingerprint includes a variant tag for educational drafts.
  Non-educational fingerprints are unchanged, so existing drafts stay valid.
  An educational render refuses a non-educational draft, and the reverse, until the
  drafting step is run again.
- Language editions still use their own card path from 7.0.73. Educational
  cards are not applied to edition copies in this release.
- Speech cards remain opt-in (the Create option "Use speech-timed Gemini cards").

## Verification

- `tests/test_v774_educational_cards.py`: validation, both orientations, transparent
  panel, the pop animation rendered through FFmpeg (area measured at 0.5, 1.12, 2.5,
  3.9 and 4.6 seconds), prompt selection, fingerprints, and structured list gating.
- Targeted suites that touch cards and audio pass, except the 10 typography and
  finishing failures already present on 7.0.73 and the ffprobe-dependent test in the
  sandbox.

## Install

From 7.0.73: `python3 ../AutoVideoAI-v7.0.74/tools/update_v773_to_v774.py .` (dry
run), then the same with `--apply`. Stop the dashboard first. Installs on 7.0.70 run
`update_v770_to_v771.py`, `update_v771_to_v772.py`, `update_v772_to_v773.py`, then
this one.

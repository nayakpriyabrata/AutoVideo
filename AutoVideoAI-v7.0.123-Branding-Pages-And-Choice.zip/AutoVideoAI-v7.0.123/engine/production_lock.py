"""Serialize browser production across tabs and installations without losing jobs."""
from contextlib import contextmanager
from pathlib import Path
import os
import time
import functools
import inspect


def serialize_clip_production(function):
    """Make local clip production visible to cross-process storage cleanup."""
    signature = inspect.signature(function)
    @functools.wraps(function)
    def wrapped(*args, **kwargs):
        arguments = signature.bind(*args, **kwargs)
        with production_slot(arguments.arguments['output_dir']):
            return function(*args, **kwargs)
    return wrapped


def acquire(handle, *, blocking=True):
    if os.name!='nt':
        import fcntl
        fcntl.flock(handle,fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
    else:
        import msvcrt
        handle.seek(0);handle.write(b'0');handle.flush()
        while True:
            handle.seek(0)
            try:msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1);return
            except OSError:
                if not blocking:raise BlockingIOError('Locked')
                time.sleep(.2)


def release(handle):
    if os.name!='nt':
        import fcntl
        fcntl.flock(handle,fcntl.LOCK_UN)
    else:
        import msvcrt
        handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)


@contextmanager
def production_slot(job_directory):
    root=Path.home()/'.local/share/autovideoai';root.mkdir(parents=True,exist_ok=True)
    job=Path(job_directory);job.mkdir(parents=True,exist_ok=True)
    with open(job/'.production.lock','a+b') as job_lock:
        try:acquire(job_lock,blocking=False)
        except BlockingIOError:raise RuntimeError('This job is already running in another tab or process. Open Queue to watch it.')
        try:
            from .progress import JobProgress
            JobProgress(str(job)).emit('Waiting for production slot',0,'Other tabs may monitor this job; browser production is serialized.')
            with open(root/'production.lock','a+b') as global_lock:
                acquire(global_lock)
                try:yield
                finally:release(global_lock)
        finally:release(job_lock)

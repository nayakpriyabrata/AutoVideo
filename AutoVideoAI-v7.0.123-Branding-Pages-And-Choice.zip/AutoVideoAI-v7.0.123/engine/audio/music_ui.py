"""Shared music import and selection controls for Studio and Music Video."""
from pathlib import Path


def library_panel(st,key,theme):
    from .music_library import import_track,list_tracks,root,select_theme
    folder=root()
    st.caption('Shared music folder: '+str(folder)+' · Choose a reviewed track or import one for future jobs.')
    upload=st.file_uploader('Upload a downloaded MP3/WAV/OGG/M4A/FLAC',type=['mp3','wav','ogg','m4a','flac'],key=key+'-file')
    title=st.text_input('Track title',key=key+'-title')
    tags=st.text_input('Theme tags (for example: motivation cinematic)',key=key+'-tags')
    source=st.text_input('Exact source or license page URL',key=key+'-url')
    license_label=st.text_input('Exact license or permission label',key=key+'-license')
    rights=st.checkbox('I checked this track’s rights for my intended platforms',key=key+'-rights')
    if st.button('Save track in shared library',key=key+'-import',disabled=not(upload and rights)):
        try:
            row=import_track(upload.getvalue(),upload.name,title,tags,source,license_label,folder)
            st.session_state[key+'-selected']=row['path'];st.success('Validated and saved: '+row['title'])
        except Exception as error:st.error(str(error))
    rows=list_tracks(folder)
    if not rows:
        st.caption('No reviewed music has been imported yet.')
        return ''
    suggested=select_theme(theme,folder)
    options=['Automatic theme match']+[r['path'] for r in rows]
    selected=st.selectbox('Music for this job',options,key=key+'-choice',
        format_func=lambda value:'Automatic theme match'+(' · '+suggested['title'] if suggested else ' · no match') if value==options[0]
            else next(r['title']+' · '+r['license'] for r in rows if r['path']==value))
    chosen=(suggested['path'] if suggested else '') if selected==options[0] else selected
    if chosen:
        st.audio(chosen)
        st.caption('Selected: '+Path(chosen).name+' · rights evidence is recorded in the shared manifest.')
    return chosen

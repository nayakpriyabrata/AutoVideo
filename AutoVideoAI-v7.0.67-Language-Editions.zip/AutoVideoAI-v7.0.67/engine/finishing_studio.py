"""Review-gated, non-destructive finishing of existing videos and clips.

The plan is durable. Source and optional assets are snapshotted before rendering;
no Flow generation, social upload, or browser action occurs here.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
import uuid

LANGUAGES = {'en': 'English', 'hi': 'Hindi', 'or': 'Odia'}
MEDIA_EXT = {'.mp4', '.mov', '.mkv', '.webm', '.mp3', '.wav', '.m4a', '.ogg', '.flac', '.png', '.jpg', '.jpeg', '.webp'}


def shared_root():
    return Path(os.getenv('AUTOVIDEO_SHARED_ROOT') or Path('outputs').resolve().parent).expanduser().resolve()


def _hash(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def _probe(path):
    p = subprocess.run(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(path)], capture_output=True, text=True, timeout=30)
    if p.returncode:
        raise ValueError('Media is not readable: ' + str(path))
    info = json.loads(p.stdout)
    return info, float(info.get('format', {}).get('duration') or 0)


def _snapshot(path, folder, kind):
    path = Path(path).expanduser().resolve(strict=True)
    if not path.is_file() or path.is_symlink() or path.suffix.lower() not in MEDIA_EXT or not path.stat().st_size:
        raise ValueError('Invalid ' + kind + ' file')
    if kind.startswith('logo'):
        from PIL import Image
        with Image.open(path) as img: img.verify()
        info, duration = {}, 0
    else:
        info, duration = _probe(path)
    wanted = ('audio' if kind.startswith(('narration', 'music', 'shared-music'))
              else 'video' if kind.startswith(('source', 'intro', 'outro')) else None)
    if wanted and (not any(s.get('codec_type') == wanted for s in info.get('streams', [])) or duration <= 0):
        raise ValueError(kind + ' needs playable ' + wanted)
    sha = _hash(path)
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    dest = folder / (kind + '-' + sha[:20] + path.suffix.lower())
    if not dest.exists():
        tmp = dest.with_name('.' + dest.name + '-' + uuid.uuid4().hex)
        shutil.copyfile(path, tmp)
        os.replace(tmp, dest)
    return {'path': str(dest.resolve()), 'sha256': sha, 'duration': duration}


def save_profile(name, *, names=None, logo='', intro='', outro='', music='', music_license='', root=None):
    """Create a shared channel profile; optional media becomes immutable snapshots."""
    root = Path(root or shared_root() / 'channel_profiles').resolve()
    slug = re.sub(r'[^a-z0-9-]', '-', name.lower().strip()).strip('-')[:60]
    if not slug or not name.strip():
        raise ValueError('Enter a channel name')
    folder = root / slug; folder.mkdir(parents=True, exist_ok=True)
    existing = {}
    if (folder / 'profile.json').is_file():
        existing = json.loads((folder / 'profile.json').read_text(encoding='utf8'))
        for asset in existing.get('assets', {}).values(): _verified(asset)
    data = {'schema_version': 1, 'id': slug, 'name': name.strip()[:120],
            'names': {lang: str((names or {}).get(lang) or existing.get('names', {}).get(lang) or name).strip()[:120]
                      for lang in LANGUAGES},
            'assets': dict(existing.get('assets', {}))}
    if music and not str(music_license).strip():
        raise ValueError('Record the music source and permission')
    data['music_license'] = str(music_license or existing.get('music_license', '')).strip()[:500]
    for kind, value in [('logo', logo), ('intro', intro), ('outro', outro), ('music', music)]:
        if value:
            data['assets'][kind] = _snapshot(value, folder / 'assets', kind)
    _atomic_json(folder / 'profile.json', data)
    return folder / 'profile.json'


def _atomic_json(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.saving-', suffix='.json')
    try:
        with os.fdopen(fd, 'w', encoding='utf8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2); fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)


def profiles(root=None):
    root = Path(root or shared_root() / 'channel_profiles')
    return sorted(root.glob('*/profile.json')) if root.is_dir() else []


def create_plan(source, profile_path, *, languages=('en',), output_root=None,
                source_rights='own_content', shared_music=None, shared_music_license=''):
    """A profile may be a single path or a language->profile path mapping."""
    if source_rights not in ('own_content', 'licensed', 'creative_commons'):
        raise ValueError('Review and declare source rights')
    languages = list(dict.fromkeys(languages))
    if not languages or any(lang not in LANGUAGES for lang in languages):
        raise ValueError('Choose English, Hindi or Odia editions')
    selection = profile_path if isinstance(profile_path, dict) else {lang: profile_path for lang in languages}
    if any(lang not in selection or not selection[lang] for lang in languages):
        raise ValueError('Choose an actual channel profile for each language edition')
    original_source = Path(source).resolve()
    job_root = original_source.parent.parent if original_source.parent.name == 'render' else original_source.parent
    clean_record = job_root / 'production' / 'visual_master.json'
    if clean_record.is_file() and original_source.parent.name == 'render' and ('-final' in original_source.stem or original_source.name == 'visual-master.mp4'):
        record = json.loads(clean_record.read_text(encoding='utf8'))
        if Path(record['path']).is_file() and _hash(record['path']) == record['sha256']:
            source = record['path']
        else:raise ValueError('Clean visual master is missing or changed; render the production again')
    folder = Path(output_root or shared_root() / 'outputs' / 'finishing') / (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
    asset_dir = folder / 'assets'
    source_asset = _snapshot(source, asset_dir, 'source')
    shared = None
    if shared_music:
        if not str(shared_music_license).strip():
            raise ValueError('Record the shared music source and permission')
        shared = _snapshot(shared_music, asset_dir, 'shared-music')
    editions = {}
    for lang in languages:
        profile = json.loads(Path(selection[lang]).read_text(encoding='utf8'))
        if profile.get('schema_version') != 1 or not profile.get('name'):
            raise ValueError('Unsupported channel profile for '+lang)
        assets = {}
        for kind, entry in profile.get('assets', {}).items():
            if kind in ('logo', 'intro', 'outro', 'music'):
                _verified(entry)
                assets[kind] = _snapshot(entry['path'], asset_dir, kind+'-'+lang)
        editions[lang] = {'channel': {'name': profile['name'], 'display_name': profile.get('names', {}).get(lang) or profile['name']},
                          'assets': assets, 'profile_music_license': profile.get('music_license',''),
                          'cards': [], 'narration': None, 'music': None,
                          'intro': bool(assets.get('intro')), 'outro': bool(assets.get('outro')), 'reviewed': False}
    edition_file = job_root / 'production' / 'language_editions.json'
    if edition_file.is_file():
        prepared = json.loads(edition_file.read_text(encoding='utf8')).get('bundles', {})
        for lang, edition in editions.items():
            bundle = prepared.get(lang)
            if bundle:
                if _hash(bundle['audio']) != bundle.get('audio_sha256'):
                    raise ValueError('Prepared language narration changed; prepare it again')
                edition['narration'] = _snapshot(bundle['audio'], asset_dir, 'narration-'+lang)
                edition['cards'] = bundle['cards']
                edition['script'] = bundle['script']
                edition['timing_source'] = bundle.get('timing_source','unverified')
                edition['reviewed'] = False
    plan = {'schema_version': 2, 'state': 'draft', 'source_rights': source_rights,
            'source': source_asset, 'shared_music': shared,
            'shared_music_license': str(shared_music_license).strip()[:500],
            'editions': editions, 'music_volume': 0.12,
            'branding_motion': True, 'created_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    _atomic_json(folder / 'plan.json', plan)
    return folder / 'plan.json'


def _verified(entry):
    path = Path(entry['path']).resolve(strict=True)
    if path.is_symlink() or _hash(path) != entry['sha256']:
        raise ValueError('Saved media changed; recreate the plan')
    return path


def set_edition(plan_path, language, *, cards=None, narration=None, music=None, intro=None, outro=None,
                reviewed=False, music_license=None):
    plan_path = Path(plan_path).resolve()
    plan = json.loads(plan_path.read_text(encoding='utf8'))
    if language not in plan['editions']:
        raise ValueError('Language was not selected for this plan')
    edition = plan['editions'][language]
    if cards is not None:
        source_duration = plan['source']['duration']
        checked = []
        for row in cards:
            text = str(row.get('text', '')).strip()
            start, end = float(row['start']), float(row['end'])
            if not text or len(text) > 160 or not 0 <= start < end <= source_duration or end-start > 12:
                raise ValueError('Card text or timing is invalid')
            checked.append({'text': text, 'start': start, 'end': end})
        if len(checked) > 30:
            raise ValueError('Too many text cards')
        edition['cards'] = checked
    if narration:
        edition['narration'] = _snapshot(narration, plan_path.parent / 'assets', 'narration-' + language)
    if music == '':
        edition['music'] = None
        edition.pop('music_license', None)
    elif music:
        if not music_license or not str(music_license).strip():
            raise ValueError('Record music source and permission before use')
        edition['music'] = _snapshot(music, plan_path.parent / 'assets', 'music-' + language)
        edition['music_license'] = str(music_license).strip()[:500]
    if intro is not None: edition['intro'] = bool(intro)
    if outro is not None: edition['outro'] = bool(outro)
    edition['reviewed'] = bool(reviewed)
    plan['state'] = 'reviewed' if any(e.get('reviewed') for e in plan['editions'].values()) else 'draft'
    _atomic_json(plan_path, plan)
    return plan_path


def propose_cards(transcript, duration, language, *, cleanup='delete-after-read'):
    """Optional text-only Gemini draft. The user must review/set the timing."""
    if language not in LANGUAGES or not transcript.strip() or not 1 <= duration <= 7200:
        raise ValueError('Provide transcript, language and duration')
    from .providers.gemini_web import gemini_web_generate
    from .planning.script_engine import _extract_json
    raw = gemini_web_generate(
        'Suggest sparse, short, useful overlay text cards for an existing video. JSON only. '
        'Never invent claims, sources, rights or download links. Keep the video visible. '
        'Return {"cards":[{"start":0,"end":2,"text":"..."}],"music_mood":"..."}. '
        'Use seconds relative to the supplied video. The result is a draft for human review.',
        'Language: '+LANGUAGES[language]+'\nDuration seconds: '+str(duration)+'\nTranscript/context:\n'+transcript[:18000],
        cleanup=cleanup)
    result = _extract_json(raw)
    if not isinstance(result, dict) or not isinstance(result.get('cards'), list):
        raise ValueError('Gemini did not return cards')
    return result


def _run(cmd, progress=None, duration=None):
    if progress and duration:
        cmd = cmd[:-1] + ['-progress', 'pipe:1', '-nostats', cmd[-1]]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        # FFmpeg stderr is bounded by -loglevel error; drain at process completion.
        for line in p.stdout:
            if line.startswith('out_time_ms='):
                try: progress(min(0.99, int(line.split('=', 1)[1]) / 1e6 / duration))
                except (ValueError, TypeError): pass
        err = p.stderr.read(); result = p.wait()
        if result:
            raise RuntimeError('FFmpeg failed: ' + err[-1200:])
    finally:
        if p.poll() is None:
            p.kill(); p.wait()
        p.stdout.close(); p.stderr.close()


def _card_image(text, width, height, path, language):
    from PIL import Image, ImageDraw, ImageFont
    from engine.render.typography import font as make_font
    image = Image.new('RGBA', (width, height), (0, 0, 0, 0)); draw = ImageDraw.Draw(image)
    font = make_font(max(22, min(58, width // 28)), style='clean', text=text)
    max_width = width * .78; words = text.split(); lines=[]; current=''
    for word in words:
        attempt = (current+' '+word).strip()
        if current and draw.textlength(attempt, font=font) > max_width:
            lines.append(current); current=word
        else: current=attempt
    if current: lines.append(current)
    if len(lines) > 3: raise ValueError('Card is too long for the frame')
    step = font.size * 1.4; box_h = int(len(lines)*step + 34); top=int(height*.72-box_h/2)
    draw.rounded_rectangle((width*.08, top, width*.92, top+box_h), radius=16, fill=(12, 18, 28, 176))
    for i, line in enumerate(lines):
        draw.text((width/2, top+17+i*step), line, font=font, anchor='mt', fill='white', stroke_width=1,
                  stroke_fill=(5, 8, 12), direction='ltr' if language == 'en' else None)
    image.save(path)


def render(plan_path, language, *, progress=None):
    """Render one edition to a new output. Exact snapshots and reviewed plan required."""
    plan_path = Path(plan_path).resolve(); plan = json.loads(plan_path.read_text(encoding='utf8'))
    if plan['state'] != 'reviewed': raise ValueError('Review the plan and approve its cards/assets before render')
    if language not in plan['editions']: raise ValueError('Edition unavailable')
    if not plan['editions'][language].get('reviewed'): raise ValueError('This language edition needs review')
    src = _verified(plan['source']); edition = plan['editions'][language]
    edition_assets = edition.get('assets', plan.get('assets', {}))
    assets = {k:_verified(v) for k,v in edition_assets.items()}
    for key in ('narration','music'):
        if edition.get(key): _verified(edition[key])
    info, duration = _probe(src)
    vstream = next(s for s in info['streams'] if s['codec_type']=='video')
    width, height = int(vstream['width']), int(vstream['height'])
    width -= width%2; height -= height%2
    if width < 320 or height < 240: raise ValueError('Source resolution too small')
    folder = plan_path.parent / 'exports'; folder.mkdir(exist_ok=True)
    dest = folder / (language+'-'+plan_path.parent.name+'.mp4')
    if dest.exists(): raise FileExistsError('Export exists; it will never be overwritten: '+str(dest))
    tmp_dir = Path(tempfile.mkdtemp(dir=plan_path.parent, prefix='.render-'))
    try:
        # Normalization yields identical codec/timebase for concat, and handles odd source dimensions.
        clips=[]
        for index, kind in enumerate(['intro','source','outro']):
            if kind != 'source' and (not edition.get(kind) or kind not in assets): continue
            source = src if kind=='source' else assets[kind]
            i, d = _probe(source)
            has_audio = any(s.get('codec_type')=='audio' for s in i['streams'])
            segment=tmp_dir / f'{index}.mp4'
            cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(source)]
            if not has_audio: cmd += ['-f','lavfi','-i','anullsrc=r=48000:cl=stereo']
            vf=f'scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p'
            cmd += ['-map','0:v:0','-map','0:a:0' if has_audio else '1:a:0', '-vf',vf,
                    '-c:v','libx264','-preset','veryfast','-crf','21','-c:a','aac','-ar','48000','-ac','2',
                    '-af','aresample=async=1:first_pts=0','-shortest',str(segment)]
            _run(cmd); clips.append((kind,segment,d))
        concat=tmp_dir/'concat.txt'
        concat.write_text(''.join("file '"+str(p.resolve()).replace("'", "'\\''")+"'\n" for _,p,_ in clips))
        joined=tmp_dir/'joined.mp4'
        _run(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','concat','-safe','0','-i',str(concat),'-c','copy',str(joined)])
        offset=sum(d for kind,_,d in clips if kind=='intro')
        _, full_duration=_probe(joined)
        cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(joined)]
        filters=[]; current='0:v'; inp=1
        # No Flow watermark mask or tracking. Branding is an independently placed channel mark.
        if 'logo' in assets:
            cmd += ['-loop','1','-framerate','30','-i',str(assets['logo'])]
            size=max(48,round(width*.13)); filters += [f'[{inp}:v]scale={size}:-1,format=rgba,colorchannelmixer=aa=0.85[logo]']
            filters += [f'[{current}][logo]overlay=x=W-w-24:y=H-h-24:shortest=1[v{inp}]']; current=f'v{inp}';inp+=1
        name=edition.get('channel',plan.get('channel',{})).get('display_name') or edition.get('channel',plan.get('channel',{})).get('name','')
        if name:
            from engine.render.graphics import OverlayEvent, render_overlay_png
            art=tmp_dir/'channel-name.png'
            event=OverlayEvent('watermark',0,full_duration,name)
            render_overlay_png(event,str(art),width,height,style='clean')
            cmd += ['-loop','1','-framerate','30','-i',str(art)]
            movement='4*sin(2*PI*t/6)' if plan.get('branding_motion') else '0'
            filters += [f'[{current}][{inp}:v]overlay=x={movement}:y=0:shortest=1[v{inp}]']
            current=f'v{inp}';inp+=1
        for index,card in enumerate(edition['cards']):
            art=tmp_dir/f'card-{index}.png';_card_image(card['text'],width,height,art,language)
            cmd += ['-loop','1','-framerate','30','-i',str(art)]
            start=offset+float(card['start']);end=offset+float(card['end'])
            filters += [f'[{current}][{inp}:v]overlay=0:0:enable=\'between(t,{start:.3f},{end:.3f})\':shortest=1[v{inp}]'];current=f'v{inp}';inp+=1
        voice=edition.get('narration')
        if voice:
            # Narration must fit the source timeline; no implicit speed-up or dialogue replacement of intro/outro.
            if voice['duration'] > plan['source']['duration']+0.25: raise ValueError('Narration exceeds source footage; edit timing or source')
            cmd += ['-i',str(_verified(voice))]
            source_end = offset + plan['source']['duration']
            filters += [f'[{inp}:a]adelay={int(offset*1000)}|{int(offset*1000)},apad,atrim=0:{full_duration:.3f}[voice]',
                        f"[0:a]volume='if(between(t,{offset:.3f},{source_end:.3f}),0,1)':eval=frame[bookends]",
                        '[bookends][voice]amix=inputs=2:duration=first:dropout_transition=0[speech]']
            speech='speech';inp+=1
        else: speech='0:a'
        music=edition.get('music') or plan.get('shared_music') or edition_assets.get('music')
        if music:
            cmd += ['-stream_loop','-1','-i',str(_verified(music))]
            volume=max(0.0,min(.35,float(plan.get('music_volume',.12))))
            if speech != '0:a':
                filters += [f'[{speech}]asplit=2[side][main]']
                side, main = 'side', 'main'
            else:
                side, main = speech, speech
            filters += [f'[{inp}:a]volume={volume:.3f},atrim=0:{full_duration:.3f},asetpts=N/SR/TB[music]',
                        f'[music][{side}]sidechaincompress=threshold=0.03:ratio=8:attack=200:release=600[duck]',
                        f'[{main}][duck]amix=inputs=2:duration=first:dropout_transition=0,alimiter=limit=0.95[aout]']
            audio='aout'
        else:audio=speech
        if filters:cmd += ['-filter_complex',';'.join(filters)]
        cmd += ['-map',f'[{current}]' if current!='0:v' else '0:v:0', '-map',f'[{audio}]' if audio!='0:a' else '0:a:0',
                '-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p',
                '-c:a','aac','-b:a','192k','-movflags','+faststart','-t',str(full_duration),str(tmp_dir/'result.mp4')]
        _run(cmd,progress,full_duration)
        result=tmp_dir/'result.mp4'; final_info, final_duration=_probe(result)
        if abs(final_duration-full_duration)>0.8 or not any(s.get('codec_type')=='audio' for s in final_info['streams']):
            raise ValueError('Export QC failed: duration or audio')
        os.replace(result,dest)
        _atomic_json(dest.with_suffix('.provenance.json'), {'plan':str(plan_path),'language':language,'source_sha256':plan['source']['sha256'],
                     'output_sha256':_hash(dest),'music_license':edition.get('music_license') or plan.get('shared_music_license') or edition.get('profile_music_license') or plan.get('profile_music_license'),
                     'channel':edition.get('channel',plan.get('channel')), 'duration':final_duration})
        if progress:progress(1.0)
        return dest
    finally:shutil.rmtree(tmp_dir,ignore_errors=True)

"""Bound decoder count for large edits; every approved cutaway remains in picture."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import os
import time

LIMIT=8


def input_count(segments, narration, options):
    return len(segments)+bool(narration)+bool(options.get('music'))+bool(options.get('ambience'))+len(options.get('sfx') or [])+len(options.get('overlays') or [])+len(options.get('video_overlays') or [])


def picture_intervals(total, overlays, fps=None):
    edges={0.,float(total)}
    for e in overlays:
        start,end=float(e['start']),float(e['end'])
        if not 0<=start<end<=total+.01:raise ValueError('Approved cutaway is outside the timeline')
        edges.update([start,min(total,end)])
    if fps:
        edges={max(0,min(total,round(t*fps)/fps)) for t in edges}
    edges=sorted(edges);out=[]
    for start,end in zip(edges,edges[1:]):
        mid=(start+end)/2
        active=next((e for e in reversed(overlays) if float(e['start'])<=mid<float(e['end'])),None)
        row={'start':start,'duration':end-start,'path':active['path'] if active else None,'in':float(active.get('in',0))+start-float(active['start']) if active else start}
        # Later approved layers win, matching the original overlay graph.
        if out and row['path']==out[-1]['path'] and abs(out[-1]['in']+out[-1]['duration']-row['in'])<1e-6:
            out[-1]['duration']+=row['duration']
        else:out.append(row)
    return out


def stage_large_edit(segments,narration,options,folder,progress,clean_master=None):
    from . import ffmpeg_renderer as ff
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    _, original=ff.build_ffmpeg_cmd(segments,narration,str(folder/'unused.mp4'),**options)
    total=original['total'];W=options.get('W',1080);H=options.get('H',1920);fps=options.get('fps',24)
    # Intermediates are re-encoded once more in the final master. A fast, low-CRF
    # staging preset saves CPU while retaining quality for the final encode.
    staging_quality='preview' if options.get('quality')=='preview' else 'intermediate'
    common=dict(W=W,H=H,fps=fps,quality=staging_quality,encoder='libx264',safe_concat=True,apply_global_fade=False)
    cuts=options.get('video_overlays') or []
    intervals=picture_intervals(total,cuts,fps=fps) if cuts else []
    graphics=list(options.get('overlays') or [])
    stage_count=(len(segments)+LIMIT-1)//LIMIT+1+(len(intervals)+1 if cuts else 0)+max(0,(len(graphics)-1)//(LIMIT-1))
    stage_index=0;stage_started=time.monotonic();history=[]
    def run(command,duration,label):
        nonlocal stage_index
        started=time.monotonic();part=stage_index+1
        def update(p,detail=''):
            if progress:
                elapsed=time.monotonic()-stage_started
                avg=elapsed/max(.05,stage_index+max(0,min(1,float(p)/100)))
                remain=max(0,stage_count-stage_index-max(0,min(1,float(p)/100)))*avg
                progress(100*(stage_index+max(0,min(1,float(p)/100)))/stage_count,
                         f'{label} · stage {part}/{stage_count} · {int(elapsed)}s elapsed · approx {int(remain/60)}m remaining · {detail}')
        update(0)
        try:r=ff._run_ffmpeg_progress(command,duration,update if progress else None)
        except Exception as error:
            (folder.parent/'bounded_failure.json').write_text(json.dumps({'stage':label,'error_type':type(error).__name__,'detail':str(error)},indent=2))
            raise
        if r.returncode:
            log=folder.parent/'bounded_ffmpeg.log';log.write_text(r.stderr or '',encoding='utf-8')
            raise RuntimeError(f'Bounded render failed at {label}; FFmpeg exit {r.returncode}. Full diagnostic: {log}. Approved assets preserved.')
        stage_index+=1
        history.append({'stage':label,'seconds':round(time.monotonic()-started,2)})
        (folder.parent/'render_stage_timings.json').write_text(json.dumps({'staging_quality':staging_quality,'completed':stage_index,
             'total_stages':stage_count,'stages':history,'elapsed_seconds':round(time.monotonic()-stage_started,2)},indent=2))
        update(0)
    def concat(paths,out,label):
        # Only generated simple filenames enter this manifest, never user paths.
        manifest=folder/(out.stem+'.ffconcat')
        manifest.write_text('ffconcat version 1.0\n'+''.join("file '"+p.name+"'\n" for p in paths))
        run([ff.ffmpeg_exe(),'-y','-f','concat','-safe','1','-i',str(manifest),'-map','0:v:0','-c:v','copy','-an','-movflags','+faststart',str(out)],total,label)
    # Preserve the original total/shot order. Crossfades become hard cuts in
    # bounded mode, with their existing overlap duration deducted from each end.
    rows=[]
    for index,s in enumerate(segments):
        row=dict(s);overlap=0
        if index<len(segments)-1:
            overlap=0 if options.get('safe_concat') and s.get('hard_cut') else (.35 if s.get('trans_out')=='dissolve' else .01)
        eff=float(s['dur'])+float(s.get('freeze',0) or 0)-overlap
        if eff<.05:raise ValueError('Scene is too short for its transition')
        row.update(dur=min(float(s['dur']),eff),freeze=max(0,eff-float(s['dur'])),hard_cut=True)
        rows.append(row)
    base_parts=[]
    for offset in range(0,len(rows),LIMIT):
        path=folder/f'base_{offset:04d}.mp4'
        command,meta=ff.build_ffmpeg_cmd(rows[offset:offset+LIMIT],None,str(path),**common,loop_short_segments=options.get('loop_short_segments',False))
        run(command,meta['total'],f'Base scenes {offset+1}–{min(offset+LIMIT,len(rows))}')
        base_parts.append(path)
    base=folder/'base.mp4';concat(base_parts,base,'Assembling base picture')
    picture=base
    if cuts:
        parts=[]
        for i,row in enumerate(intervals):
            path=folder/f'cut_{i:04d}.mp4'
            command=[ff.ffmpeg_exe(),'-y','-threads','2']
            if row['path']:command+=['-stream_loop','-1']
            command+=['-ss',str(row['in']),'-i',str(row['path'] or base),'-t',str(row['duration']),'-vf',f'scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,fps={fps},format=yuv420p,setpts=PTS-STARTPTS','-frames:v',str(max(1,round(row['duration']*fps))),'-an','-c:v','libx264','-preset','veryfast','-crf','18','-threads','2',str(path)]
            run(command,row['duration'],f'Picture interval {i+1}; approved B-roll retained')
            parts.append(path)
        picture=folder/'picture.mp4';concat(parts,picture,'Assembling all approved cutaways')
    # Bound transparent graphics too; audio and captions are applied once last.
    if clean_master:
        import shutil
        target=Path(clean_master);target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_suffix('.pending.mp4')
        shutil.copy2(picture,temporary)
        os.replace(temporary,target)
        from ..production import digest,save
        save(target.parent.parent/'production'/'visual_master.json',
             {'path':str(target.resolve()),'sha256':digest(target),'duration':total,
              'contains':'picture and approved B-roll only; no speech, captions, music or branding'})
    while len(graphics)>LIMIT-1:
        path=folder/f'graphics_{len(graphics):04d}.mp4'
        command,meta=ff.build_ffmpeg_cmd([{'src':str(picture),'in':0,'dur':total,'hard_cut':True}],None,str(path),**common,overlays=graphics[:LIMIT-1])
        run(command,total,'Applying bounded graphics batch')
        picture=path;graphics=graphics[LIMIT-1:]
    new_options={**options,'video_overlays':[],'overlays':graphics,'safe_concat':True}
    # All audio stays in the original final mix. No cutaway audio is introduced.
    return [{'src':str(picture),'in':0,'dur':total,'hard_cut':True}],new_options,{'stage_timings':str(folder.parent/'render_stage_timings.json'),'bounded_render':True,'original_segments':len(segments),'approved_cutaways':len(cuts),'decoder_limit':LIMIT,'transitions':'hard cuts; original total retained'}

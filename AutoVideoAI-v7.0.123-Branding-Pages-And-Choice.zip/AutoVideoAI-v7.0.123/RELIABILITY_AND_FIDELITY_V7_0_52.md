# AutoVideoAI 7.0.52 — reliability and scene fidelity

This release fixes defects identified in the rain-dance run, adds optional sound accents, and preserves the existing local editing/recovery tools. It is a tested application update, not a certification that Google's changing browser UI or generated artistic output will always work.

## What the supplied evidence established

The 10-second run recorded eleven “New project” actions. Multiple still requests entered a replacement path, then used free-provider images. The final `fallbacks=0` counted motion-shot substitutions and omitted those storyboard substitutions. Flow did successfully generate and download one motion clip; the final edit combined that clip with an image-motion scene. The selected Storyboard Economy profile intentionally permits that mixture.

The story-bible keyword fallback selected an apartment when the requested street/rain setting was not recognized. Generic hook coverage also requested extreme close-ups. Long character biographies repeated background/lighting preferences and could crowd the actual scene out of a bounded prompt. The supplied output showed character changes and close-up transitions inconsistent with a continuous dance. Successful decoding was insufficient to establish scene fidelity.

Music-only stopped before visuals because legacy automatic music lookup failed when its browser could not start. The terminal attachment also showed a Flow Music close-login exception escaping into the dashboard. An unrelated older pending Mini Reel prevented any new Mini Reel generation.

## Changes in this build

- Authored scene setting, weather, framing, camera movement and action take priority over generic apartment/coverage rules in visual-only jobs. The visual writer now requests those fields separately. Location masters use the scene's setting.
- Photo-backed character prompts use the actual attached photo as identity authority without repeating a long biography's background. Full approved character snapshots remain saved.
- Frame prompts are never cut mid-scene to meet a character count. Oversized complete instructions stop clearly before submission.
- Missing full prompt echoes trigger download-only recovery in the same isolated image project. They no longer immediately authorize a replacement. Input/reference images still fail output validation.
- Replacement generation is opt-in for new/unversioned jobs. Existing explicit saved permission and reservations retain their limits. One project per independent image remains an isolation choice; this release does not pretend a multi-scene job always needs only one project.
- Guided Studio defaults to Flow frames. Flow-only selection now also blocks free substitutions in candidate-image generation outside Storyboard Economy. Selecting Auto still permits substitutions; selecting Free is deliberate.
- Storyboard/master fallback receipts record committed bytes and hashes. Generation summaries report frame fallbacks alongside motion fallbacks; substitute images trigger review warnings.
- Automatic music retrieval uses local music → Pixabay → an original local instrumental when the earlier steps fail. The choice and fallback reason are recorded and shown. Explicit Local/Browser choices retain their stricter behavior. New local/downloaded tracks must pass audio probing before generation.
- Public media search no longer inherits the signed-in Flow session's hidden-display setting. Missing Chromium/OS dependencies can still require installation.
- Closing the Flow Music login window reports a bounded warning instead of crashing the page.
- A separately approved Mini Reel can proceed while an older request remains unresolved. The old request is retained, and changing that old request's prompt is still blocked.
- New video requests save their exact submitted prompt. Recovery can rebind a rotated thumbnail only when one video in the same project has that exact prompt. Ambiguous matches and older journals without sufficient evidence stay unresolved.
- Short-video readiness no longer requires an impossible number of motion scenes relative to its shot count.

## How to install in the existing folder

Stop Studio and the local runner after any active production has finished. Extract this ZIP beside the existing installation. From the existing `AutoVideoAI-v7` directory run:

```bash
python3 ../AutoVideoAI-v7.0.52/tools/update_v743_to_v752.py . --apply
./dashboard.sh
```

The cumulative updater accepts 7.0.43 through 7.0.51. It verifies the packaged code, backs up replaced files, and keeps runtime jobs, settings, profiles and shared outputs. Continue running `dashboard.sh`, CLI commands and the runner from that same updated installation. Check the displayed version is 7.0.52.

For a music-only rain-dance Reel choose Reels & Long Videos → Normal Reel / Short → 30 seconds → Cinematic theme → Music only. Choose Flow Cinematic if every shot should be generated motion. Storyboard Economy mixes motion and animated stills; the UI now explains this visibly. Keep Frame source = Flow to avoid provider substitutions. Reliable music works offline if browser retrieval fails; choose a licensed local track when you want specific music.

Start a new job for a corrected scene plan. Resume intentionally keeps an old job's approved plan and accepted media; upgrading does not silently rewrite or regenerate its incorrect apartment frames.

If Chromium itself is missing or cannot launch, use the same Python environment as Studio:

```bash
python3 -m playwright install --with-deps chromium
python3 tools/production_preflight.py
```

The first command may request Linux package-install permission. The local instrumental does not require Chromium. The preflight checks local media/dependency readiness; it does not prove signed-in Gemini/Flow UI readiness.

## Sound hooks

In the completed job monitor, open **Opening and closing sound hooks · optional**. In Clip Studio, load a saved clip batch, choose **Saved clip for optional sound hooks**, then open the same panel. Choose Soft, Cinematic or Punchy; opening/closing accents and gain are adjustable.

This creates a separate MP4 with an original synthesized accent and any existing audio. Video frames are copied without re-encoding. It adds audio even to a silent source, only after the explicit export action. Tiny clips avoid overlapping opening and closing accents. The original clip, caption burn and logo stay in the source; no Gemini/Flow request is made. These are short sound accents, not a professional music library or beat-synchronized editing engine.

## Feature audit and remaining work

| Area | Current implementation / checks | Remaining production gap |
|---|---|---|
| Reels and long videos | Explicit format/audio intent, timed visual plans, budgets, saved jobs; scene-fidelity fixes above | Generated action/likeness still requires editorial assessment; no semantic guarantee |
| Mini Reels | One approved request, native Flow audio intent, exact download recovery, independent pending-job override | Older missing assets may lack enough evidence for automatic recovery; live account UI unverified |
| Gemini writing/transcription | Reviewed plans, audible/silent even-dimension proxies, bounded upload controls and chat cleanup | Upload UI, consent, language accuracy and login remain external-session dependencies |
| Character library | Frozen snapshots, hashed photos, selected cast; concise photo identity prompts | Likeness and wardrobe must be checked in generated results |
| Music video / audio | Local/Flow music workflows, playable preflight, reliable offline fallback; optional export accents | Offline fallback is a simple loop; advanced scoring, beat matching and rich sound libraries remain future work |
| Clip Studio / local editing | Saved batch history, captions/logos/music, vertical crops, partial results, B-roll reviews | Face cropping uses sampled static framing, not continuous active-speaker tracking |
| B-roll | Exact asset checks, batch approval, saved decisions, bounded per-clip render checkpoints | Search relevance/licence review and unavailable candidates remain visible user decisions |
| Rendering / monitoring | FFmpeg validation, progress logs, saved clip render state and locks | Closing a tab is supported; stopping Studio stops in-process workers. A separate supervised worker service is still needed |
| Queue / resume | Saved assets and journals, serialized browser production, explicit bounded recovery | Unknown submissions cannot be safely converted into unlimited automatic retries |
| Cleanup / history | Reviewed local deletion and dependency/active-job checks | Automatic Google Flow project deletion remains disabled until exact remote deletion can be verified |
| Publishing / QC | Destination recipes, provenance/readiness reports and local exports | Technical checks do not certify artistic quality, account acceptance or audience performance |
| Control Center | Downloadable release, local-runner commands and monitoring | Website deployment does not update WSL code; the cumulative updater must be run locally |

The highest-value next architectural work is a supervised local worker service, a visual/storyboard acceptance stage before paid motion, and a provider adapter contract tested against recorded UI fixtures plus an actual signed-in acceptance run. Those are not completed by this patch and are not represented as shipped features.

## Research used

Checked 16 October 2026 against official documentation:

- [Playwright browser installation](https://playwright.dev/python/docs/browsers): browser binaries and Linux dependencies must match the installed Playwright version. A visible-window flag cannot install missing libraries.
- [Playwright downloads](https://playwright.dev/python/docs/downloads): downloads live in temporary context storage and need to be saved before the context closes. Existing durable capture tests cover interrupted saves.
- [Google Flow images](https://support.google.com/flow/answer/16729550?hl=en) and [videos](https://support.google.com/flow/answer/16353334?hl=en): inputs and created assets share the workspace; uploading a reference does not establish a completed output. The adapter preserves input/output exclusion.
- [FFmpeg audio filters](https://ffmpeg.org/ffmpeg-filters.html#amix): timed accent mixing uses delay, mixing, limiting and duration trimming while copying the source video stream.

No paid Google generation was submitted during this review. Automated regression tests use local media, dry runs and controlled provider doubles. Live Google/Pixabay account operation and remote deletion are not certified.

## Release verification

Engine regression suite: 1,101 passed, 13 dependency deprecation warnings. New tests exercise same-project image recovery without a prompt echo, exact/ambiguous video matching, separate Mini Reel permission, scene settings/framing, browser-failure music fallback, invalid audio rejection, strict Flow routing, fallback receipts and real audio exports. Control Center: 25 JavaScript tests and 19 Python runner tests passed; syntax checks passed. Hash-verified packaging and updater preservation are checked separately before delivery. No live signed-in Google generation was performed.

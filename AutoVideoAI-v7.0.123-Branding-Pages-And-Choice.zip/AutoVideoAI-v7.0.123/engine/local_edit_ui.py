"""Streamlit controls for local editing; separate from highlight generation."""
import json
from pathlib import Path


def local_edit_controls(st, mode):
    from .local_video_edits import edit_video
    from .studio_widgets import save_uploaded_image
    st.caption('Edits existing footage only. Whole-video conversion preserves its duration; music shots split the entire video into consecutive fixed-length segments, including the last shorter segment. Source audio is retained. No Gemini or Flow generation.')
    source=st.text_input('Video URL or local video path',key='local-edit-source')
    upload=st.file_uploader('Or upload a video',type=['mp4','mov','mkv','webm'],key='local-edit-upload')
    if upload:
        import hashlib
        data=upload.getvalue(); folder=Path('data/local_edit_imports');folder.mkdir(parents=True,exist_ok=True)
        path=folder/(hashlib.sha256(data).hexdigest()+Path(upload.name).suffix.lower())
        if not path.exists():path.write_bytes(data)
        source=str(path)
    framing=st.selectbox('Output framing',['face-crop','fit'],index=0 if mode=='convert' else 1,
        format_func=lambda x:'Vertical 9:16 · sampled face crop' if x=='face-crop' else 'Preserve full source frame',key='local-edit-framing')
    st.caption('Face crop uses one sampled face center per output. Review moving subjects and multi-speaker footage before publishing.')
    seconds=st.number_input('Seconds per music shot',1,600,30,key='local-edit-length') if mode=='split' else 30
    captions=st.selectbox('Transcript / captions',['none','automatic','reviewed','gemini-web'],
        format_func=lambda x:{'none':'None · no transcription','automatic':'Automatic speech captions','reviewed':'Reviewed timed transcript JSON','gemini-web':'Gemini Web · draft and review transcript'}[x],key='local-edit-captions')
    language=st.selectbox('Transcript language',['en','hi','or'],
        format_func=lambda x:{'en':'English','hi':'Hindi','or':'Odia / Oriya'}[x],disabled=captions=='none',key='local-edit-language')
    transcript=None
    if captions=='reviewed':
        transcript=st.file_uploader('Reviewed transcript JSON',type=['json'],key='local-edit-transcript')
        st.caption('Source-relative word timings: {"words":[{"word":"ନମସ୍କାର","start":0.2,"end":0.8}]}. No automatic translation or invented timing.')
    if language=='or' and captions=='automatic':st.info('Odia/Oriya uses a reviewed timed transcript. Select Reviewed above; automatic Odia ASR is unverified.')
    gemini_transcript=None
    if captions=='gemini-web' or (captions=='reviewed' and language=='or'):
        from .gemini_transcript import transcript_controls
        try:existing=json.loads(transcript.getvalue()) if transcript else None
        except Exception as error:st.error('Invalid uploaded transcript: '+str(error));existing=None
        gemini_transcript=transcript_controls(st,'local-edit-odia',source,language,existing)
    provider=st.selectbox('Speech timing provider',['auto','groq','local'],key='local-edit-provider') if captions=='automatic' else 'auto'
    music_on=st.checkbox('Add optional background music',value=False,key='local-edit-music')
    music_path=st.text_input('Local licensed music file',disabled=not music_on,key='local-edit-music-path')
    music_gain=st.slider('Background music volume',0.0,.35,.08,.01,disabled=not music_on,key='local-edit-gain')
    st.caption('Music is mixed under the original soundtrack. Leave it off to keep the source music unchanged.')
    logo_on=st.checkbox('Add channel logo',value=False,key='local-edit-logo')
    from .brand_logo import logo_controls
    logo, fraction=logo_controls(st,'local-edit-brand',enabled=logo_on)
    size=fraction*100
    corner=st.selectbox('Logo corner',['top-right','top-left','bottom-right','bottom-left'],disabled=not logo_on,key='local-edit-corner')
    output=st.text_input('Output folder',value='outputs/local-edits',key='local-edit-output')
    rights=st.selectbox('Source rights',['own_content','written_permission','licensed_content','creative_commons','public_domain','private_draft_only'],key='local-edit-rights')
    confirmed=st.checkbox('I confirm my source-rights declaration',key='local-edit-confirm')
    if st.button('Convert whole video' if mode=='convert' else 'Cut music video into shots',type='primary'):
        try:
            if not confirmed:raise ValueError('Confirm your source-rights declaration first.')
            if music_on and not music_path.strip():raise ValueError('Choose a local music file or turn optional music off.')
            if upload:
                import hashlib
                data=upload.getvalue(); folder=Path('data/local_edit_imports');folder.mkdir(parents=True,exist_ok=True)
                path=folder/(hashlib.sha256(data).hexdigest()+Path(upload.name).suffix.lower());path.write_bytes(data);source=str(path)
            if not source.strip():raise ValueError('Select a video source.')
            parsed=gemini_transcript or (json.loads(transcript.getvalue()) if captions=='reviewed' and transcript else None)
            if captions=='gemini-web' and not parsed:raise ValueError('Draft and approve the Gemini transcript before rendering.')
            bar=st.progress(0);status=st.empty()
            def progress(message,pct,detail=''):
                bar.progress(max(0,min(100,int(pct))));status.write(message)
            if gemini_transcript and gemini_transcript.get('source_path'):source=gemini_transcript['source_path']
            result=edit_video(source.strip(),output,mode=mode,seconds=seconds,framing=framing,
                transcript='reviewed' if captions=='gemini-web' else captions,language=language,transcript_data=parsed,caption_provider=provider,
                music_path=music_path.strip() if music_on else '',music_volume=music_gain,
                show_channel_logo=logo_on,channel_logo_path=logo,channel_logo_position=corner,
                channel_logo_size=size/100,source_rights=rights,rights_confirmed=confirmed,progress_cb=progress)
            st.session_state['local-edit-result']=result
        except Exception as error:st.error(str(error))
    result=st.session_state.get('local-edit-result')
    if result and result.get("mode")==mode:
        (st.warning if result['partial_result'] else st.success)(result['summary'])
        st.download_button('Download edit report',json.dumps(result,indent=2,ensure_ascii=False),file_name='edits.json')
        for item in result['segments']:
            if item['status']=='failed':st.error(f"{item['start']:.1f}–{item['end']:.1f}s: {item['error']}")
            else:
                with st.expander(f"{item['start']:.1f}–{item['end']:.1f}s · {Path(item['output']).name}"):
                    st.video(item['output'],width=320)
                    st.download_button('Download video',Path(item['output']).read_bytes(),file_name=Path(item['output']).name,key=item['output'])

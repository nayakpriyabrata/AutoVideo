# AutoVideo 7.0.92: a stalled Flow image request stops cleanly, and the fix works on existing journals

## What was failing (shot_020, job 20261022-143856-7-small-daily-habits-tha-9729)

Runs from 15:59 to 16:52 IST, on the 7.0.90 code:

- Each run opened the saved project, downloaded both uploaded references again (their Flow URLs had rotated),
  then waited six minutes silently for a generated image.
- No generated image was in the project. The retry repeated the same steps, then ended with
  "Recovery needs attention". Every Resume repeated this, so the job could never finish.
- Safe Resume blocked all generation and only pointed at a read-only preflight, so nothing in the app could clear it.

7.0.91 fixed the identity of references for new journals only. It did not change the stuck state of this journal,
because the old journal had no recorded labels.

## What 7.0.92 changes

1. **References are recognised by their live label and never downloaded.** Any tile labelled
   `AV_<hash>_<filename>` is an uploaded reference. This works for journals written before this release.
   Unlabelled tiles are still checked by their bytes, as before.
2. **A run that finds no generated tile stops after one wait.** The request is marked
   `recovery_state: no_generated_output_in_project`, and the message explains what happened and the one next step.
   No further browser retries are made in that run.
3. **A supported archive command.** `python3 cli.py v3 archive-request <job> storyboard/<image> --confirm-new-credit-spend`
   renames the unresolved journal (never deletes it) so the next Resume makes ONE new submission.
   It refuses when:
   - the shot already has a downloaded image;
   - the journal phase is not `submission_uncertain` or `submitted`;
   - a valid non-reference image is saved (recover it instead);
   - the job is running (production lock held).
   Without `--confirm-new-credit-spend` it only prints a dry run.
4. **Blocked-Resume message names the exact command** for each unresolved journal.

## Steps for shot_020

Approve the credit spend first. Then, from the install folder:

```
python3 cli.py v3 archive-request 20261022-143856-7-small-daily-habits-tha-9729 storyboard/shot_020_open.jpg
python3 cli.py v3 archive-request 20261022-143856-7-small-daily-habits-tha-9729 storyboard/shot_020_open.jpg --confirm-new-credit-spend
python3 cli.py v3 resume 20261022-143856-7-small-daily-habits-tha-9729
```

The first command is a dry run. Only the third command, after the flagged archive, makes a new submission.
Do not run Resume again unless you approve another credit spend.

## Installing

- From 7.0.91: `python3 ../AutoVideoAI-v7.0.92/tools/update_v791_to_v792.py .` (dry run), then add `--apply`.
- From 7.0.90: first apply the 7.0.91 update from the 7.0.91 zip folder, then the 7.0.92 update.
- Stop the dashboard before `--apply`. Restart it afterwards.

## Other notes

- Default TTS split size remains 2400 characters.
- `tools/update_v790_to_v791.py` is superseded and removed from `tools/`.

## Verification status

- Fixture tests: `tests/test_v792_stalled_recovery.py` (7 tests) reproduces the field state. All 7 fail on 7.0.91 and pass on 7.0.92.
  Also covered: `tests/test_v791_reference_labels.py` (updated for the no-download rule), and the 7.0.90 and journal guard tests.
- Not verified against live Flow. The shot_020 outcome is unknown until the approved new submission runs.

"""Keep photo-backed Flow briefs complete and avoid duplicate known uploads."""
import hashlib
import json
import os
from pathlib import Path
import uuid
from contextlib import contextmanager

_PROCESS_EPISODE = uuid.uuid4().hex


def reference_episode_id():
    return os.environ.get('AUTOVIDEO_REFERENCE_EPISODE', _PROCESS_EPISODE)


@contextmanager
def reference_recovery_episode():
    """One bounded upload allowance for each explicit job run/resume.

    Production is serialized; env also reaches its storyboard worker threads.
    Browser rebuilds within the same run do not renew the allowance.
    """
    key = 'AUTOVIDEO_REFERENCE_EPISODE'
    previous = os.environ.get(key)
    os.environ[key] = uuid.uuid4().hex
    try:
        yield
    finally:
        if previous is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = previous


def compact_photo_brief(prompt, reference_paths):
    # Only our known storyboard template and original saved-character aliases
    # qualify; unknown prompts and text-only characters retain their full text.
    if not any('character-' in Path(p).name for p in reference_paths or []):
        return prompt
    if not prompt.startswith(('STORYBOARD OPEN FRAME,', 'STORYBOARD CLOSE FRAME,')):
        return prompt
    labels=['Subject: ', 'Action context: ', 'Environment: ', 'Visual direction: ',
            'Narrative beat: ', 'Framing: ', 'Lighting: ', 'Look: ']
    if any(prompt.count(label)!=1 for label in labels):
        return prompt
    positions=[prompt.index(label) for label in labels]
    if positions != sorted(positions):
        return prompt
    subject=prompt[positions[0]+len(labels[0]):positions[1]].strip()
    cast_id=subject.split(' (',1)[0] if subject.startswith('CHARACTER_') else 'the depicted character'
    scene=prompt[positions[1]:]
    repeated=scene.find('Use the exact same protagonist identity and wardrobe: ')
    if repeated>=0:
        scene=scene[:repeated]
    return (prompt[:positions[0]] + 'Subject: '+cast_id+' from the attached original character photo; preserve face and wardrobe. '
            + scene + ' Keep composition compatible with the paired frame. Stable anatomy; no text, logo, watermark or UI.')


def upload_record(project_url, alias, *, record=False):
    # Project scope prevents an upload in one worker from authorizing another.
    if not project_url:
        return False
    key=hashlib.sha256(project_url.encode()).hexdigest()
    path=Path('data/flow_media_uploads/upload_registry')/(key+'.json')
    entries={}
    if path.exists():
        # Do not re-upload on a corrupt registry; restore/review local state.
        entries=json.loads(path.read_text())
    if record:
        path.parent.mkdir(parents=True,exist_ok=True)
        entries[alias]=True
        temporary=path.with_suffix('.tmp')
        temporary.write_text(json.dumps(entries,sort_keys=True))
        os.replace(temporary,path)
        # A verified attachment ends this failure episode. A later picker miss
        # may try one exact reattachment; failed attempts alone never reset it.
        _clear_verified_reattach(project_url, alias)
    return entries.get(alias) is True


def _clear_verified_reattach(project_url, alias):
    from .production_lock import acquire
    key=hashlib.sha256(project_url.encode()).hexdigest()
    root=Path('data/flow_media_uploads/upload_registry');root.mkdir(parents=True,exist_ok=True)
    path=root/(key+'.reattach.json')
    with open(root/(key+'.lock'),'a+b') as lock:
        acquire(lock)
        entries=json.loads(path.read_text()) if path.exists() else {}
        if alias not in entries:return
        del entries[alias]
        temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(entries));os.replace(temporary,path)


def reserve_reference_reattach(project_url, alias):
    """One exact upload recovery per failure episode; verified success resets it."""
    from .production_lock import acquire, release
    key=hashlib.sha256(project_url.encode()).hexdigest()
    root=Path('data/flow_media_uploads/upload_registry');root.mkdir(parents=True,exist_ok=True)
    path=root/(key+'.reattach.json')
    with open(root/(key+'.lock'),'a+b') as lock:
        acquire(lock)
        entries=json.loads(path.read_text()) if path.exists() else {}
        # Permit one remediation for earlier lifetime reservations; then retain
        # the new reservation until composer attachment is actually verified.
        reservation = {'protocol': 5, 'episode': reference_episode_id()}
        if entries.get(alias)==reservation:return False
        entries[alias]=reservation
        temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(entries))
        os.replace(temporary,path)
        return True


def reference_upload_attempt(project_url, alias, *, record=False):
    """Remember file-chooser submission even if attachment confirmation fails."""
    from .production_lock import acquire
    if not project_url:
        raise ValueError('A saved Flow project is required before uploading references')
    key=hashlib.sha256(project_url.encode()).hexdigest()
    root=Path('data/flow_media_uploads/upload_registry');root.mkdir(parents=True,exist_ok=True)
    path=root/(key+'.attempts.json')
    with open(root/(key+'.lock'),'a+b') as lock:
        acquire(lock)
        entries=json.loads(path.read_text()) if path.exists() else {}
        attempted=entries.get(alias) is True
        if record:
            entries[alias]=True
            temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(entries))
            os.replace(temporary,path)
        return attempted

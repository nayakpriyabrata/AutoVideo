# AutoVideoAI v7.0.48 — bounded Clip Studio B-roll rendering

Clip Studio now renders reviews with more than six approved cutaways through bounded timeline stages instead of opening every stock video and subtitle filter in one FFmpeg process.

- One picture interval is processed at a time, limiting decoder and libass pressure.
- Captions and the saved channel logo remain visible over inserted B-roll.
- The original highlight audio is restored once after the picture is assembled.
- Original highlight files are never overwritten.
- Old mixed English/Indic caption files receive a temporary render-only font correction; saved caption files are not modified.
- A failed stage writes a full `.ffmpeg.log` beside the intended output instead of returning only the final font warnings.
- v7.0.47 mixed-review approval behavior remains included: exact available assets are verified and unavailable slots are skipped.

## Update an existing installation

Stop Studio and any running production job. From the existing runtime folder:

```bash
python3 ../AutoVideoAI-v7.0.48/tools/update_v743_to_v748.py . --apply
cat VERSION
bash dashboard.sh
```

The updater changes application code only and preserves the already approved B-roll review, downloaded assets, saved clips, outputs, settings, databases and profiles.

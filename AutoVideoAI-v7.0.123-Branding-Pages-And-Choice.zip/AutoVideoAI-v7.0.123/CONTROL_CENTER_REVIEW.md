# AutoVideoAI v7.0.1 — reviewed control-center build

Based on the supplied v7.0.0 Content Studio source. This is a targeted maintenance release, not a guarantee of unattended provider reliability.

## Fixed

- Configuration loading rejects negative budgets/retries, zero/fractional image workers, fractional duration, nonfinite shares/shot limits and quoted boolean flags before job creation. Optional None settings remain supported.
- Voice-enabled Odia jobs reject unsupported TTS providers early; imported native narration and silent jobs remain supported.
- Malformed approved-plan rights objects produce a useful validation error instead of AttributeError.
- Delivery metadata preserves CR/CRLF paragraph boundaries. URL reference deduplication preserves case-sensitive paths and queries while normalizing host/scheme.
- Zero capacity wait/retry and media grace/recovery values remain zero; they are no longer replaced by defaults. Serial and parallel scene-image generation pass capacity settings to Flow.
- Mini Reel recovery preserves the approved credit/wait/retry settings. Mini Reel wait inputs reject invalid types and negative values.
- The control runner trusts engine QC/pause resolution, not merely a zero recovery exit code. A failed recovered take stays unresolved and visible.
- Control-center local input paths resolve relative to the engine folder. Relative paths no longer accidentally point inside the runner's config directory.
- Runner process checks include Mini Reels adapters and installed Streamlit entry points; approved-request deduplication remains persistent.

## Control center

Private Site: https://autovideoai-control.priyabrata-ericsson.chatgpt.site

YouTube, Reels, Cartoon and Clips retain start/resume/recovery, live logs and Flow failure categories. Added language, themes, presentation controls, approved plans, narration/character inputs, and Flow mode/pause choices. Mini Reels require a Gemini brief followed by separate prompt review and Flow approval. Exact pending Mini Reel requests can be recovered. Delivery exports are local REVIEW_REQUIRED copies and manual upload packets; there is no social-account publishing action.

The ZIP includes autovideo_runner.py, tools/control_center_adapter.py, CONTROL_CENTER_SETUP.md and regression tests. Run the runner in the same Python environment as the engine. It listens on loopback and accepts only the private Site's origin plus the terminal's random token.

## Validation and limits

The original 601 tests passed with FFmpeg here. Added 23 engine regression cases and 12 runner integration cases, plus 12 Site/DOM checks. Tests use synthetic media and mocked provider calls. Engine configuration mappings are checked against the real loader. Browser layout, Windows-to-WSL local-network permissions, Google login, actual paid generation, native audio quality and current Flow tile/download behavior have not been verified live. Final validation: 636 build tests passed (12 warnings), and 24 control-center checks passed. The included test suite can be rerun with pytest.

## Upgrade

Extract into a fresh folder. Preserve the old installation as a backup. Stop existing Studio/CLI/runner processes before moving local outputs, configuration, credentials and browser profiles to the new folder. The release excludes those runtime/private files. Keep saved job IDs, request journals and Flow project bindings together; resume uses saved job settings. New form options do not rewrite a saved job. Follow CONTROL_CENTER_SETUP.md for the one-command connection.

Changes to local workflow data and external provider operations happen only when you perform this upgrade and approve actions. No provider generation or external publishing was run during this review.

## v7.0.2 follow-up

Flow download recovery is updated for the reported tile submenu and selected-video editor toolbar. See FLOW_RECOVERY_V7_0_2.md for changes, upgrade procedure and live-verification limits. The existing v7.0.1 review below describes the earlier audit.

## v7.0.3 workflow maintenance

See WORKFLOW_RECOVERY_V7_0_3.md for this release. Complete validation: 658 engine tests passed (12 dependency deprecation warnings). Live WSL and provider browser behavior remain unverified.

## v7.0.4 parallel recovery and branding

See RECOVERY_AND_BRANDING_V7_0_4.md. Complete-suite validation: 662 tests passed (12 dependency warnings); encoded watermark sample checked. Live provider/WSL behavior remains unverified.

## v7.0.5 workflow resilience

See WORKFLOW_RESILIENCE_V7_0_5.md. Narration-runtime choice, multi-insert B-roll, original offline music, restricted XML fallback and local Mini Reel delivery. 676 engine tests and 27 control-center checks passed. No live failure-rate claim is made.

## v7.0.6 Flow frame stall and story identity

See FLOW_FRAME_STALL_V7_0_6.md. Immediate per-frame progress, worker heartbeats, browser-free reuse of valid saved frame artifacts, bounded exact image-event transfers with no late asset writes, and Kanha/Yasoda topic identity. Complete-suite validation: 685 engine tests passed (12 existing dependency deprecation warnings); 27 control-center checks passed. No live Google Flow or user WSL operations were performed.

## v7.0.7 validation

The complete engine suite passed: 691 tests (12 existing dependency deprecation warnings). Control-center checks passed: 27 tests and the configured syntax/check command. Native image-save tests exercised the installed Playwright sync bridge and async Download wrapper with controlled artifacts, including browser-local and authenticated HTTPS event URLs, timeout cancellation, invalid data, and preservation of an existing target. These tests did not launch Chromium or verify the user’s live WSL/Google session.

## v7.0.8 validation

Full engine suite: 702 passed, with 12 existing dependency deprecation warnings. Private control-center checks: 27 passed, with syntax checks also passing. Recovery regressions cover exact-prompt selection among multiple candidates, equivalent same-instruction variants, rejection of partial matches and unavailable prompt UI, composer restoration, legacy-journal recovery without submission, and protection against replacement based on gallery absence. Playwright native-artifact tests exercise its actual sync bridge with controlled Download artifacts. The new Reuse prompt UI behavior is tested with controlled locator fixtures, not the user’s live Flow DOM. No Chromium/Google/WSL end-to-end generation was performed.

## v7.0.9 validation

Full engine suite: 709 passed, with 12 existing dependency deprecation warnings. Private control center: 29 tests passed and syntax checks passed. Tests include a 50-candidate batch, missing/changed asset skipping, rejection of stale review identities, real Streamlit pagination and batch interaction, optional-logo validation, and actual FFmpeg renders confirming visible logo pixels on highlight/B-roll copies with and without added music. Audio streams were retained. Logo choices also round-trip through the private local runner payload. No external source download, paid generation, or live user WSL session was used.

## v7.0.22 — browser stability and reference recovery

See BROWSER_STABILITY_V7_0_22.md. Includes picker-filter cleanup, bounded byte-identical reference reattachment, newly reserved replacement-project isolation, WSL software rendering, atomic bounded video saves, measured reviewed-script runtime, card-crop controls and serialized browser production across tabs. Quiet mode is experimental; live WSL/Google browser validation remains unavailable here.

## v7.0.23 — safe worker cleanup

See SAFE_CLEANUP_V7_0_23.md. New worker clones omit regenerable caches; worker/job shutdown trims safe caches and removes completed clones only after final-video validation and no pending Flow requests. Preview/apply tool and Settings panel preserve source/accepted media, main login profiles and all recovery journals. Gemini upload proxies are removed after use.

"""Process-owned Studio tasks; observing a job never starts it again."""
from pathlib import Path
import json
import threading
from .production_lock import acquire, release

_tasks = {}
_guard = threading.Lock()

def is_running(root):
    path = Path(root)/'.production.lock'
    if not path.exists():
        return False
    with path.open('a+b') as handle:
        try:
            acquire(handle, blocking=False)
        except BlockingIOError:
            return True
        release(handle)
    return False

def start(factory, job):
    root = str(Path(factory.pm.job_dir(job)).resolve())
    with _guard:
        task = _tasks.get(root)
        if (task and task['thread'].is_alive()) or is_running(root):
            return False
        task = {'result': None, 'error': None}
        def work():
            try:
                task['result'] = factory.run_job(job, progress_cb=None)
            except Exception as error:
                task['error'] = str(error)
        # Keep the Python/Studio process alive while production owns work. Browser
        # tabs may close without cancelling it; durable state still supports a
        # later Resume if the whole Studio process is force-stopped.
        task['thread'] = threading.Thread(target=work, name='autovideo-'+job[-12:], daemon=False)
        _tasks[root] = task
        task['thread'].start()
    return True

def snapshot(root):
    root = Path(root).resolve()
    task = _tasks.get(str(root), {})
    running = bool(task.get('thread') and task['thread'].is_alive()) or is_running(root)
    try:
        progress = json.loads((root/'logs/progress.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        progress = {}
    # Read a bounded tail even for multi-day jobs.
    try:
        with (root/'logs/runtime.log').open('rb') as handle:
            handle.seek(0, 2)
            handle.seek(max(0, handle.tell()-24000))
            logs = handle.read().decode('utf-8', errors='replace').splitlines()[-40:]
    except OSError:
        logs = []
    return {'running': running, 'progress': progress, 'logs': logs,
            'result': task.get('result'), 'error': task.get('error')}

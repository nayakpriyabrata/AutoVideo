"""v7.0.100: the job reference people type is accepted, and a wrong one explains itself.

Field case (2026-10-26, job 20261022-143856-7-small-daily-habits-tha-9729): the recovery commands were run with
the folder pasted in, so the Factory's own ``outputs/`` prefix produced

    FileNotFoundError: .../outputs/outputs/20261022-143856-.../production_manifest.json

The same happened with a trailing slash, and the traceback never named the fix. These tests pin the accepted
shapes, the guidance for an unknown one, and that the CLI hands the Factory the bare id.

No browser, no Flow request, no credits.
"""
import json

import pytest

from engine import job_ref
from engine.job_ref import job_lookup_error, normalize_job_id

JOB = '20261022-143856-7-small-daily-habits-tha-9729'


@pytest.fixture()
def root(tmp_path):
    outputs = tmp_path / 'outputs'
    job = outputs / JOB
    job.mkdir(parents=True)
    (job / 'production_manifest.json').write_text('{"job_id": "%s"}' % JOB)
    (outputs / '20261001-090000-older-job-abcd').mkdir()
    return outputs


@pytest.mark.parametrize('value', [
    JOB,
    JOB + '/',
    'outputs/' + JOB,
    'outputs/' + JOB + '/',
    './outputs/' + JOB,
    'outputs//' + JOB,
])
def test_every_common_job_reference_shape_resolves_to_the_bare_id(root, value):
    assert normalize_job_id(value, str(root)) == JOB


def test_a_windows_style_path_resolves(root):
    windows = 'C:\\Users\\eiyanpr\\Downloads\\Auto\\AutoVideoAI-v7\\outputs\\' + JOB
    assert normalize_job_id(windows, str(root)) == JOB


def test_an_absolute_path_to_the_job_folder_resolves(root):
    assert normalize_job_id(str(root / JOB), str(root)) == JOB
    assert normalize_job_id('"' + str(root / JOB) + '"', str(root)) == JOB


def test_a_double_outputs_prefix_is_forgiven(root):
    """The exact shape that failed in the field: the app added its own outputs/ to a pasted path."""
    assert normalize_job_id('outputs/outputs/' + JOB, str(root)) == JOB


def test_a_double_outputs_prefix_with_a_typo_still_explains_itself(root):
    assert normalize_job_id('outputs/outputs/does-not-exist', str(root)) == 'does-not-exist'
    with pytest.raises(ValueError) as error:
        normalize_job_id('outputs/outputs/does-not-exist', str(root), strict=True)
    message = str(error.value)
    assert 'becomes outputs/outputs/' in message
    assert JOB in message                      # the ids that do exist are listed


def test_an_unknown_id_lists_what_does_exist(root):
    with pytest.raises(ValueError) as error:
        normalize_job_id('outputs/does-not-exist', str(root), strict=True)
    message = str(error.value)
    assert 'No saved job for' in message
    assert '<job-id>' in message               # the shape of a correct command
    assert JOB in message and 'older-job' in message


def test_an_empty_outputs_folder_says_where_to_run_from(tmp_path):
    empty = tmp_path / 'nothing-here'
    empty.mkdir()
    message = job_lookup_error('x', str(empty))
    assert '--outputs-root' in message and str(empty) in message


def test_an_empty_reference_is_reported(root):
    with pytest.raises(ValueError):
        normalize_job_id('   ', str(root), strict=True)
    assert normalize_job_id('   ', str(root)) == ''      # the CLI hands it on; the Factory reports it


# ----------------------------------------------------------------- the CLI hands over the bare id

class _StubFactory:
    last = None

    def __init__(self, *args, **kwargs):
        pass

    def recover_flow_video(self, job_id, **kwargs):
        _StubFactory.last = ('recover', job_id, kwargs)
        return {'ok': True}

    def approve_flow_request(self, job_id, **kwargs):
        _StubFactory.last = ('approve', job_id, kwargs)
        return {'ok': True}


@pytest.fixture()
def cli_in(root, monkeypatch):
    import os
    import cli
    from engine import factory as factory_module
    monkeypatch.setattr(factory_module, 'Factory', _StubFactory)
    monkeypatch.chdir(root.parent)
    _StubFactory.last = None
    return cli


def test_the_cli_strips_a_pasted_folder_from_recover_flow_video(cli_in):
    cli_in.main_v3(['recover-flow-video', 'outputs/' + JOB + '/', '--shot-id', 'shot_014'])
    kind, job_id, kwargs = _StubFactory.last
    assert (kind, job_id) == ('recover', JOB)
    assert kwargs['shot_id'] == 'shot_014'


def test_the_cli_strips_a_pasted_folder_from_approve_request(cli_in):
    cli_in.main_v3(['approve-request', 'outputs/' + JOB, '--shot-id', 'shot_014', '--confirm-credits', '5'])
    kind, job_id, kwargs = _StubFactory.last
    assert (kind, job_id) == ('approve', JOB)
    assert kwargs['confirm_credits'] == 5


def test_the_cli_never_blocks_offline_commands_with_a_reference_it_cannot_resolve(cli_in):
    """Offline commands must keep working; the friendly message belongs to the loader, not the parser."""
    cli_in.main_v3(['recover-flow-video', 'outputs/typo-job'])
    kind, job_id, _ = _StubFactory.last
    assert (kind, job_id) == ('recover', 'typo-job')      # reduced to the last component, unchanged otherwise


def test_the_factory_reports_an_unknown_job_instead_of_a_traceback(tmp_path, monkeypatch):
    from engine.factory import Factory
    monkeypatch.setattr(Factory, '_settings', lambda self, job_id: {})
    factory = Factory.__new__(Factory)

    class Manager:
        root = str(tmp_path / 'outputs')

        def load_manifest(self, job_id):
            raise FileNotFoundError('missing')

    factory.pm = Manager()
    with pytest.raises(ValueError) as error:
        Factory.recover_flow_video(factory, 'not-a-job', shot_id='shot_014')
    message = str(error.value)
    assert 'No saved job for' in message
    assert 'nothing was opened or downloaded' in message


def test_the_queued_generation_is_named_in_the_no_video_message():
    from pathlib import Path
    source = Path('engine/factory.py').read_text(encoding='utf-8')
    assert 'queued because of high demand' in source
    assert 'waiting costs no credits' in source

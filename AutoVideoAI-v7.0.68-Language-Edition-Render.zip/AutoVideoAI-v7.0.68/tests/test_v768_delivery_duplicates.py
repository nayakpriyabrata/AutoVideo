"""v7.0.68 cross-channel duplicate guard, exercised with generated synthetic videos.

Identical bytes approved or scheduled for another account are blocked. Re-encoded
near-duplicates need explicit acknowledgment. Scheduling re-checks both.
"""
import shutil
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

pytestmark = pytest.mark.skipif(shutil.which('ffprobe') is None, reason='ffprobe unavailable')


def _gen(path, source, *extra):
    from engine.render.ffmpeg_renderer import ffmpeg_exe
    subprocess.run([ffmpeg_exe(), '-y', '-v', 'error', '-f', 'lavfi', '-i', source, '-t', '4', '-an',
                    *extra, '-pix_fmt', 'yuv420p', '-c:v', 'libx264', '-preset', 'veryfast', str(path)],
                   check=True, timeout=300)
    return path


@pytest.fixture
def world(tmp_path, monkeypatch):
    """Run inside a temp repo so 'outputs/' is isolated; provide three sources."""
    monkeypatch.chdir(tmp_path)
    src = {
        'base': _gen(tmp_path / 'base.mp4', 'testsrc=size=540x960:rate=30'),
        'reencoded': _gen(tmp_path / 'reencoded.mp4', 'testsrc=size=540x960:rate=30', '-crf', '40'),
        'other': _gen(tmp_path / 'other.mp4', 'mandelbrot=size=540x960:rate=30'),
    }
    return src


def _export(source, folder, title='Launch'):
    from engine.publishing import export_delivery
    return export_delivery(source, folder, 'youtube_short', language='en', title=title,
                           caption='Caption', description='Description')


def _approve(record_path, account, **kw):
    from engine.publishing import approve_release
    return approve_release(record_path, account_id=account, rights_confirmed=True, facts_reviewed=True,
                           language_reviewed=True, made_for_kids=False, ai_disclosure_required=False, **kw)


def _twin(record, folder, identifier):
    """Identical bytes, separate release record: the same file uploaded from a second folder."""
    from engine.production import save
    from engine.publishing import _write_upload_packet
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    video = folder / (identifier + '.mp4')
    shutil.copy(record['video'], video)
    twin = dict(record, id=identifier, video=str(video), state='REVIEW_REQUIRED', account_id='')
    for key in ('approval_sha256', 'duplicate_review', 'editorial_evidence', 'publish_at'):
        twin.pop(key, None)
    release = folder / (identifier + '.release.json')
    save(release, twin)
    _write_upload_packet(twin, release)
    return release


def _record_path(record):
    return Path(record['video']).with_suffix('.release.json')


def test_identical_bytes_for_another_account_are_blocked(world):
    from engine.production import read
    first = _export(world['base'], 'outputs/deliveries/a')
    _approve(_record_path(first), 'channel-one')
    twin = _twin(first, 'outputs/deliveries/b', 'twin')
    with pytest.raises(ValueError, match='Identical video is already approved or scheduled for another account'):
        _approve(twin, 'channel-two')
    assert read(twin)['state'] == 'REVIEW_REQUIRED'


def test_identical_bytes_for_the_same_account_are_allowed(world):
    first = _export(world['base'], 'outputs/deliveries/a')
    _approve(_record_path(first), 'channel-one')
    twin = _twin(first, 'outputs/deliveries/b', 'twin')
    assert _approve(twin, 'channel-one')['state'] == 'APPROVED_FOR_MANUAL_UPLOAD'


def test_near_duplicate_needs_acknowledgment_then_is_recorded(world):
    from engine.production import read
    first = _export(world['base'], 'outputs/deliveries/a')
    _approve(_record_path(first), 'channel-one')
    variant = _export(world['reencoded'], 'outputs/deliveries/b', title='Launch variant')
    with pytest.raises(ValueError, match='Near-duplicate of approved or scheduled delivery'):
        _approve(_record_path(variant), 'channel-two')
    assert read(_record_path(variant))['state'] == 'REVIEW_REQUIRED'
    approved = _approve(_record_path(variant), 'channel-two', acknowledge_duplicate_warning=True)
    review = approved['duplicate_review']
    assert review['acknowledged'] is True
    assert [row['id'] for row in review['matches']] == [first['id']]
    assert review['matches'][0]['mean_hamming'] <= 10
    assert read(_record_path(variant))['duplicate_review']['acknowledged'] is True


def test_unrelated_content_raises_no_warning(world):
    first = _export(world['base'], 'outputs/deliveries/a')
    _approve(_record_path(first), 'channel-one')
    other = _export(world['other'], 'outputs/deliveries/b', title='Different')
    approved = _approve(_record_path(other), 'channel-two')
    assert 'duplicate_review' not in approved


def test_approval_without_matches_keeps_fingerprint_contract(world):
    from engine.publishing import _approval_fingerprint, schedule_release
    record = _approve(_record_path(_export(world['base'], 'outputs/deliveries/a')), 'channel-one')
    assert _approval_fingerprint(record) == record['approval_sha256']
    when = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
    assert schedule_release(_record_path(record), when)['state'] == 'SCHEDULED_MANUAL_REMINDER'


def test_schedule_blocks_identical_bytes_that_appeared_after_approval(world):
    from engine.production import read, save
    from engine.publishing import schedule_release
    first = _export(world['base'], 'outputs/deliveries/a')
    approved = _approve(_record_path(first), 'channel-one')
    twin = _twin(first, 'outputs/deliveries/b', 'twin')
    record = read(twin)
    record.update(state='SCHEDULED_MANUAL_REMINDER', account_id='channel-two')
    save(twin, record)  # a record written outside this approval path
    when = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
    with pytest.raises(ValueError, match='Identical video is now approved or scheduled'):
        schedule_release(_record_path(approved), when)


def test_schedule_requires_review_for_a_new_near_duplicate(world):
    from engine.production import read, save
    from engine.publishing import schedule_release
    first = _export(world['base'], 'outputs/deliveries/a')
    approved = _approve(_record_path(first), 'channel-one')
    variant = _export(world['reencoded'], 'outputs/deliveries/b', title='Variant')
    record = read(_record_path(variant))
    record.update(state='APPROVED_FOR_MANUAL_UPLOAD', account_id='channel-two')
    save(_record_path(variant), record)  # appeared after the first approval
    when = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
    with pytest.raises(ValueError, match='new near-duplicate delivery appeared'):
        schedule_release(_record_path(approved), when)


def test_candidate_outside_active_states_does_not_block(world):
    from engine.production import read, save
    first = _export(world['base'], 'outputs/deliveries/a')
    twin = _twin(first, 'outputs/deliveries/b', 'twin')
    record = read(twin)
    record['account_id'] = 'channel-two'  # still REVIEW_REQUIRED: not approved, not scheduled
    save(twin, record)
    assert _approve(_record_path(first), 'channel-one')['state'] == 'APPROVED_FOR_MANUAL_UPLOAD'


def test_missing_candidate_video_is_reported_and_does_not_block(world):
    first = _export(world['base'], 'outputs/deliveries/a')
    _approve(_record_path(first), 'channel-one')
    Path(first['video']).unlink()
    variant = _export(world['reencoded'], 'outputs/deliveries/b', title='Variant')
    approved = _approve(_record_path(variant), 'channel-two')
    assert approved['duplicate_review']['skipped'][0]['reason'] == 'video file missing'


def test_fingerprint_cache_avoids_recomputing_frames(world, monkeypatch):
    from engine import delivery_duplicates as dd
    video = _export(world['base'], 'outputs/deliveries/a')['video']
    first = dd.fingerprint(video)
    def boom(*a, **kw):
        raise AssertionError('frames recomputed despite a valid cache')
    monkeypatch.setattr(dd, '_frame_hash', boom)
    again = dd.fingerprint(video)
    assert again['frames'] == first['frames'] and again['sha256'] == first['sha256']


def test_changed_video_invalidates_the_cache(world):
    from engine import delivery_duplicates as dd
    video = Path(_export(world['base'], 'outputs/deliveries/a')['video'])
    before = dd.fingerprint(video)
    replacement = _gen(video.with_suffix('.replacement.mp4'), 'mandelbrot=size=540x960:rate=30')
    shutil.copy(replacement, video)
    after = dd.fingerprint(video)
    assert after['sha256'] != before['sha256']
    assert dd.mean_hamming(before['frames'], after['frames']) > 10


def test_mean_hamming_rejects_mismatched_frame_counts():
    from engine.delivery_duplicates import mean_hamming
    with pytest.raises(ValueError):
        mean_hamming([0, 0], [0, 0])

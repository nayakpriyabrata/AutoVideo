"""v7.0.68: Flow downloads wait until the image or video has fully loaded.

Regression: the downloader opened a tile's Download menu while Flow was still
painting a placeholder, so the download started early and the page closed.
These tests drive the real wait loop with a fake clock, so they never sleep.
"""
from types import SimpleNamespace as NS

import pytest

from engine.providers import flow_browser as fb
from engine.providers.flow_browser import FlowBrowser, FlowBrowserClosedError, FlowUIChanged

TAG_SCRIPT = "el => el.tagName"


class FakeClock:
    """Advances only when the page waits, so the loop's time checks are exact (seconds)."""

    def __init__(self):
        self.now = 0.0

    def monotonic(self):
        return self.now

    def time(self):
        return self.now

    def advance(self, ms):
        self.now += ms / 1000.0


@pytest.fixture
def clock(monkeypatch):
    fake = FakeClock()
    monkeypatch.setattr(fb, "time", fake)
    return fake


def _browser(clock, state_for_poll, *, error=None):
    """A browser whose tile answers poll N with state_for_poll(N) (or raises error)."""
    polls = []

    def evaluate(script, timeout=None):
        polls.append(clock.now)
        if error is not None:
            raise error
        return state_for_poll(len(polls) - 1)

    tile = NS(evaluate=evaluate)
    page = NS(wait_for_timeout=lambda ms: clock.advance(ms))
    browser = FlowBrowser.__new__(FlowBrowser)
    browser._page = page
    browser._looks_like_browser_closed_error = lambda exc: "has been closed" in str(exc)
    return browser, tile, polls


LOADING = {"ready": False, "src": "placeholder"}


def test_download_waits_for_placeholder_to_become_the_loaded_file(clock):
    def state(n):
        if n < 3:
            return LOADING                                  # placeholder
        if n == 3:
            return {"ready": True, "src": "360p-thumb"}     # thumbnail is decoded
        return {"ready": True, "src": "full-res"}           # real file swaps in
    browser, tile, polls = _browser(clock, state)
    browser._wait_for_media_ready(tile, "image", timeout_s=60)
    # Polls are 0.5 s apart. The full-res source first appears at t=2.0 s and must
    # stay stable for 2 s, so the download may start at t=4.0 s, never earlier.
    assert clock.now == 4.0
    assert polls[-1] == 4.0


def test_download_never_starts_while_media_is_still_loading(clock):
    browser, tile, _ = _browser(clock, lambda n: LOADING)
    with pytest.raises(FlowUIChanged, match="still loading after 20s"):
        browser._wait_for_media_ready(tile, "video", timeout_s=20)
    assert clock.now >= 20


def test_a_changing_source_restarts_the_stability_window(clock):
    browser, tile, _ = _browser(clock, lambda n: {"ready": True, "src": "a" if n % 2 else "b"})
    with pytest.raises(FlowUIChanged, match="still loading"):
        browser._wait_for_media_ready(tile, "image", timeout_s=5)


def test_closed_page_during_load_wait_is_reported_as_closed(clock):
    browser, tile, _ = _browser(clock, lambda n: LOADING,
                                error=RuntimeError("Target page, context or browser has been closed"))
    with pytest.raises(FlowBrowserClosedError):
        browser._wait_for_media_ready(tile, "video", timeout_s=20)


def test_viewer_wait_polls_until_media_appears_then_waits_for_it(clock):
    picks = [-1, -1, 0]        # the viewer has no media for two polls, then a video
    checked = []

    def element_evaluate(script, timeout=None):
        if script == TAG_SCRIPT:
            return "VIDEO"
        checked.append(script)
        return {"ready": True, "src": "viewer"}

    video = NS(evaluate=element_evaluate)
    page = NS(evaluate=lambda script: picks.pop(0),
              locator=lambda selector: NS(nth=lambda index: video),
              wait_for_timeout=lambda ms: clock.advance(ms))
    browser = FlowBrowser.__new__(FlowBrowser)
    browser._page = page
    browser._looks_like_browser_closed_error = lambda exc: False
    browser._wait_for_largest_media_ready(timeout_s=30)
    assert picks == []
    assert checked, "the selected viewer video must be checked for readiness"


def test_viewer_without_any_media_refuses_instead_of_downloading(clock):
    page = NS(evaluate=lambda script: -1, wait_for_timeout=lambda ms: clock.advance(ms))
    browser = FlowBrowser.__new__(FlowBrowser)
    browser._page = page
    browser._looks_like_browser_closed_error = lambda exc: False
    with pytest.raises(FlowUIChanged, match="No visible image or video"):
        browser._wait_for_largest_media_ready(timeout_s=3)

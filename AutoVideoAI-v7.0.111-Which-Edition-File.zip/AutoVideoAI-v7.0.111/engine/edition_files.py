"""Which language video is the current one, and what did it actually burn? (v7.0.111)

Field report: after switching the Odia transcript off and rendering again, the Odia video that was played still had
the same Odia captions.

The render itself was right - ``production/language_editions_render.json`` recorded ``"captions": false`` and the
new export was written without captions. What was missing was any way to tell **which** file had just been made.
Every render deliberately keeps the previous export in its own ``language_editions/<stamp>/exports/`` folder, so a
job accumulates several videos per language. The old Odia export - the one with the burned captions - stayed on
disk next to the new one with an equally plausible name, and nothing in the app or the CLI said which was current.

This module answers three questions for every edition, from evidence already on disk:

* **which file is current** - the recorded export, its time, and whether its bytes still match the record;
* **what it burned** - ``captions_burned`` from the export's own ``.provenance.json`` (written by the renderer
  since 7.0.107), falling back to the plan's ``captions`` flag for exports that predate provenance;
* **what else is in the job** - every older export of that language, marked superseded, so a stale file can never
  be mistaken for the new one.

Nothing is rendered, copied or deleted here; it only reads.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

SCHEMA = 'edition-files-v1'

#: Where finished editions live. ``language_editions`` is the automatic renderer, ``finishing`` is a plan built by
#: hand in Finishing Studio, ``primary_branding`` is the branded primary-language master.
EXPORT_ROOTS = ('language_editions', 'finishing', 'primary_branding')


def _read(path, default=None):
    try:
        path = Path(path)
        if not path.is_file():
            return default
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


def _stamp(path):
    """A local, human-readable time for a file that the user is about to go and open."""
    try:
        moment = time.localtime(Path(path).stat().st_mtime)
    except OSError:
        return ''
    return time.strftime('%Y-%m-%d %H:%M', moment)


def _short(digest):
    return str(digest or '')[:12]


def provenance_for(export):
    """The renderer's own record for one export, or ``{}`` when it predates provenance."""
    return _read(Path(str(export)).with_suffix('.provenance.json'), {}) or {}


def captions_state(export):
    """What this exact file burned, and how confidently that is known.

    ``burned`` is True/False when the export's provenance says so, and None when it cannot be established (an
    export from before 7.0.107). ``planned`` is the plan's request, which is evidence but not proof: a plan can be
    rendered after the job's transcript setting changed, so it is reported separately and never presented as
    what the viewer sees.
    """
    export = Path(export)
    prov = provenance_for(export)
    plan = _read(export.parents[1] / 'plan.json', {}) if export.parent.is_dir() else {}
    planned = bool(plan.get('captions')) if isinstance(plan, dict) and 'captions' in plan else None
    if 'captions_burned' in prov:
        return {'burned': bool(prov.get('captions_burned')), 'source': 'provenance',
                'planned': planned,
                'from_reviewed_script': bool(prov.get('captions_from_reviewed_script')),
                'from_correction': bool(prov.get('captions_from_correction')),
                'suppressed': str(prov.get('captions_suppressed') or ''),
                'note': str(prov.get('captions_note') or '')}
    return {'burned': None, 'source': 'unknown', 'planned': planned,
            'from_reviewed_script': None, 'from_correction': None, 'suppressed': '', 'note': ''}


def _describe(export, *, verify=False):
    export = Path(export)
    from . import finishing_studio as finish
    try:
        size = export.stat().st_size
    except OSError:
        size = 0
    row = {'path': str(export), 'exists': export.is_file(), 'bytes': size, 'exported_at': _stamp(export),
           'sha256': '', 'sha256_short': '', 'sha256_ok': None, 'captions': captions_state(export),
           'language': _export_language(export)}
    if verify and row['exists']:
        try:
            digest = finish._hash(export)
            row['sha256'] = digest
            row['sha256_short'] = _short(digest)
        except OSError:
            pass
    return row


def _export_language(path):
    """The language code an export belongs to, from its ``<code>-<stamp>.mp4`` name."""
    stem = Path(path).stem
    return stem.split('-', 1)[0]


def scan_exports(job_root):
    """Every finished edition video in the job, grouped by language, newest last."""
    job_root = Path(job_root)
    found = []
    for root in EXPORT_ROOTS:
        base = job_root / root
        if not base.is_dir():
            continue
        for path in sorted(base.glob('*/exports/*.mp4')):
            name = path.name
            if '.copying' in name or '.superseded' in name or name.startswith('.'):
                continue
            found.append(path)
    return found


def _record(job_root):
    return _read(Path(job_root) / 'production' / 'language_editions_render.json', {}) or {}


def _requested(job_root, code):
    from .language_editions import requested_languages, transcript_for
    _source, extra, state = requested_languages(job_root)
    if state is None or code not in extra:
        return None
    return transcript_for(state, code)


def report(job_root, *, language=None, verify=False):
    """The current file per edition, what it burned, and every older file that is not current.

    ``verify`` re-hashes the current export; the dashboard leaves it off (a panel rerun must not re-read every
    video), the CLI turns it on.
    """
    job_root = Path(job_root).resolve()
    from .language_editions import requested_languages
    source, extra, state = requested_languages(job_root)
    record = _record(job_root)
    editions = {}
    problems = []
    requested_languages_list = ([language] if language else
                                list(extra) + ([source] if source and record.get('primary') else []))
    for code in requested_languages_list:
        entry = (record.get('editions') or {}).get(code) or {}
        if not entry and code == source:
            entry = record.get('primary') or {}
        current_path = str(entry.get('path') or '')
        current = None
        if current_path and Path(current_path).is_file():
            current = _describe(current_path, verify=verify)
            if verify and entry.get('sha256') and current.get('sha256') and current['sha256'] != entry['sha256']:
                current['sha256_ok'] = False
            elif verify and entry.get('sha256'):
                current['sha256_ok'] = True
            copy_path = str(entry.get('render_copy') or '')
            current['render_copy'] = copy_path if copy_path and Path(copy_path).is_file() else ''
            current['render_copy_error'] = str(entry.get('render_copy_error') or '')
            from . import finishing_studio as finish
            current['render_copy_matches'] = None
            if current['render_copy'] and current['exists']:
                if verify:
                    try:
                        current['render_copy_matches'] = (finish._hash(current['render_copy']) ==
                                                          finish._hash(current_path))
                    except OSError:
                        current['render_copy_matches'] = None
                else:
                    # A panel rerun must not re-read two videos. A different size is already proof that the
                    # copy is not this export; equal sizes are reported as "not checked", never as a match.
                    try:
                        current['render_copy_matches'] = (Path(current['render_copy']).stat().st_size ==
                                                          Path(current_path).stat().st_size) or False
                    except OSError:
                        current['render_copy_matches'] = None
                    if current['render_copy_matches']:
                        current['render_copy_matches'] = None
        elif current_path:
            problems.append(_label(code) + ' is recorded as exported, but its file is missing: ' + current_path +
                            '. Render that language again from the job panel.')
        older = []
        for path in scan_exports(job_root):
            if _export_language(path) != code or str(path) == current_path:
                continue
            row = _describe(path, verify=False)
            row['superseded'] = True
            row['superseded_by'] = current_path
            older.append(row)
        requested = _requested(job_root, code)
        row = {'language': code, 'label': _label(code), 'requested_transcript': requested,
               'current': current, 'older': older, 'problems': []}
        if current is not None:
            burned = (current.get('captions') or {}).get('burned')
            if requested is False and burned is True:
                row['problems'].append(
                    _label(code) + ' is the current export and it still has burned captions, although this job '
                    'now asks for no transcript in ' + _label(code) + '. Render that language again; the new file '
                    'is written next to this one and this one is kept as the earlier version.')
            if requested is True and burned is False:
                row['problems'].append(
                    _label(code) + ' is the current export and it has no burned captions, although this job asks '
                    'for a transcript in ' + _label(code) + '. Render that language again to burn it.')
            if current.get('render_copy_matches') is False:
                row['problems'].append(
                    'The copy in render/ (' + Path(current['render_copy']).name + ') is not the current export. '
                    'Watch ' + current['path'] + ' instead, or close the player that has the copy open and render '
                    'again so it is replaced.')
            elif current.get('render_copy_error'):
                row['problems'].append('The copy in render/ could not be updated: '
                                       + current['render_copy_error'])
            if burned is True and older:
                row['problems'].append(
                    'Older ' + _label(code) + ' videos in this job are not current; some of them still have the '
                    'captions you switched off. The current one is ' + current['path'] + '.')
        elif older:
            row['problems'].append(_label(code) + ' has no current export, only earlier files. Render that '
                                                  'language again.')
        editions[code] = row
        problems.extend(row['problems'])
    return {'schema': SCHEMA, 'job': str(job_root), 'source_language': source, 'editions': editions,
            'problems': problems}


def _label(code):
    try:
        from .languages import LANGUAGES
        return LANGUAGES[str(code)].label
    except Exception:
        return str(code)


def summary(job_root, *, verify=False):
    """One line per extra language: the file to watch and whether it has captions."""
    data = report(job_root, verify=verify)
    lines = []
    for code, row in data['editions'].items():
        current = row.get('current') or {}
        if not current.get('path'):
            lines.append(row['label'] + ': no current video yet')
            continue
        burned = (current.get('captions') or {}).get('burned')
        state = 'captions: yes' if burned else ('captions: no' if burned is False else 'captions: unknown')
        watch = current.get('render_copy') or current['path']
        lines.append(row['label'] + ': ' + state + ' · ' + Path(watch).name + ' · ' + current.get('exported_at', '')
                     + ' · ' + ('copy in render/ is current' if current.get('render_copy_matches')
                                else 'watch the export path, not the copy'))
    return lines


def format_report(data):
    """A readable listing: the file to watch, what it burned, and what is stale."""
    lines = []
    for code, row in (data.get('editions') or {}).items():
        current = row.get('current') or {}
        lines.append(row['label'] + ' (' + code + ')')
        if not current.get('path'):
            lines.append('  no current video for this language yet')
            for old in row.get('older') or []:
                lines.append('  earlier file (not current): ' + old['path'])
            continue
        watch = current.get('render_copy') or current.get('path')
        lines.append('  watch: ' + watch)
        if current.get('render_copy') and current.get('render_copy_matches') is False:
            lines.append('  ! the copy in render/ is NOT the current export; watch: ' + current['path'])
        if current.get('path') != watch:
            lines.append('  export: ' + current['path'])
        captions = current.get('captions') or {}
        burned = captions.get('burned')
        state = ('burned captions: yes' if burned else
                 'burned captions: no' if burned is False else 'burned captions: unknown')
        detail = captions.get('source')
        if captions.get('from_correction'):
            detail += ', from your corrected transcript'
        elif captions.get('from_reviewed_script'):
            detail += ', from the reviewed script'
        if captions.get('suppressed'):
            detail += ', suppressed: ' + captions['suppressed']
        lines.append('  ' + state + ' (' + detail + ') · ' + str(current.get('exported_at') or '') +
                     (' · sha ' + current['sha256_short'] if current.get('sha256_short') else ''))
        for old in row.get('older') or []:
            old_burned = (old.get('captions') or {}).get('burned')
            mark = 'burned captions: yes' if old_burned else (
                'burned captions: no' if old_burned is False else 'burned captions: unknown')
            lines.append('  earlier file (NOT current): ' + old['path'] + ' · ' + mark + ' · ' +
                         str(old.get('exported_at') or ''))
        for problem in row.get('problems') or []:
            lines.append('  ! ' + problem)
    return lines

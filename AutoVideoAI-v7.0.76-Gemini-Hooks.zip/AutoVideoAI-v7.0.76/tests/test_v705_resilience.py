import builtins
import json
from pathlib import Path
from types import SimpleNamespace as NS
import wave
import pytest


def test_original_music_is_playable_without_browser(tmp_path, monkeypatch):
    from engine.audio.music_provider import ensure_background_music
    import subprocess
    monkeypatch.setattr(subprocess, 'run', lambda *a, **k: pytest.fail('No browser or network subprocess expected'))
    result = ensure_background_music('soft', str(tmp_path), mode='generated')
    with wave.open(result['path']) as audio:
        assert audio.getnchannels() == 2 and audio.getframerate() == 48000
        assert audio.getnframes()/audio.getframerate() == 32
        assert any(audio.readframes(48000))
    assert result['source'] == 'local-generated-instrumental' and result['sha256']


def test_measured_runtime_policy_preserves_script_and_rejects_planned_job(tmp_path):
    from engine.factory import Factory
    from engine.project.manifest import Shot
    f = Factory(str(tmp_path/'outputs'), str(tmp_path/'db.sqlite'))
    job = f.create_job('Recreation', target_seconds=169, auto_retime_script=False)
    script = Path(f.pm.job_dir(job))/'script.json';script.write_text('approved wording')
    f.use_measured_narration_runtime(job)
    assert f._settings(job)['narration_runtime_policy'] == 'measured'
    assert script.read_text() == 'approved wording'
    m = f.pm.load_manifest(job);m.shots=[Shot(shot_id='shot_001')];f.pm.save_manifest(m)
    with pytest.raises(ValueError, match='after scene planning'):
        f.use_measured_narration_runtime(job)


def test_multiple_cutaways_per_clip_have_nonoverlapping_context(tmp_path, monkeypatch):
    import engine.broll as b
    source=tmp_path/'source.mp4';source.write_bytes(b'original')
    out=tmp_path/'clip.mp4';out.write_bytes(b'clip')
    ass=tmp_path/'clip.ass';ass.write_text('captions')
    out.with_suffix('.transcript.json').write_text(json.dumps({'words':[
        {'word':f'concept{i}', 'start':i, 'end':i+.5} for i in range(40)]}))
    monkeypatch.setattr(b, '_file_dimensions', lambda *a:(1080,1920))
    monkeypatch.setattr(b, '_fetch_candidates', lambda slots,*a,**k:slots)
    result={'source':str(source),'highlights':[{'output':str(out),'duration':40,'title':'Useful ideas',
                'text':'speech','caption_ass_path':str(ass),'start':0}]}
    _, review=b.prepare_clip_studio_review(result,max_candidates=10,default_duration=2,per_clip=True)
    rows=review['candidates'];assert len(rows)==10
    assert len(set(r['candidate_id'] for r in rows))==10
    assert all(a['start']+a['duration'] <= c['start'] for a,c in zip(rows,rows[1:]))
    assert 'concept' in rows[0]['query'] and rows[0]['query'] != rows[-1]['query']


def test_multiple_approved_cutaways_produce_one_output(tmp_path, monkeypatch):
    import engine.broll as b
    media_files=[tmp_path/f'asset-{i}.mp4' for i in range(3)]
    for i,media in enumerate(media_files): media.write_bytes(f'asset-{i}'.encode())
    rows=[{'candidate_id':str(i),'clip_output':'original.mp4','path':str(media),
            'sha256':b.sha256_file(media),'approved':True,'rights_reviewed':True,'start':i*3,'duration':1} for i,media in enumerate(media_files)]
    monkeypatch.setattr(b,'validate_review_decisions',lambda *a,**k:{'candidates':rows})
    seen=[]
    monkeypatch.chdir(tmp_path)
    def render(candidate):
        seen.append(candidate)
        Path('combined.mp4').write_bytes(b'rendered output')
        return 'combined.mp4'
    monkeypatch.setattr(b,'_render_clip_studio_cutaway',render)
    result=b.apply_clip_studio_review(str(tmp_path/'review.json'))
    assert result['outputs']==['combined.mp4'] and len(seen[0]['cutaways'])==3


def test_mini_reels_optional_xml_dependency_and_safe_fallback(monkeypatch):
    import engine.mini_reels as reels
    original=builtins.__import__
    def no_defused(name,*a,**kw):
        if name.startswith('defusedxml'):raise ImportError('fixture missing dependency')
        return original(name,*a,**kw)
    monkeypatch.setattr(builtins,'__import__',no_defused)
    scope={'__name__':'engine.mini_reels_fallback','__package__':'engine','__file__':reels.__file__}
    exec(compile(Path(reels.__file__).read_text(),reels.__file__,'exec'),scope)
    assert scope['ET'].fromstring(b'<rss><channel/></rss>').tag=='rss'
    for payload in [b'<!DOCTYPE x [<!ENTITY bomb "x">]><x/>', '<rss/>'.encode('utf-16')]:
        with pytest.raises(scope['DefusedXmlException']):scope['ET'].fromstring(payload)


@pytest.mark.parametrize('text,code', [('error while loading shared libraries: libX.so','browser_dependencies_missing'),
    ('ProcessSingleton profile is in use','browser_profile_busy'),('No space left','browser_storage_full')])
def test_music_browser_launch_errors_are_actionable(text,code):
    from engine.providers.web_media_helper import _launch_error_code
    from engine.audio.music_provider import _safe_browser_search_error
    assert _launch_error_code(text)==code
    assert 'Chromium could not start' not in _safe_browser_search_error('AUTOVIDEO_MEDIA_SEARCH='+code)


@pytest.mark.parametrize('repair_passes', [True, False])
def test_rejected_stock_repair_still_requires_qc(tmp_path, monkeypatch, repair_passes):
    from PIL import Image
    from engine.factory import Factory
    from engine.project.manifest import Shot
    from engine.routing.provider_router import ProviderRouter
    import engine.qc.video_qc as qc
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'db.sqlite'))
    job=f.create_job('Octopus',profile='FREE_HYBRID')
    m=f.pm.load_manifest(job)
    image=tmp_path/'opening.jpg';Image.new('RGB',(96,96),'blue').save(image)
    m.shots=[Shot(shot_id='shot_001',provider='stock',gen_duration=4,num_candidates=1,
                  voice_end=4,duration_target=4,opening_frame=str(image))]
    f.pm.save_manifest(m)
    calls=[]
    class Provider:
        def __init__(self,name):self.name=name
        def status(self):return NS(available=True)
        def generate(self,s,compiled,refs,out,*a,**kw):
            calls.append(self.name);Path(out).write_bytes(self.name.encode());return {'path':out,'model':self.name,'credits':0}
    monkeypatch.setattr(f,'_providers',lambda:{name:Provider(name) for name in ['stock','image']})
    def score(*a,**kw):
        passed=len(calls)>1 and repair_passes
        return {'overall':85 if passed else 20,'decision':'ACCEPT' if passed else 'REJECT','failure':'low_motion'}
    monkeypatch.setattr(qc,'analyze_take',score)
    refs=NS(for_shot=lambda *a:{},best_end_frame=lambda *a:None)
    router=NS(budgets={'MAX_RETRIES_PER_SHOT':0})
    f._generate_all(m,f.pm.dirs(job),refs,router,True,False,lambda *a:None,{})
    shot=f.pm.load_manifest(job).shots[0]
    assert calls==['stock','image']
    assert (shot.status=='accepted') is repair_passes
    assert bool(shot.accepted_take) is repair_passes


def test_gemini_image_prompt_uses_real_adapter_signature_and_requires_review(tmp_path, monkeypatch):
    import engine.broll as b
    import engine.providers.gemini_web as gemini
    import engine.providers.image_provider as images
    path=tmp_path/'review.json'
    row={'candidate_id':'cut','query':'salary budgeting','duration':2,'output_width':1080,'output_height':1920}
    path.write_text(json.dumps({'schema_version':1,'workflow':'clip_studio','candidates':[row]}))
    seen=[]
    monkeypatch.setattr(gemini,'gemini_web_generate',lambda system,user:seen.append((system,user)) or 'Illustrate a household budget')
    monkeypatch.setattr(images.ImageProvider,'generate_image',lambda self,s,c,out,v:Path(out).write_bytes(b'image'))
    def attach(p,cid,img):
        report=b.load_review(p);report['candidates'][0].update(approved=False,rights_reviewed=False,decision='pending')
        b._write_json(p,report);return report['candidates'][0]
    monkeypatch.setattr(b,'replace_clip_candidate_asset',attach)
    b.generate_clip_candidate_image(path,'cut')
    assert 'salary budgeting' in seen[0][1]
    saved=b.load_review(path)['candidates'][0]
    assert not saved['approved'] and saved['source']=='gemini-planned-free-provider-image'


def test_mini_reel_local_hold_has_exact_duration_and_preserves_original(tmp_path, ffmpeg_media, ffmpeg_binary):
    import subprocess
    from engine.mini_reel_export import export_short_hold
    from engine.render.ffmpeg_renderer import _probe_av_durations
    source=tmp_path/'flow-eight.mp4'
    result=subprocess.run([ffmpeg_binary,'-y','-v','error','-stream_loop','-1','-i',ffmpeg_media['video'],
                           '-t','8','-c','copy',str(source)],capture_output=True,timeout=30)
    assert result.returncode==0
    before=source.read_bytes()
    out=export_short_hold(source,10)
    assert abs(_probe_av_durations(out)['video']-10) < .15
    assert source.read_bytes()==before and out!=str(source)
    assert export_short_hold(source,8)==str(source.resolve())
    with pytest.raises(ValueError):export_short_hold(source,13)


def test_legacy_free_storyboard_can_be_reviewed_for_repair(tmp_path):
    from PIL import Image
    from engine.factory import Factory
    from engine.project.manifest import Shot
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'db.sqlite'))
    job=f.create_job('Octopus',profile='FREE_HYBRID')
    m=f.pm.load_manifest(job);m.shots=[Shot(shot_id='shot_003',status='failed')];f.pm.save_manifest(m)
    frame=Path(f.pm.dirs(job)['storyboard'])/'shot_003.jpg';Image.new('RGB',(96,96),'blue').save(frame)
    assert f.storyboard_repair_frames(job,'shot_003')==(str(frame),None)

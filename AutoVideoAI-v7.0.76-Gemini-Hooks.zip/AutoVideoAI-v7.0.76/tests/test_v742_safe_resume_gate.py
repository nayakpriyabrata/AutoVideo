import json
from pathlib import Path
import pytest
from engine.flow_resume_safety import check_job, require_safe_job, FlowResumeBlocked


def job(tmp_path):
    root=tmp_path/'job-123'
    root.mkdir(); (root/'production_manifest.json').write_text('{}')
    return root


def test_new_job_without_journals_passes(tmp_path):
    root=job(tmp_path)
    assert check_job(root)['safe_to_generate'] is True
    require_safe_job(root)


def test_pending_always_blocks_even_when_file_exists(tmp_path):
    root=job(tmp_path)
    dest=root/'shot_001_open.jpg'
    dest.write_bytes(b'generated image')
    (root/'shot_001_open.jpg.flow-request.json').write_text(json.dumps({'status':'pending'}))
    with pytest.raises(FlowResumeBlocked): require_safe_job(root)
    assert dest.read_bytes()==b'generated image'


def test_downloaded_does_not_block(tmp_path):
    root=job(tmp_path)
    (root/'frame.jpg.flow-request.json').write_text(json.dumps({'status':'downloaded'}))
    assert check_job(root)['unresolved_count']==0


def test_corrupt_journal_blocks(tmp_path):
    root=job(tmp_path)
    (root/'shot.jpg.flow-request.json').write_text('{not-json')
    assert check_job(root)['unresolved'][0]['state']=='unreadable'


def test_no_modification(tmp_path):
    root=job(tmp_path)
    p=root/'shot.jpg.flow-request.json'
    p.write_text('{"status":"pending"}')
    initial=p.read_bytes()
    check_job(root)
    assert p.read_bytes()==initial

# AutoVideoAI v7.0.19 — bounded image replacement

## Why v7.0.18 still stopped

The recovery-option setters saved their values in settings.json, but the settings loader omitted `flow_local_closing_fallback` and `flow_continue_unresolved_frames`. Resume therefore ran as though these options were off. v7.0.19 adds both to the global and per-job loading paths and tests save → reload → frame generation.

## Upgrade

Stop Studio, the runner and CLI jobs. Extract the new build beside the old one. From the new folder, preview migration and then apply:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.18 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.18 . --apply
```

Keep the old folder. Use the existing Python environment and WSL browser dependencies.

## Recommended command for the existing Debanshi job

```bash
python3 cli.py v3 resume 20261006-121745-debanshi--ai-recreation-4af6 --replace-unresolved-images --image-replacement-limit 30 --local-closing-fallback
```

The choices persist in the job. Subsequent plain Resume uses them.

Recovery now follows this order:

1. Attempt exact recovery of the submitted image and three download-only retries.
2. If still unresolved and image replacement is enabled, reserve one replacement for this image in a durable whole-job ledger.
3. Generate that replacement in a small separate Flow project with the same authored scene prompt and saved character/location references. Its separate request journal is saved before submission. Keep the original main project and original request intact.
4. Validate and save the new image under the scene's expected path. An interrupted replacement is recovered from its own journal on Resume; it does not get another replacement.
5. If closing recovery/replacement still fails, the separately enabled local closing fallback may use that shot's valid opening image as closing guidance. Missing openings/masters or unresolved videos still stop safely.

This explicitly accepts the possibility that the old generation exists but could not be identified, leaving an unused duplicate in Flow. It is replacement, not proof that the original image failed. There is one replacement per image and a maximum of 30 reservations for this whole job. Set a smaller cap with `--image-replacement-limit N` (1–100). Used/reserved slots are not reset by Resume or migration.

Replacement image credit approvals are capped at zero. If Flow asks for paid image credits, this build does not approve them. Normal subsequent video generation retains the job's existing video credit limits. Images use the journaled Agent editor; an unsupported editor stops before submitting a replacement.

If a process dies between reservation and request-journal creation, submission cannot be proven. The reservation blocks another generation rather than risking a second charge/request. Do not delete the ledger or journals to force retries.

Disable future replacements with `--no-replace-unresolved-images`. Existing authorized replacement requests still recover; disabling does not erase them. Disable future closing fallback with `--no-local-closing-fallback`; saved valid guidance remains available.

## GUI

Guided Studio and AI Recreate have an optional **Regenerate an unresolved image once after 3 recovery retries** choice. Queue → Flow recovery behavior lets you save the policy and job-wide cap for an existing job. The private control center has the same choice in its Resume approval; restart it with this build's updated local runner. Paid videos never inherit image replacement permission.

## Verification and limits

Tests cover the real settings loader, three recovery retries, isolated replacement project instructions, original journal preservation, one-time reservations, pending replacement recovery, changed prompt/project rejection, missing journals after interruption, whole-job caps and exclusion of videos. The original production's exact asset remains unidentified. Live generation in the user's WSL/Google account was not performed; this build cannot guarantee that Google UI, network, capacity or QC issues never occur.

See REVIEW_AND_RECOVERY_V7_0_18.md for the script parser, per-request Gemini cleanup, full-portrait cards and source-bound recreation review features retained in this release.

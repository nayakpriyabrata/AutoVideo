# AutoVideoAI v7.0.38 — Storage management and resume recovery

## Install without losing existing work

Stop Studio and its jobs. Keep v7.0.37 until you verify the migration and saved videos.
Extract this release, open its folder, then run:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.37 . --apply
python3 cli.py v3 resume 20261010-141959-7-morning-habits-that-ca-40b7
```

Resume uses saved storyboard frames and pending request journals. No new flags are required.

## Select, preview, download and delete

Open **Gallery & Downloads → Manage saved jobs & clips**.

1. Select jobs or clip output folders. Paused jobs are included.
2. Expand each selection to play its final videos and download MP4s. Unfinished jobs may have no final video.
3. Click **Review complete deletion** to see the selected folders, associated paths and space estimate.
4. Confirm and click **Delete selected work permanently**. Downloading alone does not delete anything.

Whole-job deletion removes the job folder (voice, frames, references, takes, downloads, captions, music copies, B-roll, QC, renders, logs and request journals), its live database entry, named worker profiles, job-named global snapshots and job-folder copies in this installation's migration backups.

A **Clip folder** selection removes every clip batch in that output folder, its exports, blocked clips, caption work, downloaded source cache, B-roll, QC and history reports. If several batches use the same output folder, the review covers all of them. Use separate output folders for batches you want to manage independently. The existing Gallery's **Delete exported video** action remains available for deleting only one MP4 while keeping its work data.

Production must be stopped. Job/clip production now holds cross-process locks, including local editing. Changes after the review invalidate it. Saved jobs or clips that refer to selected media must also be selected, or the source must be retained. Linked directories and open worker profiles are protected. Database failures before commit restore staged folders. An erase failure is reported as incomplete with the remaining paths; it is never reported as freed space.

### Deletion scope

Shared character/music libraries, global upload caches/registries, login profiles, source files outside selected output folders, full database backups, old installation folders and Google Flow projects are retained. This feature cleans the selected local work; it does not remove remote media or every historical backup. After checking migrated jobs and downloading wanted videos, you can separately remove an entire old installation folder to reclaim its duplicate data.

## Resume changes grounded in the supplied log

- The v7.0.37 run did progress from shot 6 to shot 20. Its later pause was a missing location reference, with only 1/2 required attachments verified.
- One exact local reattachment is available on each explicit run/resume, even if an earlier run failed. Browser rebuilds inside the same run do not renew that allowance. Verified successful attachment still resets the failure episode.
- An exhausted in-memory reference marker is renewed on explicit resume too, including a reused browser object.
- Partial attachment errors retain filename and diagnostic details. The prompt remains blocked unless every required reference is verified.
- Download controls no longer wait for page navigation. Exact download events received before a page closes are retained for saving. Recovery does not select unrelated gallery media.
- Resume keeps valid cached storyboard frames instead of revisiting them solely for composition diversity. Existing quality review still flags insufficient diversity.

These changes have offline regression coverage. Live Google Flow/WSL upload, download, network and browser stability remain unverified. No automatic zero-failure claim is made. If a fresh resume still fails, export the support report so it includes the specific reference-upload diagnostics and the current pause state:

```bash
python3 cli.py v3 support-report 20261010-141959-7-morning-habits-that-ca-40b7
```

"""Reject literal uploaded-reference copies; preserve evidence for recovery."""
from pathlib import Path
import hashlib
import json
import uuid


def matching_reference(path, references):
    from PIL import Image, ImageChops, ImageStat, ImageOps
    path = Path(path)
    if not path.is_file():
        return None
    try:
        raw = path.read_bytes()
        with Image.open(path) as im:
            image = ImageOps.exif_transpose(im).convert('RGB')
            aspect = image.width / image.height
            preview = image.resize((96, 96), Image.Resampling.LANCZOS)
        for value in references:
            ref = Path(value)
            if not ref.is_file() or ref.resolve() == path.resolve():
                continue
            if hashlib.sha256(raw).digest() == hashlib.sha256(ref.read_bytes()).digest():
                return str(ref)
            with Image.open(ref) as im:
                original = ImageOps.exif_transpose(im).convert('RGB')
                if abs(original.width / original.height - aspect) > 0.005:
                    continue
                difference = ImageChops.difference(preview, original.resize((96, 96), Image.Resampling.LANCZOS))
                # Very close pixels permit only resizing/JPEG transport changes,
                # not semantic similarity or a character/background resemblance.
                if max(ImageStat.Stat(difference).rms) <= 1.5:
                    return str(ref)
    except (OSError, ValueError):
        return None
    return None


def quarantine_reference_copy(path, references):
    match = matching_reference(path, references)
    if not match:
        return None
    path = Path(path)
    folder = path.parent / 'rejected_reference_copies'
    folder.mkdir(exist_ok=True)
    backup = folder / (path.stem + '-' + uuid.uuid4().hex[:12] + path.suffix)
    path.rename(backup)
    journal = Path(str(path) + '.flow-request.json')
    if journal.is_file():
        try:
            request = json.loads(journal.read_text())
            old = request.get('signature')
            if old:
                request.setdefault('rejected_signatures', []).append(old)
            request.update(signature='', status='pending', reference_copy_rejected=True,
                           rejected_local_backup=str(backup))
            temporary = journal.with_suffix('.tmp')
            temporary.write_text(json.dumps(request, indent=2))
            temporary.replace(journal)
        except (OSError, ValueError):
            # The original journal remains available; generation guards will
            # stop on an unreadable journal rather than assume a new request.
            pass
    return {'path': str(path), 'reference': match, 'backup': str(backup)}

# AutoVideoAI 7.0.22 — browser stability and reference recovery

Upgrade into a fresh folder. Stop all existing Studio/CLI productions before migration:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.21 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.21 . --apply
./dashboard.sh
```

Resume the same saved job from Queue or the usual `python3 cli.py v3 resume JOB_ID`. Accepted takes, cached frames and request journals remain intact. Do not delete journals or associate unrelated media.

## Reference picker recovery

Flow's media picker retains search filters. The adapter clears these before reuse/upload and checks Uploads for the exact content-hashed filename. If a saved upload cannot be selected, it can reattach the byte-identical local reference once per project/reference. This uploads a reference file only; it does not generate an image or approve credits. The recovery reservation survives restarts. If that one recovery still cannot attach, the job retains its state with a clear error rather than selecting a different person. New replacement-image requests now leave an open original composer before creating their reserved replacement project. Existing child journals retain their recorded project URL. Existing image-replacement and opening-image fallback policies continue to apply to submitted image requests; unresolved videos remain download-only.

## Download stability

WSL headed Chromium uses software rendering and avoids background rendering throttling. Video browser-artifact saves now have a 120-second deadline and atomic replacement after video validation. Exact trusted download-URL fallback remains available after artifact failure; invalid/partial files cannot replace an accepted video. Images retain their bounded validated artifact transfer. Browser closure still triggers exact-request recovery, never an automatic replacement video.

These changes mitigate crash and transfer failure paths. They do not establish the cause of every WSL Chromium crash. Low disk space, OS memory pressure, session expiry and provider UI changes still need local diagnostics. No failure-rate guarantee is made.

## Quiet browser (experimental)

Install dependencies in your own WSL installation:

```bash
sudo apt install xvfb xauth x11-utils x11vnc tigervnc-viewer
```

In Settings enable **Quiet browser**, choose **bundled**, and save. Flow, Gemini Web and Flow Music then use headed Chromium on a private Xvfb display. Missing dependencies stop the launch; there is no unexpected visible fallback or CDP attachment. Existing native Linux Flow/Gemini profiles are reused. Flow Music uses a persistent profile under the Linux home directory; the previous repository-local Flow Music profile is preserved and may require a new sign-in.

Use the sidebar **Show quiet browser · same session** button for sign-in or consent. A local password-protected viewer reveals the existing browser. Close only the viewer to hide it again; the browser and production continue. The viewer server listens only on localhost, with private authentication files. No VNC port is exposed through Sites. The hidden display survives CLI exits to avoid interrupting downloads. Disable Quiet browser for subsequent visible sessions; do not terminate Xvfb while jobs are running.

Live hidden-display rendering and signed-in Google downloads require WSL testing. The build environment has no Chromium/Xvfb binaries, so this feature remains experimental.

## Character card crop

Face detection now checks eye evidence to reduce background false positives. When no reliable face is detected the whole photo fits the card. For Debanshi or another difficult photo, expand the character entry, adjust **Card face position** and **Card zoom**, then **Save card face crop**. This only changes the card preview; original reference bytes used by Flow remain unchanged.

## Reviewed script length

Script-first prompts include a word budget and display a warning for short drafts. Reviewed/imported scripts use measured narration duration before scene planning, preserving approved wording. A 73-second narration produces approximately a 73-second video, not a padded 180-second video. Expand and reapprove the script before production if the longer runtime is required. This also applies to saved approved plans that failed at the duration gate before any shots were planned. Existing generated shots are not retimed automatically. Unreviewed generated scripts retain their runtime checks.

## Multiple tabs

Multiple tabs can configure and monitor different jobs. Production runs through one shared slot across installations under the same Linux user, preventing concurrent jobs from fighting over browser profiles or changing process-wide provider settings. A second job waits; a duplicate start of the same job is rejected. True parallel independent Google sessions are not enabled by this release. Frame workers within a production retain their existing isolation and limits.

from pathlib import Path
from types import SimpleNamespace as NS
from threading import Event, get_ident
import io
import json
import pytest
from PIL import Image


@pytest.mark.parametrize('wait_for', ['first_result', 'heartbeat'])
def test_frames_report_before_worker_batch_finishes(tmp_path, monkeypatch, wait_for):
    import engine.providers.flow_browser as module
    import engine.factory as factory_module
    from engine.factory import Factory
    from tests.test_economy_parallel_frames import _shot, _Refs, _ProjectLog, _Browser
    reported = Event()
    heartbeat = Event()
    monkeypatch.setattr(factory_module, '_ECONOMY_FRAME_HEARTBEAT_SECONDS', .01)
    calls = []
    class Provider:
        def __init__(self, **kwargs): self.browser = _Browser('')
        def _ensure(self): return self.browser
        def generate_image(self, shot, compiled, out, vertical, dry_run=False):
            if wait_for == 'heartbeat' and not calls:
                assert heartbeat.wait(3), 'Coordinator must report a worker wait without a finished frame'
            if calls:
                assert reported.wait(2), 'First frame must report while this batch is still running'
            calls.append(shot.shot_id)
            Image.new('RGB', (160, 120), 'blue').save(out)
            return {'path': out}
        def close(self): pass
    monkeypatch.setattr(module, 'FlowBrowserProvider', Provider)
    monkeypatch.setattr(module, 'PROFILE_DIR', str(tmp_path/'absent'))
    monkeypatch.setattr(module, 'resolve_browser_cfg', lambda _: {'mode':'bundled'})
    f=Factory.__new__(Factory); f.pm=_ProjectLog()
    shots=[_shot('shot_001'), _shot('shot_002')]
    tasks=[{'shot':s, 'label':'opening frame', 'prompt':s.shot_id,
            'out':str(tmp_path/f'{s.shot_id}.jpg')} for s in shots]
    main_thread=get_ident()
    def progress(message, percent, *args):
        assert get_ident()==main_thread, 'UI and database reporting belongs on the coordinator thread'
        if 'completed 1/2' in message: reported.set()
        if 'Storyboard waiting' in message: heartbeat.set()
    result=f._generate_economy_frames_parallel(NS(job_id='job',shots=shots), {'root':str(tmp_path)},
        _Refs(), True, {'flow_frame_retries':1}, progress, tasks, 1, 'flow')
    assert len(result)==2 and calls==['shot_001','shot_002']
    if wait_for == 'heartbeat': assert heartbeat.is_set()
    state=json.loads((tmp_path/'.flow-workers/economy_frame_progress.json').read_text())
    assert state['completed']==state['total']==2
    assert len([r for r in f.pm.events if r[1]=='economy_parallel_frame'])==2
    for task in tasks: Path(task['out']).unlink()
    monkeypatch.setattr(module,'FlowBrowserProvider',lambda **kwargs:pytest.fail('Cached frames must not launch a browser'))
    recovered=f._generate_economy_frames_parallel(NS(job_id='job',shots=shots), {'root':str(tmp_path)},
        _Refs(), True, {}, lambda *args:None, tasks, 1, 'flow')
    assert len(recovered)==2 and all(Path(t['out']).is_file() for t in tasks)
    assert all(source=='flow-parallel-recovered' for source in recovered.values())


def _response(body=b'', status=200, headers=None):
    return NS(status_code=status, headers=headers or {}, close=lambda:None,
              raise_for_status=lambda:None, iter_content=lambda size:iter([body]))


def _install_session(monkeypatch, responses):
    import requests
    calls=[]
    class Session:
        trust_env=True
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def get(self,url,**kwargs):
            assert self.trust_env is False and kwargs['allow_redirects'] is False
            assert kwargs['timeout'][1]<=15
            calls.append(url);return responses.pop(0)
    monkeypatch.setattr(requests,'Session',Session)
    return calls


def test_image_save_uses_exact_event_url_without_waiting_on_browser(tmp_path,monkeypatch):
    from engine.providers.flow_browser import FlowBrowser
    data=io.BytesIO();Image.new('RGB',(160,120),'red').save(data,format='JPEG');body=data.getvalue()
    url='https://storage.googleapis.com/flow/exact.jpg?signature=private'
    calls=_install_session(monkeypatch,[_response(body,headers={'Content-Length':str(len(body))})])
    download=NS(url=url,save_as=lambda _:pytest.fail('Unbounded save_as must not run'),
                path=lambda:pytest.fail('Unbounded path must not run'))
    b=FlowBrowser.__new__(FlowBrowser);out=tmp_path/'frame.jpg'
    assert b._save_download_event(download,str(out))==str(out)
    assert out.read_bytes()==body and calls==[url]
    assert list(tmp_path.iterdir())==[out]


@pytest.mark.parametrize('response',[
    _response(b'invalid-image'),
    _response(status=302,headers={'Location':'https://outside.invalid/signed'}),
    _response(b'partial',headers={'Content-Length':'100'}),
])
def test_failed_image_save_preserves_existing_file_and_never_falls_back_to_browser(tmp_path,monkeypatch,response):
    from engine.providers.flow_browser import FlowBrowser,FlowUIChanged
    calls=_install_session(monkeypatch,[response])
    out=tmp_path/'frame.jpg';out.write_bytes(b'accepted existing frame')
    b=FlowBrowser.__new__(FlowBrowser)
    with pytest.raises(FlowUIChanged,match='download-only Resume'):
        b._save_download_event(NS(url='https://storage.googleapis.com/exact',
             save_as=lambda _:pytest.fail('Must retain journal, not wait indefinitely')),str(out))
    assert len(calls)==1 and out.read_bytes()==b'accepted existing frame'
    assert list(tmp_path.iterdir())==[out]


def test_slow_image_stream_expires_and_cleans_up(tmp_path,monkeypatch):
    import engine.providers.flow_browser as module
    clock=[0]
    monkeypatch.setattr(module.time,'monotonic',lambda:clock[0])
    response=_response()
    def chunks(size):
        clock[0]=121
        yield b'late bytes'
    response.iter_content=chunks
    _install_session(monkeypatch,[response])
    assert module.FlowBrowser.__new__(module.FlowBrowser)._save_image_download_url(
        NS(url='https://storage.googleapis.com/exact'),str(tmp_path/'frame.jpg')) is None
    assert not list(tmp_path.iterdir())


def test_maiyaa_is_not_ai_and_named_kanha_keeps_story_identity():
    from engine.planning.story_bible import build_bible
    bible=build_bible('Little kanha helping Yasoda Maiya','kids_story',{})
    assert 'Kanha' in bible['characters'][0]['canonical']
    assert 'Yasoda' in bible['characters'][1]['canonical']
    assert 'Vrindavan' in bible['locations'][0]['canonical']
    assert 'CHARACTER_02' in bible['identity_block']
    assert 'tech studio' not in build_bible('A child helping Maiya','kids_story',{})['identity_block']
    assert 'tech studio' in build_bible('AI helps robotics','education',{})['identity_block']
    from engine.planning.director import create_production_plan
    from engine.project.manifest import ProductionManifest
    from engine.routing.credit_router import CreditRouter
    from tests.conftest import fake_words
    words=fake_words(3,4)
    m=ProductionManifest(job_id='kanha',topic='Little kanha helping Yasoda Maiya',
                         content_type='kids_story',target_seconds=12)
    plan=create_production_plan(m,'Kanha helps his family',words,
        [{'name':'help mother','visual_intent':'Kanha helps his family with their work'}],
        bible,{'shot_length':[4,8]},CreditRouter('LOCAL_FREE'),words[-1]['end'])
    assert all('Vrindavan' in shot.environment for shot in plan.shots)
    assert all('helps his family' in shot.subject_action for shot in plan.shots)


def test_stalled_http_reader_returns_control_and_never_commits_late_bytes(tmp_path,monkeypatch):
    import engine.providers.flow_browser as module
    from threading import Event
    import time
    started=Event();release=Event();finished=Event()
    monkeypatch.setattr(module,'_FLOW_IMAGE_DOWNLOAD_TIMEOUT_S',.05)
    def read(self,url,cancelled):
        started.set()
        try:
            assert release.wait(3)
            return b'late result which must never replace the old file'
        finally: finished.set()
    monkeypatch.setattr(module.FlowBrowser,'_read_image_download_url',read)
    out=tmp_path/'frame.jpg';out.write_bytes(b'preserved old image')
    b=module.FlowBrowser.__new__(module.FlowBrowser)
    try:
        start=time.monotonic()
        assert b._save_image_download_url(NS(url='https://storage.googleapis.com/exact'),str(out)) is None
        assert started.is_set() and time.monotonic()-start<1
        assert out.read_bytes()==b'preserved old image'
    finally:
        release.set()
        assert finished.wait(2)
    assert out.read_bytes()==b'preserved old image' and list(tmp_path.iterdir())==[out]

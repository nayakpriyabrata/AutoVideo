"""Archive one unresolved Flow image journal so that ONE explicit Resume makes ONE new submission.

Used by `cli.py v3 archive-request` and by tools/archive_uncertain_flow_image.py. The journal is renamed,
never deleted, so the old Flow request stays on record. Nothing is submitted by this module.

v7.0.96: an image request costs no Flow credits (config/flow_models.yaml: credits_per_image 0), so an
image journal is archived without any credit confirmation. An explicit archive never counts against the
automatic fresh-request budget.

v7.0.98: a **video** journal is different. Archiving it makes the next Resume submit a new video request,
which spends credits, so it stays a dry run until --confirm-new-credit-spend is given, and the message says
so instead of borrowing the free-image wording. The download-only video recovery is the first thing to try
(`cli.py v3 recover-flow-video`).
"""
from __future__ import annotations

import fcntl
import json
import time
import uuid
from pathlib import Path

from .flow_image_transaction import SCOPES, completed, journal_path
from .isolated_frame_regeneration import image_valid

ALLOWED_PHASES = {'submission_uncertain', 'submitted'}


def free_image_request(request) -> bool:
    """v7.0.96: an isolated single image request costs no Flow credits."""
    return (str(request.get('kind') or '') == 'image'
            and str(request.get('scope') or '') in SCOPES)


def _job_hint(output) -> str:
    parts = Path(output).resolve().parts
    for index in range(len(parts) - 2):
        if parts[index] == 'flow' and parts[index + 1] == 'shots':
            return parts[index - 1] if index else '<job-id>'
    return '<job-id>' 


def archive_uncertain_request(output, confirm_new_credit_spend=False):
    """Return (exit_code, lines). 0 = done or dry run, 2 = refused, nothing changed."""
    output = Path(output).resolve()
    path = journal_path(output)
    if not path.is_file():
        return 0, [f'No open Flow image journal at {path.name}; nothing to archive.']
    try:
        request = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError) as error:
        return 2, [f'REFUSED: the journal cannot be read ({type(error).__name__}). Nothing was changed.']
    phase = str(request.get('phase') or '')
    if phase not in ALLOWED_PHASES:
        return 2, [f'REFUSED: journal phase is {phase!r}; only {sorted(ALLOWED_PHASES)} can be archived.']
    if request.get('status') == 'downloaded' or completed(output, request) or image_valid(output):
        return 2, ['REFUSED: this shot already has a downloaded image; there is nothing to resubmit.']
    for entry in (request.get('capture_probes') or {}).values():
        if entry.get('reference'):  # a known uploaded reference (label or path)
            continue
        if entry.get('file') and image_valid(output.parent / str(entry['file'])):
            return 2, [f'REFUSED: {entry["file"]} is a valid image that is not a classified uploaded reference. '
                       'Recover it instead of resubmitting.']

    lock_path = output.parent / '.production.lock'
    with lock_path.open('a+b') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return 2, ['REFUSED: the job is running (production lock held). Stop it, then retry.']
        stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + '-' + uuid.uuid4().hex[:6]
        archived = output.with_name(output.name + '.flow-request.archived-' + stamp + '.json')
        lines = [f'Journal:  {path.name}',
                 f'Phase:    {phase}  acknowledged={request.get("submission_acknowledged")}',
                 f'Project:  {request.get("project_url")}',
                 f'Archive:  {archived.name}']
        if not confirm_new_credit_spend and not free_image_request(request):
            return 0, lines + [
                f'This is a {str(request.get("kind") or "non-image")} request: archiving it makes the next Resume '
                'submit ONE new generation, which spends Flow credits.',
                'Dry run. Add --confirm-new-credit-spend to archive. Nothing was changed.',
                'Prefer download-only recovery first: python3 cli.py v3 recover-flow-video '
                f'{_job_hint(output)} --wait-seconds 180 (0 credits).']
        path.rename(archived)
        note = ('Archived. Press Resume once: that makes ONE new free image request in a new Flow project.'
                if free_image_request(request) else
                'Archived. Press Resume once: that makes ONE new PAID generation request in a new Flow project.')
        return 0, lines + [note,
                           'Image requests are free in Flow, so no credit approval was needed.'
                           if free_image_request(request) else
                           'Do not press Resume again unless the user approves another credit spend.']

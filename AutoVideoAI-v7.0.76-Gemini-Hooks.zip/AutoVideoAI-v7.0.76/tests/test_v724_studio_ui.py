import json
import subprocess
from types import SimpleNamespace
import pytest
from engine import studio_ui


@pytest.mark.parametrize('value, expected', [(-20,0),(154,100),(42.7,42),('nan',0),(None,0),('invalid',0)])
def test_progress_handles_incomplete_or_invalid_telemetry(value, expected):
    assert studio_ui.progress_percent(value) == expected


def test_settings_accept_old_provider_values():
    assert studio_ui.option_index(['edge','gemini'], 'gemini') == 1
    assert studio_ui.option_index(['edge','gemini'], 'retired') == 0


@pytest.mark.parametrize('failure', ['timeout','invalid','failed'])
def test_cleanup_failure_is_an_actionable_ui_error(monkeypatch, failure):
    def run(*args, **kwargs):
        if failure == 'timeout':
            raise subprocess.TimeoutExpired('cleanup',120)
        return SimpleNamespace(returncode=1 if failure=='failed' else 0,stdout='not json',stderr='Job is busy')
    monkeypatch.setattr(studio_ui.subprocess, 'run', run)
    with pytest.raises(RuntimeError):
        studio_ui.cleanup_report('/outputs')


def test_cleanup_command_rechecks_instead_of_applying_stale_preview(monkeypatch):
    calls=[]
    def run(command, **kwargs):
        calls.append(command)
        return SimpleNamespace(returncode=0,stdout=json.dumps({'freed_bytes':123}),stderr='')
    monkeypatch.setattr(studio_ui.subprocess, 'run', run)
    assert studio_ui.cleanup_report('/outputs',apply=True)['freed_bytes']==123
    assert calls[0][-1]=='--apply'

"""Friendly YAML configuration for the v5.7 Studio and CLI.

The CLI remains the source of truth for execution.  This module gives both the
dashboard and ``create-config`` one validated, reproducible input format.
"""
from __future__ import annotations

import copy
import math
import os
from pathlib import Path
import yaml


DEFAULTS = {
    "topic": "",
    "speech_cards_enabled": False, "gemini_video_count": 0, "flow_auto_cleanup_images": False,
    "production_mode": "youtube_pro",
    "video_type": "faceless_youtube",
    "theme": "motivational",
    "duration": 300,
    "profile": "STORYBOARD_ECONOMY",
    "preset": "cinematic_realism",
    "content_type": "education",
    "tone": "cinematic",
    "language": "en",
    "destination": None,
    "approved_plan_path": "",
    "narration_input_path": "",
    "character_id": "",
    "character_ids": [],
    "voice": "en-IN-PrabhatNeural",
    "script_provider": "auto",
    "card_draft_provider": "gemini-web",
    "hooks_enabled": False,
    "script_model": "auto",
    "script_quality": "publish",
    "gemini_chat_cleanup": "delete-after-read",
    "tts_provider": "auto",
    "tts_model": "",
    "tts_voice": "",
    "tts_style": "",
    "caption_provider": "auto",
    "caption_display": "auto",
    "render_quality": "fast",
    "dynamic_video_scenes": None,
    "stock_scenes": None,
    "stock_source": "auto",
    "broll_count": 0, "broll_duration": 2.0, "broll_max_uses": 1,
    "broll_query_hint": "", "broll_auto": False,
    "background_music": "off",
    "music_mood": "",
    "channel_name": "",
    "channel_logo": "",
    "channel_logo_size": "Medium",
    "graphics_overlays": False,
    "voiceover_enabled": True,
    "text_cards_enabled": None,
    "text_card_style": "auto",
    "background_music_path": "",
    "music_volume": None,
    "sound_effects_enabled": None,
    "ambience_enabled": None,
    "watermark": False,
    "caption_template": "auto",
    "images_per_shot": 2,
    "flow_image_workers": 1,
    "flow_pause_on_unresolved_request": None,
    "video_share": 0.20,
    "stock_share": 0.60,
    "flow_scenes": None,
    "max_flow_scenes": None,
    "frame_source": "auto",
    "flow_video_mode": "frames",
    "flow_approval": "once",
    "flow_project_url": "",
    "flow_reuse_project_media": True,
    "flow_reuse_mode": "exact",
    "max_credits": 100,
    "max_retries": 2,
    "max_generation_credits": 10, "flow_approval_cards": 1,
    "flow_frame_retries": 3,
    "network_wait_seconds": 300,
    "flow_capacity_wait_seconds": 900,
    "flow_capacity_retries": 8,
    "flow_video_retries": 1,
    "flow_video_ready_grace_seconds": 20,
    "flow_video_recovery_wait_seconds": 180,
    "shot_max_seconds": None,
    "dry_run": False,
    "plan_only": False,
}

THEMES = {
    "cinematic": {"content_type":"cinematic_story", "tone":"cinematic", "preset":"cinematic_realism", "music_mood":"joyful cinematic instrumental, no vocals"},
    "kids_cartoon": {"content_type": "kids_story", "tone": "funny", "preset": "cartoon_3d", "music_mood": "playful children instrumental"},
    "devotional_cartoon": {"content_type": "storytelling", "tone": "calm", "preset": "cartoon_3d", "music_mood": "peaceful devotional instrumental"},
    "devotional_real": {"content_type": "documentary", "tone": "calm", "preset": "cinematic_realism", "music_mood": "peaceful devotional instrumental"},
    "motivational": {"content_type": "motivation", "tone": "cinematic", "preset": "cinematic_realism", "music_mood": "soft motivational cinematic instrumental"},
    "cooking": {"content_type": "education", "tone": "exciting", "preset": "cinematic_realism", "music_mood": "light upbeat cooking instrumental"},
    "health": {"content_type": "education", "tone": "documentary", "preset": "cinematic_realism", "music_mood": "clean calm wellness instrumental"},
    "personal_finance": {"content_type": "finance", "tone": "documentary", "preset": "cinematic_realism", "music_mood": "modern confident business instrumental"},
    "personality_development": {"content_type": "motivation", "tone": "cinematic", "preset": "cinematic_realism", "music_mood": "uplifting personal growth instrumental"},
    "ai_learning": {"content_type":"technology","tone":"documentary","preset":"tech_future","music_mood":"light modern instrumental"},
    "self_care": {"content_type":"education","tone":"calm","preset":"cinematic_realism","music_mood":"calm instrumental"},
    "business_ideas": {"content_type":"education","tone":"documentary","preset":"cinematic_realism","music_mood":"light business instrumental"},
    "farming_gardening": {"content_type":"education","tone":"calm","preset":"documentary","music_mood":"gentle nature instrumental"},
    "cartoon_story": {"content_type": "cinematic_story", "tone": "funny", "preset": "cartoon_3d", "music_mood": "whimsical story instrumental"},
}

CHOICES = {
    "channel_logo_size": {"Small", "Medium", "Large"},
    "production_mode": {"legacy", "youtube_pro", "reels_pro"},
    "video_type": {"shorts", "faceless_youtube", "explainer", "marketing"},
    "profile": {"FLOW_CINEMATIC", "FLOW_BALANCED", "FLOW_ECONOMY", "STORYBOARD_ECONOMY", "LOCAL_FREE", "FREE_HYBRID", "MANUAL_DIRECTOR"},
    "script_provider": {"auto", "gemini", "gemini-web", "groq", "openai", "indus", "grok", "ollama", "planner"},
    "card_draft_provider": {"gemini-web", "chatgpt-web", "openai", "indus", "gemini", "groq", "grok", "ollama"},
    "script_quality": {"standard", "high", "publish"},
    "tts_provider": {"auto", "gemini", "gemini-lite", "groq", "elevenlabs", "kokoro", "edge", "gtts", "mock"},
    "caption_display": {"auto", "full", "none"},
    "caption_template": {"auto", "OPUS", "HORMOZI", "MINIMAL", "KIDS", "DOCUMENTARY", "CINEMATIC", "KARAOKE", "TECH"},
    "text_card_style": {"auto", "bold", "playful", "clean"},
    "render_quality": {"preview", "fast", "standard", "high"},
    "frame_source": {"auto", "flow", "free"},
    "flow_video_mode": {"frames", "prompt"},
    "flow_approval": {"once", "manual", "always"},
    "flow_reuse_mode": {"exact", "topic", "project"},
    "gemini_chat_cleanup": {"keep", "delete-after-read"},
}


def _validate_settings(cfg):
    ids=cfg.get('character_ids',[])
    if not isinstance(ids,list) or len(ids)>3 or any(not isinstance(i,str) for i in ids) or len(ids)!=len(set(ids)):
        raise ValueError('character_ids must contain up to three distinct IDs')
    integers = {'duration': (10, 7200), 'flow_image_workers': (1, 3), 'gemini_video_count': (0, 4)}
    for key in ('dynamic_video_scenes', 'stock_scenes', 'flow_scenes', 'max_flow_scenes',
                'images_per_shot', 'max_credits', 'max_retries', 'max_generation_credits',
                'flow_frame_retries', 'network_wait_seconds', 'flow_capacity_wait_seconds',
                'flow_capacity_retries', 'flow_video_retries', 'flow_video_ready_grace_seconds',
                'flow_video_recovery_wait_seconds'):
        integers[key] = (0, None)
    for key, (low, high) in integers.items():
        value = cfg[key]
        if value is None and DEFAULTS[key] is None:
            continue
        if type(value) is not int or value < low or (high is not None and value > high):
            raise ValueError(f'{key} must be a whole number >= {low}' + (f' and <= {high}' if high is not None else ''))
    for key in ('video_share', 'stock_share', 'shot_max_seconds'):
        value = cfg[key]
        if value is None and DEFAULTS[key] is None:
            continue
        if (type(value) not in (int, float) or not math.isfinite(value)
                or (not 0 <= value <= 1 if key.endswith('_share') else value <= 0)):
            raise ValueError(f'{key} must be finite and ' + ('between 0 and 1' if key.endswith('_share') else 'positive'))
    if type(cfg["flow_approval_cards"]) is not int or not 1 <= cfg["flow_approval_cards"] <= 3:
        raise ValueError("flow_approval_cards must be 1–3")
    for key, default in DEFAULTS.items():
        if type(default) is bool or key in ('flow_pause_on_unresolved_request', 'text_cards_enabled',
                                          'sound_effects_enabled', 'ambience_enabled'):
            if cfg[key] is None and default is None:
                continue
            if type(cfg[key]) is not bool:
                raise ValueError(f'{key} must be true or false')


def load_video_config(path: str) -> dict:
    p = Path(path).expanduser().resolve()
    if not p.is_file():
        raise ValueError(f"Configuration file not found: {p}")
    raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        raise ValueError("Video configuration must be a YAML mapping")
    unknown = sorted(set(raw) - set(DEFAULTS))
    if unknown:
        raise ValueError("Unknown configuration option(s): " + ", ".join(unknown))
    cfg = copy.deepcopy(DEFAULTS)
    cfg.update(raw)
    from .broll import BROLL_KEYS,validate_broll_options
    validate_broll_options(**{k:cfg[k] for k in BROLL_KEYS})
    cfg["topic"] = str(cfg.get("topic") or "").strip()
    if not cfg["topic"]:
        raise ValueError("topic is required")
    theme = str(cfg.get("theme") or "motivational")
    if theme not in THEMES:
        raise ValueError(f"Unknown theme {theme!r}. Use one of: {', '.join(THEMES)}")
    # Theme values are defaults, never overrides for explicitly supplied keys.
    for key, value in THEMES[theme].items():
        if key not in raw:
            cfg[key] = value
    mode = str(cfg.get("production_mode") or "youtube_pro")
    if mode == "reels_pro":
        if "video_type" not in raw:
            cfg["video_type"] = "shorts"
        if "duration" not in raw:
            cfg["duration"] = 45
        if "caption_display" not in raw:
            cfg["caption_display"] = "full"
        if "graphics_overlays" not in raw:
            cfg["graphics_overlays"] = True
    for key, values in CHOICES.items():
        if not isinstance(cfg.get(key), str) or cfg.get(key) not in values:
            raise ValueError(f"Invalid {key}: {cfg.get(key)!r}; choose from {sorted(values)}")
    _validate_settings(cfg)
    from .languages import language_pack, default_voice
    cfg['language'] = language_pack(cfg['language']).code
    if 'voice' not in raw:
        cfg['voice'] = default_voice(cfg['language'])
    if cfg['destination']:
        from .publishing import destination_profile
        destination_profile(cfg['destination'])
    for path_key in ('approved_plan_path','narration_input_path'):
        if cfg[path_key]:
            cfg[path_key] = os.fspath((p.parent / Path(cfg[path_key]).expanduser()).resolve())
    from .presentation import resolve_presentation
    presentation = resolve_presentation(cfg)
    if presentation.voiceover and not cfg['narration_input_path']:
        from .languages import check_tts_language
        check_tts_language(cfg['tts_provider'], cfg['language'], cfg['voice'])
    if not presentation.voiceover:
        cfg["caption_display"] = "none"
    if cfg["background_music_path"]:
        music_path = Path(cfg["background_music_path"]).expanduser()
        cfg["background_music_path"] = os.fspath((p.parent / music_path).resolve() if not music_path.is_absolute() else music_path.resolve())
    cfg["production_mode_engine"] = "youtube_pro" if mode == "reels_pro" else mode
    cfg["aspect"] = "9:16" if cfg["video_type"] == "shorts" or mode == "reels_pro" else "16:9"
    cfg["config_source"] = os.fspath(p)
    return cfg


def config_to_factory_kwargs(cfg: dict) -> dict:
    skip = {"topic", "duration", "video_type", "aspect", "theme", "max_credits", "max_retries",
            "plan_only", "config_source", "production_mode_engine"}
    out = {k: v for k, v in cfg.items() if k not in skip}
    out["target_seconds"] = int(cfg["duration"])
    out["production_mode"] = cfg["production_mode_engine"]
    out["budgets"] = {"MAX_CREDITS_PER_VIDEO": int(cfg["max_credits"]),
                      "MAX_RETRIES_PER_SHOT": int(cfg["max_retries"])}
    return out

"""Visual-only story plans: explicit silence, scene timing, no spoken script."""
import json
import math
from .content_plan import validate_plan, script_from_plan

AUDIO_MODES = ('voiceover', 'music_only', 'silent')


def audio_mode(value):
    mode = str(value).strip().lower().replace(' ', '_')
    if mode not in AUDIO_MODES:
        raise ValueError('Choose Voiceover, Music only or Silent')
    return mode


def visual_prompt(topic, seconds, language, mode, style='cinematic story', characters=()):
    mode = audio_mode(mode)
    if mode == 'voiceover':
        raise ValueError('Visual-only planning requires Music only or Silent')
    system = ('Plan an original visual-only video. Return JSON only. Do not generate media. '
              'There is NO narrator, dialogue, spoken text, singing or speech captions. '
              'Describe observable action, framing and camera motion, not poetic narration. '
              'Preserve the requested subject, setting and action throughout; do not turn a dance into an educational explainer.')
    user = (f'Topic: {topic}\nDuration: {seconds}s\nLanguage for descriptions: {language}\n'
            f'Audio mode: {mode}\nTreatment: {style}\nSaved characters: {json.dumps(list(characters), ensure_ascii=False)}\n'
            'Use instrumental music only.' if mode == 'music_only' else
            f'Topic: {topic}\nDuration: {seconds}s\nLanguage for descriptions: {language}\nAudio mode: silent\nTreatment: {style}\nSaved characters: {json.dumps(list(characters), ensure_ascii=False)}\nNo audio.')
    user += ('\nReturn {"narration":"", "scenes":[{"text":"", "visual_intent":"visible action and camera", '
             '"environment":"setting, weather, time of day only", "framing":"shot size", "camera_movement":"camera motion", "duration":6}], "character_suggestions":[]}. '
             f'Use 0.5–30 seconds per scene and make scene durations sum to exactly {seconds} seconds. '
             'Keep narration and every scene text empty. Suggestions may reference only supplied character IDs; a saved character is optional.')
    return system, user


def validated_visual_plan(value, topic, seconds, language, mode):
    if not isinstance(value, dict):
        raise ValueError('Writer did not return a complete visual scene plan')
    plan = validate_plan({**value, 'topic':topic, 'language':language,
        'audio_mode':audio_mode(mode), 'voiceover_enabled':False,
        'approved':True, 'rights':{'declaration':'own_content','adaptation_confirmed':True}})
    total = sum(float(s['duration']) for s in plan['scenes'])
    if abs(total-float(seconds)) > .05:
        raise ValueError(f'Visual scene durations total {total:g}s; requested {seconds:g}s. Correct the scene timing before production.')
    return {**plan, 'runtime_estimate_seconds':total, 'requested_seconds':int(seconds),
            'runtime_warning':'', 'timing_source':'visual_storyboard'}


def generate_visual_script(topic, seconds, language, mode, style, provider='auto', model='auto', quality='high'):
    from .planning.script_engine import auto_provider_order, _provider_available, _default_model, _call_provider, _extract_json
    system, user = visual_prompt(topic, seconds, language, mode, style)
    requested = str(provider or 'auto').lower()
    providers = auto_provider_order() if requested == 'auto' else [requested]
    errors = []
    for name in providers:
        if name == 'planner' or not _provider_available(name):
            continue
        try:
            raw = _call_provider(name, _default_model(name) if model == 'auto' else model, system, user)
            plan = validated_visual_plan(_extract_json(raw),topic,seconds,language,mode)
            script = script_from_plan(plan)
            script['source'] = name + '-visual'
            script['editorial_qc']['scope'] = 'Visual schema and duration checks only; semantic review still required'
            return script
        except Exception as error:
            errors.append(f'{name}: {error}')
            if requested != 'auto':
                raise
    if requested != 'planner' and (requested != 'auto' or quality == 'publish'):
        raise RuntimeError('Visual planning needs an available writer. ' + '; '.join(errors))
    if quality == 'publish':
        raise RuntimeError('Publish-quality visual planning requires an available AI writer')
    count = max(1, math.ceil(float(seconds)/6))
    descriptions = ('Wide establishing view', 'Medium tracking view', 'Close view of the action', 'Smooth moving wide view')
    scenes = [{'text':'', 'visual_intent': f'{descriptions[i%len(descriptions)]}: {topic}. No dialogue, singing or narration.',
               'duration':float(seconds)/count} for i in range(count)]
    plan = validated_visual_plan({'narration':'','scenes':scenes},topic,seconds,language,mode)
    result = script_from_plan(plan)
    result['source'] = 'planner-visual'
    result['editorial_qc']['scope'] = 'Deterministic visual outline; editorial review required'
    return result


def validate_draft_selection(plan, topic, seconds, language, selected_audio):
    if (plan.get('topic') != topic or plan.get('language') != language
            or plan.get('requested_seconds') != int(seconds)
            or plan.get('audio_mode', 'voiceover') != audio_mode(selected_audio)):
        raise ValueError('This draft belongs to different topic, duration, language or audio settings. Draft again before approval.')
    if audio_mode(selected_audio) != 'voiceover':
        validated_visual_plan(plan,topic,seconds,language,selected_audio)

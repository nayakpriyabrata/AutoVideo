"""Visible Flow Music sessions with generate-once journals and exact song choice.

UI selectors are intentionally conservative: if a song cannot be uniquely
identified, keep the journal and never download another row or resubmit.
"""
from pathlib import Path
import argparse
import contextlib
import fcntl
import hashlib
import json
import os
import re
import subprocess
import signal
import sys
import time
import uuid
from urllib.parse import urlsplit
from .production import save, read, probe, digest

HOME='https://flowmusic.app/'


def session_url(url):
    parsed=urlsplit(str(url))
    return (parsed.scheme=='https' and parsed.hostname in ('flowmusic.app','www.flowmusic.app')
            and not parsed.username and not parsed.password
            and bool(re.fullmatch(r'/session/[A-Za-z0-9-]+/?',parsed.path)))


def new_request(prompt, root='outputs/flow_music'):
    prompt=str(prompt).strip()
    if not 10<=len(prompt)<=8000: raise ValueError('Music prompt must be 10–8000 characters')
    folder=Path(root).expanduser().resolve()/('music-'+uuid.uuid4().hex[:16])
    journal=folder/'music_request.json'
    save(journal,{'id':folder.name,'prompt':prompt,'state':'draft','session_url':'',
                  'candidates':[], 'selected':None, 'path':None})
    return str(journal)


def list_requests(root='outputs/flow_music'):
    rows=[]
    for path in sorted(Path(root).glob('*/music_request.json'),reverse=True):
        try: rows.append({'journal':str(path.resolve()), **read(path)})
        except (OSError,ValueError,TypeError): continue
    return rows


def completed_track(journal):
    data=read(journal)
    path=Path(data.get('path') or '')
    if data.get('state')!='downloaded' or not path.is_file() or digest(path)!=data.get('sha256'):
        raise ValueError('Select and download a Flow Music candidate first')
    return str(path.resolve())


def validate_audio(path):
    media=probe(path)
    duration=float(media.get('format',{}).get('duration') or 0)
    import math
    if not math.isfinite(duration) or not 1<=duration<=1800 or not any(
            s.get('codec_type')=='audio' for s in media.get('streams',[])):
        raise ValueError('Downloaded file is not playable music of 1–1800 seconds')
    return duration


@contextlib.contextmanager
def request_lock(journal):
    lock=Path(journal).with_suffix('.lock');lock.parent.mkdir(parents=True,exist_ok=True)
    with lock.open('a') as handle:
        try: fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError('This music request is already running')
        try: yield
        finally: fcntl.flock(handle,fcntl.LOCK_UN)


# Find bounded song rows containing cover artwork and an action menu. Never
# identify candidates by title alone: the service often returns the same title.
ROWS_JS=r'''() => {
 const visible=e=>!!(e.getClientRects().length);
 const rows=[]; const seen=new Set();
 for(const button of document.querySelectorAll('button,[role="button"]')) {
   if(!visible(button)) continue;
   let row=button.parentElement;
   for(let n=0;row && n<5;n++,row=row.parentElement) {
     const image=row.querySelector('img');
     const text=(row.innerText||'').trim();
     const buttons=row.querySelectorAll('button,[role="button"]');
     if(!image || text.length<2 || text.length>1000 || buttons.length<2 || buttons.length>10) continue;
     const explicit=row.closest('[data-song-id],[data-track-id]');
     const anchor=row.querySelector('a[href*="/song/"],a[href*="/track/"]');
     let cover=''; try{ cover=new URL(image.currentSrc||image.src,location.href).pathname; }catch{}
     const id=explicit?.getAttribute('data-song-id')||explicit?.getAttribute('data-track-id')||anchor?.getAttribute('href')||cover;
     if(!id || seen.has(row)) break;
     seen.add(row);row.setAttribute('data-av-music-row',String(rows.length));
     rows.push({identity:id,label:text.slice(0,350),row:String(rows.length)});break;
   }
 }
 return rows;
}'''


class MusicBrowser:
    def __init__(self,page): self.page=page
    def composer(self):
        page=self.page
        for role in ('button','link'):
            auth=page.get_by_role(role,name=re.compile(r'^(sign in|log in|login|sign up)(?: with .*)?$',re.I))
            if any(auth.nth(i).is_visible() for i in range(auth.count())):
                raise RuntimeError('Finish Flow Music sign-in in the visible browser before submitting a request')
        for selector in ('textarea[placeholder="Let’s create..."]','textarea[placeholder="Ask Producer..."]',
                         'textarea[placeholder*="create"]','textarea[placeholder*="Producer"]',
                         '[contenteditable="true"][role="textbox"]','textarea'):
            loc=page.locator(selector)
            for index in range(loc.count()):
                box=loc.nth(index)
                if box.is_visible() and box.is_enabled(): return box
        raise RuntimeError('Flow Music composer unavailable; finish sign-in in the visible browser')
    def rows(self):
        rows=self.page.evaluate(ROWS_JS)
        counts={}
        for row in rows: counts[row['identity']]=counts.get(row['identity'],0)+1
        return [{**r,'key':hashlib.sha256(r['identity'].encode()).hexdigest()}
                for r in rows if counts[r['identity']]==1]
    def open(self,url): self.page.goto(url,wait_until='domcontentloaded',timeout=60000)
    def start_session(self):
        self.open(HOME)
        for role in ('button','link'):
            new=self.page.get_by_role(role,name=re.compile(r'^New session$',re.I))
            if new.count()==1 and new.is_visible(): new.click(timeout=10000);break
        self.composer()
    def submit(self,prompt):
        box=self.composer();box.fill(prompt,timeout=10000)
        # Enter is the composer's send action; never click a global music button.
        box.press('Enter',timeout=10000)
    def download(self,key,target):
        matching=[r for r in self.rows() if r['key']==key]
        if len(matching)!=1: raise RuntimeError('Selected song is not uniquely visible; rescan without generating')
        row=self.page.locator('[data-av-music-row="'+matching[0]['row']+'"]')
        # Menu action must belong to this exact song row.
        menus=row.locator('button[aria-haspopup="menu"],button[aria-label*="More" i],button[aria-label*="menu" i],button[aria-label*="options" i]')
        if menus.count()!=1:
            menus=row.get_by_role('button',name=re.compile(r'^(more_horiz|more_vert|More|Options|\.\.\.)$',re.I))
        if menus.count()!=1: raise RuntimeError('Selected song menu cannot be identified safely; no download clicked')
        menus.click(timeout=10000)
        download=self.page.get_by_role('menuitem',name=re.compile(r'^Download$',re.I))
        if download.count()!=1: download=self.page.get_by_text('Download',exact=True)
        if download.count()!=1: raise RuntimeError('Flow Music download submenu unavailable')
        download.hover(timeout=10000)
        format_item=self.page.get_by_role('menuitem',name=re.compile(r'^MP3$',re.I))
        if format_item.count()!=1: format_item=self.page.get_by_text('MP3',exact=True)
        if format_item.count()!=1: raise RuntimeError('MP3 option unavailable; no other media downloaded')
        with self.page.expect_download(timeout=90000) as pending: format_item.click(timeout=10000)
        asset=pending.value
        failure=asset.failure()
        if failure: raise RuntimeError('Flow Music download transfer failed; retry the same candidate')
        temporary=Path(target).with_suffix('.part.mp3')
        try:
            asset.save_as(str(temporary));validate_audio(temporary);os.replace(temporary,target)
        finally: temporary.unlink(missing_ok=True)


def operate(browser,journal,action,*,approved=False,key='',wait_seconds=300):
    """Generate once, then rescan/download only. Testable without a live account."""
    data=read(journal)
    if not data: raise ValueError('Music request is missing')
    if action=='generate':
        if data['state']!='draft': raise ValueError('Request already submitted/uncertain; use Rescan, never Generate again')
        if approved is not True: raise ValueError('Approve one Flow Music request and its account cost first')
        browser.start_session()
        baseline={r['key'] for r in browser.rows()}
        data.update(state='submission-uncertain',baseline=list(baseline));save(journal,data)
        # Journal BEFORE Enter: a timeout cannot authorize a second song request.
        try:
            browser.submit(data['prompt'])
        finally:
            if session_url(browser.page.url): data['session_url']=browser.page.url
            save(journal,data)
    elif action in ('scan','download'):
        if data['state']=='draft': raise ValueError('Generate this draft once before recovery')
        if not session_url(data.get('session_url')):
            raise ValueError('Submission URL was not captured. Paste the exact Flow Music session URL to recover; do not generate again')
        browser.open(data['session_url'])
    else: raise ValueError('Unknown music action')
    if action=='download':
        known={r['key'] for r in data.get('candidates',[])}
        if key not in known: raise ValueError('Choose one recorded song candidate')
        path=Path(journal).parent/('selected-'+key[:16]+'.mp3')
        if data.get('state')=='downloaded' and data.get('selected')==key:
            completed_track(journal);return data
        browser.download(key,path)
        data.update(state='downloaded',selected=key,path=str(path.resolve()),sha256=digest(path),duration=validate_audio(path))
        save(journal,data);return data
    deadline=time.monotonic()+wait_seconds
    while True:
        url=browser.page.url
        if session_url(url): data['session_url']=url
        rows=[r for r in browser.rows() if r['key'] not in data.get('baseline',[])]
        if rows:
            data.update(candidates=[{'key':r['key'],'label':r['label']} for r in rows])
            if data['state']!='downloaded':data['state']='candidates-ready'
        save(journal,data)
        if rows or time.monotonic()>=deadline: return data
        browser.page.wait_for_timeout(2000)


def bind_session(journal,url):
    if not session_url(url): raise ValueError('Use an exact https://flowmusic.app/session/... URL')
    with request_lock(journal):
        data=read(journal)
        if data['state']=='draft': raise ValueError('No submitted request needs recovery')
        if data.get('session_url') and data['session_url']!=url:
            raise ValueError('Saved music session cannot be replaced with another session')
        data['session_url']=url;save(journal,data)


def music_profile():
    return Path(os.getenv('AUTOVIDEO_FLOW_MUSIC_PROFILE',str(Path.home()/'.local/share/autovideoai/flow-music-profile'))).resolve()


def login_status():
    data=read(music_profile()/'.autovideo-login.json', {})
    if not data or data.get('state') in ('closed','failed'):
        return data
    try:
        os.kill(int(data['pid']),0)
    except (OSError,ValueError,KeyError):
        return {**data,'state':'closed'}
    return data


def _write_login_state(profile, data):
    path=profile/'.autovideo-login.json'
    save(path,data)
    path.chmod(0o600)


def open_manual_music():
    """Open a human-operated supported browser; no credential or automation tricks."""
    from .providers.flow_browser import is_wsl
    import shutil,webbrowser
    if is_wsl() and shutil.which('powershell.exe'):
        subprocess.Popen(['powershell.exe','-NoProfile','-Command',"Start-Process 'https://flowmusic.app/'"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return True
    if not webbrowser.open(HOME):
        raise RuntimeError('Open https://flowmusic.app/ in your normal browser, generate/download there, then import the track below.')
    return True


def import_music(content, name, root='outputs/flow_music/imported'):
    suffix=Path(name).suffix.lower()
    if suffix not in ('.mp3','.wav','.m4a','.ogg','.flac') or not 0<len(content)<=100*1024*1024:
        raise ValueError('Use a playable MP3/WAV/M4A/OGG/FLAC up to 100 MB')
    folder=Path(root).resolve();folder.mkdir(parents=True,exist_ok=True)
    path=folder/(hashlib.sha256(content).hexdigest()+suffix)
    if not path.exists():path.write_bytes(content)
    info=probe(str(path));audio=any(s.get('codec_type')=='audio' for s in info.get('streams',[]))
    if not audio or float(info.get('format',{}).get('duration',0))<=0:
        raise ValueError('Imported track contains no playable audio; choose the downloaded music file')
    return str(path)


def wait_for_manual_login(browser, profile, *, token, seconds=900):
    """Hold the owned login browser across Streamlit reruns until handoff/close."""
    state={'pid':os.getpid(),'token':token,'state':'login-open','auth_ready':False}
    _write_login_state(profile,state)
    deadline=time.monotonic()+seconds
    try:
        while time.monotonic()<deadline:
            if browser.page.is_closed():
                break
            rejected='/signin/rejected' in str(getattr(browser.page,'url',''))
            ready=False
            try:
                browser.composer();ready=True
            except RuntimeError:
                pass
            state.update(auth_ready=ready,state='sign-in-blocked' if rejected else 'signed-in' if ready else 'login-open')
            _write_login_state(profile,state)
            control=read(profile/'.autovideo-login-control.json',{})
            if control.get('token')==token and control.get('action') in ('close','handoff'):
                if control['action']=='close' or ready:
                    return {'state':'login-finished','auth_ready':ready}
            browser.page.wait_for_timeout(1000)
        return {'state':'login-closed','auth_ready':state['auth_ready']}
    finally:
        state['state']='closed'
        _write_login_state(profile,state)


def finish_login(*, require_ready=False):
    status=login_status()
    if not status or status.get('state') in ('closed','failed'):
        return
    if require_ready and not status.get('auth_ready'):
        raise RuntimeError('Finish sign-in in the Flow Music login window first. The window remains open; no request was submitted.')
    control=music_profile()/'.autovideo-login-control.json'
    save(control,{'token':status['token'],'action':'handoff' if require_ready else 'close'})
    control.chmod(0o600)
    deadline=time.monotonic()+15
    while time.monotonic()<deadline:
        if login_status().get('state')=='closed':
            # The worker releases its persistent profile before operations start.
            time.sleep(.5)
            return
        time.sleep(.2)
    raise RuntimeError('Flow Music login window is still closing. Retry after it closes; no request was submitted.')


def browser_operation(action,journal='',approved=False,key=''):
    try:
        return _browser_operation_once(action,journal,approved,key)
    except Exception as error:
        from .providers.flow_browser import FlowBrowser
        if not FlowBrowser._looks_like_browser_closed_error(error):
            raise
        recovery=action
        if action=='generate':
            data=read(journal,{})
            if data.get('state')!='draft':
                if not session_url(data.get('session_url')):
                    raise RuntimeError('Music browser closed after submission; its journal is preserved. Set the exact session URL to rescan. No duplicate request was submitted.') from None
                recovery='scan'
        # One context restart. Submitted generation becomes download-only scan.
        return _browser_operation_once(recovery,journal,approved,key)


def _browser_operation_once(action,journal='',approved=False,key=''):
    from playwright.sync_api import sync_playwright
    profile=music_profile()
    profile.mkdir(parents=True,exist_ok=True)
    with request_lock(profile/'browser'),sync_playwright() as playwright:
        from .providers.flow_browser import resolve_browser_cfg
        from .quiet_browser import quiet_enabled, browser_environment
        cfg = resolve_browser_cfg({})
        options = music_launch_options(cfg, login=(action=='login'))
        context = None
        # Launch recovery is before any submission. Never retry Generate after
        # operate() has written its uncertain journal and pressed Enter.
        for attempt in range(2):
            try:
                if attempt and '--ozone-platform=wayland' in options['args']:
                    options['args'].remove('--ozone-platform=wayland')
                    options.pop('env', None)
                context=playwright.chromium.launch_persistent_context(
                    str(profile),headless=False,accept_downloads=True,timeout=30000,**options)
                break
            except Exception as error:
                from .support_report import redact
                diagnostic=Path('logs/flow-music');diagnostic.mkdir(parents=True,exist_ok=True)
                (diagnostic/'browser-launch.txt').write_text(redact(str(error)),encoding='utf-8')
                if attempt:
                    raise RuntimeError('Flow Music Chromium could not start after two launch attempts. See logs/flow-music/browser-launch.txt. Run Browser diagnostics in Flow Session; existing music requests are preserved.') from None
        try:
            page=context.pages[0] if context.pages else context.new_page()
            page.set_default_timeout(10000)
            browser=MusicBrowser(page)
            if action=='login':
                browser.open(HOME)
                # No prompt or password entry. Login has an independent lifetime.
                return wait_for_manual_login(browser,profile,token=os.getenv('AUTOVIDEO_MUSIC_LOGIN_TOKEN',''))
            with request_lock(journal): return operate(browser,journal,action,approved=approved,key=key)
        finally:
            try: context.close()
            except Exception: pass


def music_launch_options(cfg, login=False):
    """Use the configured local browser and WSL-safe flags, on a separate profile."""
    from .quiet_browser import quiet_enabled, browser_environment
    options={'args':['--disable-dev-shm-usage','--disable-gpu','--no-first-run',
                     '--no-default-browser-check','--disable-session-crashed-bubble']}
    if cfg.get('executable'):
        options['executable_path']=cfg['executable']
    elif cfg.get('mode') == 'system':
        options['channel']=cfg.get('channel', 'chrome')
    if not login and quiet_enabled(cfg):
        options['env']=browser_environment()
        options['args'].append('--ozone-platform=x11')
    else:
        from .providers.flow_browser import is_wsl
        if is_wsl():
            environment=dict(os.environ);environment.pop('DISPLAY',None)
            environment.setdefault('WAYLAND_DISPLAY','wayland-0')
            runtime=f'/run/user/{os.getuid()}'
            if Path(runtime).is_dir(): environment['XDG_RUNTIME_DIR']=runtime
            options['env']=environment
            options['args'].append('--ozone-platform=wayland')
    return options


def run_browser(action,journal='',approved=False,key=''):
    if action=='close-login':
        finish_login();return {'state':'login-closed'}
    if action=='login':
        status=login_status()
        if status and status.get('state') not in ('closed','failed'):
            return {k:status[k] for k in ('state','pid','auth_ready') if k in status}
        profile=music_profile();profile.mkdir(parents=True,exist_ok=True)
        token=uuid.uuid4().hex
        environment=dict(os.environ);environment['AUTOVIDEO_MUSIC_LOGIN_TOKEN']=token
        log=profile/'.autovideo-login.log'
        with log.open('w') as output:
            log.chmod(0o600)
            process=subprocess.Popen([sys.executable,'-m','engine.flow_music','login'],
                stdout=output,stderr=output,env=environment,start_new_session=True)
        state={'pid':process.pid,'token':token,'state':'starting','auth_ready':False}
        _write_login_state(profile,state)
        return {'state':'login-open','pid':process.pid,'message':'Sign in in the visible browser. It stays open for up to 15 minutes; Generate hands it off after sign-in.'}
    finish_login(require_ready=True)
    command=[sys.executable,'-m','engine.flow_music',action]
    if journal: command+=['--journal',str(journal)]
    if approved: command+=['--approved']
    if key: command+=['--key',key]
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
    try: output,_stderr=process.communicate(timeout=480)
    except subprocess.TimeoutExpired:
        # Stop the isolated browser's process group too, releasing its profile
        # lock so an exact recovery can open a fresh browser on the next attempt.
        try: os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError: pass
        try: process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            try: os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError: pass
            process.communicate()
        raise RuntimeError('Music browser exceeded its deadline; saved requests require Rescan, not another generation')
    if process.returncode: raise RuntimeError('Flow Music browser needs attention: '+output[-700:])
    return json.loads(output.strip().splitlines()[-1])


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['login','generate','scan','download'])
    parser.add_argument('--journal',default='');parser.add_argument('--approved',action='store_true');parser.add_argument('--key',default='')
    args=parser.parse_args()
    try: print(json.dumps(browser_operation(args.action,args.journal,args.approved,args.key),ensure_ascii=False))
    except Exception as error:
        # Exceptions may contain authenticated transport URLs; expose the type
        # and our bounded application messages only.
        message=str(error) if isinstance(error,(ValueError,RuntimeError)) else type(error).__name__+'; check WSL Chromium/WSLg and retry recovery'
        print(json.dumps({'error':message}));sys.exit(1)

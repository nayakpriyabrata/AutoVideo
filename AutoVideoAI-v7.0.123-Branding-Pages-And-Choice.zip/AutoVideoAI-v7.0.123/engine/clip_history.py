"""Permanent batch reports alongside the backwards-compatible latest report."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import time
from .production import save


def begin_batch(folder):
    folder = Path(folder).resolve()
    history = folder/'clip-history'; history.mkdir(parents=True, exist_ok=True)
    # Archive legacy reports before the next batch replaces their latest aliases.
    for name in ('highlights.json', 'highlights.partial.json'):
        previous = folder/name
        if previous.is_file():
            raw = previous.read_bytes()
            target = history/('highlights-legacy-'+hashlib.sha256(raw).hexdigest()[:20]+'.json')
            if not target.exists():
                # Preserve malformed legacy reports too; discovery can skip
                # them without blocking the next production.
                try:
                    with target.open('xb') as handle:
                        handle.write(raw)
                except FileExistsError:
                    pass
    batch_id = str(time.time_ns())
    return batch_id, history/f'highlights-{batch_id}.json'


def save_batch(path, report):
    save(Path(path), report)


def _report_folder(path):
    path = Path(path).resolve()
    return path.parent.parent if path.parent.name == 'clip-history' else path.parent


def _existing_path(value, folder):
    """Resolve a saved clip path after an installation/shared-storage move."""
    if not value:
        return ''
    path = Path(str(value)).expanduser()
    if path.is_file():
        return str(path.resolve())
    direct = folder / path.name
    if direct.is_file():
        return str(direct.resolve())
    matches = [item for item in folder.rglob(path.name) if item.is_file()]
    return str(matches[0].resolve()) if len(matches) == 1 else str(path)


def load_batch(report_path):
    """Load one exact historical batch and rebase uniquely identifiable files."""
    path = Path(report_path).expanduser().resolve()
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError, TypeError) as exc:
        raise ValueError('The selected saved clip report is missing or unreadable') from exc
    if not isinstance(value, dict) or not isinstance(value.get('highlights'), list):
        raise ValueError('The selected file is not a Clip Studio batch report')
    folder = _report_folder(path)
    for key in ('source', 'selection_report'):
        value[key] = _existing_path(value.get(key), folder)
    for key in ('outputs', 'blocked_outputs', 'broll_outputs'):
        value[key] = [_existing_path(item, folder) for item in value.get(key, [])]
    for highlight in value['highlights']:
        if not isinstance(highlight, dict):
            continue
        for key in ('output', 'caption_ass_path', 'transcript_sidecar', 'broll_output'):
            if highlight.get(key):
                highlight[key] = _existing_path(highlight[key], folder)
    value['batch_report'] = str(path)
    value['_clip_folder'] = str(folder)
    return value


def discover_batches(roots=('outputs',)):
    """List persistent Clip Studio batches, newest first, without changing them."""
    if isinstance(roots, (str, Path)):
        roots = (roots,)
    reports = set()
    for root in roots:
        root = Path(root).expanduser()
        if root.is_file():
            reports.add(root.resolve())
            continue
        if not root.is_dir():
            continue
        reports.update(path.resolve() for path in root.glob('**/highlights.json'))
        reports.update(path.resolve() for path in root.glob('**/highlights.partial.json'))
        reports.update(path.resolve() for path in root.glob('**/clip-history/highlights-*.json'))
    selected = {}
    for path in reports:
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            highlights = data.get('highlights')
            if not isinstance(highlights, list):
                continue
        except (OSError, ValueError, TypeError):
            continue
        batch_id = str(data.get('batch_id') or '')
        identity = batch_id or hashlib.sha256(path.read_bytes()).hexdigest()[:24]
        completed = path.name != 'highlights.partial.json' and not bool(data.get('partial_result'))
        permanent = path.parent.name == 'clip-history'
        rank = (permanent, completed, path.stat().st_mtime_ns)
        if identity in selected and selected[identity]['_rank'] >= rank:
            continue
        folder = _report_folder(path)
        output_values = list(data.get('outputs') or []) + list(data.get('blocked_outputs') or [])
        if not output_values:
            output_values = [item.get('output') for item in highlights if isinstance(item, dict) and item.get('output')]
        available = sum(bool(_existing_path(item, folder)) and Path(_existing_path(item, folder)).is_file()
                        for item in dict.fromkeys(map(str, output_values)))
        expected = len([item for item in highlights if isinstance(item, dict)])
        source = str(data.get('source_input') or data.get('source') or 'Unknown source')
        first_title = next((str(item.get('title')) for item in highlights
                            if isinstance(item, dict) and item.get('title')), 'Saved highlights')
        try:
            created = datetime.fromtimestamp(int(batch_id) / 1_000_000_000).astimezone() if batch_id.isdigit() else datetime.fromtimestamp(path.stat().st_mtime).astimezone()
        except (ValueError, OSError, OverflowError):
            created = datetime.fromtimestamp(path.stat().st_mtime).astimezone()
        state = 'complete' if completed else 'partial / review required'
        selected[identity] = {
            'batch_id': batch_id or identity,
            'report_path': str(path),
            'folder': str(folder),
            'created_at': created.isoformat(timespec='seconds'),
            'source': source,
            'title': first_title,
            'available_clips': available,
            'highlight_count': expected,
            'state': state,
            'label': f"{created.strftime('%Y-%m-%d %H:%M')} · {first_title} · {available}/{expected} clips · {state}",
            '_rank': rank,
        }
    rows = sorted(selected.values(), key=lambda row: row['created_at'], reverse=True)
    for row in rows:
        row.pop('_rank', None)
    return rows

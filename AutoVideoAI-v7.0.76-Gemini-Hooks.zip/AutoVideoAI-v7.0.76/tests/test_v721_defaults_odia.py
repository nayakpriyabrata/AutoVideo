import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
from engine.factory import Factory


@pytest.mark.parametrize('kind',['faceless_youtube','shorts','cartoon','music_video'])
def test_default_and_legacy_jobs_do_not_gain_replacement_permission(tmp_path,kind):
    f=Factory(str(tmp_path/'outputs'),str(tmp_path/'jobs.db'))
    job=f.create_job('Default recovery',video_type=kind,dry_run=True)
    path=Path(f.pm.job_dir(job))/'settings.json'
    settings=json.loads(path.read_text());settings.update(flow_replace_unresolved_images=False)
    settings.pop('flow_image_replacement_policy_version',None);path.write_text(json.dumps(settings))
    assert f._settings(job)['flow_replace_unresolved_images'] is False
    assert f._settings(job)['flow_image_replacement_limit']==30
    f.set_flow_image_replacement(job,False,7)
    assert f._settings(job)['flow_replace_unresolved_images'] is False
    assert json.loads(path.read_text())['flow_image_replacement_policy_version']==1


def test_odia_correction_preserves_timings_and_source_hash(monkeypatch):
    from engine.gemini_transcript import correct_transcript
    import engine.providers.gemini_web as web
    calls=[]
    def generate(*a,**k):
        calls.append(k)
        return json.dumps({'words':[{'word':'ନମସ୍କାର','start':0,'end':1}]},ensure_ascii=False)
    monkeypatch.setattr(web,'gemini_web_generate',generate)
    original={'words':[{'word':'ନମସ୍କାର୍','start':0,'end':1}],'source_sha256':'saved-hash'}
    result=correct_transcript(original)
    assert result['words'][0]['end']==1 and result['source_sha256']=='saved-hash'
    assert original['words'][0]['word']=='ନମସ୍କାର୍'
    assert calls[0]['cleanup']=='delete-after-read' and result['review_required']
    monkeypatch.setattr(web,'gemini_web_generate',lambda *a,**k:json.dumps({'words':[{'word':'ନମସ୍କାର','start':.1,'end':1}]}))
    with pytest.raises(ValueError,match='changed word timing'):correct_transcript(original)


def test_gemini_draft_uses_audible_proxy_restores_chunk_offsets_and_cleans_chat(tmp_path,monkeypatch):
    import engine.gemini_transcript as mod
    import engine.providers.gemini_web as web
    source=tmp_path/'video.mp4';source.write_bytes(b'owned-video-fixture')
    monkeypatch.setattr(mod,'resolve_input',lambda *a,**k:str(source))
    monkeypatch.setattr(mod,'_duration',lambda p:301)
    commands=[];calls=[]
    def run(cmd,**kw):
        commands.append(cmd);Path(cmd[-1]).write_bytes(b'audible proxy');return NS(returncode=0)
    monkeypatch.setattr(mod,'_run',run)
    def generate(*a,**k):
        calls.append(k);return json.dumps({'words':[{'word':'ଜୟ','start':0,'end':.5}]})
    monkeypatch.setattr(web,'gemini_web_generate',generate)
    result=mod.draft_transcript(str(source),str(tmp_path/'drafts'),rights_confirmed=True)
    assert [w['start'] for w in result['words']]==[0,300]
    assert all('0:a:0' in c and '-an' not in c for c in commands)
    assert all(c['attachments'] and c['cleanup']=='delete-after-read' for c in calls)
    assert result['review_required'] and result['source_sha256']==hashlib.sha256(source.read_bytes()).hexdigest()

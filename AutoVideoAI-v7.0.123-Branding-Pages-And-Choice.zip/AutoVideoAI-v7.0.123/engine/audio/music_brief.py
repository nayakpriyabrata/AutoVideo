"""Text-only Gemini Web music direction for explicit human review."""
import json


def draft_music_brief(topic, genre, language='en', purpose='background', seconds=120, cleanup='delete-after-read'):
    from ..providers.gemini_web import gemini_web_generate
    from ..planning.script_engine import _extract_json
    topic=str(topic).strip()[:500]
    if not topic or purpose not in ('background','song'):
        raise ValueError('Enter a topic and select a music purpose')
    seconds=max(10,min(600,int(seconds)))
    raw=gemini_web_generate(
        'You are an original music director. Return JSON only. Create text directions, no media. '
        'Do not quote existing lyrics, melodies, artists or recognizable songs. Keep the song hook original. '
        'A music prompt cannot grant rights or guarantee that the generated music will be usable.',
        f'Topic: {topic}\nGenre: {genre}\nLanguage: {language}\nPurpose: {purpose}\nApproximate duration: {seconds}s. '
        'Return {"music_prompt":"40-180 word production prompt with instruments, pace, sections and mood",'
        '"opening_hook":"one original 2-5 second musical hook idea",'
        '"section_plan":["intro", "middle", "ending"],'
        '"lyric_draft":"original lyric idea or empty for instrumental",'
        '"search_mood":"3-8 English theme words for a local music library"}. '
        'For background music request instrumental only, no speech or singing, and leave room for narration. '
        'For a song, draft original lyrics only if useful and match the language.',
        cleanup=cleanup)
    data=_extract_json(raw)
    if not isinstance(data,dict) or not 20<=len(str(data.get('music_prompt','')).strip())<=2000:
        raise ValueError('Gemini did not return a complete music brief; review the saved Gemini chat before retrying')
    return {key:str(data.get(key,'')).strip()[:limit] for key,limit in
            [('music_prompt',2000),('opening_hook',300),('lyric_draft',4000),('search_mood',200)]} | {
            'section_plan':[str(s)[:160] for s in data.get('section_plan',[])[:12]]
            if isinstance(data.get('section_plan'),list) else []}

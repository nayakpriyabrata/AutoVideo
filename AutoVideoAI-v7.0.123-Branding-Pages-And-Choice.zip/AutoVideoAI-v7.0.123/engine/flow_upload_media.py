"""Deterministic upload derivatives; frozen originals and approval hashes stay intact."""
from pathlib import Path
from PIL import Image,ImageOps
from .production import digest,save


def prepare_reference(path,root='data/flow_media_uploads/prepared'):
    source=Path(path).resolve()
    # Only real saved character photos need this path. Storyboard/provider media
    # already has a bounded format; unknown legacy files keep their exact bytes.
    if not source.name.startswith('character-'):return str(source)
    sha=digest(source)
    target=Path(root).resolve()/sha/(source.stem[:70]+'.jpg')
    try:
        with Image.open(source) as image:
            image.load();image=ImageOps.exif_transpose(image)
            image.thumbnail((2048,2048),Image.Resampling.LANCZOS)
            if image.mode in ('RGBA','LA') or (image.mode=='P' and 'transparency' in image.info):
                rgba=image.convert('RGBA');canvas=Image.new('RGB',rgba.size,'white');canvas.paste(rgba,mask=rgba.getchannel('A'));image=canvas
            else:image=image.convert('RGB')
            target.parent.mkdir(parents=True,exist_ok=True)
            temporary=target.with_suffix('.tmp')
            image.save(temporary,format='JPEG',quality=95,subsampling=0)
            temporary.replace(target)
            save(str(target)+'.prepared.json',{'source_sha256':sha,'prepared_sha256':digest(target),'source':str(source),'protocol':1,'size':image.size,'orientation':'exif-transposed','original_preserved':True})
        return str(target)
    except (OSError,ValueError):return str(source)

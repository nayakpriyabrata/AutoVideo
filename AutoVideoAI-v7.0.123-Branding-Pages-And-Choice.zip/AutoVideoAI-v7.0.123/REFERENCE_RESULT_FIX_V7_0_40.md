# AutoVideoAI v7.0.40: reference uploads are not generated results

The supplied v7.0.39 log showed image detection soon after a reference reattachment. A delayed upload can appear after the gallery baseline and pass the old three-second image stability check. The supplied Flow conversation also ends with a reference-mode choice: interpolation accepts two frames, but the tool supplied four images. These are separate causes; repeating Resume alone cannot resolve a reference-mode decision.

## Changes

- Fresh image tiles require exact submitted-prompt/request-marker correlation before they are recorded or downloaded. A stable tile, a unique fresh image, or gallery order alone cannot prove a generated result. The generation wait continues while an unverified uploaded reference is visible. Existing saved image signatures are checked against their generation prompt during download-only recovery.
- Frame video mode attaches only the start/end frames, with their actual positional labels. Identity and environment should already be represented by the storyboard frames. Other video modes retain their reference plan. Missing selected cast photos still stop new generation.
- Economy storyboard Resume checks saved shot frames for literal or virtually identical pixel copies of character/location masters. Detected copies are moved to `storyboard/rejected_reference_copies`, and existing request journals are returned to pending with their rejected signature retained. Shared/sibling cache restores undergo the same check. Master references and accepted videos are preserved. This detects direct copies, not every possible wrong image or semantic mismatch.
- Recoverable pending video requests now reach the bounded automatic recovery supervisor even when `flow_pause_on_unresolved_request` is off. These retries perform saved-request recovery, not another video generation.
- Support reports accept production manifests up to 16 MiB; other diagnostic JSON remains capped at 512 KiB. Failures identify the manifest path and reason. A missing manifest still needs the correct outputs root or installation migration.

## Upgrade and inspect the existing job

Stop Studio and running jobs. Extract this release beside v7.0.39 and run from the new folder. This updates seven application files in the existing installation, backs up the old code, and leaves jobs, media, configuration, databases and browser profiles in place. It does not copy the roughly 7 GB of runtime data again. The existing folder keeps its name but runs v7.0.40 afterward.

```bash
python3 tools/update_v739_to_v740.py ../AutoVideoAI-v7.0.39 --apply
cd ../AutoVideoAI-v7.0.39
python3 cli.py v3 support-report 20261010-141959-7-morning-habits-that-ca-40b7
```

Share the resulting report to inspect the existing unresolved `shot_001` request. If the manifest error remains, use the printed full path to verify the installation, or supply `--outputs-root /absolute/path/to/outputs`. Do not create a replacement job just to bypass the pending journal. The updater accepts only an existing v7.0.39 target and verifies source files against the extracted release manifest. Without `--apply` it prints a plan. It does not install dependency packages.

The existing Flow conversation asks `Use all 4 images as references (R2V)` versus `Use only Image 1 and Image 2 (Interpolation)`. The tool cannot retroactively change the attachments on that saved request. Review Image 1 and Image 2 before choosing interpolation; they must actually be the intended start/end frames. An existing wrong-frame request needs review rather than blind approval. Selecting a mode is distinct from credit approval; retain the job's existing budget/approval policy.

After reviewing the request and resolving any needed Flow choice:

```bash
python3 cli.py v3 resume 20261010-141959-7-morning-habits-that-ca-40b7
```

Quarantined storyboard copies recover through the existing journal where possible; unchanged shared-cache copies are not accepted again. Prompt controls unavailable in the current Flow UI still prevent verified recovery. This release does not guess an asset, promise uninterrupted external services, or certify that all earlier cached images are correct. Live Flow generation on the user's machine remains unverified.

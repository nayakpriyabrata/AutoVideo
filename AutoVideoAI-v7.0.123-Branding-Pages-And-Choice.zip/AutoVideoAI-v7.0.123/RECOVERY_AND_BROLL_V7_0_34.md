# AutoVideoAI v7.0.34 — reference picker, music login and optional B-roll

## What changed

- Character thumbnail backgrounds now override the global theme background in light, dark and eye-friendly modes. Original photos are unchanged. Click a card to inspect its full photo and edit details.
- Flow reference attachment selects the media picker's Uploads tab, supports exact hash-bearing filenames exposed through thumbnail labels, and still requires verified composer attachment before submission. A location-only master no longer unnecessarily requires a character photo. After a shared reference exhausts exact upload recovery, later frames avoid repeatedly retrying it within the same browser session. Zero attached references now follow the same bounded handling as partial attachment failures.
- Flow Music login runs in an independent process so Streamlit reruns do not immediately close it. The visible window remains open for up to 15 minutes. Finish sign-in, then Generate hands off the saved profile; trying Generate before sign-in leaves the login window open and submits nothing. A Close login button releases the window explicitly. Browser launch diagnostics remain available if Chromium itself cannot start.
- Guided Studio, Advanced Create, AI Recreation, Music Video and saved production rendering offer optional contextual B-roll up to 150. Clip Studio supports up to 150 suggestions per clip. Choose cutaway duration and maximum uses of one asset (1, 2 or 3). New builds default to B-roll off; existing jobs remain off until explicitly enabled. Mini Reels remains its separate one-8-second-Flow-clip workflow, without post-production B-roll.
- Unique assets are searched first. Reuse requires an exact same contextual search query after a fresh search fails and stays within the chosen cap. Byte-identical assets cannot bypass that cap by using another filename. Unavailable matches are skipped; short timelines may fit fewer than the requested maximum. Source permission and contextual review still matter: automated file validation cannot guarantee editorial relevance or legal rights.
- Render-only B-roll choices preserve narration, accepted takes and pending Flow journals. Existing review decisions are reused on rerender. Automatic selection is an explicit checkbox; otherwise approve suggestions in Studio before rendering.
- Identical free fallback opening/closing images no longer trigger additional Flow retry rounds. The log reports single-frame guidance and the need to review likeness/meaning.

## Why the log showed 0 stock

The economy summary counts base storyboard scenes. A selected cast can route stock base scenes to image-motion to avoid substituting a random person for the chosen character. Render-time B-roll is separate and now gets its own progress message when enabled. Choosing 150 is an upper limit, not a promise to insert 150 or to fill every scene with stock.

## Upgrade and use the same saved job

Stop running Studio/CLI jobs. Extract this build into a fresh directory. Preview migration first, then apply it:

```bash
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.33 .
python3 tools/migrate_installation.py ../AutoVideoAI-v7.0.33 . --apply
./dashboard.sh
```

Change the source directory if your last installation has a different version. Keep the old installation as a backup. Do not delete request journals or accepted media.

For the reported job, resume the same saved job after migration:

```bash
python3 cli.py v3 resume 20261009-133627-7--the-psychology-of-mon-844d
```

To enable B-roll for a saved job, open Render → Optional related stock B-roll → saved B-roll choices, select your limit/reuse/automatic selection and Save B-roll choices. Render after the saved shots pass coverage QC. This does not initiate new Flow videos.

## Limits of verification

Regression checks cover local policy, exact attachment evidence, persistent login/handoff, thumbnail CSS, B-roll spacing/reuse and preserved review decisions. Live Google Flow/Flow Music sessions and WSLg on your PC were not available for validation. These changes do not guarantee a specific failure rate. An uncertain video still requires exact download-only recovery; no blind paid video resubmission or arbitrary asset association was added. An old exhausted upload record can still need a verified attachment once the current picker is inspected. Estimated caption timings remain marked for review.

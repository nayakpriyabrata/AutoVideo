"""v7.0.104: a stale pause notice, and a stored Flow project that answers "Project not found".

Two field reports on job 20261022-143856-7 (2026-10-27 10:07 IST):

1. the Queue said "Job needs recovery at shot_018" and then described
   ``flow/shots/shot_014/take_01.mp4.flow-request.json`` with the old FlowRequestPending cause - a request that
   had been downloaded and QC-accepted hours earlier;
2. a browser tab showed ``https://flow.google.com/404?reason=project`` ("Project not found") while the run
   opened stored project URLs, and the failure surfaced as the generic "composer was not found".

``pause_freshness.refresh()`` is pure; ``FlowBrowser.project_missing()`` reads only the current page. Nothing
here opens a browser or spends credits.
"""
import json
from types import SimpleNamespace

import pytest

from engine.pause_freshness import refresh as refresh_pause

JOB = '20261022-143856-7-small-daily-habits-tha-9729'
JOURNAL = 'flow/shots/shot_014/take_01.mp4.flow-request.json'
OLD_REASON = ('Flow video request is saved at ' + JOURNAL + '. Generation is blocked to avoid spending again. '
              'Cause: FlowRequestPending: Existing request still has no single identifiable asset after '
              'bounded gallery scans; no recovery click submitted')


# ----------------------------------------------------------------- stale pause notices

def test_a_notice_about_a_resolved_request_is_superseded():
    fresh = refresh_pause(OLD_REASON, 'shot_014', [], 'shot_018', 17, 45)
    assert fresh['stale'] is True
    assert 'Superseded notice' in fresh['reason']
    assert 'shot_014' in fresh['reason']
    assert 'No unresolved Flow request remains' in fresh['reason']
    assert 'shot_018' in fresh['reason']
    assert '17/45' in fresh['reason']
    assert JOURNAL in fresh['superseded']          # the old text is kept, not hidden


def test_a_notice_about_a_still_unresolved_request_is_left_alone():
    unresolved = [{'journal': JOURNAL, 'kind': 'video'}]
    fresh = refresh_pause(OLD_REASON, 'shot_014', unresolved, 'shot_014', 17, 45)
    assert fresh['stale'] is False
    assert fresh['reason'] == ' '.join(OLD_REASON.split())


def test_a_notice_that_names_a_different_journal_is_superseded_even_with_another_one_open():
    unresolved = [{'journal': 'flow/shots/shot_018/take_01.mp4.flow-request.json', 'kind': 'video'}]
    fresh = refresh_pause(OLD_REASON, 'shot_014', unresolved, 'shot_018', 17, 45)
    assert fresh['stale'] is True
    assert 'flow/shots/shot_018/take_01.mp4.flow-request.json' in fresh['reason']
    assert 'shot(s) shot_018' in fresh['reason']


def test_no_saved_reason_is_not_called_stale():
    fresh = refresh_pause('', '', [], 'shot_018', 17, 45)
    assert fresh['stale'] is False
    assert fresh['reason'] == ''


def test_the_job_did_not_move_but_the_request_is_resolved():
    fresh = refresh_pause(OLD_REASON, 'shot_014', [], 'shot_014', 17, 45)
    assert fresh['stale'] is True                   # the named journal is not unresolved any more
    assert 'No unresolved Flow request remains' in fresh['reason']


def test_the_unresolved_targets_are_reported_verbatim():
    unresolved = [{'journal': JOURNAL}, {'journal': 'storyboard/shot_020_open.jpg.flow-request.json'}]
    fresh = refresh_pause(OLD_REASON, 'shot_014', unresolved, 'shot_018', 17, 45)
    assert fresh['unresolved_targets'] == [JOURNAL, 'storyboard/shot_020_open.jpg.flow-request.json']
    assert fresh['stale'] is False


# ----------------------------------------------------------------- the recovery_state wiring

def _job_dir(tmp_path, unresolved=True):
    job = tmp_path / JOB
    (job / 'flow' / 'shots' / 'shot_014').mkdir(parents=True)
    (job / 'storyboard').mkdir()
    (job / 'production_manifest.json').write_text('{"job_id": "%s"}' % JOB)
    (job / 'pause_state.json').write_text(json.dumps(
        {'kind': 'flow_download_or_ui', 'shot_id': 'shot_014', 'reason': OLD_REASON,
         'actions': [{'label': 'Resume', 'command': f'python3 cli.py v3 resume {JOB}'}]}))
    if unresolved:
        (job / 'flow' / 'shots' / 'shot_014' / 'take_01.mp4.flow-request.json').write_text(json.dumps(
            {'kind': 'video', 'scope': 'video_flow_v1', 'phase': 'submitted', 'status': 'pending'}))
    return job


def _factory(job, monkeypatch, shots):
    from engine.factory import Factory
    manifest = SimpleNamespace(shots=shots, status='paused',
                               accepted_count=lambda: sum(1 for s in shots if s.accepted_take))
    factory = Factory.__new__(Factory)
    factory.pm = SimpleNamespace(job_dir=lambda job_id: str(job), log=lambda *a, **k: None,
                                 load_manifest=lambda job_id: manifest)
    factory.db = SimpleNamespace(get=lambda job_id: {})
    factory.pause_state = lambda job_id: json.loads((job / 'pause_state.json').read_text())
    factory._settings = lambda job_id: {}
    factory._flow_project_url = lambda job_id: ''
    return factory


def test_recovery_state_replaces_a_stale_reason_and_keeps_the_old_one(tmp_path, monkeypatch):
    job = _job_dir(tmp_path, unresolved=False)
    shots = [SimpleNamespace(shot_id='shot_017', accepted_take='take_01.mp4'),
             SimpleNamespace(shot_id='shot_018', accepted_take=None)]
    state = _factory(job, monkeypatch, shots).recovery_state(JOB)
    assert state['shot_id'] == 'shot_018'
    assert state['pause_notice_stale'] is True
    assert 'Superseded notice' in state['reason']
    assert state['pause_notice_superseded'].startswith('Flow video request is saved at')


def test_recovery_state_keeps_a_current_notice(tmp_path, monkeypatch):
    job = _job_dir(tmp_path, unresolved=True)
    shots = [SimpleNamespace(shot_id='shot_014', accepted_take=None)]
    state = _factory(job, monkeypatch, shots).recovery_state(JOB)
    assert state.get('pause_notice_stale') is False
    assert 'Superseded' not in state['reason']


# ----------------------------------------------------------------- "Project not found"

class FakePage:
    def __init__(self, url, body=''):
        self.url = url
        self._body = body
        self.waits = 0

    def inner_text(self, selector):
        if selector != 'body':
            raise AssertionError(selector)
        return self._body

    def wait_for_timeout(self, ms):
        self.waits += 1


def _browser(page):
    from engine.providers.flow_browser import FlowBrowser
    browser = FlowBrowser.__new__(FlowBrowser)
    browser._page = page
    return browser


def test_the_404_page_is_recognised_by_url():
    assert _browser(FakePage('https://flow.google.com/404?reason=project')).project_missing() is True


def test_the_404_page_is_recognised_by_its_text():
    page = FakePage('https://flow.google.com/', '<div>Project not found.</div>')
    assert _browser(page).project_missing() is True


def test_a_normal_project_page_is_not_missing():
    page = FakePage('https://flow.google.com/project/37d8cf57-12b4-4a85-9934-5580e90d3781',
                    'What do you want to create? Agent')
    assert _browser(page).project_missing() is False


def test_the_exception_names_the_url_and_the_repairs():
    from engine.providers.flow_browser import FlowProjectMissing
    error = FlowProjectMissing('https://flow.google.com/project/4e5a9b1c-fd8c-445d-b994-6533a15fd38c')
    message = str(error)
    assert '4e5a9b1c-fd8c-445d-b994-6533a15fd38c' in message
    assert "'Project not found'" in message
    assert 'Nothing was submitted or charged' in message
    assert 'flow-projects <job-id>' in message
    assert '--clear-video' in message and '--set-stills' in message


def test_the_factory_records_and_explains_a_missing_video_project(tmp_path):
    from engine.factory import Factory
    job = tmp_path / JOB
    job.mkdir()
    factory = Factory.__new__(Factory)
    factory.pm = SimpleNamespace(job_dir=lambda job_id: str(job), log=lambda *a, **k: None)
    factory.db = SimpleNamespace(get=lambda job_id: {})
    (job / 'settings.json').write_text('{}')
    url = 'https://flow.google.com/project/4e5a9b1c-fd8c-445d-b994-6533a15fd38c'
    record = factory._record_flow_project_missing(JOB, url, 'video')
    assert record['project_url'] == url and record['role'] == 'video'
    assert factory.flow_project_missing_record(JOB)['project_url'] == url
    message = factory.flow_project_missing_message(JOB, url, 'video')
    assert url in message
    assert 'settings.json' in message or 'flow_video_project.json' in message
    assert f'flow-projects {JOB} --clear-video --confirm' in message
    assert 'The stills project is untouched' in message
    assert 'needs a replacement request' in message and 'nothing does that automatically' in message


def test_the_record_is_empty_when_nothing_was_detected(tmp_path):
    from engine.factory import Factory
    job = tmp_path / JOB
    job.mkdir()
    factory = Factory.__new__(Factory)
    factory.pm = SimpleNamespace(job_dir=lambda job_id: str(job), log=lambda *a, **k: None)
    assert factory.flow_project_missing_record(JOB) == {}


def test_a_missing_project_is_a_stop_reason_in_the_status_view():
    from engine.job_activity import STOP_EVENTS
    assert 'flow_project_missing' in STOP_EVENTS
    assert 'flow_project_conflict' in STOP_EVENTS          # v7.0.103 entry is unchanged

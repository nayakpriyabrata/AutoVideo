# AutoVideoAI v7.0.43 — durable Flow image recovery

This full build is based on your uploaded v7.0.42 installation. It integrates recovery into normal image generation and Resume.

## Upgrade your existing WSL installation

Let running jobs finish, then stop Studio and the local runner. Extract this ZIP alongside the current installation. From the extracted `AutoVideoAI-v7.0.43` folder run:

```bash
python3 tools/update_v742_to_v743.py ../AutoVideoAI-v7.0.42 --apply
cd ../AutoVideoAI-v7.0.42
python3 -c "from pathlib import Path; print(Path('VERSION').read_text().strip())"
```

The printed version must be `7.0.43`. The folder can remain named v7.0.42. The updater verifies release hashes and backs up changed code under `code-update-backups`. It preserves outputs (including shared-workspace symlinks), browser profiles, credentials and job settings. It refuses to update while the production lock is held. Restart Studio and/or your runner afterward; updating the hosted page alone cannot update the engine on your PC.

To reconnect the control center:

```bash
python3 autovideo_runner.py --root . --origin https://autovideoai-control.priyabrata-ericsson.chatgpt.site
```

Paste the new runner token into the control center. For an unfinished job use **Resume job**, or `python3 cli.py v3 resume YOUR_JOB_ID`. A finished job does not need regeneration. Keep the completed Little Kanha output.

## Changes

- Every new Flow image request uses an isolated project and durable request record, including master-image requests. Character and location uploads cannot count as the generated result.
- The complete prompt is verified in the composer before sending. A new conversation occurrence acknowledges submission. The Enter fallback explicitly focuses the composer.
- A send attempt with unknown outcome is never blindly resent. Existing saved permission may authorize one replacement in a separate project within the job limit; a duplicate remote image is possible if the original eventually completes.
- Downloads are checkpointed individually by project, asset signature, path and checksum. A browser close after image bytes were saved does not erase success. Saved candidates are reused when their identity still matches.
- Reference uploads are excluded by stable baseline identity or decoded image comparison, including JPEG/resizing changes. Extra or ambiguous images remain unresolved rather than substituting a master image.
- Resume attempts recovery before the safety gate. Validated replacement requests are explicitly superseded so they do not keep blocking Resume.
- Legacy shared-project requests still need an exact match. With saved replacement permission, supported unresolved worker frames can use the bounded replacement ledger. Existing reservations are preserved.
- `logs/resume-reconciliation.json` records recovery outcomes. Journals retain prompts, acknowledgement, project URL, candidate checkpoints and errors.

## Limits and validation

This fixes the identified state-management and download failures; no browser automation can guarantee that Google Flow never pauses or fails. Login expiry, quota, unavailable service, changed UI, missing references and genuinely ambiguous media can require attention after bounded recovery. Video regeneration is not automatically authorized by this image policy.

Validation: the broad offline suite passed 1,049 tests; the final image-transaction and legacy-replacement checks passed 38 tests after the last recovery refinements. Control center checks passed 24 JavaScript interaction tests and 18 local-runner tests. All Python sources parse for Python 3.10.

Regression checks use synthetic images and mocked browser interruptions. This build has not been exercised against your signed-in Flow session or WSL installation. Release hashes and bundled tests make the change reviewable without consuming credits.

## Rollback

With Studio and the runner stopped, restore changed code from the updater's printed backup folder to the same relative locations. Keep job data and journals. Recover new v7.0.43 image transactions with v7.0.43; older engines do not understand the new transaction scope.

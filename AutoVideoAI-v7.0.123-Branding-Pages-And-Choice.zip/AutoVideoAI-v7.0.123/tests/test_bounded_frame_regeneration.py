import contextlib,json,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image
import sys
engine=types.ModuleType("engine")
engine.__path__=[str(Path(__file__).resolve().parents[1]/"engine")]+[str(Path(p)/"engine") for p in sys.path if (Path(p)/"engine/flow_reference_validation.py").is_file()]
sys.modules.setdefault("engine",engine)
from engine import isolated_frame_regeneration as regen
from engine.flow_resume_safety import check_job

class Browser:
 projects={};submissions=0;ready=True;copy_reference=False
 @staticmethod
 def normalize_project_url(url):return url if url and url.startswith('https://flow.google.com/project/') else ''
 @staticmethod
 def _agent_image_instruction(prompt,aspect,count):
  return f'Create exactly 1 STILL IMAGE, not a video. Use landscape orientation (16:9) and the no-charge Nano Banana 2 Lite image model when available. Create this image exactly from the creative brief: {prompt}'
 def __init__(self):
  self.ui={};self.project=None;self._page=types.SimpleNamespace(goto=self.goto,wait_for_timeout=lambda ms:None)
 def goto(self,*a,**kw):self.project=None
 def ensure_project(self,name,project_url=None):
  self.project=project_url or 'https://flow.google.com/project/'+name
  self.projects.setdefault(self.project,{'refs':[],'submitted':False})
 def create_isolated_image_project(self,name):self.goto();self.ensure_project(name)
 def current_project_url(self):return self.project
 def detect_editor_mode(self):return 'agent'
 def select_agent_generation_type(self,kind):assert kind=='image'
 def attach_agent_media(self,refs,reuse_existing=True):self.projects[self.project]['refs']=refs;return len(refs)
 def media_assets(self):
  state=self.projects[self.project]
  rows=[{'sig':'ref'+str(i),'kind':'image'} for i in range(len(state['refs']))]
  if state.get('complete'):rows.append({'sig':'generated','kind':'image'})
  return rows
 def _fill_editor_box(self,*a):pass
 def agent_submission_state(self,*a):return {'composer_matches':True,'prompt_occurrences':0}
 def wait_for_submission_ack(self,*a):return True
 def submit_prepared_text_video(self,mode):
  type(self).submissions+=1;self.projects[self.project]['submitted']=True
 def wait_for_agent_generation(self,**kw):
  assert kw['image_request'] is None
  state=self.projects[self.project]
  if self.ready and state['submitted']:state['complete']=True
  return state.get('complete',False)
 def read_asset_generation_prompt(self,sig):return 'Flow rewritten wording'
 def download_latest_asset(self,path,**kw):
  if self.copy_reference:
   Path(path).write_bytes(Path(self.projects[self.project]['refs'][0]).read_bytes())
  else:Image.new('RGB',(128,128),'green').save(path)
class Provider:
 def __init__(self):self.bridge=Browser()
 def _ensure(self):return self.bridge
 def close(self):pass
 def _fresh_asset_candidates(self,rows,baseline,kind=None):return [r for r in rows if r['sig'] not in baseline and r['kind']==kind]
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'job';self.root.mkdir()
  (self.root/'storyboard').mkdir();self.worker=self.root/'.flow-workers/economy-frame-artifacts';self.worker.mkdir(parents=True)
  (self.root/'production_manifest.json').write_text(json.dumps({'job_id':'job','aspect':'16:9','shots':[{'shot_id':'shot_001','accepted_take':None}]}))
  for name,color in [('character_master.jpg','red'),('location_master.jpg','blue')]:Image.new('RGB',(128,128),color).save(self.root/'storyboard'/name)
  self.paths=[self.worker/'shot_001_open_abcdef.jpg.flow-request.json',self.worker/'shot_001_open_abcdef.jpg.replacement-01.jpg.flow-request.json']
  for i,p in enumerate(self.paths):
   prompt=Browser._agent_image_instruction('STORYBOARD OPEN FRAME, landscape 16:9. Kanha walking.', '16:9',1)
   p.write_text(json.dumps({'kind':'image','status':'pending','submitted_prompt':prompt,'project_url':'https://flow.google.com/project/old'}))
  Browser.projects={};Browser.submissions=0;Browser.ready=True;Browser.copy_reference=False
  flow=types.ModuleType('engine.providers.flow_browser');flow.FlowBrowser=Browser;flow.FlowBrowserProvider=Provider;flow.media_signature_matches=lambda a,b:bool(a) and a==b
  lock=types.ModuleType('engine.production_lock');lock.production_slot=lambda root:contextlib.nullcontext()
  self.patch=patch.dict('sys.modules',{'engine.providers.flow_browser':flow,'engine.production_lock':lock});self.patch.start()
 def tearDown(self):self.patch.stop();self.tmp.cleanup()
 def test_plan_groups_duplicate_requests(self):
  p=regen.plan(self.root);self.assertEqual(p['frame_count'],1);self.assertEqual(len(p['frames'][0]['journals']),2)
  self.assertEqual(Browser.submissions,0)
 def test_rewritten_prompt_capture_and_safe_resume(self):
  r=regen.regenerate(self.root,True,1);self.assertEqual(r['status'],'ready_to_resume',r)
  self.assertEqual(Browser.submissions,1);self.assertTrue(check_job(self.root)['safe_to_generate'])
  for p in self.paths:
   d=json.loads(p.read_text());self.assertEqual(d['status'],'superseded_by_authorized_replacement')
   self.assertEqual(json.loads((self.root/d['original_request_backup']).read_text())['status'],'pending')
  r=regen.regenerate(self.root,True,1);self.assertEqual(Browser.submissions,1)
 def test_uncertain_request_recovers_without_resubmission(self):
  Browser.ready=False;r=regen.regenerate(self.root,True,1)
  self.assertEqual(r['status'],'replacement_pending');self.assertEqual(Browser.submissions,1)
  Browser.ready=True;r=regen.regenerate(self.root,True,1)
  self.assertEqual(r['status'],'ready_to_resume',r);self.assertEqual(Browser.submissions,1)
 def test_uploaded_reference_copy_never_commits(self):
  Browser.copy_reference=True;r=regen.regenerate(self.root,True,1)
  self.assertEqual(r['status'],'replacement_pending');self.assertFalse((self.root/'storyboard/shot_001_open.jpg').exists())
  self.assertTrue(all(json.loads(p.read_text())['status']=='pending' for p in self.paths))
 def test_changed_committed_frame_blocks_safe_resume(self):
  regen.regenerate(self.root,True,1);(self.root/'storyboard/shot_001_open.jpg').write_bytes(b'changed')
  self.assertFalse(check_job(self.root)['safe_to_generate'])
 def test_multiple_new_assets_refused(self):
  b=Browser();b.ensure_project('test');b.attach_agent_media([],True)
  p=Provider();p._fresh_asset_candidates=lambda *a,**kw:[{'sig':'a'},{'sig':'b'}]
  with self.assertRaises(RuntimeError):regen.capture(p,b,{'project_url':b.project,'baseline':[]},self.root/'out.jpg',[])
 def test_reference_settlement_failure(self):
  b=Browser();b.ensure_project('test')
  with self.assertRaises(RuntimeError):regen.settled_references(b,2,seconds=0)
  self.assertEqual(Browser.submissions,0)
 def test_cap_prevents_new_submission(self):
  p=self.worker/'shot_001_close_abcdef.jpg.flow-request.json';p.write_text(self.paths[0].read_text())
  r=regen.regenerate(self.root,True,1);self.assertEqual(r['status'],'cap_exceeded');self.assertEqual(Browser.submissions,0)
 def test_partial_commit_replays_idempotently(self):
  original=regen.commit
  def fail(root,record,out):
   # Simulate one old journal being superseded before interruption.
   original(root,record,out);raise OSError('interruption before ledger checkpoint')
  with patch.object(regen,'commit',fail):r=regen.regenerate(self.root,True,1)
  self.assertEqual(r['results'][0]['status'],'pending_or_blocked')
  r=regen.regenerate(self.root,True,1);self.assertEqual(r['status'],'ready_to_resume',r)
  self.assertEqual(Browser.submissions,1)

class GateRegressionTests(unittest.TestCase):
 def test_legacy_states_and_corruption(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);(root/'production_manifest.json').write_text('{}')
   p=root/'frame.jpg.flow-request.json'
   p.write_text('{"status":"downloaded"}')
   self.assertTrue(check_job(root)['safe_to_generate'])
   p.write_text('{"status":"pending"}');(root/'frame.jpg').write_bytes(b'existing')
   self.assertFalse(check_job(root)['safe_to_generate'])
   p.write_text('broken');self.assertEqual(check_job(root)['unresolved'][0]['state'],'unreadable')

class RestoreTests(unittest.TestCase):
 setUp=Tests.setUp
 tearDown=Tests.tearDown
 def test_restores_changed_frame_without_new_submission(self):
  regen.regenerate(self.root,True,1)
  p=self.root/'storyboard/shot_001_open.jpg';original=p.read_bytes();p.write_bytes(b'changed')
  result=regen.regenerate(self.root,True,1)
  self.assertEqual(result['status'],'ready_to_resume',result)
  self.assertEqual(p.read_bytes(),original);self.assertEqual(Browser.submissions,1)
 def test_redownloads_missing_captured_asset_without_new_submission(self):
  regen.regenerate(self.root,True,1)
  p=self.root/'authorized_frame_replacements/shot_001_open/replacement.jpg';p.unlink()
  result=regen.regenerate(self.root,True,1)
  self.assertEqual(result['status'],'ready_to_resume',result);self.assertEqual(Browser.submissions,1)



class ReopenRecoveryTests(unittest.TestCase):
 setUp=Tests.setUp
 tearDown=Tests.tearDown
 def request(self):
  return {'kind':'image','status':'pending','scope':'isolated_one_frame_one_request',
    'project_url':'https://flow.google.com/project/reopen','baseline':['ref0','ref1'],
    'signature':'generated','actual_asset_prompt':'Flow rewritten wording'}
 def bridge(self):
  b=Browser();b.ensure_project('x',project_url=self.request()['project_url']);b.attach_agent_media([str(self.root/'storyboard/character_master.jpg'),str(self.root/'storyboard/location_master.jpg')])
  Browser.projects[b.project]['complete']=True
  return b
 def test_saved_signature_recovers_three_fresh_images(self):
  b=self.bridge();p=Provider();p._fresh_asset_candidates=lambda rows,*a,**kw:rows
  output=self.root/'replacement.jpg';regen.capture(p,b,self.request(),output,[str(self.root/'storyboard/character_master.jpg'),str(self.root/'storyboard/location_master.jpg')])
  self.assertTrue(regen.image_valid(output));self.assertEqual(Browser.submissions,0)
 def test_rotated_urls_exclude_both_reference_copies(self):
  b=self.bridge();p=Provider();refs=Browser.projects[b.project]['refs'];r=self.request();r['signature']='stale';r['actual_asset_prompt']=None
  b.media_assets=lambda:[{'sig':s,'kind':'image'} for s in ['rotatedref0','rotatedref1','rotatednew']]
  def download(out,**kw):
   sig=kw['preferred_signature']
   if sig.startswith('rotatedref'):Path(out).write_bytes(Path(refs[int(sig[-1])]).read_bytes())
   else:Image.new('RGB',(128,128),'green').save(out)
  b.download_latest_asset=download
  output=self.root/'replacement.jpg';regen.capture(p,b,r,output,refs)
  self.assertEqual(r['signature'],'rotatednew');self.assertTrue(r['reference_exclusion_verified'])
  self.assertTrue(regen.image_valid(output));self.assertEqual(Browser.submissions,0)
 def test_completed_download_bytes_survive_closed_target(self):
  b=self.bridge();p=Provider();output=self.root/'replacement.jpg'
  Image.new('RGB',(128,128),'green').save(str(output)+'.download.jpg')
  b.media_assets=lambda:(_ for _ in ()).throw(AssertionError('should reuse staged file'))
  regen.capture(p,b,self.request(),output,Browser.projects[b.project]['refs'])
  self.assertTrue(regen.image_valid(output));self.assertEqual(Browser.submissions,0)
 def test_closed_download_reconnects_without_submission(self):
  b=self.bridge();p=Provider();p.bridge=b;output=self.root/'replacement.jpg'
  Closed=type('FlowBrowserClosedError',(RuntimeError,),{})
  b.download_latest_asset=lambda *a,**kw:(_ for _ in ()).throw(Closed('target closed'))
  regen.recover_capture(Provider,p,b,{'project_name':'x'},self.request(),output,Browser.projects[b.project]['refs'])
  self.assertTrue(regen.image_valid(output));self.assertEqual(Browser.submissions,0)
 def test_rotated_ambiguous_non_reference_images_stay_blocked(self):
  b=self.bridge();p=Provider();r=self.request();r['signature']='stale';r['actual_asset_prompt']=None
  b.media_assets=lambda:[{'sig':s,'kind':'image'} for s in ['rotated1','rotated2','rotated3']]
  with self.assertRaises(RuntimeError):regen.capture(p,b,r,self.root/'replacement.jpg',Browser.projects[b.project]['refs'])
  self.assertEqual(Browser.submissions,0)

if __name__=='__main__':unittest.main()

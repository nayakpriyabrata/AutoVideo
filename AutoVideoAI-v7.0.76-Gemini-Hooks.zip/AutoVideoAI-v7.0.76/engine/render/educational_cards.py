"""Educational text cards (7.0.75).

Only for educational videos: content type "education" and not a story preset.
Story, cartoon and cinematic-story videos never get these cards.

Copy is drafted by the AI provider chosen for drafting (Gemini Web by default,
or ChatGPT, Indus, the Gemini or OpenAI API, Groq, Grok or Ollama) and anchored
to the spoken narration by speech_cards. This module only draws:

* a points series: a translucent, numbered panel of 2-8 points. The panel opens
  when the first point starts, highlights the point being covered, moves through
  every point across the video, and closes after the last point.
* takeaway / tip / warning: one point with a glyph badge.

Every card PNG is full-canvas and transparent; the panel rectangle is returned as
``box`` so the FFmpeg renderer can open and close it (anim = 'open', 'close' or 'pop').
"""
from __future__ import annotations

import math
from pathlib import Path

from PIL import Image, ImageDraw

EDUCATIONAL_TYPES = ("education",)
STORY_MARKERS = ("story", "cartoon", "kids", "fairy", "animation")
SINGLE_KINDS = ("takeaway", "tip", "warning")
LIST_KIND = "points"
EDUCATIONAL_KINDS = SINGLE_KINDS + (LIST_KIND,)
LABELS = {"takeaway": "KEY IDEA", "tip": "TRY THIS", "warning": "AVOID THIS"}
MIN_POINTS, MAX_POINTS, MAX_POINT_CHARS = 2, 8, 60
INK = (12, 20, 35, 255)


def is_educational(content_type, preset="") -> bool:
    """True only for educational videos. Any story, cartoon or animation marker excludes it."""
    kind = str(content_type or "").strip().lower()
    if kind not in EDUCATIONAL_TYPES:
        return False
    label = str(preset or "").lower()
    return not any(marker in label for marker in STORY_MARKERS)


def _badge(d, kind, cx, cy, r, palette):
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=palette["accent"])
    stroke = max(4, int(r * .22))
    if kind == "tip":
        d.line([(cx - .50 * r, cy + .05 * r), (cx - .12 * r, cy + .42 * r), (cx + .52 * r, cy - .38 * r)],
               fill=INK, width=stroke, joint="curve")
    elif kind == "warning":
        d.polygon([(cx, cy - .62 * r), (cx + .66 * r, cy + .50 * r), (cx - .66 * r, cy + .50 * r)], fill=INK)
        d.rounded_rectangle((cx - .08 * r, cy - .30 * r, cx + .08 * r, cy + .16 * r),
                            radius=max(2, int(.06 * r)), fill=palette["accent"])
        d.ellipse((cx - .09 * r, cy + .27 * r, cx + .09 * r, cy + .43 * r), fill=palette["accent"])
    else:  # takeaway: five-point star
        points = []
        for i in range(10):
            angle = -math.pi / 2 + i * math.pi / 5
            radius = .62 * r if i % 2 == 0 else .27 * r
            points.append((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
        d.polygon(points, fill=INK)


def render_single(card: dict, path, width: int, height: int, style: str) -> dict:
    from .typography import resolve_style, PALETTES, fit, draw_text
    kind = card["kind"]
    style = resolve_style(style)
    palette = PALETTES[style]
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    vertical = height > width
    scale = min(width, height) / 1080.0
    left, top = int(width * .065), int(height * .12)
    panel_w = int(width * (.80 if vertical else .62))
    pad, stroke = max(12, int(30 * scale)), max(1, int(3 * scale))
    badge_r = max(26, int(52 * scale))
    content_x = left + pad + 2 * badge_r + pad
    content_w = left + panel_w - pad - content_x
    label = fit(d, LABELS[kind], content_w, int(60 * scale), size=44 * scale, minimum=30 * scale,
                style=style, bold=True, max_lines=1, stroke=max(1, stroke - 1))
    body = fit(d, card["text"], content_w, int(height * .36), size=66 * scale, minimum=44 * scale,
               style=style, bold=True, headline=True, max_lines=3, stroke=stroke)
    gap = int(10 * scale)
    text_h = (label.height if label else 0) + gap + body.height
    panel_h = max(2 * badge_r, text_h) + 2 * pad
    d.rounded_rectangle((left, top, left + panel_w, top + panel_h), radius=int(28 * scale),
                        fill=palette["panel"], outline=(255, 255, 255, 65), width=max(1, int(2 * scale)))
    _badge(d, kind, left + pad + badge_r, top + panel_h / 2, badge_r, palette)
    y = top + (panel_h - text_h) / 2
    boxes = []
    if label:
        boxes.append(draw_text(d, label, (content_x, y, content_x + content_w, y + label.height), palette["secondary"]))
    y += (label.height if label else 0) + gap
    boxes.append(draw_text(d, body, (content_x, y, content_x + content_w, y + body.height), (255, 255, 255, 255)))
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    img.save(path)
    return {"kind": kind, "path": str(path), "box": [left, top, panel_w, panel_h],
            "layout": {"style": style, "font_sizes": [label.size if label else 0, body.size],
                       "text_boxes": boxes, "canvas": [width, height]}}


def _series_layout(d, series, width, height, style, palette, scale):
    """Largest row size whose wrapped points fit the panel; returns (size, title, rows, panel_h)."""
    from .typography import fit
    vertical = height > width
    max_h = height * (.66 if vertical else .76)
    content_w = int(width * (.80 if vertical else .70)) - 2 * max(12, int(28 * scale))
    stroke = max(1, int(3 * scale))
    gap = max(6, int(12 * scale))
    for size in range(int(52 * scale), int(34 * scale) - 1, -max(1, int(2 * scale))):
        try:
            title = fit(d, series["title"], content_w, int(height * .14), size=76 * scale, minimum=52 * scale,
                        style=style, bold=True, headline=True, max_lines=2, stroke=stroke)
            rows = [fit(d, f"{i + 1}. {p['text']}", content_w, int(height * .5), size=size, minimum=size,
                        style=style, bold=True, max_lines=2, stroke=stroke)
                    for i, p in enumerate(series["points"])]
        except ValueError:
            continue
        pad = max(12, int(28 * scale))
        total = 2 * pad + title.height + gap + sum(r.height for r in rows) + gap * (len(rows) - 1) + pad // 2
        if total <= max_h:
            return size, title, rows, int(total)
    raise ValueError("Points list is too long for one card: shorten the points or use fewer of them")


def render_series(series: dict, path, width: int, height: int, style: str, active: int) -> dict:
    """One frame of the points series with point ``active`` (zero-based) highlighted.

    Points are numbered and wrapped; the font shrinks (never below 34 px at 1080 wide) so
    up to eight points fit. The active point gets a soft highlight bar.
    """
    from .typography import resolve_style, PALETTES, draw_text
    style = resolve_style(style)
    palette = PALETTES[style]
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    vertical = height > width
    scale = min(width, height) / 1080.0
    left, top = int(width * .065), int(height * .12)
    panel_w = int(width * (.80 if vertical else .70))
    pad, stroke = max(12, int(28 * scale)), max(1, int(3 * scale))
    gap = max(6, int(12 * scale))
    _, title, rows, panel_h = _series_layout(d, series, width, height, style, palette, scale)
    d.rounded_rectangle((left, top, left + panel_w, top + panel_h), radius=int(28 * scale),
                        fill=palette["panel"], outline=(255, 255, 255, 65), width=max(1, int(2 * scale)))
    boxes = []
    y = top + pad
    boxes.append(draw_text(d, title, (left + pad, y, left + panel_w - pad, y + title.height), palette["accent"]))
    y += title.height + gap
    for index, layout in enumerate(rows):
        if index == active:
            d.rounded_rectangle((left + pad // 2, y - gap // 3, left + panel_w - pad // 2, y + layout.height + gap // 3),
                                radius=max(6, int(14 * scale)), fill=(255, 255, 255, 46))
        color = palette["secondary"] if index == active else (255, 255, 255, 215)
        boxes.append(draw_text(d, layout, (left + pad, y, left + panel_w - pad, y + layout.height), color))
        y += layout.height + gap
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    img.save(path)
    return {"kind": "list", "path": str(path), "start": series["start"], "end": series["end"],
            "title": series["title"], "opacity": 1, "anchor": "center", "fade_in": .18, "fade_out": .18,
            "box": [left, top, panel_w, panel_h],
            "layout": {"style": style, "font_sizes": [title.size] + [r.size for r in rows],
                       "text_boxes": boxes, "canvas": [width, height], "active": active}}


def render_card_png(card: dict, path, width: int, height: int, style: str = "playful") -> dict:
    """Draw one single-point educational card and return its overlay fields."""
    kind = card.get("kind")
    if kind not in SINGLE_KINDS:
        raise ValueError("Unknown educational card kind: " + str(kind))
    info = render_single(card, path, width, height, style)
    return {**info, "kind": kind, "start": card["start"], "end": card["end"], "title": card["text"],
            "anchor": "top-left", "opacity": 1, "anim": "pop", "fade_in": .22, "fade_out": .22}

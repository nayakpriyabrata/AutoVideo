"""v7.0.105: a paid Flow request is not abandoned because Flow asked a second time.

Field log, job ``20261022-143856-7-small-daily-habits-tha-9729``, 2026-10-27:

    11:21:03  shot_020: Could not attach Agent reference media … no verified composer attachment appeared within 45s
    11:22:53  [Flow] Credit confirmation: clicked 'Approve' (6 credits)
    11:22:54  Flow accepted the request but it is still scheduled in the high-demand queue … remaining=899s
    11:23:27  Approval stopped: Additional approval card exceeds the saved request approval-card limit
    11:23:28  FlowRequestPending … (last observed interval 29s) → 20-retry recovery, every attempt scanning
              "6 gallery assets, 0 fresh candidates" → PAUSED flow_recovery_exhausted at 11:33

Three defects in that sequence:

1. the second approval card ended the wait at 29 s while the *already approved* request still had ~870 s of
   queue left, so the app walked away from a paid request;
2. a request Flow is still queueing counted as "no progress", so recovery gave up after five scans (~10 min);
3. the 45 s composer check declared a reference unattached although the upload had landed (the next attempt
   found it with "Reused existing project media") - which cost a whole extra submission cycle.

No browser is opened and no credit is spent here.
"""
import inspect
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from engine import flow_approval as fa
from engine.automatic_recovery import still_queued
from engine.providers.flow_browser import (
    REFERENCE_ATTACH_TIMEOUT_MS, FlowBrowser, FlowRequestPending, FlowUIChanged)

QUEUE_ERROR = FlowRequestPending(
    "Submitted Flow request has no validated local video asset; Flow adapter reported: Flow accepted the video "
    "request and showed a high-demand queue card during the bounded wait (last observed interval 29s), but no "
    "completed playable/downloadable video became available. No download was attempted and no replacement "
    "generation was submitted; the exact request remains saved.")
QUESTION = ("I'm going to generate 1 video clip interpolating between your start and end frames using Omni 1.1 "
            "Flash in 16:9 at 360p for 6 seconds. Would you like me to kick off this 1 video generation, "
            "costing 6 credits? ")


# ------------------------------------------------------------------ the wait decision

@pytest.mark.parametrize('confirmation, expected', [
    ({}, 'continue'),
    ({'blocked': False, 'clicked': 'Approve'}, 'continue'),
    ({'blocked': True, 'card_limit_reached': True, 'approved_cards': 1}, 'keep_waiting'),
    ({'blocked': True, 'card_limit_reached': True, 'approved_cards': 2}, 'keep_waiting'),
    ({'blocked': True, 'card_limit_reached': True, 'approved_cards': 0}, 'stop'),
    ({'blocked': True, 'reason': 'credit guard: 9 > 6'}, 'stop'),
    ({'blocked': True, 'reason': 'manual approval requested'}, 'stop'),
])
def test_a_second_card_leaves_an_approved_request_waiting(confirmation, expected):
    assert fa.wait_decision(confirmation) == expected


def test_the_card_limit_is_its_own_recoverable_verdict():
    error = fa.ApprovalCardLimitReached(cards=1, limit=1, cost=6)
    assert isinstance(error, ValueError)          # callers that catch ValueError keep working
    assert error.cards == 1 and error.limit == 1 and error.cost == 6
    assert 'approval-card limit' in str(error)


def test_reserve_raises_the_typed_limit_after_one_reserved_card(tmp_path):
    journal = tmp_path / 'take_01.mp4.flow-request.json'
    journal.write_text(json.dumps({'approval_reservations': [
        {'key': 'other', 'cost': 6, 'status': 'reserved'}]}))
    with pytest.raises(fa.ApprovalCardLimitReached) as caught:
        fa.reserve(journal, QUESTION, 6, 60, 1)
    assert caught.value.cards == 1
    # nothing was written: the refused card never reaches the journal
    assert len(json.loads(journal.read_text())['approval_reservations']) == 1


def test_reserve_still_refuses_a_card_over_the_credit_cap(tmp_path):
    journal = tmp_path / 'take_01.mp4.flow-request.json'
    journal.write_text(json.dumps({'approval_reservations': []}))
    with pytest.raises(ValueError) as caught:
        fa.reserve(journal, QUESTION, 6, 5, 1)
    assert not isinstance(caught.value, fa.ApprovalCardLimitReached)
    assert 'Cumulative credit guard' in str(caught.value)


# ------------------------------------------------------------------ queue is not failure

def test_the_field_queue_message_is_recognised_as_queued():
    assert still_queued(QUEUE_ERROR) is True


@pytest.mark.parametrize('error', [
    FlowRequestPending('Existing request still has no single identifiable asset after bounded gallery scans'),
    FlowRequestPending('Image recovery checkpoint retained: browser closed'),
    FlowUIChanged('composer was not found'),
    RuntimeError('high-demand queue'),
])
def test_only_a_submitted_queue_wait_is_exempt(error):
    assert still_queued(error) is False


def test_a_queued_request_is_waited_out_instead_of_being_abandoned(tmp_path, monkeypatch):
    monkeypatch.setenv('HOME', str(tmp_path / 'home'))
    from engine.automatic_recovery import run_with_recovery
    from engine.factory import Factory, RecoverableInterruption

    factory = Factory(str(tmp_path / 'outputs'), str(tmp_path / 'data/jobs.db'))
    job = factory.create_job('Queued request wait', dry_run=True)
    calls = []

    def run(*args):
        calls.append(1)
        error = FlowRequestPending(str(QUEUE_ERROR))
        factory._pause_pending_flow(factory.pm.load_manifest(job), 'shot_020', error)
    factory._run_job = run
    with pytest.raises(RecoverableInterruption):
        run_with_recovery(factory, job, None, True, sleep=lambda _: None)
    # five scans were the old ceiling for "no progress"; a queue wait keeps going to the total bound
    assert len(calls) == 21
    state = json.loads(Path(factory.pm.job_dir(job) + '/automatic_recovery.json').read_text())
    assert state['history'][-1]['queued'] is True
    assert factory.db.get(job)['status'] == 'paused'


# ------------------------------------------------------------------ reference attachment

def test_the_composer_attachment_check_waits_ninety_seconds():
    assert REFERENCE_ATTACH_TIMEOUT_MS == 90000
    default = inspect.signature(FlowBrowser._finish_agent_media_picker).parameters['timeout_ms'].default
    assert default is REFERENCE_ATTACH_TIMEOUT_MS


class _FakePage:
    def __init__(self):
        self.waits = 0

    def wait_for_timeout(self, ms):
        self.waits += 1

    def keyboard_press(self, key):
        pass

    press = keyboard_press

    class _Chooser:
        class value:
            @staticmethod
            def set_files(path):
                pass

    def expect_file_chooser(self, timeout=5000):
        page = self

        class _Context:
            def __enter__(self_inner):
                return page._Chooser()

            def __exit__(self_inner, *exc):
                return False
        return _Context()


def test_an_upload_that_only_lands_late_is_attached_from_the_project_media(tmp_path, monkeypatch):
    from engine import flow_reference_policy as policy

    image = tmp_path / 'shot_020_open.jpg'
    image.write_bytes(b'\xff\xd8\xff\xd9')
    monkeypatch.setattr(policy, 'upload_record', lambda *a, **k: None)
    monkeypatch.setattr(policy, 'reference_upload_attempt', lambda *a, **k: None)

    browser = FlowBrowser.__new__(FlowBrowser)
    browser._page = _FakePage()
    calls = {'reuse': 0}

    browser._media_upload_alias = lambda path: 'AV_a4e5d83d2775_shot_020_open.jpg'
    browser._agent_reference_names = lambda: set()
    browser.current_project_url = lambda: 'https://flow.google.com/project/fe1ccc67-bf80-4948-8530-0bf9c39e5a17'
    browser._dismiss_media_picker = lambda: None
    browser._open_agent_add_menu = lambda: None
    browser._clear_media_picker_search = lambda: None
    browser._resolve = lambda key, timeout_ms=4000: SimpleNamespace(click=lambda timeout=4000: None)
    browser._aliased_upload_path = lambda path, alias: str(path)
    browser._finish_agent_media_picker = lambda *a, **k: False      # the 90 s verification failed

    def reuse(alias):
        calls['reuse'] += 1
        return True
    browser._try_attach_existing_project_media = reuse

    attached = browser.attach_agent_media([str(image)])
    assert attached == 1 and calls['reuse'] == 1


def test_an_upload_that_is_really_missing_still_fails_without_submitting(tmp_path, monkeypatch):
    from engine import flow_reference_policy as policy

    image = tmp_path / 'shot_020_open.jpg'
    image.write_bytes(b'\xff\xd8\xff\xd9')
    monkeypatch.setattr(policy, 'upload_record', lambda *a, **k: None)
    monkeypatch.setattr(policy, 'reference_upload_attempt', lambda *a, **k: None)

    browser = FlowBrowser.__new__(FlowBrowser)
    browser._page = _FakePage()
    browser._media_upload_alias = lambda path: 'AV_a4e5d83d2775_shot_020_open.jpg'
    browser._agent_reference_names = lambda: set()
    browser.current_project_url = lambda: 'https://flow.google.com/project/fe1ccc67-bf80-4948-8530-0bf9c39e5a17'
    browser._dismiss_media_picker = lambda: None
    browser._open_agent_add_menu = lambda: None
    browser._clear_media_picker_search = lambda: None
    browser._resolve = lambda key, timeout_ms=4000: SimpleNamespace(click=lambda timeout=4000: None)
    browser._aliased_upload_path = lambda path, alias: str(path)
    browser._finish_agent_media_picker = lambda *a, **k: False
    browser._try_attach_existing_project_media = lambda alias: False

    with pytest.raises(Exception) as caught:
        browser.attach_agent_media([str(image)])
    message = str(caught.value)
    assert '90s' in message and 'No generation submitted' in message


# ------------------------------------------------------------------ console guidance

def test_the_console_guidance_describes_the_current_state():
    import cli
    pause = {'paused_at': '2026-10-26T15:11:06+05:30', 'shot_id': 'shot_014',
             'reason': 'Flow video request is saved at …/flow/shots/shot_014/take_01.mp4.flow-request.json …',
             'accepted_shots': 13, 'total_shots': 45,
             'actions': [{'label': 'Resume', 'command': 'python3 cli.py v3 resume job'}]}
    state = {'shot_id': 'shot_018', 'reason': 'Superseded notice: this job was paused at shot_014 …',
             'pause_notice_stale': True,
             'pause_notice_superseded': 'Flow video request is saved at …/flow/shots/shot_014/…',
             'accepted_shots': 17, 'total_shots': 45,
             'unresolved_journals': ['flow/shots/shot_020/take_01.mp4.flow-request.json'],
             'actions': [{'label': 'Resume', 'command': 'python3 cli.py v3 resume job'}]}
    text = '\n'.join(cli.pause_guidance_lines(pause, state))
    assert 'shot=shot_018' in text                       # the current stopping point
    assert 'Superseded notice' in text
    assert 'superseded_reason=' in text and 'shot_014' in text
    assert 'completed=17/45 (manifest)' in text          # not the saved 13
    assert 'unresolved_requests=1' in text and 'shot_020' in text


def test_the_console_guidance_still_works_without_a_state():
    import cli
    pause = {'paused_at': 'x', 'shot_id': 'shot_001', 'reason': 'plain reason',
             'accepted_shots': 1, 'total_shots': 2, 'actions': []}
    text = '\n'.join(cli.pause_guidance_lines(pause))
    assert 'shot=shot_001' in text and 'plain reason' in text and 'completed=1/2' in text
    assert 'superseded_reason' not in text

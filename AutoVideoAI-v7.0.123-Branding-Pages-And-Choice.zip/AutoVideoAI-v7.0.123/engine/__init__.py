"""Auto Video AI Engine; load legacy media stacks only when requested."""
import importlib

def __getattr__(name):
    modules = {'generate_script': 'script_generator', 'text_to_speech': 'voiceover',
               'get_visuals': 'visuals', 'build_video': 'video_builder',
               'create_video_from_topic': 'automation'}
    if name not in modules:
        raise AttributeError(name)
    value = getattr(importlib.import_module('.' + modules[name], __name__), name)
    globals()[name] = value
    return value

__all__ = ["generate_script", "text_to_speech", "get_visuals", "build_video", "create_video_from_topic"]

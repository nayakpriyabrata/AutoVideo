"""Turn a prepared Create step 4 narration batch into something you can run (v7.0.120).

v7.0.119 made the batches in Queue & Resume readable and playable - and stopped there. The panel could
describe and play voices but offered no way to go from "my three languages are narrated" to "a job is
using them", which is exactly the next question it raised.

Two honest paths exist, and both are implemented here:

* **Attach the voices to a saved job** whose script is the same narration. ``Factory`` reuses
  ``production/prepared_speech.json`` only when its script and language match the job's approved script,
  so this module refuses a job whose script differs instead of attaching audio that a Resume would reject.
* **Create a production from these voices**: an approved plan is built from the batch's own master script
  (the words the narration was made from), the job is created from that plan - so its script *is* the
  narration - and the batch is attached immediately. Nothing is generated: the new job waits for an
  explicit Resume, so no Flow credit is spent by choosing this.

Nothing here records, re-records, re-renders or deletes anything.
"""
from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path

from .production import save

# The user's own assertion, required before a plan is written - never inferred by this module.
RIGHTS_DECLARATIONS = {
    'own_content': 'I wrote this narration or own it',
    'written_permission': 'I have written permission to use this narration',
    'licensed_content': 'This narration is licensed to me',
}


def norm(text) -> str:
    return ' '.join(str(text or '').split())


def job_script(job_dir) -> str:
    """The narration this saved job approved, or '' when it has no script yet."""
    try:
        data = json.loads((Path(job_dir) / 'script.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return ''
    return norm(data.get('narration'))


def jobs_using_script(batch, job_dirs) -> list[dict]:
    """Saved jobs whose approved script is exactly this batch's master narration."""
    master = norm(batch.get('source_script'))
    if not master:
        return []
    rows = []
    for job in job_dirs:
        folder = Path(job)
        if not folder.is_dir() or norm(job_script(folder)) != master:
            continue
        try:
            manifest = json.loads((folder / 'production_manifest.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            manifest = {}
        rows.append({'job_id': folder.name, 'path': str(folder),
                     'topic': str(manifest.get('topic') or ''), 'language': str(manifest.get('language') or ''),
                     'has_editions': (folder / 'production' / 'language_editions.json').is_file()})
    return sorted(rows, key=lambda row: row['job_id'], reverse=True)


def finished(batch) -> bool:
    return bool(batch.get('ready'))


def _require_finished(batch):
    if not finished(batch):
        raise ValueError('These voices are not finished yet (' + str(batch.get('phase') or 'unknown') + '): '
                         + str(len(batch.get('done') or [])) + ' of ' + str(len(batch.get('editions') or []))
                         + ' languages have audio. Resume the batch first, then use it.')


def attach(batch, job_dir, *, factory=None) -> dict:
    """Copy a finished batch's voices into a saved job and record where they came from.

    Refuses a job whose script is not the narration the voices speak: the engine would reject that
    narration later anyway, and an attachment that cannot be reused is worse than none.
    """
    _require_finished(batch)
    from .speech_cards import attach_prepared_batch
    folder = Path(job_dir)
    if not (folder / 'production_manifest.json').is_file():
        raise ValueError('No saved job at ' + str(folder) + ' (production_manifest.json is missing).')
    master = norm(batch.get('source_script'))
    current = job_script(folder)
    if not current:
        raise ValueError('This job has no approved script yet, so its narration is not decided and these voices '
                         'cannot be attached. Create a production from these voices instead.')
    if current != master:
        raise ValueError('This job\'s script is not the narration these voices speak, so the engine would refuse '
                         'them at Resume. Use a job that has this script, or create a production from these '
                         'voices instead.')
    bundles = attach_prepared_batch(folder, {'phase': batch.get('phase'), 'bundles': batch.get('bundles') or {},
                                             'source_language': batch.get('source_language')})
    editions = list(batch.get('editions') or [])
    path = folder / 'production' / 'language_editions.json'
    try:
        record = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        record = {}
    record.update({'source_language': batch.get('source_language'), 'editions': editions,
                   'bundles': bundles, 'profiles': record.get('profiles') or {},
                   'prepare_audio': True, 'text_cards': bool((batch.get('request') or {}).get('text_cards', True)),
                   'hooks_enabled': bool((batch.get('request') or {}).get('hooks', False)),
                   'educational': bool((batch.get('request') or {}).get('educational', False)),
                   'topic': record.get('topic') or (batch.get('request') or {}).get('topic', ''),
                   'status': 'prepared batch attached from Jobs & Recovery'})
    save(path, record)
    marker = {'batch': str(batch.get('path')), 'batch_key': batch.get('key'), 'created': batch.get('created'),
              'scripts_sha256': _scripts_sha(batch), 'languages': editions,
              'attached_at': datetime.datetime.now().isoformat(timespec='seconds')}
    save(folder / 'production' / 'speech_attachment.json', marker)
    if factory is not None:
        try:
            factory.db.upsert(folder.name, status=(factory.db.get(folder.name) or {}).get('status', 'created'))
        except Exception:
            pass
    return {'job_id': folder.name, 'path': str(folder), 'languages': editions,
            'voices': sorted(bundles), 'attachment': str(folder / 'production' / 'speech_attachment.json')}


def _scripts_sha(batch) -> str:
    scripts = batch.get('scripts') or {}
    return hashlib.sha256(json.dumps(scripts, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def plan_for_batch(batch, *, declaration) -> Path:
    """An approved plan whose narration is exactly these voices' words (never a rewrite).

    ``declaration`` is the user's own rights statement; this function refuses to invent one.
    """
    _require_finished(batch)
    if declaration not in RIGHTS_DECLARATIONS:
        raise ValueError('Choose how you may use this narration: '
                         + '; '.join(code + ' = ' + label for code, label in RIGHTS_DECLARATIONS.items()))
    master = norm(batch.get('source_script'))
    if not master:
        raise ValueError('This batch has no saved master narration, so no plan can be made from it.')
    request = batch.get('request') or {}
    topic = str(request.get('topic') or '').strip() or ' '.join(master.split()[:8])
    plan = {'schema_version': 1, 'approved': True, 'topic': topic, 'narration': master,
            'language': str(batch.get('source_language') or 'en'),
            'audio_mode': 'voiceover', 'voiceover_enabled': True, 'scenes': [], 'chapters': [],
            'rights': {'declaration': declaration, 'adaptation_confirmed': True},
            'provenance': {'source': 'prepared narration batch (Create step 4)',
                           'batch': str(batch.get('path')), 'scripts_sha256': _scripts_sha(batch),
                           'note': 'The narration was approved by the user in Create step 4; this plan repeats it '
                                   'word for word so the saved voices are the words of the job.'}}
    from .content_plan import validate_plan
    plan = validate_plan(plan)
    target = Path(str(batch.get('path'))) / 'approved_plan.json'
    save(target, plan)
    return target


def measured_seconds(batch) -> int:
    """A duration taken from the finished English voice, not guessed from a word count."""
    durations = []
    for bundle in (batch.get('bundles') or {}).values():
        try:
            value = float(bundle.get('duration') or 0)
        except (TypeError, ValueError):
            continue
        if value > 1:
            durations.append(value)
    if not durations:
        return 0
    source = (batch.get('bundles') or {}).get(batch.get('source_language') or '') or {}
    try:
        primary = float(source.get('duration') or 0)
    except (TypeError, ValueError):
        primary = 0
    return int(round(primary or max(durations)))


def batch_cast(batch) -> list[str]:
    """The saved characters this narration was written for, if Create recorded them (v7.0.122)."""
    return [str(identifier) for identifier in (batch.get('character_ids') or []) if str(identifier).strip()]


def create_job_from_batch(factory, batch, *, profile='STORYBOARD_ECONOMY', declaration,
                          target_seconds=None, max_credits=100, character_ids=None) -> dict:
    """Create a saved job whose script is these voices' words, then attach the voices. Generates nothing.

    v7.0.122: the cast is carried too. ``character_ids`` wins; otherwise the characters recorded with the
    batch are used. Without either, the job's storyboard invents a new person, which is what made a finished
    video ignore the character saved in Character Library.
    """
    cast = list(dict.fromkeys(str(identifier) for identifier in
                              (character_ids if character_ids is not None else batch_cast(batch))))
    if cast:
        from .cast import snapshot_cast
        try:
            snapshot_cast(cast)
        except Exception as error:
            raise ValueError('These characters cannot be used: ' + str(error)
                             + ' Open Character Library, re-approve the missing photo, then choose again.')
    plan_path = plan_for_batch(batch, declaration=declaration)
    seconds = int(target_seconds or measured_seconds(batch) or 0)
    if not 10 <= seconds <= 7200:
        seconds = 300
    plan = json.loads(Path(plan_path).read_text(encoding='utf-8'))
    from .studio_config import DEFAULTS, config_to_factory_kwargs
    cfg = dict(DEFAULTS)
    request = batch.get('request') or {}
    cfg.update({'topic': plan['topic'], 'video_type': 'faceless_youtube', 'aspect': '16:9',
                'production_mode': 'youtube_pro', 'production_mode_engine': 'youtube_pro',
                'duration': seconds, 'profile': profile, 'language': plan['language'],
                'theme': 'motivational', 'voiceover_enabled': True,
                'text_cards_enabled': bool(request.get('text_cards', True)),
                'hooks_enabled': bool(request.get('hooks', False)),
                'speech_cards_enabled': False, 'gemini_video_count': 0,
                'tts_provider': str(request.get('provider') or 'auto'),
                'character_ids': cast,
                'approved_plan_path': str(plan_path), 'max_credits': int(max_credits)})
    kwargs = config_to_factory_kwargs(cfg)
    job_id = factory.create_job(topic=cfg['topic'], video_type=cfg['video_type'],
                                aspect=cfg['aspect'], **kwargs)
    attached = attach(batch, factory.pm.job_dir(job_id), factory=factory)
    return {'job_id': job_id, 'plan': str(plan_path), 'seconds': seconds,
            'character_ids': cast, 'characters': [_cast_name(identifier) for identifier in cast], **attached}


def _cast_name(identifier):
    from .content_library import CharacterLibrary
    try:
        return str(CharacterLibrary().get(identifier)['name'])
    except Exception:
        return str(identifier)

import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest

from engine.factory import Factory
from engine.storage_manager import inventory, preview_deletion, delete_selected
from engine.providers.flow_browser import FlowBrowser
from engine.production_lock import production_slot, serialize_clip_production


def setup(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv('HOME', str(tmp_path / 'home'))
    import engine.providers.flow_browser as flow
    monkeypatch.setattr(flow, 'PROFILE_DIR', str(tmp_path / '.flow-profile'))
    f = Factory(str(tmp_path / 'outputs'), str(tmp_path / 'data/jobs.db'))
    job = f.create_job('Saved long video', dry_run=True)
    folder = Path(f.pm.job_dir(job))
    final = folder / 'render' / (job + '-final.mp4')
    final.write_bytes(b'video')
    (folder / 'storyboard/frame.jpg').write_bytes(b'frame')
    (folder / 'pause_state.json').write_text('{}')
    f.db.upsert(job, status='paused', final_path=str(final))
    return f, job, folder


def review(f, keys, tmp_path):
    return preview_deletion(f, keys, install=tmp_path)


def test_whole_job_removes_media_state_index_workers_snapshots_and_migration_copy(tmp_path, monkeypatch):
    f, job, folder = setup(tmp_path, monkeypatch)
    worker = tmp_path / '.flow-workers' / (job + '-economy-worker-1')
    worker.mkdir(parents=True); (worker / 'cache').write_bytes(b'worker')
    backup = tmp_path / 'migration-backups/old/outputs' / job
    backup.mkdir(parents=True); (backup / 'old.mp4').write_bytes(b'old')
    snapshot = tmp_path / 'logs/flow' / ('AutoVideo-' + job + '_shot_020.png')
    snapshot.parent.mkdir(parents=True); snapshot.write_bytes(b'snapshot')
    library = tmp_path / 'data/characters/original.jpg'
    library.parent.mkdir(parents=True); library.write_bytes(b'original')
    result = delete_selected(f, review(f, ['job:' + job], tmp_path))
    assert not result['remaining'] and result['bytes'] > 0
    assert not any(p.exists() for p in (folder, worker, snapshot, backup))
    assert f.db.get(job) is None and library.read_bytes() == b'original'


def test_clip_folder_deletes_exports_work_and_history_preserves_external_source(tmp_path, monkeypatch):
    f, job, folder = setup(tmp_path, monkeypatch)
    clips = tmp_path / 'outputs/my-clips'; clips.mkdir()
    (clips / 'highlights.partial.json').write_text(json.dumps({'outputs': [str(clips / 'one.mp4')]}))
    (clips / 'one.mp4').write_bytes(b'clip')
    (clips / '_clip_work').mkdir(); (clips / '_clip_work/source.mp4').write_bytes(b'cache')
    (clips / 'clip-history').mkdir(); (clips / 'clip-history/highlights-1.json').write_text('{}')
    source = tmp_path / 'original.mp4'; source.write_bytes(b'original')
    item = next(row for row in inventory(f) if row['kind'] == 'Clip folder')
    assert len(item['videos']) == 1
    result = delete_selected(f, review(f, [item['key']], tmp_path))
    assert not clips.exists() and not result['remaining']
    assert folder.exists() and source.exists()


def test_changed_media_blocks_complete_deletion(tmp_path, monkeypatch):
    f, job, folder = setup(tmp_path, monkeypatch)
    preview = review(f, ['job:' + job], tmp_path)
    (folder / 'storyboard/frame.jpg').write_bytes(b'new data')
    with pytest.raises(ValueError, match='changed'):
        delete_selected(f, preview)
    assert folder.exists() and f.db.get(job)


def test_linked_job_data_and_output_root_are_protected(tmp_path, monkeypatch):
    f, job, folder = setup(tmp_path, monkeypatch)
    source = tmp_path / 'external'; source.write_bytes(b'keep')
    (folder / 'linked').symlink_to(source)
    with pytest.raises(ValueError, match='link'):
        review(f, ['job:' + job], tmp_path)
    (Path(f.pm.root) / 'highlights.json').write_text('{}')
    assert not any(row['path'] == f.pm.root for row in inventory(f))
    assert source.exists()


def test_active_and_queued_job_locks_block_deletion(tmp_path, monkeypatch):
    f, job, folder = setup(tmp_path, monkeypatch)
    preview = review(f, ['job:' + job], tmp_path)
    with production_slot(folder):
        with pytest.raises(ValueError, match='active'):
            delete_selected(f, preview)
    from engine.production_lock import acquire, release
    with (folder / '.production.lock').open('a+b') as handle:
        acquire(handle)
        try:
            with pytest.raises(ValueError, match='queued'):
                delete_selected(f, preview)
        finally:
            release(handle)
    assert folder.exists()


def test_dependency_requires_source_and_consumer_selection(tmp_path, monkeypatch):
    f, job, folder = setup(tmp_path, monkeypatch)
    consumer = f.create_job('Dependent recreation', dry_run=True)
    (Path(f.pm.job_dir(consumer)) / 'recreation.json').write_text(json.dumps({'source_clip': str(folder / 'render' / (job + '-final.mp4'))}))
    with pytest.raises(ValueError, match='Another saved'):
        delete_selected(f, review(f, ['job:' + job], tmp_path))
    assert folder.exists()
    result = delete_selected(f, review(f, ['job:' + job, 'job:' + consumer], tmp_path))
    assert not result['remaining'] and not folder.exists() and not f.db.list()


def test_database_failure_restores_staged_media(tmp_path, monkeypatch):
    f, job, folder = setup(tmp_path, monkeypatch)
    with f.db._cx() as cx:
        cx.execute("CREATE TRIGGER deny_delete BEFORE DELETE ON jobs BEGIN SELECT RAISE(ABORT, 'denied'); END")
    import sqlite3
    with pytest.raises(sqlite3.DatabaseError):
        delete_selected(f, review(f, ['job:' + job], tmp_path))
    assert folder.exists() and (folder / 'render' / (job + '-final.mp4')).exists()
    assert f.db.get(job) and not list(folder.parent.glob('.autovideo-delete-*'))


def test_explicit_resume_renews_once_but_browser_rebuild_does_not(tmp_path, monkeypatch):
    from engine.flow_reference_policy import reference_recovery_episode, reserve_reference_reattach
    monkeypatch.chdir(tmp_path)
    for _ in range(3):
        with reference_recovery_episode():
            assert reserve_reference_reattach('project', 'location')
            assert not reserve_reference_reattach('project', 'location')
            # A rebuilt browser sees the same run identifier.
            assert not reserve_reference_reattach('project', 'location')


def test_download_click_does_not_wait_for_flow_navigation():
    calls = []
    FlowBrowser._click_download_control(NS(click=lambda **kw: calls.append(kw)))
    assert calls == [{'timeout': 3000, 'no_wait_after': True}]


def test_same_browser_renews_exhausted_reference_only_on_explicit_resume(tmp_path, monkeypatch):
    from engine.flow_reference_policy import reference_recovery_episode, reference_episode_id
    monkeypatch.chdir(tmp_path)
    photo = tmp_path / 'location.jpg'; photo.write_bytes(b'original')
    url = 'https://flow.google.com/project/test'
    b = FlowBrowser.__new__(FlowBrowser)
    b.current_project_url = lambda: url
    b._agent_reference_names = lambda: []
    b._try_attach_existing_project_media = lambda name: True
    alias = b._media_upload_alias(str(photo))
    with reference_recovery_episode():
        b._reference_recovery_episode = reference_episode_id()
        b._unavailable_reference_aliases = {(url, alias)}
        from engine.providers.flow_browser import FlowReferenceUnavailable
        with pytest.raises(FlowReferenceUnavailable, match='exhausted'):
            b.attach_agent_media([str(photo)])
    with reference_recovery_episode():
        assert b.attach_agent_media([str(photo)]) == 1


def test_resume_keeps_cached_frames_even_if_diversity_review_is_low(tmp_path):
    from tests.test_v716_frame_batch_recovery import setup_batch
    from tests.test_economy_parallel_frames import _Refs
    from PIL import Image
    f, m, dirs, settings, calls = setup_batch(tmp_path, set())
    settings['flow_image_workers'] = 1
    for shot in m.shots:
        shot.provider = 'image'
        for label, color in [('open', 'red'), ('close', 'blue')]:
            Image.new('RGB', (96, 96), color).save(Path(dirs['storyboard']) / (shot.shot_id + '_' + label + '.jpg'))
    f._image_distance = lambda *args: 0
    before = {p.name: p.read_bytes() for p in Path(dirs['storyboard']).glob('*.jpg')}
    f._generate_economy_frames(m, dirs, _Refs(), False, settings, {}, lambda *args: None)
    assert not calls
    assert before == {p.name: p.read_bytes() for p in Path(dirs['storyboard']).glob('*.jpg')}


def test_download_event_is_kept_when_flow_closes_during_click(tmp_path):
    events = {}
    download = NS(save_as=lambda path: Path(path).write_bytes(b'exact image'))
    def click(**kw):
        events['download'](download)
        raise RuntimeError('Target page closed')
    b = FlowBrowser.__new__(FlowBrowser)
    b._page = NS(on=lambda name, callback: events.update({name: callback}),
        remove_listener=lambda name, callback: events.pop(name),
        wait_for_timeout=lambda ms: (_ for _ in ()).throw(RuntimeError('closed')))
    b._ensure_project_guard_page = lambda url: False
    b._save_download_event = lambda event, path: event.save_as(path)
    path = str(tmp_path / 'frame.jpg')
    assert b._download_from_tile_button(NS(click=click), path) == path
    assert Path(path).read_bytes() == b'exact image' and not events


def test_clip_production_holds_storage_lock(tmp_path, monkeypatch):
    f, job, folder = setup(tmp_path, monkeypatch)
    preview = review(f, ['job:' + job], tmp_path)
    @serialize_clip_production
    def generate(source, output_dir):
        with pytest.raises(ValueError, match='active'):
            delete_selected(f, preview)
        return 'done'
    assert generate('source', tmp_path / 'outputs/clips') == 'done'


def test_dashboard_select_preview_download_and_whole_job_deletion(tmp_path, monkeypatch):
    from tests.test_presentation_dashboard import dashboard, navigate
    monkeypatch.setenv('HOME', str(tmp_path / 'home'))
    f, app = dashboard(tmp_path, monkeypatch)
    job = f.create_job('Selected video', dry_run=True)
    folder = Path(f.pm.job_dir(job))
    (folder / 'render' / (job + '-final.mp4')).write_bytes(b'video')
    navigate(app, 'HISTORY')
    next(w for w in app.multiselect if w.label == 'Select jobs / clip folders').set_value(['job:' + job]).run()
    assert not app.exception
    next(w for w in app.button if w.label == 'Review complete deletion').click().run()
    assert not app.exception and folder.exists()
    next(w for w in app.checkbox if w.label == 'I confirm complete deletion of the selected work').check().run()
    next(w for w in app.button if w.label == 'Delete selected work permanently').click().run()
    assert not app.exception, [e.message for e in app.exception]
    assert not folder.exists() and f.db.get(job) is None
